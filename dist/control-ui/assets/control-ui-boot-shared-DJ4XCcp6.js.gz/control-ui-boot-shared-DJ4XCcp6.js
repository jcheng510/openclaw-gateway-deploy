const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./icon-loader-BeqOmUEn.js","./plugin-contracts-runtime-DSgjMI0R.js","./config-runtime-CgOgfOrG.js","./control-ui-boot-shared-e4-xCIbb.js","./control-ui-boot-shared-vP4joK1k.js","./css-chat-Ckz95ikh.js","./css-chat-custodian-new-session-CbWc8vdc.js","./control-ui-core-D-VUH4Gq.css","./css-chat-DCHf01mf.css","./css-chat-custodian-new-session-FmhgzIjj.css","./control-ui-boot-shared-BJ_QKfFn.css","./chat-outbox-owner-DVzfxli9.js","./sidebar-attention-panel.runtime-De01Jo2_.js","./custodian-alert-store-CZIGRvI8.js","./custodian-alert-store-D3-kKDhQ.js","./channel-avatar-DawdLoLC.js","./session-organizer-operations.runtime-BxG48QHf.js","./session-workspace-recovery.runtime-CguqxHrO.js","./input-dialog-CLHItaSF.js","./cloud-worker-stop.runtime-D557gbSb.js","./input-dialog-BFYyIfPn.js","./session-group-defaults-dialog-BOcIk5kI.js","./control-ui-boot-new-CaEHEcx2.js","./css-cron-custodian-new-session-DdqVeFqw.js","./chat-transcript-styles-BVZgOT1t.js","./css-new-session-BGJnpiJ5.js","./css-config-njfbfHBk.js","./css-cron-custodian-new-session-Ci5c-FgJ.css","./chat-transcript-styles-DHHd4Hhc.css","./css-new-session-C71huhgC.css","./css-config-vi6FusyS.css","./control-ui-boot-new-D-SpiTTi.css","./sidebar-menus-render-EoZhjhbI.js","./sidebar-people.runtime-BCxkEnps.js","./sidebar-agent-roster-DhcmyPLo.js","./roster-element-D3O5pUUK.js","./sidebar-agent-roster-DtAlR-4T.css","./modal-dialog-BJJDzs1S.js","./markdown-mermaid-unFSVeX0.js","./theme-color-DAo4KRoc.js","./session-progress-hovercard.runtime-B-RMvw4i.js","./control-ui-boot-chat-7MGT05MX.js","./css-agents-plugins-skill-workshop-skills-DvcafeYi.js","./css-skill-workshop-D2ZfJfdl.js","./css-question-Ct0OXZAc.js","./session-snapshot-database-DFW5u-6I.js","./css-agents-plugins-skill-workshop-skills-DP4CzO_X.css","./css-skill-workshop-CWhVVscF.css","./css-question-DeaP1V6y.css","./control-ui-boot-chat-CPmZGJw4.css","./session-progress-hovercard-CtXQYegF.css"])))=>i.map(i=>d[i]);
import{n as e}from"./rolldown-runtime-8BhlS34s.js";import{$i as t,Bi as n,Br as r,C as i,D as a,Da as o,Dn as s,En as c,Et as l,Fi as u,Gi as d,Gt as f,Ht as p,Ia as m,Ii as h,Ji as g,Li as _,O as v,On as y,Pa as b,Ra as x,T as S,Tt as ee,Ui as C,Ur as te,Ut as ne,Vt as re,Wr as ie,Wt as ae,X as oe,a as se,ca as ce,ci as le,co as ue,ct as de,di as fe,et as pe,hi as me,i as he,io as ge,l as _e,li as ve,ln as ye,lo as be,m as xe,mi as Se,n as Ce,na as we,nn as Te,oo as Ee,p as De,pn as Oe,qr as w,r as ke,ro as Ae,sa as je,to as Me,yi as Ne,zi as T,zr as Pe,zt as Fe}from"./control-ui-foundation-C3MHh_P-.js";import{$c as Ie,A as Le,Ar as Re,As as ze,B as Be,C as Ve,Cl as He,Dc as Ue,Di as We,Eu as Ge,Fc as Ke,Fr as qe,Fs as Je,Gl as E,Hl as Ye,Hr as Xe,Hs as Ze,Ic as Qe,Il as $e,Is as et,Jr as tt,Jt as nt,Kl as rt,Kr as it,Lc as at,Mt as ot,N as st,Nr as ct,Ns as lt,Nt as ut,O as dt,P as ft,Pc as pt,Ps as mt,Qc as ht,Ql as gt,R as _t,Rl as vt,Sc as yt,Sl as bt,Su as D,Tc as xt,Tl as St,Tu as Ct,Ul as wt,Us as Tt,Vc as Et,Vl as Dt,Vr as Ot,Wl as kt,Wr as At,Xr as jt,Yo as Mt,Zc as O,Zl as Nt,_a as Pt,_l as Ft,_s as It,al as Lt,an as Rt,at as zt,au as Bt,bs as k,cc as Vt,cr as Ht,cu as Ut,dl as A,dr as Wt,el as Gt,eo as Kt,eu as qt,fr as Jt,ga as Yt,gl as Xt,gs as Zt,hc as Qt,hl as $t,hr as en,hu as j,i as tn,ic as nn,il as rn,iu as an,jr as on,js as sn,kc as cn,ks as ln,li as un,ll as dn,lu as M,mc as fn,mr as pn,n as mn,nc as hn,ni as gn,nl as N,no as _n,nu as vn,oc as yn,ol as bn,on as xn,ou as Sn,pa as Cn,pc as wn,pl as Tn,pr as En,pu as Dn,ql as P,qo as On,qt as kn,rl as An,rt as jn,ru as Mn,sc as Nn,sl as Pn,su as Fn,ti as In,ui as Ln,uu as F,wc as Rn,wl as zn,xc as Bn,yc as Vn,zr as Hn}from"./control-ui-core-pYNj5S1a.js";import{C as Un,S as Wn,b as Gn,ht as Kn,t as qn,x as Jn}from"./control-ui-boot-shared-DhhSjjdA.js";import{$ as Yn,$n as Xn,$r as Zn,$t as Qn,Aa as $n,Ar as er,Br as tr,C as nr,Ca as rr,Ea as ir,Er as ar,Fa as or,Fr as sr,Gi as cr,Hi as lr,Ht as ur,Ia as dr,J as fr,Ji as pr,Ki as mr,Kt as hr,La as gr,Li as _r,Lr as vr,Lt as yr,Ma as br,Mi as xr,Mr as Sr,Nr as Cr,Or as wr,Ot as Tr,Pa as Er,Pr as Dr,Q as Or,Qi as kr,Ra as Ar,Rr as jr,Rt as Mr,Si as Nr,Sn as Pr,So as Fr,Ta as Ir,To as Lr,Tr as Rr,Ui as zr,Ut as Br,Vi as Vr,Vt as Hr,Wi as Ur,Wr,Wt as Gr,X as Kr,Xi as I,Y as qr,Yt as Jr,Z as Yr,Zi as L,Zt as Xr,_r as Zr,a as Qr,ao as $r,ar as ei,ba as ti,br as ni,c as ri,co as ii,ct as ai,dr as oi,ea as si,en as ci,er as li,et as ui,fa as di,fn as fi,fo as pi,ft as mi,ga as hi,go as gi,ha as _i,hi as vi,i as yi,ia as bi,jr as xi,kt as Si,la as Ci,lo as wi,mi as Ti,mt as Ei,na as Di,nn as Oi,nr as ki,nt as Ai,o as ji,on as Mi,or as Ni,pa as Pi,pt as Fi,qi as Ii,qr as Li,qt as Ri,ra as zi,rn as Bi,rt as Vi,s as Hi,sn as Ui,sr as Wi,ta as Gi,tt as Ki,ua as qi,uo as Ji,ur as Yi,va as Xi,vi as Zi,vr as Qi,w as $i,wa as ea,wi as ta,wr as na,xa as ra,ya as ia,yi as aa,yr as oa}from"./control-ui-core-D6clmJs8.js";import{$ as R,B as sa,C as ca,F as la,I as ua,M as da,Q as fa,R as pa,S as ma,T as ha,X as z,Y as B,Z as ga,at as _a,c as va,ct as V,d as ya,g as ba,i as xa,it as Sa,m as Ca,mt as wa,nt as H,o as Ta,p as Ea,r as Da,s as Oa,t as ka,tt as U,u as Aa,ut as W,v as ja,y as Ma,z as Na}from"./lit-runtime-DZL1fcCI.js";import{Tt as Pa,at as Fa,it as Ia,ot as La,rt as Ra,w as za,wt as Ba}from"./control-ui-boot-shared-CnK2ZXzW.js";import{_ as Va,a as Ha,at as Ua,b as Wa,c as Ga,et as Ka,i as qa,it as Ja,l as Ya,n as Xa,r as Za,rt as Qa,t as $a,tt as eo,u as to,v as no,x as ro,y as io}from"./control-ui-boot-shared-CES8Ypkl.js";import{c as ao,d as oo,l as so}from"./gateway-runtime-iOL78mIi.js";import{$o as co,Aa as lo,Ai as uo,Al as fo,Ao as po,Bi as mo,Bo as ho,Ci as go,Cl as _o,Co as vo,Cr as yo,D as bo,Dl as xo,Do as So,E as Co,Ea as wo,Ei as To,El as Eo,Eo as Do,Fi as Oo,Gi as ko,Go as Ao,Ho as jo,Ii as Mo,Io as No,Ja as Po,Ji as Fo,Jo as Io,Jr as Lo,Ki as Ro,Ko as zo,Lo as Bo,Lt as Vo,Mo as Ho,Mr as Uo,Nr as Wo,Nt as Go,Oa as Ko,Oo as qo,Pi as Jo,Pt as Yo,Qi as Xo,Qo as Zo,Ri as Qo,Ro as $o,So as es,Sr as ts,Ti as ns,Tl as rs,To as is,Ui as as,Uo as os,Vo as ss,Wi as cs,Wo as ls,Xi as us,Xo as ds,Yi as fs,Yo as ps,Yr as ms,Zi as hs,Zo as gs,_a as _s,_c as vs,_i as ys,_l as bs,aa as xs,ac as Ss,an as Cs,ao as ws,ba as Ts,bi as Es,bo as Ds,co as Os,dc as ks,ei as As,eo as js,es as Ms,fo as Ns,gl as Ps,ho as Fs,ia as Is,in as Ls,io as Rs,is as zs,ji as Bs,jl as Vs,jo as Hs,ki as Us,ko as Ws,la as Gs,lo as Ks,ma as qs,mo as Js,na as Ys,nn as Xs,no as Zs,ns as Qs,oc as $s,oo as ec,pa as tc,qa as nc,qi as rc,qo as ic,rn as ac,ro as oc,rs as sc,so as cc,ta as lc,ti as uc,to as dc,uo as fc,va as pc,vi as mc,vl as hc,wo as gc,xa as _c,xi as vc,xl as yc,xo as bc,ya as xc,yi as Sc,yo as Cc,zi as wc,zo as Tc,zt as Ec}from"./control-ui-boot-shared-3Hl8ksFq.js";import{C as Dc,F as Oc,G as kc,H as Ac,I as jc,K as Mc,L as Nc,M as Pc,P as Fc,R as Ic,S as Lc,T as Rc,V as zc,W as Bc,_ as Vc,b as Hc,bt as Uc,m as Wc,n as Gc,p as Kc,t as qc,w as Jc,x as Yc,z as Xc}from"./control-ui-boot-shared-D-LYw3KU.js";import{S as Zc,_ as Qc,a as $c,i as el,o as tl,r as nl,s as rl}from"./control-ui-boot-shared-C-yZTZmO.js";import{Ft as il,Pt as al}from"./control-ui-boot-shared-og7lWkK4.js";import{K as ol,U as sl,W as cl,X as ll,Y as ul,ht as dl,it as fl,pt as pl,q as ml,st as hl}from"./control-ui-boot-shared-TgR3hRAg.js";import{A as gl,C as _l,D as vl,M as yl,N as bl,P as xl,T as Sl,_ as Cl,a as wl,c as Tl,f as El,g as Dl,h as Ol,i as kl,j as Al,k as jl,m as Ml,n as Nl,o as Pl,p as Fl,u as Il,v as Ll,w as Rl,x as zl,y as Bl}from"./markdown-runtime-Hc-lvqnn.js";import{a as Vl,i as Hl,ji as Ul,ki as Wl,n as Gl,r as Kl,t as ql}from"./control-ui-boot-shared-DCY2wZcy.js";import{i as Jl,o as Yl}from"./chat-transcript-layout-hEyp1qZw.js";import{t as Xl}from"./sidebar-update-runtime-BZGhWGH_.js";function Zl(e){let t=null,n=null,r=null,i=0,a=0,o=!1,s=e=>o&&a===e,c=()=>{n!==null&&(globalThis.clearTimeout(n),n=null)},l=(e,t)=>{s(t)&&(c(),n=globalThis.setTimeout(()=>{s(t)&&(n=null,d(t))},p(e,{minMs:eu})))},u=e=>{if(!s(e))return;i+=1;let t=Math.min(nu*2**(i-1),ru);l(t,e)},d=n=>{if(r?.generation===n||!s(n)||!t)return;let a=t,o=Promise.resolve().then(()=>e.request(`plugin.surface.refresh`,{surface:`canvas`,observedUrl:a})).then(r=>{if(!s(n)||t!==a)return;let o=Ql(r);if(!o){u(n);return}i=0,t=o.canvasUrl,e.onChange(t);let c=o.expiresAtMs===void 0?tu:Math.max(eu,o.expiresAtMs-Date.now()-$l);l(c,n)}).catch(e=>{e instanceof ne&&e.gatewayCode===`FORBIDDEN`||u(n)}).finally(()=>{r?.promise===o&&(r=null)});r={generation:n,promise:o}};return{start(n){a+=1,o=!0,i=0,c(),t=n?.trim()||null,e.onChange(t),t&&d(a)},stop(){(o||t!==null||n!==null)&&(a+=1,o=!1,i=0,c(),t=null,e.onChange(null))}}}function Ql(e){if(!e||typeof e!=`object`)return;let t=e;if(t.surface!==`canvas`)return;let n=t.pluginSurfaceUrls;if(!g(n))return;let r=n.canvas;if(typeof r!=`string`||!r.trim())return;let i=t.expiresAtMs;if(!(i!==void 0&&(typeof i!=`number`||!Number.isSafeInteger(i)||i<=0)))return{surface:`canvas`,canvasUrl:r.trim(),...i===void 0?{}:{expiresAtMs:i}}}var $l,eu,tu,nu,ru;function iu(){return(iu=e((()=>{f(),re(),$l=15e3,eu=1e3,tu=6e4,nu=1e3,ru=3e5})))()}function au(e){ou(),Mi(e.seamColor);let n=document.documentElement,r=e.environment;if(!r){let e=n.getAttribute(t);if(e){let t=` · ${JSON.parse(e).label}`;document.title.endsWith(t)&&(document.title=document.title.slice(0,-t.length))}n.removeAttribute(t),n.style.removeProperty(`--control-ui-environment-color`),n.style.removeProperty(`--control-ui-environment-ink`),document.querySelector(`.control-ui-environment-stripe`)?.remove(),uu();return}if(n.setAttribute(t,JSON.stringify(r)),n.style.setProperty(`--control-ui-environment-color`,`var(--control-ui-environment-${r.color})`),n.style.setProperty(`--control-ui-environment-ink`,`var(--control-ui-environment-${r.color}-ink)`),!document.querySelector(`.control-ui-environment-stripe`)){let e=document.createElement(`div`);e.className=`control-ui-environment-stripe`,e.setAttribute(`aria-hidden`,`true`),document.body.prepend(e)}document.title.endsWith(` · ${r.label}`)||(document.title=`${document.title} · ${r.label}`),uu()}function ou(){mu=void 0}function su(e){pu!==e&&(pu=e,ou()),uu()}function cu(e,t){for(let[n,r]of[[`href`,t[0]],[`type`,t[1]]])r===null?e.removeAttribute(n):e.setAttribute(n,r)}function lu(){let e=document.documentElement,n=getComputedStyle(e),r=e.getAttribute(t),i=r?JSON.parse(r):null,a=i?n.getPropertyValue(`--control-ui-environment-${i.color}`).trim():``,o=bi().mascot===`none`?zi({fill:n.getPropertyValue(`--primary`).trim(),glyph:n.getPropertyValue(`--primary-foreground`).trim()}):a?`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><path fill="${a}" d="M60 10C30 10 15 35 15 55c0 20 15 40 30 45v10h10v-10h10v10h10v-10c15-5 30-25 30-45 0-20-15-45-45-45Z"/></svg>`:null,s=o?`data:image/svg+xml,${encodeURIComponent(o)}`:null,c=e.dataset.themeMode===`light`,l={attention:c?`--session-color-orange`:`--warn`,working:c?`--info`:`--accent`,done:`--ok`,disconnected:`--muted`,idle:``}[pu];return{baseSvg:s,color:l?n.getPropertyValue(l).trim():``,ring:n.getPropertyValue(`--bg`).trim()}}function uu(){let{baseSvg:e,color:t,ring:n}=mu??=lu();t||hu.clear();for(let r of document.querySelectorAll(`link[rel="icon"]`)){if(!e&&!t){gu.delete(r),r.dataset.openclawOriginalFavicon&&(cu(r,JSON.parse(r.dataset.openclawOriginalFavicon)),delete r.dataset.openclawOriginalFavicon);continue}r.dataset.openclawOriginalFavicon??=JSON.stringify([r.getAttribute(`href`),r.getAttribute(`type`)]);let i=JSON.parse(r.dataset.openclawOriginalFavicon),a=e??i[0],o=e?`image/svg+xml`:i[1],s=JSON.stringify([a,o,t,n]);if(gu.get(r)?.signature===s)continue;let c={signature:s};if(gu.set(r,c),!t||!a){cu(r,[a,o]);continue}fu(a,o,t,n).then(e=>{r.isConnected&&gu.get(r)===c&&(r.href=e.href,r.type=e.type)},e=>{gu.get(r)===c&&(gu.delete(r),cu(r,[a,o]),console.warn(`[openclaw] favicon status could not be composed`,e))})}}async function du(e,t){if(t===`image/svg+xml`||/(?:\.svg(?:[?#]|$)|^data:image\/svg\+xml)/i.test(e)){let t=await fetch(e);if(!t.ok)throw Error(`Favicon loading failed (${t.status})`);let n=new DOMParser().parseFromString(await t.text(),`image/svg+xml`),r=n.documentElement;if(n.querySelector(`parsererror`)||r.localName!==`svg`||r.namespaceURI!==_u)throw Error(`Invalid SVG favicon`);return{svg:r}}let n=new Image;return n.src=e,await n.decode(),{image:n}}async function fu(e,t,n,r){let i=JSON.stringify([e,t]),a=hu.get(i);a||(a=du(e,t),hu.set(i,a),a.catch(()=>{hu.get(i)===a&&hu.delete(i)}));let o=await a;if(`svg`in o){let e=new DOMParser().parseFromString(`<svg xmlns="${_u}" viewBox="0 0 32 32" width="32" height="32"><circle cx="25.5" cy="25.5" r="5" stroke-width="2"/></svg>`,`image/svg+xml`).documentElement,t=e.firstElementChild;t.setAttribute(`fill`,n),t.setAttribute(`stroke`,r);let i=document.importNode(o.svg,!0);return i.setAttribute(`x`,`0`),i.setAttribute(`y`,`0`),i.setAttribute(`width`,`32`),i.setAttribute(`height`,`32`),e.prepend(i),{href:`data:image/svg+xml,${encodeURIComponent(new XMLSerializer().serializeToString(e))}`,type:`image/svg+xml`}}let s=document.createElement(`canvas`);s.width=32,s.height=32;let c=s.getContext(`2d`);if(!c)throw Error(`Favicon canvas unavailable`);return c.drawImage(o.image,0,0,32,32),c.beginPath(),c.arc(25.5,25.5,5,0,Math.PI*2),c.fillStyle=n,c.fill(),c.strokeStyle=r,c.lineWidth=2,c.stroke(),{href:s.toDataURL(`image/png`),type:`image/png`}}var pu,mu,hu,gu,_u;function vu(){return(vu=e((()=>{we(),Gi(),Ui(),pu=`idle`,hu=new Map,gu=new WeakMap,_u=`http://www.w3.org/2000/svg`})))()}function yu(e){wu.delete(e)}function bu(e,t){let n=Tu.get(e);n||(n=new Set,Tu.set(e,n)),n.add(t)}function xu(e,t){let n=Tu.get(e);n&&(n.delete(t),n.size===0&&(Tu.delete(e),yu(e)))}function Su(e,t){yu(e);let n=Tu.get(e);if(!n)return;let r=Array.from(n,e=>({owner:e,generation:e.clientGeneration}));for(let{owner:i,generation:a}of r)n.has(i)&&i.client===e&&i.clientGeneration===a&&i.onQuestionResolution(t)}function Cu(e,t,n,r){let i=r===void 0?Fe:Math.min(Fe,Math.max(0,r-Date.now()));if(t!==`question.list`)return e.request(t,n,{timeoutMs:i});let a=wu.get(e);return a||(a=e.request(t,n,{timeoutMs:i}),wu.set(e,a),a.catch(()=>{wu.get(e)===a&&wu.delete(e)})),a}var wu,Tu;function Eu(){return(Eu=e((()=>{re(),wu=new WeakMap,Tu=new WeakMap})))()}function Du(e){if(!g(e))return null;let{name:t,kind:n,allowedHosts:r,reason:i}=e;return typeof t!=`string`||!/^[A-Z][A-Z0-9_]{0,127}$/.test(t)||n!==`secret`&&n!==`env`||i!==void 0&&(typeof i!=`string`||i.length>200)||r!==void 0&&(n!==`secret`||!Array.isArray(r)||r.length>128||r.some(e=>typeof e!=`string`||!e||e.length>253)||new Set(r).size!==r.length)?null:{name:t,kind:n,...r===void 0?{}:{allowedHosts:[...r]},...i===void 0?{}:{reason:i}}}function Ou(e){if(!g(e))return null;let t=Se(e.updatedAtMs,{min:0}),n=e.updatedBy===void 0?void 0:Me(e.updatedBy);return t===void 0||e.updatedBy!==void 0&&!n?null:{updatedAtMs:t,...n?{updatedBy:n}:{}}}function ku(e){if(e.isSecret!==void 0&&typeof e.isSecret!=`boolean`)return null;let t=e.secretStore===void 0?void 0:Du(e.secretStore),n=e.secretStoreExisting===void 0?void 0:Ou(e.secretStoreExisting);return t===null||n===null||t&&!e.isSecret||n&&!t?null:{...typeof e.isSecret==`boolean`?{isSecret:e.isSecret}:{},...t?{secretStore:t}:{},...n?{secretStoreExisting:n}:{}}}function Au(e,t){for(let n of e)n.isSecret&&t.delete(n.questionId)}function ju(e,t){if(!g(e))return null;if(e.status===`cancelled`)return{status:`cancelled`};let n=t(e.answers);return e.status===`answered`&&n?{status:`answered`,answers:n}:null}function Mu(e,t,n,r){if(!(`answers`in n))return{requestParams:{id:e,cancel:!0}};let i={answers:Object.fromEntries(Object.entries(n.answers).map(([e,t])=>[e,[...t]]))},a=t[0]?.secretStore?t[0]:void 0,o=a?.secretStore?.kind===`secret`?r===void 0?a.secretStore.allowedHosts:r.split(/[,\s]+/u).map(e=>e.trim()).filter(Boolean):void 0;return{requestParams:{id:e,answers:i,...o===void 0?{}:{secretStoreAllowedHosts:o}},submittedAnswers:a?{answers:{[a.questionId]:[`stored`]}}:i}}function Nu(){return(Nu=e((()=>{me()})))()}function Pu(e){let t=[...new Intl.Segmenter().segment(e)];return t.length<=Iu?e:t.slice(0,Iu).map(e=>e.segment).join(``)}function Fu(e){if(!g(e))return null;let t=Me(e.questionId),n=typeof e.header==`string`?e.header:null,r=Me(e.question);if(!t||!/^[a-z][a-z0-9_]*$/.test(t)||n===null||!r)return null;let i=Pu(n);if(!Array.isArray(e.options)||e.options.length>4)return null;let a=e.options.flatMap(e=>{if(!g(e))return[];let t=Me(e.label);return!t||e.description!==void 0&&typeof e.description!=`string`?[]:[{label:t,...typeof e.description==`string`?{description:e.description}:{}}]});if(a.length!==e.options.length)return null;let o=Me(e.url);if(e.url!==void 0){if(!o||!Ba(o))return null;try{let e=new URL(o);if(e.username||e.password)return null}catch{return null}}for(let t of[`multiSelect`,`isOther`])if(e[t]!==void 0&&typeof e[t]!=`boolean`)return null;let s=ku(e);return s?{questionId:t,header:i,question:r,options:a,...o?{url:o}:{},...e.multiSelect===!0?{multiSelect:!0}:{},...typeof e.isOther==`boolean`?{isOther:e.isOther}:{},...s}:null}var Iu;function Lu(){return(Lu=e((()=>{Pa(),Nu(),Iu=12})))()}function Ru(e){return Se(e,{min:0})??null}function zu(e){if(!g(e)||!g(e.answers))return null;let t={};for(let[n,r]of Object.entries(e.answers)){if(!/^[a-z][a-z0-9_]*$/.test(n)||!Array.isArray(r)||!r.every(e=>typeof e==`string`))return null;t[n]=[...r]}return{answers:t}}function Bu(e,t){if(!e||!t)return!1;let n=Object.keys(e.answers).toSorted(),r=Object.keys(t.answers).toSorted();return n.length===r.length&&n.every((n,i)=>n===r[i]&&e.answers[n]?.length===t.answers[n]?.length&&e.answers[n]?.every((e,r)=>Object.is(e,t.answers[n]?.[r])))}function Vu(e){if(!g(e))return null;let t=Me(e.id),n=Ru(e.createdAtMs),r=Ru(e.expiresAtMs);if(!t||n===null||r===null||!Array.isArray(e.questions)||e.questions.length<1||e.questions.length>3)return null;let i=e.questions.map(Fu);if(!i.every(e=>e!==null)||new Set(i.map(e=>e.questionId)).size!==i.length)return null;let a=e.agentId===void 0?void 0:Me(e.agentId),o=e.sessionKey===void 0?void 0:Me(e.sessionKey),s=e.runId===void 0?void 0:Me(e.runId);if(e.agentId!==void 0&&!a||e.sessionKey!==void 0&&!o||e.runId!==void 0&&!s)return null;let c={id:t,questions:i,...a?{agentId:a}:{},...o?{sessionKey:o}:{},...s?{runId:s}:{},createdAtMs:n,expiresAtMs:r};if(e.status===`pending`)return{...c,status:`pending`};let l=Uu(e);return l?{...c,...l}:null}function Hu(e){let t=Vu(e);return t?.status===`pending`?t:null}function Uu(e){if(!g(e))return null;let t=Me(e.id);if(!t)return null;if(e.status===`answered`){let n=zu(e.answers);return n?{id:t,status:`answered`,answers:n}:null}return e.status===`cancelled`||e.status===`expired`?{id:t,status:e.status}:null}function Wu(e){let t={client:null,ownerClient:null,clientGeneration:0,prompts:new Map,unmatchedResolutions:new Map,revision:0,expiryTimer:null,refreshRetryTimer:null,onChange:e,onQuestionResolution:e=>Ju(t,e)};return t}function Gu(e){e.expiryTimer&&=(globalThis.clearTimeout(e.expiryTimer),null);let t=1/0;for(let n of e.prompts.values())n.status===`pending`&&(t=Math.min(t,n.expiresAtMs));t!==1/0&&(e.expiryTimer=globalThis.setTimeout(()=>{e.expiryTimer=null;let t=Date.now(),n=!1;for(let r of e.prompts.values())r.status===`pending`&&r.expiresAtMs<=t&&(r.status=`expired`,Au(r.questions,r.drafts),r.locallyExpired=!0,r.submitting=!1,r.error=null,r.revision=++e.revision,n=!0);Gu(e),n&&e.onChange()},Ne(t-Date.now(),0,0)))}function Ku(e,t,n,r){let i=++e.revision,a=r?.drafts??new Map;n.status!==`pending`&&Au(n.questions,a);let o={...n,...r?.submittedAnswers?{submittedAnswers:r.submittedAnswers}:{},answeredElsewhere:n.status===`answered`&&!r?.localResolutionConfirmed&&!r?.submitting,localResolutionConfirmed:r?.localResolutionConfirmed??!1,locallyExpired:!1,submitting:n.status===`pending`||n.status===`answered`&&!(r?.localResolutionConfirmed??!1)?r?.submitting??!1:!1,error:n.status===`pending`?r?.error??null:null,drafts:a,...r?.secretStoreAllowedHostsDraft===void 0?{}:{secretStoreAllowedHostsDraft:r.secretStoreAllowedHostsDraft},revision:i},s=e.unmatchedResolutions.get(t);s&&(e.unmatchedResolutions.delete(t),qu(e,o,s)),e.prompts.set(t,o)}function qu(e,t,n){t.status=n.status,Au(t.questions,t.drafts),t.answers=n.status===`answered`?n.answers:void 0;let r=n.status===`answered`&&Bu(t.submittedAnswers,n.answers);t.answeredElsewhere=n.status===`answered`&&!t.localResolutionConfirmed&&!r&&!t.submitting,t.locallyExpired=!1,(n.status!==`answered`||t.localResolutionConfirmed)&&(t.submitting=!1),t.error=null,t.revision=++e.revision}function Ju(e,t){e.client&&yu(e.client);let n=e.prompts.get(t.id);n?(qu(e,n,t),Gu(e)):(e.unmatchedResolutions.set(t.id,t),e.revision+=1),e.onChange()}function Yu(e,t){if(t.event===`question.requested`){let n=Hu(t.payload);if(!n)return!1;e.client&&yu(e.client);let r=e.prompts.get(n.id);return r&&r.status!==`pending`?!0:(Ku(e,n.id,n,r),Gu(e),e.onChange(),!0)}if(t.event!==`question.resolved`)return!1;let n=Uu(t.payload);return n?(Ju(e,n),!0):!1}function Xu(e){if(!g(e)||!Array.isArray(e.questions))return null;let t=e.questions.map(Hu);return t.every(e=>e!==null)?t:null}function Zu(e){return e instanceof Xn&&g(e.details)&&e.details.reason===`QUESTION_NOT_FOUND`}function Qu(e,t){t.status=`unavailable`,Au(t.questions,t.drafts),t.answers=void 0,t.answeredElsewhere=!1,t.localResolutionConfirmed=!1,t.locallyExpired=!1,t.submitting=!1,t.error=null,t.revision=++e.revision}async function $u(e,t,n=()=>e.client===t){let r=e.revision,i=Xu(await Cu(t,`question.list`,{}));if(!i)return yu(t),!1;if(!n())return!1;let a=new Set(i.map(e=>e.id));for(let t of i){let n=e.prompts.get(t.id);(!n||n.revision<=r||n.locallyExpired)&&Ku(e,t.id,t,n)}Gu(e),e.onChange();let o=[...e.prompts.values()].filter(e=>(e.locallyExpired||e.status===`pending`&&e.revision<=r)&&!a.has(e.id)).map(e=>({id:e.id,prompt:e,revision:e.revision})),s=new Set(o.map(e=>e.id));for(let t of e.unmatchedResolutions.keys())!a.has(t)&&!s.has(t)&&(o.push({id:t,prompt:void 0,revision:e.revision}),s.add(t));let c=await Promise.all(o.map(async r=>{let i=await Cu(t,`question.get`,{id:r.id}).then(e=>({ok:!0,value:e}),e=>({ok:!1,error:e}));if(!n())return!1;let a=e.prompts.get(r.id);if(r.prompt&&a!==r.prompt)return!(!a||a.status===`pending`||a.locallyExpired);if(r.prompt&&a?.revision!==r.revision&&!a?.locallyExpired)return a?.status!==`pending`;if(!r.prompt&&!e.unmatchedResolutions.has(r.id))return!0;if(!i.ok)return Zu(i.error)?(a&&(Qu(e,a),Gu(e)),e.unmatchedResolutions.delete(r.id),e.onChange(),!0):!1;let o=g(i.value)?Vu(i.value.question):null;return o?(Ku(e,r.id,o,a),Gu(e),e.onChange(),!0):!1}));return n()&&c.every(Boolean)}function ed(e,t,n=()=>e.client===t){let r=e.clientGeneration,i=()=>e.client===t&&e.clientGeneration===r&&n(),a=0,o=async()=>{if(!i())return;let n;try{n=await $u(e,t,i)}catch{n=!1}if(n||!i())return;let r=sd[a];a=Math.min(a+1,sd.length-1),e.refreshRetryTimer=globalThis.setTimeout(()=>{e.refreshRetryTimer=null,o()},r)};o()}function td(e,t){if(e.refreshRetryTimer&&=(globalThis.clearTimeout(e.refreshRetryTimer),null),e.client===t)return;e.client&&xu(e.client,e),e.clientGeneration+=1;let n=t!==null&&e.ownerClient!==null&&e.ownerClient!==t;if(e.client=t,t!==null&&(e.ownerClient=t,bu(t,e)),n){let t=e.prompts.size>0||e.unmatchedResolutions.size>0;e.expiryTimer&&=(globalThis.clearTimeout(e.expiryTimer),null),e.prompts.clear(),e.unmatchedResolutions.clear(),t&&(e.revision+=1,e.onChange());return}t&&Gu(e);let r=!1;for(let t of e.prompts.values())t.submitting&&(t.submitting=!1,t.revision=++e.revision,r=!0);r&&e.onChange()}function nd(e){e.client&&xu(e.client,e),e.expiryTimer&&=(globalThis.clearTimeout(e.expiryTimer),null),e.refreshRetryTimer&&=(globalThis.clearTimeout(e.refreshRetryTimer),null),e.clientGeneration+=1,e.client=null}async function rd(e,t,n){let r=e.prompts.get(t),i=e.client,a=e.clientGeneration;if(!r||r.status!==`pending`||r.submitting)return;if(!i){r.error=j(`chat.questions.disconnected`),r.revision=++e.revision,e.onChange();return}r.submitting=!0;let o=Mu(t,r.questions,n,r.secretStoreAllowedHostsDraft);r.submittedAnswers=o.submittedAnswers,r.error=null,r.revision=++e.revision,e.onChange();try{let n=ju(await Cu(i,`question.resolve`,o.requestParams,r.expiresAtMs),zu);if(!n||n.status!==(o.submittedAnswers?`answered`:`cancelled`))throw Error(`invalid question.resolve response`);if(e.client===i&&e.clientGeneration===a){let n=e.prompts.get(t);n&&(n.localResolutionConfirmed=!0)}Su(i,{...n,id:t})}catch(n){if(e.client!==i||e.clientGeneration!==a)return;let r=e.prompts.get(t);if(!r)return;r.submitting=!1,r.status===`pending`?r.error=E(n):r.status===`answered`&&!r.localResolutionConfirmed&&(r.answeredElsewhere=!Bu(r.submittedAnswers,r.answers)),r.revision=++e.revision,e.onChange()}}async function id(e,t,n){await rd(e,t,{answers:n})}async function ad(e,t){await rd(e,t,{cancel:!0})}function od(e){return[...e.prompts.values()].toSorted((e,t)=>e.createdAtMs-t.createdAtMs||e.id.localeCompare(t.id))}var sd;function cd(){return(cd=e((()=>{me(),li(),F(),P(),Eu(),Lu(),Nu(),sd=[1e3,2e3,4e3]})))()}function ld(e,t,n=Date.now()){ou();let r=n,i=!1,a=!1,o=t.gateway.snapshot.client,s=t.agentSelection.state.selectedId,c=Yi(t.gateway),l=new Map,u=new WeakSet,d=Wu(()=>p());function f(){let e=t.gateway.snapshot,n=Yi(t.gateway),i=t.agentSelection.state.selectedId;(c!==n||e.client&&d.ownerClient&&e.client!==d.ownerClient)&&(nd(d),d=Wu(()=>p())),(o!==e.client||s!==i||c!==n)&&(a=!1,l.clear(),r=Date.now(),o=e.client,s=i,c=n)}function p(){if(i)return;f();let n=t.gateway.snapshot,c=!1;for(let t of e.querySelectorAll(`openclaw-chat-pane`)){let e=t.runActivity,n=e?.completion,i=n&&!u.has(n);n&&u.add(n),e&&e.client===o&&e.agentId===s&&(c||=e.working,i&&n.phase===`done`&&n.occurredAt>=r&&document.visibilityState===`hidden`&&(a=!0))}let p=t.sessions.state.result;if(n.phase===`connected`&&p){let e=new Map;for(let n of p.sessions)b(n.agentId??A(n.key)?.agentId??t.sessions.state.agentId??``)===s&&(pe(n)?(c=!0,e.set(n.key,n.sessionId)):n.status===`done`&&l.has(n.key)&&l.get(n.key)===n.sessionId&&document.visibilityState===`hidden`&&(a=!0));l=e}document.visibilityState===`visible`&&(a=!1),su(t.overlays.snapshot.approvalQueue.length>0||od(d).some(e=>e.status===`pending`)?`attention`:c?`working`:a?`done`:n.phase===`connected`?`idle`:`disconnected`)}function m(){f();let e=t.gateway.snapshot,n=e.phase===`connected`&&oo({hello:e.hello},`question.list`)?e.client:null;d.client!==n&&(td(d,n),n&&ed(d,n,()=>!i&&t.gateway.snapshot.client===n&&t.gateway.snapshot.phase===`connected`)),p()}let h=[t.gateway.subscribe(m),t.gateway.subscribeEvents(e=>Yu(d,e)),t.overlays.subscribe(p),t.agentSelection.subscribe(p),t.sessions.subscribe(p)],g=new MutationObserver(()=>{ou(),p()});return g.observe(document.documentElement,{attributes:!0,attributeFilter:[`style`,`data-theme`,`data-theme-mode`,`data-theme-mascot`]}),document.addEventListener(`visibilitychange`,p),e.addEventListener(nn,p),e.addEventListener(hn,p),m(),()=>{i=!0,h.forEach(e=>e()),g.disconnect(),document.removeEventListener(`visibilitychange`,p),e.removeEventListener(nn,p),e.removeEventListener(hn,p),nd(d),su(`idle`)}}function ud(){return(ud=e((()=>{so(),N(),yn(),vu(),oi(),cd()})))()}function dd(e){if(!e||typeof e!=`object`)return null;let t=e;return Array.isArray(t.gateways)&&typeof t.currentId==`string`?t:null}function fd(){if(typeof window>`u`)return null;let e=window,t=di()?.webkit?.messageHandlers?.openclawGateways;if(!t?.postMessage)return null;let n=t.postMessage.bind(t),r=dd(e.__OPENCLAW_NATIVE_GATEWAYS__),i=new Set;return window.addEventListener(md,e=>{let t=dd(e.detail);t&&(r=t,i.forEach(e=>e(t)))}),{get snapshot(){return r},subscribe(e){return i.add(e),()=>i.delete(e)},select:e=>n({type:`select`,id:e}),openWindow:e=>n({type:`open-window`,id:e}),setPrimary:e=>n({type:`set-primary`,id:e}),reconnect:e=>n({type:`reconnect`,id:e}),reconnectCancel:e=>n({type:`reconnect-cancel`,id:e}),openSettings:()=>n({type:`open-settings`})}}function pd(){return hd===void 0&&(hd=fd()),hd}var md,hd;function gd(){return(gd=e((()=>{md=`openclaw:native-gateways-changed`})))()}function _d(e,t=128){return typeof e==`string`&&e.length>0&&e.length<=t&&e.trim()===e}function vd(e){let t=C(e);if(!_d(t?.targetId)||!_d(t.profile))return;let n={targetId:t.targetId,profile:t.profile};if(t.target===`host`&&t.node===void 0)return{...n,target:`host`};if(t.target===`node`&&_d(t.node,256))return{...n,target:`node`,node:t.node}}function yd(e){return JSON.stringify([e?.target,e?.node,e?.profile])}function bd(e){return JSON.stringify([e.target,e.node,e.profile,e.targetId])}function xd(){return(xd=e((()=>{})))()}function Sd(e){try{let t=decodeURIComponent(e);return t&&t!==`.`&&t!==`..`?t:null}catch{return null}}function Cd([e,t,n,r]){return{kind:n?`issue`:`pull`,number:Number(n??r),owner:e,repo:t}}function wd(e){let t=xi(e);return t?Cd(t):null}function Td(e){let t=URL.parse(e),n=t?Sr(t):null;return n&&t?{...Cd(n),href:t.href}:null}function Ed(){return(Ed=e((()=>{})))()}function Dd(e){return kd.has(e)}function Od(e){let t=new Set,n=new Map,r=Cn(e.gateway.snapshot),i=()=>{for(let e of t)e()},a=e=>{for(let[t,r]of n)if(O(t,e))return{key:t,entry:r};return null},o=e=>a(e.owner.sessionKey)?.entry===e,s=t=>{let n=e.gateway.snapshot;return!!(t.retainsConnection()&&r.isCurrent(t.scope)&&n.client?.recoveryScopeReady)},c=e=>{let t=e.persistRecovery?_o(e.owner.gatewayUrl,e.owner.recoveryScope,e.owner.sessionKey):null;return o(e)&&(!t||t.messageId===e.owner.messageId)},l=e=>s(e)&&c(e),u=(e,t=!0)=>{let r=a(e.owner.sessionKey);r?.entry===e&&(n.delete(r.key),t&&i())},d=(t,n,r,i)=>{let a=Wl(t.owner.sessionKey,{text:n.message,mentions:n.mentions,attachments:t.attachments,createdAt:t.createdAt},t.scope.client,r);e.chatSubmissions.retain(a?{...a,...i?{consumedByEventId:i}:{}}:null)},f=t=>{l(t)&&t.work.kind!==`cancelled`&&e.sessions.invalidate()},p=(e,t,n)=>{let{recovery:r}=yc(t,n,e.persistRecovery);e.work={kind:`paused`,recovery:r},i()},m=(t,r,a)=>{let o=r;sc({client:t.scope.client,describe:e.sessions.describe,recovery:o,persistRecovery:t.persistRecovery,cleanupOnCancellation:()=>!t.persistRecovery&&t.work.kind!==`paused`,mode:a,isLifecycleCurrent:()=>s(t),ownsRecovery:()=>c(t),clearRecovery:()=>Ps(t.owner.gatewayUrl,t.owner.recoveryScope,t.owner.sessionKey,t.owner.messageId),setRecoveryPhase:e=>{o={...o,phase:e},t.work={kind:`running`,recovery:o},i()}}).then(r=>{if(!c(t)||!t.retainsConnection()){u(t);return}if(r.status===`paused`){t.work={kind:`paused`,recovery:r.recovery},i(),g(e.gateway.snapshot);return}if(r.status===`cancelled`&&r.cleanupError){p(t,o,r.cleanupError),g(e.gateway.snapshot);return}if(r.status===`cancelled`&&!t.persistRecovery){t.work={kind:`cancelled`,recovery:o};let e=[...n.values()].filter(e=>e.work.kind===`cancelled`);for(let t of e.slice(0,-32))u(t,!1);i();return}if(!s(t)){r.status===`started`||r.status===`accepted`?(t.work={kind:`checking`,recovery:o},g(e.gateway.snapshot)):r.status!==`interrupted`&&u(t);return}(r.status===`started`||r.status===`accepted`)&&d(t,o,r.status===`started`?r.messageId:t.owner.messageId,r.status===`accepted`?r.consumedByEventId:void 0),u(t)}).catch(e=>{l(t)&&p(t,o,E(e))}).finally(()=>f(t))},h=t=>{if(t.recovery.phase===`creating`)return;r.transition(e.gateway.snapshot);let o=a(t.recovery.sessionKey)?.entry;if(o&&o.owner.messageId===t.recovery.messageId&&o.retainsConnection()&&(o.work.kind===`cancelled`||l(o)&&(o.work.kind!==`paused`||t.recovery.phase===`paused`)))return;o&&u(o,!1);let s=r.capture();if(!s)return;let c={sessionKey:t.recovery.sessionKey,messageId:t.recovery.messageId,gatewayUrl:t.recovery.gatewayUrl,recoveryScope:t.recovery.recoveryScope},d={work:t.recovery.phase===`paused`?{kind:`paused`,recovery:t.recovery}:{kind:t.recovery.phase===`sending`?`checking`:`running`,recovery:t.recovery},owner:c,attachments:t.displayAttachments??nt(t.recovery.attachments),persistRecovery:t.persistRecovery,createdAt:o?.owner.messageId===c.messageId?o.createdAt:t.createdAt,scope:s,retainsConnection:Hr(e.gateway,c)};n.set(c.sessionKey,d),i(),t.recovery.phase!==`paused`&&m(d,t.recovery,t.mode)},g=t=>{if(r.transition(t),t.phase===`connected`&&t.client?.recoveryScopeReady&&t.client.recoveryScope){for(let e of n.values())(e.work.kind===`paused`||e.work.kind===`checking`)&&!s(e)&&e.retainsConnection()&&c(e)&&h({recovery:e.work.recovery,persistRecovery:e.persistRecovery,mode:`recover`,createdAt:e.createdAt});for(let n of hc(e.gateway.connection.gatewayUrl,t.client.recoveryScope))h({recovery:n,persistRecovery:!0,mode:`recover`,createdAt:Date.now()})}};return{resumeRecovery:()=>g(e.gateway.snapshot),hasPendingTurn(e){let t=a(e)?.entry;return!!(t&&t.work.kind!==`cancelled`&&t.retainsConnection()&&c(t))},get(t){let n=a(t)?.entry;if(!n||!n.retainsConnection()||!c(n))return null;let r=n.work.kind===`cancelled`,i=!r&&!s(n),o=r?j(`newSession.placementCancelled`):n.work.recovery.phase===`paused`?n.work.recovery.error:void 0,l=i?`reconnecting`:r?`cancelled`:n.work.kind===`running`?n.work.recovery.phase===`sending`?`sending`:`pending`:`failed`;if(l===`pending`){let t=(e.sessions.state.result?.sessions.find(e=>O(e.key,n.owner.sessionKey)))?.placement?.state;t&&Dd(t)&&(l=t)}return{sessionKey:n.owner.sessionKey,targetKind:n.work.recovery.target.kind,phase:l,startedAt:n.createdAt,initialTurn:Br({recovery:n.work.recovery,attachments:n.attachments,createdAt:n.createdAt,checking:n.work.kind===`checking`||r&&n.work.recovery.phase===`sending`,reconnecting:i,error:r?o:void 0}),...n.work.kind===`running`?{}:{...o?{error:o}:{},retryable:!i&&!r,...r?{}:{action:n.work.kind===`checking`||n.work.recovery.phase===`paused`&&n.work.recovery.reason===`unconfirmed`?`check-delivery`:`retry`}}}},start:h,pause(e,t){let n=a(e)?.entry;if(!n||n.work.kind===`cancelled`||!l(n))return;let{recovery:r}=yc(n.work.recovery,t,n.persistRecovery);n.work={kind:`paused`,recovery:r},u(n,!1),h({recovery:r,persistRecovery:n.persistRecovery,mode:`recover`,createdAt:n.createdAt})},retry(e){let t=a(e)?.entry;if(!t||t.work.kind!==`paused`||!l(t))return;if(t.work.recovery.reason===`unconfirmed`){t.work={kind:`checking`,recovery:t.work.recovery},i(),m(t,t.work.recovery,`recover`);return}let{reason:n,error:r,...o}=t.work.recovery,s={...o,phase:`dispatching`,messageId:n===`rejected`?ee():o.messageId};if(t.persistRecovery&&!rs(s,o.messageId)){p(t,t.work.recovery,`placement recovery storage is unavailable`);return}h({recovery:s,persistRecovery:t.persistRecovery,mode:`retry`,createdAt:t.createdAt})},subscribe(e){return t.add(e),()=>t.delete(e)},dispose(){r.dispose(),n.clear(),t.clear()}}}var kd;function Ad(){return(Ad=e((()=>{F(),fo(),P(),N(),bs(),zs(),l(),kn(),Ul(),Gr(),ur(),Vs(),kd=new Set([`requested`,`provisioning`,`syncing`,`starting`,`active`])})))()}function jd(e){return e.state===`activated`||e.state===`redundant`?Promise.resolve():new Promise(t=>{let n=()=>{(e.state===`activated`||e.state===`redundant`)&&(e.removeEventListener(`statechange`,n),t())};e.addEventListener(`statechange`,n),n()})}async function Md(e){let t=new MessageChannel,n;try{return await new Promise(r=>{n=setTimeout(()=>r(null),1e3),t.port1.addEventListener(`message`,e=>r(e.data),{once:!0}),t.port1.start(),e.postMessage({type:`sw-version-probe`},[t.port2])})}finally{clearTimeout(n),t.port1.close(),t.port2.close()}}async function Nd(e){for(;e.active;){let t=e.active,n=await Md(t);if(e.active!==t)continue;if(!lr(n))return!1;let r=await _r({canReload:()=>e.active===t});if(r||e.active===t)return r}return!1}async function Pd(){let e=typeof navigator<`u`&&`serviceWorker`in navigator?navigator.serviceWorker:null;if(!e)return!1;let t=await e.getRegistration();if(!t)return!1;let n=t.installing??t.waiting;if(!n){try{await t.update()}catch(e){if(await Nd(t))return!0;throw e}n=t.installing??t.waiting}return n&&await jd(n),Nd(t)}function Fd(){return(Fd=e((()=>{zr(),xr()})))()}function Id(e,t){let n=mi(e,t);return n?R`<div class="update-git-revisions">
    <span class="update-git-revisions__range" dir="ltr">
      ${n.currentSha?R`<code title=${n.currentSha}>${n.currentSha.slice(0,8)}</code>
              <span aria-hidden="true">→</span>`:z}
      <code title=${n.targetSha}>${n.targetSha.slice(0,8)}</code>
    </span>
    ${n.compareUrl?R`<a href=${n.compareUrl} target="_blank" rel="noopener noreferrer"
            >${j(`updates.target.viewChanges`)} <span aria-hidden="true">↗</span></a
          >`:z}
  </div>`:z}function Ld(){return(Ld=e((()=>{B(),Fi(),F()})))()}function Rd(e){return e.replace(/^(?:diagnostic|warning):(.+?)(?::\d+)?$/u,`$1`)}function zd(e,t=!0){let n=e.status!==`running`,r=e.target.installationMethod===`ocm`,i=ke(e),a=se.indexOf(e.phase),o=se.flatMap((t,r)=>{let i=e.steps.find(e=>e.step===t);if(t===`repairing`&&!i&&t!==e.phase)return[];let o=i?.status??`pending`;return i||(t===`finished`&&n?o=e.status===`succeeded`?`completed`:e.status===`skipped`?`skipped`:`failed`:t===e.phase?o=`in_progress`:(n||r<a)&&(o=`skipped`)),[{step:t,status:o,label:j(`updates.run.phase.${t}`)}]}),s=e.steps.filter(e=>!e.step.startsWith(`notice:`)&&!e.step.startsWith(`diagnostic:`)&&!se.some(t=>t===e.step)),c=s.findLast(e=>e.status===`in_progress`)??e.steps.findLast(e=>e.status===`in_progress`&&e.detail)??e.steps.findLast(e=>e.detail),l=new Map;for(let t of e.steps){if(!t.detail)continue;let e=Rd(t.step),n=l.get(e)??[];n.push(t.detail),l.set(e,n)}let d=new Map(Array.from(l,([e,t])=>[e,u(t.join(`
`),-4096).split(/\r?\n/u).slice(-80).join(`
`)])),f=c?d.get(Rd(c.step))??``:``,p=e.verification,m=he(p,e.after),h=e=>e===void 0?n?`warn`:`pending`:e?`pass`:`fail`,g=[{name:`service`,state:h(p.serviceRunning)},{name:`version`,state:m.kind===`unavailable`?`warn`:h(m.kind===`unobserved`?void 0:m.kind===`verified`)},{name:`plugins`,state:h(p.pluginErrors===void 0?void 0:p.pluginErrors.length===0)},{name:`channels`,state:h(p.channelsReady)}],_=o.filter(e=>e.status===`completed`).length,v=o.filter(e=>e.status!==`skipped`).length;return{report:i,terminal:n,reconciled:xe(e),headline:!t&&!n&&(e.phase===`activating`||e.phase===`restarting`||e.phase===`verifying`)?j(`updates.run.restarting`):i.headline,compactLabel:r?``:j(`updates.run.progress`,{completed:String(_),total:String(v)}),phases:r?[]:o.map(({step:e,status:t,label:n})=>({step:e,status:t,label:n,detail:d.get(e)})),steps:s.map(({step:e,status:t})=>({step:e,status:t,detail:d.get(Rd(e))})),detailStep:c?.step,details:f,oracles:r?[]:g}}function Bd(){return(Bd=e((()=>{_e(),De(),Ce(),F()})))()}function Vd(e){return Bi({signal:e.signal,value:!1},({render:t,finish:n})=>{let r=!1,i=!e.requiredAcknowledgement,a=e.title??j(`common.confirm`),o=()=>R`
        <openclaw-modal-dialog
          label=${a}
          description=${e.message}
          @modal-cancel=${()=>n(!1)}
        >
          <div class="exec-approval-card">
            <div class="exec-approval-header">
              <div>
                <div class="exec-approval-title">${a}</div>
                <div class="exec-approval-sub" style="white-space: pre-line">
                  ${e.message}
                </div>
              </div>
            </div>
            ${e.details?R`<div class="exec-approval-command mono">${e.details}</div>`:z}
            ${e.requiredAcknowledgement?R`<label class="field checkbox">
                    <input
                      type="checkbox"
                      .checked=${i}
                      @change=${e=>{let n=e.currentTarget;n instanceof HTMLInputElement&&(i=n.checked,t(o))}}
                    />
                    <span>${e.requiredAcknowledgement}</span>
                  </label>`:z}
            ${e.skipPreference&&!e.requiredAcknowledgement?R`<label class="field checkbox exec-approval-skip">
                    <input
                      type="checkbox"
                      @change=${e=>{r=e.target.checked}}
                    />
                    <span>${j(`common.dontAskAgain`)}</span>
                  </label>`:z}
            <div class="exec-approval-actions">
              <button
                type="button"
                class="btn ${e.danger?`danger`:`primary`}"
                ?disabled=${!i}
                @click=${()=>{i&&(r&&e.skipPreference?.remember(),n(!0))}}
              >
                ${e.confirmLabel??j(`common.confirm`)}
              </button>
              <button type="button" class="btn" autofocus @click=${()=>n(!1)}>
                ${e.cancelLabel??j(`common.cancel`)}
              </button>
            </div>
          </div>
        </openclaw-modal-dialog>
      `;t(o)})}function Hd(e){return e.skipPreference?.skipped&&!e.requiredAcknowledgement?Promise.resolve(!0):Ud?Promise.resolve(!1):(Ud=!0,Vd(e).finally(()=>{Ud=!1}))}var Ud;function Wd(){return(Wd=e((()=>{B(),F(),Oi(),Ud=!1})))()}function Gd(){let e,t=new Promise((t,n)=>{e=setTimeout(()=>n(Error(`Service worker not ready (timed out)`)),ff)});return Promise.race([navigator.serviceWorker.ready,t]).finally(()=>{e!==void 0&&clearTimeout(e)})}function Kd(e){let t=e?.pushManager;return t&&typeof t.getSubscription==`function`?t:null}function qd(e){let t=Kd(e);if(!t||typeof t.subscribe!=`function`)throw Error(`Web Push is unavailable in this browser. On iPhone or iPad, add OpenClaw to the Home Screen and open the installed app.`);return t}function Jd(e){let t=(e+`=`.repeat((4-e.length%4)%4)).replace(/-/g,`+`).replace(/_/g,`/`),n=atob(t),r=new Uint8Array(n.length);for(let e=0;e<n.length;e+=1)r[e]=n.charCodeAt(e);return r}async function Yd(){return`serviceWorker`in navigator?await Kd(await navigator.serviceWorker.getRegistration())?.getSubscription()??null:null}async function Xd(e){let t=(await e.request(`push.web.vapidPublicKey`,{})).vapidPublicKey;if(!t)throw Error(`Failed to retrieve VAPID public key`);return Jd(t)}function Zd(e,t){let n=e.options.applicationServerKey;if(!n)return!1;let r=new Uint8Array(n);return r.length===t.length&&r.every((e,n)=>e===t[n])}function Qd(e){let t=e.toJSON();if(!t.endpoint||!t.keys?.p256dh||!t.keys.auth)throw Error(`Invalid push subscription from browser`);return{endpoint:t.endpoint,keys:{p256dh:t.keys.p256dh,auth:t.keys.auth}}}async function $d(e,t,n){return Zd(t,n)?(await e.request(`push.web.subscribe`,Qd(t)),{state:`registered`}):(await e.request(`push.web.unsubscribe`,{endpoint:t.endpoint}).catch(()=>void 0),{state:`vapid-mismatch`,error:pf})}async function ef(e,t){return{subscription:t.state,preferences:t.state===`registered`?await lf(e):null,error:t.state===`vapid-mismatch`?t.error:null}}async function tf(e){let t=await Yd();return await ef(e,t?await $d(e,t,await Xd(e)):{state:`missing`})}function nf(e){let t=null,n=0,r=!1,i=async(t,i)=>{let a;try{a=await tf(t)}catch(e){a={error:E(e)}}!r&&i===n&&e.gateway.snapshot.phase===`connected`&&e.gateway.snapshot.client===t&&e.publish(a)},a=r=>{let a=r.phase===`connected`?r.client:null;if(a===t)return;t=a;let o=++n;if(e.publish({subscription:`unknown`,preferences:null,error:null}),a){let t=()=>i(a,o);(e.connectionBootstrap?.run(`web-push-reconcile`,t)??t()).catch(()=>void 0)}},o=e.gateway.subscribe(a),s=e.gateway.subscribeEvents(t=>{let r=t.payload,a=e.gateway.snapshot.client;t.event===`users.prefs.changed`&&a&&r&&typeof r==`object`&&e.gateway.snapshot.selfUser?.id&&`keys`in r&&Array.isArray(r.keys)&&r.keys.includes(mf)&&i(a,++n)});return a(e.gateway.snapshot),()=>{r=!0,n+=1,o(),s()}}function rf(e){let t=null;return{run(n){let r=e.gateway.snapshot.client;if(!r)return Promise.resolve();let i=()=>e.gateway.snapshot.phase===`connected`&&e.gateway.snapshot.client===r;t||e.publish({loading:!0,error:null});let a=(t??Promise.resolve()).then(async()=>{if(!i())throw Error(`Gateway changed before the notification change could be saved.`);e.publish({error:null});let t=await df(r,n);i()&&e.publish(t)}).catch(t=>{i()&&e.publish({error:E(t)})}).finally(()=>{t===a&&(t=null,e.publish({loading:!1,permission:`Notification`in window?Notification.permission:`unsupported`}))});return t=a,a},dispose:nf(e)}}async function af(e){let t=await Notification.requestPermission();if(t!==`granted`)throw Error(`Notification permission ${t}`);let n=qd(await Gd()),r=await Xd(e),i=await n.getSubscription();if(i)return await $d(e,i,r);let a=await n.subscribe({userVisibleOnly:!0,applicationServerKey:r.buffer});try{return await $d(e,a,r)}catch(e){try{await a.unsubscribe()}catch{}throw e}}async function of(e){let t=await Yd();if(t){try{await e.request(`push.web.unsubscribe`,{endpoint:t.endpoint})}catch{}await t.unsubscribe()}}async function sf(e){await e.request(`push.web.test`,{})}async function cf(){let e=await Yd();if(!e)throw Error(`Enable notifications before changing notification preferences.`);return e}async function lf(e){let t=await cf();return await e.request(`push.web.preferences.get`,{endpoint:t.endpoint})}async function uf(e,t,n){let r=await cf();return await e.request(`push.web.preferences.set`,{endpoint:r.endpoint,scope:t,preferences:n}),await lf(e)}async function df(e,t){switch(t.kind){case`enable`:return await ef(e,await af(e));case`disable`:return await of(e),{subscription:`missing`,preferences:null};case`test`:return await sf(e),{};case`set`:return{preferences:await uf(e,t.scope,t.preferences)};default:return t}}var ff,pf,mf;function hf(){return(hf=e((()=>{P(),ff=1e4,pf=`This browser push subscription belongs to another Gateway. Open this Gateway's own Control UI, or configure every mutually trusted Gateway behind this PWA with the same VAPID keypair.`,mf=`notifications.web.v1`})))()}function gf(e){let t=We(e),n=_f[t%_f.length],r=`hsl(${n} 58% 62%)`,i=`hsl(${n} 65% 90%)`,a=`hsl(${n} 55% 18%)`,o=[U`<circle cx="11" cy="13.5" r="1.6" /><circle cx="21" cy="13.5" r="1.6" />`,U`<ellipse cx="11" cy="13" rx="1.5" ry="2" /><ellipse cx="21" cy="13" rx="1.5" ry="2" />`,U`<path d="M9 14q2-3 4 0m6 0q2-3 4 0" fill="none" stroke=${a} stroke-width="1.6" stroke-linecap="round" />`,U`<rect x="6.5" y="9" width="19" height="9.5" rx="4.75" />
      <g fill=${i}><rect x="10.5" y="12" width="2.5" height="3.5" rx="1.25" /><rect x="19" y="12" width="2.5" height="3.5" rx="1.25" /></g>`],s=[U`<path d="M11.5 20q4.5 4.5 9 0" fill="none" stroke=${a} stroke-width="1.6" stroke-linecap="round" />`,U`<path d="M11 19q5 1.5 10 0c-.5 4.5-3 6-5 6s-4.5-1.5-5-6Z" />
      <path d="M13.5 23q2.5-2 5 0-2.5 2-5 0Z" fill=${i} />`,U`<path d="M12 22q5 2 8-1" fill="none" stroke=${a} stroke-width="1.6" stroke-linecap="round" />`,U`<path d="M13.5 22.5h5" fill="none" stroke=${a} stroke-width="1.6" stroke-linecap="round" />`],c=Math.floor(t/_f.length),l=Math.floor(c/o.length),u=Math.floor(l/s.length)%2==1;return R`<svg
    class="identity-avatar__agent-face"
    viewBox="0 0 32 32"
    width="100%"
    height="100%"
    aria-hidden="true"
  >
    ${U`<circle cx="16" cy="16" r="16" fill=${u?i:r} />
      <g fill=${a}>${o[c%o.length]}${s[l%s.length]}</g>`}
  </svg>`}var _f;function vf(){return(vf=e((()=>{B(),_f=[8,32,48,82,142,174,202,232,272,322]})))()}function yf(e,t){return!t.avatarHat||ll(e)?null:((We(e)^bf)>>>0)%6==0?t.avatarHat:null}var bf;function xf(){return(xf=e((()=>{ul(),bf=Math.trunc(Math.random()*4294967295)})))()}function Sf(e,t){return Bc(T(async()=>{let{fetchPluginThemeArtworkBlobUrl:e}=await import(`./icon-loader-BeqOmUEn.js`);return{fetchPluginThemeArtworkBlobUrl:e}},__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10]),import.meta.url).then(({fetchPluginThemeArtworkBlobUrl:t})=>t({url:e})).then(e=>e?R`<img class=${t} alt="" src=${e} />`:z).catch(()=>z),z)}function Cf(){return(Cf=e((()=>{B(),rl(),n()})))()}var wf;function Tf(){return(Tf=e((()=>{B(),wf={crown:U`
    <path
      d="M46 12 L46 2 L53 8 L60 0 L67 8 L74 2 L74 12 Q60 8 46 12 Z"
      fill="#f6c945"
    />
  `,santa:U`
    <g>
      <path d="M47 10 Q54 1 68 3 L72 9 Z" fill="#e0312f" />
      <circle cx="71" cy="3.5" r="3.5" fill="#f5f7fa" />
      <ellipse cx="59" cy="10.5" rx="15" ry="3.5" fill="#f5f7fa" />
    </g>
  `,pumpkin:U`
    <g>
      <ellipse cx="60" cy="6.5" rx="8.5" ry="5.5" fill="#e8871e" />
      <path d="M56 2.5 Q56 6.5 56 10.5 M64 2.5 Q64 6.5 64 10.5" stroke="#c96a10" stroke-width="1.5" fill="none" />
      <path d="M60 1.5 Q60.5 0 63 0.5" stroke="#4c9a4c" stroke-width="2.5" stroke-linecap="round" fill="none" />
    </g>
  `,party:U`
    <g>
      <path d="M52 11 L60 0.5 L68 11 Z" fill="#7c5cff" />
      <path d="M55.5 6.5 L64.5 6.5" stroke="#ffd166" stroke-width="2" />
      <circle cx="60" cy="1" r="2.4" fill="#ff5c8a" />
    </g>
  `}})))()}function Ef(e,t){return{penguin:`--lob-scale:2;--lob-w:0.85;--lob-h:1.1;--lob-face:${t}`,fedora:`--lob-scale:1.6;--lob-w:1;--lob-h:0.72;--lob-face:1`}[e]}var Df,Of,kf,Af,jf,Mf;function Nf(){return(Nf=e((()=>{B(),Tf(),Df=U`
  <svg
    class="lobster-pet__svg"
    viewBox="0 0 120 105"
    preserveAspectRatio="none"
    aria-hidden="true"
  >
    <ellipse cx="46" cy="99" rx="12" ry="4.5" fill="#f5921b" />
    <ellipse cx="72" cy="99" rx="12" ry="4.5" fill="#f5921b" />
    <ellipse cx="59" cy="62" rx="31" ry="39" fill="#151515" />
    <path d="M30 56 Q14 70 26 88 Q34 80 36 62 Z" fill="#151515" />
    <path d="M88 56 Q104 70 92 88 Q84 80 82 62 Z" fill="#151515" />
    <ellipse cx="60" cy="70" rx="19" ry="27" fill="#f2f2f2" />
    <ellipse cx="60" cy="40" rx="17" ry="12" fill="#f2f2f2" />
    <circle cx="52" cy="39" r="4.6" fill="#ffffff" />
    <circle cx="68" cy="39" r="4.6" fill="#ffffff" />
    <circle cx="53.5" cy="39.5" r="2.4" fill="#0a1014" />
    <circle cx="69.5" cy="39.5" r="2.4" fill="#0a1014" />
    <path d="M60 44 L79 49 L60 54 Q56 49 60 44 Z" fill="#f5921b" />
    <g transform="translate(0 3) rotate(-8 60 24)">
      <ellipse cx="60" cy="26" rx="30" ry="5.5" fill="#d40000" />
      <path d="M40 26 Q42 6 60 5 Q78 6 80 26 Z" fill="#ee0000" />
      <path d="M41 22 Q60 18 79 22 L79 26 L41 26 Z" fill="#a60000" />
      <path d="M48 9 Q60 4 72 9" stroke="#ff6b6b" stroke-width="2" fill="none" stroke-linecap="round" opacity="0.7" />
    </g>
  </svg>
`,Of=U`
  <svg
    class="lobster-pet__svg"
    viewBox="0 0 120 105"
    preserveAspectRatio="none"
    aria-hidden="true"
  >
    <ellipse cx="60" cy="82" rx="54" ry="11" fill="#d40000" />
    <path d="M26 80 Q28 30 60 26 Q92 30 94 80 Z" fill="#ee0000" />
    <path d="M52 30 Q60 24 68 30 Q64 40 60 42 Q56 40 52 30 Z" fill="#c40000" opacity="0.7" />
    <path d="M28 66 Q60 58 92 66 L92 78 Q60 72 28 78 Z" fill="#a60000" />
    <path d="M40 36 Q50 29 58 28" stroke="#ff6b6b" stroke-width="3" fill="none" stroke-linecap="round" opacity="0.7" />
    <ellipse cx="60" cy="82" rx="54" ry="11" fill="none" stroke="#a60000" stroke-width="1.5" />
  </svg>
`,kf={penguin:Df,fedora:Of},Af={penguin:`on loan from the kernel`,fedora:`a hat. nobody underneath`},jf={penguin:13e3,fedora:9e3},Mf={fedora:U`
    <svg class="identity-avatar__hat-svg" viewBox="0 0 100 100" aria-hidden="true">
      <g transform="rotate(-12 60 25)">
        <ellipse cx="60" cy="27" rx="27" ry="5" fill="#d40000" />
        <path d="M43 27 Q45 7 60 6 Q75 7 77 27 Z" fill="#ee0000" />
        <path d="M44 22 Q60 18 76 22 L76 27 L44 27 Z" fill="#a60000" />
        <path d="M50 10 Q60 6 70 10" stroke="#ff6b6b" stroke-width="1.8" fill="none" stroke-linecap="round" opacity="0.7" />
      </g>
    </svg>
  `,crown:U`
    <svg class="identity-avatar__hat-svg" viewBox="0 0 100 100" aria-hidden="true">
      <g transform="translate(60 27) rotate(-12) scale(2.2) translate(-60 -11)">
        ${wf.crown}
      </g>
    </svg>
  `,santa:U`
    <svg class="identity-avatar__hat-svg" viewBox="0 0 100 100" aria-hidden="true">
      <g transform="translate(60 27) rotate(-12) scale(2.2) translate(-60 -10.5)">
        ${wf.santa}
      </g>
    </svg>
  `,party:U`
    <svg class="identity-avatar__hat-svg" viewBox="0 0 100 100" aria-hidden="true">
      <g transform="translate(60 27) rotate(-12) scale(2.2) translate(-60 -11)">
        ${wf.party}
      </g>
    </svg>
  `,pumpkin:U`
    <svg class="identity-avatar__hat-svg" viewBox="0 0 100 100" aria-hidden="true">
      <g transform="translate(60 27) rotate(-12) scale(2.2) translate(-60 -12)">
        ${wf.pumpkin}
      </g>
    </svg>
  `}})))()}function Pf(e){let t=co(e),n=t.kind===`initials`?t:Ms(e),r=t.kind===`profile`?ds(t.url):null;return{fallback:n,imageUrl:r,sourceUrl:t.kind===`profile`?t.url:void 0,pending:r!==null&&typeof r!=`string`}}function Ff(e,t){e.setAttribute(`data-avatar-state`,t),e.classList.toggle(`is-pending`,t===`pending`),e.classList.toggle(`is-fallback`,t===`none`||t===`failed`)}function If(e,t,n){let r=e.currentTarget;if(!(r instanceof HTMLImageElement))return;let i=r.closest(t);i&&Ff(i,n?`failed`:`loaded`)}function Lf({view:e,fallbackSelector:t,className:n,alt:r=``,ariaHidden:i=!1,onImageError:a}){return e.imageUrl?R`<img
    class=${n??z}
    src=${Uf(e.imageUrl,e.sourceUrl,t)}
    alt=${r}
    aria-hidden=${i?`true`:z}
    referrerpolicy="no-referrer"
    @error=${e=>{If(e,t,!0),a?.()}}
    @load=${e=>If(e,t,!1)}
  />`:z}function Rf(e,t=``,n){let r=bi();if(ll(e.id))return r.mascot===`none`?R`<span
        class=${`identity-avatar--agent identity-avatar--neutral ${t}`}
        role=${e.name?`img`:z}
        aria-label=${e.name??z}
        aria-hidden=${e.name?z:`true`}
        >${I.mark}</span
      >`:R`<img
      class=${`identity-avatar--agent ${t}`}
      src=${or(`favicon.svg`)}
      alt=${e.name??``}
      aria-hidden=${e.name?z:`true`}
    />`;let i=e.avatar&&!e.pending?ds(e.avatar)??e.avatar:null,a={imageUrl:i,sourceUrl:e.avatar??void 0,pending:e.pending??i!==null};return R`<span
    class=${Vf(`identity-avatar--agent ${t}`,a)}
    role=${e.name?`img`:z}
    aria-label=${e.name??z}
    aria-hidden=${e.name?z:`true`}
  >
    ${Lf({view:a,fallbackSelector:`.identity-avatar--agent`,className:`identity-avatar__image`,onImageError:n})}
    <span class="identity-avatar__fallback">
      ${ya([e.id,e.textAvatar],()=>Bc(e.textAvatar?R`<span class="identity-avatar__text" data-avatar=${e.textAvatar}></span>`:T(async()=>{let{renderAgentAvatarFace:e}=await import(`./agent-avatar-face-CbdJ8TwJ.js`);return{renderAgentAvatarFace:e}},[],import.meta.url).then(({renderAgentAvatarFace:t})=>t(e.id)),z))}
    </span>
    ${e.pending?z:zf(e.id,r)}
  </span>`}function zf(e,t=bi()){let n=yf(e,t);if(!n)return z;let r=t.artwork?.hats?.[n],i=v(n)?Mf[n]:r?Sf(r.url,`identity-avatar__hat-img`):z;return R`<span class=${`identity-avatar__hat identity-avatar__hat--${n}`} aria-hidden="true"
    >${i}</span
  >`}var Bf,Vf,Hf,Uf;function Wf(){return(Wf=e((()=>{B(),sa(),Aa(),rl(),a(),ul(),dr(),ot(),ps(),Zo(),xf(),L(),Gi(),Cf(),Nf(),n(),Bf=class extends Na{constructor(...e){super(...e),this.hasImage=!1}render(e,t){return e}update(e,[t,n]){n.imageUrl?this.hasImage||Ff(e.element,`pending`):Ff(e.element,n.pending?`pending`:`none`),this.hasImage=!!n.imageUrl;let r=e.element.getAttribute(`data-avatar-state`);return`${t}${r===`pending`?` is-pending`:r===`none`||r===`failed`?` is-fallback`:``}`}},Vf=pa(Bf),Hf=class extends Ac{constructor(...e){super(...e),this.imageUrl=null,this.value=z,this.resolvedUrl=null,this.fallbackSelector=``}render(e,t,n){return z}update(e,[t,n,r]){let i=n??(typeof t==`string`?t:void 0),a=i?Qs(i,ut().origin):null,o=a&&t===i?ds(a):t;if(this.part=e,this.fallbackSelector=r,this.sourceUrl=a??void 0,o!==this.imageUrl||!this.release){let e=this.isConnected?gs(o):void 0;this.release?.(),this.release=e,this.imageUrl=o,this.value=typeof o==`string`?o:o?.then(e=>e??z)??z}let s=super.update(e,[this.value,z]);return this.reconcileSource(s,!1),s}setValue(e){super.setValue(e),this.reconcileSource(e,!0)}reconcileSource(e,t){if(e===fa||!this.part)return;let n=this.part.element;if(!(n instanceof HTMLImageElement))return;let r=typeof e==`string`?e:null;if(r!==this.resolvedUrl||!r){this.resolvedUrl=r;let e=n.closest(this.fallbackSelector);e&&Ff(e,!r&&t?`failed`:`pending`)}queueMicrotask(()=>{if(r&&this.resolvedUrl===r&&n.getAttribute(`src`)===r&&n.complete&&n.naturalWidth>0){let e=n.closest(this.fallbackSelector);e&&Ff(e,`loaded`)}})}disconnected(){super.disconnected(),this.release?.(),this.release=void 0}reconnected(){if(this.part){let e=this.sourceUrl?ds(this.sourceUrl):this.imageUrl;this.setValue(this.update(this.part,[e,this.sourceUrl,this.fallbackSelector]))}super.reconnected()}},Uf=pa(Hf)})))()}function Gf(e,t){if(e.key===`Tab`){t?.();return}e.key===`Escape`&&e.currentTarget&&tp.add(e.currentTarget)}function Kf(e){let t=e.currentTarget;return t!==null&&tp.delete(t)}function qf(e,t){if(!(e instanceof HTMLElement)||e.localName!==`wa-dropdown-item`)return;let n=e;Promise.resolve(n.updateComplete).then(()=>{n.isConnected&&(n.setAttribute(`role`,`menuitemradio`),n.setAttribute(`aria-checked`,String(t)))})}function Jf(e){let t=e.shadowRoot?.querySelector(`[part="menu"]`);if(!t)return;let n=e.querySelector(`[slot="trigger"]`),r=e.getAttribute(`aria-label`)||(n?.getAttribute(`aria-label`)??n?.textContent?.trim());r&&(t.setAttribute(`aria-label`,r),t.removeAttribute(`aria-labelledby`))}function Yf(e){let t=e.shadowRoot?.querySelector(`[part="submenu"]`);if(!t)return;let n=(e.shadowRoot?.querySelector(`slot:not([name])`))?.assignedNodes({flatten:!0}).map(e=>e.textContent).join(` `).replace(/\s+/gu,` `).trim(),r=e.getAttribute(`aria-label`)??n;r&&(t.setAttribute(`aria-label`,r),t.removeAttribute(`aria-labelledby`))}function Xf(e){e.querySelectorAll(`wa-dropdown-item`).forEach(Yf)}function Zf(e){let t=e.detail?.item;if(!(t instanceof HTMLElement)||t.localName!==`wa-dropdown-item`)return;let n=`updateComplete`in t?t.updateComplete:void 0;Promise.resolve(n).then(()=>{t.isConnected&&Yf(t)})}function Qf(e){let t=e.composedPath()[0];if(!(t instanceof HTMLElement)||t.localName!==`wa-dropdown`||(queueMicrotask(()=>{!e.defaultPrevented&&t.open&&Tt(t,`wa-after-hide`,function*(){let e=t.shadowRoot?.querySelector(`[part="menu"]`);e&&(yield e);for(let e of t.querySelectorAll(`wa-dropdown-item`)){let t=e.shadowRoot?.querySelector(`[part="submenu"]`);t&&(yield t)}})}),t.shadowRoot?.querySelector(`[part="menu"]`)?.removeAttribute(`inert`),Jf(t),Xf(t),np.get(t)?.disconnect(),typeof MutationObserver>`u`))return;let n=new MutationObserver(()=>{Jf(t),Xf(t)});n.observe(t,{attributes:!0,attributeFilter:[`aria-label`],childList:!0,characterData:!0,subtree:!0}),np.set(t,n)}function $f(e){let t=e.composedPath()[0];t instanceof HTMLElement&&t.localName===`wa-dropdown`&&queueMicrotask(()=>{e.defaultPrevented||!t.isConnected||t.open||t.shadowRoot?.querySelector(`[part="menu"]`)?.setAttribute(`inert`,``)})}function ep(e){let t=e.composedPath()[0];t instanceof HTMLElement&&t.localName===`wa-dropdown`&&(np.get(t)?.disconnect(),np.delete(t))}var tp,np;function rp(){return(rp=e((()=>{Mc(),kc(),Ze(),tp=new WeakSet,np=new WeakMap,typeof document<`u`&&(document.addEventListener(`wa-show`,Qf),document.addEventListener(`submenu-opening`,e=>{e instanceof CustomEvent&&Zf(e)},!0),document.addEventListener(`wa-hide`,$f),document.addEventListener(`wa-after-hide`,ep))})))()}function ip(e,t=null,n,r){let i=n===void 0&&e.agent?vt(e.agent,t):n??null;return e.icon&&!i?R`<span class="agent-select__avatar agent-select__avatar--icon" aria-hidden="true"
      >${e.icon}</span
    >`:Rf({id:e.agent?.id??e.value,avatar:i,textAvatar:e.agent?Et(e.agent,t):null},`agent-select__avatar`,r)}function ap(e){return R`
    <span class="agent-select__option-copy">
      <span class="agent-select__option-heading">
        <span class="agent-select__option-label">${e.label}</span>
        ${e.badge?R`<span class="agent-select__badge">${e.badge}</span>`:z}
      </span>
      ${e.description?R`<span class="agent-select__option-description">${e.description}</span>`:z}
    </span>
  `}var op;function sp(){return(sp=e((()=>{Mc(),kc(),B(),H(),da(),F(),pt(),$e(),ps(),M(),L(),Wf(),rp(),op=class extends Fn{constructor(...e){super(...e),this.options=[],this.value=``,this.placeholder=``,this.accessibleLabel=``,this.menuLabel=``,this.identityById={},this.disabled=!1,this.variant=`default`,this.onSelect=()=>{},this.onCreateAgent=null,this.avatarLoader=new Io(this),this.handleSelect=e=>{if(this.disabled){e.preventDefault();return}let t=e.detail.item;if(t.hasAttribute(`data-create-agent`)){this.onCreateAgent?.();return}let n=t.value??t.getAttribute(`value`);if(n!=null){if(n===this.value){e.preventDefault();let t=e.currentTarget;t.querySelector(`[slot="trigger"]`)?.focus({preventScroll:!0}),t.open=!1;return}this.onSelect(n)}}}willUpdate(e){if(e.has(`disabled`)&&this.disabled){let e=this.querySelector(`wa-dropdown`);e&&(e.open=!1)}}renderAvatar(e){let t=e.agent?.id,n=t?this.identityById[t]??null:null,r=e.agent?vt(e.agent,n):null;return ip(e,n,r?this.avatarLoader.resolve(r):null,r?this.avatarLoader.imageErrorHandler(r):void 0)}render(){return this.avatarLoader.withActiveRoutes(()=>this.renderContent())}renderContent(){let e=this.options.find(e=>e.value===this.value),t=!e&&this.value?{value:this.value,label:this.value,agent:{id:this.value}}:null,n=e??t,r=this.disabled||this.options.length===0&&!this.onCreateAgent,i=n?.label??(this.placeholder||j(`agents.noAgents`)),a=e?.badge,o=a?`${i}, ${a}`:i;return R`
      <wa-dropdown
        class="agent-select ${this.variant===`compact`?`agent-select--compact`:``}"
        placement="bottom-start"
        aria-label=${this.accessibleLabel||i}
        @wa-select=${this.handleSelect}
        @keydown=${e=>{let t=e.currentTarget;e.key===`Escape`&&t.open&&e.preventDefault()}}
      >
        <button
          slot="trigger"
          type="button"
          class="agent-select__trigger"
          aria-label=${this.accessibleLabel?`${this.accessibleLabel}: ${o}`:o}
          ?disabled=${r}
        >
          ${n?this.renderAvatar(n):z}
          <span class="agent-select__label">${i}</span>
          ${a?R`<span class="agent-select__badge">${a}</span>`:z}
          <span class="agent-select__chevron" aria-hidden="true">${I.chevronDown}</span>
        </button>
        ${this.menuLabel?R`<div class="agent-select__menu-title">${this.menuLabel}</div>`:z}
        ${this.options.map(e=>{let t=e.value===this.value,n=[e.label,e.description,e.badge].filter(Boolean).join(`, `);return R`
            <wa-dropdown-item
              class="agent-select__option"
              data-agent-option
              ?data-selected=${t}
              aria-label=${n}
              .value=${e.value}
              ?disabled=${this.disabled||e.disabled}
              ?autofocus=${t&&!this.disabled&&!e.disabled}
              ${la(e=>qf(e,t))}
            >
              <span slot="icon">${this.renderAvatar(e)}</span>
              ${ap(e)}
              <span slot="details" class="agent-select__option-state" aria-hidden="true">
                ${t?R`<span class="agent-select__option-check">${I.check}</span>`:z}
              </span>
            </wa-dropdown-item>
          `})}
        ${this.onCreateAgent?R`
                ${this.options.length>0?R`<div class="agent-select__separator" role="separator"></div>`:z}
                <wa-dropdown-item
                  class="agent-select__option"
                  data-create-agent
                  ?disabled=${this.disabled}
                >
                  <span slot="icon" class="agent-select__footer-icon" aria-hidden="true"
                    >${I.users}</span
                  >
                  <span class="agent-select__option-label">${j(`custodian.newAgent`)}</span>
                </wa-dropdown-item>
              `:z}
      </wa-dropdown>
    `}},w([W({attribute:!1})],op.prototype,`options`,void 0),w([W({attribute:!1})],op.prototype,`value`,void 0),w([W({attribute:!1})],op.prototype,`placeholder`,void 0),w([W({attribute:!1})],op.prototype,`accessibleLabel`,void 0),w([W({attribute:!1})],op.prototype,`menuLabel`,void 0),w([W({attribute:!1})],op.prototype,`identityById`,void 0),w([W({attribute:!1})],op.prototype,`disabled`,void 0),w([W({attribute:!1})],op.prototype,`variant`,void 0),w([W({attribute:!1})],op.prototype,`onSelect`,void 0),w([W({attribute:!1})],op.prototype,`onCreateAgent`,void 0)})))()}function cp(e){let t=Date.now();return e!=null&&Number.isFinite(e)&&e<=t&&t-e<6e4?j(`common.now`):st(e,{fallback:``,suffix:e!=null&&e>t})}function lp(e){return e!==void 0&&e<0xe8d4a51000?e*1e3:e}function up(e){let t=cn(e.sessionKey);for(let n of e.catalogs)for(let r of n.hosts)for(let i of r.sessions){let a=i.sessionKey??Rn({catalogId:n.id,hostId:r.hostId,threadId:i.threadId}),o=t?.catalogId===n.id&&t.hostId===r.hostId&&t.threadId===i.threadId;if(a!==e.sessionKey&&!o)continue;let s=Ae(i.cwd),c=Ae(i.gitBranch);return{...e.liveRow,hasActiveRun:e.liveRow?.hasActiveRun===!0,hasAutomation:e.liveRow?.hasAutomation===!0,label:e.liveRow?.label??(i.name||i.threadId),color:e.liveRow?e.liveRow.color:i.color,createdActor:e.liveRow?.createdActor??i.createdActor,createdAt:e.liveRow?.createdAt??lp(i.createdAt),updatedAt:e.liveRow?.updatedAt??lp(i.updatedAt),workContext:s?c||i.pullRequest?{kind:`project`,name:ze(s),path:s,...c?{branch:c}:{}}:{kind:`workspace`,name:ze(s),path:s}:e.liveRow?.workContext}}return e.liveRow}function dp(e){let t=new Set;for(let n of e)for(let e of n.hosts)for(let n of e.sessions)n.sessionKey&&t.add(n.sessionKey);return t}function fp(e,t,n){return n?[]:e.filter(e=>!t.has(e.id))}function pp(e){let t=new Set,n=e=>{e&&t.add(E(`[${e.code}] ${e.message}`))};n(e.error);for(let t of e.hosts)t.error?.code!==`NODE_OFFLINE`&&n(t.error);return[...t]}function mp(e,t,n){let r=new Map(n.toReversed().map(({key:e,owner:t})=>[e,t?.actor.id]));return e.flatMap(e=>{let n=hp(e.hosts,t,r);return n.length>0?[{...e,visibleHosts:n}]:[]})}function hp(e,t,n=new Map){let r=[];for(let i of e){let e=i.sessions.filter(e=>{if(!t)return!0;let r=e.sessionKey;return(r&&n.has(r)&&r?n.get(r):e.createdActor?.id)===t});e.length>0&&r.push(e.length===i.sessions.length?i:{...i,sessions:e})}return r}function gp(e,t){return e.map(e=>e.id===t.catalogId?{...e,hosts:e.hosts.map(e=>e.hostId===t.hostId?{...e,sessions:e.sessions.map(e=>e.threadId===t.threadId?{...e,sessionKey:t.sessionKey}:e)}:e)}:e)}function _p(){return(_p=e((()=>{F(),P(),_t(),ln(),Ue()})))()}function vp(e){let t=e.kind===`entry`?`data-sidebar-entry`:`data-session-section`,n=(n,r)=>{let i=n.closest(`[${t}]`),a=[...i?.parentElement?.children??[]].filter(n=>n.hasAttribute(t)&&(e.kind===`entry`||n.querySelector(`.sidebar-recent-sessions__head[draggable="true"]`))),o=i?a.indexOf(i):-1;return o<0?null:a[o+(r===`before`?-1:1)]?.getAttribute(t)??null},r=j(`chat.sidebar.reorderItem`,{item:e.label});return R`
    <wa-dropdown
      class="sidebar-reorder-menu"
      placement="bottom-end"
      aria-label=${r}
      @wa-show=${e=>{let t=e.currentTarget;if(t instanceof HTMLElement)for(let e of[`before`,`after`])t.querySelector(`wa-dropdown-item[value="${e}"]`)?.toggleAttribute(`disabled`,n(t,e)===null)}}
      @wa-select=${async t=>{let r=t.detail.item.value;if(r!==`before`&&r!==`after`)return;let i=t.currentTarget;if(!(i instanceof HTMLElement))return;let a=n(i,r);if(a){let t=i.querySelector(`button[slot=trigger]`);await e.onMove(a,r),t?.isConnected&&document.activeElement===document.body&&t.focus({preventScroll:!0})}}}
    >
      <button
        slot="trigger"
        type="button"
        class="sidebar-reorder-trigger"
        aria-label=${r}
        title=${r}
      >
        ${I.gripVertical}
      </button>
      <wa-dropdown-item value="before">
        <span slot="icon" aria-hidden="true">${I.arrowUp}</span>
        ${j(`chat.sidebar.moveUp`)}
      </wa-dropdown-item>
      <wa-dropdown-item value="after">
        <span slot="icon" aria-hidden="true">${I.arrowDown}</span>
        ${j(`chat.sidebar.moveDown`)}
      </wa-dropdown-item>
    </wa-dropdown>
  `}function yp(){return(yp=e((()=>{B(),F(),L(),rp()})))()}function bp(e){let t=e.draggable!==!1&&!e.disabledReason;return R`
    <div
      class="sidebar-recent-sessions__head ${t?`sidebar-recent-sessions__head--draggable`:``}"
      draggable=${t?`true`:`false`}
      title=${e.disabledReason??z}
      @mousedown=${e=>{e.currentTarget.toggleAttribute(`data-section-drag-blocked`,!!e.target.closest(`button, a`))}}
      @mouseup=${e=>{e.currentTarget.removeAttribute(`data-section-drag-blocked`)}}
      @dragstart=${n=>{if(!t){n.preventDefault();return}let r=n.currentTarget,i=!!n.target.closest(`button, a`)||r.hasAttribute(`data-section-drag-blocked`);if(r.removeAttribute(`data-section-drag-blocked`),i){n.preventDefault();return}n.dataTransfer&&(qo(n.dataTransfer,e.sectionId),e.onStartDrag(e.sectionId))}}
      @dragend=${t=>{t.currentTarget.removeAttribute(`data-section-drag-blocked`),e.onFinishDrag()}}
      @contextmenu=${e.onContextMenu??z}
    >
      <span class="sidebar-session-group-drag-handle" aria-hidden="true"></span>
      ${e.content}
      ${t&&e.reorder?vp({...e.reorder,kind:`section`}):z}
      ${e.status?R`<button
              type="button"
              class="sidebar-session-group-status"
              tabindex="-1"
              aria-label=${e.status.label}
              aria-expanded=${String(e.status.expanded)}
              title=${e.status.title??z}
              @click=${e.status.onToggle}
            >
              ${e.status.content}
            </button>`:z}
    </div>
  `}function xp(){return(xp=e((()=>{B(),Cc(),yp()})))()}function Sp(e){return e.split(/[-_]+/u).filter(Boolean).map(e=>`${e.charAt(0).toUpperCase()}${e.slice(1)}`).join(` `)}function Cp(e){return Fp[e]??Sp(e)}function wp(e){let t=e.indexOf(`/`);return(t>0?e.slice(0,t).trim().toLowerCase():``)||null}function Tp(e){let t=e.trim().toLowerCase(),n=Pp[t]??t;return Np.has(n)?n:null}function Ep(e){return Tp(e)!==null}function Dp(e){let t=(e?.providerDisplayId??e?.providerId??``).trim().toLowerCase();return Lp.get(t)??t}function Op(e,t){return Number(Ip.has(Dp(t)))-Number(Ip.has(Dp(e)))||e.id.localeCompare(t.id)}function kp(e){let t=Dp(e),n=Ip.get(t),r=n?.label??(e?.providerDisplayId??e?.providerId??``).trim().toLowerCase(),i=n?.brand?Ap(or(`cloud-provider-icons/${n.brand}.svg`),n.brand,`cloud-provider-icon`):t===`machine0`||t===`incus`?I.server:t===`local-container`?I.box:I.cloud;return{label:r,icon:R`<span class="cloud-profile-icon" aria-hidden="true">${i}</span>`}}function Ap(e,t,n=``){return R`<span
    class="provider-brand-icon ${n}"
    data-provider-icon=${t}
    style=${`--provider-icon-url: url("${e}")`}
    aria-hidden="true"
  ></span>`}function jp(e,t){let n=t?.className?` ${t.className}`:``,r=Ge(e.trim().toUpperCase(),1)||`?`;return R`
    <span
      class="provider-brand-icon provider-brand-icon--fallback${n}"
      aria-hidden="true"
    >
      ${r}
    </span>
  `}function Mp(e,t){let n=t?.className?` ${t.className}`:``,r=Tp(e);return r?Ap(or(`provider-icons/ProviderIcon-${r}.svg`),r,n.trim()):jp(e,t)}var Np,Pp,Fp,Ip,Lp;function Rp(){return(Rp=e((()=>{B(),dr(),Ct(),L(),Np=new Set(`abacus.alibaba.amp.antigravity.arcee.augment.baseten.bedrock.byteplus.cerebras.chutes.claude.clawrouter.cloudflare.codebuff.codex.cohere.comfy.commandcode.copilot.crof.crossmodel.cursor.deepgram.deepinfra.deepseek.devin.doubao.elevenlabs.factory.fal.featherless.fireworks.gemini.grok.groq.huggingface.jetbrains.kilo.kimi.kiro.litellm.llamacpp.llmproxy.lmstudio.longcat.manus.meta.microsoft.mimo.minimax.mistral.novita.nvidia.ollama.opencode.opencodego.openrouter.perplexity.pi.pixverse.poe.qianfan.qoder.runway.sakana.stepfun.synthetic.t3chat.tencent.together.venice.vercel.vertexai.vllm.volcengine.warp.windsurf.zai.zed`.split(`.`)),Pp={"acp-copilot":`copilot`,anthropic:`claude`,"amazon-bedrock":`bedrock`,"aws-bedrock":`bedrock`,"claude-cli":`claude`,"cloudflare-ai-gateway":`cloudflare`,"copilot-proxy":`copilot`,google:`gemini`,"google-gemini-cli":`gemini`,"github-copilot":`copilot`,kilocode:`kilo`,"kimi-coding":`kimi`,"llama-cpp":`llamacpp`,"microsoft-foundry":`microsoft`,"minimax-portal":`minimax`,"ollama-cloud":`ollama`,openai:`codex`,moonshot:`kimi`,"opencode-go":`opencodego`,"opencode-zen":`opencode`,qwen:`alibaba`,"qwen-token-plan":`alibaba`,"stepfun-plan":`stepfun`,"tencent-tokenhub":`tencent`,"tencent-tokenplan":`tencent`,xai:`grok`,xiaomi:`mimo`,"xiaomi-token-plan":`mimo`,"vercel-ai-gateway":`vercel`,"vertex-ai":`vertexai`,"z-ai":`zai`},Fp={"acp-copilot":`GitHub Copilot CLI`,anthropic:`Anthropic`,"claude-cli":`Claude CLI`,google:`Google`,"github-copilot":`GitHub`,"llama-cpp":`llama.cpp`,lmstudio:`LM Studio`,longcat:`LongCat`,openai:`OpenAI`,moonshot:`Moonshot AI`,opencode:`OpenCode`,openrouter:`OpenRouter`,qwen:`Qwen Cloud`,zai:`Z.AI`},Ip=new Map([[`aws`,{label:`AWS`,brand:`aws`}],[`azure`,{label:`Azure`,brand:`azure`}],[`daytona`,{label:`Daytona`,brand:`daytona`}],[`gcp`,{label:`Google Cloud`,brand:`gcp`}],[`hetzner`,{label:`Hetzner`,brand:`hetzner`}],[`machine0`,{label:`Machine0`}]]),Lp=new Map([[`google`,`gcp`],[`google-cloud`,`gcp`],[`docker`,`local-container`],[`local-docker`,`local-container`],[`podman`,`local-container`],[`local-podman`,`local-container`]])})))()}function zp(e,t,n){return e===`pair`?R`<svg
      class="session-glyph__trace${t?` session-glyph__trace--queued`:``}"
      viewBox="-16 -11 32 22"
      role="img"
      aria-label=${n}
    >
      <path class="session-glyph__trace-track" d=${Hp}></path>
      <path class="session-glyph__trace-run" d=${Hp} pathLength="100"></path>
    </svg>`:R`<span
    class="session-glyph__ring${t?` session-glyph__ring--queued`:``}"
    role="img"
    aria-label=${n}
  ></span>`}function Bp(e){let{content:t,running:n,queued:r=!1,runningLabel:i,circular:a=!1,badge:o=z,ring:s=`circle`}=e,c=R`<span class="session-glyph${`${a?` session-glyph--circular`:``}${n?` session-glyph--running`:``}${t===z?` session-glyph--bare`:``}`}">
    <span class="session-glyph__content">${t}</span>
    ${n?zp(s,r,i??j(r?`sessionsView.statusQueued`:`sessionsView.activeRun`)):z}
    ${o}
  </span>`;return n&&i?R`<openclaw-tooltip .content=${i} .describe=${!1}
        >${c}</openclaw-tooltip
      >`:c}function Vp(){return R`<span
    class="session-glyph__badge session-glyph__badge--unread"
    role="img"
    aria-label=${j(`sessionsView.unread`)}
  ></span>`}var Hp;function Up(){return(Up=e((()=>{B(),F(),ta(),Hp=`M0,-9.798A11,11 0 1 1 0,9.798A11,11 0 1 1 0,-9.798Z`})))()}function Wp(e){return[e?.osLabel||e?.os||``,e?.class||``,e?.cpu?j(`sessionHovercard.machineCpu`,{cpu:String(e.cpu)}):``,e?.memoryGb?j(`sessionHovercard.machineMemory`,{memory:String(e.memoryGb)}):``]}function Gp(){return(Gp=e((()=>{F()})))()}function Kp(e){return`${e.numbers.map(e=>`#${e}`).join(`, `)} · ${j(`chat.pullRequests.${e.state}`)}`}function qp(e,t,n=``,r=0,i,a,o,s=0){return R`<openclaw-tooltip .content=${e}>
    <span
      class=${`session-row-badge${n?` ${n}`:``}`}
      data-pull-request-state=${i??z}
      data-placement-state=${a??z}
      data-disk-space-status=${o??z}
      data-workspace-conflicts=${s?String(s):z}
      role="img"
      aria-label=${e}
      >${t}${r?R`<span aria-hidden="true">${r}</span>`:z}</span
    >
  </openclaw-tooltip>`}function Jp(e){let t=e.pullRequest?Kp(e.pullRequest):void 0,n=e.pullRequest?.state,r=e.isChild?void 0:e.placementState,i=no(r)?r:void 0,a=Math.max(0,Math.floor(e.workspaceConflictCount??0)),o=a>0?e.placementState:void 0,s=i??o,c=a>0,l=e.isChild?void 0:e.diskSpaceStatus,u=l===`critical`?j(`sessionsView.cloudWorkerDiskCritical`):l===`warning`?j(`sessionsView.cloudWorkerDiskWarning`):``,d=Math.max(0,Math.floor(e.outboxAttentionCount??0)),f=d>0?j(d===1?`sessionsView.messageNeedsAttention`:`sessionsView.messagesNeedAttention`,{count:String(d)}):``;if(!e.incognito&&!t&&!e.hasApproval&&d===0&&!e.hasComposerDraft&&!s&&!c)return z;let p=s?e.placementProviderId&&e.placementProfileId?[e.placementProviderId,e.placementProfileId,...Wp(e.placementMachine),s].filter(Boolean).join(` · `):j(`sessionsView.cloudWorkerPlacement`,{state:s}):``,m=[c?s?j(a===1?`sessionsView.placementWorkspaceConflict`:`sessionsView.placementWorkspaceConflicts`,{placement:p,count:String(a)}):j(a===1?`sessionsView.cloudWorkerDescendantConflict`:`sessionsView.cloudWorkerDescendantConflicts`,{count:String(a)}):p,u].filter(Boolean).join(` · `);return R`<span class="session-row-badges">
    ${e.incognito?qp(j(`sessionsView.incognito`),I.lock,`session-row-badge--incognito`):z}
    ${t?qp(t,n===`merged`?I.gitMerge:I.gitPullRequest,`session-row-badge--pull-request`,0,n):z}
    ${e.hasApproval?qp(j(`sessionsView.approvalNeeded`),I.alertTriangle,`session-row-badge--approval`):z}
    ${d>0?qp(f,I.alertTriangle,`session-row-badge--attention`,d):z}
    ${e.hasComposerDraft?qp(j(`sessionsView.unsentDraft`),I.pencil,`session-row-badge--draft`):z}
    ${s||c?qp(m,I.globe,`session-row-badge--cloud`,0,void 0,s,l,c?a:0):z}
  </span>`}function Yp(){return(Yp=e((()=>{B(),Va(),F(),L(),Gp()})))()}function Xp(e,t,n,r,i){let a=document.activeElement instanceof HTMLElement?document.activeElement:null,o=a?.closest(`[data-session-key]`),s=nm.find(e=>a?.matches(e)),c=s!==void 0&&(o?.dataset.catalogSessionKey===e||o?.dataset.sessionKey===e||o?.dataset.sessionKey===t);if(r||c)return e=>{e instanceof HTMLElement&&(r&&i.onCatalogMenuTriggerRendered(n,e.querySelector(`[data-catalog-session-menu]`)??e.querySelector(`.sidebar-recent-session__link`)??void 0),c&&queueMicrotask(()=>{e.isConnected&&document.activeElement===document.body&&(e.querySelector(s)??e.querySelector(`.sidebar-recent-session__link`))?.focus({preventScroll:!0})}))}}function Zp(e,t){return e?R`<span
      class="session-run-spinner"
      role="img"
      aria-label=${j(`sessionsView.activeRun`)}
      title=${j(`sessionsView.activeRun`)}
    ></span>`:t?R`<span
        class="session-unread-dot"
        role="img"
        aria-label=${j(`sessionsView.unread`)}
      ></span>`:z}function Qp(e){let t=new Map;for(let n of e.liveRows)t.has(n.key)||t.set(n.key,n);return e.catalogs.map(n=>{let r=`catalog:${n.id}`,i=e.collapsedSections.has(r),a=n.visibleHosts.flatMap(e=>e.sessions),o=a.flatMap(e=>{let n=e.sessionKey?t.get(e.sessionKey):void 0;return n?[n]:[]}),s=o.some(pe),c=o.some(e=>e.unread===!0),l=Ep(n.id),u=e.loadingMoreCatalogIds.has(n.id),d=n.hosts.some(e=>!!e.nextCursor),f=n.capabilities.startTerminal===!0,p=pp(n),m=p.length>0,h=p.join(`; `),g=j(`chat.sidebar.catalogDiscoveryHelp`,{error:h}),_=[`sidebar-recent-sessions__group`,`sidebar-recent-sessions__group--zone-coding`,i?`sidebar-recent-sessions__group--collapsed`:``,e.draggingSectionId===r?`sidebar-recent-sessions__group--dragging`:``,e.sectionDropTarget?.sectionId===r?`sidebar-recent-sessions__group--section-drop-${e.sectionDropTarget.position}`:``].filter(Boolean).join(` `);return R`
      <div
        class=${_}
        data-session-section=${r}
        @dragover=${e.sectionDragDisabledReason?z:t=>e.onSectionDragOver(t,r)}
        @dragleave=${e.sectionDragDisabledReason?z:t=>e.onSectionDragLeave(t,r)}
        @drop=${e.sectionDragDisabledReason?z:t=>e.onSectionDrop(t,r)}
      >
        ${bp({sectionId:r,status:m||i&&a.length>0?{label:m?`${n.label}: ${g}`:n.label,expanded:!i,title:m?g:void 0,onToggle:()=>e.onToggleSection(r),content:R`<span
                    class="sidebar-session-group-count ${m?`sidebar-session-group-count--error`:``}"
                    data-session-catalog-error=${m?n.id:z}
                    aria-hidden="true"
                    >${m?I.alertTriangle:a.length}</span
                  >`}:void 0,disabledReason:e.sectionDragDisabledReason,onStartDrag:e.onStartSectionDrag,onFinishDrag:e.onFinishSectionDrag,reorder:{label:n.label,onMove:(t,n)=>e.onReorderSection(r,t,n)},onContextMenu:t=>{t.preventDefault();let r=t.currentTarget,i=r.querySelector(`[data-session-catalog-view-menu]`)??r;e.onOpenViewMenu(n.id,i,{x:t.clientX,y:t.clientY})},content:R`
            <button
              type="button"
              class="sidebar-session-group-toggle"
              aria-expanded=${String(!i)}
              aria-label=${m?`${n.label}: ${g}`:n.label}
              title=${m?g:z}
              @click=${()=>e.onToggleSection(r)}
            >
              <span
                class="sidebar-session-group-toggle__lead ${l?`sidebar-session-group-toggle__lead--branded`:``}"
                aria-hidden="true"
              >
                ${l?Mp(n.id,{className:`sidebar-session-catalog-provider-icon`}):z}
                <span class="sidebar-session-group-toggle__icon"
                  >${i?I.chevronRight:I.chevronDown}</span
                >
              </span>
              ${ic(n.label,`sidebar-recent-sessions__label-text`)}
              ${Zp(s,c)}
            </button>
            <button
              type="button"
              class="sidebar-session-group-actions sidebar-session-sort sidebar-session-catalog-grouping ${e.ownerFilterActive?`sidebar-session-sort--filtered`:``}"
              data-session-catalog-view-menu=${n.id}
              title=${j(`chat.sidebar.catalogViewOptions`)}
              aria-label=${j(`chat.sidebar.catalogViewOptions`)}
              aria-haspopup="menu"
              aria-expanded=${String(e.viewMenuOpenCatalogId===n.id)}
              @click=${t=>{t.stopPropagation(),e.onOpenViewMenu(n.id,t.currentTarget)}}
            >
              ${I.listFilter}
            </button>
            ${f?Qr({basePath:e.basePath,agentId:e.newSessionAgentId,target:{catalogId:n.id},className:`sidebar-session-group-actions sidebar-session-new sidebar-session-catalog-new`,label:`${j(`chat.runControls.newSession`)} — ${n.label}`,disabledReason:e.newSessionDisabledReason,onOpen:e.onOpenNewSession}):z}
          `})}
        ${i?z:R`<div class="sidebar-recent-sessions__list">
                  ${n.visibleHosts.map(r=>$p(n,r,t,e))}
                </div>
                ${d?R`<button
                        type="button"
                        class="sidebar-session-catalog-load-more"
                        data-session-catalog-load-more=${n.id}
                        ?disabled=${u}
                        aria-busy=${String(u)}
                        @click=${()=>e.onLoadMore(n.id)}
                      >
                        ${j(`chat.selectors.loadMoreSessions`)}
                      </button>`:z}`}
      </div>
    `})}function $p(e,t,n,r){let i=t.error?E(`[${t.error.code}] ${t.error.message}`):void 0,a=r.projectGrouping===`project`?po(t.sessions):r.projectGrouping===`person`?Ws(t.sessions):null,o=(i,a=!1)=>va(i,n=>Rn({catalogId:e.id,hostId:t.hostId,threadId:n.threadId}),i=>em(e,t,i,n,r,a)),s=(e,t,n=!1)=>{let i=(r.visibleSessionLimits.get(t)??tm)>tm;return o(i?e:e.slice(0,tm),n)},c=(e,t)=>{if(e.length<=tm)return z;let n=(r.visibleSessionLimits.get(t)??tm)>tm,i=j(n?`chat.messages.showLess`:`chat.messages.showMore`);return R`<div class="sidebar-session-pagination sidebar-session-pagination--catalog">
      <button
        type="button"
        class="sidebar-session-pagination__button"
        aria-label=${i}
        @click=${()=>r.onSetVisibleSessionLimit(t,n?tm:e.length)}
      >
        ${i}
      </button>
    </div>`},l=a?.ungrouped??t.sessions,u=a?`catalog-${r.projectGrouping}-ungrouped:${e.id}:${t.hostId}`:`catalog-host:${e.id}:${t.hostId}`,d=t.kind!==`gateway`;return R`
    <section class="sidebar-session-catalog-host" data-session-catalog-host=${t.hostId}>
      ${d?R`<div
              class="sidebar-session-catalog-host__head"
              aria-label=${i?`${t.label}: ${i}`:t.label}
              title=${i??t.label}
            >
              <span class="sidebar-session-group-toggle__lead" aria-hidden="true">
                <span class="sidebar-session-group-toggle__icon">${I.monitor}</span>
              </span>
              <span class="sidebar-session-catalog-host__label">${t.label}</span>
              <span
                class="sidebar-session-catalog-host__count ${t.error?`sidebar-session-catalog-host__count--error`:``}"
                aria-hidden="true"
                >${t.error?I.alertTriangle:t.sessions.length}</span
              >
            </div>`:z}
      <div class="sidebar-session-catalog-host__sessions" role="list" aria-label=${t.label}>
        ${a?R`${va(a.groups,e=>e.key,n=>{let i=`catalog-${n.kind}:${e.id}:${t.hostId}:${n.key}`,a=n.legacySectionKey?`catalog-project:${e.id}:${t.hostId}:${n.legacySectionKey}`:null,o=r.collapsedSections.has(i)?i:a&&r.collapsedSections.has(a)?a:null,l=o!==null;return R`
                    <div class="sidebar-session-catalog-project" role="listitem">
                      <button
                        type="button"
                        class="sidebar-session-catalog-project__head"
                        data-session-catalog-project=${n.key}
                        aria-expanded=${String(!l)}
                        title=${n.title}
                        @click=${()=>r.onToggleSection(o??i)}
                      >
                        <span class="sidebar-session-catalog-project__icon" aria-hidden="true"
                          >${l?I.chevronRight:I.chevronDown}</span
                        >
                        <span class="sidebar-session-catalog-project__label">${n.label}</span>
                        <span class="sidebar-session-catalog-project__count" aria-hidden="true"
                          >${n.sessions.length}</span
                        >
                      </button>
                      ${l?z:R`<div
                                class="sidebar-session-catalog-project__sessions"
                                role="list"
                                aria-label=${`${t.label}: ${n.label}`}
                              >
                                ${s(n.sessions,i,!0)}
                              </div>
                              ${c(n.sessions,i)}`}
                    </div>
                  `})}
              ${s(l,u)}`:s(l,u)}
      </div>
      ${c(l,u)}
    </section>
  `}function em(e,t,n,r,i,a=!1){let o=lp(n.recencyAt??n.updatedAt??n.createdAt),s={catalogId:e.id,hostId:t.hostId,threadId:n.threadId,...n.sourceHomeId?{sourceHomeId:n.sourceHomeId}:{}},c=Rn(s),l=n.sessionKey??Rn(s,i.newSessionAgentId),u=n.name||n.threadId,d=cp(o),f=`chat`,{href:p,options:m}=Bn({face:f,sessionKey:l,fallbackAgentId:i.newSessionAgentId,basePath:i.basePath,mainKey:i.mainKey}),h={key:s,agentId:i.newSessionAgentId,routeId:f,navigation:m,canOpenTerminal:n.canOpenTerminal===!0,canDelete:n.canArchive&&e.capabilities.archive,name:n.name??n.threadId,meta:d},g=i.isMenuOpen(s),_=Xp(c,l,s,g,i),v=n.sessionKey?r.get(n.sessionKey):void 0;if(v)return i.renderLiveRow(v,{catalogIdentityKey:c,catalogMenu:h,..._?{rowRef:_}:{},...n.pullRequest?{pullRequest:n.pullRequest}:{}});let y=Ja(n.color??``),b=l===i.routeSessionKey,x=n.status===`active`||n.status===`running`,S=n.canOpenTerminal===!0&&i.terminalAvailable,ee=()=>i.onOpenTerminal(s,i.newSessionAgentId),C=(e,t,n)=>i.onOpenMenu(h,e,t,n),te=e=>Mn(e,e instanceof KeyboardEvent?e.currentTarget.querySelector(`[data-catalog-session-menu]`):null,(e,t,n)=>C(t,n,e??void 0)),ne=Ca(JSON.stringify([u,n.status,n.pullRequest]),ic(u,`sidebar-recent-session__name`));return R`
    <div
      ${_?la(_):z}
      class="sidebar-recent-session session-row-host sidebar-recent-session--single-line ${y?`sidebar-recent-session--colored`:``} ${b?`sidebar-recent-session--active`:``} ${a?`sidebar-recent-session--catalog-project-child`:``} ${x?`session-row-host--running`:``}"
      style=${y?`--session-color: var(--session-color-${y})`:z}
      data-session-key=${l}
      data-catalog-session-key=${c}
      data-session-row-action-count="1"
      role="listitem"
      @contextmenu=${te}
      @keydown=${te}
    >
      <a
        href=${p}
        class="sidebar-recent-session__link"
        aria-current=${b?`page`:z}
        @click=${e=>{k(e)&&(e.preventDefault(),i.catalogOpenTarget===`terminal`&&S?ee():i.onNavigate?.(f,m))}}
      >
        <span class="sidebar-session-indicator">
          ${x?Bp({content:z,running:x}):z}
        </span>
        <span class="sidebar-recent-session__text">
          <span class="sidebar-recent-session__title-row"> ${ne} </span>
          <span class="sidebar-recent-session__details">
            <span class="sidebar-recent-session__details-endcap">
              ${Jp({pullRequest:n.pullRequest})}
            </span>
          </span>
        </span>
      </a>
      <span class="sidebar-recent-session__aside session-row-aside">
        <span class="session-row-actions">
          <button
            class="session-action"
            data-catalog-session-menu="true"
            type="button"
            title=${j(`chat.sidebar.openSessionMenu`)}
            aria-label=${j(`chat.sidebar.openSessionMenu`)}
            aria-haspopup="menu"
            aria-expanded=${String(g)}
            @click=${e=>{e.stopPropagation();let t=e.currentTarget,n=t.getBoundingClientRect();C(n.right,n.bottom+4,t)}}
          >
            ${I.moreHorizontal}
          </button>
        </span>
      </span>
    </div>
  `}var tm,nm;function rm(){return(rm=e((()=>{B(),Ea(),da(),Oa(),Qa(),F(),P(),zo(),an(),Ue(),Hs(),Qt(),_p(),xp(),L(),yi(),Rp(),Up(),Yp(),tm=5,nm=[`.sidebar-recent-session__link`,`[data-child-session-toggle]`,`[data-sidebar-session-pin]`,`[data-sidebar-session-archive]`,`[data-sidebar-session-menu]`,`[data-catalog-session-menu]`]})))()}function im(e){let t=Un(La(hl(e).text)),n=Ns(t);return!t||Wn(t)||Jn(t)||n.shouldSkip?null:n.text}function am(e){let t=im(e);if(!t)return``;let n=t.replace(/```[\s\S]*?```/g,` `).split(/\n\s*\n/),r=``;for(let e=n.length-1;e>=0&&(r=za(n[e]??``),!r);--e);if(!r)return``;let i=r.match(/[^.!?…]+(?:[.!?…]+(?=\s|$)|$)/g)?.map(e=>e.trim()).findLast(e=>!!e)??r;return Ve(i,om)}var om;function sm(){return(sm=e((()=>{Fa(),Gn(),fl(),fc(),_t(),om=120})))()}function cm(){return{retryWindowMs:hm,retryAt:0,timer:null}}function lm(e){let t=[Ra,Ia];for(let n=Math.min(e.length,...t.map(e=>e.length-1));n>=1;--n){let r=e.slice(-n);if(t.some(e=>e.startsWith(r)))return r}return``}function um(e){return e.startedAt??e.updatedAt??0}function dm(e,t){return typeof t!=`string`||!t.trim()||b(t)===b(e)}var fm,pm,mm,hm,gm,_m;function vm(){return(vm=e((()=>{f(),re(),Qc(),ro(),Fa(),dl(),F(),N(),Ss(),sm(),fm=6,pm=2e3,mm=16384,hm=500,gm=3e4,_m=class{constructor(e,t=()=>void 0){this.onLinesChanged=e,this.onObserverDigestsChanged=t,this.source=null,this.input=null,this.visibilityDocument=null,this.handleVisibilityChange=()=>{this.input&&this.sync(this.input)},this.connectionIdentity=null,this.connected=!1,this.enabled=!1,this.agentId=`main`,this.desiredKeys=new Set,this.subscriptions=new Map,this.pendingReleases=new Map,this.pendingSubscriptions=new Map,this.streams=new Map,this.runIds=new Map,this.throttles=new Map,this.lines=new Map,this.observerDigests=new Map}sync(e){this.input||(this.visibilityDocument=globalThis.document??null,this.visibilityDocument?.addEventListener(`visibilitychange`,this.handleVisibilityChange)),this.input=e;let t=this.connectionIdentity!==e.connectionIdentity,n=this.source!==e.source,r=!e.connected||!e.connectionIdentity||!e.source;if((t||n||r)&&this.resetSubscriptions(),this.source=e.source,this.connectionIdentity=e.connectionIdentity,this.connected=e.connected,this.enabled=e.enabled&&this.visibilityDocument?.visibilityState!==`hidden`,this.agentId=b(e.agentId),r||!this.enabled){this.desiredKeys=new Set,this.resetSubscriptions(),this.syncReleases(),this.clearAllLines();return}let i=e.openSessionKey.trim(),a=new Set,o=0;for(let t of e.rows.filter(e=>e.hasActiveRun).toSorted((e,t)=>Number(this.subscriptions.has(t.key)||this.pendingSubscriptions.has(t.key))-Number(this.subscriptions.has(e.key)||this.pendingSubscriptions.has(e.key))||um(t)-um(e))){let e=O(t.key,i);!e&&o>=fm||(a.add(t.key),e||(o+=1))}for(let e of this.desiredKeys)a.has(e)||this.releaseKey(e);this.desiredKeys=a;for(let e of a){let t=this.subscriptionAgentId(e),n=this.subscriptions.get(e)?.subscription.agentId??null,r=this.pendingSubscriptions.get(e)?.agentId??null;(this.subscriptions.has(e)&&n!==t||this.pendingSubscriptions.has(e)&&r!==t)&&this.releaseKey(e),!(this.subscriptions.has(e)||(this.pendingSubscriptions.get(e)?.retryAt??0)>Date.now())&&this.subscribeKey(e)}this.syncReleases()}handleEvent(e){if(this.enabled&&this.connected){if(e.event===`chat`){this.handleChatEvent(e.payload);return}if(e.event===`session.narration`){this.handleNarrationEvent(e.payload);return}if(e.event===`session.observer`){this.handleObserverEvent(e.payload);return}(e.event===`agent`||e.event===`session.tool`)&&this.handleAgentEvent(e.payload)}}disconnect(){this.visibilityDocument?.removeEventListener(`visibilitychange`,this.handleVisibilityChange),this.visibilityDocument=null,this.input=null,this.desiredKeys=new Set,this.resetSubscriptions(),this.clearAllLines(),this.connected=!1,this.syncReleases()}async subscribeKey(e){let t=this.source,n=this.connectionIdentity;if(!t||!n||!this.connected||!this.enabled||!this.desiredKeys.has(e))return;let r=this.pendingSubscriptions.get(e)??{agentId:this.subscriptionAgentId(e),...cm()};this.cancelRetry(r),r.retryAt=1/0,this.pendingSubscriptions.set(e,r);try{let i={key:e,source:t,connectionIdentity:n,subscription:await t.subscribeMessages(e,{agentId:r.agentId??void 0,mode:`narration`})},a=this.pendingSubscriptions.get(e)===r;if(a&&this.pendingSubscriptions.delete(e),!a||t!==this.source||!this.connected||!this.enabled||!this.desiredKeys.has(e)){this.releaseSubscription(i);return}this.subscriptions.set(e,i),this.syncReleases()}catch(t){this.pendingSubscriptions.get(e)===r&&this.scheduleRetry(r,t)}}scheduleRetry(e,t){if(e.retryAt=1/0,!(t instanceof ae)&&(!(t instanceof ne)||!t.retryable))return;let n=t instanceof ne?t.retryAfterMs:void 0,r=p((typeof n==`number`&&Number.isFinite(n)?Math.max(0,n):0)+Math.random()*e.retryWindowMs);e.retryWindowMs=Math.min(e.retryWindowMs*2,gm),e.retryAt=Date.now()+r,e.timer=globalThis.setTimeout(()=>{e.timer=null,e.retryAt=0,this.input&&this.sync(this.input)},r)}cancelRetry(e){e.timer!==null&&(globalThis.clearTimeout(e.timer),e.timer=null)}subscriptionAgentId(e){return Pn(e)?this.agentId:null}releaseKey(e){let t=this.pendingSubscriptions.get(e);t&&this.cancelRetry(t),this.pendingSubscriptions.delete(e);let n=this.subscriptions.get(e);this.subscriptions.delete(e),n&&this.releaseSubscription(n),this.clearLine(e)}releaseSubscription(e){let t=this.pendingReleases.get(e)??cm();e.release||t.retryAt>Date.now()||(this.cancelRetry(t),t.retryAt=1/0,this.pendingReleases.set(e,t),e.release=e.source.unsubscribeMessages(e.subscription).then(()=>{this.pendingReleases.delete(e)}).catch(n=>{this.pendingReleases.get(e)===t&&!this.releaseIsDesired(e)&&this.scheduleRetry(t,n)}).finally(()=>{e.release=void 0,this.syncReleases()}))}releaseIsDesired(e){return e.source===this.source&&this.desiredKeys.has(e.key)&&(e.subscription.agentId??null)===this.subscriptionAgentId(e.key)}syncReleases(){for(let[e,t]of this.pendingReleases){if(!this.connected||e.connectionIdentity!==this.connectionIdentity){this.cancelRetry(t),t.retryAt=0,(this.input||e.connectionIdentity!==this.connectionIdentity)&&this.pendingReleases.delete(e);continue}this.releaseIsDesired(e)&&(this.cancelRetry(t),t.retryAt=0,!this.subscriptions.has(e.key))||this.releaseSubscription(e)}}resetSubscriptions(){let e=new Set([...this.subscriptions.keys(),...this.pendingSubscriptions.keys()]);for(let t of e)this.releaseKey(t)}matchingDesiredKey(e,t){if(typeof e!=`string`||!e.trim())return null;for(let n of this.desiredKeys)if(O(n,e)&&(!Pn(n)||dm(this.agentId,t)))return n;return null}handleChatEvent(e){if(!e||typeof e!=`object`)return;let t=e,n=this.matchingDesiredKey(t.sessionKey,t.agentId);if(!n||(this.observeRun(n,t.runId),this.observerDigests.has(n)))return;let r=t.state===`final`||t.state===`aborted`||t.state===`error`,i=t.message;if(i&&typeof i.role==`string`&&i.role!==`assistant`)return;let a=typeof t.deltaText==`string`?t.deltaText:``,o=i?$s(pl(i)??``):null,s=this.streams.get(n)?.consumedLength??0;if(t.replace===!0){let e=o??a;this.publishText(n,{streamLength:e.length,fragment:e,reset:!0,immediate:r});return}if(a){if(o!==null){let e=s>0&&o.length-a.length===s;this.publishText(n,{streamLength:o.length,fragment:e?a:o,reset:!e,immediate:r})}else s>0&&this.publishText(n,{streamLength:s+a.length,fragment:a,reset:!1,immediate:r});return}if(o!==null)this.publishText(n,{streamLength:o.length,fragment:o,reset:!0,immediate:r});else if(r){let e=this.throttles.get(n)?.pending;e&&this.publishImmediate(n,e)}}handleNarrationEvent(e){if(!Zc(io,e))return;let t=this.matchingDesiredKey(e.sessionKey,e.agentId);t&&(this.observeRun(t,e.runId),!this.observerDigests.has(t)&&(this.streams.delete(t),this.publishImmediate(t,{kind:`text`,text:e.text})))}publishText(e,t){if(t.streamLength<=0){t.reset&&this.clearLine(e);return}let n=this.streams.get(e)??{consumedLength:0,internalDepth:0,delimiterTail:``,visibleText:``};if(n.consumedLength=t.streamLength,this.streams.set(e,n),t.reset){n.internalDepth=0,n.delimiterTail=``,n.visibleText=``;let t=this.throttles.get(e);t&&(t.pending=null)}let r=this.stripInternalRuntimeFragment(n,t.fragment),i=`${n.visibleText}${r}`;if(!i){t.reset&&this.lines.delete(e)&&this.onLinesChanged(new Map(this.lines));return}n.visibleText=i.length>mm?u(i,-16384):i;let a={kind:`text`,text:n.visibleText};t.immediate?this.publishImmediate(e,a):this.publishThrottled(e,a)}stripInternalRuntimeFragment(e,t){let n=`${e.delimiterTail}${t}`;e.delimiterTail=``;let r=e.internalDepth,i=0,a=``;for(;i<n.length;){let e=n.indexOf(Ra,i),t=n.indexOf(Ia,i);if(r===0){if(e===-1&&t===-1){a+=n.slice(i);break}if(t!==-1&&(e===-1||t<e)){i=t+Ia.length;continue}a+=n.slice(i,e),r=1,i=e+Ra.length;continue}if(e===-1&&t===-1)break;if(e!==-1&&(t===-1||e<t)){r+=1,i=e+Ra.length;continue}--r,i=t+Ia.length}let o=lm(n);return o&&(e.delimiterTail=o,r===0&&a.endsWith(o)&&(a=a.slice(0,-o.length))),e.internalDepth=r,a}handleAgentEvent(e){if(!e||typeof e!=`object`)return;let t=e,n=this.matchingDesiredKey(t.sessionKey,t.agentId);if(!n||(this.observeRun(n,t.runId),t.stream!==`tool`||this.observerDigests.has(n)))return;let r=t.data,i=typeof r?.name==`string`?r.name.trim():``;i&&this.publishThrottled(n,{kind:`line`,line:j(`chat.sidebar.toolActivity`,{tool:i})})}handleObserverEvent(e){if(!e||typeof e!=`object`)return;let t=e,n=this.matchingDesiredKey(t.sessionKey,t.agentId),r=typeof t.runId==`string`?t.runId.trim():``;if(!n||!r)return;let i={...t,runId:r};if(!Zc(Wa,i))return;this.observeRun(n,r);let a=this.observerDigests.get(n);a&&Fs(a,i)===a||(this.clearNarration(n),this.observerDigests.set(n,i),this.onObserverDigestsChanged(new Map(this.observerDigests)))}observeRun(e,t){let n=typeof t==`string`?t.trim():``;if(!n)return;let r=this.runIds.get(e);r&&r!==n&&this.clearLine(e),this.runIds.set(e,n)}publishThrottled(e,t){let n=Date.now(),r=this.throttles.get(e);if(!r||n-r.lastPublishedAt>=pm){this.publishImmediate(e,t);return}r.pending=t,!r.timer&&(r.timer=globalThis.setTimeout(()=>{r.timer=null;let t=r.pending;r.pending=null,t&&this.desiredKeys.has(e)&&(r.lastPublishedAt=Date.now(),this.publishActivity(e,t))},pm-(n-r.lastPublishedAt)))}publishImmediate(e,t){let n=this.throttles.get(e)?.timer;n&&globalThis.clearTimeout(n),this.throttles.set(e,{lastPublishedAt:Date.now(),pending:null,timer:null}),this.publishActivity(e,t)}publishActivity(e,t){let n=t.kind===`text`?am(t.text):t.line;if(n){this.lines.get(e)!==n&&(this.lines.set(e,n),this.onLinesChanged(new Map(this.lines)));return}t.kind===`text`&&this.lines.delete(e)&&this.onLinesChanged(new Map(this.lines))}clearLine(e){this.clearNarration(e),this.runIds.delete(e),this.observerDigests.delete(e)&&this.onObserverDigestsChanged(new Map(this.observerDigests))}clearNarration(e){this.streams.delete(e);let t=this.throttles.get(e);t?.timer&&globalThis.clearTimeout(t.timer),this.throttles.delete(e),this.lines.delete(e)&&this.onLinesChanged(new Map(this.lines))}clearAllLines(){for(let e of this.throttles.values())e.timer&&globalThis.clearTimeout(e.timer);this.streams.clear(),this.runIds.clear(),this.throttles.clear(),this.lines.size>0&&(this.lines.clear(),this.onLinesChanged(new Map)),this.observerDigests.size>0&&(this.observerDigests.clear(),this.onObserverDigestsChanged(new Map))}}})))()}var ym;function bm(){return(bm=e((()=>{ta(),rp(),ym=class{constructor(e,t){this.host=e,this.options=t,this.generation=0,this.handleDocumentKeydown=e=>{if(!(e.defaultPrevented||Nr(e,this.host.ownerDocument))&&(this.options.onKeydown?.(e),!e.defaultPrevented)){if(e.key!==`Escape`){e.key===`Tab`&&e.composedPath().some(e=>e instanceof Element&&e.localName===`wa-dropdown-item`&&this.host.contains(e))&&Gf(e,()=>this.options.getTrigger()?.focus());return}e.preventDefault(),e.stopPropagation(),this.options.getTrigger()?.focus(),this.options.onClose()}},e.addController(this)}hostConnected(){document.addEventListener(`keydown`,this.handleDocumentKeydown,!0);let e=++this.generation;this.focusFirstItem(e)}hostDisconnected(){this.generation+=1,document.removeEventListener(`keydown`,this.handleDocumentKeydown,!0)}async focusFirstItem(e){await this.host.updateComplete,await this.host.querySelector(`wa-dropdown`)?.updateComplete,this.host.isConnected&&e===this.generation&&this.host.querySelector(`wa-dropdown-item:not([disabled])`)?.focus()}}})))()}function xm(e){if(e.key!==`Tab`)return!1;let t=e.composedPath().find(e=>e instanceof HTMLElement),n=e.composedPath().find(e=>e instanceof HTMLElement&&e.localName===`wa-dropdown-item`),r=t?.closest(`.people-menu__search, .people-menu__pagination`)?.parentElement??n?.parentElement,i=r?.querySelector(`:scope > .people-menu__search input`);if(!i||!t)return!1;let a=[];for(let e=i.parentElement?.nextElementSibling;e?.localName===`wa-dropdown-item`;e=e.nextElementSibling)e instanceof HTMLElement&&!e.hasAttribute(`disabled`)&&a.push(e);let o=[i,...r?.querySelectorAll(`:scope > .people-menu__pagination button:not(:disabled)`)??[]],s=o.indexOf(t);if(s<0&&(!n||!a.includes(n)))return!1;let c=[...o,...a[0]?[a[0]]:[]],l=s<0?c.length-1:s;return e.preventDefault(),e.stopPropagation(),c[(l+(e.shiftKey?-1:1)+c.length)%c.length]?.focus(),!0}var Sm,Cm,wm;function Tm(){return(Tm=e((()=>{B(),ba(),xa(),F(),Os(),Ks(),Sm=20,Cm=class extends ua{constructor(...e){super(...e),this.rows=[],this.query=``,this.page=0,this.onInput=e=>{this.query=e.currentTarget.value,this.page=0,this.setValue(this.content())},this.onKeydown=e=>{if(xm(e)||e.key===`Escape`||(e.stopPropagation(),e.isComposing||e.keyCode===229||![`ArrowDown`,`Enter`].includes(e.key)))return;e.preventDefault();let t=e.currentTarget.parentElement?.nextElementSibling;for(;t?.localName===`wa-dropdown-item`;){if(t instanceof HTMLElement&&!t.hasAttribute(`disabled`)){t.focus();return}t=t.nextElementSibling}}}render(e,t,n){return t!==this.scope&&(this.query=``,this.page=0),this.rows=e,this.scope=t,this.slot=n,this.content()}movePage(e,t){e.stopPropagation();let n=e.currentTarget;this.page=t,this.setValue(this.content()),n instanceof HTMLButtonElement&&n.disabled&&n.parentElement?.parentElement?.querySelector(`:scope > .people-menu__search input`)?.focus({preventScroll:!0})}content(){let e=this.query.trim().toLocaleLowerCase().split(/\s+/u),t=this.rows.filter(t=>{let n=t.text.toLocaleLowerCase();return e.every(e=>n.includes(e))});this.page=Math.min(this.page,Math.max(0,Math.ceil(t.length/Sm)-1));let n=this.page*Sm,r=t.slice(n,n+Sm);return R`
      <div
        slot=${this.slot??z}
        class="people-menu__search"
        @click=${e=>e.stopPropagation()}
      >
        <input
          type="search"
          autocomplete="off"
          aria-label=${j(`sessionsView.searchPeople`)}
          placeholder=${j(`sessionsView.searchPeople`)}
          .value=${Ta(this.query)}
          @input=${this.onInput}
          @keydown=${this.onKeydown}
        />
      </div>
      ${r.map(e=>e.render())}
      <div
        slot=${this.slot??z}
        class="people-menu__pagination"
        @click=${e=>e.stopPropagation()}
        @keydown=${e=>{!xm(e)&&e.key!==`Escape`&&e.stopPropagation()}}
      >
        <span role="status"
          >${t.length===0?j(`sessionsView.noPeopleMatch`):this.rows.length>Sm||this.query?j(`sessionsView.peopleRange`,{start:String(n+1),end:String(n+r.length),total:String(t.length)}):z}</span
        >
        ${t.length>Sm?R`
                <button
                  type="button"
                  class="btn btn--ghost btn--sm"
                  ?disabled=${this.page===0}
                  @click=${e=>this.movePage(e,this.page-1)}
                >
                  ${j(`common.previous`)}
                </button>
                <button
                  type="button"
                  class="btn btn--ghost btn--sm"
                  ?disabled=${n+Sm>=t.length}
                  @click=${e=>this.movePage(e,this.page+1)}
                >
                  ${j(`common.next`)}
                </button>
              `:z}
      </div>
    `}},wm=pa(Cm)})))()}function Em(e,t){let n=e.length===1?e.toUpperCase():e;return R`<span slot="details" class="session-menu__shortcut" aria-hidden="true"
    >${cr(n,{inline:!0})}${t?R` / ${mr(t,{inline:!0})}`:``}</span
  >`}function Dm(e,t){if(xm(t))return!0;if(t.metaKey||t.ctrlKey||t.altKey||t.composedPath().some(e=>e instanceof Element&&e.matches(`input, textarea, select, [contenteditable=true]`)))return!1;let n=Bt(t);if(!n)return!1;let r=e.querySelector(`[data-shortcut="${n}"]`);if(!r||r.disabled||r.getAttribute(`aria-disabled`)===`true`)return!1;let i=r.closest(`wa-dropdown-item:not([slot="submenu"])`);return r.getAttribute(`slot`)===`submenu`&&i?.submenuOpen!==!0?!1:(t.preventDefault(),t.stopPropagation(),r.click(),!0)}function Om(){return(Om=e((()=>{B(),an(),Ur(),Tm()})))()}function km(e){if(Tt(e),e.setAttribute(`popover`,`manual`),typeof e.showPopover==`function`)try{e.showPopover();return}catch{}e.removeAttribute(`popover`)}var Am;function jm(){return(jm=e((()=>{Ze(),Am=class extends HTMLElement{connectedCallback(){km(this)}},customElements.get(`openclaw-menu-surface`)||customElements.define(`openclaw-menu-surface`,Am)})))()}function Mm(e){return eo.some(t=>t===e)}function Nm(e){return e.startsWith(`data:image/svg+xml,`)?R`<img src=${e} alt="" aria-hidden="true" />`:Mm(e)?Pm[e]:null}var Pm;function Fm(){return(Fm=e((()=>{B(),Qa(),L(),Pm={braces:I.braces,book:I.book,monitor:I.monitor,bot:I.bot,kanban:I.kanban,coins:I.coins}})))()}function Im(e){return e.archiveShortcut&&e.selectionCount===1&&!e.session.archived?Nt.archiveSession:void 0}function Lm(e){return R`
    ${Rs.map(t=>R`
        <wa-dropdown-item
          slot=${e.inline?z:`submenu`}
          class="session-menu__item"
          value=${`open-in:${t}`}
          ?disabled=${e.disabled}
        >
          <span class="session-menu__text">${ws[t]}</span>
        </wa-dropdown-item>
      `)}
  `}function Rm(e){let t=1,n=()=>t<=9?String(t++):null,r=(t,r,i,a=!0)=>{let o=n(),s=i===`new-group`?`new-group`:`move-to-group`;return R`
      <wa-dropdown-item
        slot=${e.inline?z:`submenu`}
        class="session-menu__item"
        value=${i}
        role=${a?`menuitemradio`:`menuitem`}
        aria-checked=${a?String(r):z}
        ${a?la(e=>qf(e,r)):z}
        data-shortcut=${o??z}
        aria-keyshortcuts=${o??z}
        ?disabled=${e.actionDisabled(s)}
        title=${e.actionTitle(s)}
      >
        <span class="session-menu__text">${t}</span>
        ${a&&r?R`<span slot="details" class="session-menu__check" aria-hidden="true"
                >${I.check}</span
              >`:z}
        ${o?Em(o):z}
      </wa-dropdown-item>
    `};return R`
    ${e.groups.map(t=>r(t,e.category===t,`move-to-group:${encodeURIComponent(t)}`))}
    ${e.category?r(j(e.categoryClearReturnsToGroups?`sessionsView.moveBackToGroups`:`sessionsView.removeFromGroup`),!1,`move-to-group:`,!1):z}
    ${r(j(`sessionsView.newGroup`),!1,`new-group`,!1)}
  `}function zm(e){let t=Ja(e.color??``);return R`<div
    class="session-menu__colors"
    role="group"
    aria-label=${j(`sessionsView.setColorMenu`)}
  >
    ${(e.allowDefault===!1?Ka:[null,...Ka]).map(n=>{let r=j(n?`sessionsView.colors.${n}`:`sessionsView.noColor`),i=t===n&&(n!==null||!e.color);return R`<button
          type="button"
          class="session-menu__color-choice"
          aria-label=${r}
          aria-pressed=${String(i)}
          ?disabled=${e.disabled}
          title=${e.disabledReason??r}
          @click=${t=>e.onSelect(t,n)}
        >
          <span
            class=${`session-menu__color-swatch${n===null?` session-menu__color-swatch--none`:``}`}
            style=${n?`background: var(--session-color-${n})`:z}
            aria-hidden="true"
            >${n===null?I.circleX:i?I.check:z}</span
          >
        </button>`})}
  </div>`}function Bm(){return(Bm=e((()=>{B(),da(),Qa(),F(),ec(),qt(),L(),Om(),rp()})))()}function Vm(){let e=globalThis.navigator?.platform??``;return/Mac|iPhone|iPad|iPod/u.test(e)?[`⌃`,`⌘`,`Space`]:/Win/u.test(e)?[`Win`,`+`,`.`]:null}function Hm(e){let t=Ua(e.customIconValue),n=t&&(e.allowSvg||!t.startsWith(`data:image/svg+xml,`)),r=Vm();return R`
    <div
      class="session-menu__icon-custom-entry"
      aria-hidden=${e.mode===`custom`?z:`true`}
      ?inert=${e.mode!==`custom`}
    >
      <div class="session-menu__icon-custom-header">
        <button
          type="button"
          class="session-menu__icon-back"
          aria-label=${j(`common.back`)}
          @click=${e.onBack}
        >
          ${I.arrowLeft}
        </button>
        <span
          >${j(e.allowSvg?`sessionsView.customIconTitle`:`sessionsView.customEmojiTitle`)}</span
        >
      </div>
      <div class="session-menu__icon-custom-controls">
        <textarea
          class="session-menu__icon-custom-input"
          rows="1"
          autocomplete="off"
          aria-label=${j(e.allowSvg?`sessionsView.customIconTitle`:`sessionsView.customEmojiTitle`)}
          .value=${e.customIconValue}
          @input=${e.onInput}
          @keydown=${t=>{t.key!==`Enter`||t.isComposing||t.keyCode===229||(t.preventDefault(),t.stopPropagation(),n&&!e.disabled&&e.onApply(t))}}
        ></textarea>
        <button
          type="button"
          class="session-menu__icon-set"
          ?disabled=${!n||e.disabled}
          @click=${e.onApply}
        >
          ${j(`sessionsView.customEmojiSet`)}
        </button>
      </div>
      <div class="session-menu__icon-custom-hint">
        ${r?pr(j(e.allowSvg?`sessionsView.customIconHint`:`sessionsView.customEmojiHint`,{shortcut:`{shortcut}`}),cr(r,{inline:!0})):j(e.allowSvg?`sessionsView.customIconHintNoShortcut`:`sessionsView.customEmojiHintNoShortcut`)}
      </div>
    </div>
  `}function Um(e){let t=e.clearable!==!1&&e.currentIcon===null?null:[...Km,...eo].find(t=>t===e.currentIcon)??Km[0],n=(n,r=!1)=>R`
    <button
      type="button"
      class=${`session-menu__icon-choice${r?` session-menu__icon-choice--glyph`:``}`}
      aria-label=${r?n??j(`sessionsView.noIcon`):z}
      aria-pressed=${String(e.currentIcon===n)}
      tabindex=${n===t?`0`:`-1`}
      ?disabled=${e.disabled}
      title=${e.disabledReason??(n===null?j(`sessionsView.noIcon`):z)}
      @click=${t=>e.onSelect(t,n)}
    >
      ${n===null?I.circleX:r?Nm(n):n}
    </button>
  `;return R`
    <div class="session-menu__icon-picker session-menu__icon-panel" data-mode=${e.mode}>
      <div
        class="session-menu__icon-options"
        aria-hidden=${e.mode===`grid`?z:`true`}
        ?inert=${e.mode!==`grid`}
        role="group"
        aria-label=${j(`sessionsView.setIconMenu`)}
        @keydown=${e.onGridKeydown}
      >
        <div class="session-menu__icon-section-label">${j(`sessionsView.iconEmojiSection`)}</div>
        <div class="session-menu__icon-grid">
          ${Km.map(e=>n(e))}
          <button
            type="button"
            class="session-menu__icon-choice session-menu__icon-choice--custom"
            aria-label=${j(e.allowSvg?`sessionsView.customIconCell`:`sessionsView.customEmojiCell`)}
            aria-pressed="false"
            tabindex="-1"
            ?disabled=${e.disabled}
            title=${e.disabledReason??z}
            @click=${e.onShowCustom}
          >
            ${I.moreHorizontal}
          </button>
        </div>
        <div class="session-menu__icon-section-label">${j(`sessionsView.iconGlyphSection`)}</div>
        <div class="session-menu__icon-grid">
          ${e.clearable===!1?z:n(null,!0)}
          ${eo.map(e=>n(e,!0))}
        </div>
      </div>
      ${Hm(e)}
    </div>
  `}function Wm(e){return R`<div slot=${e.inline?z:`submenu`} class="session-menu__appearance">
    <div class="session-menu__icon-section-label">${j(`sessionsView.setColorMenu`)}</div>
    ${zm({color:e.currentColor,allowDefault:e.clearable!==!1,disabled:e.colorDisabled,disabledReason:e.colorDisabledReason,onSelect:e.onSelectColor})}
    ${Um(e)}
    ${e.clearable===!1?z:R`<div class="session-menu__separator" role="separator"></div>
            <button
              type="button"
              class="session-menu__icon-remove"
              ?disabled=${e.disabled||e.colorDisabled}
              title=${e.disabledReason??e.colorDisabledReason??z}
              @click=${e.onReset}
            >
              ${j(`sessionsView.resetAppearance`)}
            </button>`}
  </div>`}function Gm(e){let t=e.target;if(!(t instanceof HTMLButtonElement))return;let n={ArrowLeft:-1,ArrowRight:1,ArrowUp:-1,ArrowDown:1}[e.key];if(n===void 0)return;let r=e.currentTarget;if(!(r instanceof HTMLElement))return;let i=Array.from(r.querySelectorAll(`.session-menu__icon-choice:not(:disabled)`)),a=i.indexOf(t);if(a<0)return;e.preventDefault(),e.stopPropagation();let o=i[(a+n+i.length)%i.length];if(e.key===`ArrowUp`||e.key===`ArrowDown`){let e=[];for(let t of i){let n=t.getBoundingClientRect(),r=e.find(e=>Math.abs(e.top-n.top)<1),i={button:t,x:n.left+n.width/2};r?r.choices.push(i):e.push({top:n.top,choices:[i]})}e.sort((e,t)=>e.top-t.top);let r=e[(e.findIndex(e=>e.choices.some(e=>e.button===t))+n+e.length)%e.length];if(!r)return;let a=t.getBoundingClientRect(),s=a.left+a.width/2;o=r.choices.reduce((e,t)=>Math.abs(t.x-s)<Math.abs(e.x-s)?t:e).button}t.tabIndex=-1,o&&(o.tabIndex=0,o.focus())}var Km;function qm(){return(qm=e((()=>{B(),Qa(),F(),L(),Ur(),Fm(),Bm(),Km=[`🦞`,`🚀`,`🐛`,`✅`,`🔥`,`📦`,`🧪`,`📝`,`🔍`,`⚡`,`🎯`]})))()}function Jm(e){return Zm[e]??null}function Ym(e){return R`
    <wa-dropdown-item
      class=${`session-menu__item${e.details?` session-menu__item--compact-details`:``}`}
      value=${e.value}
      aria-label=${e.accessibleLabel??z}
      ?disabled=${e.disabled??!1}
      title=${e.title??z}
    >
      <span slot="icon" class="session-menu__icon" aria-hidden="true">${e.icon}</span>
      <span class="session-menu__text">${e.label}</span>
      ${e.details?R`<span class="session-menu__compact-details" aria-hidden="true"
              >${e.details}</span
            >`:z}
      <span slot="details" class="session-menu__icon session-menu__chevron" aria-hidden="true"
        >${I.chevronRight}</span
      >
    </wa-dropdown-item>
  `}function Xm(e){return R`
    <wa-dropdown-item class="session-menu__item session-menu__back" value="compact:back">
      <span slot="icon" class="session-menu__icon" aria-hidden="true">${I.arrowLeft}</span>
      <span class="session-menu__text">${j(`common.back`)}</span>
    </wa-dropdown-item>
    <div class="session-menu__separator" role="separator"></div>
    ${e}
  `}var Zm;function Qm(){return(Qm=e((()=>{B(),F(),L(),Zm={"compact:back":`root`,"compact:open-copy":`copy`,"compact:open-assign-owner":`assign-owner`,"compact:open-group":`group`,"compact:open-icon":`icon`,"compact:open-open-in":`open-in`}})))()}function $m(e,t){return{basePath:e.basePath,navigate:(n,r)=>{t?.(),e.navigate(`activity`,$r(n,e.basePath,r))}}}function eh(e,t,n){let r=e?.trim();return!r||!t?null:{href:$r(r,t.basePath,n).href,open:e=>{k(e)&&(e.preventDefault(),t.navigate(r,n))}}}function th(e,t,n){return t?R`<a class="${n} person-activity-link" href=${t.href} @click=${t.open}
        >${e}</a
      >`:R`<span class=${n}>${e}</span>`}function nh(e,t){return t?R`<a
        class="person-activity-avatar-link"
        href=${t.href}
        tabindex="-1"
        aria-hidden="true"
        @click=${t.open}
        >${e}</a
      >`:e}function rh(e,t){return t?R`<a class="person-activity-avatar-link" href=${t.href} @click=${t.open}
        >${e}</a
      >`:e}function ih(){return(ih=e((()=>{B(),ii()})))()}function ah(e){let t=R`<span
    class=${e.imageUrl?`viewer-avatar__fallback`:z}
    style=${`background: hsl(${e.fallback.colorSeed%360} 48% 42%)`}
    ><span class="viewer-avatar__initials">${e.fallback.initials}</span></span
  >`;return e.imageUrl?R`${Lf({view:e,fallbackSelector:`.viewer-avatar`})}${t}`:t}function oh(e,t,n){let r=co({identity:t,id:e.id,name:e.name,profileAvatarUrl:e.avatarUrl});return R`<span
    class="viewer-avatar viewer-avatar--session"
    aria-label=${ss(e)}
    data-viewer-id=${n?e.id:z}
    >${Rf({id:t.id,avatar:r.kind===`profile`?r.url:null})}</span
  >`}var sh,ch;function lh(){return(lh=e((()=>{B(),H(),F(),Zo(),No(),M(),Wf(),ih(),ta(),sh=class extends Sn{constructor(...e){super(...e),this.user=null,this.variant=`session`,this.markAsViewer=!0}render(){let e=this.user;if(!e)return z;let t=this.variant===`profile`?e.name??e.email??e.id:ss(e),n=Pf({identity:this.identity??e.identity,id:e.id,name:e.name,username:e.email,profileAvatarUrl:e.avatarUrl});return R`<span
      class=${Vf(`viewer-avatar viewer-avatar--${this.variant}`,n)}
      data-viewer-id=${this.markAsViewer?e.id:z}
      aria-label=${t}
    >
      ${ah(n)}
    </span>`}},w([W({attribute:!1})],sh.prototype,`user`,void 0),w([W()],sh.prototype,`variant`,void 0),w([W({attribute:!1})],sh.prototype,`identity`,void 0),w([W({type:Boolean,attribute:!1})],sh.prototype,`markAsViewer`,void 0),ch=class extends Sn{constructor(...e){super(...e),this.excludeIdentities=[],this.maxVisible=3}render(){let e=this.staticParticipants?this.staticParticipants.map(({identity:e,label:t,avatarUrl:n})=>({identity:e,id:e.id,name:t,avatarUrl:n,watchedSessions:[]})):this.staticUsers??Ao(this.presencePayload,this.selfUser,this.selfInstanceId,this.sessionKey,this.excludeIdentities);if(e.length===0)return z;let t=e.slice(0,this.maxVisible),n=e.slice(this.maxVisible),r=Math.max(e.length,this.totalCount??0)-t.length,i=n.length===r?n.map(ss).join(`
`):j(`sessionHovercard.moreParticipantsLabel`,{count:String(r)});return R`<span
      class="viewer-facepile viewer-facepile--session"
      data-viewer-count=${Math.max(e.length,this.totalCount??0)}
      aria-label=${e.map(ss).join(`, `)}
    >
      ${t.map(e=>R`<openclaw-tooltip .content=${ss(e)}>
          <span class="viewer-facepile__tooltip-anchor">
            ${rh(e.identity?.type===`agent`?oh(e,e.identity,!this.staticParticipants):R`<openclaw-viewer-avatar
                    .user=${e}
                    .identity=${e.identity}
                    .markAsViewer=${!this.staticParticipants}
                    variant="session"
                  ></openclaw-viewer-avatar>`,e.identity?.type===`profile`?eh(e.identity.id,this.personActivity,ss(e)):null)}
          </span>
        </openclaw-tooltip>`)}
      ${r>0?R`<openclaw-tooltip .content=${i}>
              <span class="viewer-avatar viewer-avatar--overflow" aria-label=${i}
                >+${r}</span
              >
            </openclaw-tooltip>`:z}
    </span>`}},w([W({attribute:!1})],ch.prototype,`presencePayload`,void 0),w([W({attribute:!1})],ch.prototype,`selfUser`,void 0),w([W({attribute:!1})],ch.prototype,`selfInstanceId`,void 0),w([W({attribute:!1})],ch.prototype,`sessionKey`,void 0),w([W({attribute:!1})],ch.prototype,`excludeIdentities`,void 0),w([W({attribute:!1})],ch.prototype,`staticParticipants`,void 0),w([W({attribute:!1})],ch.prototype,`staticUsers`,void 0),w([W({type:Number,attribute:`max-visible`})],ch.prototype,`maxVisible`,void 0),w([W({type:Number,attribute:!1})],ch.prototype,`totalCount`,void 0),w([W({attribute:!1})],ch.prototype,`personActivity`,void 0),globalThis.customElements&&(customElements.get(`openclaw-viewer-avatar`)||customElements.define(`openclaw-viewer-avatar`,sh),customElements.get(`openclaw-viewer-facepile`)||customElements.define(`openclaw-viewer-facepile`,ch))})))()}function uh(e){return e?{type:`human`,id:e.id,identity:{type:`profile`,id:e.id},label:e.name,avatarUrl:e.avatarUrl}:null}function dh(e,t,n=`created`,r,i,a){return e?.id?R`<openclaw-session-owner-chip
        .owner=${e}
        size=${t}
        attribution=${n}
        .viewingNow=${r}
        .participants=${i??[]}
        .participantCount=${a??i?.length??0}
      ></openclaw-session-owner-chip>`:z}function fh(e){let t=e.label?.trim()||e.id?.trim()||``;if(!t)return``;let n=t.replace(/@.*$/u,``).split(/[\s._-]+/u).filter(Boolean),r=e=>e?Ge(e,1):``;return(r(n[0])+r(n[1])).toUpperCase()||r(t).toUpperCase()}function ph(e){let t=0;for(let n=0;n<e.length;n+=1)t=t*31+e.charCodeAt(n)|0;return Math.abs(t)%360}function mh(e){if(e.identity?.type===`agent`){let t=co({id:e.id,identity:e.identity,name:e.label,profileAvatarUrl:e.avatarUrl});return R`<span
      class="viewer-avatar viewer-avatar--session"
      aria-label=${e.label||e.id}
    >
      ${Rf({id:e.identity.id,avatar:t.kind===`profile`?t.url:null})}
    </span>`}return R`<openclaw-viewer-avatar
    .identity=${e.identity}
    .user=${{id:e.id,name:e.label,avatarUrl:e.avatarUrl,watchedSessions:[]}}
    .markAsViewer=${!1}
    variant="session"
    aria-hidden="true"
  ></openclaw-viewer-avatar>`}var hh;function gh(){return(gh=e((()=>{B(),H(),F(),Ct(),Zo(),M(),Wf(),lh(),hh=class extends Fn{constructor(...e){super(...e),this.owner=null,this.size=`row`,this.attribution=`created`,this.participants=[],this.participantCount=0}render(){let e=this.owner;if(!e?.id)return z;let t=fh(e);if(!t)return z;let n=e.label||e.id,r=this.attribution===`archived`?`sessionsView.archivedBy`:this.attribution===`owned`?`sessionsView.ownedBy`:`sessionsView.createdBy`,i=j(r,{name:n}),a=this.viewingNow?`${i} · ${j(`sessionsView.viewingNow`)}`:i,o=co({id:e.id,identity:e.identity,name:e.label,profileAvatarUrl:e.avatarUrl}),s=this.size===`row`&&this.participantCount>0,c=R`
      <span
        class="session-owner-chip session-owner-chip--${this.size} ${this.viewingNow===!1?`session-owner-chip--away`:``} ${s?`session-owner-stack__front`:``}"
        style="--owner-hue: ${ph(e.id)}"
        role="img"
        aria-label=${a}
        title=${a}
        >${e.identity?.type===`agent`||o.kind===`profile`?mh({...e,id:e.id}):R`<span class="session-owner-chip__initials">${t}</span>`}</span
      >
    `;if(!s)return c;let l=this.participants[0],u=l?.label||l?.identity.id,d=this.participantCount===1&&u?`${a} · ${j(`sessionsView.withParticipant`,{name:u})}`:`${a} · ${j(`sessionsView.withMoreParticipants`,{count:String(this.participantCount)})}`;return R`<span
      class="session-owner-stack ${this.participantCount>1?`session-owner-stack--overflow`:``}"
      role="group"
      aria-label=${d}
    >
      <span class="session-owner-stack__back" aria-hidden="true">
        ${this.participantCount===1&&l?mh({...l,id:l.identity.id}):R`<span class="session-owner-stack__overflow"
                ><span class="session-owner-stack__count">+${this.participantCount}</span></span
              >`}
      </span>
      ${c}
    </span>`}},w([W({attribute:!1})],hh.prototype,`owner`,void 0),w([W({type:String})],hh.prototype,`size`,void 0),w([W({type:String})],hh.prototype,`attribution`,void 0),w([W({attribute:!1})],hh.prototype,`viewingNow`,void 0),w([W({attribute:!1})],hh.prototype,`participants`,void 0),w([W({type:Number})],hh.prototype,`participantCount`,void 0),customElements.get(`openclaw-session-owner-chip`)||customElements.define(`openclaw-session-owner-chip`,hh)})))()}var _h;function vh(){return(vh=e((()=>{te(),Nc(),B(),da(),S(),aa(),F(),pt(),$e(),P(),oc(),L(),Tm(),gh(),rp(),_h=class{constructor(e){this.opened=!1,this.searchGeneration=0,this.load=()=>{this.searchGeneration+=1,this.opened=!0,this.profiles.run()},this.context=new ie(e,{context:Zi,subscribe:!0});let t=new Zs(e,{getGateway:()=>this.context.value?.gateway,invalidateRequests:()=>{this.searchGeneration+=1}});this.profiles=new Ic(e,{args:()=>[t.epoch,this.opened,t.capture()?.client],task:([,e,t])=>e&&t?t.request(`users.list`,{}):Xc})}render(e,t=!1){let n=this.context.value,r=uh(n?.gateway.snapshot.selfUser),a=e.currentOwner,o=a?.identity?.id??a?.id,s=this.profiles.status===zc.COMPLETE?(this.profiles.value?.profiles??[]).filter(e=>!e.mergedInto&&e.id!==r?.id).map(e=>({type:`human`,id:e.id,identity:{type:`profile`,id:e.id},label:e.displayName?.trim()||e.githubIdentity?.login||e.emails[0]||e.id,avatarUrl:i(e.id,e.updatedAt)})):a?.type===`human`&&o&&o!==r?.id?[{...a,type:a.type,id:o}]:[];for(let e of n?.agents.state.agentsList?.agents??[]){let t=n?.agentIdentity.get(e.id);s.push({type:`agent`,id:e.id,identity:{type:`agent`,id:e.id},label:at(e,t),avatarUrl:vt(e,t)??void 0})}s.sort((e,t)=>e.type.localeCompare(t.type)||(e.label??e.id).localeCompare(t.label??t.id)||e.id.localeCompare(t.id)),r&&s.unshift(r);let c=t?z:`submenu`;return R`
      ${wm(s.map(t=>({text:[t.label,t.id,t.type,t===r?j(`sessionsView.assignToMe`):``].join(` `),render:()=>{let n=t.type===a?.type&&t.id===o;return R`<wa-dropdown-item
              slot=${c}
              class="session-menu__item"
              value=${`assign-owner:${t.type}:${encodeURIComponent(t.id)}`}
              role="menuitemradio"
              aria-checked=${String(n)}
              ${la(e=>qf(e,n))}
              ?disabled=${e.disabled||n}
              title=${e.disabledReason??z}
            >
              <span slot="icon" class="session-menu__avatar" aria-hidden="true"
                >${mh(t)}</span
              >
              <span class="session-menu__text"
                >${t===r?j(`sessionsView.assignToMe`):t.label??t.id}</span
              >
              ${n?R`<span slot="details" class="session-menu__check" aria-hidden="true"
                      >${I.check}</span
                    >`:z}
            </wa-dropdown-item>`}})),this.searchGeneration,t?void 0:`submenu`)}
      ${this.profiles.render({pending:()=>R`<wa-dropdown-item slot=${c} disabled>${j(`common.loading`)}</wa-dropdown-item>`,error:e=>R`
          <div slot=${c} class="session-menu__info" role="alert">
            ${E(e,j(`common.failed`))}
          </div>
          <wa-dropdown-item slot=${c} class="session-menu__item" value="reload-owners"
            >${j(`common.retry`)}</wa-dropdown-item
          >
        `})}
    `}}})))()}var yh,bh;function xh(){return(xh=e((()=>{te(),B(),Qa(),aa(),F(),ec(),Vt(),L(),Om(),qm(),Qm(),Bm(),vh(),yh={label:``,sessionId:null,pinned:!1,unread:!1,archived:!1,category:null,icon:null,color:null,categoryClearReturnsToGroups:!1},bh=class{constructor(e,t,n,r){this.host=e,this.readState=t,this.onAction=n,this.onClose=r,this.iconPickerMode=`grid`,this.customIconValue=``,this.loadOwners=()=>{this.readState().selectionCount===1&&this.ownerMenu.load()},this.selectIcon=(e,t)=>{e.stopPropagation(),this.runAction({kind:`set-icon`,icon:t})},this.showCustomIconEntry=e=>{e.stopPropagation(),this.iconPickerMode=`custom`,this.customIconValue=``,this.host.requestUpdate(),this.host.updateComplete.then(()=>{this.host.querySelector(`.session-menu__icon-custom-input`)?.focus()})},this.showIconGrid=e=>{e?.stopPropagation(),this.iconPickerMode=`grid`,this.customIconValue=``,this.host.requestUpdate(),this.host.updateComplete.then(()=>{let e=this.host.querySelector(`.session-menu__icon-choice--custom`);for(let t of this.host.querySelectorAll(`.session-menu__icon-choice`))t.tabIndex=t===e?0:-1;e?.focus()})},this.updateCustomIconValue=e=>{e.currentTarget instanceof HTMLTextAreaElement&&(this.customIconValue=e.currentTarget.value,this.host.requestUpdate())},this.applyCustomIcon=e=>{e?.stopPropagation();let t=Ua(this.customIconValue);t&&this.runAction({kind:`set-icon`,icon:t})},this.focusAppearanceOnOpen=e=>{let t=e.currentTarget;t instanceof HTMLElement&&e.detail.item===t&&t.getAttribute(`aria-expanded`)!==`true`&&(this.iconPickerMode=`grid`,this.customIconValue=``,this.host.requestUpdate(),this.host.updateComplete.then(()=>requestAnimationFrame(()=>{t.querySelector(`.session-menu__appearance button:not(:disabled)`)?.focus()})))},this.context=new ie(e,{context:Zi,subscribe:!0}),new Nn(e).watch(()=>this.context.value?.gateway,(e,t)=>e.subscribe(t)),this.ownerMenu=new _h(e)}get involvementAvailable(){return this.context.value?.gateway.snapshot.hello?.policy?.hasMultipleSessionSharingIdentities===!0}actionDisabled(e,t=!1){let n=this.readState();return n.disabled||t||!!n.actionDisabledReasons[e]}actionExtraDisabled(e){let t=this.readState(),{session:n}=t,r=t.selectionCount>1;switch(e){case`open-in`:return r||!t.worktreePath;case`copy-session-link`:case`copy-session-preview-link`:case`open-new-tab`:case`open-new-window`:return r||!t.navigationAllowed;case`copy-markdown`:return r||!t.copyMarkdownAllowed;case`split-right`:case`split-below`:return r||!t.splitAllowed;case`reset-appearance`:return r||this.actionDisabled(`set-icon`)||this.actionDisabled(`set-color`);case`copy-session-id`:return r||!n.sessionId;case`toggle-pin`:return r||n.pinnable===!1||n.isChild===!0||n.archived;case`toggle-involving-me`:return!this.involvementAvailable||r||n.hiddenFromInvolvingMe===void 0||!n.sessionId;case`rename`:case`set-icon`:case`set-color`:case`assign-owner`:return r;case`fork`:return r||t.forkDisabled;case`move-to-group`:case`new-group`:return n.isChild===!0;case`toggle-archived`:return n.archiving===!0||!r&&!n.archived&&!t.archiveAllowed;case`delete`:return!t.deleteAllowed;case`toggle-unread`:return!1;default:return e}}runAction(e){this.actionDisabled(e.kind,this.actionExtraDisabled(e.kind))||(e.kind!==`set-icon`&&e.kind!==`set-color`&&e.kind!==`reset-appearance`&&this.onClose(),this.onAction(e))}handleSelect(e){if(e===`reload-owners`)return this.ownerMenu.load(),!0;if(e===`copy-session-id`||e===`copy-session-link`||e===`copy-session-preview-link`||e===`copy-markdown`||e===`open-new-tab`||e===`open-new-window`||e===`split-right`||e===`split-below`||e===`reset-appearance`||e===`toggle-pin`||e===`toggle-unread`||e===`toggle-involving-me`||e===`rename`||e===`fork`||e===`new-group`||e===`toggle-archived`||e===`delete`)return this.runAction({kind:e}),!0;if(e.startsWith(`open-in:`)){let t=this.readState(),n=Rs.find(t=>t===e.slice(8));return t.worktreePath&&n&&this.runAction({kind:`open-in`,editor:n,path:t.worktreePath}),!0}if(e.startsWith(`move-to-group:`)){let t=e.slice(14);return this.runAction({kind:`move-to-group`,category:t?decodeURIComponent(t):null}),!0}let[t,n,r]=e.split(`:`);return t===`assign-owner`&&(n===`human`||n===`agent`)&&r?(this.runAction({kind:`assign-owner`,owner:{type:n,id:decodeURIComponent(r)}}),!0):!1}prepareCompactView(e){e===`icon`&&(this.iconPickerMode=`grid`,this.customIconValue=``)}focusCurrentView(){this.host.updateComplete.then(()=>{(this.host.querySelector(`.session-menu__appearance button:not(:disabled)`)??this.host.querySelector(`wa-dropdown-item:not([disabled])`))?.focus()})}handleKeydown(e){let t=e.composedPath().find(e=>e instanceof HTMLElement),n=t?.closest(`.session-menu__appearance`);if(e.key===`Tab`&&t&&n&&this.host.contains(n)){let r=Array.from(n.querySelectorAll(`button:not(:disabled):not([tabindex="-1"]), textarea:not(:disabled)`)).filter(e=>!e.closest(`[inert], [hidden], [aria-hidden="true"]`)),i=r.indexOf(t),a=i<0?void 0:r[i+(e.shiftKey?-1:1)];return a?(e.preventDefault(),e.stopPropagation(),a.focus(),!0):!1}return e.composedPath().find(e=>e instanceof HTMLTextAreaElement&&e.classList.contains(`session-menu__icon-custom-input`))?e.key===`Enter`||(e.stopPropagation(),e.key===`Escape`&&(e.preventDefault(),this.showIconGrid()),!0):!1}renderItem(e,t,n,r={}){let i=this.readState(),a=e===`toggle-archived`?Im(i):void 0;return R`<wa-dropdown-item
      slot=${r.inline===!1?`submenu`:z}
      class=${`session-menu__item${e===`delete`?` session-menu__item--destructive`:``}`}
      variant=${e===`delete`?`danger`:`neutral`}
      value=${e}
      data-shortcut=${r.shortcut??z}
      aria-keyshortcuts=${r.shortcut?.toUpperCase()??z}
      ?data-new-tab-action=${e===`open-new-tab`||e===`open-new-window`}
      ?disabled=${this.actionDisabled(e,this.actionExtraDisabled(e))}
      title=${i.actionDisabledReasons[e]??r.title??z}
    >
      <span slot="icon" class="session-menu__icon" aria-hidden="true">${n}</span>
      <span class="session-menu__text">${t}</span>
      ${r.shortcut?Em(r.shortcut,a):z}
    </wa-dropdown-item>`}renderSubmenu(e,t,n,r=!1,i){if(this.readState().compact)return Ym({value:`compact:open-${e}`,label:t,icon:n,disabled:r,title:i});let a=e===`icon`?`i`:e===`copy`?`c`:void 0;return R`<wa-dropdown-item
      class=${`session-menu__item${e===`assign-owner`?` people-menu__submenu`:``}`}
      ?disabled=${r}
      title=${i??z}
      data-shortcut=${a??z}
      aria-keyshortcuts=${a?.toUpperCase()??z}
      @submenu-opening=${e===`icon`?this.focusAppearanceOnOpen:z}
    >
      <span slot="icon" class="session-menu__icon" aria-hidden="true">${n}</span>
      <span class="session-menu__text">${t}</span>
      ${a?Em(a):z} ${this.renderSubmenuBody(e)}
    </wa-dropdown-item>`}renderPrimaryActions(){let{session:e,selectionCount:t}=this.readState(),n=t>1,r=String(t);return R`
      ${n||e.pinnable===!1||e.isChild?z:this.renderItem(`toggle-pin`,j(e.pinned?`sessionsView.unpinSession`:`sessionsView.pinSession`),e.pinned?I.pinOff:I.pin,{shortcut:`p`})}
      ${n?z:this.renderItem(`rename`,j(`sessionsView.renameSessionMenu`),I.edit,{shortcut:`r`})}
      ${this.renderItem(`toggle-unread`,j(n?e.unread?`sessionsView.markReadCount`:`sessionsView.markUnreadCount`:e.unread?`sessionsView.markRead`:`sessionsView.markUnread`,{count:r}),e.unread?I.eye:I.circle,{shortcut:`u`})}
      ${this.involvementAvailable&&!n&&e.hiddenFromInvolvingMe!==void 0?this.renderItem(`toggle-involving-me`,j(e.hiddenFromInvolvingMe?`sessionsView.showInInvolvingMe`:`sessionsView.hideFromInvolvingMe`),e.hiddenFromInvolvingMe?I.eye:I.eyeOff):z}
      ${this.renderItem(`toggle-archived`,j(e.archiving?`sessionsView.archiving`:n?e.archived?`sessionsView.restoreSessionCount`:`sessionsView.archiveSessionCount`:e.archived?`sessionsView.restoreSession`:`sessionsView.archiveSession`,{count:r}),e.archived?I.archiveRestore:I.archive,{shortcut:`a`})}
    `}renderOrganizationActions(){let e=this.readState(),t=e.selectionCount>1;return R`
      ${t?z:this.renderSubmenu(`icon`,j(`sessionsView.setIconColorMenu`),I.palette,this.actionDisabled(`set-icon`)&&this.actionDisabled(`set-color`))}
      ${this.renderGroupAction()}
      ${t?z:this.renderSubmenu(`assign-owner`,j(`sessionsView.assignTo`),I.users,this.actionDisabled(`assign-owner`),e.actionDisabledReasons[`assign-owner`])}
    `}renderTransferActions(){let e=this.readState();return e.selectionCount>1?z:R`
      ${this.renderItem(`fork`,j(`sessionsView.forkSession`),I.copy,{shortcut:`f`,title:e.forkFromLastCompleted?j(`sessionsView.forkFromLastCompleted`):void 0})}
      ${this.renderSubmenu(`copy`,j(`common.copy`),I.copy)}
      ${e.navigationAllowed||e.worktreePath||e.renderOpenInExtra?this.renderSubmenu(`open-in`,j(`sessionsView.openInEditorMenu`),I.externalLink):z}
    `}renderGroupAction(){let e=this.readState(),t=e.selectionCount>1,n=String(e.selectionCount);if(e.session.isChild===!0)return z;let r=t?j(`sessionsView.moveToGroupMenuCount`,{count:n}):j(`sessionsView.moveToGroupMenu`);return this.renderSubmenu(`group`,r,I.folder,this.actionDisabled(`move-to-group`),e.actionDisabledReasons[`move-to-group`])}renderDeleteAction(){let e=this.readState(),t=e.selectionCount>1?j(`sessionsView.deleteSessionCount`,{count:String(e.selectionCount)}):j(`sessionsView.deleteSessionMenu`);return this.renderItem(`delete`,t,I.trash,{shortcut:`d`})}renderCompactView(e){return e===`root`?z:Xm(this.renderSubmenuBody(e,!0))}renderSubmenuBody(e,t=!1){let n=this.readState();switch(e){case`copy`:return this.renderCopySubmenu(t);case`open-in`:return this.renderOpenSubmenu(t);case`icon`:return this.renderAppearancePicker(t);case`group`:return this.renderGroupSubmenu(t);case`assign-owner`:return this.ownerMenu.render({currentOwner:n.currentOwner,disabled:this.actionDisabled(`assign-owner`),disabledReason:n.actionDisabledReasons[`assign-owner`]},t);default:return e}}renderCopySubmenu(e=!1){let t=this.readState();return R`
      ${t.navigationAllowed?[[`copy-session-link`,`sessionsView.copySessionLink`],[`copy-session-preview-link`,`sessionsView.copySessionPreviewLink`]].map(([t,n])=>this.renderItem(t,j(n),I.link,{inline:e})):z}
      ${this.renderItem(`copy-markdown`,j(`sessionsView.copyMarkdown`),I.fileText,{inline:e})}
      ${this.renderItem(`copy-session-id`,j(`sessionsView.copySessionId`),I.copy,{inline:e})}
    `}renderOpenSubmenu(e=!1){let t=this.readState();return R`
      ${t.navigationAllowed?[[`open-new-tab`,`sessionsView.openNewTab`,I.externalLink],[`open-new-window`,`sessionsView.openNewWindow`,I.monitor]].map(([t,n,r])=>this.renderItem(t,j(n),r,{inline:e})):z}
      ${t.splitAllowed?[[`split-right`,`chat.splitView.splitRight`,I.columns2],[`split-below`,`sessionsView.splitBelow`,I.panelBottomOpen]].map(([t,n,r])=>this.renderItem(t,j(n),r,{inline:e})):z}
      ${t.renderOpenInExtra?.(e)??z}
      ${t.worktreePath?R`
              <div slot=${e?z:`submenu`} class="session-menu__info">
                ${j(`sessionsView.workspaceEditors`)}
              </div>
              ${Lm({inline:e,disabled:this.actionDisabled(`open-in`)})}
            `:z}
    `}renderGroupSubmenu(e=!1){let t=this.readState();return Rm({inline:e,category:t.session.category,categoryClearReturnsToGroups:t.session.categoryClearReturnsToGroups,groups:t.groups,actionDisabled:e=>this.actionDisabled(e),actionTitle:e=>t.actionDisabledReasons[e]??z})}renderAppearancePicker(e=!1){let t=this.readState();return Wm({inline:e,allowSvg:!0,mode:this.iconPickerMode,currentIcon:t.session.icon,currentColor:t.session.color,colorDisabled:this.actionDisabled(`set-color`),colorDisabledReason:t.actionDisabledReasons[`set-color`],onSelectColor:(e,t)=>{e.stopPropagation(),this.runAction({kind:`set-color`,color:t})},onReset:e=>{e.stopPropagation(),this.runAction({kind:`reset-appearance`})},customIconValue:this.customIconValue,disabled:this.actionDisabled(`set-icon`),disabledReason:t.actionDisabledReasons[`set-icon`],onSelect:this.selectIcon,onShowCustom:this.showCustomIconEntry,onBack:this.showIconGrid,onInput:this.updateCustomIconValue,onApply:this.applyCustomIcon,onGridKeydown:Gm})}}})))()}var G;function Sh(){return(Sh=e((()=>{B(),H(),Ea(),F(),M(),bm(),L(),Om(),jm(),xh(),Qm(),G=class extends Fn{constructor(...e){super(...e),this.session=yh,this.compact=!1,this.navigationAllowed=!1,this.copyMarkdownAllowed=!1,this.splitAllowed=!1,this.selectionCount=1,this.lastActive=``,this.anchor={x:0,y:0},this.trigger=null,this.disabled=!1,this.actionDisabledReasons={},this.forkDisabled=!1,this.forkFromLastCompleted=!1,this.archiveAllowed=!1,this.deleteAllowed=!1,this.cloudWorkerStopAllowed=!1,this.groups=[],this.currentOwner=null,this.work=null,this.pluginActions=[],this.onAction=()=>{},this.onClose=()=>{},this.compactView=`root`,this.managementActions=new bh(this,()=>this,e=>this.onAction(e),()=>this.onClose()),this.menuLifecycle=new ym(this,{getTrigger:()=>this.trigger,onClose:()=>this.onClose(),onKeydown:e=>{this.managementActions.handleKeydown(e)||Dm(this,e)}}),this.handleSelect=e=>{e.preventDefault();let t=e.detail.item.value;if(!t)return;let n=Jm(t);if(n){this.compactView=n,this.managementActions.prepareCompactView(n),this.managementActions.focusCurrentView();return}if(!this.managementActions.handleSelect(t)){if(t.startsWith(`plugin:`)){let e=t.slice(7),n=this.pluginActions.find(t=>t.id===e);n&&this.selectionCount===1&&!this.actionDisabled(`plugin`,n.disabled)&&this.runAction({kind:`plugin`,id:e});return}if(t===`stop-cloud-worker`){this.runAction({kind:t});return}t===`open-pr`&&this.work?.pullRequestUrl&&this.runAction({kind:`open-pr`,url:this.work.pullRequestUrl})}},this.handleAfterHide=e=>{e.currentTarget instanceof Node&&e.currentTarget.isConnected&&this.onClose()}}get worktreePath(){return this.work?.worktreePath??null}connectedCallback(){super.connectedCallback(),km(this)}runAction(e){this.actionDisabledReasons[e.kind]||(this.onClose(),this.onAction(e))}actionDisabled(e,t=!1){return this.disabled||t||!!this.actionDisabledReasons[e]}actionTitle(e){return this.actionDisabledReasons[e]??z}renderWorkItems(){return this.work?.pullRequestUrl?R`
      <wa-dropdown-item
        class="session-menu__item"
        value="open-pr"
        data-new-tab-action
        data-shortcut="g"
        aria-keyshortcuts="G"
        ?disabled=${this.disabled}
      >
        <span slot="icon" class="session-menu__icon" aria-hidden="true"
          >${I.gitPullRequest}</span
        >
        <span class="session-menu__text">${j(`sessionsView.openPullRequest`)}</span>
        ${Em(`g`)}
      </wa-dropdown-item>
    `:z}render(){let e=Math.max(8,Math.min(this.anchor.x,window.innerWidth-240-8)),t=Math.max(8,Math.min(this.anchor.y,window.innerHeight-460-8)),n=this.session,r=this.selectionCount>1,i=String(this.selectionCount),a=r?j(`chat.sidebar.sessionMenuMany`,{count:i}):j(`chat.sidebar.sessionMenu`,{session:n.label});return Ca(this.anchor,R`<wa-dropdown
        class=${`session-menu${this.compact?` session-menu--compact`:``}`}
        .open=${!0}
        placement="bottom-start"
        .distance=${0}
        aria-label=${a}
        @wa-show=${this.managementActions.loadOwners}
        @wa-select=${this.handleSelect}
        @wa-after-hide=${this.handleAfterHide}
      >
        <button
          slot="trigger"
          type="button"
          tabindex="-1"
          aria-hidden="true"
          aria-label=${a}
          style="position: fixed; left: ${e}px; top: ${t}px; width: 1px; height: 1px; opacity: 0; pointer-events: none;"
        ></button>
        ${this.compact&&this.compactView!==`root`?this.managementActions.renderCompactView(this.compactView):R`
                ${!r&&this.lastActive?R`<div class="session-menu__info">
                        ${j(`sessionsView.lastActive`,{time:this.lastActive})}
                      </div>`:z}
                ${this.managementActions.renderPrimaryActions()}
                <div class="session-menu__separator" role="separator"></div>
                ${this.managementActions.renderOrganizationActions()}
                ${r?z:this.pluginActions.map(e=>R`
                          <wa-dropdown-item
                            class="session-menu__item"
                            value=${`plugin:${e.id}`}
                            ?disabled=${this.actionDisabled(`plugin`,e.disabled)}
                            title=${this.actionTitle(`plugin`)}
                          >
                            <span slot="icon" class="session-menu__icon" aria-hidden="true"
                              >${I.plug}</span
                            >
                            <span class="session-menu__text">${e.label}</span>
                          </wa-dropdown-item>
                        `)}
                ${r?z:R`
                        <div class="session-menu__separator" role="separator"></div>
                        ${this.managementActions.renderTransferActions()} ${this.renderWorkItems()}
                      `}
                <div class="session-menu__separator" role="separator"></div>
                ${!r&&this.cloudWorkerStopAllowed?R`
                        <wa-dropdown-item
                          class="session-menu__item session-menu__item--destructive"
                          value="stop-cloud-worker"
                          variant="danger"
                          ?disabled=${this.actionDisabled(`stop-cloud-worker`)}
                          title=${this.actionTitle(`stop-cloud-worker`)}
                        >
                          <span slot="icon" class="session-menu__icon" aria-hidden="true"
                            >${I.stop}</span
                          >
                          <span class="session-menu__text"
                            >${j(`sessionsView.stopCloudWorker`)}</span
                          >
                        </wa-dropdown-item>
                      `:z}
                ${this.managementActions.renderDeleteAction()}
              `}
      </wa-dropdown>`)}},w([W({attribute:!1})],G.prototype,`session`,void 0),w([W({attribute:!1})],G.prototype,`compact`,void 0),w([W({attribute:!1})],G.prototype,`navigationAllowed`,void 0),w([W({attribute:!1})],G.prototype,`copyMarkdownAllowed`,void 0),w([W({attribute:!1})],G.prototype,`splitAllowed`,void 0),w([W({attribute:!1})],G.prototype,`selectionCount`,void 0),w([W({attribute:!1})],G.prototype,`lastActive`,void 0),w([W({attribute:!1})],G.prototype,`anchor`,void 0),w([W({attribute:!1})],G.prototype,`trigger`,void 0),w([W({attribute:!1})],G.prototype,`disabled`,void 0),w([W({attribute:!1})],G.prototype,`actionDisabledReasons`,void 0),w([W({attribute:!1})],G.prototype,`forkDisabled`,void 0),w([W({attribute:!1})],G.prototype,`forkFromLastCompleted`,void 0),w([W({attribute:!1})],G.prototype,`archiveAllowed`,void 0),w([W({attribute:!1})],G.prototype,`deleteAllowed`,void 0),w([W({attribute:!1})],G.prototype,`cloudWorkerStopAllowed`,void 0),w([W({attribute:!1})],G.prototype,`groups`,void 0),w([W({attribute:!1})],G.prototype,`currentOwner`,void 0),w([W({attribute:!1})],G.prototype,`work`,void 0),w([W({attribute:!1})],G.prototype,`pluginActions`,void 0),w([W({attribute:!1})],G.prototype,`onAction`,void 0),w([W({attribute:!1})],G.prototype,`onClose`,void 0),w([V()],G.prototype,`compactView`,void 0),customElements.get(`openclaw-session-menu`)||customElements.define(`openclaw-session-menu`,G)})))()}var Ch;function wh(){return(wh=e((()=>{B(),H(),F(),zo(),ps(),M(),L(),Wf(),Ch=class extends Sn{constructor(...e){super(...e),this.agentId=``,this.agentName=``,this.avatarUrl=null,this.avatarAuthReady=!1,this.avatarText=null,this.environment=null,this.menuOpen=!1,this.menuUnread=!1,this.switcherAvailable=!1,this.avatarLoader=new Io(this)}render(){return this.avatarLoader.withActiveRoutes(()=>this.renderContent())}renderContent(){let e=this.avatarUrl,t=!(!e?.startsWith(`/`)||this.avatarAuthReady),n=e&&!t?this.avatarLoader.resolve(e):null,r=this.switcherAvailable?j(`agentChip.switchAgent`):j(`agentChip.menuLabel`);return R`
      <div class="sidebar-agent-card ${this.menuOpen?`sidebar-agent-card--open`:``}">
        <button
          type="button"
          class="sidebar-agent-card__main"
          aria-haspopup="menu"
          aria-expanded=${String(this.menuOpen)}
          aria-label="${this.agentName} · ${r}"
          @pointermove=${e=>{this.switcherAvailable&&e.currentTarget instanceof HTMLElement&&this.onMenuPointerMove?.(e.currentTarget,e)}}
          @pointerleave=${()=>this.onMenuPointerLeave?.()}
          @pointerdown=${e=>{e.stopPropagation()}}
          @click=${e=>{e.stopPropagation(),e.currentTarget instanceof HTMLElement&&this.onToggleMenu?.(e.currentTarget)}}
        >
          <span
            class="sidebar-agent-card__avatar ${this.environment?`sidebar-agent-card__avatar--environment`:``}"
          >
            ${Rf({id:this.agentId,avatar:n,textAvatar:this.avatarText,pending:t},``,e?this.avatarLoader.imageErrorHandler(e):void 0)}
            ${this.menuUnread&&!this.menuOpen?R`<span
                    class="session-unread-dot sidebar-agent-card__menu-unread"
                    role="img"
                    aria-label=${j(`sessionsView.unread`)}
                  ></span>`:z}
          </span>
          <span class="sidebar-agent-card__text">
            <span class="sidebar-agent-card__name">
              ${ic(this.agentName,`sidebar-agent-card__name-text`,{loop:!0,delay:300,speed:35})}
              <span class="sidebar-agent-card__chevron" aria-hidden="true"
                >${I.chevronsUpDown}</span
              >
            </span>
            ${this.environment?R`<span class="sidebar-agent-card__subtitle-row">
                    <span class="control-ui-environment-pill">${this.environment.label}</span>
                  </span>`:z}
          </span>
        </button>
      </div>
    `}},w([W({attribute:!1})],Ch.prototype,`agentId`,void 0),w([W({attribute:!1})],Ch.prototype,`agentName`,void 0),w([W({attribute:!1})],Ch.prototype,`avatarUrl`,void 0),w([W({attribute:!1})],Ch.prototype,`avatarAuthReady`,void 0),w([W({attribute:!1})],Ch.prototype,`avatarText`,void 0),w([W({attribute:!1})],Ch.prototype,`environment`,void 0),w([W({attribute:!1})],Ch.prototype,`menuOpen`,void 0),w([W({attribute:!1})],Ch.prototype,`menuUnread`,void 0),w([W({attribute:!1})],Ch.prototype,`switcherAvailable`,void 0),w([W({attribute:!1})],Ch.prototype,`onToggleMenu`,void 0),w([W({attribute:!1})],Ch.prototype,`onMenuPointerMove`,void 0),w([W({attribute:!1})],Ch.prototype,`onMenuPointerLeave`,void 0),customElements.get(`openclaw-sidebar-agent-card`)||customElements.define(`openclaw-sidebar-agent-card`,Ch)})))()}function Th(e){return e.state.phase===`hidden`?null:{type:`scopeUpgrade`,category:`system`,dismissal:ui(e),requiresAction:!0,severity:e.state.phase===`error`||e.state.phase===`rejected`?`error`:`warning`,state:e.state}}function Eh(e){return e.visible?{type:`update`,category:`system`,dismissal:e.canDismiss&&!e.forced?e.dismissal:null,requiresAction:e.requiresAction,severity:e.severity}:null}function Dh(e){let t=e.approvals.map(e=>({type:`approval`,approval:e,category:`approvals`,dismissal:null,requiresAction:!0,severity:`warning`})),n=e.attention.filter(e=>e.severity===`error`),r=e.attention.filter(e=>e.severity===`warning`),i=e.mentions.toSorted((e,t)=>t.createdAt-e.createdAt||e.id.localeCompare(t.id)).map(e=>({type:`mention`,mention:e,category:`mentions`,dismissal:null,requiresAction:!0,severity:`neutral`}));return[...t,...e.outbox??[],...e.update?.severity===`error`?[e.update]:[],...e.scopeUpgrade?[e.scopeUpgrade]:[],...n,...e.update?.severity===`warning`?[e.update]:[],...r,...i]}function Oh(e,t){return t===`all`||e.category===t}function kh(e){let t=e.filter(e=>e.requiresAction);return{all:t.length,approvals:t.filter(e=>e.category===`approvals`).length,mentions:t.filter(e=>e.category===`mentions`).length,automations:t.filter(e=>e.category===`automations`).length,system:t.filter(e=>e.category===`system`).length}}function Ah(){return(Ah=e((()=>{qr()})))()}function jh(e,t={}){let n={phase:`unavailable`,items:[],dismissing:[],error:null},r=null,i=!1,a=new Set,o=e=>{n={...n,...e};for(let e of a)e()},s=t=>!i&&r===t&&ao(e.snapshot,`mentions.list`,`operator.read`)&&e.snapshot.client===t.client&&e.snapshot.hello===t.hello&&e.connectionRevision===t.connectionRevision&&e.snapshot.selfUser?.identity?.id===t.profileId,c=async(e,t,n)=>{if(s(e))try{let r=await e.client.request(t,n);if(!s(e)||r.gatewayInstanceId!==e.gatewayInstanceId||e.revision!==null&&r.revision<e.revision||e.requiredRevision!==null&&r.revision<e.requiredRevision)return;e.revision=r.revision,o({phase:`ready`,items:r.items,error:null})}catch(t){if(!s(e))return;let n=t instanceof Xn&&(t.gatewayCode===`FORBIDDEN`||ki(t)===ye.AUTHENTICATED_PROFILE_UNAVAILABLE);n&&(r=null),o({phase:`error`,error:E(t),...n?{items:[],dismissing:[]}:{}})}},l=e=>s(e)?(e.refreshRequested=!0,e.refreshPromise||=Promise.resolve().then(async()=>{try{for(;s(e)&&e.refreshRequested;)e.refreshRequested=!1,o({phase:`loading`,error:null}),await c(e,`mentions.list`,{})}finally{e.refreshPromise=null,s(e)&&e.refreshRequested&&await l(e)}}),e.refreshPromise):Promise.resolve(),u=e=>{let n=()=>s(e)?e.refreshPromise?e.refreshPromise:e.revision!==null&&(e.requiredRevision===null||e.revision>=e.requiredRevision)?(e.refreshRequested=!1,Promise.resolve()):l(e):Promise.resolve();return t.connectionBootstrap?.run(e,n,{background:!0})??n()},d=()=>{let t=e.snapshot,n=t.selfUser?.identity?.id,a=t.hello?.server?.bootId;if(r&&s(r))return;if(i||t.phase!==`connected`||!t.client||!t.hello||!n||!a||!ao(t,`mentions.list`,`operator.read`)){r=null,o({phase:`unavailable`,items:[],dismissing:[],error:null});return}let c={client:t.client,hello:t.hello,connectionRevision:e.connectionRevision,profileId:n,gatewayInstanceId:a,revision:null,requiredRevision:null,dismissing:new Set,refreshRequested:!1,refreshPromise:null};r=c,o({phase:`loading`,items:[],dismissing:[],error:null}),s(c)&&u(c)},f=e.subscribeEvents(e=>{let t=r;if(e.event!==`mentions.changed`||!t||!s(t))return;let n=g(e.payload)?e.payload:void 0;n?.gatewayInstanceId!==t.gatewayInstanceId||typeof n.revision!=`number`||!Number.isSafeInteger(n.revision)||n.revision<0||t.revision!==null&&n.revision<=t.revision||(t.requiredRevision=Math.max(t.requiredRevision??0,n.revision),t.refreshRequested=!0,u(t))}),p=e.subscribe(d);return d(),{get snapshot(){return n},refresh:()=>(r||d(),r?l(r):Promise.resolve()),async dismiss(t){let i=r;if(!i||!s(i)||!ao(e.snapshot,`mentions.dismiss`,`operator.read`))return;let a=new Set(n.items.map(e=>e.id)),l=[...new Set(t)].filter(e=>a.has(e)&&!i.dismissing.has(e));if(l.length){for(let e of l)i.dismissing.add(e);o({dismissing:[...i.dismissing],error:null});try{await c(i,`mentions.dismiss`,{ids:l})}finally{for(let e of l)i.dismissing.delete(e);s(i)&&o({dismissing:[...i.dismissing]})}}},subscribe(e){return a.add(e),()=>a.delete(e)},dispose(){i=!0,r=null,p(),f(),a.clear()}}}function Mh(){return(Mh=e((()=>{Oe(),li(),P(),so()})))()}function Nh(e,t){return t!==!1&&e.enabled&&!qs(e)&&e.state?.nextRunAtMs!=null?e.state.nextRunAtMs+Ih:1/0}function Ph(e,t){return Rh[e.kind]-Rh[t.kind]}function Fh(e){let t=[],n=(e,t)=>({...e,type:`attention`,category:t,dismissal:{kind:e.kind,signature:e.signature},requiresAction:!0});for(let r of[`cronFailed`,`cronOverdue`]){let i=r===`cronFailed`,a=e=>(i?e.state?.lastRunAtMs:e.state?.nextRunAtMs)??e.updatedAtMs,o=e.cronJobs.filter(t=>i?tc(t):e.now>Nh(t,e.cronSchedulerEnabled)).toSorted((e,t)=>a(t)-a(e));for(let s of o){let o=ft(Math.max(0,e.now-a(s))),c=e.cronOwnerByJobId?.get(s.id);t.push(n({kind:r,severity:i?`error`:`warning`,icon:`clock`,label:s.name?.trim()||s.id,detail:j(i?`attention.automationFailed`:`attention.automationOverdue`,{time:o}),meta:{...c?{context:c}:{},status:j(i?`attention.failed`:`attention.overdue`),time:o},action:{kind:`navigate`,routeId:`cron`},signature:i?s.id:`${s.id}@${s.state?.nextRunAtMs}`},`automations`))}}let r=xc(e.modelAuthStatus?.providers??[]).filter(pc).filter(e=>e.status===`expired`||e.status===`missing`);for(let i of r){let r=e.modelAuthAgentId?`agent:${e.modelAuthAgentId}\n${i.provider}`:i.provider,a=`${i.displayName}: ${i.status}`,o=i.profiles.find(e=>e.status===`expired`||e.status===`missing`)?.profileId??e.modelAuthAgentId?.trim(),s=ft(Math.max(0,e.now-(e.modelAuthStatus?.ts??e.now)),{suffix:!1}),c=o?j(`attention.modelAuthExpiredWithScope`,{scope:o,time:s}):j(`attention.modelAuthExpiredState`,{time:s}),l=j(`attention.modelAuthExpired`,{providers:i.displayName});t.push(n({kind:`modelAuthExpired`,severity:`error`,icon:`plug`,label:i.displayName,detail:c,meta:{...o?{context:o}:{},status:j(`attention.authExpired`),time:s},inlineAction:{label:j(`attention.reconnect`),routeId:`model-providers`},signature:r,action:{kind:`askCustodian`,alert:{id:`modelAuthExpired:${r}`,title:l,facts:[a],question:Ve(j(`attention.alerts.modelAuthExpiredQuestion`,{facts:a}),Lh),action:{label:j(`routeTitles.modelProviders`),target:{kind:`navigate`,routeId:`model-providers`}}}}},`system`))}return t}var Ih,Lh,Rh;function zh(){return(zh=e((()=>{F(),js(),_t(),_s(),dc(),Ih=3e5,Lh=1e3,Rh={modelAuthExpired:0,cronFailed:1,cronOverdue:2}})))()}function Bh(e,t,n=Date.now()){return!!(e&&(e.status===`running`||!t&&e.finishedAtMs!==null&&n-e.finishedAtMs<864e5))}function Vh(e){let t=e.overlays.snapshot,n=t.updateSchedule?.campaign,r=t.updateRun,i=Bh(r,t.updateRunAcknowledged),a=r?null:t.updateStatusBanner,o=t.updateRunning||t.updateReconciliationPending||n?.state===`applying`,s=ao(e.gateway.snapshot,`update.run`,`operator.admin`),c=ao(e.gateway.snapshot,`update.status`,`operator.admin`),l=n&&!t.updateCampaignStatusHydrated&&c,u=Ei(t.updateAvailable,t.updateSchedule,o),d=!!(i||t.updateReconciliationPending||a||(l?t.updateRunning:u));return{actionable:u,busy:o,canUpdate:s,dismissal:i&&r?.status!==`running`?{kind:`updateAvailable`,signature:JSON.stringify([`run`,r?.runId])}:Ai({gatewayBootId:e.gateway.snapshot.hello?.server?.bootId,updateAvailable:t.updateAvailable,updateSchedule:t.updateSchedule}),forced:t.updateRunning||t.updateReconciliationPending||n?.state===`applying`||Yr(a?.tone),present:d}}function Hh(){return(Hh=e((()=>{Fi(),so(),qr()})))()}var Uh;function Wh(){return(Wh=e((()=>{Mh(),pt(),ks(),Ko(),nc(),jn(),_s(),N(),qr(),Ah(),zh(),Hh(),n(),Uh=class{constructor(e,t){this.sources=e,this.onChange=t,this.cronJobs=[],this.cronSchedulerEnabled=null,this.modelAuthStatus=null,this.modelAuthAgentId=null,this.loadedOwner=null,this.loadedClient=this.sources.gateway.snapshot.client,this.loadedAgentScope={...this.sources.agentSelection.state},this.dismissalKey=null,this.dismissed={},this.reviewedOutbox=new Set,this.loadGeneration=0,this.cronRefresh=null,this.cronRefreshNeeded=!1,this.modelAuthRefresh=null,this.outboxRuntime=null,this.disposed=!1,this.refreshDeferred=()=>{this.scheduleHealthRefresh(),document.visibilityState===`visible`&&(this.onChange(),this.cronRefreshNeeded&&this.load(!1))},this.syncDismissalsFromStorage=e=>{this.dismissalKey&&(e.key===null||e.key===this.dismissalKey)&&this.syncDismissals()},this.mentions=jh(e.gateway,{connectionBootstrap:e.connectionBootstrap}),this.loadedClient=null,this.stopSubscriptions=[e.gateway.subscribe(()=>this.synchronizeGateway()),e.gateway.subscribeEvents(e=>{e.event===`cron`?this.load(!1):e.event===`config.changed`?this.load():zt(e)&&this.load(!0,!1)}),e.agentSelection.subscribe(()=>this.synchronizeGateway()),e.agents.subscribe(t),e.overlays.subscribe(t),this.mentions.subscribe(t),vs(t)],T(()=>import(`./chat-outbox-owner-DVzfxli9.js`).then(e=>{this.disposed||(this.outboxRuntime=e,this.buildEntries().some(e=>e.type===`outbox`)&&this.onChange())}),__vite__mapDeps([11,1,2,4,3,5,6,7,10,8,9]),import.meta.url).catch(()=>{}),document.addEventListener(`visibilitychange`,this.refreshDeferred),globalThis.addEventListener(`storage`,this.syncDismissalsFromStorage),this.synchronizeGateway()}get entries(){return this.buildEntries().filter(e=>!e.dismissal||!Kr(this.dismissed,e.dismissal)&&!(e.dismissal.kind===`outbox`&&this.reviewedOutbox.has(e.dismissal.signature)))}owner(){return{connectionRevision:this.sources.gateway.connectionRevision,dismissalKey:Ki(this.sources.gateway)}}ownerEquals(e,t){return e.connectionRevision===t.connectionRevision&&e.dismissalKey===t.dismissalKey}clearHealth(){this.cronJobs=[],this.cronSchedulerEnabled=null,this.cronRetryAt=void 0,this.modelAuthStatus=null,this.modelAuthAgentId=null,this.modelAuthRefreshAt=void 0,this.scheduleHealthRefresh()}scheduleHealthRefresh(){if(globalThis.clearTimeout(this.healthRefreshTimer),this.healthRefreshTimer=void 0,this.disposed||this.sources.gateway.snapshot.phase!==`connected`||document.visibilityState===`hidden`)return;let e=Date.now(),t=this.modelAuthRefreshAt!==void 0&&this.modelAuthRefreshAt<=e,n=this.cronRetryAt!==void 0&&this.cronRetryAt<=e;if(t||n){this.load(t,n);return}let r=Math.min(this.modelAuthRefreshAt??1/0,this.cronRetryAt??1/0);for(let t of this.cronJobs){let n=Math.floor(Nh(t,this.cronSchedulerEnabled))+1;n>e&&(r=Math.min(r,n))}Number.isFinite(r)&&(this.healthRefreshTimer=globalThis.setTimeout(()=>{this.onChange(),this.scheduleHealthRefresh()},Math.min(2147483647,r-e)))}cronOwnerByJobId(){let e=this.sources.agentSelection.state,t=this.sources.agents.state.agentsList;if(e.scopeId!==null||!t)return;let n=new Map(t.agents.map(e=>[b(e.id),Qe(e)])),r=b(t.defaultId);return new Map(this.cronJobs.map(e=>{let t=b(e.agentId??r);return[e.id,n.get(t)??t]}))}buildEntries(){let e=this.sources.gateway.snapshot,t=this.outboxRuntime?.listChatOutboxAttention({client:e.client,connected:e.phase===`connected`,settings:{gatewayUrl:this.sources.gateway.connection.gatewayUrl},assistantAgentId:e.assistantAgentId,agentsList:this.sources.agents.state.agentsList,hello:e.hello}).map(t=>Object.assign(t,{type:`outbox`,category:`system`,dismissal:{kind:`outbox`,signature:JSON.stringify([e.client?.recoveryScope,t.agentId,t.sessionKey,t.id,t.unconfirmed,t.command])},requiresAction:!0,severity:t.unconfirmed?`warning`:`error`}))??[];if(e.phase!==`connected`)return t;let n=this.sources.overlays.snapshot,r=Vh(this.sources),i=Eh({canDismiss:r.canUpdate,dismissal:r.dismissal,forced:r.forced,requiresAction:r.forced||r.canUpdate&&r.actionable,severity:n.updateStatusBanner?.tone===`danger`?`error`:`warning`,visible:r.present}),a=Th({scopes:e.hello?.auth?.scopes,state:this.sources.scopeUpgrade.state}),o=Fh({cronJobs:this.cronJobs,cronSchedulerEnabled:this.cronSchedulerEnabled,cronOwnerByJobId:this.cronOwnerByJobId(),modelAuthStatus:this.modelAuthStatus,modelAuthAgentId:this.modelAuthAgentId,now:Date.now()}).toSorted(Ph);return Dh({approvals:n.approvalQueue,attention:o,outbox:t,mentions:this.mentions.snapshot.items,scopeUpgrade:a,update:i})}reconcileDismissals(e){this.dismissalKey&&(this.dismissed=Yn({active:this.buildEntries().flatMap(e=>e.dismissal?[e.dismissal]:[]),key:this.dismissalKey,scope:e}))}load(e=!0,t=!0){let n=this.sources.gateway.snapshot,r=n.client;if(n.phase!==`connected`||!r)return;let i=this.owner(),a={...this.sources.agentSelection.state},o=this.loadGeneration;this.loadedOwner=i,this.loadedClient=r,this.loadedAgentScope=a;let s=()=>o===this.loadGeneration&&this.sources.gateway.snapshot.phase===`connected`&&this.sources.gateway.snapshot.client===r&&this.ownerEquals(i,this.owner())&&this.sources.agentSelection.state.selectedId===a.selectedId&&this.sources.agentSelection.state.scopeId===a.scopeId,c=e=>{s()&&(this.reconcileDismissals(e),this.scheduleHealthRefresh(),this.onChange())};if(t&&this.cronRefresh?.generation===o&&(this.cronRefresh.requested=!0),t&&(this.cronRetryAt=void 0,this.cronRefreshNeeded=document.visibilityState===`hidden`),t&&!this.cronRefreshNeeded&&this.cronRefresh?.generation!==o){let e={generation:o,requested:!0};this.cronRefresh=e;let t=()=>s()&&document.visibilityState!==`hidden`,n=async()=>{try{for(;e.requested&&s();){if(!t()){this.cronRefreshNeeded=!0;break}e.requested=!1;let n=wo({client:r,connected:!0});for(n.canRefresh=t,n.cronAgentId=a.scopeId,await Promise.all([Po(n),lo(n)]);t()&&n.cronJobsHasMore&&!n.cronJobsError&&!e.requested;)await Po(n,{append:!0});if(s()){let r=!!(n.cronJobsError||n.cronError);this.cronRefreshNeeded||=r,this.cronRetryAt=r?Date.now()+6e4:void 0,!n.cronJobsError&&!n.cronJobsHasMore&&(this.cronJobs=n.cronJobs.map(e=>({id:e.id,name:e.name,agentId:e.agentId,enabled:e.enabled,updatedAtMs:e.updatedAtMs,state:{nextRunAtMs:e.nextRunAtMs??void 0,lastRunAtMs:e.lastRunAtMs??void 0,lastRunStatus:e.lastRunStatus??void 0,runningAtMs:e.runningAtMs,autoDisabled:e.autoDisabled}}))),n.cronError||(this.cronSchedulerEnabled=n.cronStatus?.enabled??null),c({cronInventoryComplete:a.scopeId===null&&!n.cronJobsHasMore&&!e.requested&&!n.cronJobsError&&!n.cronError,modelAuthAgentId:null}),n.cronJobsHasMore&&!t()&&(this.cronRefreshNeeded=!0)}}}finally{this.cronRefresh===e&&(this.cronRefresh=null)}};this.sources.connectionBootstrap?.run(e,n,{background:!0})??n()}if((e||a.selectedId!==this.modelAuthAgentId)&&a.selectedId){if(this.modelAuthRefreshAt=void 0,this.modelAuthRefresh?.generation===o)this.modelAuthRefresh.requested||=e;else{let e={generation:o,requested:!0},t=a.selectedId;this.modelAuthRefresh=e,(async()=>{try{for(;e.requested&&s();){e.requested=!1;let n=await Ts(r,{agentId:t}).catch(()=>null);s()&&(this.modelAuthStatus=n,this.modelAuthAgentId=t,this.modelAuthRefreshAt=n?_c(n):void 0,c({cronInventoryComplete:!1,modelAuthAgentId:t}))}}finally{this.modelAuthRefresh===e&&(this.modelAuthRefresh=null)}})()}}else a.selectedId||(this.modelAuthStatus=null,this.modelAuthAgentId=null);this.scheduleHealthRefresh()}synchronizeGateway(){let e=this.sources.gateway.snapshot,t=Ki(this.sources.gateway);if(t!==this.dismissalKey&&(this.dismissalKey=t,this.dismissed=Or(t)),e.phase!==`connected`||!e.client){this.loadGeneration+=1,this.loadedOwner=null,this.loadedClient=null,this.clearHealth(),this.onChange();return}let n=this.owner(),r=this.sources.agentSelection.state,i=this.loadedOwner!==null&&!this.ownerEquals(n,this.loadedOwner);if(i&&(this.clearHealth(),this.onChange()),!i&&e.client===this.loadedClient&&r.selectedId===this.loadedAgentScope.selectedId&&r.scopeId===this.loadedAgentScope.scopeId)return;let a=!1;r.selectedId!==this.loadedAgentScope.selectedId&&(this.modelAuthStatus=null,this.modelAuthAgentId=null,a=!0),r.scopeId!==this.loadedAgentScope.scopeId&&(this.cronJobs=[],a=!0),a&&this.onChange(),this.loadGeneration+=1,this.modelAuthRefreshAt=void 0,this.cronRetryAt=void 0,this.scheduleHealthRefresh(),this.load()}syncDismissals(){this.synchronizeGateway(),this.dismissed=Or(this.dismissalKey),this.onChange()}dismiss(e){let t=this.sources.overlays.snapshot.updateRun;if(e.kind===`outbox`&&(this.reviewedOutbox.add(e.signature),this.onChange()),e.kind===`updateAvailable`&&t&&t.status!==`running`&&e.signature===JSON.stringify([`run`,t.runId])){this.sources.overlays.acknowledgeUpdateRun();return}this.dismissalKey&&(this.dismissed=fr(this.dismissalKey,e),this.onChange())}dispose(){this.disposed=!0,this.loadGeneration+=1,this.modelAuthRefreshAt=void 0,this.scheduleHealthRefresh();for(let e of this.stopSubscriptions)e();this.mentions.dispose(),document.removeEventListener(`visibilitychange`,this.refreshDeferred),globalThis.removeEventListener(`storage`,this.syncDismissalsFromStorage)}}})))()}var Gh;function Kh(){return(Kh=e((()=>{r(),B(),H(),aa(),F(),js(),so(),M(),Vt(),L(),Zn(),Ah(),Wh(),ta(),n(),dc(),Gh=class extends Fn{constructor(...e){super(...e),this.panelOpen=!1,this.panelPosition={left:8,anchor:`bottom`,bottom:8},this.selectedTab=`all`,this.overflowAbove=!1,this.overflowBelow=!1,this.panelTrigger=null,this.mentions=null,this.panelRenderer=null,this.panelLoad=et(()=>T(()=>import(`./sidebar-attention-panel.runtime-De01Jo2_.js`),__vite__mapDeps([12,1,2,3,4,5,6,7,8,9,10]),import.meta.url)),this.panelGeneration=0,this.subscriptions=new Nn(this).watch(()=>this.context?.sidebarAttention,(e,t)=>e.subscribe(t)).watch(()=>this.context?.sessions,(e,t)=>e.subscribe(t)).watch(()=>this.context?.agents,(e,t)=>e.subscribe(t)).watch(()=>this.context?.agentIdentity,(e,t)=>e.subscribe(t)),this.handleOutsideInteraction=e=>{(e instanceof KeyboardEvent?e.key===`Escape`&&!this.panelOpen&&!e.defaultPrevented:!e.composedPath().includes(this))&&(e instanceof KeyboardEvent&&this.panelTrigger&&(e.preventDefault(),e.stopPropagation()),this.closePanel(!1))},this.preloadPanel=()=>{this.panelLoad.load().catch(()=>void 0)},this.syncOverflowCue=()=>{let e=this.querySelector(`.sidebar-issues-panel__list`);this.overflowAbove=!!(e&&e.scrollTop>2),this.overflowBelow=!!(e&&e.scrollHeight-e.scrollTop-e.clientHeight>2)},this.handlePanelKeydown=e=>{if(e.key===`Escape`){e.preventDefault(),this.closePanel(!0);return}if(e.key!==`Tab`)return;let t=e.currentTarget;if(!(t instanceof HTMLElement))return;let n=Array.from(t.querySelectorAll(`summary, button, a[href], [tabindex]:not([tabindex='-1'])`)).filter(e=>{let t=e.closest(`details:not([open])`),n=e.tagName===`SUMMARY`||!!e.parentElement?.closest(`summary`);return!e.hasAttribute(`disabled`)&&!e.closest(`[hidden]`)&&(!t||n)}),r=n[0],i=n.at(-1);e.shiftKey&&document.activeElement===r?(e.preventDefault(),i?.focus()):!e.shiftKey&&document.activeElement===i&&(e.preventDefault(),r?.focus())}}connectedCallback(){super.connectedCallback(),this.mentions=this.context?.sidebarAttention.activate(Uh)??null,this.preloadPanel(),document.addEventListener(`pointerdown`,this.handleOutsideInteraction,!0),document.addEventListener(`keydown`,this.handleOutsideInteraction,!0)}disconnectedCallback(){document.removeEventListener(`pointerdown`,this.handleOutsideInteraction,!0),document.removeEventListener(`keydown`,this.handleOutsideInteraction,!0),this.panelLoad.dispose(),this.closePanel(!1),this.subscriptions.clear(),super.disconnectedCallback()}willUpdate(e){e.has(`activeRouteId`)&&e.get(`activeRouteId`)!==void 0&&this.closePanel(!1)}updated(e){super.updated(e),this.panelOpen&&this.syncOverflowCue()}async openPanel(e){let t=++this.panelGeneration;this.panelTrigger=e;let n=await this.panelLoad.load();if(!this.isConnected||t!==this.panelGeneration)return;this.context?.scopeUpgrade.activate(n.ScopeUpgradeController);let r=e.getBoundingClientRect(),i=Math.min(390,globalThis.innerWidth-16),a=r.left+r.width/2-i/2,o=Math.max(8,Math.min(a,globalThis.innerWidth-i-8));this.panelRenderer=n.renderSidebarAttentionPanel,this.panelPosition=r.top<globalThis.innerHeight/2?{left:o,anchor:`top`,top:Math.max(8,r.bottom+8)}:{left:o,anchor:`bottom`,bottom:Math.max(8,globalThis.innerHeight-r.top+8)},this.selectedTab=`all`,this.panelOpen=!0,await this.updateComplete,t===this.panelGeneration&&this.querySelector(`.sidebar-issues-panel__list`)?.focus()}closePanel(e){let t=++this.panelGeneration,n=e&&this.panelOpen?this.panelTrigger:null;this.panelOpen=!1,this.overflowAbove=!1,this.overflowBelow=!1,this.panelTrigger=null,n&&this.updateComplete.then(()=>{t===this.panelGeneration&&n.focus()})}dismissPanel(){let e=this.panelOpen;return this.closePanel(!1),e}selectTab(e){this.selectedTab=e,this.updateComplete.then(()=>{if(!this.panelOpen||this.selectedTab!==e)return;let t=this.querySelector(`.sidebar-issues-panel__list`);t&&(t.scrollTop=0),this.syncOverflowCue()})}async open(e){if(this.closePanel(!1),e.action.kind===`navigate`){this.onNavigate?.(e.action.routeId);return}let{custodianAlertStore:t}=await T(async()=>{let{custodianAlertStore:e}=await import(`./custodian-alert-store-CZIGRvI8.js`);return{custodianAlertStore:e}},__vite__mapDeps([13,14]),import.meta.url);t.present(e.action.alert);let n=this.context?.gateway.snapshot;ao(n,`openclaw.chat`,`operator.admin`)?window.dispatchEvent(new CustomEvent(Wr,{detail:{open:!0}})):(this.onNavigate??(e=>this.context?.navigate(e)))(`custodian`)}async decideApproval(e,t,n){let r=this.context;if(!r)return;let i=e.currentTarget;if(!(i instanceof HTMLElement))return;let a=Array.from(this.querySelectorAll(`[data-issue-row-focus]`)),o=i.closest(`[data-approval-id]`)?.querySelector(`[data-issue-row-focus]`)??null,s=o?a.indexOf(o):0,c=this.panelGeneration;if(await r.overlays.decideApproval(n,t),await this.updateComplete,c!==this.panelGeneration||i.isConnected)return;let l=Array.from(this.querySelectorAll(`[data-issue-row-focus]`));l[Math.min(Math.max(s,0),l.length-1)]?.focus()}render(){if(!this.context)return z;let e=[...this.context.sidebarAttention.entries??[]];if(this.context.gateway.snapshot.phase!==`connected`&&e.length===0)return z;let t=kh(e).all,n=j(t===1?`attention.issueCount`:`attention.issueCountPlural`,{count:String(t)});return R`
      <span class="sr-only" role="status" aria-live="polite">${n}</span>
      <button
        type="button"
        class="sidebar-issues-button"
        aria-expanded=${String(this.panelOpen)}
        aria-haspopup="dialog"
        aria-controls="sidebar-issues-panel"
        aria-label=${n}
        @pointerenter=${this.preloadPanel}
        @focus=${this.preloadPanel}
        @pointerdown=${this.preloadPanel}
        @click=${e=>{let t=e.currentTarget;t instanceof HTMLElement&&(this.panelOpen?this.closePanel(!0):this.openPanel(t))}}
      >
        <span class="sidebar-issues-button__icon" aria-hidden="true">${I.inbox}</span>
        ${t>0?R`<span class="sidebar-issues-button__count" aria-hidden="true"
                >${t>9?`9+`:t}</span
              >`:z}
      </button>
      ${this.panelOpen&&this.panelRenderer&&this.mentions?this.panelRenderer({context:this.context,mentions:this.mentions,entries:e,onApprovalDecision:(e,t,n)=>void this.decideApproval(e,t,n),onClose:e=>this.closePanel(e),onDismiss:e=>this.context?.sidebarAttention.dismiss(e),onKeydown:this.handlePanelKeydown,onNavigate:(e,t)=>{this.closePanel(!1),(this.onNavigate??this.context?.navigate)?.(e,t)},onOpen:e=>void this.open(e),onScroll:this.syncOverflowCue,onSelectTab:e=>this.selectTab(e),overflowAbove:this.overflowAbove,overflowBelow:this.overflowBelow,panelPosition:this.panelPosition,selectedTab:this.selectedTab,watchUpdateProgress:this.watchUpdateProgress}):z}
    `}},w([Pe({context:Zi,subscribe:!0})],Gh.prototype,`context`,void 0),w([V()],Gh.prototype,`panelOpen`,void 0),w([V()],Gh.prototype,`panelPosition`,void 0),w([V()],Gh.prototype,`selectedTab`,void 0),w([V()],Gh.prototype,`overflowAbove`,void 0),w([V()],Gh.prototype,`overflowBelow`,void 0),w([W({attribute:!1})],Gh.prototype,`activeRouteId`,void 0),w([W({attribute:!1})],Gh.prototype,`onNavigate`,void 0),w([W({attribute:!1})],Gh.prototype,`watchUpdateProgress`,void 0),customElements.get(`openclaw-sidebar-attention`)||customElements.define(`openclaw-sidebar-attention`,Gh)})))()}var qh;function Jh(){return(Jh=e((()=>{B(),H(),F(),M(),L(),ta(),qh=class extends Sn{constructor(...e){super(...e),this.mode=`system`,this.menuItem=!1,this.handleModeChange=e=>{let t=this.mode===`system`?`light`:this.mode===`light`?`dark`:`system`;this.dispatchEvent(new CustomEvent(`theme-change`,{detail:{mode:t,element:e.currentTarget},bubbles:!0,composed:!0}))}}render(){let e=this.mode===`system`?`common.system`:this.mode===`light`?`common.light`:`common.dark`,t=j(e),n=j(`common.colorModeOption`,{mode:t});return R`
      <openclaw-tooltip .content=${n}>
        <button
          type="button"
          class="theme-mode-toggle"
          role=${this.menuItem?`menuitem`:z}
          aria-label=${n}
          @click=${this.handleModeChange}
        >
          ${this.mode===`system`?I.monitor:this.mode===`light`?I.sun:I.moon}
        </button>
      </openclaw-tooltip>
    `}},w([W({attribute:!1})],qh.prototype,`mode`,void 0),w([W({attribute:!1})],qh.prototype,`menuItem`,void 0),customElements.get(`openclaw-theme-mode-toggle`)||customElements.define(`openclaw-theme-mode-toggle`,qh)})))()}function Yh(e){let t=`online`,n=e.sidebarAgentsMode===`roster`,r=n?!e.teamOnlineExpanded:e.collapsedSessionSections.has(t),i=j(`presence.rosterTitle`),a=os(e.sessionData.presencePayload);if(a.length===0)return z;let o=e.sessionData.ownerCounts.counts,s=e=>o&&e.identity?.type===`profile`?o.get(e.identity.id)??{open:0,running:0}:null,c=Date.now(),l={active:0,idle:1,unknown:2},u=e=>Number((s(e)?.running??0)>0),d=a.toSorted((e,t)=>l[ho(e,c)]-l[ho(t,c)]||u(t)-u(e)||ss(e).localeCompare(ss(t),void 0,{sensitivity:`base`})),f=$m({basePath:e.basePath,navigate:(t,n)=>e.onNavigate?.(t,n)},()=>e.dismissTransientMenus());return R`
    <section class="sidebar-online" aria-label=${i} data-session-section=${t}>
      ${bp({sectionId:t,draggable:!1,onStartDrag:()=>void 0,onFinishDrag:()=>void 0,content:R`
          <button
            type="button"
            class="sidebar-session-group-toggle"
            aria-expanded=${String(!r)}
            aria-label=${i}
            @click=${()=>{n?e.teamOnlineExpanded=r:e.toggleSection(t)}}
          >
            <span class="sidebar-session-group-toggle__lead" aria-hidden="true">
              <span class="sidebar-session-group-toggle__icon"
                >${r?I.chevronRight:I.chevronDown}</span
              >
            </span>
            ${ic(i,`sidebar-recent-sessions__label-text`)}
            ${r?R`<span class="sidebar-online__facepile">
                    <openclaw-viewer-facepile
                      .staticUsers=${a}
                      .maxVisible=${2}
                    ></openclaw-viewer-facepile>
                  </span>`:z}
          </button>
        `})}
      ${r?z:R`<div class="sidebar-online__list">
                ${va(d,ml,e=>{let t=ho(e),n=s(e),r=n?j(`presence.sessions.counts`,{open:String(n.open),running:String(n.running)}):j(`presence.sessions.unavailable`),i=eh(e.identity?.id,f,ss(e)),a=i?Ma`a`:Ma`button`;return ma`<div
                  class="sidebar-online__row"
                  data-person-card
                  data-person-card-section="online"
                >
                  <${a}
                    class="sidebar-online__person"
                    type=${i?z:`button`}
                    href=${i?.href??z}
                    @click=${i?.open??z}
                    data-online-user-id=${e.id}
                    data-presence-activity=${t}
                    aria-description=${`${Bo(t)} · ${r}`}
                    title=${n?z:j(`presence.sessions.unavailable`)}
                    data-person-card-key=${ml(e)}
                    data-person-card-trigger
                    aria-haspopup="dialog"
                    aria-expanded="false"
                    aria-label=${j(i?`presence.card.ariaLabel`:`presence.card.details`,{name:ss(e)})}
                  >
                    <span class="sidebar-online__avatar" aria-hidden="true">
                      <openclaw-viewer-avatar
                        .user=${e}
                        .markAsViewer=${!1}
                        variant="footer"
                      ></openclaw-viewer-avatar>
                    </span>
                    <span class="sidebar-online__person-name">${ss(e)}</span>
                    ${n&&(n.open>0||n.running>0)?R`<span class="sidebar-online__counts" aria-hidden="true">
                            ${n.running>0?R`<span
                                    class="sidebar-online__running"
                                    data-session-count="running"
                                    title=${j(`presence.sessions.runningCount`,{count:String(n.running)})}
                                    ><span class="session-run-spinner"></span
                                    ><span class="sidebar-online__count"
                                      >${n.running}</span
                                    ></span
                                  >`:z}
                            ${n.open>0?R`<span
                                    class="sidebar-online__open"
                                    data-session-count="open"
                                    title=${j(`presence.sessions.openCount`,{count:String(n.open)})}
                                    ><span class="sidebar-online__open-icon"
                                      >${I.messageCircle}</span
                                    ><span class="sidebar-online__count"
                                      >${n.open}</span
                                    ></span
                                  >`:z}
                          </span>`:z}
                  </${a}>
                </div>`})}
              </div>
              ${e.sessionData.ownerCounts.error?R`<button
                      type="button"
                      class="sidebar-online__retry"
                      @click=${()=>e.sessionData.ownerCounts.refresh()}
                    >
                      ${j(`presence.sessions.retry`)}
                    </button>`:z}`}
    </section>
  `}function Xh(){return(Xh=e((()=>{B(),Oa(),ja(),ol(),F(),zo(),No(),xp(),L(),ih()})))()}function Zh(e,t,n,r={}){return R`<wa-dropdown-item
    class=${`sidebar-customize-menu__item${r.className?` ${r.className}`:``}`}
    value=${e}
    ?disabled=${r.disabled}
    title=${r.title??z}
  >
    <span slot="icon" class="nav-item__icon" aria-hidden="true">${I[n]}</span>
    <span class="sidebar-customize-menu__text">${t}</span>
    ${r.details??z}
  </wa-dropdown-item>`}function Qh(e,t,n=`top`){return R`<button
    slot="trigger"
    type="button"
    tabindex="-1"
    aria-hidden="true"
    aria-label=${t}
    style="position: fixed; left: ${e.x}px; ${n}: ${e.y}px; width: 1px; height: 1px; opacity: 0; pointer-events: none;"
  ></button>`}function $h(e,t){return e===void 0?!1:t===`config`?ra(e):t===`plugins`?ia(e):t===`sessions`?ti(e):e===t}function eg(e){let t=e??[];return[`chat`,`control`,`agent`,`settings`].flatMap(e=>t.filter(t=>(t.group??`control`)===e))}function tg(e){return R`
    <a
      href=${e.href}
      class="nav-item ${e.active?`nav-item--active`:``}"
      aria-current=${e.active?`page`:z}
      @focus=${t=>e.onPreload(t)}
      @blur=${e.onCancelPreload}
      @pointerenter=${t=>e.onPreload(t)}
      @pointerleave=${e.onCancelPreload}
      @touchstart=${{handleEvent:t=>e.onPreload(t,!0),passive:!0}}
      @click=${t=>{k(t)&&(t.preventDefault(),e.onNavigate())}}
    >
      <span class="nav-item__icon" aria-hidden="true"
        >${I[rr(e.routeId)]}</span
      >
      <span class="nav-item__text">${br(e.routeId)}</span>
    </a>
  `}function ng(e){let t=Fr(e.tab,e.basePath),n=Object.hasOwn(I,e.tab.icon)?e.tab.icon:`plug`;return R`
    <a
      href=${`${t.pathname}${t.search}`}
      class="nav-item ${e.active?`nav-item--active`:``}"
      aria-current=${e.active?`page`:z}
      @click=${n=>{k(n)&&(n.preventDefault(),e.onNavigate(t))}}
    >
      <span class="nav-item__icon" aria-hidden="true">${I[n]}</span>
      <span class="nav-item__text">${e.tab.label}</span>
    </a>
  `}function rg(e,t){let n=$h(e.activeRouteId,t);return R`
    <wa-dropdown-item
      value=${t}
      class="sidebar-customize-menu__item ${n?`sidebar-customize-menu__item--active`:``}"
      aria-current=${n?`page`:z}
      @pointerenter=${n=>e.onPreloadRoute(t,n)}
      @pointerleave=${e.onCancelPreload}
      @click=${e=>{if(!k(e)){e.currentTarget.dataset.nativeNavigation=`true`;return}e.preventDefault()}}
    >
      <a href=${gi(t,e.basePath)} tabindex="-1">
        <span class="nav-item__icon" aria-hidden="true"
          >${I[rr(t)]}</span
        >
        <span class="sidebar-customize-menu__text">${br(t)}</span>
      </a>
    </wa-dropdown-item>
  `}function ig(e){let t=e.position,n=$n(e.sidebarEntries).filter(t=>e.isRouteEnabled(t));return R`
    <wa-dropdown
      class="sidebar-customize-menu sidebar-more-menu"
      .open=${!0}
      placement="bottom-start"
      .distance=${0}
      aria-label=${j(`nav.more`)}
      @wa-select=${t=>{t.preventDefault();let r=t.detail.item;if(r.dataset.nativeNavigation){delete r.dataset.nativeNavigation;return}let i=r.value;if(i===`customize`){e.onEditPinnedItems();return}i&&n.includes(i)&&e.onNavigateRoute(i)}}
      @keydown=${t=>Gf(t,e.onTabAway)}
      @wa-after-hide=${t=>e.onClose(Kf(t))}
    >
      ${Qh(t,j(`nav.more`))}
      ${n.map(t=>rg(e,t))}
      <div class="sidebar-customize-menu__separator" role="separator"></div>
      ${Zh(`customize`,j(`nav.customize`),`penLine`)}
    </wa-dropdown>
  `}function ag(e){let t=e.position;return R`
    <wa-dropdown
      class="sidebar-customize-menu sidebar-pin-editor-menu"
      .open=${!0}
      placement="bottom-start"
      .distance=${0}
      aria-label=${j(`nav.customize`)}
      @wa-select=${t=>{t.preventDefault();let n=t.detail.item.value;if(n===`reset`)e.onReset();else if(n?.startsWith(`plugin:`)){let t=n.slice(7);e.pluginNavigation.some(e=>e.key===t)&&e.onTogglePlugin(t)}else n&&_i.includes(n)&&e.onToggleRoute(n)}}
      @keydown=${t=>Gf(t,e.onTabAway)}
      @wa-after-hide=${t=>e.onClose(Kf(t))}
    >
      ${Qh(t,j(`nav.customize`))}
      <div class="sidebar-customize-menu__title">${j(`nav.customize`)}</div>
      ${e.preferencesBrowserOnly?R`<div class="sidebar-customize-menu__provenance" role="note">
              ${j(`quickSettings.personal.browserOnly`)}
            </div>`:z}
      ${_i.filter(t=>e.isRouteEnabled(t)).map(t=>{let n=e.sidebarEntries.includes(ir({type:`route`,route:t}));return R`
          <wa-dropdown-item
            class="sidebar-customize-menu__item"
            type="checkbox"
            value=${t}
            .checked=${n}
          >
            <span slot="icon" class="nav-item__icon" aria-hidden="true"
              >${I[rr(t)]}</span
            >
            <span class="sidebar-customize-menu__text">${br(t)}</span>
          </wa-dropdown-item>
        `})}
      ${e.pluginNavigation.filter(e=>e.value.defaultVisible===!1).map(t=>R` <wa-dropdown-item
            class="sidebar-customize-menu__item"
            type="checkbox"
            value=${`plugin:${t.key}`}
            .checked=${e.sidebarEntries.includes(`plugin:${t.key}`)}
          >
            <span slot="icon" class="nav-item__icon" aria-hidden="true">${I.plug}</span>
            <span class="sidebar-customize-menu__text">${t.value.label}</span>
          </wa-dropdown-item>`)}
      <div class="sidebar-customize-menu__separator" role="separator"></div>
      ${Zh(`reset`,j(`nav.customizeReset`),`refresh`)}
    </wa-dropdown>
  `}function og(){return(og=e((()=>{B(),Xi(),ii(),F(),L(),rp()})))()}function sg(e){let t=e.sessionOwnerFilterActive?e.sessionOwnerFilterId:null,n=t?e.sessionOwnerOptions.find(e=>e.id===t):e.sessionInvolvingMeFilterActive?uh(Si({snapshotUser:e.sessionDataContext?.gateway.snapshot.selfUser,presenceEntries:Tr(e.sessionData.presencePayload),presenceInstanceId:e.sessionData.presenceInstanceId})):void 0,r=[...t?[n?.label??t]:[],...e.sessionInvolvingMeFilterActive?[j(`sessionsView.involvingMe`)]:[],...e.sessionsStatusFilter===`archived`?[j(`sessionsView.archived`)]:e.sessionsStatusFilter===`all`?[j(`sessionsView.all`)]:[]],i=r.join(` · `),a=j(`chat.sidebar.showAllSessions`);return R`<button
    type="button"
    class="sidebar-session-filter-summary"
    title=${a}
    aria-label=${`${i} · ${a}`}
    @click=${()=>{e.setSessionOwnerFilter(null),e.sessionsStatusFilter!==`active`&&e.sessionOrganizer.setSessionsStatusFilter(`active`)}}
  >
    <span class="sidebar-session-filter-summary__lead" aria-hidden="true">
      <span class="sidebar-session-filter-summary__glyph"
        >${n?mh(n):I.archive}</span
      >
      <span class="sidebar-session-filter-summary__clear">${I.x}</span>
    </span>
    <span class="sidebar-session-filter-summary__label"
      >${r.map((e,t)=>R`${t>0?R`<span class="sidebar-session-filter-summary__sep" aria-hidden="true">·</span>`:z}${e}`)}</span
    >
  </button>`}function cg(e){return Number(e.sessionOwnerFilterActive||e.sessionInvolvingMeFilterActive)+Number(e.sessionsStatusFilter!==`active`)}function lg(e,t){let n=cg(e);return R`<button
    type="button"
    class="${t} sidebar-session-sort ${n>0?`sidebar-session-sort--filtered`:``}"
    title=${j(`chat.sidebar.sortSessions`)}
    aria-label=${j(`chat.sidebar.sortSessions`)}
    aria-description=${n>0?j(`chat.sidebar.activeFilterCount`,{count:String(n)}):z}
    aria-haspopup="dialog"
    aria-expanded=${String(e.sidebarMenus.sessionSortMenuPosition!==null)}
    @click=${t=>{t.currentTarget instanceof HTMLElement&&e.sidebarMenus.toggleSessionSortMenu(t.currentTarget)}}
  >
    ${I.listFilter}
  </button>`}function ug(e){let t=e.readNewSessionAccess(),n=e.sessionOwnerFilterActive||e.sessionInvolvingMeFilterActive||e.sessionsStatusFilter!==`active`;return R`
    <div class="sidebar-session-toolbar">
      <span class="sidebar-recent-sessions__label-text">${j(`chat.sidebar.threads`)}</span>
      ${n?sg(e):z}
      ${lg(e,`sidebar-session-toolbar__button`)}
      ${Qr({basePath:e.basePath,agentId:e.expandedAgentId(),className:`sidebar-session-toolbar__button sidebar-new-session`,label:j(`agentChip.newConversation`),showShortcut:!0,disabledReason:t.allowed?void 0:t.reason,onOpen:(t,n)=>e.requestOpenNewSession(t,n)})}
    </div>
  `}function dg(e){return e.sessionData.sessionMutationError?R`
        <div
          class="sidebar-session-error callout danger callout--dismissible"
          role="alert"
          data-sidebar-session-error
        >
          <span class="callout__content">${e.sessionData.sessionMutationError}</span>
          <openclaw-tooltip .content=${j(`chat.actions.dismissError`)}>
            <button
              class="callout__dismiss"
              type="button"
              @click=${()=>e.sessionData.dismissSessionMutationError()}
              aria-label=${j(`chat.actions.dismissError`)}
            >
              ${I.x}
            </button>
          </openclaw-tooltip>
        </div>
      `:z}function fg(e,t,n){return t&&n&&e.sessionsStatusFilter===`active`&&(e.sessionOwnerFilterActive||e.sessionInvolvingMeFilterActive)?R`<span class="sidebar-session-empty-hint"
        >${j(`chat.sidebar.noActiveSessionsForFilter`)}</span
      >`:z}function pg(){return(pg=e((()=>{B(),F(),L(),yi(),gh()})))()}function mg(e){switch(e.kind){case`question`:case`approval`:return 3;case`agent`:return 2;case`error`:return 1;case`none`:return 0;default:return e}}function hg(e){let t=e.flatMap(e=>e.kind===`question`||e.kind===`approval`?e.requests:[]).toSorted((e,t)=>e.createdAtMs-t.createdAtMs||e.id.localeCompare(t.id)||e.kind.localeCompare(t.kind)),n=t[0];return n?{kind:n.kind,requests:[...new Map(t.map(e=>[`${e.kind}:${e.id}`,e])).values()]}:e.toSorted((e,t)=>mg(t)-mg(e))[0]??Kg}function gg(e,t=0){return t===1?e.hasActiveRun:t===2?e.attention.kind!==`none`:e.visuallyActive||e.containsActiveDescendant||e.hasActiveRun||e.runningChildCount>0||e.failedChildCount>0||(e.workspaceConflictCount??0)>0||e.unread||(e.unreadChildCount??0)>0||e.attention.kind!==`none`}function _g(e){let t=Math.max(0,e.scrollHeight-e.clientHeight);return t<=1?`none`:e.scrollTop<=1?`top`:e.scrollTop>=t-1?`bottom`:`middle`}function vg(e){return`sidebar-session-meta-${encodeURIComponent(e)}`}function yg(e){return`sidebar-session-state-${encodeURIComponent(e)}`}function bg(){return Gs(D()?.getItem(Jg))}function xg(){return Ho(D()?.getItem(Yg))}function Sg(){return D()?.getItem(Zg)===`true`}function Cg(){return D()?.getItem(Xg)===`true`}function wg(){return D()?.getItem(Qg)===`true`}function Tg(){let e=D()?.getItem($g);return e===`archived`||e===`all`?e:`active`}function Eg(e,t){return`${r_}${Te(e)}:${encodeURIComponent(t)}`}function Dg(e,t){try{let n=D()?.getItem(Eg(e,t)),r=n?.startsWith(`owner:`)?n.slice(6).trim():``;return{ownerId:n===`involving-me`?null:r||null,involvingMe:n===`involving-me`}}catch{return{ownerId:null,involvingMe:!1}}}function Og(){let e=D()?.getItem(e_);return e===`updated`||e===`people`?e:`created`}function kg(e,t=[]){try{let n=D()?.getItem(e);if(n==null)return new Set(t);let r=JSON.parse(n);return new Set(Array.isArray(r)?r.flatMap(e=>typeof e==`string`&&e?[e]:[]):[])}catch{return new Set(t)}}function Ag(){return kg(t_,[`work`])}function jg(){return kg(n_)}function Mg(e,t){try{D()?.setItem(e,t)}catch{}}function Ng(e){Mg(Jg,e)}function Pg(e){D()?.setItem(Yg,e)}function Fg(e){Mg(Zg,String(e))}function Ig(e){Mg(Xg,String(e))}function Lg(e){Mg(Qg,String(e))}function Rg(e){Mg($g,e)}function zg(e,t,n){try{let r=D(),i=Eg(e,t),a=n.involvingMe?`involving-me`:n.ownerId?`owner:${n.ownerId}`:null;a===null?r?.removeItem(i):r?.setItem(i,a)}catch{}}function Bg(e,t){return e===`people`&&!t?`created`:e}function Vg(e,t){let n=Bg(e,t!==!1);return Mg(e_,n),n}function Hg(e){Mg(t_,JSON.stringify([...e]))}function Ug(e){D()?.setItem(n_,JSON.stringify([...e])),typeof window<`u`&&window.dispatchEvent(new CustomEvent(i_))}function Wg(e,t){let n=new Set(jg());t?n.add(e):n.delete(e),Ug(n)}function Gg(e,t){return`${e}\u0000${t}`}var Kg,qg,Jg,Yg,Xg,Zg,Qg,$g,e_,t_,n_,r_,i_,a_,o_;function K(){return(K=e((()=>{Hs(),xs(),Kg={kind:`none`},qg=function(e){return e[e.Any=0]=`Any`,e[e.ActiveRun=1]=`ActiveRun`,e[e.Attention=2]=`Attention`,e}({}),Jg=`openclaw:sidebar:sessions:grouping`,Yg=`openclaw:sidebar:sessions:catalog-grouping`,Xg=`openclaw:sidebar:sessions:show-preview`,Zg=`openclaw:sidebar:sessions:show-cron`,Qg=`openclaw:sidebar:sessions:show-system`,$g=`openclaw:sidebar:sessions:status-filter`,e_=`openclaw:sidebar:sessions:sort-mode`,t_=`openclaw:sidebar:sessions:collapsed-sections`,n_=`openclaw:sidebar:sessions:hidden-catalogs`,r_=`openclaw.control.sidebarSessionOwnerFilter.v1:`,i_=`openclaw:sidebar-hidden-catalogs-changed`,a_=[{mode:`created`,labelKey:`chat.sidebar.sortCreated`},{mode:`updated`,labelKey:`chat.sidebar.sortUpdated`},{mode:`people`,labelKey:`sessionsView.owners`}],o_=[`active`,`archived`,`all`]})))()}function s_(e){return e.replace(l_,e=>e.replace(c_,``))}var c_,l_;function u_(){return(u_=e((()=>{c_=/(?:⚠️?|⛔|❌|🛠️?|✉️?)/gu,l_=/^[ \t]*(?:⚠️?|⛔|❌|🛠️?|✉️?)(?:[ \t]*(?:⚠️?|⛔|❌|🛠️?|✉️?))*/u})))()}function d_(e){return f_[e]}var f_;function p_(){return(p_=e((()=>{L(),f_={hand:I.hand,key:I.key,alert:I.alertTriangle,flag:I.flag,lock:I.lock,hourglass:I.circle}})))()}function m_(e){e.stopPropagation()}function h_(e){e.preventDefault(),e.stopPropagation()}function g_(e,t=!1){if(e.kind===`none`)return z;let n=t?y_(e):void 0,r=e.kind===`question`?I.hand:e.kind===`approval`?I.shieldQuestion:e.kind===`agent`?d_(e.icon):I.alertTriangle,i=R`<span
    class="sidebar-session-attention__icon sidebar-session-attention__icon--${e.kind}"
    data-session-attention=${e.kind}
    role=${n?`img`:z}
    aria-label=${n??z}
    aria-hidden=${n?z:`true`}
    tabindex=${n?`0`:z}
    @focusin=${n?m_:z}
    @click=${n?h_:z}
    >${r}</span
  >`;return t&&n?b_(e,i):i}function __(e){switch(e.kind){case`question`:return j(`sessionsView.waitingForAnswer`);case`approval`:return j(`sessionsView.waitingForApproval`);case`error`:return j(e.childLabel===void 0?`sessionsView.runFailedReason`:`sessionsView.childRunFailedReason`,{label:e.childLabel??``,reason:s_(e.reason)});case`agent`:return e.note;case`none`:return;default:return e}}function v_(e){let t=__(e);if(e.kind!==`question`&&e.kind!==`approval`)return{status:t};let n=e.requests.filter(t=>t.kind===e.kind),r=n.reduce((e,t)=>e+t.count,0);return{status:r>1?j(e.kind===`question`?`sessionsView.questionsNeedAnswer`:`sessionsView.approvalsNeedApproval`,{count:String(r)}):t,preview:n[0]?.preview,more:r>1?j(`sessionsView.attentionMore`,{count:String(r-1)}):void 0}}function y_(e){let{status:t,preview:n,more:r}=v_(e);return[t,n,r].filter(Boolean).join(`
`)||void 0}function b_(e,t){let{status:n,preview:r,more:i}=v_(e);return R`<openclaw-tooltip .content=${r?``:n} open-on-click>
    ${t}
    ${r?R`<span slot="content" class="sidebar-session-attention-tooltip">
            <strong>${n}</strong>
            <span class="sidebar-session-attention-tooltip__preview">${r}</span>
            ${i?R`<span>${i}</span>`:z}
          </span>`:z}
  </openclaw-tooltip>`}function x_(e){if(!e.isChild)return e.unread?R`<span
          class="session-unread-dot"
          role="img"
          aria-label=${j(`sessionsView.unread`)}
        ></span>`:z;let t=e.status;if(!t)return z;let n=t===`done`?{icon:I.check,label:j(`sessionsView.statusDone`)}:t===`killed`?{icon:I.stop,label:j(`sessionsView.statusKilled`)}:t===`timeout`?{icon:I.alertTriangle,label:j(`sessionsView.statusTimeout`)}:t===`interrupted`?{icon:I.pause,label:j(`sessionsView.statusInterrupted`)}:t===`failed`?{icon:I.alertTriangle,label:j(`sessionsView.statusFailed`)}:null;return n?R`<span
        class="sidebar-child-session__status sidebar-child-session__status--${t}"
        role="img"
        aria-label=${n.label}
        title=${n.label}
        >${n.icon}</span
      >`:z}function S_(e,t,n,r=0){let i=hg(e.flatMap(e=>t?[e.attention]:[e.ownAttention??e.attention,...e.subagentSummary?[e.subagentSummary.attention]:[]])),a=0,o=0,s=0,c=!1;for(let n of e){let e=t?n:n.subagentSummary;a+=Number(n.hasActiveRun)+(e?.runningChildCount??0),o+=Number(n.hasActiveRun&&n.status===`queued`)+(e?.queuedChildCount??0),s+=Number(n.unread)+(e?.unreadChildCount??0),c||=n.status===`failed`||n.status===`timeout`||(e?.failedChildCount??0)>0}let l=i&&i.kind!==`none`?g_(i,!0):c?R`<span
            class="sidebar-child-session__status--failed"
            role="img"
            aria-label=${j(`sessionsView.statusFailed`)}
            >${I.alertTriangle}</span
          >`:r?R`<span
              role="img"
              aria-label=${j(`sessionsView.cloudWorkerDescendantConflicts`,{count:String(r)})}
              >${I.globe}</span
            >`:a?Bp({content:z,running:!0,queued:a===o}):e.length===1&&e[0]?.isChild?x_(e[0]):z;return(!t||n===0)&&s===0&&l===z?z:R`<span class="sidebar-session-team-state">
    ${t&&n>0||s>0?R`<span class="sidebar-session-team-state__counts">
            ${t&&n>0?R`<span class="sidebar-child-session-toggle__count" role="img" aria-label=${`${j(`sessionsView.childSessions`)}: ${n}`}>${n}</span>`:z}
            ${s>0?R`<span class=${s===1?`session-unread-dot`:`sidebar-agent-roster__unread`} role="img" aria-label=${j(`sessionsView.unread`)} title=${j(`sessionsView.unread`)}>${s>1?s:z}</span>`:z}
          </span>`:z}
    ${l===z?z:R`<span class="sidebar-session-team-state__status">${l}</span>`}
  </span>`}function C_(){return(C_=e((()=>{B(),F(),K(),u_(),L(),p_(),Up()})))()}async function w_(e,t,n){let r=e.currentTarget;if(!(r instanceof HTMLButtonElement))return;let i=await un(t);r.dataset.copied=i?`1`:`0`,r.setAttribute(`aria-label`,j(i?`aboutPage.copiedCommit`:`common.copyFailed`)),window.setTimeout(()=>{r.isConnected&&(delete r.dataset.copied,r.setAttribute(`aria-label`,n))},N_)}function T_(e){return!e||e===`main`?``:`${e.length>M_?`${h(e,M_)}…`:e}@`}function E_(e){return e.commit?`${T_(e.branch)}${`${e.commit.slice(0,7)}${e.dirty===!0?`*`:``}`}`:null}function D_(e){if(e.release)return null;let t=E_(e);return t?e.branch&&e.branch!==`main`?t:`git@${t}`:null}function O_(e){let t=D_(e);if(!t)return null;let n=e.commitAt?Date.parse(e.commitAt):NaN;return Number.isFinite(n)?`${t} · ${st(n)}`:t}function k_(e,t){let n=e.version??t,r=D_(e);return r?[n,r].filter(e=>!!e).join(` · `):n}function A_(e,t){let n=e.builtAt?Date.parse(e.builtAt):NaN;return{summary:e.version?`v${e.version}`:null,commit:e.commit?.slice(0,12)??null,builtAt:Number.isFinite(n)?`${Le(n,{day:`numeric`,month:`short`,year:`numeric`,hour:`2-digit`,minute:`2-digit`,hour12:!1,timeZone:`UTC`})} UTC`:null,gatewayVersion:t}}function j_(e,t){let n=A_(e,t),r=n.commit,i=j(`aboutPage.unavailable`),a=j(`aboutPage.copyCommit`);return R`
    <div class="sidebar-hover-card__server-details">
      <div class="sidebar-hover-card__summary">${n.summary||i}</div>
      <dl class="sidebar-hover-card__metadata">
        <div class="sidebar-hover-card__metadata-row">
          <dt>${j(`aboutPage.commit`)}</dt>
          <dd class="sidebar-hover-card__metadata-value--mono sidebar-build-hover-card__commit">
            <span>${r??i}</span>
            ${r?R`<button
                    type="button"
                    class="sidebar-build-hover-card__copy"
                    aria-label=${a}
                    @click=${e=>void w_(e,r,a)}
                  >
                    <span class="sidebar-build-hover-card__copy-idle" aria-hidden="true"
                      >${I.copy}</span
                    >
                    <span class="sidebar-build-hover-card__copy-done" aria-hidden="true"
                      >${I.check}</span
                    >
                  </button>`:null}
          </dd>
        </div>
        <div class="sidebar-hover-card__metadata-row">
          <dt>${j(`aboutPage.built`)}</dt>
          <dd>${n.builtAt??i}</dd>
        </div>
        <div class="sidebar-hover-card__metadata-row">
          <dt>${j(`aboutPage.gateway`)}</dt>
          <dd>
            ${n.gatewayVersion?R`<span
                      class="sidebar-build-hover-card__gateway-state"
                      aria-hidden="true"
                    ></span
                    ><span class="sr-only">${j(`common.connected`)}</span>`:null}
            ${n.gatewayVersion??i}
          </dd>
        </div>
      </dl>
    </div>
  `}var M_,N_;function P_(){return(P_=e((()=>{B(),F(),Ln(),_t(),L(),M_=14,N_=1500})))()}function F_(){let e=window.__OPENCLAW_NATIVE_GATEWAYS__;return!e||!Array.isArray(e.gateways)?null:e.gateways.find(t=>t.id===e.currentId)??null}function I_(e){let{activeId:t,agent:n,agents:r,identity:i}=e.activeChipAgent(),a=r.some(n=>{let r=b(n.id);return r!==t&&e.agentUnreadCount(r)>0}),o=Qe(n??{id:t},i),s=e.sessionDataContext?.gateway,c=!!(s&&(s.snapshot.hello||s.connection.token.trim()||s.connection.password.trim()));return R`
    <openclaw-sidebar-agent-card
      .agentName=${o}
      .agentId=${t}
      .avatarUrl=${n?vt(n,i):i?.avatar}
      .avatarAuthReady=${c}
      .avatarText=${Et(n??{identity:{}},i)}
      .environment=${e.sessionDataContext?.config?.current?.environment??null}
      .menuOpen=${e.sidebarMenus.agentMenuPosition!==null}
      .menuUnread=${a}
      .switcherAvailable=${r.length>1}
      .onToggleMenu=${t=>e.sidebarMenus.toggleAgentMenu(t)}
      .onMenuPointerMove=${(t,n)=>e.sidebarMenus.scheduleAgentMenuHoverOpen(t,n)}
      .onMenuPointerLeave=${()=>e.sidebarMenus.handleAgentMenuTriggerPointerLeave()}
      @contextmenu=${t=>{if(t.preventDefault(),e.sidebarMenus.agentMenuPosition!==null)return;let n=t.currentTarget,r=n.querySelector(`.sidebar-agent-card__main`)??n;e.sidebarMenus.toggleAgentMenu(r)}}
    ></openclaw-sidebar-agent-card>
  `}function L_(e){let t=F_()?.name.trim()||`OpenClaw`,n=e.sidebarMenus.agentMenuPosition!==null;return R`
    <div class="sidebar-workspace-header">
      <button
        type="button"
        class="sidebar-workspace-header__main"
        aria-haspopup="menu"
        aria-expanded=${String(n)}
        aria-label="${t} · ${j(`agentChip.workspaceMenuLabel`)}"
        @pointermove=${t=>{t.currentTarget instanceof HTMLElement&&e.sidebarMenus.scheduleAgentMenuHoverOpen(t.currentTarget,t)}}
        @pointerleave=${()=>e.sidebarMenus.handleAgentMenuTriggerPointerLeave()}
        @pointerdown=${e=>e.stopPropagation()}
        @click=${t=>{t.stopPropagation(),t.currentTarget instanceof HTMLElement&&e.sidebarMenus.toggleAgentMenu(t.currentTarget)}}
        @contextmenu=${t=>{t.preventDefault(),!n&&t.currentTarget instanceof HTMLElement&&e.sidebarMenus.toggleAgentMenu(t.currentTarget)}}
      >
        ${e.sessionDataContext?.theme.branding.mascot===`none`?R`<span
                class="sidebar-workspace-header__mark sidebar-workspace-header__mark--neutral"
                aria-hidden="true"
                >${I.mark}</span
              >`:R`<img
                class="sidebar-workspace-header__mark"
                src=${Er(`favicon.svg`,e.basePath)}
                alt=""
                aria-hidden="true"
              />`}
        <span class="sidebar-agent-card__text">
          <span class="sidebar-agent-card__name">
            ${ic(t,`sidebar-agent-card__name-text`,{loop:!0,delay:300,speed:35})}
            <span class="sidebar-agent-card__chevron" aria-hidden="true"
              >${I.chevronsUpDown}</span
            >
          </span>
          ${e.sessionDataContext?.config.current.environment?R`<span class="control-ui-environment-pill"
                  >${e.sessionDataContext.config.current.environment.label}</span
                >`:z}
        </span>
      </button>
    </div>
  `}function R_(e,t=z){let n=e.readNewSessionAccess(),r=j(`nav.collapse`);return R`
    <div class="sidebar-brand">
      ${e.sidebarAgentsMode===`roster`?L_(e):I_(e)}
      <div class="sidebar-brand__actions">
        <openclaw-tooltip
          .content=${`${r} (${gt(Nt.toggleSidebar)})`}
          .contentTemplate=${Ii(r,Nt.toggleSidebar)}
        >
          <button
            type="button"
            class="sidebar-brand__icon sidebar-brand__header-control sidebar-brand__desktop-control sidebar-brand__collapse"
            aria-label=${r}
            aria-expanded="true"
            ?disabled=${!e.onToggleSidebar}
            @click=${()=>e.onToggleSidebar?.()}
          >
            ${I.panelLeftClose}
          </button>
        </openclaw-tooltip>
        <openclaw-tooltip
          .content=${`${j(`chat.openCommandPalette`)} (${gt(Nt.commandPalette)})`}
          .contentTemplate=${Ii(j(`chat.openCommandPalette`),Nt.commandPalette)}
        >
          <button
            type="button"
            class="sidebar-brand__icon sidebar-brand__header-control sidebar-brand__desktop-control sidebar-brand__search"
            aria-label=${j(`chat.openCommandPalette`)}
            ?disabled=${!e.onOpenPalette}
            @click=${()=>e.onOpenPalette?.()}
          >
            ${I.search}
          </button>
        </openclaw-tooltip>
        ${e.sidebarAgentsMode===`roster`?lg(e,`sidebar-brand__icon sidebar-brand__header-control`):z}
        ${e.sidebarAgentsMode===`roster`?t:Qr({basePath:e.basePath,agentId:e.expandedAgentId(),className:`sidebar-brand__icon sidebar-brand__header-control sidebar-brand__new-thread`,label:j(`agentChip.newConversation`),showShortcut:!0,disabledReason:n.allowed?void 0:n.reason,onOpen:(t,n)=>e.requestOpenNewSession(t,n)})}
      </div>
    </div>
  `}function z_(e){if(e.sidebarAgentsMode===`roster`)return z;let t=e.expandedAgentId(),n=e.selectedAgentMainSessionKey(t),r=e.mainSessionRow(t),i=r?e.projectHomeSession(r,t):null,a=i?.attention??e.resolveSessionAttention({key:n,agentId:t}),o=y_(a),s=e.outboxAttentionCountForSession(n),c=Ji(e.activeRouteId)&&O(e.getRouteSessionKey(),n),l=e.hasSessionDraft(n),u=r?pe(r):!1,d=(i?.runningChildCount??0)>0,f=u||d,p=u&&r?.status===`queued`&&!d,m=(r?.unread===!0||(i?.unreadChildCount??0)>0)&&!c,h=f?j(d&&(!u||r?.status===`queued`)?`sessionsView.subagentsWorking`:p?`sessionsView.statusQueued`:`sessionsView.activeRun`):``,g=m?j(`sessionsView.unread`):``,_=o||h&&g?[o,h,g].filter(Boolean).join(` · `):``,v=Bp({content:a.kind===`none`?R`<span class="nav-item__icon" aria-hidden="true">${I.home}</span>`:g_(a,!0),running:f,queued:p,runningLabel:h,badge:m&&!f?Vp():z});return R`
    <a
      href=${Bn({face:Vn(r),sessionKey:n,fallbackAgentId:t,basePath:e.basePath,row:r??void 0,mainKey:A(n)?.rest,preferenceDerivedFace:!0}).href}
      class="nav-item nav-item--home ${c?`nav-item--active`:``}"
      aria-label=${_?`${j(`nav.home`)} · ${_}`:z}
      aria-current=${c?`page`:z}
      @click=${n=>{k(n)&&(n.preventDefault(),e.openMainSession(t))}}
    >
      ${v}
      <span class="nav-item__text">${j(`nav.home`)}</span>
      ${s>0||l?R`<span class="nav-item__state sidebar-home-session-states">
              ${Jp({outboxAttentionCount:s,hasComposerDraft:l})}
            </span>`:z}
    </a>
  `}function B_(e){return R`
    <div class="sidebar-nav__head">
      <span class="sidebar-recent-sessions__label-text sr-only">${j(`nav.pages`)}</span>
      <button
        type="button"
        class="sidebar-nav__head-action"
        aria-haspopup="menu"
        aria-expanded=${String(e.sidebarMenus.moreMenuPosition!==null)}
        aria-label=${j(`nav.customize`)}
        @click=${t=>e.sidebarMenus.toggleMoreMenu(t.currentTarget)}
      >
        ${I.penLine}
      </button>
    </div>
  `}function V_(e){let t=e.connectionStatus,n=e.sessionDataContext?Yi(e.sessionDataContext.gateway).displayUser:null,r=n?.name??n?.email??j(`nav.owner`),i={id:`owner`,...n,name:r,watchedSessions:[]},a=F_(),o=O_(Vr),s=a?.isPrimary?j(`nav.gateway.primaryTag`):null,c=j(`profilePage.identity.menuButtonLabel`,{name:r}),l=t?j(`connection.${t}`):null,u=l||(a?`${a.name}${s?`, ${s}`:``}`:o),d=l??(e.connected?j(`nav.gateway.connected`):``);return R`
    <div class="sidebar-footer-bar sidebar-footer-bar--one-action">
      <button
        type="button"
        class="sidebar-identity-card"
        aria-haspopup="menu"
        aria-expanded=${String(e.sidebarMenus.identityMenuPosition!==null)}
        aria-label=${u?`${c}: ${u}`:c}
        @click=${t=>e.sidebarMenus.toggleIdentityMenu(t.currentTarget)}
      >
        <openclaw-viewer-avatar .user=${i} variant="footer"></openclaw-viewer-avatar>
        <span class="sidebar-identity-card__text">
          ${ic(r,`sidebar-identity-card__name`,{loop:!0,delay:300,speed:35})}
          ${t?ri({kind:t,lastError:e.lastError,announce:!1}):R`
                  ${a?R`<span class="sidebar-identity-card__gateway" aria-hidden="true">
                          <span class="sidebar-gateway-name">${a.name}</span>
                          ${s?R`<span class="sidebar-gateway-primary">${s}</span>`:z}
                        </span>`:z}
                `}
        </span>
      </button>
      <span class="sr-only" role="status" aria-live="polite" aria-atomic="true"
        >${d}</span
      >
      <span class="sidebar-footer-actions">
        ${ai(e.sessionDataContext?.gateway)?R`<openclaw-tooltip
                .content=${`${j(`assistantPanel.toggle`)} (${gt(Nt.homePanel)})`}
                .contentTemplate=${Ii(j(`assistantPanel.toggle`),Nt.homePanel)}
                ><button
                  type="button"
                  class="sidebar-brand__icon sidebar-footer-bar__home"
                  aria-label=${j(`assistantPanel.toggle`)}
                  @click=${()=>window.dispatchEvent(new CustomEvent(Li))}
                >
                  ${I.home}
                </button></openclaw-tooltip
              >`:z}
        <openclaw-sidebar-attention
          .activeRouteId=${e.activeRouteId}
          .onNavigate=${e.onNavigate}
          .watchUpdateProgress=${e.watchUpdateProgress}
        ></openclaw-sidebar-attention>
      </span>
    </div>
  `}function H_(e,t,n,r){if(t.type===`route`&&!e.sidebarMenus.isRouteEnabled(t.route))return z;let i=ir(t),a=e.sessionOrganizer.sidebarZoneDropTarget?.entry===i?e.sessionOrganizer.sidebarZoneDropTarget.position:null,o=t.type===`plugin`?r.get(t.key):void 0,s=t.type===`route`?e.sidebarMenus.renderRoute(t.route):o?U_(e,o):t.type===`plugin`?R`<openclaw-plugin-contributions
              .kind=${`navigation`}
              .navigationKey=${t.key}
            ></openclaw-plugin-contributions>`:n.has(t.key)?e.renderPinnedSidebarSession(n.get(t.key)):z,c=t.type===`route`||t.type===`plugin`,l=t.type===`route`?br(t.route):t.type===`session`?n.get(t.key)?.label??t.key:o?.label??e.pluginNavigation().find(e=>e.key===t.key)?.value.label??t.key;return R`
    <div
      class="sidebar-zone-entry ${a?`sidebar-zone-entry--drop-${a}`:``} ${e.sessionOrganizer.draggingSidebarEntry===i?`sidebar-zone-entry--dragging`:``}"
      data-sidebar-entry=${i}
      draggable=${c?`true`:`false`}
      @dragstart=${t.type===`route`?n=>e.sessionOrganizer.startSidebarRouteDrag(n,t.route):t.type===`plugin`?n=>e.sessionOrganizer.startSidebarPluginDrag(n,t.key):z}
      @dragend=${c?()=>e.sessionOrganizer.finishSidebarEntryDrag():z}
      @dragover=${t=>e.sessionOrganizer.handleSidebarZoneDragOver(t,i)}
      @drop=${t=>e.sessionOrganizer.handleSidebarZoneDrop(t,i)}
    >
      ${s}
      ${vp({label:l,kind:`entry`,onMove:async(t,n)=>{e.sessionOrganizer.writeSidebarEntryAt(i,t,n),e.requestUpdate(),await e.updateComplete}})}
    </div>
  `}function U_(e,t){let n={pluginId:t.pluginId,id:t.id},r=_n(n),i=t.placement?.startsWith(`route:`)?t.placement.slice(6):``,a=wi(i)?i:null;return a?e.sidebarMenus.renderRoute(a):ng({tab:t,basePath:e.basePath,active:e.activeRouteId===`plugin`&&e.activePluginTabId===r,onNavigate:t=>e.onNavigate?.(`plugin`,t)})}function W_(){return(W_=e((()=>{B(),Xi(),ii(),oi(),Vi(),dr(),zr(),F(),pt(),$e(),zo(),qt(),Qt(),N(),Kt(),og(),pg(),Hi(),L(),Ur(),yi(),Zn(),C_(),Up(),Yp(),P_(),yp()})))()}function G_(){Y_??=T(()=>import(`./channel-avatar-DawdLoLC.js`),__vite__mapDeps([15,1,2,3,4,5,6,7,10,8,9]),import.meta.url)}function K_(e){let t=Nm(e);return t?R`<span class="session-glyph__icon" aria-hidden="true">${t}</span>`:R`<span class="session-glyph__emoji" aria-hidden="true">${e}</span>`}function q_(e){return[!e.isChild&&e.forkSource?j(`sessionsView.forkedSession`):``,(e.hasActiveRun||e.runningChildCount>0)&&e.unread?j(`sessionsView.unread`):``].filter(Boolean).join(` · `)}function J_(e,t,n,r,i,a=!1,o){let{participants:s,participantCount:c}=e,l=!a&&e.runningChildCount>0,u=e.hasActiveRun||l,d=e.hasActiveRun&&e.status===`queued`,f={running:u&&!a&&e.attention.kind!==`question`,queued:d&&!l,runningLabel:l&&(!e.hasActiveRun||d)?j(`sessionsView.subagentsWorking`):void 0},p=e.attention.kind!==`none`&&!a?g_(e.attention,!0):o??(e.icon?K_(e.icon):z);if(p!==z)return{running:u,leadingIndicator:Bp({content:p,...f,badge:e.unread&&!u&&!a?Vp():z})};if(e.isChild&&!a)return e.channelAvatarUrl?(G_(),{running:u,leadingIndicator:Bp({content:R`<openclaw-channel-avatar
            .routeUrl=${e.channelAvatarUrl}
            .authTokens=${i?.authTokens??[]}
            .authReady=${i?.authReady??!1}
          ></openclaw-channel-avatar>`,...f,circular:!0,badge:e.unread&&!u?Vp():z})}):{running:u,leadingIndicator:u?Bp({content:z,...f}):x_(e)};let m=t?.id?.trim()?dh(t,`row`,n,r,s,c):void 0;if(e.channelAvatarUrl)return G_(),{running:u,leadingIndicator:Bp({content:R`<openclaw-channel-avatar
          .routeUrl=${e.channelAvatarUrl}
          .authTokens=${i?.authTokens??[]}
          .authReady=${i?.authReady??!1}
          .fallback=${m??z}
        ></openclaw-channel-avatar>`,...f,badge:e.unread&&!u&&!a?Vp():z,circular:!0})};if(m){let n=c??s?.length??0;return{running:u,leadingIndicator:Bp({content:m,...f,badge:e.unread&&!u&&!a?Vp():z,circular:!0,ring:n>0?`pair`:`circle`}),renderedIdentities:[...t?.identity?[t.identity]:[],...n===1?(s??[]).slice(0,1).map(e=>e.identity):[]]}}return{running:u,leadingIndicator:f.running?Bp({content:z,...f}):e.unread&&!a?x_(e):z}}var Y_;function X_(){return(X_=e((()=>{B(),F(),C_(),Up(),Fm(),gh(),n()})))()}function Z_(e){let{session:t}=e;if(t.attention.kind===`question`||t.attention.kind===`error`)return{subtitle:void 0,narration:void 0};let n=__(t.attention),r=t.hasActiveRun,i=t.activeRunIds??[],a=e=>!!(e?.runId&&i.includes(e.runId)),o=a(e.observerDigest)?e.observerDigest:void 0,s=a(t.observerDigest)?t.observerDigest:void 0,c=r?Fs(o,s):Fs(e.observerDigest,t.observerDigest),l=!!(c&&(c.health===`done`||c.health===`failed`)&&(t.lastReadAt??0)<c.updatedAt),u=r||l?c?.headline:void 0;if(!e.showPreview){let e=Js(c?.health)?u:void 0;return{subtitle:n??e,narration:void 0}}let d=t.agentStatusNote||void 0,f=n||d||u||!e.sidebarLiveActivity||!r?void 0:e.narrationLine,p=e.hasDisplay?e.displaySubtitle:t.subtitle&&t.workSession&&t.subtitle!==t.label?t.subtitle:void 0,m=!r&&!e.hasDisplay&&t.lastMessagePreview?.trim()||void 0;return{subtitle:r?n??d??u??f??p:n??d??u??m??p,narration:f}}function Q_(e){return e.subtitle?e.narration?Ca(e.narration,R`<span
          class="sidebar-recent-session__subtitle sidebar-recent-session__subtitle--narration"
          >${e.subtitle}</span
        >`):R`<span class="sidebar-recent-session__subtitle">${e.subtitle}</span>`:z}function $_(){return($_=e((()=>{B(),Ea(),C_()})))()}var ev;function tv(){return(tv=e((()=>{B(),H(),us(),M(),rc(),ev=class extends Sn{constructor(...e){super(...e),this.startMs=null,this.endMs=null,this.minimumUnit=`second`,this.singleUnit=!1,this.polling=new Ro(this,1e3,()=>this.requestUpdate(),!1,`visible`)}connectedCallback(){super.connectedCallback(),this.syncTimer()}updated(){this.syncTimer()}syncTimer(){this.isConnected&&this.startMs!=null&&this.endMs==null?this.polling.start():this.polling.stop()}shouldUpdate(e){let t=this.currentDuration(),n=t!==this.duration;return this.duration=t,!this.hasUpdated||e.size>0||n}currentDuration(){let e=this.startMs;if(e==null)return;let t=this.endMs??Date.now(),n=this.minimumUnit===`minute`?6e4:1e3,r=Math.max(n,t-e);return this.singleUnit?fs(r):Fo(this.minimumUnit===`minute`?Math.floor(r/6e4)*6e4:r)}render(){return this.duration===void 0?z:R`${this.duration}`}},w([W({type:Number})],ev.prototype,`startMs`,void 0),w([W({type:Number})],ev.prototype,`endMs`,void 0),w([W({type:String})],ev.prototype,`minimumUnit`,void 0),w([W({type:Boolean})],ev.prototype,`singleUnit`,void 0),customElements.get(`openclaw-elapsed-time`)||customElements.define(`openclaw-elapsed-time`,ev)})))()}function nv(e){return e.fullyShown?e.session.children:e.session.children.filter((e,t)=>t<sv||gg(e))}function rv(e,t,n,r){let i=e.sidebarAgentsMode===`roster`,a=t.ownAttention??t.attention,o=e.isSessionChildrenExpanded(t),s=t.pullRequest??n?.pullRequest,c=t.worktreeId?e.sessionPullRequests.summary(t.key,t.worktreeId,s):s,l=e.sessionsStatusFilter===`archived`?`archived`:t.owner?.assignedAt===void 0?`created`:`owned`,u=e.sessionOwnershipVisibility.avatars?e.sessionsStatusFilter===`archived`?t.archivedBy:t.owner?.actor:void 0,d=u?.identity?.type===`profile`?ls(e.sessionData.presencePayload).users.some(e=>$o(e,u.identity)&&e.watchedSessions.includes(t.key)):void 0,f=e.sessionsGrouping===`person`&&!t.pinned&&l!==`archived`,p=e.sessionDataContext?.gateway.snapshot.selfUser,m=p?.identity?.id??p?.id,h=l!==`archived`&&u?.identity?.type===`profile`&&u.identity.id===m&&(e.sessionInvolvingMeFilterActive||e.sessionOwnerFilterId===u.id)&&(t.participantCount??t.participants?.length??0)===0||!i&&f&&d!==!0?void 0:u,g=e.sessionDataContext?.gateway,{running:_,leadingIndicator:v,renderedIdentities:y}=J_(t,h,l,d,{authTokens:g?Xr({hello:g.snapshot.hello,settings:{token:g.connection.token},password:g.connection.password}):[],authReady:!!(g&&(g.snapshot.hello||g.connection.token.trim()||g.connection.password.trim()))},i,r),b=q_(t),x=t.isChild&&(t.runtimeMs!=null||t.startedAt!=null),S=x?vg(t.key):void 0,ee=!i&&b?yg(t.key):void 0,C=R`<span class="sidebar-session-indicator"
    >${v}
    ${t.visibility===`draft`?R`<span class="session-row-draft-indicator" title=${j(`chat.sessionSharing.draft`)}
            >👻</span
          >`:z}</span
  >`,te=R`${t.archived?R`<span class="sidebar-session__archive-glyph" role="img" aria-label=${j(`sessionsView.archived`)} title=${j(`sessionsView.archived`)}>${I.archive}</span>`:z}${t.forkSource?R`<span class="sidebar-session-fork-indicator" aria-hidden=${i||t.isChild?z:`true`} role="img" aria-label=${j(`sessionsView.forkedSession`)}>${I.gitFork}</span>`:z}`,ne=x?R`<span class="session-row-trail" id=${S}
        >${t.runtimeMs==null?R`<openclaw-elapsed-time
                .startMs=${t.startedAt}
                .endMs=${t.endedAt??null}
              ></openclaw-elapsed-time>`:t.hasActiveRun?R`<openclaw-elapsed-time
                  .startMs=${t.runtimeSampledAt-t.runtimeMs}
                ></openclaw-elapsed-time>`:Fo(t.runtimeMs)??`0ms`}</span
      >`:z;return{running:_,stateId:ee,metaId:S,pullRequest:c,persistentIndicator:C,originIndicators:te,childrenExpanded:o,content:R` <span class="sidebar-recent-session__details-endcap">
      <openclaw-viewer-facepile
        .presencePayload=${e.sessionData.presencePayload}
        .selfUser=${e.sessionDataContext?.gateway.snapshot.selfUser}
        .selfInstanceId=${e.sessionData.presenceInstanceId}
        .sessionKey=${t.key}
        .excludeIdentities=${y??[]}
        .maxVisible=${3}
        variant="session"
      ></openclaw-viewer-facepile>
      ${i?te:z}
      ${i&&(t.workSession||t.acpSession)&&!t.workspaceKind&&!c?R`<span class="session-row-badge" role="img" aria-label=${j(`chat.sidebar.coding`)} title=${t.subtitle??j(`chat.sidebar.coding`)}>${I.terminal}</span>`:z}
      ${i&&t.hasAutomation?R`<span class="session-row-badge" role="img" aria-label=${j(`tabs.cron`)} title=${j(`tabs.cron`)}>${I.clock}</span>`:z}
      ${Jp({isChild:t.isChild,incognito:t.incognito,placementState:t.placementState,placementProviderId:t.placementProviderId,placementProfileId:t.placementProfileId,placementMachine:t.placementMachine,diskSpaceStatus:t.diskSpaceStatus,workspaceConflictCount:t.workspaceConflictCount,outboxAttentionCount:t.outboxAttentionCount,hasComposerDraft:t.hasComposerDraft===!0,pullRequest:c,hasApproval:a.kind===`question`?a.requests.some(e=>e.kind===`approval`):!i&&a.kind===`approval`})}
      ${i?ne:z}
      ${i?S_([t],!o,t.childSessionKeys.length):z}
      ${!i&&b?R`<span class="sr-only" id=${ee} aria-hidden="true">${b}</span>`:z}
      ${i?z:ne}
    </span>`}}function iv(e){let{host:t,session:n,display:r,listItem:i=!0,icon:a}=e,o=t.readSessionMutationAccess({method:`sessions.patch`,params:{key:n.key,pinned:!n.pinned},sessionScope:!0,session:n}),s=t.readSessionMutationAccess({method:`sessions.patch`,params:{key:n.key,archived:!n.archived},sessionScope:!0,session:n}),c=n.archived||ht(n,$t({agentsList:t.sessionDataContext?.agents.state.agentsList,hello:t.sessionDataContext?.gateway.snapshot.hello})),l=t.sessionDataContext?.sessions.archiveVisibility(n.key)===`pending`,u=t.sidebarAgentsMode===`roster`,d=n.ownAttention??n.attention,f=n.label,{subtitle:p,narration:m}=t.sessionProjection.resolveSubtitle({session:n,hasDisplay:r!==void 0,displaySubtitle:r?.subtitle,sidebarLiveActivity:t.sidebarLiveActivity,showPreview:t.sessionsShowPreview,narrationLine:t.sidebarNarrationLines.get(n.key),observerDigest:t.sidebarObserverDigests.get(n.key)??null}),h=rv(t,n,r,a),{running:g,stateId:_,metaId:v,pullRequest:y,persistentIndicator:b,childrenExpanded:x}=h,S=e=>Mn(e,e.currentTarget.querySelector(`.sidebar-recent-session__link`),(e,i,a)=>{if(r?.catalogMenu){t.sidebarMenus.catalogMenu.open(r.catalogMenu,i,a,e??void 0);return}t.sidebarMenus.openSessionMenu(n,i,a,e)}),ee=j(n.pinned?`sessionsView.unpinSession`:`sessionsView.pinSession`),C=j(n.archived?`sessionsView.restoreSession`:`sessionsView.archiveSession`),te=r?.catalogMenu?t.sidebarMenus.catalogMenu.isOpenFor(r.catalogMenu.key):t.sidebarMenus.sessionMenu?.session.key===n.key,ne=Ja(n.color??``),re=[`sidebar-recent-session`,`session-row-host`,u?`sidebar-recent-session--team`:``,ne?`sidebar-recent-session--colored`:``,n.isChild?`sidebar-recent-session--child`:``,u||!p&&!n.channelPresentation?`sidebar-recent-session--single-line`:``,n.archived?`sidebar-session--archived`:``,n.visuallyActive?`sidebar-recent-session--active`:``,t.selectedSessionKeys.has(n.key)?`sidebar-recent-session--selected`:``,n.pinned?`session-row-host--pinned`:``,g?`session-row-host--running`:``,n.visibility===`draft`?`session-row-host--draft`:``,n.visibility===`draft`?n.draftOwnedBySelf?`session-row-host--draft-owner`:`session-row-host--draft-other`:``,(u?d:n.attention).kind===`error`?`sidebar-recent-session--attention-danger`:(u?d:n.attention).kind!==`none`&&(u?d:n.attention).kind!==`question`?`sidebar-recent-session--attention-amber`:``,t.sessionOrganizer.draggingSessionKey===n.key?`sidebar-recent-session--dragging`:``].filter(Boolean).join(` `),ie=t.readSessionMutationAccess({method:`sessions.groups.put`,requiredScope:`operator.write`}),ae=!n.isChild&&ie.allowed,oe=ic(R`${u?z:h.originIndicators}${f}`,`sidebar-recent-session__name`),se=r?Ca(JSON.stringify([f,n.archived===!0,n.forkSource!==void 0,y]),oe):oe,ce=R`
    <div
      ${r?.rowRef?la(r.rowRef):z}
      class=${re}
      style=${ne?`--session-color: var(--session-color-${ne})`:z}
      data-session-key=${n.key}
      data-catalog-session-key=${r?.catalogIdentityKey??z}
      role=${ha(i?`listitem`:void 0)}
      draggable=${ae?`true`:`false`}
      @dragstart=${ae?e=>{e.dataTransfer&&(Do(e.dataTransfer,n.key),t.sessionOrganizer.startSessionDrag(n))}:z}
      @dragend=${ae?()=>{t.sessionOrganizer.finishSessionDrag()}:z}
      @contextmenu=${S}
      @keydown=${S}
    >
      <a
        href=${t.sidebarSessionHref(n)}
        class="sidebar-recent-session__link"
        draggable="false"
        aria-current=${n.visuallyActive?`page`:z}
        aria-describedby=${[_,v].filter(Boolean).join(` `)||z}
        @click=${e=>t.handleSessionRowClick(e,n)}
      >
        ${b}
        <span class="sidebar-recent-session__text">
          <span class="sidebar-recent-session__title-row"> ${se} </span>
          <span class="sidebar-recent-session__details">
            ${n.channelPresentation?R`<span class="sidebar-recent-session__channel">
                    <span class="sr-only"
                      >${j(`sessionHovercard.linkedChannel`,{channel:n.channelPresentation.channelLabel})}</span
                    >
                    <span aria-hidden="true">${n.channelPresentation.channelLabel}</span>
                  </span>`:z}
            ${u?z:Q_({subtitle:p,narration:m})}
            ${h.content}
          </span>
        </span>
      </a>
      ${n.childSessionKeys.length>0?R`<button
              class="sidebar-child-session-toggle ${!u&&n.runningChildCount>0?`sidebar-child-session-toggle--running`:!u&&n.failedChildCount>0?`sidebar-child-session-toggle--failed`:``}"
              type="button"
              data-child-session-toggle=${n.key}
              aria-expanded=${String(x)}
              aria-label=${j(x?`sessionsView.hideChildSessions`:`sessionsView.showChildSessions`,{count:String(n.childSessionKeys.length),session:f})}
              aria-description=${!u&&!x&&n.runningChildCount>0?j(`sessionsView.activeRun`):z}
              @click=${()=>t.toggleSessionChildren(n)}
            >
              <span class="sidebar-child-session-toggle__icon" aria-hidden="true"
                >${x?I.chevronDown:I.chevronRight}</span
              >
              ${x||u?z:R`<span class="sidebar-child-session-toggle__count"
                      >${n.childSessionKeys.length}</span
                    >`}
            </button>`:z}
      <span class="sidebar-recent-session__aside session-row-aside">
        <span class="session-row-actions">
          ${n.pinnable?R`<button
                  class="session-action session-action--pin"
                  data-sidebar-session-pin="true"
                  type="button"
                  title=${o.allowed?ee:o.reason}
                  aria-label=${ee}
                  ?disabled=${!o.allowed}
                  @click=${()=>t.toggleSessionPin(n)}
                >
                  ${I.pin}
                </button>`:z}
          <openclaw-tooltip
            .content=${s.allowed?C:s.reason}
            .describe=${!1}
          >
            <button
              class="session-action"
              data-sidebar-session-archive="true"
              type="button"
              aria-label=${`${C}: ${f}`}
              ?disabled=${!s.allowed||!c||l}
              @click=${e=>{e.stopPropagation(),n.archived?t.sessionOrganizer.patchSession(n,{archived:!1},{sessionScope:!0}):t.sessionOrganizer.archiveSessionWithUndo(n)}}
            >
              ${n.archived?I.archiveRestore:I.archive}
            </button>
          </openclaw-tooltip>
          <button
            class="session-action session-action--touch-menu"
            data-sidebar-session-menu="true"
            type="button"
            title=${j(`chat.sidebar.openSessionMenu`)}
            aria-label=${`${j(`chat.sidebar.openSessionMenu`)}: ${f}`}
            aria-haspopup="menu"
            aria-expanded=${String(te)}
            @click=${e=>{e.stopPropagation(),t.toggleSessionMenu(n,e.currentTarget,r?.catalogMenu)}}
          >
            ${I.moreHorizontal}
          </button>
        </span>
      </span>
    </div>
  `;return Ca(n.key,ce)}function av(e,t){let n=e.sessionData.childSessionErrorsByParent.get(t);return n?R`<div
    class="sidebar-session-error callout danger"
    data-child-session-error=${t}
    role="alert"
  >
    <span>${n}</span>
    <button
      class="sidebar-session-tree__show-more"
      type="button"
      data-retry-child-sessions=${t}
      @click=${()=>e.sessionData.retryChildSessions(t)}
    >
      ${j(`common.retry`)}
    </button>
  </div>`:z}function ov(e){let{host:t,session:n,listItem:r=!0,icon:i}=e,a=t.isSessionChildrenExpanded(n),o=nv({session:n,fullyShown:t.isSessionChildrenFullyShown(n.key)}),s=n.children.length-o.length;return R`<div
    class="sidebar-session-tree"
    data-session-tree=${n.key}
    role=${ha(r?`listitem`:void 0)}
  >
    ${iv({host:t,session:n,listItem:!1,icon:i})}
    ${a?R`<div class="sidebar-session-tree__children">
            ${o.length>0?R`<div
                    class="sidebar-session-tree__list"
                    role=${ha(r?`list`:void 0)}
                    aria-label=${ha(r?j(`sessionsView.childSessions`):void 0)}
                  >
                    ${va(o,e=>e.key,e=>ov({host:t,session:e,listItem:r}))}
                  </div>`:z}
            ${s>0?R`<button
                    class="sidebar-session-tree__show-more"
                    type="button"
                    data-show-more-children=${n.key}
                    aria-label=${j(`sessionsView.showMoreChildren`,{count:String(s)})}
                    @click=${()=>t.showMoreChildren(n.key)}
                  >
                    ${j(`sessionsView.showMoreChildren`,{count:String(s)})}
                  </button>`:z}
            ${(n.childLoadParentKeys??[n.key]).map(e=>av(t,e))}
            ${n.loadingChildren&&n.children.length===0?R`<span
                    class="sidebar-session-tree__loading skeleton skeleton-line skeleton-line--medium"
                    role="status"
                    aria-busy="true"
                    aria-label=${j(`common.loading`)}
                  ></span>`:z}
          </div>`:z}
  </div>`}var sv;function cv(){return(cv=e((()=>{B(),ca(),Ea(),da(),Oa(),Qa(),Jr(),F(),us(),zo(),an(),No(),Cc(),N(),K(),L(),C_(),X_(),Yp(),$_(),tv(),ta(),sv=4})))()}function lv(e,t){return t.size===0?e:e.map(e=>({...e,hosts:e.hosts.map(n=>({...n,sessions:n.sessions.filter(r=>!t.has(Rn({catalogId:e.id,hostId:n.hostId,threadId:r.threadId})))}))}))}function uv(){return{code:`PAGINATION_FAILED`,message:j(`chat.sidebar.catalogPaginationFailed`)}}function dv(){return{code:`PAGINATION_FAILED`,message:j(`chat.sidebar.catalogPageMissingHost`)}}function fv(e){return{code:e instanceof Xn?e.gatewayCode:`UNAVAILABLE`,message:E(e)}}function pv(e,t){let n=new Set(e.map(e=>e.threadId));return[...e,...t.filter(e=>!n.has(e.threadId))]}function mv(e,t){if(!t)return e;let{sessions:n,nextCursor:r,...i}=e,{nextCursor:a,pending:o,...s}=t;return{...s,...i,...a===void 0?{}:{nextCursor:a}}}function hv(e){let{page:t}=e;if(!t)return{catalog:{...e.current,error:dv()},advancedHostIds:[],repeatedHostIds:[]};let n=new Map(t.hosts.map(e=>[e.hostId,e])),r=[],i=[],a=e.current.hosts.map(a=>{let o=e.cursors[a.hostId],s=n.get(a.hostId);if(t.error||o===void 0||a.nextCursor!==o)return a;if(!s)return{...a,error:dv()};if(s.error)return mv(s,a);let{nextCursor:c,sessions:l,error:u,...d}=s,f=c===o||c!==void 0&&e.previousCursors?.get(a.hostId)?.has(c);f?i.push(a.hostId):r.push(a.hostId);let{nextCursor:p,error:m,pending:h,...g}=a;return{...g,...d,sessions:pv(a.sessions,l),...c?{nextCursor:c}:{},...f?{error:uv()}:{}}}),{hosts:o,error:s,...c}=e.current,{hosts:l,error:u,...d}=t;return{catalog:{...c,...d,hosts:a,...u?{error:u}:{}},advancedHostIds:r,repeatedHostIds:i}}async function gv(e){let t=new Map(e.previousCatalogs.map(e=>[e.id,e]));return Promise.all(e.catalogs.map(async n=>{let r=new Map(t.get(n.id)?.hosts.map(e=>[e.hostId,e])??[]),i=await Promise.all(n.hosts.map(async t=>{let i=e.pageDepths.get(Gg(n.id,t.hostId))??0;if(i===0||t.pending)return t;let a=r.get(t.hostId);if(t.error||n.error)return mv({...t,error:t.error??n.error},a);let o=t.sessions,s=t.nextCursor,c=e=>mv({...t,error:e},a??{...t,sessions:o,nextCursor:s}),l=new Set;for(let r=0;r<i&&s;r+=1){if(!e.canRequestPage())return mv(t,a);l.add(s);let r;try{r=await e.client.request(`sessions.catalog.list`,{agentId:e.agentId,catalogId:n.id,hostIds:[t.hostId],cursors:{[t.hostId]:s}})}catch(e){return c(fv(e))}if(!e.isCurrent())return a??t;let i=r.catalogs.find(e=>e.id===n.id),u=i?.hosts.find(e=>e.hostId===t.hostId);if(i?.error)return c(i.error);if(!u)return c(dv());if(u.error)return mv({...t,...u},a??t);if(o=pv(o,u.sessions),s=u.nextCursor,s&&l.has(s))return c(uv())}let{nextCursor:u,sessions:d,...f}=t;return{...f,sessions:o,...s?{nextCursor:s}:{}}}));return{...n,hosts:i}}))}function _v(){return(_v=e((()=>{li(),F(),P(),Ue(),K()})))()}function vv(e,t){return!t||e?.phase!==`connected`||!e.client||oo(e,`sessions.catalog.list`)!==!0?null:e.client}function yv(e){let t=C(e),n=C(t?.catalog),r=Array.isArray(n?.hosts)?n.hosts:[],i=C(r[0]);return!!(t&&n&&i&&typeof t.progressId==`string`&&t.progressId.length>0&&typeof t.agentId==`string`&&t.agentId.length>0&&typeof n.id==`string`&&typeof n.label==`string`&&n.capabilities!==null&&typeof n.capabilities==`object`&&r.length===1&&typeof i.hostId==`string`&&Array.isArray(i.sessions))}async function bv(e){let{live:t,client:n,generation:r,revision:i}=e;if(t.requestGeneration===r)return;if(t.retryDelayMs>0){t.schedule(t.retryDelayMs,e.connected(),()=>void e.refresh());return}let{progressId:a,progressSequence:o,requestOwner:s}=t.beginRequest(r),c=null,l=null,u=()=>t.ownsRequest(s)&&r===e.currentGeneration()&&n===e.currentClient(),d=()=>u()&&i===e.currentRevision();try{let r=await n.request(`sessions.catalog.list`,{agentId:e.agentId,limitPerHost:40,progressId:a,allowPartialResults:!0});if(!u()||!r?.catalogs)return;c=t.beginRefetch(e.pageDepths.size>0);let i=e.catalogs(),s=await gv({catalogs:t.mergeFinal(r.catalogs,i),previousCatalogs:i,client:n,agentId:e.agentId,pageDepths:e.pageDepths,isCurrent:d,canRequestPage:()=>d()&&document.visibilityState!==`hidden`});if(!d())return;t.resetRetry(),e.applyFinal(s,new Set([...e.catalogs(),...s].map(e=>e.id))),t.markFinal({catalogs:s,progressSequence:o}),t.endRefetch(c),c=null,await e.continueRefresh()}catch(n){d()&&(l=t.retryRequest(n),l===null&&(t.warnRequestError(n),e.applyError(n)))}finally{t.endRefetch(c);let n=t.ownsRequest(s);if(n&&(t.requestGeneration=null),n&&u()&&e.connected()){let n=t.refreshPending;t.refreshPending=!1;let r=l??(e.catalogChangedEvents?xv:Sv);t.schedule(r,e.connected(),()=>{e.refresh()}),n&&l===null&&t.scheduleActivation(e.refresh)}}}var xv,Sv,Cv,wv;function Tv(){return(Tv=e((()=>{li(),P(),En(),so(),Jt(),N(),l(),_v(),K(),xv=6e5,Sv=3e4,Cv=3,wv=class{constructor(){this.refreshScope={},this.timer=null,this.requestGeneration=null,this.refreshPending=!1,this.discoveryPages=new Map,this.activationRefresh=null,this.eventRefresh=Wt({active:!0,refresh:async()=>{let e=this.activationRefresh;this.activationRefresh=null,await e?.()}}),this.refetchOwner=null,this.progressSequence=0,this.progressSequences=new Map,this.hostProgressSequences=new Map,this.knownHostKeys=new Set,this.requestChangedHostKeys=new Set,this.warnedRequestErrors=new Set,this.requestOwner=null,this.retryAttempts=0,this.retryAt=0}get retryDelayMs(){return Math.max(0,this.retryAt-Date.now())}resetRetry(){this.retryAttempts=0,this.retryAt=0}retryRequest(e){if(!(e instanceof Xn)||!e.retryable||pn(e,null)||this.retryAttempts>=Cv)return this.resetRetry(),null;let t=typeof e.retryAfterMs==`number`&&Number.isFinite(e.retryAfterMs)?e.retryAfterMs:0,n=Math.max(t,1e3*2**this.retryAttempts++);return this.retryAt=Date.now()+n,n}cancelTimer(){let e=this.timer;e!==null&&(globalThis.clearTimeout(e),this.timer=null)}clear(){this.refreshScope={},this.cancelScheduledRefreshes(),this.resetRetry(),this.requestGeneration=null,this.requestOwner=null,this.progressSequence=0,this.progressSequences.clear(),this.hostProgressSequences.clear(),this.knownHostKeys.clear(),this.requestChangedHostKeys.clear(),this.refreshPending=!1,this.discoveryPages.clear(),this.refetchOwner=null}resumeDiscovery(e){let t=new Set,n=e.map(e=>({...e,hosts:e.hosts.map(n=>{let r=Gg(e.id,n.hostId);t.add(r);let i=this.discoveryPages.get(r);return!i||n.pending||n.error||e.error?n:n.sessions.length>0||n.nextCursor!==i.headCursor?(this.discoveryPages.delete(r),n):{...n,nextCursor:i.nextCursor}})}));for(let e of this.discoveryPages.keys())t.has(e)||this.discoveryPages.delete(e);return n}mergeFinal(e,t){let n=new Map(t.flatMap(e=>e.hosts.map(t=>[Gg(e.id,t.hostId),t])));return e.map(e=>({...e,hosts:e.hosts.map(t=>{let r=Gg(e.id,t.hostId),i=n.get(r);return t.pending?this.requestChangedHostKeys.has(r)&&i&&!i.pending?i:mv(t,i):t.error&&this.requestChangedHostKeys.has(r)&&i&&!i.error?i:t})}))}get refetching(){return this.refetchOwner!==null}get hasRequested(){return this.progressSequence>0}beginRefetch(e){if(!e)return null;let t=Symbol(`session-catalog-refetch`);return this.refetchOwner=t,t}endRefetch(e){e!==null&&this.refetchOwner===e&&(this.refetchOwner=null)}beginRequest(e){this.eventRefresh.absorb(),this.activationRefresh=null,this.requestGeneration=e;let t=Symbol(`session-catalog-request`);this.requestOwner=t,this.requestChangedHostKeys.clear();let n=ee(),r=++this.progressSequence;if(this.progressSequences.set(n,r),this.progressSequences.size>8){let e=this.progressSequences.keys().next().value;e&&this.progressSequences.delete(e)}return{progressId:n,progressSequence:r,requestOwner:t}}ownsRequest(e){return this.requestOwner===e}warnRequestError(e){let t=`${e instanceof Xn?e.gatewayCode:`UNAVAILABLE`}\u0000${E(e)}`;this.warnedRequestErrors.has(t)||(this.warnedRequestErrors.add(t),console.warn(`Session catalog refresh failed`,e))}markFinal(e){let t=new Set;for(let n of e.catalogs)for(let r of n.hosts){let i=Gg(n.id,r.hostId);t.add(i),!r.error&&this.hostProgressSequences.set(i,Math.max(this.hostProgressSequences.get(i)??-1,e.progressSequence))}for(let n of this.knownHostKeys)t.has(n)||this.hostProgressSequences.set(n,e.progressSequence);this.knownHostKeys=t}applyHost(e){if(!yv(e.payload))return null;let t=e.payload;if(b(t.agentId)!==b(e.agentId))return null;let n=this.progressSequences.get(t.progressId),r=t.catalog.hosts[0];if(n===void 0||!r)return null;let i=Gg(t.catalog.id,r.hostId);if(n<(this.hostProgressSequences.get(i)??-1))return null;this.hostProgressSequences.set(i,n),this.requestGeneration!==null&&this.requestChangedHostKeys.add(i);let a=e.catalogs.find(e=>e.id===t.catalog.id),o,s;if(!a)s={...t.catalog,hosts:[r]},o=[...e.catalogs,s].toSorted((e,t)=>e.id.localeCompare(t.id));else{let n=a.hosts.find(e=>e.hostId===r.hostId),c=this.discoveryPages.get(i);c&&!r.pending&&!r.error&&(r.sessions.length>0||r.nextCursor!==c.headCursor)&&this.discoveryPages.delete(i);let l=r.pending||(e.pageDepths.get(i)??0)>0||this.discoveryPages.has(i)?mv(r,n):r,u=n?a.hosts.map(e=>e.hostId===r.hostId?l:e):[...a.hosts,l];s={...t.catalog,hosts:u.toSorted((e,t)=>e.label.localeCompare(t.label))},o=e.catalogs.map(e=>e.id===t.catalog.id?s:e)}let c=a?.hosts.find(e=>e.hostId===r.hostId),l=s.hosts.find(e=>e.hostId===r.hostId);return a!==void 0&&a.label===s.label&&JSON.stringify(a.capabilities)===JSON.stringify(s.capabilities)&&JSON.stringify(a.error)===JSON.stringify(s.error)&&JSON.stringify(c)===JSON.stringify(l)?null:{catalogs:o,catalogId:t.catalog.id}}schedule(e,t,n){document.visibilityState!==`hidden`&&t&&(this.cancelTimer(),this.timer=globalThis.setTimeout(()=>{this.timer=null,n()},e))}async requestRefresh(e){e.visible&&e.connected&&(this.cancelTimer(),this.requestGeneration===e.generation&&(this.refreshPending=!0),await e.refresh())}cancelActivation(){this.eventRefresh.reset(),this.activationRefresh=null}cancelScheduledRefreshes(){this.cancelTimer(),this.cancelActivation()}scheduleActivation(e){this.activationRefresh=e,this.eventRefresh.schedule()}}})))()}function Ev(){return{error:null,hasLoaded:!1,stale:!1,awaitingGateway:!1}}function Dv(e,t){return{...e,error:t?.clearError===!1?e.error:null}}function Ov(){return{error:null,hasLoaded:!0,stale:!1,awaitingGateway:!1}}function kv(e,t,n){let r=pn(t,n);return{error:r?null:E(t),hasLoaded:e.hasLoaded,stale:e.hasLoaded,awaitingGateway:r}}function Av(e){let{status:t}=e;if(t.awaitingGateway)return z;let n=e.errorMessage??t.error,r=n&&E(n);if(!r&&!t.stale)return z;let i=e.className?` ${e.className}`:``;return R`
    <div
      class="callout ${r?`danger`:`warn`}${i}"
      role=${r?`alert`:`status`}
    >
      ${r?R`<span>${r}</span>`:z}
      ${r&&t.stale?R`<br />`:z}
      ${t.stale?R`<strong>${j(`common.staleData`)}</strong>`:z}
    </div>
  `}function jv(){return(jv=e((()=>{B(),F(),P(),En()})))()}function Mv(e){let t=e.sessionCatalogRefreshStatus;return!t.error&&(oo(e.context?.gateway.snapshot??{},`sessions.catalog.list`)!==!0||t.hasLoaded&&!t.awaitingGateway&&e.sessionCatalogLive.requestGeneration===null&&e.loadingMoreSessionCatalogIds.size===0&&e.sessionCatalogs.every(e=>!e.error&&e.hosts.every(e=>!e.pending&&!e.error&&!e.nextCursor)))}function Nv(e){return document.visibilityState===`hidden`?null:vv(e.context?.gateway.snapshot,e.sessionDataHostConnected)}function Pv(e){let t=e.context;if(!t)return Promise.resolve();let n=e.sessionCatalogLive.refreshScope;return t.connectionBootstrap.run(n,async()=>{e.context===t&&e.sessionCatalogLive.refreshScope===n&&e.isSessionDataHostConnected&&await e.refreshSessionCatalogs()},{background:!0})}function Fv(e,t=e.expandedAgentId()){let n=e.context,r=n?.gateway.snapshot;if(r?.phase===`connected`&&oo(r,`sessions.catalog.list`)===!1)return null;let i=n?.agents.state,a=r?.phase===`connected`&&r.client&&i?.connected&&i.client===r.client?i.agentsList:null;if(a){let e=n?n.agentSelection.state.selectedId:t,r=e?.trim()?b(e):null;if(r&&a.agents.some(e=>b(e.id)===r))return r;let i=b(a.defaultId);return a.agents.some(e=>b(e.id)===i)?i:null}if(r?.phase!==`connected`||!r.hello||!r.assistantAgentId)return null;let o=b(r.assistantAgentId),s=n?.agentSelection.state.selectedId,c=s?.trim()?b(s):null;return c&&c!==o?null:o}function Iv(e){if(document.visibilityState===`hidden`){e.sessionCatalogLive.cancelScheduledRefreshes();return}e.sessionCatalogLive.scheduleActivation(()=>Lv(e))}function Lv(e){let t=e.context?.gateway.snapshot;return e.sessionCatalogLive.requestRefresh({visible:document.visibilityState!==`hidden`,connected:e.isSessionDataHostConnected&&e.sessionCatalogAgentId!==null&&!!vv(t,e.sessionDataHostConnected),generation:e.sessionScopeGeneration,refresh:()=>Pv(e)})}function Rv(e){e.context&&e.synchronizeSessionScope(),Nv(e)&&!e.sessionCatalogLive.hasRequested&&e.sessionCatalogLive.requestGeneration!==e.sessionScopeGeneration&&Pv(e)}function zv(e){return e.context?.gateway.snapshot.hello?.features?.events?.includes(`sessions.catalog.changed`)===!0}function Bv(e,t){if(!zv(e))return;let n=C(t)?.agentId;(typeof n!=`string`||b(n)===e.sessionCatalogAgentId)&&Iv(e)}function Vv(e,t){let n=e.sessionCatalogLive.applyHost({payload:t,agentId:e.sessionCatalogAgentId??``,catalogs:e.sessionCatalogs,pageDepths:e.sessionCatalogPageDepths});if(!n)return;e.sessionCatalogs=n.catalogs,e.requestSessionDataUpdate(),e.sessionCatalogRevision+=+!!e.sessionCatalogLive.refetching;let r=e.sessionCatalogRevisions.get(n.catalogId)??0;e.sessionCatalogRevisions.set(n.catalogId,r+1)}function Hv(e,t){let n=typeof t?.agentId==`string`?t.agentId.trim():``,r=n?b(n):null,i=e.sessionCatalogAgentId?b(e.sessionCatalogAgentId):null;t?.sessionKey&&r&&r===i&&(e.sessionCatalogLive.discoveryPages.clear(),e.sessionCatalogs=gp(e.sessionCatalogs,t),e.requestSessionDataUpdate(),e.sessionCatalogRevision+=1,e.sessionCatalogRevisions.set(t.catalogId,(e.sessionCatalogRevisions.get(t.catalogId)??0)+1))}async function Uv(e){e.synchronizeSessionScope();let t=e.sessionCatalogAgentId,n=Nv(e);if(!n||!t)return;let r=e.sessionScopeGeneration,i=e.sessionCatalogRevision;e.requestSessionDataUpdate(),await bv({live:e.sessionCatalogLive,client:n,agentId:t,generation:r,revision:i,currentGeneration:()=>e.sessionScopeGeneration,currentRevision:()=>e.sessionCatalogRevision,currentClient:()=>e.sessionCatalogGatewayClient(),catalogs:()=>e.sessionCatalogs,pageDepths:e.sessionCatalogPageDepths,connected:()=>e.isSessionDataHostConnected,catalogChangedEvents:zv(e),applyFinal:(t,n)=>{e.sessionCatalogs=e.sessionCatalogLive.resumeDiscovery(t),e.sessionCatalogRefreshStatus=Ov(),e.requestSessionDataUpdate();for(let t of n)e.sessionCatalogRevisions.set(t,(e.sessionCatalogRevisions.get(t)??0)+1);e.sessionCatalogRevision+=1},continueRefresh:()=>Gv(e),applyError:t=>{e.sessionCatalogRefreshStatus=kv(e.sessionCatalogRefreshStatus,t,e.context?.gateway.snapshot),e.requestSessionDataUpdate()},refresh:()=>Pv(e)}),e.requestSessionDataUpdate()}function Wv(e){let t=new Set(e.sessionCatalogIdsWithoutVisibleRows());return e.sessionCatalogs.flatMap(e=>{if(!t.has(e.id)||e.error)return[];let n=e.hosts.filter(e=>e.nextCursor&&!e.pending&&!e.error).map(e=>e.hostId);return n.length>0?[{catalogId:e.id,hostIds:n}]:[]})}async function Gv(e){let t=e.sessionScopeGeneration,n=Nv(e);if(n&&e.isSessionDataHostConnected)for(;t===e.sessionScopeGeneration&&n===Nv(e)&&e.isSessionDataHostConnected;){let t=Wv(e);if(t.length===0)return;let n=e.sessionCatalogRevision;if(await Promise.all(t.map(({catalogId:t,hostIds:n})=>qv(e,t,n,!0))),n===e.sessionCatalogRevision)return}}function Kv(e){e.sessionCatalogLive.clear(),e.sessionCatalogRevision+=1;for(let{id:t}of e.sessionCatalogs)e.sessionCatalogRevisions.set(t,(e.sessionCatalogRevisions.get(t)??0)+1);Lv(e)}async function qv(e,t,n,r=!1){if(e.loadingMoreSessionCatalogIds.has(t))return;let i=e.sessionCatalogs.find(e=>e.id===t),a=Object.fromEntries((i?.hosts??[]).flatMap(e=>e.nextCursor&&(!n||n.includes(e.hostId))?[[e.hostId,e.nextCursor]]:[]));if(!i||Object.keys(a).length===0)return;let o=e.context?.gateway.snapshot.client,s=Fv(e);if(!o||!e.sessionDataHostConnected||!s||s!==e.sessionCatalogAgentId)return;let c=e.sessionScopeGeneration,l=e.sessionCatalogRevisions.get(t)??0;e.loadingMoreSessionCatalogIds=new Set([...e.loadingMoreSessionCatalogIds,t]),e.requestSessionDataUpdate();try{let n=await o.request(`sessions.catalog.list`,{agentId:s,catalogId:t,hostIds:Object.keys(a),cursors:a});if(!Jv(e,t,o,c,l))return;let i=n.catalogs.find(e=>e.id===t),u=e.sessionCatalogs.find(e=>e.id===t);if(!u)return;let d=e.sessionCatalogLive.discoveryPages,f=hv({current:u,page:i,cursors:a,previousCursors:new Map(u.hosts.flatMap(e=>{let n=d.get(Gg(t,e.hostId));return n?[[e.hostId,n.cursors]]:[]}))});for(let e of f.repeatedHostIds)d.delete(Gg(t,e));for(let[n,i]of Object.entries(a)){if(!f.advancedHostIds.includes(n))continue;let a=Gg(t,n),o=d.get(a),s=u.hosts.find(e=>e.hostId===n),c=f.catalog.hosts.find(e=>e.hostId===n),l=(o?.depth??e.sessionCatalogPageDepths.get(a)??0)+1;if(r&&s?.sessions.length===0&&c?.sessions.length===0&&!e.sessionCatalogPageDepths.has(a)){if(c.nextCursor){let e=o?.cursors??new Set;e.add(i),d.set(a,{headCursor:o?.headCursor??i,nextCursor:c.nextCursor,depth:l,cursors:e})}else d.delete(a)}else d.delete(a),e.sessionCatalogPageDepths.set(a,l)}e.sessionCatalogs=e.sessionCatalogs.map(e=>e.id===t?f.catalog:e),e.requestSessionDataUpdate(),e.sessionCatalogRevisions.set(t,l+1),e.sessionCatalogRevision+=1}catch(n){if(!Jv(e,t,o,c,l))return;e.sessionCatalogs=e.sessionCatalogs.map(e=>e.id===t?{...e,error:fv(n)}:e),e.requestSessionDataUpdate(),e.sessionCatalogRevisions.set(t,l+1),e.sessionCatalogRevision+=1}finally{if(c===e.sessionScopeGeneration){let n=new Set(e.loadingMoreSessionCatalogIds);n.delete(t),e.loadingMoreSessionCatalogIds=n,e.requestSessionDataUpdate()}}}function Jv(e,t,n,r,i){return r===e.sessionScopeGeneration&&i===(e.sessionCatalogRevisions.get(t)??0)&&n===e.sessionCatalogGatewayClient()}async function Yv(e,t,n){let r=t.catalogGeneration,i=Rn(n);e.pendingCatalogArchives.add(i),e.requestSessionDataUpdate();try{await t.client.request(`sessions.catalog.archive`,n),r===e.sessionScopeGeneration&&e.isSessionMutationScopeCurrent(t)&&(e.sessionCatalogs=lv(e.sessionCatalogs,new Set([i])),e.invalidateSessionCatalogs())}finally{r===e.sessionScopeGeneration&&(e.pendingCatalogArchives.delete(i),e.requestSessionDataUpdate())}}function Xv(){return(Xv=e((()=>{so(),Ue(),N(),Tv(),_v(),_p(),K(),jv()})))()}function Zv(e){let{host:t,section:n,personHeaders:r}=e,i=n.totalRowCount,a=n.category,o=n.personOwner,s=o?.identity,c=s?.type===`profile`?r?.presence.get(s.id):void 0,l=o&&s?.type===`profile`&&s.id!==r?.selfProfileId,u=l?ml({id:o.id,identity:s}):void 0,d=c?Bo(c):void 0,f=c&&s?`sidebar-person-presence-${s.id}`:void 0,p=n.renderHeader&&t.collapsedSessionSections.has(n.id),m=o?s?.type===`profile`?ss({id:s.id,name:o.label||o.id}):o.label||o.id:n.project?n.project.name:n.groups?j(`chat.sidebar.groups`):n.work?j(`chat.sidebar.coding`):a||j(`chat.sidebar.otherSessions`),h=o?`person`:n.project?`project`:n.groups?`groups`:n.work?`coding`:a?`category`:`threads`,g=t.sessionOwnerFilterActive&&t.sessionOwnerFilterId===o?.id,_=g?j(`chat.sidebar.showEveryone`):j(`chat.sidebar.showOnlyPerson`,{name:m}),v=p&&n.work&&n.rows.some(e=>gg(e,qg.ActiveRun)),y=p&&n.rows.some(e=>gg(e,qg.Attention)),b=t.readNewSessionAccess(),x=t.readSessionMutationAccess({method:`sessions.groups.put`,requiredScope:`operator.write`}),S=!!(o||n.project||n.id.startsWith(`agent:`)),ee=x.allowed&&!S,C=[`sidebar-recent-sessions__group`,`sidebar-recent-sessions__group--zone-${h}`,p?`sidebar-recent-sessions__group--collapsed`:``,t.sessionOrganizer.draggingSidebarSection===n.id?`sidebar-recent-sessions__group--dragging`:``,t.sessionOrganizer.sessionDropTarget===n.id?`sidebar-recent-sessions__group--session-drop`:``,t.sessionOrganizer.sidebarSectionDropTarget?.sectionId===n.id?`sidebar-recent-sessions__group--section-drop-${t.sessionOrganizer.sidebarSectionDropTarget.position}`:``].filter(Boolean).join(` `),te=R`<span class="sidebar-session-group-toggle__lead" aria-hidden="true">
    <span class="sidebar-session-group-toggle__icon"
      >${p?I.chevronRight:I.chevronDown}</span
    >
  </span>`,ne=o?R`<span class="sidebar-session-group-toggle__person"
        ><openclaw-viewer-avatar
          .identity=${o.identity}
          .user=${{id:o.id,name:o.label,avatarUrl:o.avatarUrl,watchedSessions:[]}}
          .markAsViewer=${!1}
          variant="session"
          aria-hidden="true"
        ></openclaw-viewer-avatar>
        ${c?R`<span
                id=${f??z}
                class="sidebar-session-group-presence ${`sidebar-session-group-presence--${c}`}"
                role="img"
                aria-label=${d}
              ></span>`:z}
      </span>`:z,re=ic(m,`sidebar-recent-sessions__label-text`),ie=p&&i>0,ae=ie||v||y?R`${ie?R`<span class="sidebar-session-group-count">${i}</span>`:z}${v?R`<span
                class="session-run-spinner sidebar-session-group-running"
                role="img"
                aria-label=${j(`sessionsView.activeRun`)}
                title=${j(`sessionsView.activeRun`)}
              ></span>`:z}${y?R`<span
                class="sidebar-session-group-attention"
                role="img"
                aria-label=${j(`sessionsView.attentionRequired`)}
                title=${j(`sessionsView.attentionRequired`)}
              ></span>`:z}`:void 0;return R`
    <div
      class=${C}
      data-session-section=${n.id}
      data-zone=${h}
      @dragover=${ee?e=>t.sessionOrganizer.sectionDragOver(e,n.id,a):z}
      @dragleave=${ee?e=>t.sessionOrganizer.sectionDragLeave(e,n.id,a):z}
      @drop=${ee?e=>t.sessionOrganizer.sectionDrop(e,n.id,a):z}
    >
      ${n.renderHeader?bp({sectionId:n.id,status:ae?{content:ae,label:m,expanded:!p,onToggle:()=>t.toggleSection(n.id)}:void 0,draggable:!S,disabledReason:x.allowed?void 0:x.reason,onStartDrag:e=>t.sessionOrganizer.startSidebarSectionDrag(e),onFinishDrag:()=>t.sessionOrganizer.finishSidebarSectionDrag(),reorder:{label:m,onMove:(e,r)=>t.sessionOrganizer.reorderSidebarSection(n.id,e,r)},onContextMenu:a?e=>{e.preventDefault(),t.sidebarMenus.openSessionGroupMenu(a,e.clientX,e.clientY,null)}:void 0,content:R`
                ${l?R`<button
                          type="button"
                          class="sidebar-session-group-toggle sidebar-session-group-toggle--lead"
                          aria-expanded=${String(!p)}
                          aria-label=${m}
                          @click=${()=>t.toggleSection(n.id)}
                        >
                          ${te}
                        </button>
                        <button
                          type="button"
                          class="sidebar-session-group-person"
                          data-person-card
                          data-person-card-key=${u}
                          aria-haspopup="dialog"
                          aria-expanded="false"
                          aria-label=${j(`presence.card.details`,{name:m})}
                          aria-describedby=${f??z}
                        >
                          ${ne}${re}
                        </button> `:R`<button
                        type="button"
                        class="sidebar-session-group-toggle"
                        aria-expanded=${String(!p)}
                        aria-label=${m}
                        title=${n.project?.path??z}
                        @click=${()=>t.toggleSection(n.id)}
                      >
                        ${te}${ne}${re}
                      </button>`}
                ${o&&t.sessionOwnershipVisibility.filters&&t.sessionOwnerOptions.some(e=>e.id===o.id)?R`<button
                        type="button"
                        class="sidebar-session-group-actions sidebar-session-person-filter ${g?`sidebar-session-sort--filtered`:``}"
                        aria-pressed=${g}
                        title=${_}
                        aria-label=${_}
                        @click=${e=>{e.stopPropagation(),t.setSessionOwnerFilter(g?null:o.id)}}
                      >
                        ${I.listFilter}
                      </button>`:z}
                ${a||n.id===`ungrouped`?Qr({basePath:t.basePath,agentId:t.expandedAgentId(),target:{group:a??``},className:`sidebar-session-group-actions sidebar-new-session`,label:j(`sessionsView.newSessionInGroup`,{group:m}),disabledReason:b.allowed?void 0:b.reason,onOpen:(e,n)=>t.requestOpenNewSession(e,n)}):z}
                ${a?R`
                        <button
                          type="button"
                          class="sidebar-session-group-actions"
                          title=${j(`sessionsView.groupMenu`,{group:a})}
                          aria-label=${j(`sessionsView.groupMenu`,{group:a})}
                          aria-haspopup="menu"
                          aria-expanded=${String(t.sidebarMenus.sessionGroupMenu?.group===a)}
                          @click=${e=>{e.stopPropagation();let n=e.currentTarget,r=n.getBoundingClientRect();t.sidebarMenus.openSessionGroupMenu(a,r.right,r.bottom+4,n)}}
                        >
                          ${I.moreHorizontal}
                        </button>
                      `:z}
              `}):z}
      ${p?z:R`
              ${n.rows.length>0?R`<div class="sidebar-recent-sessions__list" role="list" aria-label=${m}>
                      ${va(n.rows,e=>e.key,e=>ov({host:t,session:e}))}
                    </div>`:z}
              ${$v({host:t,section:n})}
            `}
    </div>
  `}function Qv(e,t,n,r){return n?R`
    <div class="sidebar-session-pagination sidebar-session-pagination--roster">
      <button
        type="button"
        class="sidebar-session-pagination__button"
        aria-label=${j(r?`common.loading`:`chat.selectors.loadMoreRosterSessions`)}
        ?disabled=${r}
        aria-busy=${String(r)}
        @click=${()=>{e.sessionData.sessionsLoading||e.sessionData.loadMoreSidebarSessions().then(()=>{for(let n of t)e.setVisibleSessionLimit(n.id,n.visibleLimit+10)})}}
      >
        ${r?R`<span class="session-run-spinner" aria-hidden="true"></span>`:z}
        ${j(r?`common.loading`:`chat.selectors.loadMoreRosterSessions`)}
      </button>
    </div>
  `:z}function $v(e){let{host:t,section:n}=e,r=n.visibleRowCount<n.totalRowCount,i=n.visibleRowCount>30&&n.visibleRowCount>n.collapsedVisibleRowCount;return!r&&!i?z:R`
    <div class="sidebar-session-pagination">
      ${r?R`<button
              type="button"
              class="sidebar-session-pagination__button"
              aria-label=${j(`chat.selectors.loadMoreSessions`)}
              @click=${()=>{t.setVisibleSessionLimit(n.id,n.visibleLimit+10)}}
            >
              ${j(`chat.selectors.loadMoreSessions`)}
            </button>`:z}
      ${i?R`<button
              type="button"
              class="sidebar-session-pagination__button"
              aria-label=${j(`usage.details.collapse`)}
              @click=${()=>{t.clearSessionSelection(),t.setVisibleSessionLimit(n.id,10)}}
            >
              ${j(`usage.details.collapse`)}
            </button>`:z}
    </div>
  `}function ey(e){let{host:t,snapshot:n,catalog:r,renderer:i}=e,a=t.readNewSessionAccess(),o=t.readSessionMutationAccess({method:`sessions.groups.put`,requiredScope:`operator.write`});return R`
    ${i({catalogs:[r],connected:t.connected,basePath:n.basePath,routeSessionKey:n.routeSessionKey,newSessionAgentId:n.newSessionAgentId,mainKey:n.mainKey,collapsedSections:t.collapsedSessionSections,loadingMoreCatalogIds:n.loadingMoreCatalogIds,visibleSessionLimits:t.sessionData.visibleSessionLimits,projectGrouping:n.projectGrouping,liveRows:n.liveRows,renderLiveRow:(e,r)=>iv({host:t,session:n.toSidebarSession(e),display:r}),onToggleSection:e=>t.toggleSection(e),draggingSectionId:t.sessionOrganizer.draggingSidebarSection,sectionDropTarget:t.sessionOrganizer.sidebarSectionDropTarget,onSectionDragOver:(e,n)=>t.sessionOrganizer.sectionDragOver(e,n),onSectionDragLeave:(e,n)=>t.sessionOrganizer.sectionDragLeave(e,n),onSectionDrop:(e,n)=>t.sessionOrganizer.sectionDrop(e,n),onStartSectionDrag:e=>t.sessionOrganizer.startSidebarSectionDrag(e),onFinishSectionDrag:()=>t.sessionOrganizer.finishSidebarSectionDrag(),onReorderSection:(e,n,r)=>t.sessionOrganizer.reorderSidebarSection(e,n,r),viewMenuOpenCatalogId:t.sidebarMenus.catalogViewMenuPosition?.catalogId??null,ownerFilterActive:t.sessionOwnerFilterActive,onOpenViewMenu:(e,n,r)=>{if(r){t.sidebarMenus.openCatalogViewMenu(e,r.x,r.y,n);return}t.sidebarMenus.toggleCatalogViewMenu(e,n)},onLoadMore:e=>void t.sessionData.loadMoreSessionCatalog(e),onSetVisibleSessionLimit:(e,n)=>t.setVisibleSessionLimit(e,n),onOpenNewSession:(e,n)=>t.requestOpenNewSession(e,n),newSessionDisabledReason:a.allowed?void 0:a.reason,sectionDragDisabledReason:o.allowed?void 0:o.reason,onNavigate:t.onNavigate,catalogOpenTarget:n.catalogOpenTarget,terminalAvailable:n.terminalAvailable,onOpenTerminal:(e,n)=>Xo(t,e,n),onOpenMenu:(e,n,r,i)=>t.sidebarMenus.catalogMenu.open(e,n,r,i),onCatalogMenuTriggerRendered:(e,n)=>t.sidebarMenus.catalogMenu.retargetTrigger(e,n),isMenuOpen:e=>t.sidebarMenus.catalogMenu.isOpenFor(e)})}
  `}function ty(e){let{host:t}=e,n;if(t.sessionsGrouping===`person`){let e=Si({snapshotUser:t.sessionDataContext?.gateway.snapshot.selfUser,presenceEntries:Tr(t.sessionData.presencePayload),presenceInstanceId:t.sessionData.presenceInstanceId}),r=new Map;for(let n of Ao(t.sessionData.presencePayload,e,t.sessionData.presenceInstanceId))n.identity?.type===`profile`&&r.set(n.identity.id,ho(n));n={presence:r,selfProfileId:e?.identity?.type===`profile`?e.identity.id:void 0}}let r=new Map(e.catalogs.catalogs.map(e=>[`catalog:${e.id}`,e]));return R`
    ${va(e.sections,e=>e.id,i=>{if(i.id.startsWith(`catalog:`)){let n=r.get(i.id);return n&&e.catalogRenderer?ey({host:t,snapshot:e.catalogs,catalog:n,renderer:e.catalogRenderer}):z}return i.id===`work`&&i.totalRowCount===0||i.id===`ungrouped`&&i.totalRowCount===0&&!e.nativeSessionsHaveMore&&!t.sessionOwnershipVisibility.filters&&t.sessionsStatusFilter===`active`&&t.sessionOrganizer.draggingSessionKey===null?z:Zv({host:t,section:i,personHeaders:n})})}
  `}function ny(e){let{host:t}=e;return ry(t,R`
      <div class="sidebar-recent-sessions">
        ${ty(e)}
        ${Qv(t,e.sections,e.nativeSessionsHaveMore,e.nativeSessionsLoading)}
        ${fg(t,e.empty&&e.sections.every(e=>e.totalRowCount===0),t.connected&&t.sessionData.sessionsResult!==null&&!t.sessionData.sessionsLoading&&!t.sessionData.sessionMutationError&&!e.nativeSessionsHaveMore&&e.catalogs.catalogs.length===0&&Mv(t.sessionData))}
        ${t.sessionsStatusFilter===`archived`&&e.empty?R`<span class="sidebar-session-empty-hint"
                >${j(`sessionsView.noArchivedSessions`)}</span
              >`:z}
      </div>
    `)}function ry(e,t){let n=e.sidebarAgentsMode===`roster`?null:e.mainSessionRow(),r=n?e.projectHomeSession(n,e.expandedAgentId()).childLoadParentKeys:[],i=r?.length?r:n?[n.key]:[];return R`
    <section
      class="sidebar-sessions ${e.sessionOrganizer.sessionListRemovalDrop?`sidebar-sessions--removal-drop`:``}"
      @dragover=${t=>e.sessionOrganizer.handleSessionListDragOver(t)}
      @dragleave=${t=>e.sessionOrganizer.handleSessionListDragLeave(t)}
      @drop=${t=>e.sessionOrganizer.handleSessionListDrop(t)}
    >
      ${e.sidebarAgentsMode===`roster`?z:ug(e)}
      ${i.map(t=>av(e,t))}
      ${dg(e)} ${t}
    </section>
  `}function iy(){return(iy=e((()=>{B(),Oa(),ol(),F(),zo(),No(),hs(),pg(),cv(),xp(),K(),L(),yi(),Xv()})))()}function ay(e){let t=t=>{let n=e.archiveVisibility(t);return e.deletionState(t,e.selectedAgentId)||n===`pending`||e.statusFilter===`active`&&n===`archived`},n=n=>t(n.key)||e.statusFilter===`archived`&&n.archived!==!0,r=b(e.selectedAgentId),i=r===b(e.sessionData.sessionsAgentId??``)?e.sessionData.sessionsResult?.sessions??[]:e.sessionData.sessionResultsByAgent[r]?.sessions??[],a=new Map([...Object.values(e.sessionData.childSessionRowsByParent).flat(),...i].map(e=>[e.key,e])),o=i.filter(e=>!n(e));return{childSessionRowsByParent:Object.fromEntries(Object.entries(e.sessionData.childSessionRowsByParent).map(([e,t])=>[e,t.filter(e=>!n(e))])),isSessionHidden:n,isChildSessionVisible:(r,i,o)=>{let s=o??a.get(i);return(s?n(s):t(i))?!1:e.statusFilter!==`active`||!e.sessionData.loadedChildSessionKeys.has(r)||e.sessionData.loadingChildSessionKeys.has(r)||e.sessionData.childSessionErrorsByParent.has(r)||e.sessionData.childSessionRowsByParent[r]?.some(e=>e.key===i)===!0},rows:o}}function oy(){return(oy=e((()=>{N()})))()}function sy(e){return!e||!no(e.state)||e.state===`failed`&&e.recoveryAction===`restart`?null:{method:`sessions.reclaim`,requiredScope:`operator.write`,blocksActiveRun:e.state===`active`}}function cy(){return(cy=e((()=>{Va()})))()}function ly(e){let t,n;return(r,i)=>{let a=t??=e();if(a.sortMode!==`people`)return a.sortMode===`updated`?At(r,i):uy(r,i,a.createdOrder);let o=r.owner?.actor,s=i.owner?.actor,c=o?.id?.trim()??``,l=s?.id?.trim()??``;if(c!==l){if(!n){n=new Map;for(let e of a.owners??[])n.has(e.id)||n.set(e.id,e.label?.trim())}let e=n.get(c)||o?.label?.trim()||c,t=n.get(l)||s?.label?.trim()||l,r=e.localeCompare(t)||c.localeCompare(l);if(r!==0)return r}return uy(r,i,a.createdOrder)}}function uy(e,t,n){let r=fe(e.createdAt)??null,i=fe(t.createdAt)??null;if(r!==null||i!==null){if(r===null)return 1;if(i===null)return-1;let e=i-r;if(e!==0)return e}return(n.get(e.key)??2**53-1)-(n.get(t.key)??2**53-1)||e.key.localeCompare(t.key)}function dy(e,t){return e.visibility===`draft`&&(e.sharingRole===`owner`||!!(t&&e.createdActor?.id===t))}function fy(e){let{context:t}=e,n=Ft({agentsList:t?.agents.state.agentsList,hello:t?.gateway.snapshot.hello}),r=jt({result:e.sessionsResult,activeSession:e.activeSession,resultAgentId:e.sessionsAgentId,sessionKey:e.routeSessionKey,assistantAgentId:t?.agentSelection.state.selectedId??t?.gateway.snapshot.assistantAgentId,hello:t?.gateway.snapshot.hello,showCron:e.showCron,showSystem:e.showSystem,archivedFilter:e.statusFilter,compareSessions:e.compareSessions});return{routeSessionKey:r.currentSessionKey,selectedAgentId:r.selectedAgentId,activeRowKey:r.activeRowKey,visibleSessionRows:r.visibleSessions,toSidebarSession:(i,a=!1)=>{let o=sn(i.key,i.channel),s=i.runtimeSampledAt;return i.runtimeMs!=null&&s==null&&(s=e.runtimeSampledAtByRow.get(i),s??(s=Date.now(),e.runtimeSampledAtByRow.set(i,s))),{key:i.key,agentId:He(i,n),sessionId:i.sessionId,displayName:i.displayName,incognito:i.incognito===!0,createdActor:i.createdActor,owner:i.owner,participants:i.participants,expandedParticipants:i.expandedParticipants,participantCount:i.participantCount,archivedBy:i.archivedBy,label:lt(i.key,i,{includeSubagentPrefix:!1}),userLabel:i.label,renameValue:Qo(i),subtitle:Je(i),workContext:mt(i),active:i.key===r.activeRowKey,visuallyActive:e.highlightCurrentSession&&i.key===r.currentSessionKey,hasActiveRun:i.archived!==!0&&pe(i),gatewayHasActiveRun:i.hasActiveRun,activeRunIds:i.archived===!0?void 0:i.activeRunIds,modelSelectionLocked:i.modelSelectionLocked===!0,kind:i.kind,pinned:i.pinned===!0,pinnable:rn(i),archived:i.archived===!0,visibility:i.visibility,sharingRole:i.sharingRole,draftOwnedBySelf:dy(i,t?.gateway.snapshot.selfUser?.id),category:Ae(i.category),icon:Ae(i.icon),color:Ae(i.color),channelAvatarUrl:Ae(i.channelAvatarUrl),boardFace:i.boardFace,channel:o.channel,channelSession:o.channelSession,channelPresentation:mo(i),workSession:!!(i.worktree||i.repository||i.execNode)||t?.sessions.isPreparedWorkSession(i.key)===!0,acpSession:An(i.key),worktreeId:i.worktree?.id,workspaceKind:i.worktree?`worktree`:i.repository?`checkout`:void 0,execNode:i.execNode,placementState:i.placement?.state,placementProviderId:i.placement&&`providerId`in i.placement?i.placement.providerId:void 0,placementProfileId:i.placement&&`profileId`in i.placement?i.placement.profileId:void 0,placementMachine:i.placement&&`machine`in i.placement?i.placement.machine:void 0,diskSpaceStatus:i.placement?.state===`active`?i.placement.diskSpace?.status:void 0,workspaceConflictCount:i.placement&&`workspaceResultConflict`in i.placement&&Math.max(i.placement.workspaceResultConflict?.paths.length??0,i.placement.workspaceResultConflict?.totalCount??0)||void 0,cloudWorkerStopAction:sy(i.placement),hasAutomation:i.hasAutomation===!0,pullRequest:t?.sessions.pullRequestSummary(i.key),outboxAttentionCount:e.outboxAttentionCountForSessionKey(i.key),hasComposerDraft:e.hasSessionDraft(i.key),unread:i.archived!==!0&&i.unread===!0,hiddenFromInvolvingMe:i.hiddenFromInvolvingMe,lastMessagePreview:Ae(i.lastMessagePreview),lastReadAt:i.lastReadAt,attention:i.archived===!0?Kg:e.resolveAttention(i),agentStatusNote:e.resolveAgentStatusNote(i),observerDigest:i.observerDigest,spawnedBy:i.spawnedBy,forkSource:i.forkSource,status:i.status,createdAt:i.createdAt,startedAt:i.startedAt,updatedAt:i.updatedAt,endedAt:i.endedAt,runtimeMs:i.runtimeMs,runtimeSampledAt:s,childSessionKeys:i.archived===!0?[]:(i.childSessions??[]).filter(e=>!Lt(e)),children:[],isChild:a,loadingChildren:e.loadingChildSessionKeys.has(i.key),containsActiveDescendant:!1,runningChildCount:0,failedChildCount:0}}}}function py(e){let t=e.pluginNavigation,n=new Set(e.sidebarEntries),r=new Map(eg(e.pluginTabs).filter(e=>(!e.placement||!n.has(e.placement))&&!t.some(t=>t.pluginId===e.pluginId&&t.value.page.id===e.id)).map(e=>[_n(e),e])),i=new Set([...r.keys(),...t.filter(e=>e.value.defaultVisible!==!1).toSorted((e,t)=>(e.value.order??0)-(t.value.order??0)||e.key.localeCompare(t.key)).map(e=>e.key)]),a=e.rows.filter(e=>e.pinned),o=new Set(e.rows.filter(e=>!e.pinned).map(e=>e.key));return{...Oo(e.sidebarEntries,a,_i,o,new Set([...r.keys(),...t.map(e=>e.key)]),i),sessionRows:new Map(a.map(e=>[e.key,e])),pluginTabs:r,defaultPluginNavigationKeys:i}}function my(e,t){let n=new Set(e);return n.has(t)?n.delete(t):n.add(t),{selectedKeys:n,anchor:n.has(t)?t:null}}function hy(e){let t=e.anchor??e.rows.find(e=>e.visuallyActive||e.active)?.key??e.key,n=e.rows.findIndex(e=>e.key===t),r=e.rows.findIndex(t=>t.key===e.key);if(n===-1||r===-1)return{selectedKeys:new Set([e.key]),anchor:e.key};let[i,a]=n<=r?[n,r]:[r,n];return{selectedKeys:new Set(e.rows.slice(i,a+1).map(e=>e.key)),anchor:t}}function gy(e){let t=new Map(e.identities.map(e=>[e.agentId,e]));return{activeId:e.activeId,agent:e.roster.find(t=>b(t.id)===e.activeId),agents:Ke(e.roster),identity:t.get(e.activeId)??null,identities:t}}function _y(e){let{sessionData:t}=e,n=b(e.agentId),r=n===b(t.sessionsAgentId??``)?t.sessionsResult?.sessions??[]:t.sessionResultsByAgent[n]?.sessions??[];return it(r,{agentId:n,defaultAgentId:Ft({agentsList:e.context?.agents.state.agentsList,hello:e.context?.gateway.snapshot.hello}),filterByAgent:!0,archivedFilter:`active`}).reduce((e,t)=>e!==null&&At(e,t)<=0?e:t,null)}function vy(e){return new Map([...Object.values(e.childRowsByParent).flat(),...e.rows].map(e=>[e.key,e]))}function yy(e){let t=new Set(e.scopedRoots.map(e=>e.key));return e.rows.filter(n=>!t.has(n.key)&&!Lt(n.key)&&Ae(n.category)!=null&&bt(n)!=null&&gn(n,e.visibilityOptions))}function by(e,t,n){return e?.key??o({agentId:t,mainKey:n})}function xy(e){if(e.hasLoaded)return[...e.loadedCatalogIds];let t=e.sectionOrder.flatMap(e=>e.startsWith(`catalog:`)?[e.slice(8)]:[]);return[...new Set([...e.loadedCatalogIds,...t])]}function Sy(e){let t={agentsList:e.agentsList,hello:e.hello};return bn(t)?Ae(Tn(t)?.mainSessionKey)??`global`:o({agentId:e.agentId,mainKey:$t(t)})}function Cy(e,t){return e.find(e=>O(e.key,t))??null}function wy(e,t){let n=[...e];for(let e=n.pop();e;e=n.pop()){if(t(e))return e;n.push(...e.children)}}function Ty(e){let t=e.navigationState.visibleSessionRows.find(t=>t.key===e.sessionKey);if(t)return e.navigationState.toSidebarSession(t);for(let t of Object.values(e.sessionResultsByAgent)){let n=t.sessions.find(t=>t.key===e.sessionKey);if(n)return e.navigationState.toSidebarSession(n)}}function Ey(){return(Ey=e((()=>{me(),Xi(),pt(),wc(),ln(),Mo(),Ht(),N(),Jo(),Kt(),og(),K(),cy()})))()}function Dy(e,t,n){let r=bt(e)??n;if(!r||e?.createdVia!==`operator`||e.spawnDepth!==0||e.parentSessionId||e.spawnedBy||e.forkSource||e.forkedFromParent===!0||Lt(e.key)||![...t].some(e=>O(e,r)))return r}function Oy(e,t){let n=new Map,r=(e,t)=>{let r=dn(e),i=n.get(r)??[];i.includes(t)||(i.push(t),n.set(r,i))};for(let n of e.values())for(let i of n.childSessions??[]){let a=Dy(e.get(i),t,n.key);O(a,n.key)&&r(n.key,i)}for(let n of e.values()){let e=Dy(n,t);e&&r(e,n.key)}return n}function ky(e){let t=new Set([...e.mainSessionKeys].map(dn)),n=new Set;for(let r of t)for(let i of e.childKeysByParent.get(r)??[])Lt(i)?t.add(dn(i)):n.add(i);return e.rows.filter(t=>n.has(t.key)&&!e.scopedRootKeys.has(t.key)&&!Lt(t.key)&&In(t,e.archivedFilter)&&(e.showCron||!s(t.key))&&(e.showSystem||!y(t)))}function Ay(){return(Ay=e((()=>{c(),tt(),N()})))()}function jy(e,t,n=!1){let r=[],i=0,a=0,o=0,s=0,c=0;for(let t of e){if(n&&!Lt(t.key))continue;let e=n?t.subagentSummary:t,l=n?hg([t.ownAttention??t.attention,t.subagentSummary?.attention??Kg]):t.attention;r.push(l.kind===`error`&&l.childLabel===void 0?{...l,childLabel:t.label}:l),i+=Number(t.unread)+(e?.unreadChildCount??0),a+=+!!t.hasActiveRun+(e?.runningChildCount??0),o+=Number(t.status===`failed`||t.status===`timeout`)+(e?.failedChildCount??0),s+=Number(t.hasActiveRun&&t.status===`queued`)+(e?.queuedChildCount??0),c+=n?(t.ownWorkspaceConflictCount??0)+(e?.workspaceConflictCount??0):t.workspaceConflictCount??0}return{attention:hg([...r,...t]),unreadChildCount:i,runningChildCount:a,failedChildCount:o,queuedChildCount:s,workspaceConflictCount:c}}function My(e){let{roots:t,mainSessionKeys:n=new Set,rowsByKey:r,loadingChildKeys:i,resolveAttention:a,toSidebarSession:o}=e,s=Oy(r,n),c=e=>typeof e?.category==`string`&&e.category.trim().length>0&&!Lt(e.key),l=new Set,u=(t,n,d)=>{let f=t.archived===!0?[]:(s.get(dn(t.key))??[]).filter(n=>!c(r.get(n))&&(e.isChildSessionVisible?.(t.key,n,r.get(n))??!0)),p=!d.has(t.key);d.add(t.key);let m=[],h=new Set([t.key]),g=f.flatMap(e=>{let t=r.get(e),n=t&&!d.has(e)?u(t,!0,d):null;if(m.push(...Lt(e)?n?.childSessionKeys??[]:[e]),Lt(e))for(let e of n?.childLoadParentKeys??[])h.add(e);return n?[n]:[]}),_=g.flatMap(e=>Lt(e.key)?e.children:[e]);_.forEach(e=>l.add(e.key)),p&&d.delete(t.key);let v=o(t,n),y=f.filter(e=>!r.has(e)).map(e=>({key:e,attention:a({key:e,agentId:A(e)?.agentId??v.agentId})})),b=jy(g,y.map(e=>e.attention)),x=jy(g,y.filter(e=>Lt(e.key)).map(e=>e.attention),!0),S=hg([v.attention,b.attention]),ee=Math.min(2**53-1,(v.workspaceConflictCount??0)+b.workspaceConflictCount),C=t.archived!==!0&&!v.hasActiveRun&&t.hasActiveSubagentRun;return x.runningChildCount=Math.max(x.runningChildCount,C&&b.runningChildCount===0?1:0),{...v,...b,ownAttention:v.attention,ownWorkspaceConflictCount:v.workspaceConflictCount,subagentSummary:x,attention:S,childSessionKeys:m,childLoadParentKeys:f.length>0?[...h]:[],children:_,loadingChildren:[...h].some(e=>i.has(e)),containsActiveDescendant:_.some(e=>e.active||e.visuallyActive||e.containsActiveDescendant),workspaceConflictCount:ee||void 0,runningChildCount:Math.max(b.runningChildCount,+!!C)}},d=new Set(t.map(e=>e.key)),f=new Set;return t.filter(e=>{if(Lt(e.key))return!1;if(c(e))return!0;let t=Dy(e,n);return t&&Lt(t)?(f.add(e.key),!0):!t||!d.has(t)}).map(e=>u(e,!1,new Set)).filter(e=>!f.has(e.key)||!l.has(e.key))}function Ny(){return(Ny=e((()=>{N(),Ay(),K()})))()}function Py({host:e,navigationState:t,selected:n,agentIds:r,result:i,compareSessions:a,resolveAttention:o}){let s=i!==void 0,c=Ft({agentsList:e.sessionDataContext?.agents.state.agentsList,hello:e.sessionDataContext?.gateway.snapshot.hello}),l=new Set(r),u=e=>!s||l.has(He(e,c)),d=e.sessionData.activeSessionLineageRoot,f=s?vy({rows:[...d?[d]:[],...t.visibleSessionRows],childRowsByParent:e.sessionData.childSessionRowsByParent}):null,p=s?new Set:dp(e.visibleSessionCatalogs()),m=b(e.sessionData.sessionsAgentId??``),h=b(t.selectedAgentId),g={agentId:n,defaultAgentId:c,filterByAgent:!s,showCron:e.sessionsShowCron,showSystem:e.sessionsShowSystem,archivedFilter:e.sessionsStatusFilter},{childSessionRowsByParent:_,isSessionHidden:v,isChildSessionVisible:y,rows:x}=ay({sessionData:s?{sessionsAgentId:n,sessionsResult:i,sessionResultsByAgent:e.sessionData.sessionResultsByAgent,childSessionRowsByParent:e.sessionData.childSessionRowsByParent,loadedChildSessionKeys:e.sessionData.loadedChildSessionKeys,loadingChildSessionKeys:e.sessionData.loadingChildSessionKeys,childSessionErrorsByParent:e.sessionData.childSessionErrorsByParent}:e.sessionData,selectedAgentId:n,statusFilter:e.sessionsStatusFilter,deletionState:(t,n)=>e.sessionDataContext?.sessions.deletionState(t,s?He(f?.get(t)??{key:t},c):n),archiveVisibility:t=>e.sessionDataContext?.sessions.archiveVisibility(t)}),S=new Map(x.map(e=>[e.key,e])),ee=vy({rows:x,childRowsByParent:_}),C=r.map(t=>e.selectedAgentMainSessionKey(t)),te=e=>C.some(t=>O(e,t)),ne=!s&&n===h&&n===m?t.visibleSessionRows.flatMap(e=>{let t=S.get(e.key);return t?[t]:[]}):it(x.filter(u),g).toSorted(a),re=b(A(d?.key??``)?.agentId??``),ie=t.visibleSessionRows.find(e=>(s?u(e):n===h||re===n)&&e.key===t.activeRowKey&&!v(e)&&!p.has(e.key)&&!te(e.key)),ae=new Set(C),oe=ne.filter(e=>!te(e.key)),se=b(A(t.routeSessionKey)?.agentId??``);d&&!v(d)&&(O(d.key,t.routeSessionKey)||In(d,e.sessionsStatusFilter))&&(s?u(d):re===n||se===n)&&!p.has(d.key)&&!te(d.key)&&!oe.some(e=>e.key===d.key)&&oe.push(d);let ce=new Map([...ee].filter(([t,n])=>!s||In(n,e.sessionsStatusFilter)&&(!e.sessionInvolvingMeFilterActive||S.has(t))));if(d&&te(d.key)&&O(d.key,t.routeSessionKey)&&![...ce.keys()].some(e=>O(e,d.key))&&ce.set(d.key,d),s){for(let e of[...oe,...ie?[ie]:[]])ce.set(e.key,e);for(let[t,n]of ce){let r=n.childSessions?.filter(t=>ce.has(t)||!e.sessionInvolvingMeFilterActive&&!ee.has(t));r&&r.length!==n.childSessions?.length&&ce.set(t,{...n,childSessions:r})}}let le=new Set([...S.keys(),...oe.map(e=>e.key),...ie?[ie.key]:[],...d&&O(d.key,t.routeSessionKey)?[d.key]:[]].map(dn)),ue=Oy(ce,ae),de=new Set(le);for(let e of de)for(let t of ue.get(e)??[])de.add(dn(t));let fe=[...ce.values()].filter(e=>u(e)&&(!s||de.has(dn(e.key)))),pe=yy({rows:fe.filter(e=>!te(e.key)),scopedRoots:oe,visibilityOptions:g});oe.push(...pe);let me=new Set(oe.map(e=>e.key)),he=ky({rows:fe,childKeysByParent:ue,archivedFilter:e.sessionsStatusFilter,mainSessionKeys:ae,scopedRootKeys:me,showCron:e.sessionsShowCron,showSystem:e.sessionsShowSystem});for(let e of he)me.has(e.key)||(me.add(e.key),oe.push(e));let ge=My({mainSessionKeys:ae,roots:(he.length>0||pe.length>0?oe.toSorted(a):oe).filter(e=>!p.has(e.key)&&(!s||ce.has(e.key))),rowsByKey:ce,loadingChildKeys:e.sessionData.loadingChildSessionKeys,isChildSessionVisible:y,resolveAttention:o,toSidebarSession:t.toSidebarSession});return ie&&!Lt(ie.key)&&(!s||ce.has(ie.key))&&!wy(ge,e=>e.key===ie.key)&&ge.unshift(t.toSidebarSession(ie)),ge}function Fy({host:e,row:t,agentId:n,result:r,navigationState:i,resolveAttention:a}){let{rows:o,childSessionRowsByParent:s,isChildSessionVisible:c}=ay({sessionData:r===void 0?e.sessionData:{childSessionRowsByParent:e.sessionData.childSessionRowsByParent,loadedChildSessionKeys:e.sessionData.loadedChildSessionKeys,loadingChildSessionKeys:e.sessionData.loadingChildSessionKeys,childSessionErrorsByParent:e.sessionData.childSessionErrorsByParent,sessionResultsByAgent:e.sessionData.sessionResultsByAgent,sessionsAgentId:n,sessionsResult:r},selectedAgentId:n,statusFilter:e.sessionsStatusFilter,deletionState:(t,n)=>e.sessionDataContext?.sessions.deletionState(t,n),archiveVisibility:t=>e.sessionDataContext?.sessions.archiveVisibility(t)}),l={...t,agentId:n},u=i.toSidebarSession(l),d=My({roots:[l],mainSessionKeys:new Set([t.key,e.selectedAgentMainSessionKey(n)]),rowsByKey:vy({rows:[...o,l],childRowsByParent:s}),loadingChildKeys:e.sessionData.loadingChildSessionKeys,isChildSessionVisible:c,resolveAttention:a,toSidebarSession:(e,t)=>t?i.toSidebarSession(e,!0):u})[0];return r===void 0?d:{...d,...d.subagentSummary,attention:hg([u.attention,d.subagentSummary?.attention??Kg]),workspaceConflictCount:(u.workspaceConflictCount??0)+(d.subagentSummary?.workspaceConflictCount??0)||void 0}}function Iy(){return(Iy=e((()=>{Ht(),N(),oy(),_p(),Ey(),Ay(),Ny(),K()})))()}var q;function Ly(){return(Ly=e((()=>{r(),H(),Xi(),Ti(),aa(),Re(),as(),Qt(),N(),M(),q=class extends Sn{constructor(...e){super(...e),this.basePath=``,this.activePluginTabId=``,this.connected=!1,this.connectionStatus=null,this.lastError=null,this.outboxAttentionCountForSession=e=>0,this.hasSessionDraft=()=>!1,this.terminalAvailable=!1,this.catalogOpenTarget=`viewer`,this.canPairDevice=!1,this.preferencesBrowserOnly=!1,this.sessionKey=``,this.sidebarEntries=Pi,this.navigationVisible=!0,this.sidebarAgentsMode=`chip`,this.sidebarLiveActivity=!0,this.pinnedAgentIds=[],this.themeMode=`system`,this.gatewayVersion=null,this.devGitBranch=null,this.watchUpdateProgress=void 0}pluginNavigation(){return this.context?.plugins?.registrations(`navigation`)??[]}setApplicationSession(e,t){let n=this.context;n&&vi({selection:n.agentSelection,gateway:n.gateway,sessionKey:e,agentId:A(e)?.agentId??t})}prepareSessionNavigation(e,t){this.context&&cs(this.context.gateway,t,e)}bindLiteralSession(e,t,n){new URLSearchParams(n.search??``).has(`__openclawSessionKey`)||this.setApplicationSession(e,t)}sessionMainKey(){return $t({agentsList:this.context?.agents.state.agentsList,hello:this.context?.gateway.snapshot.hello})}readNewSessionAccess(){return on(this.connected?this.context?.gateway.snapshot:null,{method:`sessions.create`,params:{},sessionScope:!0})}readSessionMutationAccess(e){return on(this.connected?this.context?.gateway.snapshot:null,e)}requestOpenNewSession(e,t){this.readNewSessionAccess().allowed&&(t?this.onOpenNewSession?.(e,t):this.onOpenNewSession?.(e))}},w([W({attribute:!1})],q.prototype,`basePath`,void 0),w([W({attribute:!1})],q.prototype,`activeRouteId`,void 0),w([W({attribute:!1})],q.prototype,`router`,void 0),w([V()],q.prototype,`contextualSidebar`,void 0),w([W({attribute:!1})],q.prototype,`activePluginTabId`,void 0),w([W({attribute:!1})],q.prototype,`enabledRouteIds`,void 0),w([W({attribute:!1})],q.prototype,`connected`,void 0),w([W({attribute:!1})],q.prototype,`connectionStatus`,void 0),w([W({attribute:!1})],q.prototype,`lastError`,void 0),w([W({attribute:!1})],q.prototype,`outboxAttentionCountForSession`,void 0),w([W({attribute:!1})],q.prototype,`hasSessionDraft`,void 0),w([W({attribute:!1})],q.prototype,`terminalAvailable`,void 0),w([W({attribute:!1})],q.prototype,`catalogOpenTarget`,void 0),w([W({attribute:!1})],q.prototype,`canPairDevice`,void 0),w([W({attribute:!1})],q.prototype,`preferencesBrowserOnly`,void 0),w([W({attribute:!1})],q.prototype,`sessionKey`,void 0),w([W({attribute:!1})],q.prototype,`sidebarEntries`,void 0),w([W({attribute:!1})],q.prototype,`navigationVisible`,void 0),w([W({attribute:!1})],q.prototype,`sidebarAgentsMode`,void 0),w([W({attribute:!1})],q.prototype,`sidebarLiveActivity`,void 0),w([W({attribute:!1})],q.prototype,`pinnedAgentIds`,void 0),w([W({attribute:!1})],q.prototype,`themeMode`,void 0),w([W({attribute:!1})],q.prototype,`gatewayVersion`,void 0),w([W({attribute:!1})],q.prototype,`devGitBranch`,void 0),w([W({attribute:!1})],q.prototype,`watchUpdateProgress`,void 0),w([W({attribute:!1})],q.prototype,`onOpenPalette`,void 0),w([W({attribute:!1})],q.prototype,`onRetryConnect`,void 0),w([W({attribute:!1})],q.prototype,`onToggleSidebar`,void 0),w([W({attribute:!1})],q.prototype,`onOpenNewSession`,void 0),w([W({attribute:!1})],q.prototype,`onUpdateSidebarEntries`,void 0),w([W({attribute:!1})],q.prototype,`onPairMobile`,void 0),w([W({attribute:!1})],q.prototype,`onNavigate`,void 0),w([W({attribute:!1})],q.prototype,`onPreloadRoute`,void 0),w([Pe({context:Zi,subscribe:!0})],q.prototype,`context`,void 0)})))()}function Ry(e,t=e.key){let n=e.agentId?.trim();return n&&!A(dn(t))?JSON.stringify([t,b(n)]):t}function zy(e,t){let n=new Map;for(let r of[...Object.values(t).flat(),...e]){let e=Ry(r,dn(r.key)||r.key);n.delete(e),n.set(e,r)}return new Map([...n.values()].map(e=>[Ry(e),e]))}async function By(e){let t={},n=e.sessionKey,r=A(n)?.agentId??null,i=null,a=!1,o,s=new Set;try{for(let a=0;a<eb;a+=1){let c=JSON.stringify([n,r]);if(s.has(c))break;s.add(c);let l=a===0&&e.readSelected,u=l?await l():[...e.knownRows.values()].find(e=>Ot(e,n,r));if(!e.isCurrent())return null;if(l&&!u)break;if(!u){let t=a===0?e.captureReconcile():void 0,i=await e.sessions.describe({key:n,...!A(n)&&r?{agentId:r}:{}},{client:e.client});if(!e.isCurrent())return null;if(u=i?.session?{...i.session,runtimeSampledAt:i.session.runtimeSampledAt??Date.now()}:void 0,!u)break;if(t&&(o={row:u,reconcile:t},e.publishSelected)){if(u=e.publishSelected(u,t)??void 0,!e.isCurrent())return null;if(!u)break}e.knownRows.set(Ry(u),u)}i=u;let d=bt(u);if(!d)break;t[d]=[...(t[d]??[]).filter(e=>e.key!==u.key),u],r=A(d)?.agentId??A(u.key)?.agentId??u.agentId?.trim()??r,n=d}}catch{a=!0}return{rowsByParent:t,topmostRow:i,lookupFailed:a,selectedObservation:o}}function Vy(e,t){let n=Object.fromEntries(Object.entries(e).map(([e,t])=>[e,[...t]]));for(let[e,r]of Object.entries(t)){let t=n[e]??[];for(let e of r)t.some(t=>t.key===e.key)||t.push(e);n[e]=t}return n}function Hy(e,t){let n={},r=e?.trim(),i=new Set;for(;r&&!i.has(r);){i.add(r);let e=Object.entries(t).find(([,e])=>e.some(e=>O(e.key,r)));if(!e)break;n[e[0]]=e[1].filter(e=>O(e.key,r)),r=e[0]}return n}function Uy(e,t,n,r){let i=Hy(e,t)[n]??[];return{...t,...Vy({[n]:r},{[n]:i})}}function Wy(e,t){let n=t();e.retireStaleChildSessions(n);let r=e.context,i=r?.gateway.snapshot.client,a=e.childSessionScope;if(r&&i&&[...n].some(t=>e.needsChildSessionLoad(t))){let n=()=>e.context===r&&e.childSessionScope===a&&r.gateway.snapshot.client===i&&e.isSessionDataHostConnected,o;r.connectionBootstrap.run(a,async()=>{n()&&(o=t(),await Promise.all([...o].map(t=>e.loadChildSessions(t))))},{background:!0}).then(()=>{let r=o;r&&n()&&[...t()].some(e=>!r.has(e))&&e.requestSessionDataUpdate()})}}async function Gy(e){let{owner:t,parentKey:n,sessions:r,initialResult:i,childRead:a}=e,o=()=>e.ownsQuery()&&a.isCurrent();try{let s=await uo({sessions:r,parentKey:n,isCurrent:o,initialResult:i});if(!s||!o())return;let c=s.flatMap(e=>{let t=a.reconcile(e);return t.status===`selected`?t.row?[t.row]:[]:[e]});if(!o())return;t.childSessionRowsByParent=Uy(e.selectedKey(),t.childSessionRowsByParent,n,r.projectRows(c)),t.loadedChildSessionKeys=new Set([...t.loadedChildSessionKeys,n]);let l=new Map(t.childSessionErrorsByParent);l.delete(n),t.childSessionErrorsByParent=l}catch(e){if(!o())return;t.childSessionErrorsByParent=new Map(t.childSessionErrorsByParent).set(n,E(e))}}function Ky(e,t,n){let r=Hy(t,e.childSessionRowsByParent),i={...e.childSessionRowsByParent},a=!1;for(let[t,o]of Object.entries(i)){if(e.loadedChildSessionKeys.has(t)||e.loadingChildSessionKeys.has(t)||e.childSessionErrorsByParent.has(t)||n.has(t))continue;let s=r[t];s?.length!==o.length&&(s?i[t]=s:delete i[t],a=!0)}a&&(e.childSessionRowsByParent=i,e.requestSessionDataUpdate())}function qy(e,t,n,r){let i=Pn(t.key)&&(t.sessionId!==n?.sessionId||b(t.agentId)!==b(n?.agentId))?void 0:n;return Jy(e,r(t===i?t:Xe(t,i),t,i),r)}function Jy(e,t,n){e.activeSessionLineageSelectedRow=t,O(e.activeSessionLineageRoot?.key,t.key)&&(!Pn(t.key)||b(e.activeSessionLineageRoot?.agentId)===b(t.agentId))&&(e.activeSessionLineageRoot=t);for(let[r,i]of Object.entries(e.childSessionRowsByParent)){let a=i.find(e=>O(e.key,t.key)&&(!Pn(t.key)||e.agentId===t.agentId&&e.sessionId===t.sessionId));if(!a||a===t)continue;let o=a.key===t.key?t:n({...t,key:a.key},t);e.childSessionRowsByParent={...e.childSessionRowsByParent,[r]:i.map(e=>e===a?o:e)}}return t}function Yy(e,t,n){Jy(e,t,n),e.activeSessionLineageRoot??=t}function Xy(e,t,n,r){Yy(e,n,r);let i=e=>O(e.key,n.key)&&e.agentId===n.agentId&&e.sessionId===n.sessionId?n:e;e.childSessionRowsByParent=Vy(e.childSessionRowsByParent,Object.fromEntries(Object.entries(t.rowsByParent).map(([e,t])=>[e,t.map(i)]))),e.activeSessionLineageRoot=t.topmostRow?i(t.topmostRow):n}function Zy(e,t,n,r,i){let a=e.context?.sessions;if(!i())return null;let o=n(t,e.sessionsResult?.defaults,{archivedFilter:`all`})===!0;if(!i())return null;let s=()=>a?.state.result?.sessions.find(e=>O(e.key,t.key));if(!o){let t=[s(),e.activeSessionLineageSelectedRow].find(e=>e&&i()&&a?.reconcile(e,void 0,{archivedFilter:`all`})===!0);if(!i())return null;if(!t)return e.activeSessionLineageSelectedRow}let c=s();return c?qy(e,c,e.activeSessionLineageSelectedRow??void 0,r):(e.activeSessionLineageSelectedRow=null,null)}function Qy(e,t,n,r,i,a){if(!a())return;let o=e.activeSessionLineageRoot,s=e.activeSessionLineageSelectedRow,c=t=>{let n=A(t.key)?.agentId??t.agentId?.trim()??null,r=e=>Ot(e,t.key,n),a=s&&r(s)?s:o&&r(o)?o:null,c=e.sessionsResult?.sessions.find(r)??t;return i(Xe(c,a??void 0),c,a??void 0)},l=n.topmostRow?c(n.topmostRow):null,u=Object.fromEntries(Object.entries(n.rowsByParent).map(([e,t])=>[e,t.map(c)]));e.childSessionRowsByParent=Vy(e.childSessionRowsByParent,u),e.activeSessionLineageRoot=l;let d=n.selectedObservation?.row??[l,...Object.values(u).flat(),...zy(e.sessionsResult?.sessions??[],e.childSessionRowsByParent).values()].filter(e=>e!=null&&O(e.key,t)).reduce((e,t)=>!e||(t.updatedAt??0)>(e.updatedAt??0)?t:e,void 0);d?Zy(e,d,n.selectedObservation?.reconcile??((t,n,i)=>e.context?.sessions.reconcile(t,n,{...i,sourceCanonicalListRevision:r})??!1),i,a):e.activeSessionLineageSelectedRow=n.lookupFailed?s:null}function $y(e,t){if(!t)return;let n=e.context?.gateway?.snapshot.sessionKey?.trim();if(n&&O(n,t))return;let r=e.sessionsResult?.sessions.find(e=>O(e.key,t))??[e.activeSessionLineageSelectedRow,e.activeSessionLineageRoot,...Object.values(e.childSessionRowsByParent).flat()].find(e=>e!=null&&O(e.key,t));r?.archived===!0&&(e.childSessionRowsByParent=Object.fromEntries(Object.entries(e.childSessionRowsByParent).map(([e,n])=>[e,n.filter(e=>!O(e.key,t))])),e.context?.sessions.reconcile(r,e.sessionsResult?.defaults,{archivedFilter:`active`}))}var eb;function tb(){return(tb=e((()=>{P(),Bs(),qe(),N(),Hn(),eb=16})))()}function nb(e){return{assistantAgentId:e?.agentSelection.state.selectedId??e?.gateway.snapshot.assistantAgentId,agentsList:e?.agents.state.agentsList,hello:e?.gateway.snapshot.hello}}var rb;function ib(){return(ib=e((()=>{ii(),N(),tb(),rb=class{constructor(e,t,n){this.owner=e,this.route=t,this.childScope=n,this.routeKey=null,this.loaded=null,this.request=null,this.retryTimer=null,this.binding=null,this.navigation=null}selectedAgentId(){let e=this.owner.context?.agentSelection.state.selectedId?.trim();return e?b(e):null}identity(e){return Xt(nb(this.owner.context),e)}scopeIsCurrent(e){let t=this.owner.context,n=this.route();return this.owner.isSessionDataHostConnected&&Ji(n.routeId)&&n.key.trim()===e.key&&this.routeKey===e.key&&this.selectedAgentId()===e.selectedAgentId&&t?.sessions===e.sessions&&t.gateway===e.gateway&&e.sessions.captureConnectionScope()!==null&&e.gateway.snapshot.phase===`connected`&&e.gateway.snapshot.client===e.client&&e.gateway.connectionRevision===e.connectionRevision}bindingIsCurrent(e){let t=this.identity(e.key);return this.binding===e&&this.scopeIsCurrent(e)&&t.sessionKey===e.target.key&&(t.agentId??e.selectedAgentId)===e.target.agentId&&(e.observation?.isCurrent()??!0)}clearRetry(){this.retryTimer!==null&&(globalThis.clearTimeout(this.retryTimer),this.retryTimer=null)}retireWalk(){this.request=null,this.loaded=null,this.clearRetry()}retire(){let e=this.binding;this.binding=null,e?.observation?.dispose(),this.retireWalk()}clearPresentation(){this.owner.activeSessionLineageRoot=null,this.owner.activeSessionLineageSelectedRow=null}evictPreviousLineage(){this.routeKey&&this.identity(this.routeKey).sessionKey!==`global`&&$y(this.owner,this.routeKey)}synchronize(){let e=this.route(),t=this.owner.context,n=Ji(e.routeId)?e.key.trim():``,r=n?this.identity(n):null,i=this.selectedAgentId(),a=this.navigation;!n||!r||!t?this.navigation=null:(a?.key!==n||a.identity.sessionKey!==r.sessionKey||a.identity.agentId!==r.agentId||a.selectedAgentId!==i||a.sessions!==t.sessions||a.gateway!==t.gateway)&&(this.navigation={key:n,identity:r,selectedAgentId:i,sessions:t.sessions,gateway:t.gateway}),this.routeKey!==null&&(!Ji(e.routeId)||e.key.trim()!==this.routeKey)?(this.evictPreviousLineage(),this.retire(),this.routeKey=null,this.clearPresentation(),this.owner.requestSessionDataUpdate()):(a!==this.navigation||this.binding&&!this.bindingIsCurrent(this.binding))&&(this.retire(),this.clearPresentation(),this.owner.requestSessionDataUpdate())}reset(e){if(this.binding&&this.bindingIsCurrent(this.binding)&&(this.binding.target.key===`global`||e)){this.binding.target.key===`global`?this.publish(this.binding,this.binding.observation?.row??null):this.retireWalk();return}this.retire(),e||(this.routeKey=null,this.clearPresentation())}disconnect(){this.navigation=null,this.retire()}publish(e,t){if(!this.bindingIsCurrent(e))return;let n=this.selectedRow();t?e.target.key===`global`?Yy(this.owner,t,e.sessions.inheritRow):qy(this.owner,t,n,e.sessions.inheritRow):this.clearPresentation(),e.target.key!==`global`&&!this.request?.publishingSelected&&this.retireChangedLineage(n,t)}observe(e,t){let n={...e,target:t,refreshRequested:!1};return this.binding=n,n.observation=e.sessions.observeRow(t,e=>{if(this.binding===n){if(!this.bindingIsCurrent(n)){this.synchronize();return}this.publish(n,e),!e&&this.request===null&&(this.loaded=null),this.owner.requestSessionDataUpdate()}},{onInvalidate:e=>{e===`runner-availability`&&this.bindingIsCurrent(n)&&(n.refreshRequested=!0,this.loaded=null,this.owner.requestSessionDataUpdate())}}),this.synchronize(),this.bindingIsCurrent(n)?(this.publish(n,n.observation.row),n):(n.observation.dispose(),n)}selectedRow(){return this.owner.activeSessionLineageSelectedRow??this.owner.sessionsResult?.sessions.find(e=>O(e.key,this.routeKey))}retireChangedLineage(e,t){e&&t&&(e.sessionId&&t.sessionId&&e.sessionId!==t.sessionId||dn(bt(e))!==dn(bt(t)))&&this.retireWalk()}captureChildRead(e){this.synchronize();let t=this.navigation,n=t?.key,r=this.owner.context?.sessions,i=this.owner.context?.gateway,a=r?.captureConnectionScope(),o=nb(this.owner.context),s=t?.identity.sessionKey===`global`,c=s?this.binding:null,l=c?.observation?.captureReconcile(),u=s?void 0:r?.captureReconcile(),d=u?(t,n,r)=>u(t,n,{...r,sourceListScope:e}):void 0,f=()=>this.owner.isSessionDataHostConnected&&r===this.owner.context?.sessions&&i===this.owner.context?.gateway&&!!(a&&r?.isConnectionScopeCurrent(a)),p=()=>(this.synchronize(),f()&&t!==null&&t===this.navigation);return{isCurrent:f,reconcile:e=>{if(!(s?St(o,n,e.key,e.agentId):O(e.key,n))||!p())return{status:`not-selected`};if(!s){let t=d&&r?Zy(this.owner,e,d,r.inheritRow,p):null;return p()?{status:`selected`,row:t}:{status:`not-selected`}}if(!c||!l||!this.bindingIsCurrent(c))return{status:`selected`,row:null};let t=l(e);return p()?t.status===`current`?(this.publish(c,t.row),{status:`selected`,row:t.row}):t.status===`invalidated`?(this.loaded=null,this.owner.requestSessionDataUpdate(),{status:`selected`,row:c.observation?.row??null}):(this.synchronize(),{status:`selected`,row:null}):{status:`not-selected`}}}}load(e){this.synchronize();let t=e.trim();if(t!==this.routeKey&&(this.evictPreviousLineage(),this.retire(),this.routeKey=t,this.clearPresentation(),this.owner.requestSessionDataUpdate()),this.request)return this.request.promise;let{gateway:n,sessions:r}=this.owner.context??{},i=n?.snapshot.client;if(!t||this.loaded||this.retryTimer!==null||!n||!r||!i)return Promise.resolve();let a={key:t,gateway:n,sessions:r,client:i,selectedAgentId:this.selectedAgentId(),connectionRevision:n.connectionRevision};if(!this.scopeIsCurrent(a))return Promise.resolve();let o=this.identity(t);if(o.sessionKey===`global`&&!o.agentId)return Promise.resolve();let s=o.agentId??a.selectedAgentId,c=this.binding,l=s?c??this.observe(a,{key:o.sessionKey,agentId:s}):null;if(l&&!this.bindingIsCurrent(l))return Promise.resolve();let u=o.sessionKey===`global`?l:null,d=u??(l===c&&l?.observation?.row||l?.refreshRequested?l:null),f=this.childScope(),p={sourceRevision:r.canonicalListRevision,publishingSelected:!1,promise:Promise.resolve()};return this.request=p,p.promise=Promise.resolve().then(async()=>{let e=()=>p===this.request&&this.scopeIsCurrent(a)&&this.identity(t).sessionKey===o.sessionKey&&this.identity(t).agentId===o.agentId&&(u?this.bindingIsCurrent(u):f===this.childScope()),n=await By({client:i,sessions:r,sessionKey:t,captureReconcile:r.captureReconcile,knownRows:zy(this.owner.sessionsResult?.sessions??[],this.owner.childSessionRowsByParent),isCurrent:e,...d?{readSelected:()=>this.readDescriptor(d,e)}:{publishSelected:(t,n)=>{p.publishingSelected=!0;try{return Zy(this.owner,t,n,r.inheritRow,e)}finally{p.publishingSelected=!1}}}});if(!n||!e()){p===this.request&&(this.request=null,this.synchronize());return}if(u){let e=u.observation?.row;e?Xy(this.owner,n,e,r.inheritRow):this.clearPresentation()}else Qy(this.owner,t,n,p.sourceRevision,r.inheritRow,e);e()&&(this.request=null,n.lookupFailed?this.retryTimer=globalThis.setTimeout(()=>{this.retryTimer=null,this.routeKey===t&&this.owner.requestSessionDataUpdate()},5e3):this.loaded=l?.refreshRequested?null:o,this.owner.requestSessionDataUpdate())}),p.promise}async readDescriptor(e,t){let n=e.observation;if(n&&t()){if(n.row&&!e.refreshRequested)return n.row;for(;t();){let r=e.refreshRequested;e.refreshRequested=!1;let i=n.captureReconcile(),a=await e.sessions.describe({key:e.key,...Pn(e.key)?{agentId:e.target.agentId}:{}},{client:e.client,refresh:r}).catch(t=>{throw e.refreshRequested=!0,t});if(!t())return;let o=i(a?.session?{...a.session,runtimeSampledAt:a.session.runtimeSampledAt??Date.now()}:void 0);if(o.status!==`invalidated`){if(o.status===`retired`){this.synchronize();return}return this.publish(e,o.row),o.row??void 0}}}}}})))()}function ab(e,t){return[e.activeSessionLineageSelectedRow,e.activeSessionLineageRoot,...Object.values(e.childSessionRowsByParent).flat()].find(n=>n!=null&&St(nb(e.context),t,n.key,n.agentId))}function ob(e,t,n){let r=wy(n,e=>e.key===t),i=e.getSessionNavigationState(),a=ab(e.sessionData,t),o=r??Ty({sessionKey:t,navigationState:i,sessionResultsByAgent:e.sessionData.sessionResultsByAgent})??(a?i.toSidebarSession(a,!0):void 0);return up({catalogs:e.visibleSessionCatalogs(),sessionKey:t,liveRow:o})}function sb(e){if(e.adopted.size===0)return e.rows;let t=new Map(e.rows.map(e=>[e.key,e])),n=[...e.sessionsResult?.sessions??[],...Object.values(e.sessionResultsByAgent).flatMap(e=>e.sessions)];for(let r of n)e.adopted.has(r.key)&&!t.has(r.key)&&t.set(r.key,e.navigationState.toSidebarSession(r));return[...t.values()]}function cb(){return(cb=e((()=>{N(),_p(),Ey(),ib()})))()}function lb(e){switch(e.type){case`profile`:case`agent`:return JSON.stringify([e.type,e.id]);case`remote`:return JSON.stringify([e.type,e.pluginId,e.domain,e.idKind,e.id]);case`observation`:return JSON.stringify([e.type,e.pluginId,e.accountId,e.senderKind,e.id]);case`legacy`:return JSON.stringify([e.type,e.actorType,e.source,e.id]);default:return e}}function ub(e,t,n){let r=new Set(e.filter(e=>!n||e.type===`human`).map(e=>lb(e.identity??{type:e.type===`human`?`profile`:`agent`,id:e.id})));return r.size>=2||!!wy(t,e=>{let t=e.participants??[];for(let e of t){let t=e.identity;if((!n||t.type===`profile`||t.type===`observation`&&t.senderKind===`human`||t.type===`legacy`&&t.actorType===`human`)&&(r.add(lb(t)),r.size>=2))return!0}return!n&&(e.participantCount??t.length)>t.length})}function db(e){let t=e.ownerFacet??[],n=e.self?.id,r=t.find(e=>e.id===n)?.type===`agent`?null:uh(e.self),i=r?[r,...t.filter(e=>e.id!==r.id)]:t,a={filters:ub(i,e.projected,!1),avatars:ub(i,e.projected,!0)},o=e.selectedOwnerId?.trim()||null,s=o&&(e.ownerFacet===void 0||i.some(e=>e.id===o))?o:null,c=e=>{let t=[];for(let n of e){let e=c(n.children);if(n.owner?.actor.id===s)t.push({...n,children:e});else for(let n of e)t.push({...n,isChild:!1})}return t};return{rows:s?c(e.projected):e.projected,ownerOptions:i,ownershipVisibility:a,activeOwnerId:s}}function fb(){return(fb=e((()=>{Ey(),gh()})))()}var pb;function mb(){return(mb=e((()=>{so(),go(),N(),pb=class{constructor(e,t){this.host=e,this.options=t,this.states=new Map,this.gateway=null,this.client=null,this.agentId=null,this.store=null,this.stopStoreUpdates=null,this.connected=!1,e.addController(this)}hostConnected(){this.connected=!0}hostUpdated(){this.connected&&this.refreshVisible()}hostDisconnected(){this.connected=!1,this.releaseStore(),this.reset(!1)}summary(e,t,n){let r=this.states.get(e);return r?.worktreeId===t?r.summary:n}releaseStore(){this.store?.unwatch(this),this.stopStoreUpdates?.(),this.stopStoreUpdates=null,this.store=null,this.gateway=null,this.client=null,this.agentId=null}reset(e){this.states.size!==0&&(this.states.clear(),e&&this.host.requestUpdate())}eligibleRows(){return this.options.getRows().filter(e=>!e.isChild&&e.worktreeId)}scopedKey(e){return zn(e,A(e)?.agentId??this.options.getSelectedAgentId())}applySnapshots(e){let t=this.store;if(!t)return;let n=!1;for(let r of e??this.eligibleRows()){if(!r.worktreeId)continue;let e=t.get(this.scopedKey(r.key));if(!e){let e=this.states.delete(r.key);if(e){let e=this.options.getSessions();e&&e.setPullRequestSummary(r.key,void 0,e.capturePullRequestEpoch(r.key))}n=e||n;continue}if(e.status!==`ready`&&e.pullRequests.length===0)continue;let i=this.states.get(r.key),a={summary:To(e.pullRequests,i?.summary),worktreeId:r.worktreeId};(!i||i.summary!==a.summary||i.worktreeId!==a.worktreeId)&&(this.states.set(r.key,a),n=!0)}n&&this.host.requestUpdate()}refreshVisible(){let e=this.options.getGateway();if(!e||!this.options.getConnected()||oo(e.snapshot,`controlUi.sessionPullRequests.subscribe`)!==!0){this.releaseStore(),this.reset(!0);return}e!==this.gateway&&(this.releaseStore(),this.gateway=e,this.store=ns(e),this.stopStoreUpdates=this.store.subscribe(()=>this.applySnapshots())),e.snapshot.client!==this.client&&(this.client=e.snapshot.client,this.reset(!0));let t=this.options.getSelectedAgentId();t!==this.agentId&&(this.agentId=t,this.reset(!0));let n=this.eligibleRows(),r=new Set(n.map(e=>e.key)),i=!1;for(let e of this.states.keys())r.has(e)||(this.states.delete(e),i=!0);i&&this.host.requestUpdate(),this.store?.watch(this,n.map(e=>this.scopedKey(e.key)),{passive:!0}),this.applySnapshots(n)}}})))()}function hb(e){return!!(__(e.attention)||e.agentStatusNote||e.hasActiveRun&&e.status===`queued`)}var gb,_b,vb;function yb(){return(yb=e((()=>{xs(),K(),C_(),$_(),gb=1e3,_b=2e3,vb=class{constructor(e=()=>Date.now()){this.now=e,this.observedOrder=new Map,this.nextCreatedOrder=0,this.stickySections=new Map,this.childModes=new Map,this.heldSubtitles=new Map,this.previousInput=null,this.previousCollapsedSections=new Set}get createdOrder(){return this.observedOrder}observeRows(e){for(let t of e)for(let{key:e}of t.sessions)e&&!this.observedOrder.has(e)&&this.observedOrder.set(e,this.nextCreatedOrder++);if(this.observedOrder.size<=gb)return;let t=new Set(e.flatMap(e=>e.sessions.map(({key:e})=>e)));for(let e of this.observedOrder.keys()){if(this.observedOrder.size<=gb)break;t.has(e)||this.observedOrder.delete(e)}}promoteCreatedSession(e){let t=this.observedOrder.get(e);if(t===0)return!1;for(let[n,r]of this.observedOrder)n!==e&&(t===void 0||r<t)&&(this.observedOrder.set(n,r+1),this.nextCreatedOrder=Math.max(this.nextCreatedOrder,r+2));return this.observedOrder.set(e,0),this.nextCreatedOrder=Math.max(this.nextCreatedOrder,1),!0}project(e){let t=this.previousInput,n=t!==null&&(t.agentId!==e.agentId||t.connectionIdentity!==e.connectionIdentity||t.listSource!==e.listSource);(n||t!==null&&(t.grouping!==e.grouping||t.sortMode!==e.sortMode||t.statusFilter!==e.statusFilter))&&this.resetMembership(),t!==null&&(t.agentId!==e.agentId||t.connectionIdentity!==e.connectionIdentity)&&this.childModes.clear(),n&&this.heldSubtitles.clear();for(let t of e.collapsedSections)this.previousCollapsedSections.has(t)||this.resetMembership(t);this.previousInput={grouping:e.grouping,sortMode:e.sortMode,statusFilter:e.statusFilter,agentId:e.agentId,connectionIdentity:e.connectionIdentity,listSource:e.listSource},this.previousCollapsedSections=new Set(e.collapsedSections);let r=new Set([...this.childModes.keys(),...this.heldSubtitles.keys()]),i=t=>{r.delete(t.key),t.containsActiveDescendant&&!this.childModes.has(t.key)&&this.childModes.set(t.key,`expanded`),this.observeSubtitle(t,e.subtitle);for(let e of t.children)i(e)};e.rows.forEach(i);for(let e of r)this.childModes.delete(e),this.heldSubtitles.delete(e);let{grouping:a,knownGroups:o,selfOwnerId:s,sectionOrder:c,catalogIds:l}=e,u=e.emptyGroupsMode===`always`||e.emptyGroupsMode===`filtering`&&e.ownerFiltered,d=e.sections??Is(e.rows,{grouping:a,knownGroups:o,selfOwnerId:s,sectionOrder:c,catalogIds:l}).filter(e=>e.id!==`pinned`&&!(u&&!e.id.startsWith(`catalog:`)&&e.rows.length===0)),f=new Set(d.map(e=>e.id));for(let e of this.stickySections.keys())f.has(e)||this.stickySections.delete(e);let p=e.grouping!==`none`&&d.some(e=>e.id!==`ungrouped`&&(e.id!==`work`||e.rows.length>0)),m=[],h=[];for(let t of d){let n=t.rows.length,r=!t.id.startsWith(`agent:`)&&(t.id!==`ungrouped`||p),i=(r||t.id.startsWith(`agent:`))&&e.collapsedSections.has(t.id),a=e.visibleSessionLimits.get(t.id)??10,o=t.rows.reduce((e,t)=>e+Number(t.active||t.pinned),0),s=Math.max(o,Math.min(n,10)),c=0;if(!i){let e=Math.max(0,a-o),n=a,r=this.stickySections.get(t.id);t.rows=t.rows.filter(t=>t.active||t.pinned?!0:e>0?(--e,!0):n===0||!r?.has(t.key)?!1:(--n,!0)),this.stickySections.set(t.id,new Set(t.rows.map(e=>e.key))),m.push(...t.rows),c=t.rows.length}h.push(Object.assign(t,{totalRowCount:n,visibleRowCount:c,visibleLimit:a,collapsedVisibleRowCount:s,renderHeader:r}))}return{sections:h,visibleRows:m}}resetMembership(e){e===void 0?this.stickySections.clear():this.stickySections.delete(e)}isChildrenExpanded(e){let t=this.childModes.get(e);return t===`expanded`||t===`expanded-fully`}isChildrenFullyShown(e){return this.childModes.get(e)===`expanded-fully`}toggleChildren(e){return this.isChildrenExpanded(e.key)?(this.childModes.set(e.key,`collapsed-by-user`),{expanded:!1}):(this.childModes.set(e.key,`expanded`),{expanded:!0})}showMoreChildren(e){this.isChildrenExpanded(e)&&this.childModes.set(e,`expanded-fully`)}resolveSubtitle(e){if(!e.session.hasActiveRun||!e.showPreview)return Z_(e);let t=this.heldSubtitles.get(e.session.key);return t?e.hasDisplay?t.catalogValue??Z_(e):t.value:Z_(e)}observeSubtitle(e,t){if(!e.hasActiveRun||!t.showPreview){this.heldSubtitles.delete(e.key);return}!t.sidebarLiveActivity&&this.heldSubtitles.get(e.key)?.value.narration&&this.heldSubtitles.delete(e.key);let n={session:e,hasDisplay:!1,displaySubtitle:void 0,sidebarLiveActivity:t.sidebarLiveActivity,showPreview:t.showPreview,narrationLine:t.narrationLines.get(e.key),observerDigest:t.observerDigests.get(e.key)??null},r=Z_(n);if(!r.subtitle){(e.attention.kind===`question`||e.attention.kind===`error`)&&this.heldSubtitles.delete(e.key);return}let i=this.heldSubtitles.get(e.key),a=this.now(),o=i!==void 0&&i.value.subtitle!==r.subtitle;if(o&&a-i.shownAt<_b&&!hb(e))return;let s=Z_({...n,hasDisplay:!0});this.heldSubtitles.set(e.key,{value:r,...s.subtitle?{catalogValue:s}:{},shownAt:i!==void 0&&!o?i.shownAt:a})}}})))()}function bb(e){let t=e.replace(/\s+/g,` `).trim();return t.length>64?`${h(t,61)}…`:t}function xb(){return(xb=e((()=>{})))()}function Sb(e){let t=e.replace(/\s+/g,` `).trim();return t.length>240?`${h(t,239)}…`:t}var Cb;function wb(){return(wb=e((()=>{xb(),cd(),F(),P(),so(),N(),Vt(),K(),Cb=class{constructor(e){this.host=e,this.attentionGateway=null,this.attentionGatewayClient=null,this.attentionGatewayConnected=!1,this.agentStatusExpiryTimer=null,this.agentStatusExpiryAt=null,e.addController(this),this.attentionSubscriptions=new Nn(e),this.questionPromptState=Wu(()=>e.requestUpdate()),this.attentionSubscriptions.watch(()=>e.sessionAttentionContext?.gateway,(e,t)=>e.subscribe(t),e=>this.synchronizeAttentionGateway(e)).effect(()=>e.sessionAttentionContext?.gateway,e=>e.subscribeEvents(e=>{Yu(this.questionPromptState,e)})).watch(()=>e.sessionAttentionContext?.overlays,(e,t)=>e.subscribe(t))}hostDisconnected(){this.attentionGateway=null,this.attentionGatewayClient=null,this.attentionGatewayConnected=!1,this.agentStatusExpiryTimer&&(globalThis.clearTimeout(this.agentStatusExpiryTimer),this.agentStatusExpiryTimer=null,this.agentStatusExpiryAt=null),nd(this.questionPromptState)}synchronizeAttentionGateway(e){let t=e.snapshot.phase===`connected`,n=t&&oo({hello:e.snapshot.hello},`question.list`)===!0&&typeof e.snapshot.client?.request==`function`?e.snapshot.client:null;(e!==this.attentionGateway||n!==this.attentionGatewayClient||t!==this.attentionGatewayConnected)&&(this.attentionGateway=e,this.attentionGatewayClient=n,this.attentionGatewayConnected=t,td(this.questionPromptState,n),n&&ed(this.questionPromptState,n,()=>this.host.isConnected&&this.host.sessionAttentionContext?.gateway===e&&e.snapshot.phase===`connected`&&e.snapshot.client===n))}resolveSessionAgentStatus(e){let t=e.agentStatus;if(!(!t||t.expiresAt<=Date.now()||!t.note.trim()))return this.scheduleAgentStatusExpiry(t.expiresAt),t}scheduleAgentStatusExpiry(e){this.host.isConnected&&(this.agentStatusExpiryAt!==null&&this.agentStatusExpiryAt<=e||(this.agentStatusExpiryTimer&&globalThis.clearTimeout(this.agentStatusExpiryTimer),this.agentStatusExpiryAt=e,this.agentStatusExpiryTimer=globalThis.setTimeout(()=>{this.agentStatusExpiryTimer=null,this.agentStatusExpiryAt=null,this.host.requestUpdate()},Math.max(0,e-Date.now()+1))))}createResolver(){let e=this.host.sessionAttentionContext,t={hello:e?.gateway.snapshot.hello,agentsList:e?.agents.state.agentsList},n=[...od(this.questionPromptState).filter(e=>e.status===`pending`).map(e=>({sessionKey:e.sessionKey,agentId:e.agentId,kind:`question`,id:e.id,preview:Sb(e.questions[0]?.question??``),count:e.questions.length,createdAtMs:e.createdAtMs})),...(e?.overlays?.snapshot.approvalQueue??[]).map(e=>({sessionKey:e.request.sessionKey,agentId:e.request.agentId,kind:`approval`,id:e.id,preview:e.kind===`exec`?bb(e.request.command):Sb(e.pluginTitle??e.request.command),count:1,createdAtMs:e.createdAtMs}))];return e=>{let r=hg(n.filter(n=>St(t,e.key,n.sessionKey,n.agentId,e.agentId)).map(e=>({kind:e.kind,requests:[e]})));if(r.kind!==`none`)return r;let i=this.resolveSessionAgentStatus(e);if(i?.attention)return{kind:`agent`,note:i.note,icon:i.attention};let a=e.endedAt??e.updatedAt??0;return e.status!==`failed`&&e.status!==`timeout`||e.lastReadAt!=null&&a<=e.lastReadAt?Kg:{kind:`error`,reason:rt(e.lastRunError)||j(e.status===`timeout`?`sessionsView.runErrorTimedOut`:`sessionsView.runErrorUnknown`)}}}}})))()}function Tb(e,t){return document.addEventListener(yt,e),document.addEventListener(`visibilitychange`,t),()=>{document.removeEventListener(yt,e),document.removeEventListener(`visibilitychange`,t)}}function Eb(e,t,n){(n!==`list`||Ib.get(e)!==`action`)&&(e.sessionMutationError=t,t===null?Ib.delete(e):Ib.set(e,n))}function Db(e,t){let n=new Set(t.map(b));for(let t of Object.keys(e.sessionResultsByAgent))n.has(t)||delete e.sessionResultsByAgent[t];e.sessionsAgentId&&!n.has(b(e.sessionsAgentId))&&(e.sessionsResult=null,e.sessionsAgentId=null)}function Ob(e,t,n){let r=()=>{let n=e.state.agentsList;n&&Db(t,n.agents.map(e=>e.id))};return r(),e.subscribe(()=>{r(),n()})}function kb(e){let{ownerId:t,involvingMe:n}=e.sidebarSessionOwnerFilter();return e.sidebarSessionStatusFilter()!==`active`||!!(t||n)}function Ab(e,t){let{ownerId:n,involvingMe:r}=e.sidebarSessionOwnerFilter();return{ownerId:r?void 0:n||void 0,involvingMe:r||void 0,agentId:t,archivedFilter:e.sidebarSessionStatusFilter(),limit:200,includeDerivedTitles:!0,includeLastMessage:!0}}function jb(e,t){e.sessionsResult=t.result,e.sessionsAgentId=t.agentId,t.result&&t.agentId&&(e.sessionResultsByAgent[b(t.agentId)]=t.result)}function Mb(e,t,n,r){let i=t=>{r()&&(e.context?.gateway.snapshot.phase===`connected`||t.result)&&(jb(e,t),e.sessionsLoading=t.loading,Eb(e,t.error,`list`),e.requestSessionDataUpdate())},a=t.subscribeList(n,i);return i(t.listSnapshot(n)),()=>{a(),Eb(e,null,`list`)}}function Nb(e,t){let n=e.context,r=t();return!n||!r?Promise.resolve():n.connectionBootstrap.run(r,async()=>{e.context===n&&t()===r&&e.isSessionDataHostConnected&&await e.refreshSidebarSessions()},{background:!0})}function Pb(e,t,n=!1){let r=e.sessionsResult,i=r?.nextOffset===void 0?r?.sessions.length:r.nextOffset;return!e.context?.sessions||!t||n&&(e.sessionsLoading||!r?.hasMore||typeof i!=`number`||b(t)!==b(e.expandedAgentId()))?Promise.resolve():e.context.sessions.refreshList({...e.sessionListQuery(t),...n&&typeof i==`number`?{offset:i,append:!0}:{},force:!0})}function Fb(e,t){return e.subscribeEvents(e=>{if(e.event===`sessions.catalog.host`){t.handleSessionCatalogHostEvent(e.payload);return}if(e.event===`sessions.catalog.changed`){t.handleSessionCatalogChanged(e.payload);return}if(e.event===`presence`){let n=Tr(e.payload);t.presencePayload=n?{presence:n}:void 0,t.requestSessionDataUpdate()}})}var Ib;function Lb(){return(Lb=e((()=>{Ue(),N(),Ib=new WeakMap})))()}var Rb;function zb(){return(zb=e((()=>{K(),Rb=class{constructor(e){this.notify=e,this.state=`none`,this.element=null,this.resizeObserver=null,this.frame=null}synchronize(e){let t=e.querySelector(`.sidebar-shell__body`);t!==this.element&&(this.resizeObserver?.disconnect(),this.element=t,this.resizeObserver=null,t&&typeof ResizeObserver==`function`&&(this.resizeObserver=new ResizeObserver(()=>this.update(t)),this.resizeObserver.observe(t))),t&&this.frame===null&&(this.frame=requestAnimationFrame(()=>{this.frame=null,this.element?.isConnected&&this.update(this.element)}))}update(e){let t=_g(e);t!==this.state&&(this.state=t,this.notify())}dispose(){this.resizeObserver?.disconnect(),this.resizeObserver=null,this.element=null,this.frame!==null&&(cancelAnimationFrame(this.frame),this.frame=null)}}})))()}var Bb,Vb;function Hb(){return(Hb=e((()=>{Bb={includeOwnerSessionCounts:!0,limit:1,includeDerivedTitles:!1,includeLastMessage:!1,includeGlobal:!1,includeUnknown:!1,excludeSubagents:!0,excludeCron:!0,excludeSystem:!0},Vb=class{constructor(e){this.changed=e,this.counts=null,this.error=null,this.viewerId=null,this.observation=null,this.accept=null}synchronize(e,t,n){if(this.source===e&&(!e||this.viewerId===t))return;let r=this.source!==void 0;this.dispose();let i=e?.captureConnectionScope();if(!e||!i||!n){r&&this.changed();return}this.source=e,this.viewerId=t;let a=!1,o,s=()=>{if(o&&e.isConnectionScopeCurrent(i)){if(this.error=o.error,a&&!o.loading&&!o.error){let e=o.result?.ownerSessionCounts;this.counts=e?new Map(e.map(({profileId:e,open:t,running:n})=>[e,{open:t,running:n}])):null}this.changed()}};this.observation=e.observeList(Bb,e=>{o=e,s()}),this.accept=()=>{a=!0,s()};let c=this.observation;n.run(c,async()=>{this.observation===c&&e.isConnectionScopeCurrent(i)&&await this.refresh()},{background:!0})}refresh(){let e=this.observation,t=()=>{this.observation===e&&this.accept?.()};return e?.refresh().then(t,t)??Promise.resolve()}dispose(){this.observation?.dispose(),this.observation=null,this.source=void 0,this.viewerId=null,this.accept=null,this.counts=null,this.error=null}}})))()}var Ub;function Wb(){return(Wb=e((()=>{P(),En(),No(),Bs(),N(),Vt(),tb(),Tv(),jv(),Xv(),Lb(),zb(),ib(),Hb(),Ub=class{constructor(e){this.host=e,this.sessionCatalogs=[],this.pendingCatalogArchives=new Set,this.sessionCatalogRefreshStatus=Ev(),this.loadingMoreSessionCatalogIds=new Set,this.visibleSessionLimits=new Map,this.sessionsResult=null,this.sessionsAgentId=null,this.sessionsLoading=!1,this.childSessionRowsByParent={},this.loadedChildSessionKeys=new Set,this.childSessionErrorsByParent=new Map,this.loadingChildSessionKeys=new Set,this.activeSessionLineageRoot=null,this.activeSessionLineageSelectedRow=null,this.sessionMutationError=null,this.ownerCounts=new Vb(()=>this.requestSessionDataUpdate()),this.sessionResultsByAgent={},this.sessionCatalogLive=new wv,this.sessionScopeGeneration=0,this.sessionCatalogAgentId=null,this.sessionCatalogRevision=0,this.sessionCatalogPageDepths=new Map,this.sessionCatalogRevisions=new Map,this.sessionScopeAgentId=null,this.sessionsSource=null,this.filteredSessionScope=null,this.unsubscribeFilteredSessions=null,this.childSessionScope={},this.childSessionCanonicalListRevision=null,this.childSessionQueries=new Map,this.cachedSessionResult=null,this.stopCatalogBrowserEvents=null,this.gatewaySource=null,this.gatewayConnectionRevision=0,this.gatewayClient=null,this.gatewayConnected=!1,this.gatewayAvailable=!1,this.sessionMutationEpoch=0,this.sessionMutationAbortController=new AbortController,this.scroll=new Rb(()=>this.requestSessionDataUpdate()),this.lineage=new rb(this,()=>({routeId:this.host.activeRouteId,key:this.host.getRouteSessionKey()}),()=>this.childSessionScope),this.expandedAgentId=()=>this.host.expandedAgentId(),this.sessionCatalogIdsWithoutVisibleRows=()=>this.host.sessionCatalogIdsWithoutVisibleRows(),this.requestSessionDataUpdate=()=>this.host.requestUpdate(),this.sessionListQuery=e=>Ab(this.host,e),this.handleCatalogSessionContinued=e=>{Hv(this,e.detail)},this.handleSessionCatalogPageActivation=()=>{Iv(this)},this.invalidateSessionCatalogs=()=>Kv(this),this.archiveSessionCatalog=Yv.bind(null,this),this.refreshSessionCatalogs=()=>Uv(this),this.loadMoreSessionCatalog=e=>qv(this,e),this.updateSessions=e=>{let t=e.state;this.cachedSessionResult&&!e.presentation.resultCached&&(this.sessionsResult===this.cachedSessionResult&&this.clearSessionCache(),this.cachedSessionResult=null),this.childSessionCanonicalListRevision!==e.canonicalListRevision&&(this.childSessionCanonicalListRevision=e.canonicalListRevision,this.loadedChildSessionKeys=new Set([...this.loadedChildSessionKeys].filter(e=>this.childSessionQueries.has(e))),this.lineage.reset(!0),this.requestSessionDataUpdate()),!kb(this.host)&&(!e.presentation.result&&this.sessionsResult&&this.clearSessionCache(),jb(this,{...t,...e.presentation}),this.cachedSessionResult=e.presentation.resultCached?e.presentation.result:null,this.sessionsLoading=t.loading,this.requestSessionDataUpdate())},e.addController(this),this.subscriptions=new Nn({addController:()=>void 0,removeController:()=>void 0,requestUpdate:()=>e.requestUpdate(),get updateComplete(){return e.updateComplete}}),this.subscriptions.watch(()=>this.context?.gateway,(e,t)=>e.subscribe(t),e=>this.synchronizeGateway(e)).watch(()=>this.context?.sessions,(e,t)=>e.subscribe(t),e=>this.synchronizeSessions(e)).effect(()=>this.context?.sessions,t=>t.subscribeCreated(t=>e.promoteCreatedSession(t))).effect(()=>this.context?.gateway,e=>Fb(e,this)).watch(()=>this.context?.agents,(e,t)=>Ob(e,this,t)).watch(()=>this.context?.agentSelection,(e,t)=>e.subscribe(t),()=>this.synchronizeSessionScope())}get context(){return this.host.sessionDataContext}get isSessionDataHostConnected(){return this.host.isConnected}get sessionDataHostConnected(){return this.host.connected}hostConnected(){this.subscriptions.hostConnected(),this.stopCatalogBrowserEvents=Tb(this.handleCatalogSessionContinued,this.handleSessionCatalogPageActivation)}hostUpdate(){this.subscriptions.hostUpdate(),this.lineage.synchronize()}hostUpdated(){this.host.isConnected&&(this.synchronizeSessionScope(),this.synchronizeOwnerSessionCounts(),this.lineage.synchronize(),this.scroll.synchronize(this.host),Rv(this))}hostDisconnected(){this.ownerCounts.dispose(),this.resetChildSessionState(),this.retireFilteredSessions(),this.stopCatalogBrowserEvents?.(),this.stopCatalogBrowserEvents=null,this.host.dismissTransientMenus(),this.invalidateSessionMutations(),this.gatewaySource=null,this.gatewayClient=null,this.gatewayConnected=!1,this.gatewayAvailable=!1,this.retireSessionCatalogData(),this.scroll.dispose(),this.lineage.disconnect(),this.subscriptions.hostDisconnected()}sessionCatalogGatewayClient(){return this.gatewayClient}synchronizeOwnerSessionCounts(){let e=ls(this.presencePayload).users.some(e=>e.identity?.type===`profile`);this.ownerCounts.synchronize(this.host.connected&&e?this.context?.sessions:void 0,this.context?.gateway.snapshot.selfUser?.id??null,this.context?.connectionBootstrap)}retireSessionCatalogData(){this.sessionScopeGeneration+=1,this.pendingCatalogArchives.clear(),this.sessionsLoading=!1,this.loadingMoreSessionCatalogIds=new Set,this.sessionCatalogLive.clear()}resetSessionCatalogConnection(){this.retireSessionCatalogData(),this.sessionCatalogRevision+=1,this.sessionCatalogs=[],this.sessionCatalogRefreshStatus=Ev(),this.sessionCatalogPageDepths.clear(),this.sessionCatalogRevisions.clear(),this.requestSessionDataUpdate()}synchronizeSessionScope(){let e=this.context,t=e?b(this.host.expandedAgentId()):null,n=Fv(this)??(e?.gateway.snapshot.phase===`connected`?null:this.sessionCatalogAgentId);if(t===this.sessionScopeAgentId&&n===this.sessionCatalogAgentId)return;let r=this.sessionScopeAgentId,i=this.sessionCatalogAgentId,a=r!==null&&r!==t,o=i!==null&&i!==n,s=!kb(this.host)&&t!==null&&this.sessionsAgentId!==null&&b(this.sessionsAgentId)===t&&this.sessionsResult===e?.sessions.presentation.result;this.sessionScopeAgentId=t,this.sessionCatalogAgentId=n,this.retireSessionCatalogData(),this.sessionCatalogRevision+=1,this.sessionCatalogRefreshStatus=Ev(),(a||o)&&(this.sessionCatalogs=[],this.sessionCatalogPageDepths.clear(),this.sessionCatalogRevisions.clear()),a&&!s&&this.clearSessionCache(),this.bindFilteredSessions(),this.requestSessionDataUpdate(),a&&e?.gateway.snapshot.phase===`connected`&&kb(this.host)&&this.scheduleSidebarSessions()}handleSessionCatalogHostEvent(e){Vv(this,e)}handleSessionCatalogChanged(e){Bv(this,e)}get sessionsScrollState(){return this.scroll.state}updateSessionsScrollState(e){this.scroll.update(e)}resetChildSessionState(e=!1){for(let e of this.childSessionQueries.values())e.observation?.dispose();this.childSessionQueries.clear(),this.childSessionScope={},this.loadedChildSessionKeys=new Set,this.loadingChildSessionKeys=new Set,this.childSessionErrorsByParent=new Map,e||(this.childSessionRowsByParent={},this.activeSessionLineageRoot=null,this.activeSessionLineageSelectedRow=null),this.lineage.reset(e)}synchronizeSessions(e){let t=e!==this.sessionsSource;t&&(this.invalidateSessionMutations(),this.retireFilteredSessions(),this.clearSessionCache(),this.sessionsSource=e),this.updateSessions(e),this.context?.gateway.snapshot.phase===`connected`&&(this.context.connectionBootstrap.run(e.groupsLoad,()=>e.groupsLoad(),{background:!0}),t&&kb(this.host)&&this.scheduleSidebarSessions())}synchronizeGateway(e){this.lineage.synchronize();let t=e.snapshot.client,n=e.snapshot.phase===`connected`,r=e!==this.gatewaySource||e.connectionRevision!==this.gatewayConnectionRevision,i=t!==this.gatewayClient,a=r||i,o=n!==this.gatewayConnected,s=en(e.snapshot),c=s&&!this.gatewayAvailable;if(this.gatewayAvailable=s,!a&&!o){this.synchronizeOwnerSessionCounts();let{awaitingGateway:e,error:t}=this.sessionCatalogRefreshStatus,n=this.sessionCatalogLive.requestGeneration!==null;c&&(e||t!==null||n)&&Iv(this);return}if(this.invalidateSessionMutations(),this.ownerCounts.dispose(),this.resetChildSessionState(!0),this.gatewaySource=e,this.gatewayConnectionRevision=e.connectionRevision,this.gatewayClient=t,this.gatewayConnected=n,this.presenceInstanceId=t?.instanceId,!n)this.presencePayload=void 0;else if(i||o){let t=Tr(e.snapshot.hello?.snapshot);this.presencePayload=t?{presence:t}:void 0}this.requestSessionDataUpdate(),a?(r&&this.clearSessionCache(),this.resetSessionCatalogConnection()):this.retireSessionCatalogData(),n&&this.sessionsSource&&kb(this.host)&&this.scheduleSidebarSessions()}clearSessionCache(){this.childSessionCanonicalListRevision=null,this.cachedSessionResult=null,this.sessionsResult=null,this.sessionsAgentId=null,this.sessionResultsByAgent={},this.resetChildSessionState(),this.visibleSessionLimits.clear(),this.requestSessionDataUpdate()}retireFilteredSessions(){this.unsubscribeFilteredSessions?.(),this.unsubscribeFilteredSessions=null,this.filteredSessionScope=null}bindFilteredSessions(){let e=this.context?.sessions;if(!e||!kb(this.host)){this.retireFilteredSessions();return}let t=b(this.host.expandedAgentId()),n=this.sessionListQuery(t),r=JSON.stringify(n);this.filteredSessionScope!==r&&(this.retireFilteredSessions(),this.filteredSessionScope=r,this.unsubscribeFilteredSessions=Mb(this,e,n,()=>this.filteredSessionScope===r&&this.context?.sessions===e&&this.host.sidebarSessionStatusFilter()===n.archivedFilter&&b(this.host.expandedAgentId())===t))}refreshSidebarSessions(e){let t=this.host.expandedAgentId();return this.bindFilteredSessions(),e!==void 0&&b(e)!==b(t)?Promise.resolve():Pb(this,t)}scheduleSidebarSessions(){return this.bindFilteredSessions(),Nb(this,()=>this.unsubscribeFilteredSessions)}loadMoreSidebarSessions(){return Pb(this,this.sessionsAgentId,!0)}retireStaleChildSessions(e){for(let[t,n]of this.childSessionQueries)!e.has(t)&&!n.refresh&&!n.hydration&&(n.observation?.dispose(),this.childSessionQueries.delete(t),this.finishChildSessionLoad(t));Ky(this,this.lineage.routeKey,e)}needsChildSessionLoad(e){return!this.childSessionQueries.has(e)&&!this.childSessionErrorsByParent.has(e)}async loadChildSessions(e,t=!1){let n=this.context?.sessions;if(!this.host.isConnected||!n||!n.captureConnectionScope()||!e||this.childSessionErrorsByParent.has(e))return;let r=this.childSessionQueries.get(e);if(r){await r.refresh,await r.hydration;return}let i=Us(e),a={};this.childSessionQueries.set(e,a);let o=()=>this.host.isConnected&&n===this.context?.sessions&&this.childSessionQueries.get(e)===a;if(a.observation=n.observeList(i,r=>{if(!o())return;if(r.loading){a.loading||(a.childRead=this.lineage.captureChildRead(i)),a.loading=!0,this.loadingChildSessionKeys=new Set([...this.loadingChildSessionKeys,e]),this.requestSessionDataUpdate();return}if(r.error){if(t&&!a.observation)return;a.loading=!1,this.childSessionErrorsByParent=new Map(this.childSessionErrorsByParent).set(e,r.error),this.finishChildSessionLoad(e);return}let s=r.result,c=a.loading||!a.result;if(a.loading=!1,s){if(!c){let t=this.childSessionRowsByParent[e];if(t){let r=n.projectRows(t);r.some((e,n)=>e!==t[n])&&(this.childSessionRowsByParent={...this.childSessionRowsByParent,[e]:r},this.requestSessionDataUpdate())}return}a.result=s,!a.hydration&&(a.hydration=Gy({owner:this,parentKey:e,sessions:n,initialResult:s,childRead:a.childRead??this.lineage.captureChildRead(i),ownsQuery:o,selectedKey:()=>this.lineage.routeKey}).finally(()=>{o()&&(a.hydration=void 0,this.finishChildSessionLoad(e))}))}}),!o()){a.observation.dispose();return}a.refresh=a.observation.refresh().catch(()=>void 0).finally(()=>{a.refresh=void 0,o()&&this.requestSessionDataUpdate()}),await a.refresh,await a.hydration}finishChildSessionLoad(e){if(this.childSessionErrorsByParent.has(e)){let t=new Set(this.loadedChildSessionKeys);t.delete(e),this.loadedChildSessionKeys=t,this.childSessionQueries.get(e)?.observation?.dispose(),this.childSessionQueries.delete(e)}let t=new Set(this.loadingChildSessionKeys);t.delete(e),this.loadingChildSessionKeys=t,this.requestSessionDataUpdate()}loadActiveSessionLineage(e){return this.lineage.load(e)}setVisibleSessionLimit(e,t){this.visibleSessionLimits.set(e,t),this.requestSessionDataUpdate()}dismissSessionMutationError(){Eb(this,null,`action`),this.requestSessionDataUpdate()}resetSessionList(){this.retireFilteredSessions(),this.sessionsLoading=!1,this.visibleSessionLimits.clear(),this.resetChildSessionState(),this.sessionResultsByAgent={},!kb(this.host)&&this.context?(this.sessionsResult=this.context.sessions.presentation.result,this.sessionsAgentId=this.context.sessions.presentation.agentId):this.context&&this.bindFilteredSessions(),this.requestSessionDataUpdate()}discardEmptyChildSessionSnapshot(e){if(this.childSessionRowsByParent[e]?.length===0){let t={...this.childSessionRowsByParent};delete t[e],this.childSessionRowsByParent=t;let n=new Set(this.loadedChildSessionKeys);n.delete(e),this.loadedChildSessionKeys=n,this.requestSessionDataUpdate()}}retryChildSessions(e){let t=this.childSessionErrorsByParent.has(e);if(t){this.finishChildSessionLoad(e);let t=new Map(this.childSessionErrorsByParent);t.delete(e),this.childSessionErrorsByParent=t}this.loadChildSessions(e,t)}invalidateSessionMutations(){this.sessionMutationEpoch+=1,Eb(this,null,`action`),this.sessionMutationAbortController.abort(),this.sessionMutationAbortController=new AbortController,this.requestSessionDataUpdate()}beginSessionMutation(){let e=this.context;if(!e||!this.host.connected)return null;let t=e.gateway,n=t.snapshot.client;return t.snapshot.phase!==`connected`||!n?null:(Eb(this,null,`action`),this.requestSessionDataUpdate(),{epoch:this.sessionMutationEpoch,context:e,gateway:t,sessions:e.sessions,client:n,selectedAgentId:this.host.selectedAgentIdForSessions(),signal:this.sessionMutationAbortController.signal})}isSessionMutationScopeCurrent(e){let t=this.context,n=t?.gateway;return this.host.connected&&this.sessionMutationEpoch===e.epoch&&t===e.context&&n===e.gateway&&t.sessions===e.sessions&&n.snapshot.phase===`connected`&&n.snapshot.client===e.client}publishSessionMutationError(e,t){this.isSessionMutationScopeCurrent(e)&&(Eb(this,E(t),`action`),this.requestSessionDataUpdate())}}})))()}var Gb;function Kb(){return(Kb=e((()=>{K(),Gb=class{constructor(e,t){this.host=e,this.getContext=t,this.ownerId=null,this.involvingMe=!1,this.scope=null,this.ownerFacetResolved=!1,this.ownerOptions=[],this.pendingFacetRefresh=null,e.addController(this)}hostUpdated(){this.restore(),!this.pendingFacetRefresh&&this.ownerFacetResolved&&this.ownerId&&!this.ownerOptions.some(e=>e.id===this.ownerId)&&this.set(null)}observeOwnerFacet(e,t){this.pendingFacetRefresh||(this.ownerFacetResolved=e,this.ownerOptions=t)}set(e,t=!1){this.pendingFacetRefresh=null,this.ownerId=t?null:e?.trim()||null,this.involvingMe=t;let n=this.getContext(),r=n?.gateway.snapshot.selfUser?.id.trim();n&&r&&zg(n.gateway.connection.gatewayUrl,r,this.currentFilter()),this.host.requestUpdate(),this.host.sessionData.resetSessionList(),this.host.sessionData.refreshSidebarSessions()}restore(){let e=this.getContext(),t=e?.gateway.snapshot.selfUser?.id.trim();if(!e||!t)return;let n=e.gateway.connection.gatewayUrl,r=`${n}\0${t}`;if(r===this.scope)return;let i=this.scope;if(this.scope=r,i===null&&(this.ownerId||this.involvingMe))zg(n,t,this.currentFilter());else{let e=Dg(n,t);this.ownerId=e.ownerId,this.involvingMe=e.involvingMe}if(this.host.requestUpdate(),i!==null||this.ownerId||this.involvingMe){this.ownerFacetResolved=!1,this.ownerOptions=[],this.host.sessionData.resetSessionList();let e=this.host.sessionData.scheduleSidebarSessions();this.pendingFacetRefresh=e,e.finally(()=>{this.pendingFacetRefresh===e&&(this.pendingFacetRefresh=null,this.host.requestUpdate())})}}currentFilter(){return{ownerId:this.ownerId,involvingMe:this.involvingMe}}}})))()}var qb,Jb,Yb;function Xb(){return(Xb=e((()=>{qb=`openclaw.control.sidebarEmptyGroups.v1:`,Jb=`openclaw:sidebar:sessions:hide-empty-groups`,Yb=class{constructor(e,t){this.host=e,this.getContext=t,this.mode=`filtering`,this.storageKey=null,this.owner=null}set(e){if(this.reconcile()){this.host.requestUpdate();return}this.mode=e;try{this.storageKey&&D()?.setItem(this.storageKey,e)}catch{}this.host.requestUpdate()}reconcile(){let e=this.getContext()?.gateway,t=e?Te(e.connection.gatewayUrl):``,n=!e||e.snapshot.phase===`stopped`||this.owner?.gateway!==e||this.owner.revision!==e.connectionRevision||this.owner.origin!==t,r=!1;if(n&&(r=this.storageKey!==null,this.storageKey=null,this.mode=`filtering`,this.owner=e&&e.snapshot.phase!==`stopped`?{gateway:e,revision:e.connectionRevision,origin:t}:null),!e||e.snapshot.phase!==`connected`)return r;let i=e.snapshot.selfUser?.id.trim(),a=`${qb}${t}:${i?`user:${encodeURIComponent(i)}`:`browser`}`;if(a===this.storageKey)return r;this.storageKey=a,this.mode=`filtering`;try{let e=D(),t=e?.getItem(a);if(t===`filtering`||t===`always`||t===`never`)return this.mode=t,!0;let n=e?.getItem(Jb);t==null&&(n===`true`||n===`false`)&&(this.mode=n===`true`?`always`:`filtering`,e?.setItem(a,this.mode),e?.removeItem(Jb))}catch{}return!0}}})))()}var Zb;function Qb(){return(Qb=e((()=>{H(),Xi(),ii(),F(),xs(),as(),Qt(),N(),Iy(),Ly(),tb(),_v(),_p(),cb(),Ey(),fb(),mb(),yb(),K(),wb(),Wb(),Kb(),Xb(),Zb=class extends q{constructor(...e){super(...e),this.rosterSessionSource=null,this.rosterVisibleSessionLimits=new Map,this.sessionSortMode=Og(),this.sessionProjection=new vb,this.sessionData=new Ub(this),this.sessionPullRequests=new pb(this,{getConnected:()=>this.connected,getRows:()=>sb({rows:this.visibleSessionRowsInOrder(),adopted:dp(this.visibleSessionCatalogs()),sessionsResult:this.groupedSessionSource?.result??this.sessionData.sessionsResult,sessionResultsByAgent:this.sessionData.sessionResultsByAgent,navigationState:this.getSessionNavigationState()}),getSelectedAgentId:()=>this.selectedAgentIdForSessions(),getGateway:()=>this.context?.gateway,getSessions:()=>this.context?.sessions}),this.readSidebarSessionSortOptions=()=>({sortMode:this.effectiveSessionSortMode(),owners:this.selectedAgentSessionResult()?.owners,createdOrder:this.sessionProjection.createdOrder}),this.sessionOwnerFilter=new Gb(this,()=>this.context),this.sessionOwnerOptions=[],this.activeSessionOwnerId=null,this.sessionOwnershipVisibility={filters:!1,avatars:!1},this.selectedSessionKeys=new Set,this.sessionsGrouping=bg(),this.sessionsShowCron=Sg(),this.sessionsShowPreview=Cg(),this.sessionsShowSystem=wg(),this.emptyGroups=new Yb(this,()=>this.context),this.sessionsStatusFilter=Tg(),this.hiddenSessionCatalogIds=jg(),this.visibleSessionCatalogs=()=>fp(lv(this.sessionData.sessionCatalogs,this.sessionData.pendingCatalogArchives),this.hiddenSessionCatalogIds,this.sessionsStatusFilter===`archived`),this.catalogLiveRows=()=>[...this.sessionData.sessionsResult?.sessions??[],...Object.values(this.sessionData.sessionResultsByAgent).flatMap(e=>e.sessions)],this.sidebarSessionCatalogs=()=>mp(this.visibleSessionCatalogs(),this.activeSessionOwnerId,this.catalogLiveRows()),this.sessionCatalogIdsWithoutVisibleRows=()=>{let e=new Set(this.sidebarSessionCatalogs().map(e=>e.id));return this.visibleSessionCatalogs().filter(t=>!e.has(t.id)).map(e=>e.id)},this.sessionSelectionAnchor=null,this.runtimeSampledAtByRow=new WeakMap,this.attention=new Cb(this),this.setSessionOwnerFilter=(e,t=!1)=>this.sessionOwnerFilter.set(e,t),this.selectSession=(e,t)=>{let n=this.findSidebarSessionByKey(e),r=t!==void 0&&this.sidebarAgentsMode===`roster`,i=r?`chat`:Vn(n),a=t??this.sessionNavigationAgentId(n??{key:e}),o=Bn({face:i,sessionKey:e,fallbackAgentId:a,basePath:this.basePath,row:n,mainKey:this.sessionMainKey(),preferenceDerivedFace:!r,navigationKey:e});ko(this,{agentId:a,commit:()=>(this.sidebarAgentsMode===`roster`&&this.expandAgent(a),this.prepareSessionNavigation(e,o.options.pathname),this.onNavigate?.(i,o.options),this.bindLiteralSession(e,a,o.options),!0),face:i,sessionKey:e})},this.expandAgent=e=>{let t=this.context;if(!t)return;let n=b(e);if(n===b(this.expandedAgentId())){this.sidebarAgentsMode!==`roster`&&t.agentSelection.setScope(n);return}this.clearSessionSelection(),this.sidebarAgentsMode!==`roster`&&(this.sessionProjection.resetMembership(),this.sessionData.visibleSessionLimits.clear()),t.agentSelection.set(n)},this.knownSectionOrder=()=>[...this.context?.sessions.state.sectionOrder??[]],this.resolveSessionAttention=this.attention.createResolver(),this.openMainSession=e=>{if(!this.connected){this.onNavigate?.(`appearance`);return}this.clearSessionSelection();let t=b(e);this.selectSession(this.selectedAgentMainSessionKey(t),t)}}get groupedSessionSource(){return this.sidebarAgentsMode===`roster`?this.rosterSessionSource:null}sessionPeopleSortCapability(){let e=this.selectedAgentSessionResult()?.owners;return e?e.length>=2:void 0}sessionPeopleSortAvailable(){return this.sessionPeopleSortCapability()!==!1}effectiveSessionSortMode(){return Bg(this.sessionSortMode,this.sessionPeopleSortAvailable())}effectiveSessionsGrouping(){let e=this.sessionsGrouping;return e===`person`&&!this.sessionPeopleSortAvailable()?`category`:e}setSessionSortMode(e){this.sessionSortMode=Vg(e,this.sessionPeopleSortCapability())}sidebarSessionOwnerFilter(){return this.sessionOwnerFilter}get sessionOwnerFilterId(){return this.sessionOwnerFilter.ownerId}get sessionInvolvingMeFilterActive(){return this.sessionOwnerFilter.involvingMe}get sessionOwnerFilterActive(){return this.sessionOwnerFilter.ownerId!==null}get sessionsEmptyGroupsMode(){return this.emptyGroups.mode}setSessionsEmptyGroupsMode(e){this.emptyGroups.set(e)}get sessionAttentionContext(){return this.context}get sessionDataContext(){return this.context}get collapsedSessionSections(){return this.sessionOrganizer.collapsedSessionSections}dismissTransientMenus(){return this.sidebarMenus.dismissTransientMenus()}promoteCreatedSession(e){this.sessionProjection.promoteCreatedSession(e)&&this.requestUpdate()}willUpdate(e){this.resolveSessionAttention=this.attention.createResolver(),this.emptyGroups.reconcile()&&this.sidebarMenus.sessionSortMenuPosition&&this.sidebarMenus.closeSessionSortMenu(),super.willUpdate(e)}updated(e){super.updated(e),this.sessionSortMode===`people`&&this.sessionPeopleSortCapability()===!1&&this.setSessionSortMode(`created`),Ji(this.activeRouteId)&&this.sessionData.loadActiveSessionLineage(this.getRouteSessionKey()),Wy(this.sessionData,()=>this.childSessionParents())}childSessionParents(){let e=new Set,t=[...this.visibleSessionRowsInOrder()];for(;t.length>0;){let n=t.shift();if(n&&(t.push(...n.children),(n.childLoadParentKeys?.length??0)>0&&(n.visuallyActive||this.isSessionChildrenExpanded(n))))for(let t of n.childLoadParentKeys??[n.key])e.add(t)}let n=this.groupedSessionSource,r=n?n.agentIds.filter(e=>!n.collapsedAgentIds.has(e)):[this.expandedAgentId()];for(let t of r){let n=this.mainSessionRow(t);if(n?.childSessions?.length)for(let r of this.projectHomeSession(n,t).childLoadParentKeys??[])e.add(r)}return e}applySessionOwnerFilter(e,t){let n=db({projected:e,ownerFacet:t,selectedOwnerId:this.sessionOwnerFilterId,self:this.context?.gateway.snapshot.selfUser});return this.sessionOwnerFilter.observeOwnerFacet(t!==void 0,n.ownerOptions),this.sessionOwnerOptions=n.ownerOptions,this.sessionOwnershipVisibility=n.ownershipVisibility,this.activeSessionOwnerId=n.activeOwnerId,n.rows}getRouteSessionKey(){return this.sessionKey.trim()||this.context?.gateway.snapshot.sessionKey.trim()||``}getSessionNavigationState(){let e=this.getRouteSessionKey(),t=fy({context:this.context,routeSessionKey:e,sessionsResult:this.groupedSessionSource?.result??this.sessionData.sessionsResult,activeSession:ab(this.sessionData,e),sessionsAgentId:this.sessionData.sessionsAgentId,showCron:this.sessionsShowCron,showSystem:this.sessionsShowSystem,statusFilter:this.sessionsStatusFilter,compareSessions:ly(this.readSidebarSessionSortOptions),highlightCurrentSession:Ji(this.activeRouteId),runtimeSampledAtByRow:this.runtimeSampledAtByRow,loadingChildSessionKeys:this.sessionData.loadingChildSessionKeys,outboxAttentionCountForSessionKey:this.outboxAttentionCountForSession,hasSessionDraft:e=>this.hasSessionDraft(e),resolveAttention:this.resolveSessionAttention,resolveAgentStatusNote:e=>this.attention.resolveSessionAgentStatus(e)?.note});if(this.groupedSessionSource){let e=this.groupedSessionSource.result?.sessions??[],n=t.visibleSessionRows.find(e=>e.key===t.activeRowKey);t.visibleSessionRows=n&&!e.some(e=>e.key===n.key)?[...e,n]:[...e]}return t}selectedAgentIdForSessions(){return this.getSessionNavigationState().selectedAgentId}sessionNavigationAgentId(e){return this.sidebarAgentsMode===`roster`?He(e,Ft({agentsList:this.context?.agents.state.agentsList,hello:this.context?.gateway.snapshot.hello})):this.selectedAgentIdForSessions()}sidebarSessionHref(e){return Bn({face:Vn(e),sessionKey:e.key,fallbackAgentId:this.sessionNavigationAgentId(e),basePath:this.context?.basePath??``,row:e,mainKey:this.context?this.sessionMainKey():void 0,preferenceDerivedFace:!0}).href}sidebarSessionStatusFilter(){return this.sessionsStatusFilter}zonedVisibleSections(e,t=this.sidebarSessionCatalogs()){let n=this.effectiveSessionsGrouping(),r=this.groupedSessionSource,i=r?.agentIds.map(t=>({id:`agent:${t}:recent`,rows:e.filter(e=>!e.pinned&&this.sessionNavigationAgentId(e)===t)})),a=new Set(this.collapsedSessionSections);for(let e of r?.collapsedAgentIds??[])a.add(`agent:${e}:recent`);return this.sessionProjection.project({rows:e,sections:i,grouping:n,knownGroups:n===`category`?this.knownSessionGroups():[],selfOwnerId:this.context?.gateway.snapshot.selfUser?.id??null,sectionOrder:this.knownSectionOrder(),catalogIds:t.map(e=>e.id),collapsedSections:a,emptyGroupsMode:this.sessionsEmptyGroupsMode,ownerFiltered:this.sessionOwnerFilterActive||this.sessionInvolvingMeFilterActive,visibleSessionLimits:r?this.rosterVisibleSessionLimits:this.sessionData.visibleSessionLimits,sortMode:this.effectiveSessionSortMode(),statusFilter:this.sessionsStatusFilter,agentId:r?`*`:this.expandedAgentId(),connectionIdentity:this.context?.gateway.snapshot.phase===`connected`?this.context.gateway.snapshot.client??null:null,listSource:this.context?.sessions??null,subtitle:{sidebarLiveActivity:this.sidebarLiveActivity,showPreview:this.sessionsShowPreview,narrationLines:this.sidebarNarrationLines,observerDigests:this.sidebarObserverDigests}})}reconciledSidebarZone(e=this.selectedAgentSessionRows(this.getSessionNavigationState())){return py({sidebarEntries:this.sidebarEntries,rows:e,pluginNavigation:this.pluginNavigation(),pluginTabs:this.context?.gateway.snapshot.hello?.controlUiTabs})}pruneSidebarSessionEntry(e){let t=ir({type:`session`,key:e});this.sidebarEntries.includes(t)&&this.onUpdateSidebarEntries?.(this.sidebarEntries.filter(e=>e!==t))}visibleSessionRowsInOrder(){let e=this.getSessionNavigationState(),t=this.selectedAgentSessionRows(e),{visibleRows:n}=this.zonedVisibleSections(t),{entries:r,sessionRows:i}=this.reconciledSidebarZone(t);return[...r.flatMap(e=>{let t=e.type===`session`?i.get(e.key):void 0;return t?[t]:[]}),...n]}selectedVisibleSessions(){return this.selectedSessionKeys.size===0?[]:this.visibleSessionRowsInOrder().filter(e=>this.selectedSessionKeys.has(e.key))}handleSessionRowClick(e,t){if(t.isChild&&k(e)){e.preventDefault(),this.clearSessionSelection(),this.selectSession(t.key);return}if(!(t.isChild||e.defaultPrevented||e.button!==0)&&!(e.metaKey||e.ctrlKey)){if(e.shiftKey){e.preventDefault(),this.extendSessionSelection(t.key);return}if(e.altKey){e.preventDefault(),this.toggleSessionSelected(t.key);return}e.preventDefault(),this.clearSessionSelection(),this.selectSession(t.key)}}toggleSessionSelected(e){let t=my(this.selectedSessionKeys,e);this.sessionSelectionAnchor=t.anchor,this.selectedSessionKeys=t.selectedKeys}extendSessionSelection(e){let t=hy({rows:this.visibleSessionRowsInOrder(),anchor:this.sessionSelectionAnchor,key:e});this.sessionSelectionAnchor=t.anchor,this.selectedSessionKeys=t.selectedKeys}clearSessionSelection(){this.sessionSelectionAnchor=null,this.selectedSessionKeys.size>0&&(this.selectedSessionKeys=new Set)}expandedAgentId(){let e=Ae(this.context?.agentSelection.state.selectedId);return b(e||this.getSessionNavigationState().selectedAgentId)}activeChipAgent(){return gy({activeId:this.expandedAgentId(),roster:this.context?.agents.state.agentsList?.agents??[],identities:this.context?.agentIdentity.entries()??[]})}agentResumeKey(e){return by(_y({agentId:e,sessionData:this.sessionData,context:this.context}),e,this.sessionMainKey())}openAgentConversation(e){if(!this.connected){this.onNavigate?.(`appearance`);return}this.selectSession(this.agentResumeKey(e))}switchChipAgent(e){this.sidebarMenus.closeAgentMenu(),this.expandAgent(e),this.activeRouteId!==`skills`&&this.openAgentConversation(e)}askAgentCapabilities(e){if(this.sidebarMenus.closeAgentMenu(),!this.connected)return;let t=this.agentResumeKey(e),n=Bn({face:`chat`,sessionKey:t,fallbackAgentId:e,basePath:this.basePath,row:this.findSidebarSessionByKey(t),mainKey:this.sessionMainKey()});ko(this,{sessionKey:t,agentId:e,face:`chat`,commit:()=>(this.setApplicationSession(t,e),this.onNavigate?.(`chat`,{...n.options,search:wn(j(`chat.welcome.suggestions.whatCanYouDo`))}),!0)})}knownSessionGroups(){return Ys(this.context?.sessions.state.groups??[],this.sessionData.sessionsResult?.sessions??[])}knownSessionCatalogIds(){return xy({loadedCatalogIds:this.sessionData.sessionCatalogs.map(e=>e.id),hasLoaded:this.sessionData.sessionCatalogRefreshStatus.hasLoaded,sectionOrder:this.knownSectionOrder()})}findSidebarSessionByKey(e){return Ty({sessionKey:e,navigationState:this.getSessionNavigationState(),sessionResultsByAgent:this.sessionData.sessionResultsByAgent})}findSidebarHovercardRowByKey(e){return ob(this,e,this.selectedAgentSessionRows(this.getSessionNavigationState()))}selectedAgentSessionRows(e){let t=this.groupedSessionSource,n=this.expandedAgentId(),r=Py({host:this,navigationState:e,selected:n,agentIds:t?.agentIds??[n],result:t?.result,compareSessions:ly(this.readSidebarSessionSortOptions),resolveAttention:this.resolveSessionAttention});return this.applySessionOwnerFilter(r,this.selectedAgentSessionResult()?.owners)}selectedAgentSessionResult(){if(this.groupedSessionSource)return this.groupedSessionSource.result;let e=this.expandedAgentId();return e===b(this.sessionData.sessionsAgentId??``)?this.sessionData.sessionsResult:this.sessionData.sessionResultsByAgent[e]??null}selectedAgentMainSessionKey(e){return Sy({agentId:e??this.expandedAgentId(),agentsList:this.context?.agents.state.agentsList,hello:this.context?.gateway.snapshot.hello})}projectHomeSession(e,t){return Fy({host:this,row:e,agentId:t,result:this.groupedSessionSource?.result,navigationState:this.getSessionNavigationState(),resolveAttention:this.resolveSessionAttention})}mainSessionRow(e){let t=b(e??this.expandedAgentId()),n=this.selectedAgentMainSessionKey(t),r=this.groupedSessionSource?.result?.sessions??(t===b(this.sessionData.sessionsAgentId??``)?this.sessionData.sessionsResult?.sessions??[]:this.sessionData.sessionResultsByAgent[t]?.sessions??[]),i=this.sessionData.activeSessionLineageRoot;return Cy(i?[...r,i]:r,n)}isSessionChildrenExpanded(e){return this.sessionProjection.isChildrenExpanded(e.key)}isSessionChildrenFullyShown(e){return this.sessionProjection.isChildrenFullyShown(e)}toggleSessionChildren(e){let{expanded:t}=this.sessionProjection.toggleChildren(e);for(let n of e.childLoadParentKeys??[e.key])t?this.sessionData.retryChildSessions(n):this.sessionData.discardEmptyChildSessionSnapshot(n);this.requestUpdate()}showMoreChildren(e){this.sessionProjection.showMoreChildren(e),this.requestUpdate()}agentUnreadCount(e){return(this.sessionData.sessionResultsByAgent[b(e)]?.sessions??[]).filter(e=>e.unread===!0&&e.archived!==!0).length}},w([V()],Zb.prototype,`rosterSessionSource`,void 0),w([V()],Zb.prototype,`sessionSortMode`,void 0),w([V()],Zb.prototype,`selectedSessionKeys`,void 0),w([V()],Zb.prototype,`sessionsGrouping`,void 0),w([V()],Zb.prototype,`sessionsShowCron`,void 0),w([V()],Zb.prototype,`sessionsShowPreview`,void 0),w([V()],Zb.prototype,`sessionsShowSystem`,void 0),w([V()],Zb.prototype,`sessionsStatusFilter`,void 0),w([V()],Zb.prototype,`hiddenSessionCatalogIds`,void 0)})))()}function $b(e){return R`
    <div class="community-invite-card">
      <aside class="invite" role="complementary" aria-label=${j(`communityInvite.cardLabel`)}>
        <div class="invite__header">
          <img
            class="invite__art"
            src=${or(`community-art/discord-invite.webp`)}
            alt=${j(`communityInvite.artAlt`)}
            width="1024"
            height="538"
            loading="lazy"
          />
          <button
            class="invite__close"
            type="button"
            aria-label=${j(`communityInvite.dismissForever`)}
            @click=${e}
          >
            ${I.x}
          </button>
        </div>
        <div class="invite__body">
          <h2 class="invite__title">${j(`communityInvite.title`)}</h2>
          <p class="invite__text">
            ${j(`communityInvite.body`)} ${j(`communityInvite.bodyGreeting`)}
          </p>
          <a
            class="invite__cta"
            href=${ys}
            target=${Sc}
            rel=${Es()}
          >
            ${ex}
            <span>${j(`communityInvite.action`)}</span>
          </a>
        </div>
      </aside>
    </div>
  `}var ex;function tx(){return(tx=e((()=>{B(),dr(),F(),vc(),mc(),L(),ex=R`
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path
      d="M20.32 4.37a19.8 19.8 0 0 0-4.93-1.51 13.78 13.78 0 0 0-.64 1.29 18.27 18.27 0 0 0-5.5 0 12.64 12.64 0 0 0-.64-1.29 19.74 19.74 0 0 0-4.93 1.51C.53 9.05-.32 13.6.1 18.06a19.9 19.9 0 0 0 6.07 3.03c.46-.63.87-1.3 1.24-2a12.86 12.86 0 0 1-1.96-.93c.16-.12.32-.24.48-.37a14.2 14.2 0 0 0 12.14 0c.16.13.32.25.48.37-.63.37-1.28.68-1.96.93.36.7.78 1.37 1.24 2a19.84 19.84 0 0 0 6.07-3.03c.5-5.18-.84-9.68-3.58-13.69ZM8.02 15.33c-1.18 0-2.16-1.08-2.16-2.42 0-1.33.95-2.42 2.16-2.42 1.21 0 2.18 1.09 2.16 2.42 0 1.34-.95 2.42-2.16 2.42Zm7.97 0c-1.18 0-2.15-1.08-2.15-2.42 0-1.33.95-2.42 2.15-2.42 1.22 0 2.18 1.09 2.16 2.42 0 1.34-.94 2.42-2.16 2.42Z"
    />
  </svg>
`})))()}function nx(){if(ax)return!1;try{return D()?.getItem(ix)===null}catch{return!1}}function rx(){ax=!0;try{let e=D();return e?(e.setItem(ix,JSON.stringify({dismissedAtMs:Date.now()})),ax=!1,x(void 0)):m(`storage-unavailable`)}catch{return m(`storage-unavailable`)}}var ix,ax;function ox(){return(ox=e((()=>{ix=`openclaw:control-ui:community-invite`,ax=!1})))()}var sx;function cx(){return(cx=e((()=>{Xi(),F(),Cc(),xs(),K(),n(),sx=class{constructor(e){this.host=e,this.collapsedSessionSections=Ag(),this.draggingSessionKey=null,this.draggingSidebarSection=null,this.sessionDropTarget=null,this.sidebarSectionDropTarget=null,this.draggingSidebarEntry=null,this.sidebarZoneDropTarget=null,this.sessionListRemovalDrop=!1,this.operationsLoad=null,this.patchSession=async(e,t,n={})=>{let r=this.host.sessionData.beginSessionMutation();if(!r)return`stale`;let i=await this.loadOperations(r);return i?i.patchSession(this.host,e,t,r,n):this.host.sessionData.isSessionMutationScopeCurrent(r)?`failed`:`stale`}}async loadOperations(e){let t=this.operationsLoad??=T(()=>import(`./session-organizer-operations.runtime-BxG48QHf.js`),__vite__mapDeps([16,1,2,3,4,5,6,17,18,19,7,10,8,9]),import.meta.url);try{return await t}catch(n){return this.operationsLoad===t&&(this.operationsLoad=null),this.host.sessionData.publishSessionMutationError(e,n),null}}async runOperation(e){let t=this.host.sessionData.beginSessionMutation();if(t){let n=await this.loadOperations(t);n&&await e(n,t)}}async archiveSessionWithUndo(e){await this.runOperation((t,n)=>t.archiveSessionWithUndo(this.host,e,n))}async runBatchSessionAction(e,t,n){if(e.kind===`new-group`){await this.createSessionGroup(t);return}await this.runOperation((r,i)=>r.runBatchSessionAction(this.host,e,t,n,i))}async forkSession(e){await this.runOperation((t,n)=>t.forkSession(this.host,e,n))}async stopCloudWorker(e){await this.runOperation((t,n)=>t.stopCloudWorker(this.host,e,n))}async setSessionInvolvement(e,t){await this.runOperation((n,r)=>n.setSessionInvolvement(this.host,e,t,r))}async assignSessionOwner(e,t){await this.runOperation((n,r)=>n.assignSessionOwner(this.host,e,t,r))}async deleteSession(e){await this.runOperation((t,n)=>t.deleteSession(this.host,e,n,{offerSkip:!0}))}startSidebarRouteDrag(e,t){e.dataTransfer&&(So(e.dataTransfer,t),this.draggingSidebarEntry=ir({type:`route`,route:t}),this.host.requestUpdate())}startSidebarPluginDrag(e,t){if(!e.dataTransfer)return;let n=ir({type:`plugin`,key:t});So(e.dataTransfer,n),this.draggingSidebarEntry=n,this.host.requestUpdate()}finishSidebarEntryDrag(){this.draggingSidebarEntry=null,this.draggingSessionKey=null,this.sidebarZoneDropTarget=null,this.sessionListRemovalDrop=!1,this.host.requestUpdate()}startSessionDrag(e){this.draggingSessionKey=e.key,this.draggingSidebarEntry=e.pinned?`session:${e.key}`:null,this.host.requestUpdate()}finishSessionDrag(){this.sessionDropTarget=null,this.finishSidebarEntryDrag()}startSidebarSectionDrag(e){this.draggingSidebarSection=e,this.host.requestUpdate()}finishSidebarSectionDrag(){this.draggingSidebarSection=null,this.sidebarSectionDropTarget=null,this.host.requestUpdate()}draggedSidebarEntry(e){let t=bc(e),n=ea(t?`route:${t}`:null);if(n?.type===`route`)return ir(n);let r=ea(t);if(r?.type===`plugin`)return ir(r);let i=Ds(e);return i?ir({type:`session`,key:i}):null}handleSidebarZoneDragOver(e,t){if(!gc(e.dataTransfer)&&!vo(e.dataTransfer))return;if(e.preventDefault(),e.stopPropagation(),e.dataTransfer&&(e.dataTransfer.dropEffect=`move`),!t){this.sidebarZoneDropTarget=null,this.host.requestUpdate();return}let n=e.currentTarget.getBoundingClientRect();this.sidebarZoneDropTarget={entry:t,position:e.clientY<n.top+n.height/2?`before`:`after`},this.host.requestUpdate()}handleSidebarZoneDragLeave(e){let t=e.currentTarget;e.relatedTarget instanceof Node&&t.contains(e.relatedTarget)||(this.sidebarZoneDropTarget=null,this.host.requestUpdate())}writeSidebarEntryAt(e,t,n){let r=this.host.reconciledSidebarZone().sidebarEntries.filter(t=>t!==e),i=t?r.indexOf(t):-1,a=+(n===`after`);r.splice(i<0?r.length:i+a,0,e),this.host.onUpdateSidebarEntries?.(r)}handleSidebarZoneDrop(e,t){let n=this.draggedSidebarEntry(e.dataTransfer);if(!n)return;if(e.preventDefault(),e.stopPropagation(),t===n){this.finishSidebarEntryDrag();return}let r=this.sidebarZoneDropTarget?.position,i=Ds(e.dataTransfer),a=i?this.host.findSidebarSessionByKey(i):void 0;if(a&&!a.pinnable){this.finishSidebarEntryDrag();return}a&&!a.pinned?this.patchSession(a,{pinned:!0},{sessionScope:!0}).then(e=>{e===`completed`&&this.writeSidebarEntryAt(n,t,r)}):this.writeSidebarEntryAt(n,t,r),this.finishSidebarEntryDrag()}removeSidebarEntry(e){let t=this.host.reconciledSidebarZone().sidebarEntries.filter(t=>t!==e);this.host.onUpdateSidebarEntries?.(t)}canRemoveSidebarEntry(e){let t=ea(e);return t?.type!==`plugin`||!this.host.reconciledSidebarZone().defaultPluginNavigationKeys.has(t.key)}handleSessionListDragOver(e){if(!this.canRemoveSidebarEntry(this.draggingSidebarEntry))return;let t=gc(e.dataTransfer),n=Ds(e.dataTransfer),r=n?this.host.findSidebarSessionByKey(n):void 0;(t||r?.pinned)&&(e.preventDefault(),e.dataTransfer&&(e.dataTransfer.dropEffect=`move`),this.sessionListRemovalDrop=!0,this.host.requestUpdate())}handleSessionListDragLeave(e){let t=e.currentTarget;e.relatedTarget instanceof Node&&t.contains(e.relatedTarget)||(this.sessionListRemovalDrop=!1,this.host.requestUpdate())}handleSessionListDrop(e){let t=bc(e.dataTransfer),n=ea(t?`route:${t}`:null),r=ea(t),i=n?.type===`route`?n:r?.type===`plugin`?r:null;if(i){e.preventDefault();let t=ir(i);this.canRemoveSidebarEntry(t)&&this.removeSidebarEntry(t),this.finishSidebarEntryDrag();return}let a=Ds(e.dataTransfer),o=a?this.host.findSidebarSessionByKey(a):void 0;o?.pinned&&(e.preventDefault(),this.patchSession(o,{pinned:!1},{sessionScope:!0})),this.finishSidebarEntryDrag()}async loadInputDialog(){try{return(await T(async()=>{let{showInputDialog:e}=await import(`./input-dialog-BFYyIfPn.js`);return{showInputDialog:e}},__vite__mapDeps([20,18,7]),import.meta.url)).showInputDialog}catch(e){let t=this.host.sessionData.beginSessionMutation();return t&&this.host.sessionData.publishSessionMutationError(t,e),null}}async renameSession(e){await this.runOperation((t,n)=>t.renameSession(this.host,e,n))}async createSessionGroup(e=[]){await(await this.loadInputDialog())?.({title:j(`sessionsView.newGroupTitle`),label:j(`sessionsView.newGroupPrompt`),submitLabel:j(`sessionsView.newGroupCreate`),requireValue:!0,submit:t=>this.writeSessionGroup(t,e)})}async writeSessionGroup(e,t){let n=this.host.sessionData.beginSessionMutation();if(!n)return j(`sessionsView.newGroupFailed`);let r=await this.loadOperations(n);if(!r)return this.host.sessionData.isSessionMutationScopeCurrent(n)?this.sessionGroupFailure():j(`sessionsView.newGroupStale`);let i=await r.createSessionGroup(this.host,e,t,n);return i===`failed`?this.sessionGroupFailure():i===`stale`?j(`sessionsView.newGroupStale`):null}sessionGroupFailure(){return this.host.sessionData.sessionMutationError??j(`sessionsView.newGroupFailed`)}async renameSessionGroupFromMenu(e){let t=await(await this.loadInputDialog())?.({title:j(`sessionsView.renameGroupTitle`,{group:e}),label:j(`sessionsView.groupNameLabel`),defaultValue:e,requireValue:!0,requireChange:!0});if(!t)return;let n=this.host.sessionData.beginSessionMutation();if(!n)return;let r=await this.loadOperations(n);if(!r||!await r.renameSessionGroup(this.host,e,t,n))return;let i=`category:${e}`;if(this.collapsedSessionSections.has(i)){let e=new Set(this.collapsedSessionSections);e.delete(i),e.add(`category:${t}`),this.saveCollapsedSessionSections(e)}this.host.requestUpdate()}async deleteSessionGroupFromMenu(e){let t=this.host.sessionData.beginSessionMutation();if(!t)return;let n=await this.loadOperations(t);if(!n||!await n.deleteSessionGroup(this.host,e,t))return;let r=new Set(this.collapsedSessionSections);r.delete(`category:${e}`),this.saveCollapsedSessionSections(r),this.host.requestUpdate()}async editSessionGroupDefaults(e){let t;try{t=(await T(async()=>{let{showSessionGroupDefaultsDialog:e}=await import(`./session-group-defaults-dialog-BOcIk5kI.js`);return{showSessionGroupDefaultsDialog:e}},__vite__mapDeps([21,1,2,3,4,5,6,22,23,24,25,26,7,10,8,9,27,28,29,30,31]),import.meta.url)).showSessionGroupDefaultsDialog}catch(e){let t=this.host.sessionData.beginSessionMutation();t&&this.host.sessionData.publishSessionMutationError(t,e);return}let n=this.host.sessionGroupDefaults(e);n&&await t({group:e,defaults:n,listDirectory:e=>this.host.listSessionGroupFolders(e),inspectRepository:e=>this.host.inspectSessionGroupRepository(e),submit:async t=>{let n=this.host.sessionData.beginSessionMutation();if(!n||!this.host.sessionGroupDefaults(e))return j(`sessionsView.groupDefaultsStale`);let r=await(await this.loadOperations(n))?.updateSessionGroupDefaults(this.host,e,{cwd:t.cwd||null,worktree:t.worktree},n);return r===`completed`?null:r===`stale`?j(`sessionsView.groupDefaultsStale`):this.host.sessionData.sessionMutationError??j(`sessionsView.groupDefaultsFailed`)}})}saveCollapsedSessionSections(e){this.collapsedSessionSections=new Set(e),this.host.requestUpdate(),Hg(e)}toggleSection(e){let t=new Set(this.collapsedSessionSections);t.has(e)?t.delete(e):t.add(e),this.saveCollapsedSessionSections(t)}async reorderSidebarSection(e,t,n){await this.runOperation((r,i)=>r.reorderSidebarSection(this.host,e,t,n,i))}async assignSessionCategory(e,t,n={}){await this.runOperation((r,i)=>r.assignSessionCategory(this.host,e,t,i,n))}sectionAcceptsSession(e,t,n){return e===`pinned`||this.host.sessionsGrouping===`category`&&(e===`ungrouped`||t)?!0:e===`groups`&&!!(n&&lc(n,this.host.sessionsGrouping))}sectionDragOver(e,t,n){let r=e.dataTransfer;if(is(r)&&this.draggingSidebarSection!==t){e.preventDefault(),r&&(r.dropEffect=`move`);let n=e.currentTarget,i=(n.querySelector(`:scope > .sidebar-recent-sessions__head`)??n).getBoundingClientRect(),a=e.clientY<i.top+i.height/2?`before`:`after`;this.sidebarSectionDropTarget={sectionId:t,position:a},this.sessionDropTarget=null,this.host.requestUpdate();return}if(!vo(r))return;let i=this.draggingSessionKey?this.host.findSidebarSessionByKey(this.draggingSessionKey):void 0;if(!this.sectionAcceptsSession(t,n,i)){e.stopPropagation();return}e.preventDefault(),r&&(r.dropEffect=`move`),this.sessionDropTarget=t,this.sidebarSectionDropTarget=null,this.host.requestUpdate()}sectionDragLeave(e,t,n){let r=e.currentTarget;e.relatedTarget instanceof Node&&r.contains(e.relatedTarget)||(this.sessionDropTarget===t&&(this.sessionDropTarget=null,this.host.requestUpdate()),this.sidebarSectionDropTarget?.sectionId===t&&(this.sidebarSectionDropTarget=null,this.host.requestUpdate()))}sectionDrop(e,t,n){let r=es(e.dataTransfer),i=Ds(e.dataTransfer);if(!r&&!i)return;let a=i?this.host.findSidebarSessionByKey(i):void 0;if(!r&&!this.sectionAcceptsSession(t,n,a)){e.stopPropagation();return}if(e.preventDefault(),e.stopPropagation(),r&&r!==t){let e=this.sidebarSectionDropTarget?.sectionId===t?this.sidebarSectionDropTarget.position:`before`;this.reorderSidebarSection(r,t,e)}else if(a&&t===`pinned`)a.pinnable&&!a.pinned&&this.patchSession(a,{pinned:!0},{sessionScope:!0});else if(a){let e=n??null;(a.category!==e||a.pinned)&&this.assignSessionCategory(a,e,a.pinned?{pinned:!1}:{})}this.draggingSidebarSection=null,this.sessionDropTarget=null,this.sidebarSectionDropTarget=null,this.finishSidebarEntryDrag()}setSessionsGrouping(e){this.host.sessionsGrouping=e,Ng(e)}setSessionsShowCron(e){this.host.sessionsShowCron=e,Fg(e)}setSessionsShowPreview(e){this.host.sessionsShowPreview=e,Ig(e)}setSessionsShowSystem(e){this.host.sessionsShowSystem=e,Lg(e)}setSessionsStatusFilter(e){e!==this.host.sessionsStatusFilter&&(this.host.sessionsStatusFilter=e,this.host.clearSessionSelection(),this.host.sessionData.resetSessionList(),Rg(e),this.host.sessionData.refreshSidebarSessions())}}})))()}function lx(e){let t=jr(e.matches[0],e.pendingMatches[0]),n=t?.module?.renderSidebar;return t&&(t.status===`success`||t.status===`pending`)&&t.error===void 0&&typeof n==`function`?{key:t.routeId,data:t.data,loaderPending:t.isFetching===`loader`,render:n}:void 0}function ux(e,t){return e?.key===t?.key&&e?.data===t?.data&&e?.loaderPending===t?.loaderPending&&e?.render===t?.render}function dx(){return(dx=e((()=>{vr()})))()}var fx;function px(){return(px=e((()=>{Vt(),dx(),fx=class{constructor(e){this.host=e,this.positions=new Map,this.presentedKey=`sessions`,new Nn(e).watch(()=>e.router,(t,n)=>{let r=t.subscribeSelector(lx,n,ux);return()=>{r(),e.contextualSidebar=void 0}},t=>{e.contextualSidebar=lx(t.getState())}),e.addController(this)}hostUpdate(){if(!this.host.isConnected||this.key===this.presentedKey)return;let e=this.scroller;e&&this.positions.set(this.presentedKey,e.scrollTop)}hostUpdated(){if(!this.host.isConnected||this.key===this.presentedKey)return;this.presentedKey=this.key;let e=this.scroller;e&&(e.scrollTop=this.positions.get(this.key)??0,this.host.sessionData.updateSessionsScrollState(e))}handleScroll(e){let t=e.currentTarget;t instanceof HTMLElement&&(this.positions.set(this.presentedKey,t.scrollTop),this.host.sessionData.updateSessionsScrollState(t))}get key(){return this.host.contextualSidebar?.key??`sessions`}get scroller(){return this.host.querySelector(`.sidebar-shell__body`)}}})))()}var mx;function hx(){return(hx=e((()=>{B(),H(),F(),M(),bm(),L(),jm(),rp(),mx=class extends Fn{constructor(...e){super(...e),this.x=0,this.y=0,this.trigger=null,this.lastActive=``,this.terminalDisabled=!1,this.canDelete=!1,this.onAction=()=>{},this.onClose=()=>{},this.menuLifecycle=new ym(this,{getTrigger:()=>this.trigger,onClose:()=>this.onClose()}),this.handleSelect=e=>{e.preventDefault();let t=e.detail.item.value;t&&this.run(t)},this.handleAfterHide=e=>{e.currentTarget instanceof Node&&e.currentTarget.isConnected&&this.onClose()}}connectedCallback(){super.connectedCallback(),km(this)}run(e){this.onAction(e),this.onClose()}render(){let e=this.canDelete?180:140,t=Math.max(8,Math.min(this.x,window.innerWidth-240-8)),n=Math.max(8,Math.min(this.y,window.innerHeight-e-8)),r=j(`chat.catalog.sessionMenu`);return R`
      <wa-dropdown
        class="session-menu"
        .open=${!0}
        placement="bottom-start"
        .distance=${0}
        aria-label=${r}
        @wa-select=${this.handleSelect}
        @wa-after-hide=${this.handleAfterHide}
      >
        <button
          slot="trigger"
          type="button"
          tabindex="-1"
          aria-hidden="true"
          aria-label=${r}
          style="position: fixed; left: ${t}px; top: ${n}px; width: 1px; height: 1px; opacity: 0; pointer-events: none;"
        ></button>
        ${this.lastActive?R`<div class="session-menu__info">
                ${j(`sessionsView.lastActive`,{time:this.lastActive})}
              </div>`:``}
        <wa-dropdown-item class="session-menu__item" value="viewer">
          <span slot="icon" class="session-menu__icon" aria-hidden="true"
            >${I.messageSquare}</span
          >
          <span class="session-menu__text">${j(`chat.catalog.openInOpenClaw`)}</span>
        </wa-dropdown-item>
        <wa-dropdown-item
          class="session-menu__item"
          value="terminal"
          title=${this.terminalDisabled?j(`chat.catalog.terminalUnavailable`):``}
          ?disabled=${this.terminalDisabled}
        >
          <span slot="icon" class="session-menu__icon" aria-hidden="true">${I.terminal}</span>
          <span class="session-menu__text">${j(`chat.catalog.openInTerminal`)}</span>
        </wa-dropdown-item>
        ${this.canDelete?R`<wa-dropdown-item
                class="session-menu__item session-menu__item--destructive"
                variant="danger"
                value="delete"
              >
                <span slot="icon" class="session-menu__icon" aria-hidden="true"
                  >${I.trash}</span
                >
                <span class="session-menu__text">${j(`chat.catalog.deleteSession`)}</span>
              </wa-dropdown-item>`:``}
      </wa-dropdown>
    `}},w([W({attribute:!1})],mx.prototype,`x`,void 0),w([W({attribute:!1})],mx.prototype,`y`,void 0),w([W({attribute:!1})],mx.prototype,`trigger`,void 0),w([W({attribute:!1})],mx.prototype,`lastActive`,void 0),w([W({attribute:!1})],mx.prototype,`terminalDisabled`,void 0),w([W({attribute:!1})],mx.prototype,`canDelete`,void 0),w([W({attribute:!1})],mx.prototype,`onAction`,void 0),w([W({attribute:!1})],mx.prototype,`onClose`,void 0),customElements.get(`openclaw-catalog-session-menu`)||customElements.define(`openclaw-catalog-session-menu`,mx)})))()}function gx(e){if(e instanceof PointerEvent&&e.pointerType===`touch`)return null;for(let t of e.composedPath()){if(t instanceof HTMLElement&&t.matches(xx))return t;if(t===e.currentTarget)break}return null}function _x(e){return e.matches(yx)?`horizontal`:`vertical`}var vx,yx,bx,xx;function Sx(){return(Sx=e((()=>{vx=`a.markdown-session-link, [data-session-href]`,yx=`.sidebar-recent-session[data-session-key]`,bx=`openclaw-session-menu-open`,xx=`${vx}, ${yx}`})))()}var Cx;function wx(){return(wx=e((()=>{B(),ii(),F(),P(),Ue(),hs(),wt(),hx(),Wd(),Sx(),Cx=class{constructor(e,t){this.host=e,this.beforeOpen=t,this.state=null,this.trigger=null}get isOpen(){return this.state!==null}isOpenFor(e){let t=this.state?.key;return t?.catalogId===e.catalogId&&t.hostId===e.hostId&&t.threadId===e.threadId&&t.sourceHomeId===e.sourceHomeId}open(e,t,n,r=null){r?.dispatchEvent(new CustomEvent(bx,{bubbles:!0,composed:!0})),this.beforeOpen(),this.trigger=r,this.state={...e,x:t,y:n},this.host.requestUpdate()}close(){(this.state||this.trigger)&&(this.trigger=null,this.state=null,this.host.requestUpdate())}retargetTrigger(e,t){t instanceof HTMLElement&&this.isOpenFor(e)&&queueMicrotask(()=>{t.isConnected&&!this.trigger?.isConnected&&this.isOpenFor(e)&&(this.trigger=t,this.host.requestUpdate())})}handleAction(e,t){if(t===`terminal`){e.canOpenTerminal&&this.host.terminalAvailable&&Xo(this.host,e.key,e.agentId);return}if(t===`delete`){e.canDelete&&this.deleteSession(e);return}this.host.onNavigate?.(e.routeId,e.navigation)}isMutationCurrent(e){return this.host.sessionData.isSessionMutationScopeCurrent(e)&&e.catalogGeneration===this.host.sessionData.sessionScopeGeneration}async deleteSession(e){let t=this.host.sessionData.beginSessionMutation();if(!t)return;let n={...t,catalogGeneration:this.host.sessionData.sessionScopeGeneration};try{let t=await Hd({message:j(`chat.catalog.deleteSessionConfirm`),details:e.name,confirmLabel:j(`chat.catalog.deleteSession`),danger:!0,signal:n.signal});if(!this.isMutationCurrent(n)){kt({message:j(`sessionsView.deleteSessionStale`,{session:e.name})});return}if(!t||(await this.host.sessionData.archiveSessionCatalog(n,{...e.key,agentId:e.agentId,confirmNoOtherRunner:!0}),!this.isMutationCurrent(n)))return;let r=cn(this.host.getRouteSessionKey());this.host.activeRouteId===`chat`&&r?.catalogId===e.key.catalogId&&r.hostId===e.key.hostId&&r.threadId===e.key.threadId&&this.host.onNavigate?.(`chat`,{pathname:gi(`chat`,this.host.basePath),search:``,hash:``})}catch(e){kt({message:E(e)})}}render(){let e=this.state;return e?R`
      <openclaw-catalog-session-menu
        .x=${e.x}
        .y=${e.y}
        .trigger=${this.trigger}
        .lastActive=${e.meta}
        .canDelete=${e.canDelete}
        .terminalDisabled=${!e.canOpenTerminal||!this.host.terminalAvailable}
        .onAction=${t=>this.handleAction(e,t)}
        .onClose=${()=>this.close()}
      ></openclaw-catalog-session-menu>
    `:z}}})))()}function Tx(){let e=pd()?.snapshot;return e?.gateways.find(t=>t.id===e.currentId)?.kind===`local`}function Ex(e,t){return t||!Tx()?null:/^(?:\/|[a-z]:[\\/]|\\\\)/i.test(e.path)?e.path:e.root?`${e.root.replace(/[\\/]+$/,``)}/${e.path.replace(/^[\\/]+/,``)}`:null}function Dx(e,t){new Nn(e).watch(pd,(e,t)=>e.subscribe(t),t)}function Ox(){return(Ox=e((()=>{Vt(),gd()})))()}function kx(e){for(let t of Nx){let n=e.find(e=>e.state===t);if(n)return n.url}return null}async function Ax(e){try{return kx((await e.loadPullRequests?.())?.pullRequests??[])}catch{return null}}async function jx(e){let t=e.worktreeId;if(!t||e.execNode||!Tx())return null;try{return(await e.client.request(`worktrees.list`,{})).worktrees.find(e=>e.id===t&&e.removedAt===void 0)?.path??null}catch{return null}}async function Mx(e){let[t,n]=await Promise.all([Ax(e),jx(e)]);return{pullRequestUrl:t,worktreePath:n}}var Nx;function Px(){return(Px=e((()=>{Ox(),Nx=[`open`,`draft`,`merged`,`closed`]})))()}function Fx(e,t,n,r){return{x:Math.max(8,Math.min(e,window.innerWidth-n-8)),y:Math.max(8,Math.min(t,window.innerHeight-r-8))}}var Ix,Lx,Rx,zx;function Bx(){return(Bx=e((()=>{B(),Xi(),ii(),so(),ps(),go(),Qt(),N(),wx(),og(),Px(),Sx(),n(),Ix=300,Lx=200,Rx=264,zx=class{constructor(e){this.host=e,this.customizeMenuPosition=null,this.moreMenuPosition=null,this.sessionMenu=null,this.sessionMenuWork=null,this.sessionGroupMenu=null,this.sessionSortMenuPosition=null,this.catalogViewMenuPosition=null,this.filterMenuView=`root`,this.agentMenuPosition=null,this.identityMenuPosition=null,this.customizeMenuTrigger=null,this.moreMenuTrigger=null,this.sessionMenuTrigger=null,this.sessionMenuWorkVersion=0,this.sessionGroupMenuTrigger=null,this.sessionSortMenuTrigger=null,this.catalogViewMenuTrigger=null,this.agentMenuTrigger=null,this.agentMenuInteractionState=`closed`,this.identityMenuTrigger=null,this.agentMenuHoverOpenTimer=null,this.agentMenuHoverCloseTimer=null,this.agentMenuFocusBeforeHover=null,this.routePreloadTimers=new Map,this.menuRenderer=null,this.menuRendererImport=et(()=>T(()=>import(`./sidebar-menus-render-EoZhjhbI.js`),__vite__mapDeps([32,1,2,3,4,5,6,7,8,9,10]),import.meta.url),e=>{this.menuRenderer=e,this.host.requestUpdate()}),this.pluginActionLifetime=new AbortController,this.cancelPreload=e=>{hi(this.routePreloadTimers,e)},this.openCustomizeMenuFromContext=e=>{e.preventDefault(),this.openCustomizeMenu(e.clientX,e.clientY)},e.addController(this),this.agentMenuAvatars=new Io(e),this.catalogMenu=new Cx(e,()=>{this.dismissTransientMenus()})}hostConnected(){this.pluginActionLifetime.signal.aborted&&(this.pluginActionLifetime=new AbortController),this.menuRendererImport.schedule()}hostDisconnected(){this.pluginActionLifetime.abort(),this.menuRendererImport.dispose(),this.clearAgentMenuHoverTimers();for(let e of this.routePreloadTimers.values())globalThis.clearTimeout(e);this.routePreloadTimers.clear()}updateState(e,t){this[e]=t,this.host.requestUpdate()}preloadMenuRenderer(){return this.menuRendererImport.load()}loadMenuRenderer(){this.preloadMenuRenderer().catch(()=>void 0)}closePositionedMenu(e,t){let n=this[`${e}MenuTrigger`];this[`${e}MenuTrigger`]=null,this.updateState(`${e}MenuPosition`,null),t.restoreFocus&&n?.focus()}dismissTransientMenus(){let e=!!(this.customizeMenuPosition||this.moreMenuPosition||this.sessionMenu||this.catalogMenu.isOpen||this.sessionGroupMenu||this.sessionSortMenuPosition||this.catalogViewMenuPosition||this.agentMenuPosition||this.identityMenuPosition);return this.closeCustomizeMenu(),this.closeMoreMenu(),this.closeSessionMenu(),this.catalogMenu.close(),this.closeSessionGroupMenu(),this.closeSessionSortMenu(),this.closeCatalogViewMenu(),this.closeAgentMenu(),this.closeIdentityMenu(),e}preloadRoute(e,t,n=!1){Ir(this.routePreloadTimers,e,t,e=>this.host.onPreloadRoute?.(e),e===this.host.activeRouteId||!this.isRouteEnabled(e),n)}isRouteEnabled(e){return this.host.enabledRouteIds?.includes(e)??!0}openCustomizeMenu(e,t,n=null){this.loadMenuRenderer(),this.dismissTransientMenus(),this.customizeMenuTrigger=n,this.updateState(`customizeMenuPosition`,Fx(e,t,240,420))}closeCustomizeMenu(e={}){this.closePositionedMenu(`customize`,e)}toggleMoreMenu(e){if(this.moreMenuPosition){this.closeMoreMenu();return}this.loadMenuRenderer();let t=e.getBoundingClientRect();this.dismissTransientMenus(),this.moreMenuTrigger=e,this.updateState(`moreMenuPosition`,Fx(t.left,t.bottom+4,240,420))}closeMoreMenu(e={}){this.closePositionedMenu(`more`,e)}openSessionMenu(e,t,n,r=null){r?.dispatchEvent(new CustomEvent(bx,{bubbles:!0,composed:!0})),this.host.selectedSessionKeys.has(e.key)||this.host.clearSessionSelection(),this.loadMenuRenderer(),this.dismissTransientMenus(),this.sessionMenuTrigger=r,this.updateState(`sessionMenu`,{session:e,x:t,y:n}),this.loadSessionMenuWork(e)}closeSessionMenu(){let e=this.host.sessionDataContext?.gateway;e&&ns(e).unwatch(this),this.sessionMenuTrigger=null,this.sessionMenuWorkVersion+=1,this.updateState(`sessionMenu`,null),this.updateState(`sessionMenuWork`,null)}loadSessionMenuWork(e){let t=++this.sessionMenuWorkVersion;if(!e.worktreeId){this.updateState(`sessionMenuWork`,null);return}this.updateState(`sessionMenuWork`,{loading:!0,pullRequestUrl:null,worktreePath:null});let n=this.host.sessionDataContext,r=n?.gateway.snapshot.client;if(!n||!r){this.updateState(`sessionMenuWork`,{loading:!1,pullRequestUrl:null,worktreePath:null});return}let{selectedAgentId:i}=this.host.getSessionNavigationState(),a=ns(n.gateway),o=zn(e.key,A(e.key)?.agentId??i);Mx({client:r,loadPullRequests:oo(n.gateway.snapshot,`controlUi.sessionPullRequests.subscribe`)===!0?()=>a.load(this,o):void 0,worktreeId:e.worktreeId,execNode:e.execNode}).then(e=>{t===this.sessionMenuWorkVersion&&this.updateState(`sessionMenuWork`,{loading:!1,...e})})}openSessionGroupMenu(e,t,n,r){this.loadMenuRenderer(),this.dismissTransientMenus(),this.sessionGroupMenuTrigger=r,this.updateState(`sessionGroupMenu`,{group:e,...Fx(t,n,224,160)})}closeSessionGroupMenu(e={}){let t=this.sessionGroupMenuTrigger;this.sessionGroupMenuTrigger=null,this.updateState(`sessionGroupMenu`,null),e.restoreFocus&&t?.focus()}toggleSessionSortMenu(e){if(this.sessionSortMenuPosition){this.closeSessionSortMenu();return}this.loadMenuRenderer();let t=e.getBoundingClientRect();this.dismissTransientMenus(),this.sessionSortMenuTrigger=e,this.updateState(`sessionSortMenuPosition`,Fx(t.right,t.bottom+4,200,280))}toggleCatalogViewMenu(e,t){if(this.catalogViewMenuPosition?.catalogId===e){this.closeCatalogViewMenu();return}let n=t.getBoundingClientRect();this.openCatalogViewMenu(e,n.right,n.bottom+4,t)}openCatalogViewMenu(e,t,n,r=null){this.loadMenuRenderer(),this.dismissTransientMenus(),this.catalogViewMenuTrigger=r,this.filterMenuView=`root`,this.updateState(`catalogViewMenuPosition`,{catalogId:e,...Fx(t,n,200,360)})}setFilterMenuView(e){this.catalogViewMenuPosition&&(this.filterMenuView=e,this.host.requestUpdate(),this.focusFilterMenuView())}focusFilterMenuView(){this.host.updateComplete.then(()=>{let e=this.catalogViewMenuTrigger?.closest(`openclaw-app-sidebar`)?.querySelector(`.sidebar-session-sort-menu`),t=e?.shadowRoot?.querySelector(`[part="menu"]`);e&&t&&(t.scrollTop=0,e.querySelector(`wa-dropdown-item:not([disabled])`)?.focus())})}closeCatalogViewMenu(e={}){this.closePositionedMenu(`catalogView`,e)}closeSessionSortMenu(e={}){this.closePositionedMenu(`sessionSort`,e)}toggleAgentMenu(e){if(this.clearAgentMenuHoverTimers(),this.agentMenuInteractionState===`open-click`){this.closeAgentMenu();return}if(this.agentMenuInteractionState===`open-hover`){this.agentMenuFocusBeforeHover=null,this.updateState(`agentMenuInteractionState`,`open-click`);return}this.openAgentMenu(e,`open-click`)}openAgentMenu(e,t){this.clearAgentMenuHoverTimers(),this.loadMenuRenderer();let n=Rx,r=e.getBoundingClientRect();this.closeCustomizeMenu(),this.closeMoreMenu(),this.closeSessionMenu(),this.closeSessionGroupMenu(),this.closeSessionSortMenu(),this.closeCatalogViewMenu(),this.closeIdentityMenu(),this.agentMenuTrigger=e,this.agentMenuFocusBeforeHover=t===`open-hover`&&document.activeElement instanceof HTMLElement?document.activeElement:null,this.updateState(`agentMenuInteractionState`,t),this.updateState(`agentMenuPosition`,{x:Math.max(8,Math.min(r.left,window.innerWidth-n-8)),top:Math.min(r.bottom+4,window.innerHeight-8)})}scheduleAgentMenuHoverOpen(e,t){globalThis.clearTimeout(this.agentMenuHoverCloseTimer??void 0),this.agentMenuHoverCloseTimer=null,this.agentMenuInteractionState===`closed`&&t.pointerType!==`touch`&&globalThis.matchMedia(`(hover: hover) and (pointer: fine)`).matches&&(this.loadMenuRenderer(),globalThis.clearTimeout(this.agentMenuHoverOpenTimer??void 0),this.updateState(`agentMenuInteractionState`,`hover-pending`),this.agentMenuHoverOpenTimer=globalThis.setTimeout(()=>{this.agentMenuHoverOpenTimer=null,this.agentMenuInteractionState===`hover-pending`&&this.openAgentMenu(e,`open-hover`)},Ix))}handleAgentMenuTriggerPointerLeave(){if(globalThis.clearTimeout(this.agentMenuHoverOpenTimer??void 0),this.agentMenuHoverOpenTimer=null,this.agentMenuInteractionState===`hover-pending`){this.updateState(`agentMenuInteractionState`,`closed`);return}this.scheduleAgentMenuHoverClose()}handleAgentMenuPointerEnter(){globalThis.clearTimeout(this.agentMenuHoverCloseTimer??void 0),this.agentMenuHoverCloseTimer=null}handleAgentMenuPointerLeave(){this.scheduleAgentMenuHoverClose()}restoreFocusAfterAgentMenuHoverOpen(){if(this.agentMenuInteractionState!==`open-hover`)return;let e=this.agentMenuFocusBeforeHover;this.agentMenuFocusBeforeHover=null,e&&e!==document.body&&e.isConnected?e.focus({preventScroll:!0}):document.activeElement instanceof HTMLElement&&document.activeElement.closest(`.sidebar-agent-menu`)&&document.activeElement.blur()}closeAgentMenu(e={}){let t=this.agentMenuTrigger;this.clearAgentMenuHoverTimers(),this.agentMenuTrigger=null,this.agentMenuFocusBeforeHover=null,this.updateState(`agentMenuInteractionState`,`closed`),this.updateState(`agentMenuPosition`,null),e.restoreFocus&&t?.focus()}scheduleAgentMenuHoverClose(){this.agentMenuInteractionState===`open-hover`&&(globalThis.clearTimeout(this.agentMenuHoverCloseTimer??void 0),this.agentMenuHoverCloseTimer=globalThis.setTimeout(()=>{this.agentMenuHoverCloseTimer=null,this.agentMenuInteractionState===`open-hover`&&(document.activeElement?.closest(`.sidebar-agent-menu`)||this.closeAgentMenu())},Lx))}clearAgentMenuHoverTimers(){globalThis.clearTimeout(this.agentMenuHoverOpenTimer??void 0),globalThis.clearTimeout(this.agentMenuHoverCloseTimer??void 0),this.agentMenuHoverOpenTimer=null,this.agentMenuHoverCloseTimer=null}toggleIdentityMenu(e){if(this.identityMenuPosition){this.closeIdentityMenu();return}this.loadMenuRenderer();let t=e.getBoundingClientRect(),n=Math.max(240,t.width);this.dismissTransientMenus(),this.identityMenuTrigger=e,this.updateState(`identityMenuPosition`,{x:Math.max(8,Math.min(t.right-n,window.innerWidth-n-8)),bottom:Math.max(8,window.innerHeight-t.top+4),width:t.width})}closeIdentityMenu(e={}){this.closePositionedMenu(`identity`,e)}render(){let e=this.menuRenderer;return R`
      ${e?.renderSidebarCustomizeMenuForController(this)??z}
      ${e?.renderSidebarMoreMenuForController(this)??z}
      ${this.agentMenuAvatars.withActiveRoutes(()=>e?.renderSidebarAgentMenuForController(this)??z)}
      ${e?.renderSidebarIdentityMenuForController(this)??z}
      ${e?.renderSidebarSessionMenuForController(this)??z}
      ${this.catalogMenu.render()}
      ${e?.renderSidebarSessionGroupMenuForController(this)??z}
      ${e?.renderSidebarSessionSortMenuForController(this)??z}
      ${e?.renderSidebarCatalogViewMenuForController(this)??z}
    `}renderRoute(e){if(!this.isRouteEnabled(e))return z;let t=Ji(e)?this.host.getRouteSessionKey():``,n=this.host.sessionDataContext,r=Ji(e)&&t&&n?Bn({context:n,face:e,sessionKey:t}):null;return tg({routeId:e,href:r?.href??gi(e,this.host.basePath),active:$h(this.host.activeRouteId,e),onNavigate:()=>{this.host.onNavigate?.(e,r?.options)},onPreload:(t,n)=>this.preloadRoute(e,t,n),onCancelPreload:this.cancelPreload})}}})))()}function Vx(e){let t=Ux.get(e);return t||(t={listeners:new Set},Ux.set(e,t)),t}function Hx(e,t){let n=Vx(e);return n.listeners.add(t),{get data(){return n.data},dispose:()=>{n.listeners.delete(t)}}}var Ux,Wx;function Gx(){return(Gx=e((()=>{Ux=new WeakMap,Wx=class{constructor(e,t,n){this.host=e,this.context=t,this.data=n}hostUpdated(){if(!this.host.isConnected)return;let e=this.context(),t=e?Vx(e):void 0;if(this.source!==t&&(this.hostDisconnected(),this.source=t),t){t.data=this.data;for(let e of t.listeners)e()}}hostDisconnected(){if(this.source?.data===this.data){this.source.data=void 0;for(let e of this.source.listeners)e()}this.source=void 0}}})))()}var Kx,qx;function Jx(){return(Jx=e((()=>{F(),No(),wt(),il(),Gx(),n(),Kx=[`pointerover`,`pointerout`,`focusin`,`focusout`,`click`,`keydown`],qx=class{constructor(e){this.host=e,this.runtime=null,this.loading=null,this.generation=0,this.pendingTarget=null,this.cancelPending=e=>{(e instanceof KeyboardEvent?e.key===`Escape`:e.target instanceof Node&&!this.pendingTarget?.contains(e.target))&&(this.generation+=1,this.clearPending())},this.handleEvent=e=>{if(e.type===`click`&&e.target instanceof Element&&e.target.closest(`a[href]`))return;if(this.runtime){this.runtime.handleEvent(e);return}let t=e.target instanceof Element?e.target.closest(`[data-person-card]`):null;if(!t||![`pointerover`,`focusin`,`click`].includes(e.type))return;let n=++this.generation;this.pendingTarget=t,document.addEventListener(`pointerdown`,this.cancelPending,!0),document.addEventListener(`keydown`,this.cancelPending,!0);let r=this.host.sessionDataContext?.gateway.snapshot.client,i=this.host.sessionDataContext?.gateway,a=i?.snapshot.hello,o=this.host.activeRouteId,s=this.host.sessionKey,c=performance.now();this.loading??=T(()=>import(`./sidebar-people.runtime-BCxkEnps.js`),__vite__mapDeps([33,1,2,3,4,5,6,7,10,8,9]),import.meta.url),this.loading.then(l=>{n===this.generation&&this.clearPending(),n===this.generation&&this.host.isConnected&&t.isConnected&&i===this.host.sessionDataContext?.gateway&&r===i?.snapshot.client&&a===i?.snapshot.hello&&o===this.host.activeRouteId&&s===this.host.sessionKey&&(this.runtime??=new l.SidebarPeopleRuntime(this.host),this.runtime.handleEvent(e,c))},()=>{this.loading=null,n===this.generation&&this.host.isConnected&&(this.clearPending(),kt({message:j(`presence.card.loadFailed`)}))})},e.addController(this),this.activityExpiry=al(e,()=>e.connected?ls(e.sessionData.presencePayload).users:[]),e.addController(new Wx(e,()=>e.sessionDataContext,e.sessionData))}hostConnected(){for(let e of Kx)this.host.addEventListener(e,this.handleEvent)}hostUpdate(){this.activityExpiry.sync()}hostUpdated(){this.runtime?.sync()}dismiss(){return this.generation+=1,this.clearPending(),this.runtime?.dismiss()??!1}hostDisconnected(){for(let e of Kx)this.host.removeEventListener(e,this.handleEvent);this.generation+=1,this.clearPending(),this.runtime?.dispose(),this.runtime=null}clearPending(){this.pendingTarget=null,document.removeEventListener(`pointerdown`,this.cancelPending,!0),document.removeEventListener(`keydown`,this.cancelPending,!0)}}})))()}var Yx;function Xx(){return(Xx=e((()=>{B(),H(),Oa(),Xi(),ii(),qi(),F(),Sh(),wh(),Kh(),Ue(),Jh(),ta(),wt(),Vt(),Mt(),mn(),Xh(),W_(),iy(),Qb(),cv(),K(),tx(),ox(),L(),jv(),cx(),px(),Bx(),Jx(),n(),Yx=class extends Zb{sessionGroupDefaults(e){if(this.context?.sessions.groupsStatus()!==`ready`)return null;let t=this.context?.sessions.state.groupSettings.find(t=>t.name===e);return t?{cwd:t.cwd??``,worktree:t.worktree===!0}:null}async listSessionGroupFolders(e){let t=this.context?.sessions,n=t?.captureConnectionScope();if(!t||!n)throw Error(j(`sessionsView.groupDefaultsStale`));let r=await n.client.request(`fs.listDir`,e?{path:e}:{});if(this.context?.sessions!==t||!t.isConnectionScopeCurrent(n))throw Error(j(`sessionsView.groupDefaultsStale`));return r}async inspectSessionGroupRepository(e){let t=e?.trim()||this.activeChipAgent().agent?.workspace?.trim();if(!t)return`unavailable`;let n=this.context?.sessions,r=n?.captureConnectionScope();if(!n||!r)throw Error(j(`sessionsView.groupDefaultsStale`));let i=await r.client.request(`worktrees.branches`,{repoRoot:t,includeRepositoryStatus:!0});if(this.context?.sessions!==n||!n.isConnectionScopeCurrent(r))throw Error(j(`sessionsView.groupDefaultsStale`));return i.repositoryStatus===`git`||i.repositoryStatus===`not_git`?i.repositoryStatus:`unavailable`}constructor(){super(),this.teamOnlineExpanded=!1,this.sidebarNarrationLines=new Map,this.sidebarObserverDigests=new Map,this.sessionOrganizer=new sx(this),this.sidebarMenus=new zx(this),this.people=new qx(this),this.narration=null,this.narrationLoad=null,this.sidebarContext=new fx(this),this.projectedSessionCatalogs=[],this.projectedSessionSections={sections:[],visibleRows:[]},this.subscriptions=new Nn(this).effect(()=>this.context?.gateway,e=>e.subscribeEvents(e=>this.narration?.handleEvent(e))).watch(()=>this.context?.agentIdentity,(e,t)=>e.subscribe(t)).watch(()=>this.context?.theme,(e,t)=>e.subscribe(t)).watch(()=>this.context?.config,(e,t)=>e.subscribe(t),()=>this.syncCommunityInviteState()).watch(()=>this.context?.plugins,(e,t)=>e.subscribe(t)),this.nativeGatewaysChanged=()=>this.sidebarMenus.closeSessionMenu(),this.hiddenSessionCatalogsChanged=()=>{this.hiddenSessionCatalogIds=jg()},this.communityInvitePresentation=`unavailable`,this.communityInviteStorageChanged=e=>{(e.key===`openclaw:control-ui:community-invite`||e.key===null)&&this.syncCommunityInviteState()},this.catalogRenderer=null,this.catalogRendererImport=et(()=>T(()=>import(`./app-sidebar-session-catalog-render-DMTyF35u.js`),[],import.meta.url),e=>{this.catalogRenderer=e.renderSessionCatalogGroups,this.isConnected&&this.requestUpdate()}),this.rosterRenderer=null,this.rosterRendererImport=et(()=>T(()=>import(`./sidebar-agent-roster-DhcmyPLo.js`),__vite__mapDeps([34,35,1,2,3,4,5,6,7,10,8,9,36]),import.meta.url),e=>{this.rosterRenderer=e,this.requestUpdate()}),this.catalogProjectGrouping=xg(),this.handleSidebarInteractionEnd=e=>{this.communityInvitePresentation!==`pending`||e instanceof FocusEvent&&e.relatedTarget instanceof Node&&this.contains(e.relatedTarget)||this.requestUpdate()},this.dismissCommunityInvite=()=>{let e=rx();this.syncCommunityInviteState(),e.ok||kt({message:j(`communityInvite.dismissFailed`)})},this.subscriptions}dismissTransientMenus(){let e=this.people.dismiss();return super.dismissTransientMenus()||e}disconnectedCallback(){this.rosterRendererImport.dispose(),window.removeEventListener(`openclaw:native-gateways-changed`,this.nativeGatewaysChanged),window.removeEventListener(i_,this.hiddenSessionCatalogsChanged),this.narration?.disconnect(),this.catalogRendererImport.dispose(),window.removeEventListener(`storage`,this.communityInviteStorageChanged),super.disconnectedCallback()}willUpdate(e){super.willUpdate(e),this.communityInvitePresentation===`pending`&&!this.matches(`:hover`)&&!this.contains(this.ownerDocument.activeElement)&&this.sessionOrganizer.draggingSessionKey===null&&this.sessionOrganizer.draggingSidebarSection===null&&this.sessionOrganizer.draggingSidebarEntry===null&&(this.communityInvitePresentation=`shown`);let t=this.sidebarAgentsMode===`roster`?this.rosterSessionSource?.result:this.sessionData.sessionsResult;this.sessionProjection.observeRows([...t?[t]:[],...Object.values(this.sessionData.sessionResultsByAgent)]),this.sessionNavigationState=super.getSessionNavigationState(),this.projectedSessionRows=super.selectedAgentSessionRows(this.sessionNavigationState);let n=this.sidebarSessionCatalogs();this.projectedSessionCatalogs=n,this.projectedSessionSections=super.zonedVisibleSections(this.projectedSessionRows,n);let r=this.sidebarMenus.agentMenuPosition===null?[this.expandedAgentId()]:this.activeChipAgent().agents.map(e=>e.id);this.ensureAgentIdentities(r)}ensureAgentIdentities(e){this.connected&&this.context?.agentIdentity.ensure(e)}getSessionNavigationState(){return this.sessionNavigationState??super.getSessionNavigationState()}selectedAgentSessionRows(e){return this.projectedSessionRows??super.selectedAgentSessionRows(e)}zonedVisibleSections(e){return this.projectedSessionSections}updated(e){super.updated(e),this.narration?this.narration.sync(this.narrationSyncInput()):this.sidebarLiveActivity&&this.ensureNarrationController(),this.sessionNavigationState=void 0,this.projectedSessionRows=void 0}visibleNarrationRowsInOrder(){let e=[],t=n=>{e.push(n),this.isSessionChildrenExpanded(n)&&nv({session:n,fullyShown:this.isSessionChildrenFullyShown(n.key)}).forEach(t)};return this.visibleSessionRowsInOrder().forEach(t),e}narrationSyncInput(){let e=this.context?.gateway.snapshot;return{enabled:this.sidebarLiveActivity,connected:this.connected&&e?.phase===`connected`,connectionIdentity:e?.client??null,source:this.context?.sessions??null,rows:this.visibleNarrationRowsInOrder(),openSessionKey:Ji(this.activeRouteId)?this.getRouteSessionKey():``,agentId:this.selectedAgentIdForSessions()}}ensureNarrationController(){this.narration||this.narrationLoad||(this.narrationLoad=T(()=>import(`./app-sidebar-session-narration-CeasRhPk.js`).then(e=>{this.narrationLoad=null,this.isConnected&&(this.narration=new e.SidebarSessionNarrationController(e=>{this.sidebarNarrationLines=e},e=>{this.sidebarObserverDigests=e}),this.narration.sync(this.narrationSyncInput()))}),[],import.meta.url))}connectedCallback(){super.connectedCallback(),window.addEventListener(`openclaw:native-gateways-changed`,this.nativeGatewaysChanged),this.hiddenSessionCatalogsChanged(),window.addEventListener(i_,this.hiddenSessionCatalogsChanged),window.addEventListener(`storage`,this.communityInviteStorageChanged),this.syncCommunityInviteState(),this.catalogRendererImport.schedule()}syncCommunityInviteState(){this.context?.config.current.communityInvite!==!0||!nx()?this.communityInvitePresentation=`unavailable`:this.communityInvitePresentation!==`shown`&&(this.communityInvitePresentation=`pending`)}firstUpdated(){requestAnimationFrame(()=>requestAnimationFrame(()=>this.classList.add(`sidebar-r`)))}toggleSessionPin(e){this.sessionOrganizer.patchSession(e,{pinned:!e.pinned},{sessionScope:!0})}toggleSessionMenu(e,t,n){if(n){if(this.sidebarMenus.catalogMenu.isOpenFor(n.key)){this.sidebarMenus.catalogMenu.close();return}let e=t.getBoundingClientRect();this.sidebarMenus.catalogMenu.open(n,e.right,e.bottom+4,t);return}if(this.sidebarMenus.sessionMenu?.session.key===e.key){this.sidebarMenus.closeSessionMenu();return}let r=t.getBoundingClientRect();this.sidebarMenus.openSessionMenu(e,r.right,r.bottom+4,t)}toggleSection(e){this.collapsedSessionSections.has(e)||this.sessionProjection.resetMembership(e),this.sessionOrganizer.toggleSection(e)}setVisibleSessionLimit(e,t){let n=this.sidebarAgentsMode===`roster`&&e.startsWith(`agent:`);t<((n?this.rosterVisibleSessionLimits:this.sessionData.visibleSessionLimits).get(e)??10)&&this.sessionProjection.resetMembership(e),n?(this.rosterVisibleSessionLimits.set(e,t),this.requestUpdate()):this.sessionData.setVisibleSessionLimit(e,t)}preloadCatalogRenderer(){return this.catalogRendererImport.load()}setCatalogProjectGrouping(e){Pg(e),this.catalogProjectGrouping=e}hideSessionCatalog(e){let t=this.sessionData.sessionCatalogs.find(t=>t.id===e)?.label??e;Wg(e,!0);let n=On.appearanceSidebar,r=gi(n.routeId,this.basePath)+n.search+n.hash;kt({message:R`${j(`chat.sidebar.sectionHidden`,{section:t})}
        <a
          class="session-link"
          href=${r}
          @click=${e=>{k(e)&&(e.preventDefault(),this.onNavigate?.(n.routeId,{search:n.search,hash:n.hash}))}}
          >${j(`chat.sidebar.sectionHiddenRecovery`)}</a
        >`,actionLabel:j(`common.undo`),onAction:()=>Wg(e,!1),durationMs:12e3})}renderPinnedSidebarSession(e){return this.sidebarAgentsMode===`roster`&&this.rosterRenderer?this.rosterRenderer.renderSidebarPinnedSession(this,e):ov({host:this,session:e,listItem:!1})}renderSessions(){return tn(`session-list`,{sessionKey:this.sessionKey,agentId:this.getSessionNavigationState().selectedAgentId,sessions:this.context?.sessions.state.result?.sessions??[]},this.renderSessionsBody())}renderSessionsBody(){if(this.sidebarAgentsMode===`roster`)return this.rosterRenderer?this.rosterRenderer.renderSidebarAgentRoster(this,this.projectedSessionSections.sections,this.selectedAgentSessionRows(this.getSessionNavigationState()).length===0):(this.rosterRendererImport.load().catch(()=>void 0),z);let e=this.getSessionNavigationState(),t=this.selectedAgentSessionRows(e),n=this.expandedAgentId(),r=this.activeRouteId===`terminal`?xt(this.context?.router.getState().matches[0]?.location.search??``):null,i=r?Rn(r,n):Ji(this.activeRouteId)?this.getRouteSessionKey():``,a=this.projectedSessionCatalogs,{sections:o}=this.zonedVisibleSections(t);return!this.catalogRenderer&&(a.length>0||this.sessionData.sessionCatalogRefreshStatus.error!==null)&&this.preloadCatalogRenderer().catch(()=>void 0),ny({host:this,empty:t.length===0,sections:o,nativeSessionsHaveMore:this.sessionData.sessionsResult?.hasMore===!0,nativeSessionsLoading:this.sessionData.sessionsLoading,catalogRenderer:this.catalogRenderer,catalogs:{catalogs:a,basePath:this.basePath,routeSessionKey:i,newSessionAgentId:n,mainKey:this.sessionMainKey(),loadingMoreCatalogIds:this.sessionData.loadingMoreSessionCatalogIds,projectGrouping:this.catalogProjectGrouping,liveRows:this.catalogLiveRows(),toSidebarSession:e.toSidebarSession,catalogOpenTarget:this.catalogOpenTarget,terminalAvailable:this.terminalAvailable}})}render(){let e=this.reconciledSidebarZone();return R`
      <aside
        class="sidebar"
        @pointerleave=${this.handleSidebarInteractionEnd}
        @focusout=${this.handleSidebarInteractionEnd}
        @contextmenu=${e=>{e.target.closest(`input, textarea, [contenteditable]`)||e.preventDefault()}}
      >
        <div class="sidebar-shell" @mousedown=${Ci}>
          ${R_(this,this.sidebarAgentsMode===`roster`?this.rosterRenderer?.renderSidebarNewSessionMenu(this,`sidebar-brand__icon sidebar-brand__header-control sidebar-brand__new-thread`):z)}
          <div class="sidebar-shell__content">
            <div
              class="sidebar-shell__body sidebar-shell__body--scroll-${this.sessionData.sessionsScrollState}"
              @scroll=${e=>this.sidebarContext.handleScroll(e)}
            >
              <nav
                class="sidebar-nav"
                @contextmenu=${this.sidebarMenus.openCustomizeMenuFromContext}
              >
                ${B_(this)}
                <div
                  class="nav-section__items"
                  @dragover=${e=>this.sessionOrganizer.handleSidebarZoneDragOver(e)}
                  @dragleave=${e=>this.sessionOrganizer.handleSidebarZoneDragLeave(e)}
                  @drop=${e=>this.sessionOrganizer.handleSidebarZoneDrop(e)}
                >
                  ${z_(this)}
                  ${va(e.entries,ir,t=>H_(this,t,e.sessionRows,e.pluginTabs))}
                </div>
              </nav>
              <div class="sidebar-session-content" ?hidden=${!!this.contextualSidebar}>
                ${Yh(this)} ${this.renderSessions()}
              </div>
              ${this.contextualSidebar?.render(this.contextualSidebar.data,this.contextualSidebar.loaderPending,!0)??z}
            </div>
            ${this.contextualSidebar||this.sessionsStatusFilter===`archived`?z:Av({status:this.sessionData.sessionCatalogRefreshStatus,className:`sidebar-session-error sidebar-session-catalog-error`})}
          </div>
          <div class="sidebar-shell__invite">
            ${this.communityInvitePresentation===`shown`?$b(this.dismissCommunityInvite):z}
          </div>
          <div class="sidebar-shell__footer">
            ${this.devGitBranch?R`<openclaw-tooltip .content=${this.devGitBranch}>
                    <div class="sidebar-footer-branch">
                      <span class="sidebar-footer-branch__icon" aria-hidden="true"
                        >${I.gitBranch}</span
                      >
                      <span class="sidebar-footer-branch__name">${this.devGitBranch}</span>
                    </div>
                  </openclaw-tooltip>`:z}
            ${V_(this)}
          </div>
        </div>
        ${this.sidebarMenus.render()}
      </aside>
    `}},w([V()],Yx.prototype,`teamOnlineExpanded`,void 0),w([V()],Yx.prototype,`sidebarNarrationLines`,void 0),w([V()],Yx.prototype,`sidebarObserverDigests`,void 0),w([V()],Yx.prototype,`communityInvitePresentation`,void 0),w([V()],Yx.prototype,`catalogProjectGrouping`,void 0),customElements.get(`openclaw-app-sidebar`)||customElements.define(`openclaw-app-sidebar`,Yx)})))()}var Zx,Qx;function $x(){return($x=e((()=>{ba(),sa(),Zx=class extends ua{constructor(...e){super(...e),this.state=`loading`}render(e,t){e!==this.source&&(this.state=`loading`,this.source=e);let n=()=>{let n=e&&this.state!==`failed`?e:null;return t(n,i,{loading:!!(n&&this.state===`loading`),onLoad:r})},r=()=>{this.isConnected&&this.source===e&&this.state===`loading`&&(this.state=`ready`,this.setValue(n()))},i=()=>{this.isConnected&&this.source===e&&(this.state=`failed`,this.setValue(n()))};return n()}},Qx=pa(Zx)})))()}function eS(e,t,n={}){let r=e.querySelector(`:scope > summary`),i=e.querySelector(`:scope > wa-popup[data-anchored-overlay]`);r&&i&&(tS(i,n.anchor??r,t,n.alignment),i.active=e.open)}function tS(e,t,n,r=`start`){e.anchor=t,e.placement=`${n}-${r}`,e.boundary=`viewport`;let i=t.closest(`.shell`);e.flipBoundary=i??[],e.shiftBoundary=i??[],e.autoSizeBoundary=i??[],e.distance=6,e.flip=!0,e.flipPadding=nS,e.shift=!0,e.shiftPadding=i&&Number.parseFloat(getComputedStyle(i).getPropertyValue(`--shell-popup-inline-gutter`))||rS,e.autoSize=`vertical`,e.autoSizePadding=nS}var nS,rS;function iS(){return(iS=e((()=>{jc(),nS=8,rS=12})))()}function aS(e,t){let n=e.getBoundingClientRect(),r=t.getBoundingClientRect();r.top<n.top?e.scrollTop-=n.top-r.top:r.bottom>n.bottom&&(e.scrollTop+=r.bottom-n.bottom)}function oS(e,t=!1){let n=t?e.scrollWidth:e.scrollHeight,r=t?e.clientWidth:e.clientHeight,i=t?e.scrollLeft:e.scrollTop,a=n>r+1;e.dataset.scrollable=String(a),e.dataset.atStart=String(!a||i<=1),e.dataset.atEnd=String(!a||i+r>=n-1)}var sS,cS;function lS(){return(lS=e((()=>{B(),ba(),sa(),sS=class extends ua{constructor(...e){super(...e),this.horizontal=!1,this.trackScroll=!0,this.pending=!1,this.sync=()=>{let e=this.element;this.isConnected&&e?.isConnected&&oS(e,this.horizontal)},this.observer=typeof ResizeObserver>`u`?void 0:new ResizeObserver(this.sync)}render(e=!1,t=!0){return z}update(e,[t=!1,n=!0]){return this.element=e.element instanceof HTMLElement?e.element:void 0,this.horizontal=t,this.trackScroll=n,this.schedule(),z}schedule(){!this.pending&&this.isConnected&&(this.pending=!0,queueMicrotask(()=>{this.pending=!1;let e=this.element;this.isConnected&&e?.isConnected&&(this.observer?.observe(e),this.trackScroll?e.addEventListener(`scroll`,this.sync):e.removeEventListener(`scroll`,this.sync),this.sync())}))}disconnected(){this.observer?.disconnect(),this.element?.removeEventListener(`scroll`,this.sync)}reconnected(){this.schedule()}},cS=pa(sS)})))()}function uS(){return fS+=1,`openclaw-picker-${fS}`}function dS(e){return R`<openclaw-select-picker
    class=${`settings-select picker-select ${e.variant===`submenu`?`picker-select--submenu`:``} ${e.sheet?`picker-select--sheet`:``} ${e.className??``}`}
    style="width:100%;min-width:min(138px,100%)"
    .params=${e}
  ></openclaw-select-picker>`}var fS,pS;function mS(){return(mS=e((()=>{jc(),B(),H(),xa(),Oa(),F(),M(),iS(),L(),lS(),fS=0,pS=class extends Fn{constructor(...e){super(...e),this.mode=`closed`,this.query=``,this.activeValue=null,this.keyboard=!1,this.collapsedGroups=new Set,this.listboxId=uS(),this.typeahead=``,this.typeaheadAt=0,this.renderedSections=[],this.sheetScroll=null,this.hoverOpened=!1,this.syncScrollFade=()=>{let e=this.querySelector(`.picker-select__options`);e&&(e.toggleAttribute(`data-fade-start`,e.scrollTop>0),e.toggleAttribute(`data-fade-end`,e.scrollTop+e.clientHeight<e.scrollHeight-1))},this.handleOutsidePointer=e=>{e.composedPath().includes(this)||this.closeMenu()},this.handleFocusOut=e=>{(!(e.relatedTarget instanceof Node)||!this.contains(e.relatedTarget))&&this.closeMenu()},this.handleHover=e=>{if(this.params.variant!==`submenu`||this.params.sheet||e.pointerType!==`mouse`)return;clearTimeout(this.hoverTimer);let t=e.type===`pointerenter`;t!==(this.mode!==`closed`)&&(this.hoverTimer=setTimeout(()=>{t?(this.keyboard=!1,this.hoverOpened=this.openMenu(!1,!1)!==void 0):this.closeMenu(this.contains(this.ownerDocument.activeElement))},t?120:150))},this.handleTriggerClick=()=>{clearTimeout(this.hoverTimer),this.keyboard=!1,this.mode===`closed`?this.openMenu():this.hoverOpened?this.hoverOpened=!1:this.closeMenu()},this.handleKeydown=e=>{let t=e.target instanceof HTMLInputElement,n=e.key.length===1&&!e.ctrlKey&&!e.metaKey&&!e.altKey,r=this.params.variant===`submenu`,i=this.submenuSide===`right`?`ArrowRight`:`ArrowLeft`,a=i===`ArrowRight`?`ArrowLeft`:`ArrowRight`,o=[`ArrowDown`,`ArrowUp`,`Enter`,` `].includes(e.key)||r&&e.key===i;if(this.mode===`closed`&&!o&&!n||(e.key===`Enter`||e.key===` `)&&e.target instanceof Element&&e.target.matches(`.picker-select__back`)||((!t||!(n||e.key===`Backspace`||e.key===`Delete`))&&(this.keyboard=!0),e.stopPropagation(),e.isComposing||this.params.disabled))return;let s=performance.now(),c=s-this.typeaheadAt<1e3?this.typeahead:``;if(this.mode===`closed`){if(o){e.preventDefault(),this.openMenu(e.key===`ArrowUp`);return}if(!n)return;if(e.preventDefault(),this.openMenu()===`search`){this.query=e.key,this.activeValue=null;return}}if(e.key===`Escape`&&this.query&&this.params.searchable===`always`){e.preventDefault(),this.query=``;return}if(e.key===`Tab`&&this.params.groupBy)return;if(e.key===`Escape`||e.key===`Tab`||r&&!t&&e.key===a){e.key!==`Tab`&&e.preventDefault(),this.closeMenu(!0);return}if(e.target instanceof Element&&e.target.closest(`.picker-select__group-toggle`))return;if(e.key===`Enter`||e.key===` `&&!t&&!c){e.preventDefault(),this.commit(this.activeValue);return}if(t&&e.key!==`ArrowDown`&&e.key!==`ArrowUp`)return;let l=this.rows().filter(e=>!e.disabled),u=l.findIndex(e=>e.value===this.activeValue);e.key===`ArrowDown`||e.key===`ArrowUp`?(e.preventDefault(),u+=e.key===`ArrowDown`?1:-1,u<0&&(u=l.length-1),u>=l.length&&(u=0)):!t&&(e.key===`Home`||e.key===`End`)?(e.preventDefault(),u=e.key===`Home`?0:l.length-1):!t&&(n||e.key===`Backspace`)&&(e.preventDefault(),this.typeahead=e.key===`Backspace`?c.slice(0,-1):c+e.key.toLocaleLowerCase(),this.typeaheadAt=s,u=l.findIndex(e=>e.label.toLocaleLowerCase().startsWith(this.typeahead)));let d=l[u];d&&(this.activeValue=d.value)}}options(){let{value:e,options:t}=this.params;return e===null||e===``||t.some(t=>t.value===e)?t:[...t,{value:e,label:e}]}sections(){let e=this.query.trim().toLocaleLowerCase().split(/\s+/u),t={options:[],expanded:!0},n=new Map;for(let r of this.options()){let i=this.params.groupBy?.(r),a=[r.label,r.value,r.description,i?.label].join(` `).toLocaleLowerCase();if(!e.every(e=>a.includes(e)))continue;if(!i){t.options.push(r);continue}let o=n.get(i.id);o||(o={group:i,options:[],expanded:!!this.query.trim()||!this.collapsedGroups.has(i.id)},n.set(i.id,o)),o.options.push(r)}return[t,...n.values()]}rows(e=this.sections()){return e.flatMap(e=>e.expanded?e.options:[])}get trigger(){return this.querySelector(`.picker-select__trigger`)}closeMenu(e=!1){clearTimeout(this.hoverTimer),this.sheetScroll&&=(this.sheetScroll.root.scrollTop=this.sheetScroll.top,null),this.hoverOpened=!1,this.mode=`closed`,this.query=``,this.collapsedGroups=new Set,this.activeValue=null,this.typeahead=``,this.ownerDocument.removeEventListener(`pointerdown`,this.handleOutsidePointer,!0),this.querySelectorAll(`[data-picker-focus]`).forEach(e=>{e.tabIndex=-1}),e&&this.trigger?.focus()}openMenu(e=!1,t=!0){if(this.params.disabled||this.mode!==`closed`)return;let{searchable:n}=this.params;this.mode=n===`always`||n&&(this.params.groupBy||this.options().length>8)?`search`:`compact`;let r=this.rows().filter(e=>!e.disabled);return this.activeValue=r.find(e=>e.value===this.params.value)?.value??(e?r.at(-1):r[0])?.value??null,this.ownerDocument.addEventListener(`pointerdown`,this.handleOutsidePointer,!0),this.params.onOpen?.(),this.updateComplete.then(()=>{if(this.mode===`closed`)return;let e=this.querySelector(`.picker-select__menu`)?.offsetParent;this.params.sheet&&e&&(this.sheetScroll={root:e,top:e.scrollTop},e.scrollTop=0);let n=this.params.sheet&&!this.keyboard?`.picker-select__back`:`[data-picker-focus]`;t&&this.querySelector(n)?.focus({preventScroll:!0}),requestAnimationFrame(this.syncScrollFade)}),this.mode}disconnectedCallback(){this.closeMenu(),super.disconnectedCallback()}willUpdate(){if(this.params.disabled&&this.mode!==`closed`&&this.closeMenu(),this.renderedSections=this.sections(),this.mode!==`closed`){let e=this.rows(this.renderedSections).filter(e=>!e.disabled);e.some(e=>e.value===this.activeValue)||(this.activeValue=e[0]?.value??null)}}updated(e){if(this.configurePopup(),this.syncScrollFade(),this.mode===`closed`||!e.has(`activeValue`)&&!e.has(`query`))return;let t=this.querySelector(`.picker-select__options`),n=t?.querySelector(`[data-active]`);t&&n&&aS(t,n)}commit(e){let t=this.rows().find(t=>t.value===e);this.mode===`closed`||this.params.disabled||!t||t.disabled||(this.closeMenu(!0),this.params.onChangeTarget?this.params.onChangeTarget(t.value,this):this.params.onChange(t.value))}get submenuSide(){return getComputedStyle(this).direction===`rtl`?`left`:`right`}configurePopup(){let e=this.querySelector(`wa-popup`);e instanceof Uc&&this.trigger&&(this.params.variant===`submenu`&&e.setAttribute(`flip-fallback-placements`,`${this.submenuSide===`right`?`left`:`right`}-start bottom-start top-start`),tS(e,this.trigger,this.params.variant===`submenu`?this.submenuSide:this.params.placement??`bottom`))}leading(e){let t=e&&this.params.renderLeading?.(e);return t==null||t===z?z:R`<span class="picker-select__leading">${t}</span>`}optionId(e){return`${this.listboxId}-option-${encodeURIComponent(JSON.stringify(e))}`}renderOption(e,t,n=!1){return R`
      <div
        class="picker-select__option"
        role="option"
        id=${this.optionId(e.value)}
        data-value=${e.value}
        ?hidden=${n}
        title=${this.params.showOptionTooltips===!1?z:e.value}
        aria-selected=${String(e.value===this.params.value)}
        aria-disabled=${String(!!e.disabled)}
        ?data-active=${e.value===this.activeValue}
        @mousedown=${e=>e.preventDefault()}
        @mousemove=${()=>{this.keyboard=!1,e.disabled||(this.activeValue=e.value)}}
        @click=${()=>this.commit(e.value)}
      >
        ${t?z:this.leading(e)}
        <span class="picker-select__copy">
          <span class="picker-select__label" style=${e.labelStyle??z}
            >${e.label}</span
          >
          ${e.description?R`<span class="picker-select__description">${e.description}</span>`:z}
        </span>
        <span class="picker-select__check" aria-hidden="true"
          >${e.value===this.params.value?I.check:z}</span
        >
      </div>
    `}render(){let e=this.renderedSections,t=this.rows(e),n=e.map((e,t)=>`${this.listboxId}-group-${t}`),r=this.params.groupBy?n.join(` `):this.listboxId,i=this.options(),a=new Set(t.map(e=>e.value)),o=i.find(e=>e.value===this.params.value),s=t.find(e=>e.value===this.activeValue),c=this.mode!==`closed`,l=R`<div
      class=${`picker-select__menu ${this.params.groupBy?`picker-select__menu--grouped`:``}`}
    >
      ${this.params.sheet?R`<div class="picker-select__page-header">
              <button
                type="button"
                class="picker-select__back"
                aria-label=${j(`common.back`)}
                @click=${()=>this.closeMenu(!0)}
              >
                ${I.chevronLeft}
              </button>
              <span>${this.params.label}</span>
            </div>`:z}
      ${this.mode===`search`?R` <input
              class="picker-select__search settings-input"
              type="search"
              role="combobox"
              data-picker-focus
              tabindex="0"
              autocomplete="off"
              spellcheck="false"
              aria-label=${j(`common.search`)}
              placeholder=${this.params.searchPlaceholder??j(`common.search`)}
              aria-autocomplete="list"
              aria-expanded="true"
              aria-controls=${r}
              aria-invalid=${this.params.invalid?`true`:z}
              aria-describedby=${this.params.describedBy??z}
              aria-activedescendant=${s?this.optionId(s.value):z}
              .value=${Ta(this.query)}
              @input=${e=>{this.query=e.currentTarget.value,this.activeValue=null}}
            />`:z}
      <div
        class="picker-select__options"
        role=${this.params.groupBy?z:`listbox`}
        @scroll=${this.syncScrollFade}
        id=${this.params.groupBy?z:this.listboxId}
        aria-label=${this.params.groupBy?z:this.params.label}
        ?data-picker-focus=${this.mode===`compact`}
        tabindex=${this.mode===`compact`?0:-1}
        aria-activedescendant=${this.mode===`compact`&&s?this.optionId(s.value):z}
      >
        ${e.map((e,t)=>{let r=e.expanded?va(this.params.groupBy?e.options:i,e=>e.value,t=>this.renderOption(t,!!e.group,!a.has(t.value))):z,o=e.group,s=n[t];return o?R`<div class="picker-select__group" role="group" aria-label=${o.label}>
            <button
              class="picker-select__group-toggle"
              type="button"
              tabindex=${c?0:-1}
              aria-expanded=${String(e.expanded)}
              aria-controls=${s}
              ?disabled=${!!this.query.trim()}
              @click=${()=>{let e=new Set(this.collapsedGroups);e.has(o.id)?e.delete(o.id):e.add(o.id),this.collapsedGroups=e}}
            >
              ${o.leading??z}<span class="picker-select__group-label"
                >${o.label}</span
              >
              <span>${e.options.length}</span
              ><span class="picker-select__chevron" aria-hidden="true">${I.chevronDown}</span>
            </button>
            <div
              id=${s}
              class="picker-select__group-options"
              role="listbox"
              aria-label=${o.label}
            >
              ${r}
            </div>
          </div>`:this.params.groupBy?R`<div id=${s} role="listbox" aria-label=${this.params.label}>
                  ${r}
                </div>`:r})}
      </div>
      <div
        class="picker-select__empty"
        role="status"
        ?hidden=${e.some(e=>e.options.length>0)}
      >
        ${j(`common.pickerNoMatches`)}
      </div>
    </div>`;return R`
      <div
        @focusout=${this.handleFocusOut}
        @keydown=${this.handleKeydown}
        @pointerenter=${this.handleHover}
        @pointerleave=${this.handleHover}
        ?data-keyboard=${this.keyboard}
      >
        <button
          id=${this.params.id??z}
          class="picker-select__trigger"
          type="button"
          aria-label=${o?`${this.params.label}: ${[o.label,this.params.showSelectedDescription&&o.description].filter(Boolean).join(` · `)}`:this.params.label}
          aria-haspopup="listbox"
          aria-expanded=${String(c)}
          aria-controls=${r}
          aria-invalid=${this.params.invalid?`true`:z}
          aria-describedby=${this.params.describedBy??z}
          title=${this.params.title??z}
          ?disabled=${this.params.disabled}
          @click=${this.handleTriggerClick}
        >
          ${this.params.variant===`submenu`?R`<span class="picker-select__name">${this.params.label}</span>`:z}
          ${this.leading(o)}
          <span class="picker-select__copy">
            <span class="picker-select__label">${o?.label??this.params.label}</span>
            ${this.params.showSelectedDescription&&o?.description?R`<span class="picker-select__description">${o.description}</span>`:z}
          </span>
          <span class="picker-select__chevron" aria-hidden="true"
            >${this.params.variant===`submenu`||this.params.sheet?I.chevronRight:I.chevronDown}</span
          >
        </button>
        ${this.params.sheet?c?l:z:R`<wa-popup
                ?active=${c}
                sync=${this.params.variant===`submenu`?z:`width`}
                >${l}</wa-popup
              >`}
      </div>
    `}},w([W({attribute:!1})],pS.prototype,`params`,void 0),w([V()],pS.prototype,`mode`,void 0),w([V()],pS.prototype,`query`,void 0),w([V()],pS.prototype,`activeValue`,void 0),w([V()],pS.prototype,`keyboard`,void 0),w([V()],pS.prototype,`collapsedGroups`,void 0),customElements.get(`openclaw-select-picker`)||customElements.define(`openclaw-select-picker`,pS)})))()}function hS(){return j(`chat.actions.copyAsMarkdown`)}function gS(e){return e.querySelector(`[data-copy-label]`)?.textContent??e.getAttribute(`aria-label`)}function _S(e,t,n=!1){let r=e.parentElement?.querySelector(`[data-copy-feedback]`);r&&(r.hidden=!n,r.textContent=t);let i=e.querySelector(`[data-copy-label]`)?.lastChild;i?.nodeType===Node.TEXT_NODE?i.nodeValue=t:e.setAttribute(`aria-label`,t)}async function vS(e,t,n){let r=e.currentTarget;if(!r||r.dataset.copyState===`copying`)return!1;let i=String(Number(r.dataset.copyAttempt??`0`)+1);r.dataset.copyAttempt=i,r.dataset.copyState=`copying`,r.setAttribute(`aria-busy`,`true`),r.disabled=!0,_S(r,n);let a=()=>r.isConnected&&r.dataset.copyAttempt===i,o=await un(t,a);if(delete r.dataset.copyState,r.removeAttribute(`aria-busy`),r.disabled=!1,!a())return!1;r.dataset.copyState=o?`copied`:`error`;let s=gS(r)??n,c=j(o?`common.copied`:`common.copyFailed`);_S(r,c,!0);let l=o?xS:SS;return window.setTimeout(()=>{if(!a())return;delete r.dataset.copyState;let e=gS(r);_S(r,e&&e!==c?e:s)},l),o}function yS(e,t=hS(),n=!1){return R`${Ca(e,R`
      <openclaw-tooltip .content=${t}>
        <button
          class=${n?`chat-copy-btn`:`btn btn--xs chat-copy-btn`}
          type="button"
          aria-label=${t}
          @click=${n=>void vS(n,e,t)}
        >
          <span class="chat-copy-btn__icon" aria-hidden="true">
            <span class="chat-copy-btn__icon-copy">${I.copy}</span>
            <span class="chat-copy-btn__icon-check">${I.check}</span>
          </span>
        </button>
        <span data-copy-feedback role="status" hidden></span>
      </openclaw-tooltip>
    `)}`}function bS(e){return yS(e,hS(),!0)}var xS,SS;function CS(){return(CS=e((()=>{B(),Ea(),F(),Ln(),L(),ta(),xS=1500,SS=2e3})))()}function J(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#39;`)}function wS(e){return!e.includes(`\r`)&&!e.includes(`\u2028`)&&!e.includes(`\u2029`)?e:e.replace(/\r\n?|[\u2028\u2029]/g,`
`)}function TS(e){if(!DS.test(e))return!1;let t=wS(e).split(`
`).filter(e=>e.trim().length>0);if(t.length<2)return!1;let n=0;for(let e of t){if(!ES.test(e)||!DS.test(e))return!1;n+=Array.from(e).filter(e=>DS.test(e)).length}return n>=8}var ES,DS;function OS(){return(OS=e((()=>{ES=/^[\t \u00a0▀▄█]+$/u,DS=/[▀▄█]/u})))()}function kS(e){return`<code class="assistant-transcript-role">${J(e)}</code>`}function AS(e){let t=FS.get(e);if(t)return t;let n=new Set,r=0;for(let t=0;t<e.length;t+=1){let i=e[t]?.type;i===`link_open`?r+=1:i===`link_close`?r=Math.max(0,r-1):i===`image`&&r>0&&n.add(t)}return FS.set(e,n),n}function jS(e,t){let n=``,r=0;for(let i of t){let t=Math.max(r,Math.min(i.start,e.length)),a=Math.max(t,Math.min(i.end,e.length));n+=J(e.slice(r,t)),a>t&&(n+=kS(e.slice(t,a))),r=a}return n+J(e.slice(r))}function MS(e){e.use(Ha,{isStructuralHtmlInline:e=>e.meta?.taskListPlugin===!0}),e.renderer.rules[Za]=(e,t)=>{let n=e[t];return n?kS(n.content):``},e.renderer.rules.image=(e,t,n,r)=>{let i=e[t];if(!i)return``;let a=String(i.attrGet(`src`)??``).trim(),o=i.content.trim()||`image`,s=i.meta?.assistantTranscriptRoleImage,c=AS(e).has(t);if(!/^data:image\/[a-z0-9.+-]+;base64,/i.test(a)&&r?.remoteImages!==!0){let e=s?jS(s.text,s.spans):J(o),t=URL.parse(a);return!t||t.protocol!==`https:`&&t.protocol!==`http:`?e:`<span class="markdown-external-image">${`<span>${J(j(`chat.externalImage.notLoaded`))}: ${e}</span>`}${c?``:` <a href="${J(a)}">${J(j(`chat.externalImage.open`))}</a>`}</span>`}let l=`<img class="markdown-inline-image" src="${J(a)}" alt="${J(o)}">`,u=c||r?.interactiveImages!==!0?l:`<button class="markdown-inline-image-button" type="button" aria-label="${J(j(`chat.imageLightbox.open`,{title:i.content.trim()?o:j(`chat.imageLightbox.untitled`)}))}">${l}</button>`;return s?`${kS(`${j(`sessionsView.assistant`)}:`)} ${u}`:u}}function NS(e){return e.replace(/\r\n?/g,`
`).replace(/\0/g,``)}function PS(e,t){let n=document.createElement(`div`);if(n.className=`markdown-plain-text-fallback`,!t)return n.textContent=NS(e),n;let r=document.createElement(`code`);r.className=`assistant-transcript-role`,r.textContent=NS(`${j(`sessionsView.assistant`)}:`);let i=document.createElement(`span`);return i.className=`markdown-plain-text-source`,i.textContent=NS(e),n.append(r,`
`,i),n}var FS;function IS(){return(IS=e((()=>{qa(),F(),OS(),FS=new WeakMap})))()}function LS(e={}){return{assistantTranscriptRoleHeaders:e.assistantTranscriptRoleHeaders??!1,codeBlockChrome:e.codeBlockChrome??`copy`,codeBlockInteraction:e.codeBlockInteraction??`static`,fileLinks:e.fileLinks??!1,githubRepo:e.githubRepo??null,humanMentions:e.humanMentions??[],githubRepositories:e.githubRepositories??[],interactiveImages:e.interactiveImages??!1,linkFavicons:e.linkFavicons??!1,progressBars:e.progressBars??!1,mode:e.mode??`message`,remoteImages:e.remoteImages??e.mode===`document`,sessionLinks:e.sessionLinks??!1,tableInteractions:e.tableInteractions??`none`}}function RS(){return(RS=e((()=>{})))()}function zS(e){if(e.length>4e4)return null;let t=e.trim();if(!/^(?:\{[\s\S]*\}|\[[\s\S]*\])$/.test(t))return null;if(e.length>HS)return{text:e};let n=Pc(e,!0),r=0,i=0;for(n.scan();n.getTokenLength()>0;n.scan()){let t=e[n.getTokenOffset()];if((t===`{`||t===`[`)&&(r+=1),(t===`}`||t===`]`)&&--r,r>US||++i>WS)try{return JSON.parse(e),{text:e}}catch{return null}}let a=[],o=Oc(e,a,{disallowComments:!0,allowTrailingComma:!1});return o&&a.length===0?{text:e,root:o}:null}function BS({text:e,root:t}){if(!t)return``;let n=t=>J(e.slice(t.offset,t.offset+t.length)),r=(e,t,i=``,a=``)=>{let o=e.children??[],s=e.type,c=s===`array`;if(s!==`object`&&!c||o.length===0)return`${i}<span class="code-block-json-value--${s===`string`||s===`null`?s:`literal`}">${n(e)}</span>${a}`;let l=c?`[`:`{`,u=c?`]`:`}`,d=j(c?o.length===1?`chat.codeBlock.jsonArrayItem`:`chat.codeBlock.jsonArrayItems`:`chat.codeBlock.jsonObjectKeys`,{count:String(o.length)}),f=o.map((e,i)=>{let a=e.type===`property`,s=a?e.children?.[0]:void 0,c=a?e.children?.[1]:e;if(!c)return``;let l=s?`<span class="code-block-json-key">${n(s)}</span>: `:``;return`<div class="code-block-json-row">${r(c,t+1,l,i+1<o.length?`,`:``)}</div>`}).join(``);return`<details class="code-block-json-node"${t<2?` open`:``}><summary>${i}<span class="code-block-json-node-opening">${l}</span><span class="code-block-json-node-summary">${J(d)}${a}</span></summary><div class="code-block-json-children">${f}</div><span class="code-block-json-bracket">${u}${a}</span></details>`};return`<div class="code-block-json-tree" data-markdown-key="json-tree">${r(t,0)}</div>`}function VS(){return`<div class="code-block-json-modes" data-markdown-key="json-modes" role="group" aria-label="${J(j(`chat.codeBlock.jsonView`))}">${[`tree`,`raw`].map(e=>`<button type="button" class="code-block-json-mode" data-json-mode="${e}" aria-pressed="${e===`tree`}">${J(j(e===`tree`?`chat.codeBlock.jsonTree`:`chat.codeBlock.jsonRaw`))}</button>`).join(``)}</div>`}var HS,US,WS;function GS(){return(GS=e((()=>{Fc(),F(),As(),RS(),OS(),uc(),HS=2e4,US=64,WS=4e3})))()}function KS(e){let t=JSON.stringify(e).replaceAll(`<`,`\\u003c`).replaceAll(`>`,`\\u003e`);return`${oC}${t}`}function qS(e,t){if(t!==sC||!e.startsWith(oC))return e;try{let t=JSON.parse(e.slice(24));return typeof t==`string`?t:e}catch{return e}}function JS(e){return qS(e.dataset.code??``,e.dataset.codeEncoding)}function YS(e){let t=e.target;if(!(t instanceof Element))return;XS(t);let n=t.closest(`.code-block-copy`);if(!n)return;let r=JS(n),i=(lC.get(n)??0)+1;lC.set(n,i);let a=()=>n.isConnected&&lC.get(n)===i&&JS(n)===r;un(r,a).then(e=>{if(!a())return;n.classList.toggle(`copied`,e),n.classList.toggle(`copy-failed`,!e),n.setAttribute(`aria-label`,j(e?`common.copied`:`common.copyFailed`)),clearTimeout(uC.get(n));let t=setTimeout(()=>{n.classList.remove(`copied`),n.classList.remove(`copy-failed`),n.setAttribute(`aria-label`,j(`common.copyCode`)),uC.delete(n)},e?1500:2e3);uC.set(n,t)})}function XS(e){let t=e.closest(`.code-block-wrapper`);if(!t)return;e.closest(`.code-block-expand`)&&(t.classList.add(`is-expanded`),e.closest(`.code-block-expand`)?.setAttribute(`aria-expanded`,`true`));let n=e.closest(`.code-block-json-mode`);if(n){t.classList.toggle(`is-json-raw`,n.dataset.jsonMode===`raw`);for(let e of t.querySelectorAll(`.code-block-json-mode`))e.setAttribute(`aria-pressed`,String(e===n));ZS(t)}let r=e.closest(`.code-block-wrap`);if(!r)return;let i=t.classList.toggle(`is-wrapped`),a=j(i?`chat.codeBlock.disableWrap`:`chat.codeBlock.enableWrap`);r.setAttribute(`aria-pressed`,String(i)),r.setAttribute(`aria-label`,a),r.title=a,ZS(t)}function ZS(e){let t=e.querySelector(`.code-block-viewport`),n=t?.querySelector(`code`);if(!t||!n)return;let r=!e.classList.contains(`is-wrapped`)&&n.scrollWidth>t.clientWidth+1;e.classList.toggle(`has-horizontal-overflow`,r)}function QS(e,t){let n=t.trim().toLowerCase();try{if(n&&jl.getLanguage(n))return jl.highlight(e,{language:n,ignoreIllegals:!0}).value;if(!n&&e.trim()){let t=jl.highlightAuto(e);if(t.relevance>=2)return t.value}}catch{}return J(e)}function $S(e){return QS(e,`json`)}function eC(e,t){let n=[t.includes(`hljs-`)?`hljs`:``,e?`language-${e}`:``].filter(Boolean);return n.length>0?` class="${J(n.join(` `))}"`:``}function tC(e,t){return`<div class="code-block-header" data-markdown-key="header"><span class="code-block-lang">${J(e||j(`chat.codeBlock.languageFallback`))}</span><div class="code-block-actions">${t}</div></div>`}function nC(e){return`<button type="button" class="code-block-copy" data-markdown-key="copy" data-code="${J(KS(e))}" data-code-encoding="${sC}" aria-label="${J(j(`common.copyCode`))}"><span class="code-block-copy__idle" aria-hidden="true"></span><span class="code-block-copy__done" aria-hidden="true"></span><span class="code-block-copy__failed" aria-hidden="true">!</span></button>`}function rC(e,t,n,r={}){let i=r.blockArt||TS(e),a=r.highlight,o=i||a===!1?J(e):QS(e,t),s=`<pre><code${i?` class="markdown-block-art"`:eC(t,o)}>${o}</code></pre>`,c=n,l=c?.codeBlockChrome!==`none`,u=c?.codeBlockInteraction===`interactive`;if(!l&&!u)return s;let d=l?nC(r.copyText??e):``;if(!u)return`<div class="code-block-wrapper">${tC(t,d)}${s}</div>`;let f=!i&&a!==!1&&(!t||t.toLowerCase()===`json`)?r.json??zS(e):null,p=f?BS(f):``,m=[`text`,`md`,`markdown`].includes(t.trim().toLowerCase())?0:Math.max(0,iC(e)-cC),h={count:String(m)},g=j(m===1?`chat.codeBlock.showHiddenLine`:`chat.codeBlock.showHiddenLines`,h),_=j(m===1?`chat.codeBlock.hiddenLine`:`chat.codeBlock.hiddenLines`,h),v=m?`<button type="button" class="code-block-expand" data-markdown-key="expand" aria-label="${J(g)}" aria-expanded="false"><span class="code-block-chevron" aria-hidden="true"></span><span>${J(_)}</span></button>`:``,y=J(j(`chat.codeBlock.enableWrap`)),b=`<button type="button" class="code-block-wrap" data-markdown-key="wrap" aria-label="${y}" title="${y}" aria-pressed="false"><span class="code-block-wrap__enable" aria-hidden="true"></span><span class="code-block-wrap__disable" aria-hidden="true"></span></button>`,x=tC(t,`${p?VS():``}${b}${d}`);return`<div class="code-block-wrapper${p?` code-block-wrapper--json`:``}${m?` is-collapsible`:``}">${x}${p}<div class="code-block-viewport" data-markdown-key="viewport">${s}</div>${v}</div>`}function iC(e){let t=1,n=-1;for(;(n=e.indexOf(`
`,n+1))>=0&&n<e.length-1;)t+=1;return t}function aC(e){return e.endsWith(`
`)?e.slice(0,-1):e}var oC,sC,cC,lC,uC;function dC(){return(dC=e((()=>{gl(),Rl(),Cl(),Ol(),Fl(),wl(),F(),As(),Ln(),GS(),OS(),uc(),oC=`openclaw:block-art-code:`,sC=`block-art-json`,cC=7,lC=new WeakMap,uC=new WeakMap;for(let[e,t]of Object.entries({bash:vl,cpp:Sl,css:_l,diff:zl,go:Bl,java:Ll,javascript:Dl,json:Ml,markdown:El,python:Il,rust:Tl,typescript:Pl,xml:kl,yaml:Nl}))jl.registerLanguage(e,t);jl.registerAliases(`shell`,{languageName:`bash`})})))()}function fC(e,t=bC){let n=`${t}\\.${e}`,r=`(?:~\\/|\\.\\.\\/|\\.\\/|\\/)(?:${t}\\/)*${n}`,i=`(?![\\p{L}\\p{M}\\p{N}-]+(?:\\.[\\p{L}\\p{M}\\p{N}-]+)*\\.(?:[\\p{L}\\p{M}]{2,}|[xX][nN]--[A-Za-z0-9-]+)\\/)${t}(?:\\/${t})*\\/${n}`,a=`[A-Za-z]:[\\\\/](?:${t}[\\\\/])*${n}`,o=`(?!\\.?[\\p{L}\\p{M}\\p{N}_])`,s=`(?:${r}|${a}|${i})(?:${wC})?${o}`,c=`${n}${wC}${o}`;return{scan:RegExp(`${s}|${c}`,`gu`),exact:RegExp(`^(?:${s}|${c})$`,`u`),bare:RegExp(`^${t}\\.(${SC})$`,`u`)}}function pC(e){let t=e.target;if(!(t instanceof Element))return null;let n=t.closest(`a[data-file-path]`),r=n?.dataset.filePath;if(!r)return null;let i=n.dataset.fileLine;return{path:r,line:i?Number.parseInt(i,10):null}}function mC(e){if(e.key!==`Enter`&&e.key!==` `)return null;let t=pC(e);return t&&e.preventDefault(),t}function hC(e){let t=OC.exec(e),n=t?.[1];return t&&n?{path:e.slice(0,t.index),line:Number.parseInt(n,10)}:{path:e,line:null}}function gC(e,t){if(e.includes(`/`)||e.includes(`\\`))return!1;let n=t.exec(e);return!!(n?.[1]&&kC.has(n[1].toLowerCase()))}function _C(e,t){let n=e.trim(),r=t?.authored?EC:TC;return!r.exact.test(n)&&!gC(n,r.bare)?null:hC(n)}function vC(e){return yC.test(e.trim())}var yC,bC,xC,SC,CC,wC,TC,EC,DC,OC,kC;function AC(){return(AC=e((()=>{yC=/^(?:~\/|\/(?:Users|home|tmp|private\/tmp|var\/folders|private\/var\/folders)\/|\/[A-Za-z]:\/|[A-Za-z]:[\\/])/,bC=`[\\p{L}\\p{M}\\p{N}_.@#+-]+`,xC=`[^/\\\\:?\\p{Cc}]+`,SC=`[A-Za-z][A-Za-z0-9]{0,7}`,CC=`[A-Za-z0-9]{1,8}`,wC=`:\\d{1,6}(?:[-:]\\d{1,6})?`,TC=fC(SC),EC=fC(CC,xC),DC=TC.scan,OC=/:(\d{1,6})(?:[-:]\d{1,6})?$/,kC=new Set(`astro.bash.c.cc.cfg.cjs.conf.cpp.cs.css.csv.diff.fish.go.h.hpp.htm.html.ini.java.js.json.jsonc.jsx.kt.kts.less.lock.log.markdown.md.mdx.mjs.patch.plist.proto.py.rb.rs.scss.sh.sql.svelte.svg.swift.toml.ts.tsx.txt.vue.xml.yaml.yml.zsh`.split(`.`))})))()}function jC(e=[],t){let n=new Map;for(let r of[...e,...t?[{...t,aliases:[]}]:[]]){let e=r.owner&&r.repo?{owner:r.owner.toLowerCase(),repo:r.repo.toLowerCase()}:null;for(let t of[...r.aliases,...e?[e.repo]:[]]){let r=t.trim().toLowerCase();if(!r)continue;let i=n.get(r);n.set(r,i===void 0||i?.owner===e?.owner&&i?.repo===e?.repo?e:null)}}return[...n].toSorted(([e],[t])=>e<t?-1:+(e>t))}function MC(e,t){return JSON.stringify(jC(e,t))}function NC(){return(NC=e((()=>{})))()}function PC(e,t,n){let r=xo(e,t),i=[];if(!r)return{source:e,tokens:i};let a=to(e),o=n(e),s=0,c;do c=`openclawhumanmention`+s+++`x`;while(o.includes(n(c)));let l=0,u=``;for(let t of r){if(a.some(([e,n])=>t.start<n&&t.end>e&&(e<t.start||n>t.end)))continue;let n=c+i.length+`end`;i.push({marker:n,profileId:t.profileId,label:e.slice(t.start,t.end)}),u+=e.slice(l,t.start)+n,l=t.end}return{source:u+e.slice(l),tokens:i}}function FC(e,t=[]){let n=e;for(let e of t)n=n.replaceAll(e.marker,()=>e.label);return n}function IC(e){e.core.ruler.before(`inline`,`human-mention-references`,t=>{let n=t.env.humanMentionTokens,r=t.env.references;if(!n?.length||!r)return;let i=e.utils.normalizeReference,a=n.map(({marker:e,label:t})=>({marker:i(e),label:t})),o=e=>{let t=e;for(let{marker:e,label:n}of a)t=t.replaceAll(e,()=>n);return i(t)},s=new Map;for(let[e,t]of Object.entries(r)){let n=o(e);s.has(n)||s.set(n,t)}t.env.references=new Proxy(r,{get(e,t){return typeof t==`string`?s.get(o(t)):Reflect.get(e,t)}})}),e.core.ruler.after(`file-links`,`human-mentions`,e=>{let t=e.env?.humanMentionTokens;if(!t?.length)return;let n=e=>FC(e,t),r=e=>{e.content=n(e.content),e.attrs=e.attrs?.map(([e,t])=>[e,typeof t==`string`?n(t):t])??null,e.children?.forEach(r)};for(let i of e.tokens){if(i.type!==`inline`||!i.children){r(i);continue}let a=0;i.children=i.children.flatMap(n=>{if(n.type===`link_open`?a+=1:n.type===`link_close`&&(a=Math.max(0,a-1)),n.type!==`text`||a>0)return r(n),[n];let i=t.flatMap(e=>{let t=n.content.indexOf(e.marker);return t<0?[]:[{...e,index:t}]}).toSorted((e,t)=>e.index-t.index);if(!i.length)return[n];let o=[],s=0;for(let t of i){let r=new e.Token(`text`,``,0);r.content=n.content.slice(s,t.index);let i=new e.Token(`human_mention`,``,0);i.content=t.label,i.attrSet(`profile-id`,t.profileId),o.push(r,i),s=t.index+t.marker.length}let c=new e.Token(`text`,``,0);return c.content=n.content.slice(s),[...o,c]}),i.content=n(i.content)}}),e.renderer.rules.human_mention=(e,t)=>{let n=e[t],r=n?.attrGet(`profile-id`);return n&&typeof r==`string`&&r?`<openclaw-person-reference profile-id="${J(r)}" label="${J(n.content)}">${J(n.content)}</openclaw-person-reference>`:``}}function LC(){return(LC=e((()=>{Ga(),Eo(),OS()})))()}function RC(e){let t=(e.split(WC).at(-1)??e).toLowerCase();if(Object.hasOwn(HC,t))return HC[t];let n=t.lastIndexOf(`.`),r=n>0?t.slice(n+1):``;return Object.hasOwn(UC,r)?UC[r]:`file`}function zC(e,t){let n=e;for(let e=t.length-1;e>=0;e--){let r=t[e],i=n.children.get(r);i||(i={pathCount:0,children:new Map},n.children.set(r,i)),n=i,n.pathCount+=1}}function BC(e,t){let n=e;for(let e=1;e<=t.length;e++)if(n=n.children.get(t[t.length-e])??n,n.pathCount===1||e===t.length)return e;return t.length}function VC(e){let t=[...new Set(e)],n=new Map(t.map(e=>[e,e.split(WC)])),r={pathCount:0,children:new Map};for(let e of n.values())zC(r,e);let i=new Map;for(let[e,t]of n){let n=BC(r,t);i.set(e,t.slice(-n).join(e.includes(`\\`)?`\\`:`/`))}return i}var HC,UC,WC;function GC(){return(GC=e((()=>{HC={"bun.lock":`package`,"package-lock.json":`package`,"package.json":`package`,"pnpm-lock.yaml":`package`,"skill.md":`skill`,"yarn.lock":`package`},UC={astro:`component`,avif:`image`,bash:`shell`,c:`code`,cc:`code`,cfg:`data`,cjs:`code`,conf:`data`,cpp:`code`,cs:`code`,css:`code`,cts:`code`,fish:`shell`,gif:`image`,go:`code`,h:`code`,hpp:`code`,htm:`code`,html:`code`,ico:`image`,ini:`data`,java:`code`,jpeg:`image`,jpg:`image`,js:`code`,json:`data`,jsonc:`data`,jsx:`component`,kt:`code`,kts:`code`,less:`code`,lock:`data`,markdown:`markdown`,md:`markdown`,mdx:`markdown`,mjs:`code`,mts:`code`,php:`code`,plist:`data`,png:`image`,proto:`data`,py:`code`,rb:`code`,rs:`code`,scss:`code`,sh:`shell`,sql:`code`,svelte:`component`,svg:`image`,swift:`code`,toml:`data`,ts:`code`,tsx:`component`,vue:`component`,webp:`image`,xml:`data`,yaml:`data`,yml:`data`,zsh:`shell`},WC=/[\\/]/})))()}function KC(e,t){let n=0;for(let r=t-1;r>=0&&e.charAt(r)===`\\`;--r)n+=1;return n%2==1}function qC(e,t){return t.some(([t,n])=>e>=t&&e<n)}function JC(e){let t=sw.exec(e);return t?t[1]?`details_open_expanded`:`details_open`:cw.test(e)?`details_close`:lw.test(e)?`summary_open`:uw.test(e)?`summary_close`:null}function YC(e,t,n=0){if(!/^[ \t]*<\/?(?:details|summary)(?=[\s>])/i.exec(e))return null;let r=t??to(e),i=[];for(let t of e.matchAll(ow)){let a=t.index??0;KC(e,a)||qC(n+a,r)||i.push({end:a+t[0].length,raw:t[0],start:a})}return i.length>0?i:null}function XC(e,t,n,r=`paragraph`){if(r===`paragraph`&&!t.trim())return;let i=r===`paragraph`?`p`:`summary`,a=e.push(`${r}_open`,i,1);a.map=[n,n+1];let o=e.push(`inline`,``,0);o.content=t,o.map=[n,n+1],o.children=[],e.push(`${r}_close`,i,-1)}function ZC(e,t,n={}){let r=e.map(e=>JC(e.raw)),i=Array.from({length:e.length},()=>-1),a=-1;for(let t=e.length-1;t>=0;--t)i[t]=a,r[t]===`summary_close`&&(a=t);for(let a=0;a<e.length;a+=1){let o=e[a];if(!o)continue;let s=r[a];if((s===`details_open`||s===`details_open_expanded`)&&t.length<aw)n.onOpen?.(o,s===`details_open_expanded`),t.push({hasSummary:!1});else if(s===`details_close`&&t.length>0)n.onClose?.(o),t.pop();else if(s===`summary_open`){let r=t.at(-1);if(!r||r.hasSummary)continue;let s=i[a]??-1,c=s>=0?e[s]:void 0;if(c)n.onSummary?.(o,c),r.hasSummary=!0,a=s;else if(n.allowPendingSummary)return!0}}return!1}function QC(e,t,n,r,i){let a=0,o=(r,i=r.end)=>{XC(e,t.slice(a,r.start),n),a=i};ZC(i,r,{onOpen(t,n){o(t);let r=e.push(`details_open`,`details`,1);n&&r.attrSet(`open`,``)},onClose(t){o(t),e.push(`details_close`,`details`,-1)},onSummary(r,i){o(r,i.end),XC(e,t.slice(r.end,i.start),n,`summary`)}}),XC(e,t.slice(a),n)}function $C(e,t,n,r){if((e.sCount[t]??0)-e.blkIndent>=4)return!1;let i=(e.bMarks[t]??0)+(e.tShift[t]??0),a=e.eMarks[t]??e.src.length,o=e.src.slice(i,a),s=YC(o);return s?r?!0:(QC(e,o,t,e[dw]??=[],s),e.line=t+1,!0):!1}function ew(e){let t=e.trimStart();if(t.startsWith(`<!--`))return`comment`;if(t.startsWith(`<?`))return`processing_instruction`;if(t.startsWith(`<![CDATA[`))return`cdata`;if(/^<![A-Za-z]/.test(t))return`declaration`;let n=/^<(pre|script|style|textarea)(?=[\s>]|$)/i.exec(t)?.[1];return n?{element:n.toLowerCase()}:null}function tw(e,t){return typeof e==`object`?t.toLowerCase().includes(`</${e.element}>`):e===`comment`?t.includes(`-->`):e===`processing_instruction`?t.includes(`?>`):e===`declaration`?t.includes(`>`):t.includes(`]]>`)}function nw(e,t,n=[],r=0){let i=t.context??ew(e);if(!i)return!1;let a=e.length-e.trimStart().length;return!t.context&&qC(r+a,n)?!1:(t.context=tw(i,e)?null:i,!0)}function rw(e,t){let n=[];t.block.parse(e,t,{},n);let r=[0];for(let t of e.matchAll(/\n/g))r.push(t.index+1);let i=[];for(let t of n){if(t.type!==`html_block`||!t.map)continue;let n={context:null},a=t.content.split(`
`);for(let o=t.map[0];o<t.map[1];o+=1){if(!nw(a[o-t.map[0]]??``,n))continue;let s=r[o]??e.length,c=r[o+1]??e.length,l=i.at(-1);l?.[1]===s?l[1]=c:i.push([s,c])}}return i}function iw(e){e.block.ruler.before(`html_block`,`details_block`,$C,{alt:[`paragraph`,`reference`,`blockquote`]}),e.core.ruler.after(`block`,`details_balance`,e=>{let t=[],n=[];for(let r of e.tokens){if(r.type===`details_open`)n.push({hasSummary:!1});else if(r.type===`summary_open`){let e=n.at(-1);e&&(e.hasSummary=!0)}else r.type===`details_close`&&n.pop();if(r.type!==`html_block`||n.length===0){t.push(r);continue}let i=r.level,a=[],o={push(t,n,r){let o=new e.Token(t,n,r);return o.block=!0,r<0&&--i,o.level=i,r>0&&(i+=1),a.push(o),o}},s=r.content.split(`
`),c=``,l={context:null},u=()=>{if(!c)return;let e=o.push(`html_block`,``,0);e.content=c,e.map=r.map,c=``};for(let[e,t]of s.entries()){let i=e<s.length-1,a=nw(t,l)?null:YC(t);if(!a){c+=t+(i?`
`:``);continue}u(),QC(o,t,(r.map?.[0]??0)+e,n,a)}u(),t.push(...a)}for(;n.length>0;){let r=new e.Token(`details_close`,`details`,-1);r.block=!0,t.push(r),n.pop()}let r=0;for(let e of t)e.nesting<0&&--r,e.level=r,e.nesting>0&&(r+=1);e.tokens=t}),e.renderer.rules.details_open=(e,t)=>e[t]?.attrGet(`open`)===null?`<details>`:`<details open>`,e.renderer.rules.details_close=()=>`</details>
`,e.renderer.rules.summary_open=()=>`<summary>`,e.renderer.rules.summary_close=()=>`</summary>`}var aw,ow,sw,cw,lw,uw,dw;function fw(){return(fw=e((()=>{Ga(),aw=32,ow=/<\/?(?:details|summary)(?=[\s>])[^>]*>/gi,sw=/^<details( open)?>$/i,cw=/^<\/details>$/i,lw=/^<summary>$/i,uw=/^<\/summary>$/i,dw=Symbol(`markdownDetailsStack`)})))()}function pw(e,t,n){let r=e[t-1],i=e[n];return(r===void 0||/\s/.test(r)||`([{<"'\``.includes(r))&&(i===void 0||/\s/.test(i)||`.,;:!?)]}>"'`.includes(i))}function mw(e,t,n,r,i){let a=t[n].content,o=[],s=0,c=t=>{if(t){let n=new e.Token(`text`,``,0);n.content=t,o.push(n)}};for(let e of a.matchAll(r)){let t=i(e);t&&(c(a.slice(s,e.index)),o.push(...t),s=e.index+e[0].length)}return s?(c(a.slice(s)),t.splice(n,1,...o),n+o.length-1):n}function hw(e){let t=/(?:^|[\s([{"'])([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)$/.exec(e);return!t||[t[1],t[2]].some(e=>e===`.`||e===`..`)?null:{repository:{owner:t[1],repo:t[2]},length:t[1].length+t[2].length+1}}function gw(e,t,n=e.length){let r=e.toLowerCase(),i=e.slice(0,n).toLowerCase().length;return t.filter(([e])=>{let t=r.lastIndexOf(e);return t>=0&&t<=i&&/^[,:\])]*$/u.test(r.slice(t+e.length))&&!/[\p{L}\p{N}_./-]/u.test(r[t-1]??``)}).toSorted(([e],[t])=>t.length-e.length)[0]}function _w(e,t,n){let r=e.trimEnd(),i=r.replace(/[,:\])]+$/u,``).trimEnd(),a=/(?:^|[\s([{])(?:"(.*)"|'(.*)'|“(.*)”|‘(.*)’)$/u.exec(i)?.slice(1).find(e=>e!==void 0),o=/\b(?:repo(?:sitory)?|project)\s*[:=]?\s+([^;!?]+)$/iu.exec(r)?.[1],s=a??o,c=(s??i).trim(),l=hw(c);if(l&&(s===void 0||l.length===c.length))return l.repository;let u=gw(r,t,a===void 0?o===void 0?r.length:r.length-o.length:i.length-a.length-2);if(u)return u[1];if(s!==void 0)return t.find(([e])=>e===c.toLowerCase())?.[1]??null;let d=c.match(/[^\s([{]+$/u)?.[0]??``;return/[a-z][A-Z]|\w[._]\w|\/|["'’”]$/u.test(d)?null:n}function vw(e){let t=new Map,n={content:``,scannedTo:0},r=0;for(let i of e)i.type===`link_open`?r++:i.type===`link_close`&&r--,r===0&&i.type===`text`?(t.set(i,{run:n,offset:n.content.length}),n.content+=i.content):/^(?:em|strong)_(?:open|close)$/.test(i.type)||(n={content:``,scannedTo:0});return t}function yw(e){e.core.ruler.before(`web-link-classes`,`github-item-refs`,e=>{let t=e.env,n=jC(t?.githubRepositories,t?.githubRepo),r=!1;for(let i of e.tokens){i.type===`heading_open`?r=!0:i.type===`heading_close`&&(r=!1);let a=i.children;if(r||i.type!==`inline`||!a)continue;let o=vw(a);for(let r=0;r<a.length;r++){let i=a[r];if(!i)continue;let s=o.get(i);s&&(r=mw(e,a,r,bw,r=>{let i=r[1];if(!i)return null;let a=r.index+r[0].length,o=r.index,c=s.offset+o,l=s.offset+a,u=s.run.content,d=u.slice(s.run.scannedTo,c),f=hw(d),p=f?c-f.length:c,m=u.slice(s.run.scannedTo,p).match(xw);s.run.scannedTo=l;let h=m&&pw(u,p-m[0].length,l)?m[1]:void 0;if(!h&&!f&&i.length<4||!pw(u,p,l)||/^[.-]\w/.test(u.slice(l)))return null;let g=f?.repository??(h?_w(d.slice(0,-m[0].length),n,t?.githubRepo):t?.githubRepo);if(!g)return null;let _=`https://github.com/${encodeURIComponent(g.owner)}/${encodeURIComponent(g.repo)}`,v=h&&/^(?:pr|pull)/i.test(h)?`pull`:`issues`,y=new e.Token(`link_open`,`a`,1);y.attrSet(`href`,`${_}/${v}/${i}`);let b=new e.Token(`text`,``,0);return b.content=`#${i}`,[y,b,new e.Token(`link_close`,`a`,-1)]}))}}})}var bw,xw;function Sw(){return(Sw=e((()=>{bw=/#([1-9]\d{0,9})(?!\w|[.-]\w)/g,xw=/(PR|pull request|pull|issue|fixes|closes|resolves)\s+$/i})))()}function Cw(e){let t=e.trim(),n=A(t);return!n||`agent:${n.agentId}:${n.rest}`!==t.toLowerCase()?null:{sessionKey:t,agentId:n.agentId}}function ww(e,t,n){if(!/^(?:https?:\/\/|\/)/i.test(e.trim()))return null;try{let r=new URL(e,globalThis.location.href),i=de(r.pathname,t??Ar(globalThis.location.pathname)[0],n);return i&&(r.protocol===`http:`||r.protocol===`https:`)?{url:r,target:i}:null}catch{return null}}function Tw(e,t={}){let n=ww(e,t.basePath,t.mainKey);return n&&(n.url.origin===globalThis.location.origin||n.url.origin===t.publicOrigin)?n:null}function Ew(e){e.core.ruler.before(`file-links`,`session-links`,e=>{if(e.env?.sessionLinks!==!0)return;let t=(e,t)=>{let n=Cw(t),r=n?null:ww(t);if(!n&&!r)return!1;if(r){if(e.attrSet(`data-session-href`,t),r.url.origin!==globalThis.location.origin)return!1;e.attrSet(`href`,t)}else n&&e.attrSet(`data-session-key`,n.sessionKey);return e.attrJoin(`class`,`markdown-session-link`),e.attrSet(`role`,`link`),e.attrSet(`tabindex`,`0`),!0};for(let n of e.tokens){let r=n.children;if(n.type!==`inline`||!r)continue;let i=0;for(let n=0;n<r.length;n++){let a=r[n];if(a){if(a.type===`link_open`)t(a,String(a.attrGet(`href`)??``)),i++;else if(a.type===`link_close`)i--;else if(i===0&&a.type===`code_inline`){let i=new e.Token(`link_open`,`a`,1);t(i,a.content)?(r.splice(n,1,i,a,new e.Token(`link_close`,`a`,-1)),n+=2):i.attrGet(`data-session-href`)&&a.attrSet(`data-session-href`,a.content)}else i===0&&a.type===`text`&&(n=mw(e,r,n,jw,n=>{let r=n.index+n[0].length,i=new e.Token(`link_open`,`a`,1);if(!pw(a.content,n.index,r)||!t(i,n[0]))return null;let o=new e.Token(`text`,``,0);return o.content=n[0],[i,o,new e.Token(`link_close`,`a`,-1)]}))}}}})}function Dw(e){let t=e?.runtimeConfig?.state.configSnapshot?.runtimeConfig;return Kn({gateway:{publicOrigin:ge(d(t?.gateway)?.publicOrigin)}})}function Ow(e,t){let n=e.target instanceof Element?e.target.closest(`a, [data-session-href]`):null,r=n?.dataset.sessionKey;if(r&&!n.dataset.sessionHref)return Cw(r);let i=n?.closest(`openclaw-session-progress-hovercard-provider`)?.context,a=n?.getAttribute(`href`)??n?.dataset.sessionHref,o=a?Tw(a,{basePath:t??i?.basePath,publicOrigin:Dw(i)}):null;if(!o)return null;let{url:s,target:c}=o;return{namespace:c.namespace,pathname:s.pathname,...s.search?{search:s.search}:{},...s.hash?{hash:s.hash}:{}}}function kw(e,t){if(e.key!==`Enter`&&e.key!==` `)return null;let n=Ow(e,t);return n&&e.preventDefault(),n}function Aw(e,t){if(`pathname`in t){let{namespace:n,...r}=t;e.navigate(n,r);return}let n=Bn({context:e,face:`chat`,sessionKey:t.sessionKey,agentId:t.agentId,exactKey:!0,preferenceDerivedFace:!0});e.navigate(`chat`,n.options)}var jw;function Mw(){return(Mw=e((()=>{ei(),gr(),Qt(),N(),jw=/agent:[^\s<>"'`]*[^\s<>"'`.,;:!?)}\]]/g})))()}function Nw(e){return typeof e==`object`&&!!e&&`tableInteractions`in e&&e.tableInteractions===`enabled`}function Pw(e){let t=e.renderer.rules.table_open,n=e.renderer.rules.table_close;e.renderer.rules.table_open=(e,n,r,i,a)=>Nw(i)?`<div class="markdown-table" data-table-interactions><div class="markdown-table__viewport"><table>`:t?.(e,n,r,i,a)??`<table>
`,e.renderer.rules.table_close=(e,t,r,i,a)=>Nw(i)?`</table></div><div class="markdown-table__actions"><button type="button" class="markdown-table__expand" aria-label="${J(j(`common.expandTable`))}"></button><button type="button" class="markdown-table__copy" aria-label="${J(j(`common.copyTable`))}"></button></div></div>`:n?.(e,t,r,i,a)??`</table>
`}function Fw(e){return[...e.rows].map(e=>[...e.cells].map(e=>e.textContent?.trim()??``).join(`	`)).join(`
`)}function Iw(e){let t=e.querySelector(Uw);if(!t)return;let{scrollWidth:n,clientWidth:r,scrollLeft:i}=t,a=n-r>1;e.classList.toggle(`markdown-table--can-scroll-left`,a&&i>1),e.classList.toggle(`markdown-table--can-scroll-right`,a&&i+r<n-1)}function Lw(e){if(Ww.has(e))return;let t=e.querySelector(Uw),n=e.querySelector(`.markdown-table__expand`),r=e.querySelector(`.markdown-table__copy`);t&&n&&r&&(Ww.add(e),ga(R`${si.maximize}<span>${j(`common.expandTable`)}</span>`,n),ga(I.copy,r),t.addEventListener(`scroll`,()=>Iw(e),{passive:!0}))}function Rw(e){let t=Gw.get(e);if(!t){let n=new Set,r=typeof ResizeObserver==`function`?new ResizeObserver(e=>{let t=new Set(e.map(e=>e.target.closest(Hw)));for(let e of t)e&&Iw(e)}):null,i=t=>{for(let i of t)if(e.contains(i)){Lw(i),r||Iw(i);for(let e of i.querySelectorAll(`${Uw}, table`))n.has(e)||(n.add(e),r?.observe(e))}},a=new MutationObserver(t=>{let a=new Set;for(let i of t){let t=i.target instanceof Element?i.target:i.target.parentElement,o=t?.closest(Hw);o&&(t===o||t?.closest(Uw))&&a.add(o);for(let e of i.addedNodes)if(e instanceof HTMLElement){e.matches(Hw)&&a.add(e);for(let t of e.querySelectorAll(Hw))a.add(t)}for(let t of i.removedNodes){if(!(t instanceof HTMLElement)||e.contains(t))continue;let i=[t,...t.querySelectorAll(`${Uw}, table`)];for(let e of i)n.delete(e)&&r?.unobserve(e)}}i(a)});t={release:()=>{a.disconnect(),r?.disconnect()}},Gw.set(e,t),i(e.querySelectorAll(Hw)),a.observe(e,{childList:!0,subtree:!0,characterData:!0})}return t}function zw(e){let t=Gw.get(e);Gw.delete(e),t?.release(),t?.closeDialog?.()}async function Bw(e,t,n){let r=Gw.get(n)??Rw(n);if(r.closeDialog)return;let i,a=()=>{r.closeDialog===a&&delete r.closeDialog,i?.remove()};r.closeDialog=a;try{if(await T(()=>import(`./modal-dialog-BJJDzs1S.js`),__vite__mapDeps([37,7]),import.meta.url),r.closeDialog!==a||!n.isConnected||!t.isConnected)return;i=document.createElement(`openclaw-modal-dialog`),i.className=`markdown-table-modal`,i.label=j(`common.expandedTable`),i.setReturnFocusTarget(t);let o=e=>{let t=Zt(e);!t||e instanceof KeyboardEvent&&e.key!==`Enter`&&e.key!==` `||setTimeout(()=>{(e.type===`click`||e.defaultPrevented||e instanceof MouseEvent&&e.button===1&&t.hasAttribute(`href`))&&a()},0)};i.addEventListener(`modal-cancel`,a),ga(R`
        <div
          class="markdown-table-dialog chat-text"
          dir=${getComputedStyle(e).direction}
          @click=${o}
          @auxclick=${o}
          @keydown=${o}
        >
          <button
            type="button"
            class="markdown-table-dialog__close"
            aria-label=${j(`common.closeTable`)}
            autofocus
            @click=${a}
          >
            ${I.x}
          </button>
          ${e.cloneNode(!0)}
        </div>
      `,i),n.append(i)}finally{i||a()}}function Vw(e){let t=e.target;if(!(t instanceof Element))return;let n=t.closest(Hw);if(!n)return;Lw(n);let r=n.querySelector(`table`);if(!r)return;let i=t.closest(`.markdown-table__expand`);if(i&&e.currentTarget instanceof HTMLElement){Bw(r,i,e.currentTarget);return}let a=t.closest(`.markdown-table__copy`);if(a){let e=Fw(r),t=(qw.get(a)??0)+1;qw.set(a,t);let i=()=>a.isConnected&&r.isConnected&&qw.get(a)===t&&n.querySelector(`table`)===r&&Fw(r)===e;un(e,i).then(e=>{if(!i())return;a.setAttribute(`aria-label`,j(e?`common.copied`:`common.copyFailed`)),ga(e?I.check:I.copy,a),clearTimeout(Kw.get(a));let t=setTimeout(()=>{ga(I.copy,a),a.setAttribute(`aria-label`,j(`common.copyTable`)),Kw.delete(a)},e?1500:2e3);Kw.set(a,t)})}}var Hw,Uw,Ww,Gw,Kw,qw;function Jw(){return(Jw=e((()=>{B(),F(),Ln(),kr(),L(),OS(),n(),Hw=`.chat-text .markdown-table[data-table-interactions]`,Uw=`.markdown-table__viewport`,Ww=new WeakSet,Gw=new WeakMap,Kw=new WeakMap,qw=new WeakMap})))()}function Yw(e,t,n,r){let i=e[t];if(!i)return``;let a=i.content;return n?oT.test(a.trim())?a:``:/^<br\s*\/?>$/iu.test(a.trim())?r?`<br>
`:`<br>`:J(a)+(r?`
`:``)}function Xw(e,t){let n=``;for(let r=t+1;r<e.length;r++){let t=e[r];if(!t||t.type===`link_close`)break;(t.type===`text`||t.type===`code_inline`)&&(n+=t.content)}return n.trim()}function Zw(e){let t=URL.parse(e);return t?.protocol===`https:`||t?.protocol===`http:`?t:null}function Qw(e){let t=e.pathname.split(`/`).filter(Boolean);if(t.length===2)return t.map(e=>Sd(e)??e).join(`/`);if((t[2]===`blob`||t[2]===`tree`)&&t.length>4){let e=Sd(t.at(-1)??``);if(e)return t[2]===`tree`?`${t.slice(0,2).map(e=>Sd(e)??e).join(`/`)}/…/${e}`:e}return[`github.com`,...t.map(e=>Sd(e)??e)].join(`/`)}function $w(){let e=new bl({html:!0,breaks:!0,linkify:!0});e.use(tl);let t=e.renderer.rules.code_inline;return e.enable(`strikethrough`),MS(e),iw(e),Pw(e),e.linkify.set({fuzzyLink:!1}),e.linkify.add(`www`,{validate(e,t){let n=e.slice(t),r=n.match(/^\.(?:[a-zA-Z0-9-]+\.?)+[^\s<\u2E80-\u2FFF\u3000-\u303F\u3040-\u309F\u30A0-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uAC00-\uD7AF\uF900-\uFAFF\uFF01-\uFF60]*/);if(!r)return 0;let i=r[0].length,a={")":`(`,"]":`[`,"}":`{`,'"':`"`,"'":`'`},o={};for(let[e,t]of Object.entries(a)){o[e]=0;for(let r=0;r<i;r++){let i=n.charAt(r);t===e?i===t&&(o[e]=+(o[e]===0)):i===t?o[e]=(o[e]??0)+1:i===e&&(o[e]=(o[e]??0)-1)}}for(;i>0;){let e=n.charAt(i-1);if(/[?!.,:*_~]/.test(e)){i--;continue}if(e===`;`){let e=i-2;for(;e>=0&&/[a-zA-Z0-9]/.test(n.charAt(e));)e--;if(e>=0&&n.charAt(e)===`&`&&e<i-2){i=e;continue}break}let t=a[e];if(t!==void 0){if(t===e){if((o[e]??0)!==0){o[e]=0,i--;continue}}else if((o[e]??0)<0){o[e]=(o[e]??0)+1,i--;continue}}break}return i},normalize(e){e.url=`http://`+e.url}}),e.validateLink=()=>!0,e.core.ruler.after(`linkify`,`disallowed-link-schemes`,e=>{for(let t of e.tokens){let e=t.children;if(t.type!==`inline`||!e)continue;let n=!1;for(let t of e)t.type===`link_open`&&eT.test(String(t.attrGet(`href`)??``))?(t.hidden=!0,n=!0):t.type===`link_close`&&n&&(t.hidden=!0,n=!1)}}),e.core.ruler.after(`linkify`,`linkify-cjk-trim`,e=>{for(let t of e.tokens){if(t.type!==`inline`||!t.children)continue;let n=t.children;for(let t=n.length-1;t>=0;t--){let r=n[t];if(!r||r.type!==`link_open`||r.markup!==`linkify`)continue;let i=n[t+1];if(!i||i.type!==`text`)continue;let a=i.content,o=a.length;for(;o>0&&tT.test(a.charAt(o-1));)o--;if(o<=0||o===a.length)continue;let s=a.slice(0,o),c=a.slice(o),l=String(r.attrGet(`href`)??``),u=l.indexOf(a),d=u>0?l.slice(0,u):``;r.attrSet(`href`,d+s),i.content=s;for(let r=t+1;r<n.length;r++)if(n[r]?.type===`link_close`){let t=new e.Token(`text`,``,0);t.content=c,n.splice(r+1,0,t);break}}}}),e.core.ruler.after(`linkify-cjk-trim`,`file-links`,e=>{if(e.env?.fileLinks!==!0)return;let t=[];for(let n of e.tokens){if(n.type!==`inline`||!n.children)continue;let r=n.children,i=0;for(let n=0;n<r.length;n++){let a=r[n];if(a){if(a.type===`link_open`){let e=String(a.attrGet(`href`)??``);if(e&&!a.attrGet(`data-session-href`)){let t=e;try{t=decodeURIComponent(e)}catch{}if(!t.includes(`://`)){let e=_C(t,{authored:!0})??(vC(t)?hC(t.trim()):null);if(e){a.attrs=a.attrs?.filter(([e])=>e!==`href`)??null,a.attrJoin(`class`,`markdown-file-link`),a.attrSet(`role`,`button`),a.attrSet(`tabindex`,`0`),a.attrSet(`data-file-path`,e.path),a.attrSet(`data-file-kind`,RC(e.path)),e.line!==null&&a.attrSet(`data-file-line`,String(e.line));let i=t.trim();Xw(r,n)!==i&&a.attrSet(`title`,i)}}}i+=1;continue}if(a.type===`link_close`){i=Math.max(0,i-1);continue}if(!(i>0)){if(a.type===`code_inline`){let e=_C(a.content);if(e){let n=a.content.trim(),r={path:e.path,line:e.line,title:null};a.meta={...a.meta,fileLink:r},t.push({path:e.path,reference:n,applyLabel:e=>{a.content=e,r.title=e===n?null:n}})}continue}a.type===`text`&&(DC.lastIndex=0,n=mw(e,r,n,DC,n=>{let r=n.index,i=n[0],o=r+i.length;if(!pw(a.content,r,o))return null;let s=_C(i);if(!s)return null;let c=new e.Token(`link_open`,`a`,1);c.markup=`file-link`,c.attrSet(`class`,`markdown-file-link`),c.attrSet(`role`,`button`),c.attrSet(`tabindex`,`0`),c.attrSet(`data-file-path`,s.path),c.attrSet(`data-file-kind`,RC(s.path)),s.line!==null&&c.attrSet(`data-file-line`,String(s.line));let l=new e.Token(`text`,``,0);l.content=i;let u=new e.Token(`link_close`,`a`,-1);return u.markup=`file-link`,t.push({path:s.path,reference:i,applyLabel:e=>{l.content=e,e!==i&&c.attrSet(`title`,i)}}),[c,l,u]}))}}}}let n=VC(t.map(e=>e.path));for(let e of t){let t=n.get(e.path)??e.path;e.applyLabel(t+e.reference.slice(e.path.length))}}),Ew(e),e.core.ruler.after(`linkify`,`web-link-classes`,e=>{for(let t of e.tokens){if(t.type!==`inline`||!t.children)continue;let n=t.children,r=0;for(let t=0;t<n.length;t++){let i=n[t];if(i?.type===`link_close`){r=Math.max(0,r-1);continue}if(i?.type===`code_inline`&&r===0){let r=i.content,a=aT.test(r)?null:Zw(r);if(!a||!er(a.hostname))continue;let o=new e.Token(`text`,``,0);o.content=r,i=new e.Token(`link_open`,`a`,1),i.markup=iT,i.attrSet(`href`,o.content),n.splice(t,1,i,o,new e.Token(`link_close`,`a`,-1))}if(i?.type!==`link_open`)continue;r+=1;let a=String(i.attrGet(`href`)??``),o=a?Zw(a):null;if(!o)continue;let s=i.markup===`linkify`||i.markup===`autolink`||i.markup===iT,c=o.hostname.toLowerCase(),l=er(c),u=l?Td(a):null;s&&i.attrJoin(`class`,rT);let d=null;for(let e=t+1;e<n.length;e++){let t=n[e];if(!t||t.type===`link_close`)break;if((t.type===`text`||t.type===`code_inline`)&&t.content.trim()!==``){d=t;break}}if(l&&d){i.attrJoin(`class`,nT);let e=u??wd(o),r=d.type===`text`&&n[t+1]===d&&n[t+2]?.type===`link_close`?d.content:null,c=e&&(s||r===`#${e.number}`||r===`${e.owner}/${e.repo}#${e.number}`);c&&(i.attrJoin(`class`,`markdown-github-item`),i.attrSet(`data-github-kind`,e.kind)),s&&(d.content=e?`#${e.number}`:Qw(o)),!u&&(s||c)&&i.attrSet(`title`,a)}if(!l&&d&&e.env.linkFavicons){let r=new e.Token(`link_favicon`,`img`,0);r.meta={hostname:c},n.splice(t+1,0,r),t+=1}}}}),yw(e),e.core.ruler.after(`inline`,`task-lists`,e=>{for(let[t,n]of e.tokens.entries()){let r=e.tokens[t-2],i=n.children,a=i?.[0];if(n.type!==`inline`||e.tokens[t-1]?.type!==`paragraph_open`||r?.type!==`list_item_open`||!/^\[[ xX]\] /.test(n.content)||!i||!a)continue;let o=new e.Token(`html_inline`,``,0);o.content=`<input class="task-list-item-checkbox"${n.content[1]===` `?``:` checked=""`} disabled="" type="checkbox">`,o.meta={taskListPlugin:!0},a.content=a.content.slice(3),i.unshift(o),n.content=n.content.slice(3),r.attrSet(`class`,`task-list-item`);for(let n=t-3;n>=0;n--){let t=e.tokens[n];if(t?.level===r.level-1){t.attrSet(`class`,`contains-task-list`);break}}}}),e.renderer.rules.html_block=(e,t,n,r)=>Yw(e,t,r?.progressBars===!0,!0),e.renderer.rules.html_inline=(e,t,n,r)=>{let i=e[t];return i?.meta?.taskListPlugin===!0?i.content:Yw(e,t,r?.progressBars===!0,!1)},e.renderer.rules.link_favicon=(e,t)=>{let n=e[t]?.meta?.hostname;return typeof n==`string`?`<img class="markdown-link-favicon" data-link-favicon-host="${J(n)}" alt="" role="presentation">`:``},e.renderer.rules.code_inline=(e,n,r,i,a)=>{let o=t(e,n,r,i,a),s=e[n]?.meta?.fileLink;if(s){let e=s.line===null?``:` data-file-line="${J(String(s.line))}"`,t=s.title===null?``:` title="${J(s.title)}"`;return`<a class="markdown-file-link" role="button" tabindex="0" data-file-path="${J(s.path)}" data-file-kind="${RC(s.path)}"${e}${t}>${o}</a>`}return o},e.renderer.rules.fence=(e,t,n,r)=>{let i=e[t];if(!i)return``;let a=i.info.trim().split(/\s+/)[0]||``,o=r?.streamingOpenFence===!0&&e.findLastIndex(({nesting:e})=>e!==-1)===t,s=rC(i.content,a,r,{copyText:aC(i.content),highlight:!o});return a.toLowerCase()===`mermaid`&&!o?`<div class="markdown-mermaid">${s}</div>`:s},e.renderer.rules.code_block=(e,t,n,r)=>{let i=e[t]?.content;return i===void 0?``:rC(i,``,r,{copyText:aC(i)})},IC(e),e}var eT,tT,nT,rT,iT,aT,oT;function sT(){return(sT=e((()=>{xl(),$c(),GC(),Ed(),IS(),dC(),fw(),AC(),Sw(),LC(),Mw(),Jw(),OS(),eT=/^(?!(?:https?|mailto):)[a-z][a-z0-9+.-]*:/i,tT=RegExp(`[\\u2E80-\\u2FFF\\u3000-\\u303F\\u3040-\\u309F\\u30A0-\\u30FF\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uAC00-\\uD7AF\\uF900-\\uFAFF\\uFF01-\\uFF60]`),nT=`markdown-github-link`,rT=`markdown-bare-url`,iT=`code-span-url`,aT=/[\s\p{Cc}]/u,oT=/^(?:<progress(?:\s[^<>]*)?>\s*(?:<\/progress>)?|<\/progress>)$/iu})))()}function cT(e,t,n){let r=t+1,i=e[r]===`/`;i&&(r+=1);let a=uT.find(t=>{let n=r+t.name.length;return t.pattern.test(e.slice(r,n))&&!dT.test(e[n]??``)});if(!a)return null;let o=a.name,s=r+o.length;if(i){for(let t=s;t<n;t+=1)if(!fT.test(e[t]??``))return null}return{start:t,end:n+1,isClosing:i,name:o}}function lT(e){let t=[],n=0,r=e.indexOf(`>`);for(;n<e.length;){let i=e.indexOf(`<`,n);if(i===-1)break;for(;r!==-1&&r<i;)r=e.indexOf(`>`,r+1);if(r===-1)break;let a=cT(e,i,r);a&&t.push(a),n=i+1}let i=new Map;for(let e of t)if(e.isClosing){let t=i.get(e.name)??[];t.push(e),i.set(e.name,t)}let a=``,o=0;for(let n of t){if(n.isClosing||n.start<o)continue;let t=i.get(n.name);if(!t)continue;let r=0,s=t.length;for(;r<s;){let e=r+Math.floor((s-r)/2);t[e].start>=n.end?s=e:r=e+1}let c=t[r];c&&(a+=e.slice(o,n.start),o=c.end)}return o===0?e:a+e.slice(o)}var uT,dT,fT;function pT(){return(pT=e((()=>{uT=[{name:`script`,pattern:/^script$/iu},{name:`style`,pattern:/^style$/iu},{name:`iframe`,pattern:/^iframe$/iu},{name:`object`,pattern:/^object$/iu},{name:`template`,pattern:/^template$/iu}],dT=/^\w$/iu,fT=/^\s$/u})))()}function mT(e){let t=e,n=0;for(let e=0;e<8;e+=1){let e=DT.exec(t)?.[0];if(!e)return{content:t,offset:n};t=t.slice(e.length),n+=e.length}return{content:t,offset:n}}function hT(e){let{content:t,offset:n}=mT(e),r=ET.exec(t),i=r?.[1];return!r||!i||i.startsWith("`")&&t.slice(r[0].length).includes("`")?null:{length:i.length,marker:i.startsWith("`")?"`":`~`,container:n>0}}function gT(e,t){let n=(t.container?mT(e).content:e).replace(/[ \t]+$/u,``),r=ET.exec(n),i=r?.[1];return!r||!i?!1:i.charAt(0)===t.marker&&i.length>=t.length&&n.length===r[0].length}function _T(e,t,n,r,i){let a=mT(e),o=YC(a.content,r,i+a.offset);return o?ZC(o,t,{allowPendingSummary:n}):!1}function vT(e){if(!e)return;let t=NT.get(e)??{};if(NT.delete(e),NT.set(e,t),NT.size>jT){let e=NT.keys().next().value;e!==void 0&&NT.delete(e)}return t}function yT(e,t){return to(e.slice(t)).map(([e,n])=>[e+t,n+t])}function bT(e,t){let n=e.slice(t,e.lastIndexOf(`
`)+1);if(n.includes(`<`))return;let r=PT??=$w(),i=[];r.block.parse(n,r,{},i);let a=i.filter(e=>e.level===0&&e.map),o=a[0],s=a.at(-1);if(!o||!MT.has(o.type)||!s?.map||o===s)return;let c=t;for(let t=0;t<s.map[0];t++)c=e.indexOf(`
`,c)+1;return{boundary:c,containerOffset:MT.has(s.type)?c:null}}function xT(e,t,n){let r,i=0;return(a,o)=>{let s=mT(a);!r&&s.content.trimStart().startsWith(`<`)&&nw(s.content,{context:null},n(),o+s.offset)&&(r=rw(e.slice(t),PT??=$w()).map(([e,n])=>[e+t,n+t]));let c=r?.[i];for(;c&&c[1]<=o;)i+=1,c=r?.[i];return c&&c[0]<=o&&o<c[1]?c:void 0}}function ST(e,t={boundary:0,containerOffset:null,hasLinkReferenceDefinition:!1,index:0,lastLiteralOffset:0,lineMode:null,openFence:null}){let{boundary:n,containerOffset:r,hasLinkReferenceDefinition:i,index:a,lastLiteralOffset:o}=t,s=t.lineMode,c=t.openFence,l=[],u=t.openFence?0:Math.min(t.lastLiteralOffset,t.containerOffset??t.lastLiteralOffset),d=e.slice(u),f=/ {4}|\t/u.test(d)?Ya(d).map(e=>({start:e.start+u,end:e.end+u,block:e.block})):[],p=f.length?f.map(({start:e,end:t})=>[e,t]):void 0,m=xT(e,Math.min(t.boundary,t.containerOffset??t.boundary),()=>p??=yT(e,r??n)),h=t,g=!1;for(;a<e.length;){let t=e.indexOf(`
`,a),u=t===-1?e.length:t+1;if(s){a=u,s=t===-1?s:null,h={boundary:n,containerOffset:r,hasLinkReferenceDefinition:i,index:a,lastLiteralOffset:o,lineMode:s,openFence:c};continue}let d=e.slice(a,t===-1?u:t),f=c,_=!1;if(c)gT(d,c)&&(c=null,o=u,l.length===0&&(n=u));else{let s=mT(d),f=m(d,a);if(_=f!==void 0,r===null&&OT.test(d)&&(!f||f[0]===a)&&(r=n),_){o=u;let e=s.content.trimStart();g=t===-1&&e.length>0&&!e.startsWith(`<`)}else{let t=hT(d);t?(c=t,o=u):(AT.test(s.content)&&_T(d,l,!1,p??=yT(e,r??n),a),l.length===0&&(kT.test(s.content)&&(i=!0),/^[ \t]*$/u.test(d)&&(n=u)))}}a=u,l.length===0&&!_&&(t!==-1||CT(d,f))&&(s=t===-1?f?`fence`:`plain`:null,h={boundary:n,containerOffset:r,hasLinkReferenceDefinition:i,index:a,lastLiteralOffset:o,lineMode:s,openFence:c})}if(r!==null&&!i){let t=bT(e,r);t&&(r=t.containerOffset,n=Math.max(n,t.boundary),h={...h,containerOffset:r,boundary:Math.max(h.boundary,t.boundary)})}i?n=0:r!==null&&(n=Math.min(n,r));let _=o;for(let e of f)e.block&&(e.start<n&&n<e.end&&(n=e.start),_=Math.max(_,e.end));return{cursor:h,rawTail:g,result:{boundary:n,tailRepairStart:c?null:Math.max(n,_)}}}function CT(e,t){let n=mT(e).content.charAt(0);return n?t?n!==t.marker:!/[\s`~<[\]*+\-\d>]/u.test(n):!1}function wT(e,t,n=e.length){let r=vT(t);if(!r)return ST(e).result;let i=e.slice(0,n),a=r.split,o=a&&i.startsWith(a.markdown),s=o&&a.rawTail&&!/[\r\n]/u.test(i.slice(a.markdown.length))?{cursor:a.cursor,rawTail:!0,result:{boundary:a.result.boundary,tailRepairStart:i.length}}:ST(i,o?a.cursor:void 0);return r.split={...s,markdown:i},n===e.length?s.result:ST(e,s.cursor).result}function TT(e,t){if(t===e.length)return e;let n=e.slice(0,t)+nl(e.slice(t),FT);if(!n.includes(`<`))return n;let r=[],i=to(n),a=xT(e.slice(0,t),0,()=>i),o=null,s=!1,c=0;for(;c<n.length;){let e=n.indexOf(`
`,c),t=e===-1?n.length:e+1,l=n.slice(c,e===-1?t:e);o?gT(l,o)&&(o=null):a(l,c)||(o=hT(l),o||(s=_T(l,r,e===-1,i,c))),c=t}return s?`${n}</summary>`:n}var ET,DT,OT,kT,AT,jT,MT,NT,PT,FT;function IT(){return(IT=e((()=>{el(),Ga(),fw(),sT(),ET=/^[ \t]{0,3}(`{3,}|~{3,})/,DT=/^[ \t]{0,3}(?:(?:>\s?)|(?:(?:[-+*]|\d{1,9}[.)])[ \t]+))/,OT=/^[ \t]{0,3}(?:[-+*]|\d{1,9}[.)])[ \t]+/u,kT=/^[ \t]*\[/u,AT=/^[ \t]*<\/?(?:details|summary)(?=[\s>])/iu,jT=8,MT=new Set([`bullet_list_open`,`ordered_list_open`,`blockquote_open`]),NT=new Map,FT={katex:!1,linkMode:`text-only`}})))()}function LT(e){let t=gE.get(e);return t===void 0?null:(gE.delete(e),gE.set(e,t),t)}function RT(e,t){if(gE.set(e,t),gE.size<=lE)return;let n=gE.keys().next().value;n&&gE.delete(n)}function zT(e,t){let n=cl(e),r=vT(t),i=r?.input,a;if(i&&n.startsWith(i.source)){let e=n.slice(i.source.length),t=wS(e);a=i.source.endsWith(`\r`)&&e.startsWith(`
`)?`${i.normalized.slice(0,-1)}${t}`:`${i.normalized}${t}`}else a=wS(n);return r&&(r.input=n.length<=cE?{source:n,normalized:a}:void 0),a}function BT(e){if(Lr(e)!==null)return!0;let t=VT();return!t||e!==t&&!e.startsWith(`${t}/`)?!1:Lr(e,t)!==null}function VT(){return typeof window>`u`?``:Ar(window.location.pathname)[0]}function HT(e){return e.split(`/`).filter(Boolean)}function UT(e){let t=HT(e),n=HT(VT());return n.length===0||n.some((e,n)=>t[n]!==e)?t:t.slice(n.length)}function WT(e,t){return t.every((t,n)=>e[n]===t)}function GT(e){if(e.includes(`__openclaw__`)||e.includes(`__openclaw`))return!0;let t=e[0];return!t||mE.has(t)?!0:hE.some(t=>WT(e,t))}function KT(e,t){if(pE.has(e))return!0;let n=t[0];return n?fE.has(n):!1}function qT(e){let t=e.trim();if(!t.startsWith(`/`)||t.startsWith(`//`))return e;try{let n=new URL(t,dE);if(n.origin!==dE)return e;let r=n.pathname.replace(/\/+$/,``)||`/`;if(BT(r))return e;let i=HT(r);return GT(UT(r))?e:KT(r,i)?n.href:e}catch{return e}}function JT(e){if(e.nodeType===Node.TEXT_NODE)return!!e.textContent?.trim();if(!(e instanceof Element)||e.getAttribute(`aria-hidden`)?.trim().toLowerCase()===`true`)return!1;if(e.matches(`img[alt]`))return!!e.getAttribute(`alt`)?.trim();if(e.matches(`progress`)){let t=e.getAttribute(`aria-valuetext`);return t===null?e.hasAttribute(`value`)||e.hasAttribute(`aria-valuenow`)||!!(e.getAttribute(`aria-label`)?.trim()||e.getAttribute(`title`)?.trim()):!!t.trim()}return[...e.childNodes].some(JT)}function YT(e=aE){let t=sE.get(e);if(t)return t;let n=yl(window);return n.setConfig(e),n.addHook(`afterSanitizeAttributes`,e=>{if(!(e instanceof HTMLAnchorElement))return;let t=e.getAttribute(`href`);if(!t)return;if(vC(t)){e.removeAttribute(`href`);return}let n=qT(t);n!==t&&e.setAttribute(`href`,n);try{let t=new URL(n,document.baseURI);if(t.protocol!==`http:`&&t.protocol!==`https:`&&t.protocol!==`mailto:`){e.removeAttribute(`href`);return}if(Td(t.href))for(let t of[e,...e.querySelectorAll(`[title]`)]){let e=t.getAttribute(`title`),n=!t.matches(`progress`)&&JT(t);e&&!n&&!t.getAttribute(`aria-label`)?.trim()&&t.setAttribute(`aria-label`,e),t.removeAttribute(`title`)}if(t.origin===window.location.origin&&BT(t.pathname)){e.removeAttribute(`rel`),e.removeAttribute(`target`);return}}catch{}e.setAttribute(`rel`,`noreferrer noopener`),e.setAttribute(`target`,`_blank`)}),sE.set(e,n),n}function XT(e){let t=e.truncated?`\n\n${j(`chat.markdown.truncated`,{total:String(e.total),shown:String(e.text.length)})}`:``;return`${e.text}${t}`}function ZT(e,t,n){let r=YT(t.progressBars?oE:aE),i=t.mode===`document`,a=i?{text:e,truncated:!1,total:e.length}:Be(e,cE),o=t.progressBars?lT(XT(a)):XT(a);if(n??TS(a.text))return r.sanitize(rC(o,``,t,{blockArt:!0}));if(!i&&a.text.length>4e4)return r.sanitize(tE(o,t));let s;try{s=_E.render(o,t)}catch(e){console.warn(`[markdown] md.render failed, falling back to plain text:`,e),s=tE(o,t)}return r.sanitize(s)}function QT(e,t){return YT().sanitize(rC(e.text,`json`,LS(t),{json:e}).replaceAll(`\r`,`&#13;`)).replaceAll(`\r`,`&#13;`)}function $T(e,t={}){let n=LS(t),r=n.mode===`document`||e.length<=4e4?PC(e,n.humanMentions,_E.utils.normalizeReference):{source:e,tokens:[]};n.humanMentionTokens=r.tokens;let i=wS(cl(r.source));if(!i.trim())return``;if(i.length>uE)return ZT(i,n);let a=`${eE(n)}\0${i}`,o=LT(a);if(o!==null)return o;let s=ZT(i,n);return RT(a,s),s}function eE(e){return`${Dn.getLocale()}\0${e.assistantTranscriptRoleHeaders}\0${e.codeBlockChrome}\0${e.codeBlockInteraction}\0${e.fileLinks}\0${JSON.stringify(e.githubRepo?[e.githubRepo.owner,e.githubRepo.repo]:null)}\0${MC(e.githubRepositories,e.githubRepo)}\0${e.interactiveImages}\0${e.linkFavicons}\0${e.progressBars}\0${e.mode}\0${e.remoteImages}\0${e.sessionLinks}\0${e.tableInteractions}\0${JSON.stringify(e.humanMentionTokens??[])}`}function tE(e,t){return PS(FC(wS(e),t.humanMentionTokens),t.assistantTranscriptRoleHeaders)}function nE(e,t={},n){let r=LS(t);if(r.humanMentions.length)return[$T(e,t),``];let i=zT(e,n);if(TS(i))return[``,ZT(i,r)];if(!i.trim())return[``,``];let a=Be(i,cE),o=XT(a),{boundary:s,tailRepairStart:c}=wT(o,n,a.text.length),l=o.slice(0,s),u=o.slice(s),d=vT(n),f=d?.rendered,p=eE(r),m=f?.options===p&&l.startsWith(f.markdown)&&(f.markdown===l||f.markdown.endsWith(`
`)&&!/^(?: {4}| {0,3}[\t>])/mu.test(l)&&!/^ {0,3}(?:[-+*]|\d{1,9}[.)])$/mu.test(l)&&!l.includes(`<`)&&!TS(l)&&!f.html.includes(`class="markdown-block-art"`)&&(r.mode===`document`||s<=4e4)),h=m?f.html:``,g=l.slice(m?f.markdown.length:0);if(g){let e=ZT(g,{...r});h=h.length>0&&TS(g)||r.fileLinks&&h.includes(`class="markdown-file-link"`)&&e.includes(`class="markdown-file-link"`)?ZT(l,{...r}):h+e}if(d&&(d.rendered={options:p,markdown:l,html:h}),!u.trim())return[h,``];let _=c===null?ZT(u,{...r,streamingOpenFence:!0},!1):ZT(TT(u,c-s),r,!1);return[h,_]}var rE,iE,aE,oE,sE,cE,lE,uE,dE,fE,pE,mE,hE,gE,_E;function vE(){return(vE=e((()=>{Al(),be(),sl(),ii(),gr(),F(),_t(),Ed(),IS(),dC(),AC(),LC(),sT(),pT(),RS(),IT(),OS(),rE=`a.b.blockquote.br.button.code.del.details.div.em.h1.h2.h3.h4.hr.i.input.li.ol.openclaw-person-reference.p.pre.s.span.strong.summary.table.tbody.td.th.thead.tr.ul.img`.split(`.`),iE=`checked.profile-id.label.class.disabled.href.open.rel.target.tabindex.title.start.src.alt.data-code.data-code-encoding.data-file-kind.data-file-line.data-file-path.data-link-favicon-host.data-session-key.data-session-href.data-table-interactions.type.aria-expanded.aria-label.aria-pressed.role`.split(`.`),aE={ALLOWED_TAGS:rE,ALLOWED_ATTR:iE,ADD_DATA_URI_TAGS:[`img`]},oE={...aE,ALLOWED_TAGS:[...rE,`progress`],ALLOWED_ATTR:[...iE,`value`,`max`]},sE=new Map,cE=14e4,lE=500,uE=5e4,dE=`https://docs.openclaw.ai`,fE=new Set(`agent-runtime-architecture.announcements.auth-credential-semantics.automation.brave-search.channels.ci.clawhub.cli.concepts.date-time.debug.diagnostics.gateway.help.index.install.logging.maturity-scorecard.network.nodes.openclaw-agent-runtime.perplexity.plan.platforms.plugins.prose.providers.refactor.reference.security.specs.start.tools.tts.vps.web`.split(`.`)),pE=new Set(`/AGENTS.default,/RELEASING,/agent,/agent-loop,/agent-send,/agent-workspace,/android,/anthropic,/architecture,/audio,/auth-monitoring,/azure,/background-process,/bash,/bonjour,/browser,/browser-linux-troubleshooting,/bun,/camera,/clawd,/clawdhub,/compaction,/configuration,/context,/context-engine,/control-ui,/cron,/cron-jobs,/cron-vs-heartbeat,/dashboard,/device-models,/discord,/discovery,/docker,/doctor,/duckduckgo-search,/elevated,/exa-search,/experiments/plans/cron-add-hardening,/experiments/plans/group-policy-hardening,/faq,/gateway-lock,/gcp,/gemini-search,/getting-started,/glm,/gmail-pubsub,/grammy,/grok-search,/group-messages,/groups,/health,/heartbeat,/hubs,/images,/imessage,/ios,/kimi-search,/line,/linux,/location,/location-command,/lore,/mac/bun,/mac/canvas,/mac/child-process,/mac/dev-setup,/mac/health,/mac/icon,/mac/logging,/mac/menu-bar,/mac/peekaboo,/mac/permissions,/mac/release,/mac/remote,/mac/signing,/mac/skills,/mac/voice-overlay,/mac/voicewake,/mac/webchat,/mac/xpc,/macos,/mattermost,/mcp,/message,/messages,/minimax,/mistral,/model,/model-failover,/models,/moonshot,/multi-agent,/nix,/northflank,/oauth,/onboarding,/openai,/opencode,/opencode-go,/openrouter,/pairing,/pi,/pi-dev,/plugin,/podman,/poll,/presence,/provider-routing,/qianfan,/queue,/quickstart,/railway,/remote,/remote-gateway-readme,/render,/rpc,/sandbox,/sandboxing,/session,/session-tool,/sessions,/setup,/showcase,/signal,/skill-workshop,/skills,/skills-config,/slack,/slash-commands,/subagents,/tailscale,/talk,/telegram,/templates/AGENTS,/templates/BOOT,/templates/BOOTSTRAP,/templates/HEARTBEAT,/templates/IDENTITY,/templates/SOUL,/templates/TOOLS,/templates/USER,/test,/thinking,/timezone,/troubleshooting,/tui,/typebox,/updating,/voicewake,/web-fetch,/webchat,/webhook,/whatsapp,/windows,/wizard,/xiaomi,/zai`.split(`,`)),mE=new Set([`__openclaw`,`__openclaw__`,`_next`,`api`,`assets`,`avatar`,`manifest.json`,`media`,`res`,`socket.io`,`static`,`ws`,...ue]),hE=[[`plugins`,`diffs`],[`plugins`,`diffs-language-pack`]],gE=new Map,_E=$w()})))()}function yE(e){let t=JSON.parse(e),n=Object.create(null);if(t.avatars&&typeof t.avatars==`object`&&!Array.isArray(t.avatars))for(let[e,r]of Object.entries(t.avatars)){let t=Ae(e),i=Ae(r);t&&i&&(n[t]=i)}let r=Ae(t.avatar),i=Ae(t.agentId);return r&&i&&!Object.hasOwn(n,i)&&(n[i]=r),{avatars:n,legacyAvatar:i?null:r??null}}function bE(e,t){if(Object.keys(t).length===0){e?.removeItem(CE);return}e?.setItem(CE,JSON.stringify({avatars:t}))}function xE(e){let t=Ae(e?.agentId);if(!t)return{avatar:null};let n=D();try{let e=n?.getItem(CE);if(!e)return{avatar:null};let{avatars:r,legacyAvatar:i}=yE(e);return!Object.hasOwn(r,t)&&i&&(r[t]=i,bE(n,r)),{avatar:Object.hasOwn(r,t)?r[t]??null:null,agentId:t}}catch{return{avatar:null}}}async function SE(e,t){let n=await Yt(e,t);if(!n)return null;let r=Ye(n),i=xE({agentId:r.agentId}).avatar;return i?{...r,avatar:i,avatarSource:i,avatarStatus:`data`,avatarReason:null}:r}var CE;function wE(){return(wE=e((()=>{Pt(),Dt(),CE=`openclaw.control.assistant.v1`})))()}function TE(e){if(!e)return[];let t=[{agentId:e.sessionsAgentId,result:e.sessionsResult},...Object.entries(e.sessionResultsByAgent).map(([e,t])=>({agentId:e,result:t}))].flatMap(({agentId:e,result:t})=>e?(t?.sessions??[]).map(t=>({row:t,agentId:A(t.key)?.agentId??t.agentId??e})):[]),n=Object.entries(e.childSessionRowsByParent).flatMap(([t,n])=>{let r=A(t)?.agentId??e.sessionsAgentId;return r&&e.loadedChildSessionKeys.has(t)?n.map(e=>({row:e,agentId:A(e.key)?.agentId??e.agentId??r})):[]});return[...t,...n]}function EE(e,t,n){let r=A(e)?.agentId??b(t);return`${r}\u0000${Gt({agentsList:{defaultId:r,mainKey:n.mainKey,scope:n.globalScope?`global`:`agent`}},A(e)||e.toLowerCase()===`global`?e:`agent:${r}:${e}`)}`}function DE(e){let t=e.filter(e=>e!==void 0);return t.length?Math.min(...t):void 0}function OE(e,t=`compact`){let n=new Date(e);return R`<time
    datetime=${n.toISOString()}
    title=${n.toLocaleString(Dn.getLocale())}
    aria-label=${t===`minute-compact`?z:n.toLocaleString(Dn.getLocale())}
    ><openclaw-elapsed-time
      .startMs=${e}
      .minimumUnit=${t===`minute-compact`?`minute`:`second`}
      .singleUnit=${t===`single-unit`}
    ></openclaw-elapsed-time
  ></time>`}function kE(e){return[...new Set((e.entries??[]).map(e=>{let t=e.deviceFamily?.trim(),n=Uo(e.platform??``,t),r=t===`Mac`?`macOS`:t===`iPad`?`iPadOS`:t,i=Lo({id:e.clientId,mode:e.mode}),a=i?j(`presence.card.${i}`):void 0;return[...new Set([t,n.label===r?void 0:n.label,n.architecture,a].map(e=>e?.trim()).filter(Boolean))].join(` · `)}).filter(Boolean))].toSorted()}function AE(e,t,n){if(!n&&e.length===0)return z;let r=j(n?`presence.card.recentSessions`:`presence.card.viewingNow`);return R`<section class="person-activity-card__section">
    <h3>${r}</h3>
    ${e.length?R`<div class="person-activity-card__sessions">
            ${va(e.slice(0,3),({row:e,agentId:n})=>EE(e.key,n,t),({row:e,agentId:r})=>{let i=lt(e.key,e),a=n?ic(i,`person-activity-card__session-name`,{delay:250,speed:80}):R`<span
                      class="person-activity-card__session-name person-activity-card__session-name--multiline"
                      >${i}</span
                    >`,o=Bn({face:Vn(e),sessionKey:e.key,fallbackAgentId:r,basePath:t.routing.basePath,row:e,mainKey:t.mainKey});return R`<a
                  class="person-activity-card__session session-row-host"
                  href=${o.href}
                  @click=${n=>{k(n)&&(n.preventDefault(),t.openSession(e,r))}}
                  ><span class="person-activity-card__session-icon" aria-hidden="true"
                    >${I.messageSquare}</span
                  >
                  <span class="person-activity-card__session-copy"
                    >${n?Ca(i,a):a}
                    ${e.updatedAt==null?z:R`<span class="person-activity-card__session-age"
                            >${OE(e.updatedAt,`single-unit`)}</span
                          >`}</span
                  >
                </a>`})}
          </div>`:R`<p class="person-activity-card__muted">
            ${j(n?`presence.card.noRecentSessions`:`presence.card.noVisibleSessions`)}
          </p>`}
  </section>`}function jE(e,t=z){let n=Tc(e,j(`presence.card.person`));return R` <header class="person-activity-card__header">
    <openclaw-viewer-avatar
      .user=${e}
      .markAsViewer=${!1}
      variant="footer"
      aria-hidden="true"
    ></openclaw-viewer-avatar>
    <div>
      <h2>${n.name}</h2>
      ${t}
    </div>
  </header>`}function ME(e,t){let n=eh(e.identity?.id,t,Tc(e,j(`presence.card.person`)).name);return R` ${n?R`<footer>
          <a href=${n.href} @click=${n.open}
            >${j(`presence.card.viewActivity`)}<span aria-hidden="true"
              >${I.chevronRight}</span
            ></a
          >
        </footer>`:z}`}function NE(e){let{user:t}=e,n=Tc(t,j(`presence.card.person`)),r=t.entries!==void 0,i=t.entries?.length===0,a=t.entries??[],o=DE(a.map(e=>e.onlineSince)),s=jo(t),c=ho(t),l=kE(t),u=[...new Set(a.flatMap(e=>e.timeZone?.trim()?[e.timeZone.trim()]:[]))].toSorted(),d=new Set(t.watchedSessions.map(t=>EE(t,e.watchAgentId,e))),f=new Map;for(let t of TE(e.sessionData)){let n=EE(t.row.key,t.agentId,e);f.has(n)||f.set(n,t)}let p=[...f.values()].toSorted((t,n)=>(n.row.updatedAt??0)-(t.row.updatedAt??0)||EE(t.row.key,t.agentId,e).localeCompare(EE(n.row.key,n.agentId,e))),m=p.filter(({row:t,agentId:n})=>d.has(EE(t.key,n,e))),h=p.filter(({row:n,agentId:r})=>!d.has(EE(n.key,r,e))&&[n.owner?.actor,n.createdActor].some(e=>$o(t,e?.identity)));return R`<div class="person-activity-card">
    ${jE(t,r?R` <span
            class="person-activity-card__status ${i?`person-activity-card__status--offline`:`person-activity-card__status--${c}`}"
            ><span aria-hidden="true"></span>${i?j(`presence.offline`):o===void 0?j(`presence.rosterTitle`):R`${j(`presence.card.onlineFor`)} ${OE(o,`minute-compact`)}`}${!i&&c!==`unknown`?R` · ${j(c===`active`?`presence.active`:`presence.idle`)}`:z}</span
          >`:z)}
    ${n.isSharedOwner?R`<p class="person-activity-card__hint person-activity-card__muted">${j(`presence.sharedOwner.hint`)}</p>`:z}
    ${!r||i?z:R`<dl class="person-activity-card__facts">
            ${l.length||u.length?R`<div>
                    <dt>${j(`presence.card.where`)}</dt>
                    <dd>
                      ${l.map(e=>R`<span>${e}</span>`)}${u.map(e=>R`<small>${j(`presence.card.reportedTimeZone`,{zone:e})}</small>`)}
                    </dd>
                  </div>`:z}
            <div>
              <dt>${j(`presence.card.lastActivity`)}</dt>
              <dd>
                ${s===void 0?j(`presence.card.notObserved`):R`<span>${OE(s)} ${j(`presence.card.ago`)}</span>`}
              </dd>
            </div>
          </dl>`}
    ${AE(m,e,!1)}${AE(h,e,!0)}
    ${ME(t,e.routing)}
  </div>`}function PE(){return(PE=e((()=>{B(),Ea(),Oa(),F(),ms(),zo(),Wo(),No(),ln(),Qt(),N(),L(),ih(),tv(),lh()})))()}function FE(e){e.setAttribute(`aria-haspopup`,`dialog`),e.setAttribute(`aria-expanded`,`false`)}function IE(e){e?.removeAttribute(`aria-controls`),e?.removeAttribute(`aria-expanded`),e?.removeAttribute(`aria-haspopup`)}function LE(e,t){let n=document.createElement(`div`);return n.id=e,n.className=t,n.dataset.open=`true`,n.setAttribute(`role`,`dialog`),n}function RE(e){let t=document.body;for(let n=e.anchor;n;n=It(n))if(n.localName===`openclaw-modal-dialog`){t=n;break}t.append(e.card),km(e.card),e.trigger.setAttribute(`aria-controls`,e.card.id),e.trigger.setAttribute(`aria-expanded`,`true`);let n=()=>zE(e.anchor,e.card,e.placement),r=null,i=()=>{r===null&&(r=requestAnimationFrame(()=>{r=null,n()}))},a=t=>{let n=t.composedPath()[0];if(n===window||n===document){i();return}for(let t=e.anchor;t;t=It(t))if(t===n){i();return}};return window.addEventListener(`resize`,i),window.addEventListener(`scroll`,a,!0),e.observeVisualViewport!==!1&&(window.visualViewport?.addEventListener(`resize`,i),window.visualViewport?.addEventListener(`scroll`,i)),n(),()=>{r!==null&&cancelAnimationFrame(r),window.removeEventListener(`resize`,i),window.removeEventListener(`scroll`,a,!0),window.visualViewport?.removeEventListener(`resize`,i),window.visualViewport?.removeEventListener(`scroll`,i)}}function zE(e,t,n){let r=e.getBoundingClientRect(),i=t.offsetWidth,a=t.offsetHeight,o=Math.max(VE,innerWidth-i-VE),s=Math.max(VE,innerHeight-a-VE),c=r.bottom+BE+a+VE<=innerHeight;if(n===`horizontal`){let e=r.right+BE+i+VE<=innerWidth,n=r.left-BE-i>=VE,l=r.top-BE-a>=VE;if(e||n||!c&&!l){let n=e?r.right+BE:r.left-i-BE;t.dataset.side=e?`right`:`left`,t.style.left=`${Math.min(Math.max(VE,n),o)}px`,t.style.top=`${Math.min(Math.max(VE,r.top),s)}px`;return}}let l=c?`bottom`:`top`,u=c?r.bottom+BE:r.top-a-BE;t.dataset.side=l,t.style.left=`${Math.min(Math.max(VE,r.left),o)}px`,t.style.top=`${Math.min(Math.max(VE,u),s)}px`}var BE,VE,HE;function UE(){return(UE=e((()=>{jm(),BE=10,VE=12,HE=class{constructor(e,t=120,n=e){this.close=e,this.closeDelayMs=t,this.dismiss=n,this.card=null,this.pointerInside=!1,this.pointerOverCard=!1,this.focusInside=!1,this.cardFocusInside=!1,this.explicitHold=!1,this.restoringFocus=!1,this.closeTimer=null,this.exitCleanup=null,this.anchor=null,this.openTimer=null,this.placement=`vertical`,this.stopPositioning=null,this.trigger=null,this.triggerAncestors=[],this.presentationObserver=new MutationObserver(()=>{this.checkPresentation()&&this.observePresentation()}),this.unmountContents=null,this.handleCardPointerEnter=e=>{e.currentTarget===this.card&&(this.pointerOverCard=!0,this.clearClose())},this.handleCardFocusIn=e=>{e.currentTarget===this.card&&(this.cardFocusInside=!0,this.clearClose())},this.handleCardFocusOut=e=>{let t=this.card;t&&e.currentTarget===this.card&&(e.relatedTarget instanceof Node&&t.contains(e.relatedTarget)||(this.cardFocusInside=!1,this.scheduleClose()))},this.handleTriggerKeyDown=e=>{if(e.key===`Escape`){this.dismiss();return}if(e.key!==`Tab`||e.shiftKey||e.composedPath()[0]!==this.trigger)return;let t=this.focusables()[0];t&&(e.preventDefault(),t.focus())},this.handleCardKeyDown=e=>{if(e.key!==`Escape`&&e.key!==`Tab`)return;let t=this.focusables(),n=e.shiftKey?t[0]:t.at(-1);if(e.key===`Tab`&&document.activeElement!==n)return;e.preventDefault();let r=this.trigger;this.dismiss(),this.returnFocus(r)}}renderContents(e,t){let n=e.contains(document.activeElement)?document.activeElement:null;if(t(),n&&!e.contains(document.activeElement)){let e=n instanceof HTMLAnchorElement?this.focusables().find(e=>e instanceof HTMLAnchorElement&&e.href===n.href):void 0;e?e.focus({preventScroll:!0}):(this.returnFocus(this.trigger),this.focusInside=document.activeElement===this.trigger)}}returnFocus(e){this.restoringFocus=!0,e?.focus({preventScroll:!0}),this.restoringFocus=!1}get held(){return this.explicitHold||this.pointerInside||this.pointerOverCard||this.focusInside||this.cardFocusInside}schedulePointerExit(e=220){this.pointerInside=!1,this.scheduleClose(e)}focusables(){return[...this.card?.querySelectorAll(`a[href]:not([tabindex="-1"])`)??[]]}scheduleOpen(e,t,n=this.trigger){this.trigger=n,this.observePresentation(),this.openTimer=window.setTimeout(()=>{this.openTimer=null,this.checkPresentation()&&t()},e)}clearClose(){this.closeTimer!==null&&(window.clearTimeout(this.closeTimer),this.closeTimer=null)}scheduleClose(e=this.closeDelayMs){if(this.clearClose(),!this.held){if(!this.card){this.close();return}this.closeTimer=window.setTimeout(()=>{this.closeTimer=null,this.held||this.close()},e)}}markTrigger(e){this.trigger!==e&&IE(this.trigger),this.trigger=e,FE(e),this.observePresentation()}presentationAncestors(){let e=[],t=this.trigger;for(;t;)e.push(t),t=t instanceof Element&&t.assignedSlot?t.assignedSlot:t instanceof ShadowRoot?t.host:t.parentNode;return e}checkPresentation(){return this.trigger&&(!this.trigger.isConnected||this.presentationAncestors().some(e=>e instanceof Element&&(e.hasAttribute(`inert`)||e.hasAttribute(`hidden`)||e.getAttribute(`aria-hidden`)===`true`)))?(this.dismiss(),!1):!0}observePresentation(){let e=this.presentationAncestors();if(!(e.length===this.triggerAncestors.length&&e.every((e,t)=>e===this.triggerAncestors[t]))){this.presentationObserver.disconnect(),this.triggerAncestors=e;for(let t of e)this.presentationObserver.observe(t,{childList:!0,attributes:!0,attributeFilter:[`inert`,`hidden`,`aria-hidden`,`slot`,`name`]})}}mount(e,t,n,r=!0,i){if(!this.checkPresentation()){i?.(),t.remove();return}this.clearCard(),this.anchor=e,this.card=t,t.addEventListener(`pointerenter`,this.handleCardPointerEnter),t.addEventListener(`focusin`,this.handleCardFocusIn),t.addEventListener(`focusout`,this.handleCardFocusOut),this.placement=n,this.unmountContents=i??null,this.stopPositioning=RE({anchor:e,trigger:this.trigger??e,card:t,placement:n,observeVisualViewport:r})}clearCard(e=0){this.stopPositioning?.(),this.stopPositioning=null,this.exitCleanup?.(),this.exitCleanup=null;let t=this.card,n=this.unmountContents;if(this.card=null,this.unmountContents=null,!t)return;if(e<=0||!t.isConnected||globalThis.matchMedia?.(`(prefers-reduced-motion: reduce)`).matches){n?.(),t.remove();return}t.dataset.open=`false`,t.style.pointerEvents=`none`;let r=null,i=()=>{r!==null&&(window.clearTimeout(r),r=null),t.removeEventListener(`transitionend`,a),n?.(),t.remove(),this.exitCleanup===i&&(this.exitCleanup=null)},a=e=>{e.target===t&&e.propertyName===`opacity`&&i()};t.addEventListener(`transitionend`,a),r=window.setTimeout(i,e+50),this.exitCleanup=i}position(){this.anchor&&this.card&&zE(this.anchor,this.card,this.placement)}reset(e=0){this.presentationObserver.disconnect(),this.triggerAncestors=[],this.openTimer!==null&&(window.clearTimeout(this.openTimer),this.openTimer=null),this.clearClose(),this.pointerInside=!1,this.pointerOverCard=!1,this.focusInside=!1,this.cardFocusInside=!1,this.explicitHold=!1,IE(this.trigger),this.clearCard(e),this.anchor=null,this.trigger=null}}})))()}var WE,GE;function KE(){return(KE=e((()=>{te(),B(),H(),S(),Ti(),aa(),F(),No(),as(),Qt(),N(),oc(),M(),il(),Wf(),PE(),Gx(),ih(),UE(),WE=0,GE=class e extends Sn{constructor(...t){super(...t),this.profileId=``,this.label=``,this.context=new ie(this,{context:Zi,subscribe:!0}),this.connection=new Zs(this,{getGateway:()=>this.context.value?.gateway,invalidateRequests:()=>this.close()}),this.portal=new HE(()=>this.close()),this.activityExpiry=al(this,()=>ls(this.activity?.data?.presencePayload).users.filter(e=>$o(e,this.person?.identity)),()=>this.renderCard()),this.close=()=>{e.active.get(this.ownerDocument)===this&&e.active.delete(this.ownerDocument),this.activity?.dispose(),this.activity=void 0,this.activityExpiry.sync(),this.stopRoute?.(),this.stopRoute=void 0,document.removeEventListener(`pointerdown`,this.outside,!0),document.removeEventListener(`focusin`,this.outside,!0),document.removeEventListener(`keydown`,this.escape,!0),this.portal.reset(),this.person=void 0,this.trigger?.setAttribute(`aria-expanded`,`false`),this.trigger?.setAttribute(`aria-haspopup`,`dialog`)},this.outside=e=>{e.composedPath().some(e=>e===this||e===this.portal.card)||this.close()},this.escape=e=>{if(e.key!==`Escape`)return;e.preventDefault(),e.stopPropagation();let t=this.portal.card?.contains(document.activeElement),n=this.trigger;this.close(),t&&this.portal.returnFocus(n)}}static{this.active=new WeakMap}createRenderRoot(){return this.replaceChildren(),super.createRenderRoot()}disconnectedCallback(){this.close(),super.disconnectedCallback()}willUpdate(e){e.has(`profileId`)&&this.close()}updated(){for(let e of this.trigger?.childNodes??[])e.nodeType===Node.TEXT_NODE&&e.textContent&&!e.textContent.trim()&&(e.textContent=``);this.portal.card&&this.renderCard()}get trigger(){return this.querySelector(`button`)}open(){let t=this.trigger;if(!t||!this.profileId||this.portal.card)return;e.active.get(this.ownerDocument)?.close(),e.active.set(this.ownerDocument,this);let n=LE(`openclaw-person-reference-`+ ++WE,`session-progress-hovercard person-activity-hovercard`);this.portal.markTrigger(t),n.addEventListener(`keydown`,this.portal.handleCardKeyDown),n.addEventListener(`pointerleave`,()=>{this.portal.pointerOverCard=!1,this.portal.scheduleClose()}),this.portal.mount(t,n,`vertical`,!0,()=>ga(z,n)),document.addEventListener(`pointerdown`,this.outside,!0),document.addEventListener(`focusin`,this.outside,!0),document.addEventListener(`keydown`,this.escape,!0);let r=this.context.value;this.stopRoute=r?.router.subscribe(()=>this.close()),r&&(this.activity=Hx(r,()=>this.renderCard())),this.person=this.connection.capture()?void 0:null,this.renderCard(),this.loadPerson(n)}async loadPerson(e){let t=this.connection.capture(),n=this.context.value,r=this.profileId;if(!t||!n)return;let a=null;try{let{profiles:e}=await t.client.request(`users.list`,{}),n=new Map(e.map(e=>[e.id,e])),o=new Set,s=n.get(r);for(;s?.mergedInto&&!o.has(s.id);)o.add(s.id),s=n.get(s.mergedInto);s&&!s.mergedInto&&(a={id:s.id,identity:{type:`profile`,id:s.id},name:s.displayName?.trim()||s.githubIdentity?.login||j(`presence.card.person`),avatarUrl:s.hasAvatar?i(s.id,s.updatedAt):void 0,watchedSessions:[]})}catch{}this.portal.card===e&&this.profileId===r&&this.context.value===n&&this.connection.isCurrent(t)&&(this.person=a,this.renderCard())}renderCard(){this.activityExpiry.sync();let e=this.portal.card,t=this.context.value;if(!e)return;e.setAttribute(`aria-label`,j(`presence.card.ariaLabel`,{name:this.person?.name??this.label}));let n=this.activity?.data,r=ls(n?.presencePayload).users.find(e=>$o(e,this.person?.identity)),i=this.person&&{...this.person,name:r?.name??this.person.name,avatarUrl:r?.avatarUrl??this.person.avatarUrl,watchedSessions:r?.watchedSessions??[],entries:r?.entries??(n?.presencePayload?[]:void 0)},a={agentsList:t?.agents.state.agentsList,hello:t?.gateway.snapshot.hello},o=this.connection.capture(),s=t?.router.getState().location;this.portal.renderContents(e,()=>ga(i&&t?NE({user:i,sessionData:n,watchAgentId:Ft(a),mainKey:$t(a),globalScope:bn(a),routing:$m(t,this.close),openSession:(e,n)=>{let r=Vn(e),i=Bn({face:r,sessionKey:e.key,row:e,fallbackAgentId:n,basePath:t.basePath,mainKey:$t(a)});this.close(),ko(this,{agentId:n,face:r,sessionKey:e.key,commit:()=>!o||this.context.value!==t||t.router.getState().location!==s||!this.connection.isCurrent(o)?!1:(cs(t.gateway,i.options.pathname,e.key),t.navigate(r,i.options),vi({selection:t.agentSelection,gateway:t.gateway,sessionKey:e.key,agentId:n}),!0)})}}):R`<div class="person-reference__status" role="status">
              ${this.person===void 0?j(`common.loading`):j(`chat.mentions.unavailable`)}
            </div>`,e)),this.portal.position()}render(){let e=Pf({id:this.profileId,identity:{type:`profile`,id:this.profileId},name:this.label.replace(/^@/u,``)}),t=R`<span
      class=${Vf(`markdown-person-reference__avatar`,e)}
      aria-hidden="true"
      data-initials=${e.fallback.initials}
      >${Lf({view:e,fallbackSelector:`.markdown-person-reference__avatar`,ariaHidden:!0})}</span
    >`,n=this.label.startsWith(`@`)?R`<span class="markdown-person-reference__prefix" aria-hidden="true">@</span
          >${this.label.slice(1)}`:this.label;return R`<button
      type="button"
      class="markdown-person-reference"
      aria-haspopup="dialog"
      aria-expanded="false"
      aria-label=${j(`presence.card.ariaLabel`,{name:this.label})}
      @pointerenter=${e=>{e.pointerType!==`touch`&&(this.portal.pointerInside=!0,this.portal.clearClose(),this.portal.scheduleOpen(250,()=>{this.portal.held&&this.open()}))}}
      @pointerleave=${()=>this.portal.schedulePointerExit()}
      @pointercancel=${this.close}
      @contextmenu=${this.close}
      @focus=${()=>{this.portal.restoringFocus||(this.portal.focusInside=!0,this.portal.clearClose(),this.open())}}
      @blur=${()=>{this.portal.focusInside=!1,this.portal.scheduleClose()}}
      @keydown=${this.portal.handleTriggerKeyDown}
      @click=${()=>{if(this.portal.explicitHold){this.close();return}this.portal.explicitHold=!0,this.open()}}
    >
      ${t}${n}
    </button>`}},w([W({attribute:`profile-id`})],GE.prototype,`profileId`,void 0),w([W()],GE.prototype,`label`,void 0),customElements.get(`openclaw-person-reference`)||customElements.define(`openclaw-person-reference`,GE)})))()}function qE(e,t=``,n,r,i){let a=new URLSearchParams({source:e}),o=n?.trim();return o&&a.set(`mediaTicket`,o),r?.sessionKey&&a.set(`sessionKey`,r.sessionKey),r?.agentId&&a.set(`agentId`,r.agentId),i&&a.set(`filename`,i),`${ce(t)}/__openclaw__/assistant-media?${a.toString()}`}function JE(){return(JE=e((()=>{je()})))()}var YE;function XE(){return(XE=e((()=>{YE=String.raw`function openclawInspectBrowserElement(x, y) {
  const el = document.elementFromPoint(x, y);
  if (!el) return null;
  const rect = el.getBoundingClientRect();
  const label = el.getAttribute("aria-label") || el.getAttribute("alt") || el.getAttribute("title") || "";
  const text = (el.textContent || "").replace(/\s+/g, " ").trim();
  const nameSource = label || text;
  const nameLimit = 120;
  // This serialized page function cannot call imported helpers; back up only when the cap splits a surrogate pair.
  const nameEnd = (nameSource.codePointAt(nameLimit - 1) || 0) > 0xffff ? nameLimit - 1 : nameLimit;
  return {
    tag: el.tagName.toLowerCase(),
    id: el.id || "",
    classes: Array.from(el.classList).slice(0, 6),
    role: el.getAttribute("role") || "",
    name: nameSource.slice(0, nameEnd),
    rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
    focusable: typeof el.tabIndex === "number" && el.tabIndex >= 0,
  };
}`})))()}async function ZE(e,t,n=`open`){let r=C(await e.request(t.sessionScoped?`browser.dashboard.request`:`browser.request`,{...t.sessionScoped?{sessionKey:t.sessionKey,...t.agentId?{agentId:t.agentId}:{},dashboard:{name:t.name,instanceId:t.instanceId}}:{target:`host`},method:n===`stop`?`DELETE`:n===`inspect`?`GET`:`POST`,path:`/dashboard`,...n===`inspect`?{query:t.sessionScoped?{}:t}:{body:{...t.sessionScoped?{}:t,...n===`resume`?{resume:!0}:{}}},timeoutMs:12e4},{timeoutMs:15e4})),i=vd(r?.browserTab);if(typeof r?.sessionKey!=`string`||!r.sessionKey||r.name!==t.name||r.instanceId!==t.instanceId||typeof r.revision!=`number`||!Number.isSafeInteger(r.revision)||typeof r.paused!=`boolean`||typeof r.stopping!=`boolean`||r.stopping&&!r.paused||typeof r.url!=`string`||!r.paused&&!i&&n!==`inspect`)throw Error(j(`browser.dashboardInvalidReply`));return{sessionKey:r.sessionKey,name:t.name,instanceId:t.instanceId,revision:r.revision,paused:r.paused,stopping:r.stopping,url:r.url,...i?{browserTab:i}:{}}}function QE(e){let t={...C(e)};for(let e of[`target`,`targetId`,`node`,`profile`])delete t[e];return t}function $E(e){return e.slice(-64)}function eD(e,t,n=()=>!0,r,i){return{async request(a,o,s){if(!n())throw new DOMException(`Browser request scope ended`,`AbortError`);let c=C(o);if(r?.sessionScoped){let t={method:c?.method,path:c?.path,...c?.timeoutMs===void 0?{}:{timeoutMs:c.timeoutMs},...c?.query?{query:QE(c.query)}:{},...c?.body?{body:QE(c.body)}:{},sessionKey:r.sessionKey,...r.agentId?{agentId:r.agentId}:{},dashboard:{name:r.name,instanceId:r.instanceId}};return s?await e.request(`browser.dashboard.request`,t,s):await e.request(`browser.dashboard.request`,t)}let l=!r&&a===DD?i?.():void 0,u=t||r||l?{...c,...t?{target:t.target,...t.target===`node`?{node:t.node}:{},query:{...C(c?.query),profile:t.profile}}:{},...r?{dashboard:r}:{},...l?{tabScope:{sessionKey:l.sessionKey,...c?.method===`GET`&&c.path===`/tabs`?{referencedTabs:$E(l.referencedTabs)}:{}}}:{}}:o;return s?await e.request(a,u,s):await e.request(a,u)}}}function tD(e,t,n){return n?e.request(DD,t,n):e.request(DD,t)}function nD(e,t){return tD(e,{method:`POST`,path:`/act`,body:t})}function Y(e){return Ee(e)??``}function rD(e){let t=C(e),n=Y(t?.targetId);return n?{kind:`remote`,id:Y(t?.tabId)||n,targetId:n,title:Y(t?.title),url:Y(t?.url),...t?.urlUnavailableReason===`navigation_blocked`||t?.urlUnavailableReason===`navigation_check_failed`?{urlUnavailableReason:t.urlUnavailableReason}:{}}:null}async function iD(e){let t=C(await tD(e,{method:`GET`,path:`/tabs`})),n=Array.isArray(t?.tabs)?t.tabs.flatMap(e=>rD(e)??[]):[];return{running:t?.running===!0,tabs:n}}async function aD(e){await tD(e,{method:`POST`,path:`/start`,body:{}})}async function oD(e,t){return rD(await tD(e,{method:`POST`,path:`/tabs/open`,body:{url:t}}))}async function sD(e,t){await tD(e,{method:`POST`,path:`/tabs/focus`,body:{targetId:t}})}async function cD(e,t){await tD(e,{method:`DELETE`,path:`/tabs/${encodeURIComponent(t)}`})}async function lD(e,t,n,r){let i=C(await e.request(DD,{method:`POST`,path:`/download`,body:{targetId:t,currentDocument:!0,expectedUrl:n,timeoutMs:12e4},timeoutMs:15e4},{signal:r,timeoutMs:15e4})),a=C(i?.download),o=Y(a?.path),s=Y(a?.suggestedFilename);if(!o||!s)throw Error(j(`browser.errors.downloadEmpty`));return{path:o,filename:s}}async function uD(e,t){let n=C(await tD(e,{method:`POST`,path:`/navigate`,body:t}));return{targetId:Y(n?.targetId)||t.targetId||``,url:Y(n?.url)||t.url}}async function dD(e,t,n){let r=C(await tD(e,{method:`POST`,path:`/screencast`,body:t},n)),i=Y(r?.token),a=Y(r?.wsPath);if(!i||!a)throw Error(`browser screencast response is malformed`);return{token:i,wsPath:a,targetId:Y(r?.targetId),url:Y(r?.url)}}function fD(e){let t=C(e),n=C(t?.details);return n?.code===`SCREENCAST_UNSUPPORTED`||C(n?.body)?.code===`SCREENCAST_UNSUPPORTED`||C(t?.body)?.code===`SCREENCAST_UNSUPPORTED`}async function pD(e,t){let n=C(await tD(e,{method:`POST`,path:`/screenshot`,body:{targetId:t,type:`png`}})),r=Y(n?.path);if(!r)throw Error(j(`browser.errors.screenshotPathMissing`));return{path:r,targetId:Y(n?.targetId)||t,url:Y(n?.url)}}async function mD(e,t){await nD(e,{kind:`clickCoords`,targetId:t.targetId,x:Math.max(0,Math.round(t.x)),y:Math.max(0,Math.round(t.y)),...t.doubleClick?{doubleClick:!0}:{}})}async function hD(e,t){await nD(e,{kind:`press`,targetId:t.targetId,key:t.key})}async function gD(e,t){try{await nD(e,{kind:`insertText`,...t})}catch{throw Error(j(`browser.errors.pasteFailed`))}}async function _D(e,t){await nD(e,{kind:`resize`,targetId:t.targetId,width:Math.round(t.width),height:Math.round(t.height)})}async function vD(e,t){return C(await nD(e,{kind:`evaluate`,targetId:t.targetId,fn:t.fn}))?.result??null}function yD(e){return e instanceof Xn&&C(e.details)?.reason===`navigation_blocked`}function bD(e){if(!(e instanceof Error))return!1;let t=e instanceof Xn?C(e.details):null,n=t?.code;return n===void 0&&t?.unrecognizedCode!==!0?e.message.includes(`evaluateEnabled=false`):n===`ACT_EVALUATE_DISABLED`}async function xD(e,t){let n=Math.round(t.deltaX),r=Math.round(t.deltaY);await vD(e,{targetId:t.targetId,fn:`() => { window.scrollBy(${n}, ${r}); return true; }`})}async function SD(e,t){await vD(e,{targetId:t.targetId,fn:`() => { history.go(${t.delta}); return true; }`})}async function CD(e,t){let n=C(await vD(e,{targetId:t,fn:`() => ({ cssWidth: window.innerWidth, cssHeight: window.innerHeight, title: document.title, url: location.href })`})),r=ve(n?.cssWidth),i=ve(n?.cssHeight);return!r||!i||r<=0||i<=0?null:{cssWidth:r,cssHeight:i,title:Y(n?.title),url:Y(n?.url)}}async function wD(e,t){let n=Math.max(0,Math.round(t.x)),r=Math.max(0,Math.round(t.y));return TD(await vD(e,{targetId:t.targetId,fn:`() => { ${YE}\nreturn openclawInspectBrowserElement(${n}, ${r}); }`}))}function TD(e){let t=C(e);if(!t)return null;let n=C(t.rect);return{tag:Y(t.tag),id:Y(t.id),classes:Array.isArray(t.classes)?t.classes.filter(e=>typeof e==`string`):[],role:Y(t.role),name:Y(t.name),rect:{x:ve(n?.x)??0,y:ve(n?.y)??0,width:ve(n?.width)??0,height:ve(n?.height)??0},focusable:t.focusable===!0}}async function ED(e){let t=new Headers({Accept:`image/*`});e.authToken&&t.set(`Authorization`,`Bearer ${e.authToken}`);let n=new AbortController,r=setTimeout(()=>n.abort(new DOMException(j(`browser.errors.screenshotFetchTimedOut`),`TimeoutError`)),OD),i;try{let r=await fetch(qE(e.path,e.resourceBasePath),{method:`GET`,headers:t,credentials:`same-origin`,signal:n.signal});if(!r.ok)throw r.body?.cancel().catch(()=>void 0),Error(j(`browser.errors.screenshotFetchFailed`,{status:String(r.status)}));i=await r.blob()}finally{clearTimeout(r)}return await new Promise((e,t)=>{let n=new FileReader;n.addEventListener(`load`,()=>{typeof n.result==`string`?e(n.result):t(Error(j(`browser.errors.screenshotReadFailed`)))}),n.addEventListener(`error`,()=>t(n.error??Error(j(`browser.errors.screenshotReadFailed`)))),n.readAsDataURL(i)})}var DD,OD;function kD(){return(kD=e((()=>{me(),li(),JE(),F(),ts(),XE(),xd(),yo(),DD=`browser.request`,OD=3e4})))()}function AD(e,t){e instanceof Rc&&e.updateComplete.then(()=>{let n=e.shadowRoot?.querySelector(`[role="tablist"]`);e.isConnected&&n instanceof HTMLElement&&n.setAttribute(`aria-label`,t)})}function jD(){return(jD=e((()=>{Jc(),Dc(),Lc()})))()}function MD(e,t){let n=new URL(e||t,t);if(n.protocol===`ws:`?n.protocol=`http:`:n.protocol===`wss:`&&(n.protocol=`https:`),n.protocol!==`http:`&&n.protocol!==`https:`)throw Error(`Gateway URL is invalid`);return n.origin}function ND(e,t,n,r,i,a=`Sandbox host URL is invalid`){if(!Number.isInteger(t)||t<1||t>65535)throw Error(a);let o;try{o=MD(r,i)}catch{throw Error(a)}let s=n?new URL(n):new URL(o);if(n){if(s.origin!==n.replace(/\/$/u,``)||s.username!==``||s.password!==``)throw Error(a)}else s.port=String(t);s.pathname=`/`,s.search=``,s.hash=``;let c=new URL(e,s);if(s.protocol!==`http:`&&s.protocol!==`https:`||s.origin===new URL(i).origin||s.origin===o||c.origin!==s.origin||c.pathname!==`/mcp-app-sandbox`)throw Error(a);return c.href}function PD(){return(PD=e((()=>{})))()}function FD(e){if(typeof e!=`string`)return null;let t=e.trim(),n=t.startsWith(`/`)||t.startsWith(`!`);return!t||t.length>UD||n?null:t}function ID(e,t){let n=t-WD,r=(qD.get(e)??[]).filter(e=>e>n);if(!qD.has(e)&&qD.size>=KD){let e=qD.keys().next().value;e!==void 0&&qD.delete(e)}return r.length>=GD?(qD.set(e,r),!1):(r.push(t),qD.set(e,r),!0)}function LD(e){if(!e.isConnected||!(typeof e.checkVisibility==`function`?e.checkVisibility():e.getClientRects().length>0))return!1;let t=e.ownerDocument.activeElement;for(;t?.shadowRoot?.activeElement;)t=t.shadowRoot.activeElement;return t===e}function RD(e,t,n,r){let i=FD(t);return!i||!LD(e)||!ID(n,Date.now())||r&&!r(i)?!1:(e.dispatchEvent(new CustomEvent(VD,{bubbles:!0,composed:!0,detail:{text:i}})),!0)}function zD(e,t=!1,n=!1,r=!1){return{openLinks:{},serverTools:{},sandbox:{csp:e??{}},...r?{serverResources:{}}:{},...t?{message:{text:{}}}:{},...n?{updateModelContext:{text:{}}}:{}}}function BD(e,t,n,r,i){return ND(e,t,n,r,i,j(`mcpApp.errors.invalidSandboxUrl`))}var VD,HD,UD,WD,GD,KD,qD;function JD(){return(JD=e((()=>{F(),VD=`openclaw-widget-prompt`,HD=`openclaw-mcp-app-view-expired`,UD=4e3,WD=6e4,GD=10,KD=100,qD=new Map})))()}function YD(e,t){let n=e,r=t;for(;r!==0;)[n,r]=[r,n%r];return n}function XD(e,t,n){let r=We(`${e}:offset`)%n,i=n===1?0:1+We(`${e}:stride`)%(n-1);for(;YD(i,n)!==1;)i=i%(n-1)+1;return(r+t*i)%n}var ZD,QD,$D,eO;function tO(){return(tO=e((()=>{B(),H(),F(),M(),rc(),ZD=[`shelling`,`scuttling`,`clawing`,`pinching`,`molting`,`bubbling`,`tiding`,`reefing`,`cracking`,`sifting`,`brining`,`nautiling`,`krilling`,`barnacling`,`lobstering`,`tidepooling`,`pearling`,`snapping`,`surfacing`],QD=3e4,$D=45e3,eO=class extends Sn{constructor(...e){super(...e),this.startMs=null,this.seed=``,this.polling=new Ro(this,1e3,()=>this.requestUpdate(),!1,`visible`)}connectedCallback(){super.connectedCallback(),this.syncTimer()}updated(){this.syncTimer()}syncTimer(){this.isConnected&&this.startMs!=null&&this.phrases?.length!==0?this.polling.start():this.polling.stop()}shouldUpdate(e){let t=this.currentPhrase(),n=t!==this.phrase;return this.phrase=t,!this.hasUpdated||e.size>0||n}currentPhrase(){if(this.startMs==null||this.phrases?.length===0)return;let e=Date.now()-this.startMs;if(e<QD)return;let t=e-QD,n=Math.floor(t/$D),r=XD(this.seed,n,this.phrases?.length??ZD.length);return this.phrases?this.phrases[r]:j(`chat.progressLabels.${ZD[r]}`)}render(){return this.phrase===void 0?z:R`<span>·</span> ${this.phrase}…`}},w([W({type:Number})],eO.prototype,`startMs`,void 0),w([W()],eO.prototype,`seed`,void 0),w([W({attribute:!1})],eO.prototype,`phrases`,void 0),customElements.get(`openclaw-working-phrase`)||customElements.define(`openclaw-working-phrase`,eO)})))()}var nO,rO,iO,aO;function oO(){return(oO=e((()=>{B(),ba(),sa(),F(),dC(),Jw(),n(),nO=0,rO=`.code-block-wrapper, .markdown-mermaid`,iO=class extends ua{constructor(...e){super(...e),this.scanPending=!1,this.active=!0,this.pendingBlocks=new Set,this.observedNodes=new Set,this.resizeObserver=typeof ResizeObserver>`u`?null:new ResizeObserver(e=>{if(!this.active||!this.isConnected)return;let t=new Set(e.map(({target:e})=>e.closest(`.code-block-wrapper`)));for(let e of t)e&&ZS(e)}),this.mutationObserver=new MutationObserver(e=>{this.collectMutations(e),this.pendingBlocks.size&&this.scheduleScan()})}collectMutations(e){for(let t of e){let e=(t.target instanceof Element?t.target:t.target.parentElement)?.closest(rO);e&&this.pendingBlocks.add(e);for(let e of t.addedNodes)e instanceof HTMLElement&&this.collectBlocks(e);for(let e of t.removedNodes){if(!(e instanceof HTMLElement)||this.root?.contains(e))continue;let t=[e,...e.querySelectorAll(`.code-block-viewport, code`)];for(let e of t)this.observedNodes.delete(e)&&this.resizeObserver?.unobserve(e)}}}render(e=!0){return z}update(e,[t=!0]){let n=e.element instanceof HTMLElement?e.element:void 0;return n!==this.root&&(this.release(),this.root=n),this.active=t,t?this.scheduleScan():this.release(),z}disconnected(){this.release()}release(){this.mutationObserver.disconnect(),this.observedRoot=void 0,this.pendingBlocks.clear(),this.resizeObserver?.disconnect(),this.observedNodes.clear(),this.root&&zw(this.root)}reconnected(){this.scheduleScan()}scheduleScan(){!this.scanPending&&this.active&&this.isConnected&&(this.scanPending=!0,queueMicrotask(()=>{this.scanPending=!1,this.active&&this.isConnected&&this.root?.isConnected&&this.scan(this.root)}))}scan(e){Rw(e),this.observedRoot!==e&&(this.collectBlocks(e),this.mutationObserver.observe(e,{childList:!0,subtree:!0,characterData:!this.resizeObserver}),this.observedRoot=e),this.collectMutations(this.mutationObserver.takeRecords());let t=[...this.pendingBlocks];this.pendingBlocks.clear();for(let n of t){if(!e.contains(n))continue;if(n.matches(`.markdown-mermaid`)){if(n.querySelector(`pre code`)){let t=()=>this.active&&this.isConnected&&this.root===e&&e.isConnected&&e.contains(n);T(async()=>{let{mountMermaidBlocks:e}=await import(`./markdown-mermaid-unFSVeX0.js`);return{mountMermaidBlocks:e}},__vite__mapDeps([38,39,7]),import.meta.url).then(({mountMermaidBlocks:e})=>{t()&&e(n)},()=>{t()&&n.matches(`.markdown-mermaid`)&&(n.classList.remove(`markdown-mermaid`),n.prepend(j(`chat.mermaid.rendererError`)))})}continue}let t=n.querySelector(`.code-block-viewport`),r=t?.querySelector(`code`);if(!t||!r)continue;let i=n.querySelector(`.code-block-expand`);i&&(t.id||=`code-block-${++nO}`,i.getAttribute(`aria-controls`)!==t.id&&i.setAttribute(`aria-controls`,t.id));for(let e of[t,r])this.observedNodes.has(e)||(this.observedNodes.add(e),this.resizeObserver?.observe(e));this.resizeObserver||ZS(n)}}collectBlocks(e){e.matches(rO)&&this.pendingBlocks.add(e);for(let t of e.querySelectorAll(rO))this.pendingBlocks.add(t)}},aO=pa(iO)})))()}function sO(){return{floatOffset:0,antennaDegrees:0,antennaDroop:0,leftClawDegrees:0,rightClawDegrees:0,eyeGlowOpacity:1,glowScale:1,leftEyeOpenness:1,rightEyeOpenness:1,happyEyes:0,gaze:{x:0,y:0},mouthCurve:0,mouthOpen:0,mouthRound:0,blush:0,hardHat:0,bodyTilt:0,bodyStretch:1,effect:`none`,effectPhase:0}}function X(e,t=0,n=1){return Math.min(Math.max(e,t),n)}function cO(e){let t=X(e);return t*t*(3-2*t)}function lO(e){let t=X(e);return cO(t<.5?t*2:(1-t)*2)}function uO(e){return e.floatOffset=X(e.floatOffset,-12,2),e.antennaDegrees=X(e.antennaDegrees,-14,14),e.antennaDroop=X(e.antennaDroop,0,1),e.leftClawDegrees=X(e.leftClawDegrees,-45,45),e.rightClawDegrees=X(e.rightClawDegrees,-45,45),e.eyeGlowOpacity=X(e.eyeGlowOpacity,0,1),e.glowScale=X(e.glowScale,.5,1.6),e.leftEyeOpenness=X(e.leftEyeOpenness,0,1),e.rightEyeOpenness=X(e.rightEyeOpenness,0,1),e.happyEyes=X(e.happyEyes,0,1),e.gaze.x=X(e.gaze.x,-1.2,1.2),e.gaze.y=X(e.gaze.y,-1.2,1.2),e.mouthCurve=X(e.mouthCurve,-1,1),e.mouthOpen=X(e.mouthOpen,0,1),e.mouthRound=X(e.mouthRound,0,1),e.blush=X(e.blush,0,1),e.hardHat=X(e.hardHat,0,1),e.bodyTilt=X(e.bodyTilt,-8,8),e.bodyStretch=X(e.bodyStretch,.86,1.05),e}function dO(e){let t=sO();switch(e){case`idle`:case`curious`:case`attentive`:break;case`thinking`:t.gaze={x:.3,y:-.5};break;case`working`:t.hardHat=1,t.rightClawDegrees=-28,t.gaze={x:.4,y:.35},t.mouthCurve=.15,t.bodyTilt=2;break;case`happy`:t.mouthCurve=.6,t.happyEyes=.4;break;case`celebrating`:t.mouthCurve=.9,t.mouthOpen=.4,t.happyEyes=.8,t.leftClawDegrees=30,t.rightClawDegrees=-30;break;case`sad`:t.antennaDroop=.75,t.mouthCurve=-.55,t.eyeGlowOpacity=.6,t.gaze={x:0,y:.5};break;case`sleepy`:t.leftEyeOpenness=.25,t.rightEyeOpenness=.25,t.eyeGlowOpacity=.5,t.antennaDroop=.35}return t}function fO(e){return e?mO:pO}var pO,mO;function hO(){return(hO=e((()=>{pO={gradientTop:`#ff4d4d`,gradientBottom:`#991b1b`,antenna:`#ff4d4d`},mO={gradientTop:`#ff7079`,gradientBottom:`#ea4c59`,antenna:`#ef4b58`}})))()}function Z(e,t){let n=e/t%1;return n<0?n+1:n}function gO(e,t,n){let r=X(e);return r<t?cO(r/t):r>n?cO((1-r)/(1-n)):1}var _O,vO,yO,Q,bO,xO,SO,CO,wO,TO;function EO(){return(EO=e((()=>{hO(),_O=(1n<<64n)-1n,vO=11400714819323198485n,yO=2685821657736338717n,Q=Math.PI*2,bO=.16,xO=.8,SO={wave:1.5,hop:.7,celebrate:2.4,sigh:1.8,yawn:2,wipeBrow:2,clawSnap:.6,donHardHat:1},CO={idle:null,curious:null,thinking:null,attentive:null,happy:`hop`,celebrating:`celebrate`,sad:`sigh`,sleepy:`yawn`,working:`donHardHat`},wO=class{constructor(e){let t=BigInt.asUintN(64,BigInt(e));this.state=t===0n?vO:t}next(){return this.state^=this.state>>12n,this.state=BigInt.asUintN(64,this.state),this.state^=this.state<<25n,this.state=BigInt.asUintN(64,this.state),this.state^=this.state>>27n,this.state=BigInt.asUintN(64,this.state),this.state*yO&_O}unit(){return Number(this.next()>>11n)/9007199254740992}},TO=class{constructor(e=BigInt(Date.now())){this.currentMood=`idle`,this.startTime=null,this.lastPoseTime=0,this.activeGesture=null,this.activeGestureStart=0,this.pendingGesture=null,this.pendingGestureAt=0,this.nextBlinkAt=0,this.pendingDoubleBlink=!1,this.blinkStarts=[],this.nextGlanceAt=0,this.gazeHoldUntil=0,this.gazeTarget={x:0,y:0},this.currentGaze={x:0,y:0},this.nextClawSnapAt=0,this.nextMoodBeatAt=0,this.teaseActive=!1,this.teaseChangedAt=0,this.catchStartedAt=null,this.rng=new wO(e)}setMood(e,t){if(e===this.currentMood)return;this.currentMood=e,this.pendingGesture=null,this.activeGesture=null,this.rescheduleMoodBeat(t);let n=CO[e];n&&this.startGesture(n,t)}setTease(e,t){this.teaseActive=e,this.teaseChangedAt=t}playCatch(e){this.catchStartedAt=e}poseAt(e){this.startTime===null&&this.begin(e);let t=X(e-this.lastPoseTime,0,.1);this.lastPoseTime=e,this.advanceSchedules(e);let n=this.basePose(this.currentMood,e);if(this.applyGaze(n,this.currentMood,e,t),this.applyBlinks(n,e),this.activeGesture){let t=(e-this.activeGestureStart)/SO[this.activeGesture];t>=1?this.activeGesture=null:this.applyGesture(this.activeGesture,n,t)}if(this.teaseActive&&e>=this.teaseChangedAt&&(n.mouthRound=Math.max(n.mouthRound,.5),n.gaze={x:0,y:.6}),this.catchStartedAt!==null){let t=(e-this.catchStartedAt)/xO;if(t>=1)this.catchStartedAt=null;else if(t>=0){let e=lO(t);this.applyGesture(`clawSnap`,n,X(t/.75)),n.happyEyes=Math.max(n.happyEyes,.9*e),n.mouthCurve=Math.max(n.mouthCurve,.7*e),n.blush=Math.max(n.blush,.65*e)}}return uO(n)}begin(e){this.startTime=e,this.lastPoseTime=e,this.nextBlinkAt=e+this.random(.8,2.4),this.nextGlanceAt=e+this.random(1.5,4),this.nextClawSnapAt=e+this.random(2,5),this.rescheduleMoodBeat(e),(this.currentMood===`idle`||this.currentMood===`curious`||this.currentMood===`happy`)&&(this.pendingGesture=`wave`,this.pendingGestureAt=e+.9)}advanceSchedules(e){if(e>=this.nextBlinkAt&&(this.blinkStarts.push(e),this.pendingDoubleBlink?(this.pendingDoubleBlink=!1,this.nextBlinkAt=e+this.blinkInterval()):this.random(0,1)<.14?(this.pendingDoubleBlink=!0,this.nextBlinkAt=e+.34):this.nextBlinkAt=e+this.blinkInterval()),this.blinkStarts=this.blinkStarts.filter(t=>e-t<=bO),e>=this.nextGlanceAt?(this.gazeTarget=this.randomGlanceTarget(),this.gazeHoldUntil=e+this.random(.7,1.9),this.nextGlanceAt=this.gazeHoldUntil+this.glanceInterval()):e>=this.gazeHoldUntil&&(this.gazeTarget={x:0,y:0}),e>=this.nextClawSnapAt&&(this.activeGesture===null&&this.currentMood!==`sad`&&this.currentMood!==`working`&&this.startGesture(`clawSnap`,e),this.nextClawSnapAt=e+this.random(4,9)),e>=this.nextMoodBeatAt&&(this.activeGesture===null&&(this.currentMood===`sad`?this.startGesture(`sigh`,e):this.currentMood===`sleepy`?this.startGesture(`yawn`,e):this.currentMood===`working`&&this.startGesture(`wipeBrow`,e)),this.rescheduleMoodBeat(e)),this.pendingGesture&&e>=this.pendingGestureAt&&this.activeGesture===null){let t=this.pendingGesture;this.pendingGesture=null,this.startGesture(t,e)}}basePose(e,t){let n=sO();switch(e){case`idle`:n.floatOffset=-4.8*(1-Math.cos(Q*Z(t,4))),n.antennaDegrees=-3*Math.sin(Q*Z(t,2));break;case`curious`:n.floatOffset=-4.2*(1-Math.cos(Q*Z(t,3.4))),n.antennaDegrees=-4*Math.sin(Q*Z(t,1.7)),n.bodyTilt=1.6*Math.sin(Q*Z(t,5.2));break;case`thinking`:n.floatOffset=-3.2*(1-Math.cos(Q*Z(t,5))),n.antennaDegrees=-5*Math.sin(Q*Z(t,1.3)),n.bodyTilt=2*Math.sin(Q*Z(t,6)),n.eyeGlowOpacity=.9+.1*Math.sin(Q*Z(t,.8));break;case`working`:{let e=Z(t,.95);if(e<.05)n.rightClawDegrees=-6;else if(e<.6)n.rightClawDegrees=-6-28*cO((e-.05)/.55);else if(e<.72){let t=X((e-.6)/.12);n.rightClawDegrees=-34+46*t*t}else n.rightClawDegrees=12-18*cO((e-.72)/.28);n.leftClawDegrees=4+2*Math.sin(Q*e);let r=lO(X((e-.72)/.14));if(n.floatOffset=-2*(1-Math.cos(Q*Z(t,3.8)))+.8*r,n.bodyStretch=1-.03*r,n.bodyTilt=2.2+.6*Math.sin(Q*Z(t,5)),e>=.72){let t=X((e-.72)/.28);n.antennaDegrees=6*(1-t)*Math.sin(t*3*Math.PI)}n.leftEyeOpenness=.85,n.rightEyeOpenness=.85,n.mouthCurve=.18,n.hardHat=1,n.effect=`sparks`;let i=(e-.72)%1;n.effectPhase=i<0?i+1:i;break}case`happy`:n.floatOffset=-6*(1-Math.cos(Q*Z(t,3))),n.antennaDegrees=-4.5*Math.sin(Q*Z(t,1.6)),n.mouthCurve=.55+.1*Math.sin(Q*Z(t,3)),n.happyEyes=.35;break;case`celebrating`:{let e=Math.abs(Math.sin(Q*Z(t,1.6)));n.floatOffset=-9*e,n.bodyStretch=1+.03*e,n.antennaDegrees=-6*Math.sin(Q*Z(t,.8));let r=Math.sin(Q*Z(t,.9));n.leftClawDegrees=20+8*r,n.rightClawDegrees=-20+8*r,n.mouthCurve=.9,n.mouthOpen=.35,n.happyEyes=.7,n.glowScale=1.1,n.effect=`sparkles`,n.effectPhase=Z(t,2.2);break}case`sad`:n.floatOffset=-2.4*(1-Math.cos(Q*Z(t,5.5))),n.antennaDegrees=-1.5*Math.sin(Q*Z(t,3)),n.antennaDroop=.75,n.mouthCurve=-.55,n.eyeGlowOpacity=.6;break;case`sleepy`:n.floatOffset=-2*(1-Math.cos(Q*Z(t,6))),n.antennaDroop=.35,n.leftEyeOpenness=.22+.08*Math.sin(Q*Z(t,3)),n.rightEyeOpenness=n.leftEyeOpenness,n.eyeGlowOpacity=.5,n.mouthRound=.15,n.bodyTilt=2.5*Math.sin(Q*Z(t,6)),n.effect=`zzz`,n.effectPhase=Z(t,3);break;case`attentive`:n.floatOffset=-3*(1-Math.cos(Q*Z(t,4))),n.antennaDegrees=-2.5*Math.sin(Q*Z(t,2)),n.mouthCurve=.25}return n}applyGaze(e,t,n,r){let i=this.gazeTarget;switch(t){case`thinking`:i={x:.4*Math.sin(Q*Z(n,3.8)),y:-.55};break;case`working`:i={x:.55+.04*Math.sin(Q*Z(n,4.6)),y:.45+.02*Math.cos(Q*Z(n,3.9))};break;case`attentive`:i={x:i.x*.5,y:.35};break;case`sad`:i={x:i.x*.3,y:.5};break;case`sleepy`:i={x:0,y:.4}}let a=1-Math.exp(-r*9);this.currentGaze.x+=(i.x-this.currentGaze.x)*a,this.currentGaze.y+=(i.y-this.currentGaze.y)*a,e.gaze={...this.currentGaze}}applyBlinks(e,t){if(!(e.happyEyes>=.6))for(let n of this.blinkStarts){let r=(t-n)/bO;if(r<0||r>1)continue;let i=lO(r);e.leftEyeOpenness=Math.min(e.leftEyeOpenness,1-i),e.rightEyeOpenness=Math.min(e.rightEyeOpenness,1-i),e.eyeGlowOpacity*=Math.max(.3,1-i)}}applyGesture(e,t,n){let r=X(n);switch(e){case`wave`:{let e=gO(r,.18,.82);t.rightClawDegrees+=e*(-28+9*Math.sin(r*6*Math.PI)),t.bodyTilt+=-2*e,t.mouthCurve=Math.max(t.mouthCurve,.5*e);break}case`hop`:{let e=lO(X((r-.2)/.6));t.floatOffset+=-9*e,t.bodyStretch+=.045*e-.1*lO(X(r/.2))-.06*lO(X((r-.82)/.18)),t.mouthCurve=Math.max(t.mouthCurve,.4*e);break}case`celebrate`:{let e=gO(r,.12,.88),n=Math.abs(Math.sin(r*4*Math.PI));t.floatOffset+=-11*n*e,t.bodyStretch+=.035*n*e,t.leftClawDegrees+=38*e,t.rightClawDegrees+=-38*e,t.happyEyes=Math.max(t.happyEyes,e),t.mouthCurve=Math.max(t.mouthCurve,e),t.mouthOpen=Math.max(t.mouthOpen,.6*lO(r)),t.antennaDroop=0,t.glowScale=Math.max(t.glowScale,1+.2*e),t.effect=`sparkles`,t.effectPhase=r;break}case`sigh`:{let e=cO(X(r/.3)),n=cO(X((r-.3)/.45));t.bodyStretch+=.025*e-.08*n*(1-X((r-.85)/.15)),t.gaze={x:t.gaze.x,y:.5*n},t.antennaDroop=Math.min(1,t.antennaDroop+.15*n);break}case`yawn`:{let e=gO(r,.3,.75);t.mouthRound=Math.max(t.mouthRound,.9*e),t.leftEyeOpenness=Math.min(t.leftEyeOpenness,1-.9*e),t.rightEyeOpenness=Math.min(t.rightEyeOpenness,1-.9*e),t.bodyStretch+=.03*e,t.bodyTilt+=-2*e;break}case`clawSnap`:t.leftClawDegrees+=-8*lO(X(r/.7)),t.rightClawDegrees+=-8*lO(X((r-.25)/.7));break;case`donHardHat`:{let e=cO(X(r/.55));t.hardHat=Math.min(t.hardHat,e),r<.55&&(t.gaze={x:0,y:-.9*(1-r)}),t.bodyStretch-=.04*lO(X((r-.5)/.2));let n=lO(X((r-.7)/.3));t.leftClawDegrees+=-8*n,t.rightClawDegrees+=8*n;break}case`wipeBrow`:{let e=gO(r,.2,.8);t.leftClawDegrees*=1-e,t.rightClawDegrees*=1-e,t.leftClawDegrees+=38*e*(.9+.1*Math.sin(r*5*Math.PI)),t.bodyTilt*=1-e,t.bodyStretch+=.02*e,t.happyEyes=Math.max(t.happyEyes,.7*e),t.mouthCurve=Math.max(t.mouthCurve,.5*e),t.gaze={x:t.gaze.x*(1-e),y:t.gaze.y*(1-e)},t.effect=`sweat`,t.effectPhase=r;break}}}startGesture(e,t){this.activeGesture=e,this.activeGestureStart=t}random(e,t){return e+(t-e)*this.rng.unit()}blinkInterval(){return this.currentMood===`attentive`?this.random(1.8,4):this.random(2.2,5.5)}glanceInterval(){return this.currentMood===`curious`?this.random(1.6,4):this.currentMood===`thinking`?this.random(1.2,3):this.random(3,8)}randomGlanceTarget(){let e=this.random(.5,1),t=this.random(0,Q);return{x:Math.cos(t)*e,y:Math.sin(t)*e*.6}}rescheduleMoodBeat(e){this.nextMoodBeatAt=e+this.random(6,12)}}})))()}function DO(){if(YO)return YO;let e=new Path2D;e.moveTo(60,10),e.bezierCurveTo(30,10,15,35,15,55),e.bezierCurveTo(15,75,30,95,45,100),e.lineTo(45,110),e.lineTo(55,110),e.lineTo(55,100),e.bezierCurveTo(55,100,60,102,65,100),e.lineTo(65,110),e.lineTo(75,110),e.lineTo(75,100),e.bezierCurveTo(90,95,105,75,105,55),e.bezierCurveTo(105,35,90,10,60,10),e.closePath();let t=new Path2D;t.moveTo(20,45),t.bezierCurveTo(5,40,0,50,5,60),t.bezierCurveTo(10,70,20,65,25,55),t.bezierCurveTo(28,48,25,45,20,45),t.closePath();let n=new Path2D;n.moveTo(100,45),n.bezierCurveTo(115,40,120,50,115,60),n.bezierCurveTo(110,70,100,65,95,55),n.bezierCurveTo(92,48,95,45,100,45),n.closePath();let r=new Path2D;r.moveTo(45,15),r.quadraticCurveTo(35,5,30,8);let i=new Path2D;return i.moveTo(75,15),i.quadraticCurveTo(85,5,90,8),YO={body:{path:e,bounds:{minX:15,minY:10,maxX:105,maxY:110}},leftClaw:{path:t,bounds:{minX:3.125,minY:43.67006838144548,maxX:26.196938456699073,maxY:65.45084971874738}},rightClaw:{path:n,bounds:{minX:93.80306154330093,minY:43.67006838144548,maxX:116.875,maxY:65.45084971874738}},leftAntenna:r,rightAntenna:i},YO}function OO(e,t,n){let{bounds:r}=t,i=e.createLinearGradient(r.minX,r.minY,r.maxX,r.maxY);return i.addColorStop(0,n.gradientTop),i.addColorStop(1,n.gradientBottom),i}function kO(e){return e*Math.PI/180}function AO(e,t,n,r){e.save(),e.translate(n.x,n.y),e.rotate(kO(t)),e.translate(-n.x,-n.y),r(),e.restore()}function jO(e,t,n){let r=new Path2D;return r.ellipse(e.x,e.y,t,n,0,0,HO),r}function MO(e,t,n,r,i){let a=new Path2D,o=e+n,s=t+r;return a.moveTo(e+i,t),a.lineTo(o-i,t),a.quadraticCurveTo(o,t,o,t+i),a.lineTo(o,s-i),a.quadraticCurveTo(o,s,o-i,s),a.lineTo(e+i,s),a.quadraticCurveTo(e,s,e,s-i),a.lineTo(e,t+i),a.quadraticCurveTo(e,t,e+i,t),a.closePath(),a}function NO(e,t,n,r){let i={x:t.x+r.gaze.x*2,y:t.y+r.gaze.y*1.5};if(r.happyEyes<1){let t=Math.max(1.2,12*n*(1-.6*r.happyEyes));e.save(),e.globalAlpha*=1-r.happyEyes,e.fillStyle=UO,e.fill(jO({x:i.x,y:i.y-6+(12-t)*.65+t/2},6,t/2)),e.restore()}if(r.happyEyes>0){let t=new Path2D;t.moveTo(i.x-6,i.y+2),t.quadraticCurveTo(i.x,i.y-5.5,i.x+6,i.y+2),e.save(),e.globalAlpha*=r.happyEyes,e.strokeStyle=UO,e.lineWidth=2.6,e.lineCap=`round`,e.stroke(t),e.restore()}let a=r.eyeGlowOpacity*n*(1-r.happyEyes);if(a<=.01)return;let o=2*r.glowScale,s={x:i.x+1+r.gaze.x*1.2,y:i.y-1+r.gaze.y*.9};e.save(),e.globalAlpha*=a,e.fillStyle=WO,e.fill(jO(s,o,o)),e.restore()}function PO(e,t){if(e.fillStyle=UO,e.strokeStyle=UO,e.lineCap=`round`,t.mouthRound>.05){let n=1+3.2*t.mouthRound,r=1+4.2*t.mouthRound;e.fill(jO({x:60,y:51},n,r));return}if(t.mouthOpen>.05){let n=new Path2D;n.moveTo(52.5,48.5),n.quadraticCurveTo(60,48.5+14*t.mouthOpen,67.5,48.5),n.closePath(),e.fill(n);return}if(Math.abs(t.mouthCurve)<=.05)return;let n=new Path2D;n.moveTo(52.5,49),n.quadraticCurveTo(60,49+8*t.mouthCurve,67.5,49),e.lineWidth=2.2,e.stroke(n)}function FO(e,t){t.blush<=.02||(e.save(),e.globalAlpha*=t.blush*.55,e.fillStyle=GO,e.fill(jO({x:37,y:45},4.5,2.5)),e.fill(jO({x:83,y:45},4.5,2.5)),e.restore())}function IO(e,t){if(t<=.01)return;let n=new Path2D;n.moveTo(45,15),n.bezierCurveTo(47,7,54,3,60,3),n.bezierCurveTo(66,3,73,7,75,15),n.lineTo(45,15),n.closePath();let r=MO(41,14,38,5,2);e.save(),e.globalAlpha*=t,e.translate(60,15-14*(1-t)),e.rotate(kO(-5)),e.translate(-60,-15);let i=e.createLinearGradient(60,3,60,16);i.addColorStop(0,qO),i.addColorStop(1,KO),e.fillStyle=i,e.fill(n),e.strokeStyle=JO,e.lineWidth=.8,e.stroke(n),e.fillStyle=KO,e.fill(r),e.stroke(r),e.restore()}function LO(e,t){let n=new Path2D;n.moveTo(e.x,e.y-t);for(let[r,i]of[[1,0],[0,1],[-1,0],[0,-1]])n.quadraticCurveTo(e.x,e.y,e.x+t*r,e.y+t*i);return n.closePath(),n}function RO(e,t,n,r){let i=new Path2D,a=n*.62,o=n*.78;i.moveTo(t.x-a/2,t.y-o/2),i.lineTo(t.x+a/2,t.y-o/2),i.lineTo(t.x-a/2,t.y+o/2),i.lineTo(t.x+a/2,t.y+o/2),e.save(),e.globalAlpha*=r*.9,e.strokeStyle=WO,e.lineWidth=Math.max(1.2,n*.16),e.lineCap=`round`,e.lineJoin=`round`,e.stroke(i),e.restore()}function zO(e,t,n){switch(t.effect){case`none`:return;case`sparkles`:for(let r=0;r<6;r+=1){let i=lO((t.effectPhase+r*.37)%1);if(i<=.05)continue;let a=Math.PI+Math.PI*(r+.5)/6,o={x:60+Math.cos(a)*(50+r%3*4),y:55+Math.sin(a)*(40+r*5%3*4)};e.save(),e.globalAlpha*=i,e.fillStyle=r%2==0?WO:n.antenna,e.fill(LO(o,2.5+2*i)),e.restore()}return;case`zzz`:for(let n=0;n<3;n+=1){let r=(t.effectPhase+n*.33)%1,i=r<.2?r/.2:1-(r-.2)/.8;i<=.05||RO(e,{x:86+14*r+2*Math.sin(r*4*Math.PI),y:24-20*r},6+4*r,i)}return;case`sparks`:for(let n=0;n<5;n+=1){let r=t.effectPhase-n*.025;if(r<0||r>=.45)continue;let i=r<.08?r/.08:1-(r-.08)/.37,a=kO(-160+n*35),o=5+12*r/.45,s=2.2+n%3*.8,c={x:X(106+Math.cos(a)*o,s,VO-s),y:X(66+Math.sin(a)*o,s,VO-s)};e.save(),e.globalAlpha*=i,e.fillStyle=n%2==0?WO:KO,e.fill(LO(c,s)),e.restore()}return;case`sweat`:{let n=lO(t.effectPhase);if(n<=.02)return;let r={x:42,y:24+7*t.effectPhase},i=new Path2D;i.moveTo(r.x,r.y-3),i.bezierCurveTo(r.x-4,r.y+1,r.x-2,r.y+3,r.x,r.y+3),i.bezierCurveTo(r.x+2,r.y+3,r.x+4,r.y+1,r.x,r.y-3),e.save(),e.globalAlpha*=n,e.fillStyle=`#80d4ff`,e.fill(i),e.restore()}}}function BO(e,t,n,r){let i=DO();if(n.save(),n.scale(r/VO,r/VO),e.bodyStretch!==1){let t=X(1+(1-e.bodyStretch)*.5,.97,1.03);n.translate(60,110),n.scale(t,e.bodyStretch),n.translate(-60,-110)}e.bodyTilt!==0&&(n.translate(60,60),n.rotate(kO(e.bodyTilt)),n.translate(-60,-60)),n.fillStyle=OO(n,i.body,t),n.fill(i.body.path),AO(n,e.leftClawDegrees,{x:26,y:53},()=>{n.fillStyle=OO(n,i.leftClaw,t),n.fill(i.leftClaw.path)}),AO(n,e.rightClawDegrees,{x:94,y:53},()=>{n.fillStyle=OO(n,i.rightClaw,t),n.fill(i.rightClaw.path)});let a=e.antennaDegrees*(1-e.antennaDroop);n.strokeStyle=t.antenna,n.lineWidth=2,n.lineCap=`round`,AO(n,-e.antennaDroop*40,{x:45,y:15},()=>{AO(n,a,{x:37.5,y:11},()=>n.stroke(i.leftAntenna))}),AO(n,e.antennaDroop*40,{x:75,y:15},()=>{AO(n,a,{x:82.5,y:11},()=>n.stroke(i.rightAntenna))}),IO(n,e.hardHat),FO(n,e),NO(n,{x:45,y:35},e.leftEyeOpenness,e),NO(n,{x:75,y:35},e.rightEyeOpenness,e),PO(n,e),zO(n,e,t),n.restore()}var VO,HO,UO,WO,GO,KO,qO,JO,YO;function XO(){return(XO=e((()=>{hO(),VO=120,HO=Math.PI*2,UO=`#050810`,WO=`#00e5cc`,GO=`#ff9eae`,KO=`#f2a833`,qO=`#ffd659`,JO=`rgba(184, 115, 31, 0.7)`,YO=null})))()}function ZO(){return performance.now()/1e3}var QO,$O,ek;function tk(){return(tk=e((()=>{B(),H(),EO(),XO(),hO(),Gi(),QO=120,$O=new Set([`idle`,`curious`,`thinking`,`working`,`happy`,`celebrating`,`sad`,`sleepy`,`attentive`]),ek=class extends _{constructor(...e){super(...e),this.mood=`idle`,this.size=QO,this.tease=!1,this.animator=new TO,this.animationFrame=0,this.visible=!0,this.reducedMotion=!1,this.intersectionObserver=null,this.themeObserver=null,this.motionQuery=null,this.handleVisibilityChange=()=>this.syncPlayback(),this.handleMotionChange=e=>{this.reducedMotion=e.matches,this.syncPlayback()},this.renderAnimationFrame=e=>{this.animationFrame=0,this.shouldAnimate&&(this.drawCurrentFrame(e/1e3),this.animationFrame=window.requestAnimationFrame(this.renderAnimationFrame))}}static{this.styles=wa`
    :host {
      display: inline-block;
      width: var(--openclaw-mascot-size, 120px);
      height: var(--openclaw-mascot-size, 120px);
      overflow: visible;
      contain: layout style;
      pointer-events: none;
      line-height: 0;
    }

    canvas {
      display: block;
      width: 100%;
      height: 100%;
      will-change: transform;
    }

    .openclaw-mascot--neutral,
    .openclaw-mascot--neutral svg {
      display: block;
      width: 100%;
      height: 100%;
    }
  `}connectedCallback(){super.connectedCallback(),this.setAttribute(`aria-hidden`,`true`),document.addEventListener(`visibilitychange`,this.handleVisibilityChange),this.motionQuery=window.matchMedia?.(`(prefers-reduced-motion: reduce)`)??null,this.reducedMotion=this.motionQuery?.matches??!1,this.motionQuery?.addEventListener(`change`,this.handleMotionChange),typeof IntersectionObserver<`u`&&(this.intersectionObserver=new IntersectionObserver(e=>{this.visible=e.some(e=>e.isIntersecting),this.syncPlayback()}),this.intersectionObserver.observe(this)),typeof MutationObserver<`u`&&(this.themeObserver=new MutationObserver(()=>this.requestUpdate()),this.themeObserver.observe(document.documentElement,{attributes:!0,attributeFilter:[`data-theme-mode`,`data-theme-mascot`]}))}disconnectedCallback(){this.stopAnimation(),document.removeEventListener(`visibilitychange`,this.handleVisibilityChange),this.motionQuery?.removeEventListener(`change`,this.handleMotionChange),this.motionQuery=null,this.intersectionObserver?.disconnect(),this.intersectionObserver=null,this.themeObserver?.disconnect(),this.themeObserver=null,super.disconnectedCallback()}firstUpdated(){this.animator.setMood(this.resolvedMood,ZO()),this.animator.setTease(this.tease,ZO()),this.drawCurrentFrame(ZO()),this.syncPlayback()}updated(e){e.has(`size`)&&this.style.setProperty(`--openclaw-mascot-size`,`${this.resolvedSize}px`),e.has(`mood`)&&this.animator.setMood(this.resolvedMood,ZO()),e.has(`tease`)&&this.animator.setTease(this.tease,ZO()),this.drawCurrentFrame(ZO()),this.syncPlayback()}catchOnce(){if(!this.isConnected||this.reducedMotion||bi().mascot===`none`)return;let e=ZO();this.animator.playCatch(e),this.drawCurrentFrame(e),this.syncPlayback()}render(){return bi().mascot===`none`?R`<span class="openclaw-mascot--neutral">${Di}</span>`:R`<canvas></canvas>`}get resolvedMood(){return $O.has(this.mood)?this.mood:`idle`}get resolvedSize(){return Number.isFinite(this.size)&&this.size>0?this.size:QO}get shouldAnimate(){return this.isConnected&&bi().mascot===`claw`&&this.visible&&!this.reducedMotion&&document.visibilityState!==`hidden`}syncPlayback(){if(!this.renderRoot.querySelector(`canvas`)){this.stopAnimation();return}if(this.reducedMotion){this.stopAnimation(),this.drawPose(dO(this.resolvedMood));return}if(!this.shouldAnimate){this.stopAnimation();return}this.animationFrame===0&&(this.animationFrame=window.requestAnimationFrame(this.renderAnimationFrame))}stopAnimation(){this.animationFrame!==0&&(window.cancelAnimationFrame(this.animationFrame),this.animationFrame=0)}drawCurrentFrame(e){this.drawPose(this.reducedMotion?dO(this.resolvedMood):this.animator.poseAt(e))}drawPose(e){let t=this.renderRoot.querySelector(`canvas`);if(!(t instanceof HTMLCanvasElement)||typeof Path2D>`u`)return;let n=t.getContext(`2d`);if(!n)return;let r=this.resolvedSize,i=Math.max(1,window.devicePixelRatio||1),a=Math.round(r*i);(t.width!==a||t.height!==a)&&(t.width=a,t.height=a),n.setTransform(i,0,0,i,0,0),n.clearRect(0,0,r,r),BO(e,fO(document.documentElement.dataset.themeMode===`light`),n,r),t.style.transform=`translate3d(0, ${e.floatOffset*r/120}px, 0)`}},w([W({reflect:!0})],ek.prototype,`mood`,void 0),w([W({type:Number})],ek.prototype,`size`,void 0),w([W({type:Boolean})],ek.prototype,`tease`,void 0),customElements.get(`openclaw-mascot`)||customElements.define(`openclaw-mascot`,ek)})))()}function nk(e,t,n=!1,r=!1){return R`
    <openclaw-panel-loading-skeleton
      .variant=${e}
      .label=${t}
      ?compact=${n}
      ?overlay=${r}
      role="status"
      aria-busy="true"
      aria-label=${t}
    ></openclaw-panel-loading-skeleton>
  `}var rk;function ik(){return(ik=e((()=>{B(),H(),M(),rk=class extends Ut{constructor(...e){super(...e),this.variant=`files`,this.compact=!1,this.overlay=!1,this.label=``}static{this.styles=wa`
    :host {
      display: block;
      box-sizing: border-box;
      width: 100%;
      min-height: 100%;
      padding: 14px;
      color: var(--muted);
    }

    :host([compact]) {
      min-height: 0;
      padding: 8px;
    }

    :host([data-panel-skeleton="desktop"]) {
      display: flex;
      flex: 1;
      min-height: 0;
      align-items: center;
      justify-content: center;
    }

    .desktop-loading {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      text-align: center;
      font-size: 13px;
    }

    .desktop-spinner {
      width: 24px;
      height: 24px;
      border: 2px solid var(--border);
      border-top-color: var(--muted);
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    :host([overlay]) {
      position: absolute;
      inset: 0;
      z-index: 2;
      min-height: 0;
      background: color-mix(in srgb, var(--bg, #0e1015) 92%, transparent);
      pointer-events: none;
    }

    :host([compact]) .viewport,
    :host([compact]) .terminal,
    :host([compact]) .discussion-frame {
      min-height: 72px;
    }

    * {
      box-sizing: border-box;
    }

    /* Terminal/desktop/browser hosts use shadow roots, so base.css's .skeleton
       and global reduced-motion gate cannot reach here. Keep this primitive
       declaration-identical to base.css; the unit test guards against drift. */
    .skeleton {
      position: relative;
      overflow: hidden;
      background: var(--skeleton-base, var(--bg-muted));
      border-radius: var(--radius-md);
    }

    .skeleton::after {
      position: absolute;
      inset: 0;
      background: linear-gradient(
        90deg,
        transparent 25%,
        var(--skeleton-highlight, var(--bg-hover)) 50%,
        transparent 75%
      );
      content: "";
      transform: translateX(-100%);
      animation: shimmer var(--skeleton-duration, 1.5s) ease-in-out infinite;
      will-change: transform;
    }

    .line {
      height: 10px;
    }

    .short {
      width: 36%;
    }

    .medium {
      width: 62%;
    }

    .long {
      width: 88%;
    }

    .row,
    .toolbar,
    .bubble,
    .summary {
      display: flex;
      gap: 10px;
      align-items: center;
    }

    .rows,
    .conversation,
    .code {
      display: grid;
      gap: 12px;
    }

    .toolbar {
      padding-bottom: 12px;
      border-bottom: 1px solid var(--border);
      margin-bottom: 14px;
    }

    .icon {
      width: 18px;
      height: 18px;
      flex: 0 0 auto;
      border-radius: 5px;
    }

    .copy {
      display: grid;
      flex: 1;
      gap: 6px;
    }

    .meta {
      height: 7px;
      width: 28%;
    }

    .viewport {
      min-height: 220px;
      border-radius: 8px;
    }

    .address {
      height: 28px;
      flex: 1;
      border-radius: 7px;
    }

    .button {
      width: 28px;
      height: 28px;
      flex: 0 0 auto;
    }

    .summary {
      margin-bottom: 16px;
    }

    .pill {
      width: 64px;
      height: 24px;
      border-radius: 999px;
    }

    .file-heading {
      height: 30px;
      margin-bottom: 14px;
    }

    .code .line {
      height: 9px;
      border-radius: 3px;
    }

    .terminal {
      display: grid;
      gap: 11px;
      padding: 12px;
      min-height: 220px;
      align-content: start;
      border-radius: 8px;
      background: color-mix(in srgb, var(--bg) 76%, transparent);
    }

    .bubble {
      width: 82%;
      min-height: 58px;
      padding: 12px;
      align-items: flex-start;
      border-radius: 12px;
      background: color-mix(in srgb, var(--bg-muted) 76%, transparent);
    }

    .bubble.user {
      width: 58%;
      margin-left: auto;
    }

    .discussion-frame {
      min-height: 280px;
      padding: 18px;
      border: 1px solid var(--border);
      border-radius: 8px;
    }

    /* Mirrors board.css: a 38px tab strip over a 12-column grid with 56px rows,
       so the placeholder occupies the same footprint as the widgets it precedes. */
    .board-tabs {
      display: flex;
      gap: 14px;
      align-items: center;
      min-height: 38px;
      margin-bottom: 12px;
      padding: 0 13px;
      border-bottom: 1px solid var(--border);
    }

    .tab {
      width: 64px;
      height: 10px;
      border-radius: 5px;
    }

    .board-grid {
      container-type: inline-size;
      display: grid;
      gap: 12px;
      grid-auto-rows: 56px;
      grid-template-columns: repeat(12, minmax(0, 1fr));
    }

    .widget {
      display: grid;
      grid-template-rows: 38px minmax(0, 1fr);
      min-height: 0;
      min-width: 0;
      overflow: hidden;
      border: 1px solid var(--border);
      border-radius: 12px;
    }

    @container (max-width: 560px) {
      .widget {
        grid-column: 1 / -1 !important;
      }
    }

    .widget-bar {
      display: flex;
      gap: 7px;
      align-items: center;
      padding: 0 12px;
      border-bottom: 1px solid var(--border);
    }

    .widget-body {
      display: grid;
      gap: 10px;
      align-content: start;
      padding: 12px;
    }

    @keyframes shimmer {
      from {
        transform: translateX(-100%);
      }
      to {
        transform: translateX(100%);
      }
    }

    @keyframes spin {
      to {
        transform: rotate(360deg);
      }
    }

    @media (prefers-reduced-motion: reduce) {
      .desktop-spinner,
      .skeleton::after {
        animation: none;
      }
    }
  `}line(e=`long`){return R`<div class="skeleton line ${e}"></div>`}rows(e){return Array.from({length:e},(e,t)=>R`
        <div class="row">
          <div class="skeleton icon"></div>
          <div class="copy">
            ${this.line(t%2==0?`long`:`medium`)}
            <div class="skeleton meta"></div>
          </div>
        </div>
      `)}widget(e,t,n){return R`
      <div class="widget" style=${`grid-column: span ${e}; grid-row: span ${t}`}>
        <div class="widget-bar">
          <div class="skeleton icon"></div>
          ${this.line(`short`)}
        </div>
        <div class="widget-body">${n.map(e=>this.line(e))}</div>
      </div>
    `}render(){switch(this.variant){case`board`:return R`
          <div class="board-tabs">
            <div class="skeleton tab"></div>
            <div class="skeleton tab"></div>
          </div>
          <div class="board-grid">
            ${this.widget(6,4,[`long`,`medium`,`short`])}
            ${this.widget(6,4,[`medium`,`long`])} ${this.widget(4,3,[`medium`,`short`])}
            ${this.widget(8,3,[`long`,`medium`,`long`])}
          </div>
        `;case`browser`:return R`
          <div class="toolbar">
            <div class="skeleton button"></div>
            <div class="skeleton button"></div>
            <div class="skeleton address"></div>
          </div>
          <div class="skeleton viewport"></div>
        `;case`chat`:return R`
          <div class="conversation">
            <div class="bubble"><div class="copy">${this.line()}${this.line(`medium`)}</div></div>
            <div class="bubble user"><div class="copy">${this.line(`medium`)}</div></div>
            <div class="bubble"><div class="copy">${this.line()}${this.line(`short`)}</div></div>
          </div>
        `;case`desktop`:return R`
          <div class="desktop-loading">
            <span class="desktop-spinner" aria-hidden="true"></span>
            <span>${this.label}</span>
          </div>
        `;case`discussion`:return R`
          <div class="discussion-frame">
            <div class="conversation">
              ${this.line(`medium`)} ${this.line()} ${this.line(`long`)} ${this.line(`short`)}
            </div>
          </div>
        `;case`file-list`:return R`<div class="rows">${this.rows(5)}</div>`;case`document`:return R`
          <div class="skeleton file-heading medium"></div>
          <div class="code">
            ${this.line()} ${this.line()} ${this.line(`medium`)} ${this.line()}
            ${this.line(`short`)}
          </div>
        `;case`review`:return R`
          <div class="summary">
            <div class="skeleton pill"></div>
            <div class="skeleton pill"></div>
          </div>
          <div class="skeleton file-heading"></div>
          <div class="code">
            ${this.line()} ${this.line(`long`)} ${this.line(`medium`)} ${this.line()}
            ${this.line(`short`)}
          </div>
        `;case`terminal`:return R`
          <div class="toolbar">
            <div class="skeleton pill"></div>
            <div class="skeleton pill"></div>
          </div>
          <div class="terminal">
            ${this.line(`medium`)} ${this.line()} ${this.line(`short`)} ${this.line(`long`)}
          </div>
        `;default:return R`
          <div class="toolbar">
            <div class="skeleton address"></div>
            <div class="skeleton button"></div>
          </div>
          <div class="rows">${this.rows(5)}</div>
        `}}},w([W({reflect:!0,attribute:`data-panel-skeleton`})],rk.prototype,`variant`,void 0),w([W({type:Boolean,reflect:!0})],rk.prototype,`compact`,void 0),w([W({type:Boolean,reflect:!0})],rk.prototype,`overlay`,void 0),w([W()],rk.prototype,`label`,void 0),customElements.get(`openclaw-panel-loading-skeleton`)||customElements.define(`openclaw-panel-loading-skeleton`,rk)})))()}function ak(e,t=``){try{let n=new URL(e,globalThis.location.origin),r=`${ce(t)}${$a}`;return n.origin===globalThis.location.origin&&n.pathname.startsWith(r)&&/^[^/]+\/[^/]+$/u.test(n.pathname.slice(r.length))}catch{return!1}}async function ok(e,t,n,r){let i=e.client,a=e.connectionEpoch,o=e.resourceBasePath;if(!e.connected||!i)return null;let s=!/^artifact_managed_(?:image|media)_/u.test(t.artifactId)&&globalThis.location?.protocol===`https:`&&Ri(i.gatewayUrl),c=()=>!n?.aborted&&e.connected&&e.client===i&&e.connectionEpoch===a,l=async e=>{if(!c())return null;let n=await i.request(`artifacts.download`,{...t,...e?{transport:`http`}:{}},{timeoutMs:3e4});return c()?n:null},u=await l(s);if(!u)return null;let d=u.url?.trim();if(!s||!d?.startsWith(`/api/artifacts/download/`))return u;let f={...u,url:`${ce(o??``)}${d}`},p=u.artifact.mimeType?.split(`;`,1)[0]?.trim().toLowerCase()??``;if(!r?.readBinary&&!/^(?:image\/|text\/|application\/json$)/u.test(p))return f;try{if(!ak(f.url,o))throw Error(`Invalid artifact download URL`);let e=AbortSignal.timeout(3e4),t=await Qn(f.url,{credentials:`same-origin`,redirect:`error`,signal:n?AbortSignal.any([n,e]):e});if(!t.ok)throw Error(`Artifact download failed (${t.status})`);if(t.headers.get(`content-disposition`)?.split(`;`,1)[0]?.trim().toLowerCase()!==`attachment`)throw Error(`Artifact download returned an unexpected content disposition`);let r=await t.blob();if(r.type.split(`;`,1)[0]?.trim().toLowerCase()!==(p||`application/octet-stream`))throw Error(`Artifact download returned an unexpected content type`);return c()?{...f,blob:r}:null}catch{return await l(!1)}}function sk(){return(sk=e((()=>{Xa(),ii(),ci(),hr()})))()}async function ck(e){if(!e||e.kind===`video`)return e;let t=new Image;t.referrerPolicy=`no-referrer`,t.src=e.src;try{return await t.decode(),e}catch{return e.release?.(),null}}function lk(e,t){let n=e?.getRootNode();if(!e||document.fullscreenElement||n instanceof ShadowRoot&&n.fullscreenElement)return!1;if(!t.composedPath().includes(e))return!0;let r=e.getBoundingClientRect();return t.clientY<r.bottom-Math.min(80,r.height/2)}function uk(e,t){return e?.matches(`:fullscreen`)?(t.preventDefault(),t.stopPropagation(),e.ownerDocument.exitFullscreen().catch(()=>void 0),!0):!1}function dk(e,t){if(e.key!==`Tab`)return;let n=[...t].filter(e=>!(e instanceof HTMLButtonElement&&e.disabled)),r=n[0],i=n.at(-1);if(!r||!i)return;let a=e.composedPath()[0];e.shiftKey&&a===r?(e.preventDefault(),i.focus()):!e.shiftKey&&a===i&&(e.preventDefault(),r.focus())}var fk;function pk(){return(pk=e((()=>{fk=class{constructor(e){this.notify=e,this.index=0,this.busy=!1,this.failed=!1,this.videoStatus=`preparing`,this.videoRetryable=!0,this.generation=0,this.images=new Map}get count(){return this.gallery?.items.length??0}reset(e,t){this.dispose(),this.gallery=e,this.index=e?.index??0,this.current=t;let n={...t,release:void 0};t.loadFullResolution?this.upgrade(this.index,n,t.loadFullResolution):this.images.set(this.index,Promise.resolve(n)),this.preloadNeighbors()}upgrade(e,t,n){let r=this.generation,i=Promise.resolve().then(()=>r===this.generation?n():null).then(ck).catch(()=>null).then(n=>(n&&r===this.generation&&this.images.get(e)===i&&this.index===e&&(this.current=n,this.notify()),n??t));this.images.set(e,i)}dispose(){this.stopPlayer(),this.generation+=1;for(let e of this.images.values())e.then(e=>e?.release?.());this.images.clear(),this.gallery=void 0,this.current=void 0,this.busy=!1,this.failed=!1}canMove(e){let t=this.index+e;return this.count>1&&t>=0&&t<this.count}async move(e){if(this.busy||!this.canMove(e))return!1;let t=this.generation,n=this.index+e;this.busy=!0,this.failed=!1,this.notify();let r=await this.load(n,!0);return t===this.generation&&(this.busy=!1,this.failed=!r,r&&(this.stopPlayer(),this.index=n,this.current=r,this.preloadNeighbors()),this.notify(),r!==null)}connectPlayer(e,t=!1){let n=this.current;e&&n?.kind===`video`&&this.video!==e&&(this.stopPlayer(),this.video=e,this.videoStatus=`preparing`,n.connectVideo?this.disconnectVideo=n.connectVideo(e,(t,r=!0)=>{this.video===e&&this.current===n&&(this.videoStatus=t===`ready`&&e.readyState<2?`preparing`:t,this.videoRetryable=r,this.notify())},t):e.src=n.src)}updateVideoStatus(e){this.videoStatus=e,this.notify()}stopPlayer(){this.disconnectVideo?.(),this.disconnectVideo=void 0,this.video?.hasAttribute(`src`)&&(this.video.pause(),this.video.removeAttribute(`src`),this.video.load()),this.video=void 0}retryVideo(){let e=this.video;this.stopPlayer(),this.connectPlayer(e,!0)}load(e,t=!1){let n=this.images.get(e);if(n)return n;let r=this.gallery?.items[e];if(!r)return Promise.resolve(null);let i=this.generation,a=Promise.resolve().then(()=>i===this.generation?r(t):null).then(ck).catch(()=>null);return this.images.set(e,a),a.then(t=>{!t&&this.images.get(e)===a&&this.images.delete(e)}),a}preloadNeighbors(){for(let[e,t]of this.images)Math.abs(e-this.index)>1&&(this.images.delete(e),t.then(e=>e?.release?.()));if(this.current?.kind!==`video`)for(let e of[this.index-1,this.index+1])e>=0&&e<this.count&&this.load(e)}}})))()}function mk(e,t){let n=gk.find(({combo:t})=>vn(t,e));if(!n)return!1;let r=t?.getScale()??1;if(t&&r>1){e.preventDefault(),e.stopPropagation();let i=hk/r;t.pan(n.x*i,n.y*i,{relative:!0,animate:!1})}return!0}var hk,gk;function _k(){return(_k=e((()=>{qt(),hk=48,gk=[{combo:Nt.imagePanLeft,x:-1,y:0},{combo:Nt.imagePanRight,x:1,y:0},{combo:Nt.imagePanUp,x:0,y:-1},{combo:Nt.imagePanDown,x:0,y:1}]})))()}var vk;function yk(){return(yk=e((()=>{B(),vk=wa`
  :host {
    --image-lightbox-control-background: rgba(12, 16, 24, 0.64);
    --image-lightbox-control-background-hover: rgba(12, 16, 24, 0.78);
    display: contents;
  }

  :host-context([data-theme-mode="dark"]) {
    --image-lightbox-control-background: rgba(255, 255, 255, 0.16);
    --image-lightbox-control-background-hover: rgba(255, 255, 255, 0.22);
  }

  openclaw-modal-dialog {
    --openclaw-modal-width: 100vw;
    --openclaw-modal-max-width: 100vw;
    --openclaw-modal-max-height: 100dvh;
    --openclaw-modal-backdrop-filter: none;
  }

  .lightbox {
    width: 100vw;
    height: 100dvh;
    display: grid;
    grid-template-rows: minmax(0, 1fr);
    overflow: hidden;
  }

  .header {
    display: contents;
  }

  .actions {
    position: fixed;
    z-index: 1;
    top: max(16px, calc(12px + var(--safe-area-top, 0px)));
    right: max(16px, calc(12px + var(--safe-area-right, 0px)));
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }

  .actions .action,
  .action.zoom-control {
    color: var(--media-foreground);
    background-color: var(--image-lightbox-control-background);
    -webkit-backdrop-filter: blur(16px) saturate(140%);
    backdrop-filter: blur(16px) saturate(140%);
    box-shadow: 0 6px 24px rgba(0, 0, 0, 0.18);
  }

  .actions .action {
    border-radius: 999px;
    transition: background-color 180ms ease;
  }

  .actions .action:hover,
  .zoom-control:hover:not([aria-disabled="true"]) {
    background-color: var(--image-lightbox-control-background-hover);
  }

  .title {
    display: none;
  }

  .action {
    min-height: 36px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0 12px;
    border: 0;
    border-radius: var(--radius-md);
    background: transparent;
    color: #fff;
    font: inherit;
    font-size: 12px;
    font-weight: 650;
    text-decoration: none;
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.85);
  }

  .action:hover {
    background: color-mix(in srgb, var(--text) 10%, transparent);
  }

  .action:focus-visible {
    outline: 2px solid #fff;
    outline-offset: 2px;
  }

  .action:focus:not(:focus-visible) {
    outline: none;
  }

  .open-original {
    min-height: 44px;
  }

  .open-original-icon {
    display: none;
  }

  .close {
    width: 44px;
    height: 44px;
    padding: 0;
    color: rgba(255, 255, 255, 0.82);
  }

  .close svg {
    width: 17px;
    height: 17px;
    /* Shadow DOM: global icon stroke rules don't reach in here; without a
         stroke the open-path x icon renders invisible. */
    fill: none;
    stroke: currentColor;
    stroke-width: 2;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .stage {
    min-height: 0;
    width: 100%;
    height: 100%;
    display: grid;
    place-items: center;
    box-sizing: border-box;
    padding: 20px 20px 72px;
    overflow: hidden;
  }

  .stage--gallery {
    touch-action: none;
  }

  .stage.stage--video {
    padding: calc(76px + var(--safe-area-top, 0px)) calc(64px + var(--safe-area-right, 0px))
      calc(76px + var(--safe-area-bottom, 0px)) calc(64px + var(--safe-area-left, 0px));
    touch-action: pan-y;
  }

  .slide {
    container-type: size;
    width: 100%;
    height: 100%;
    min-height: 0;
    min-width: 0;
    display: grid;
    place-items: center;
  }

  .navigation {
    position: fixed;
    z-index: 1;
    top: 50%;
    width: 44px;
    height: 44px;
    padding: 0;
    border-radius: 50%;
    transform: translateY(-50%);
    color: var(--media-foreground);
    background: var(--image-lightbox-control-background);
  }

  .navigation:hover:not([aria-disabled="true"]) {
    background: var(--image-lightbox-control-background-hover);
  }

  .navigation[aria-disabled="true"] {
    opacity: 0.35;
  }

  .previous {
    inset-inline-start: max(12px, var(--safe-area-left, 0px));
  }

  .next {
    inset-inline-end: max(12px, var(--safe-area-right, 0px));
  }

  .navigation svg {
    width: 20px;
    height: 20px;
  }

  .navigation:dir(rtl) svg {
    transform: scaleX(-1);
  }

  .gallery-counter,
  .gallery-error {
    position: fixed;
    z-index: 1;
    margin: 0;
    padding: 6px 12px;
    border-radius: 999px;
    color: var(--media-foreground);
    background: var(--image-lightbox-control-background);
    font-size: 12px;
    font-variant-numeric: tabular-nums;
  }

  .gallery-counter {
    top: max(24px, calc(20px + var(--safe-area-top, 0px)));
    inset-inline-start: max(16px, calc(12px + var(--safe-area-left, 0px)));
  }

  .gallery-error {
    bottom: max(68px, calc(64px + var(--safe-area-bottom, 0px)));
    left: 50%;
    transform: translateX(-50%);
    max-width: calc(100vw - 48px);
  }

  @media (hover: hover) and (pointer: fine) {
    .navigation {
      opacity: 0;
      transition: opacity 180ms ease;
    }

    .lightbox:hover .navigation,
    .lightbox:focus-within .navigation {
      opacity: 1;
    }

    .lightbox:hover .navigation[aria-disabled="true"],
    .lightbox:focus-within .navigation[aria-disabled="true"] {
      opacity: 0.35;
    }
  }

  .image,
  .video {
    display: block;
    min-width: 0;
    min-height: 0;
    max-width: 100%;
    max-height: 100%;
    height: auto;
    object-fit: contain;
  }

  .image {
    width: auto;
    cursor: zoom-in;
    -webkit-user-drag: none;
  }

  .video {
    width: min(1280px, 100%);
    background: var(--media-bg);
  }

  .image.zoomed {
    cursor: grab;
  }

  .zoom-controls {
    position: fixed;
    z-index: 1;
    bottom: max(14px, calc(10px + var(--safe-area-bottom, 0px)));
    left: 50%;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    transform: translateX(-50%);
  }

  .zoom-control {
    min-width: 40px;
    min-height: 40px;
    padding: 0 10px;
    border: 0;
    font-size: 15px;
  }

  .zoom-control[aria-disabled="true"] {
    color: rgba(255, 255, 255, 0.8);
  }

  .zoom-level {
    min-width: 58px;
    font-size: 11px;
  }

  @media (max-width: 768px),
    (max-width: 932px) and (max-height: 500px) and (orientation: landscape) {
    .stage {
      padding: calc(68px + var(--safe-area-top, 0px)) calc(12px + var(--safe-area-right, 0px))
        calc(64px + var(--safe-area-bottom, 0px)) calc(12px + var(--safe-area-left, 0px));
    }

    .open-original {
      width: 44px;
      padding: 0;
    }

    .open-original-label {
      display: none;
    }

    .open-original-icon {
      display: inline-flex;
    }

    .open-original-icon svg {
      width: 17px;
      height: 17px;
    }

    .zoom-control {
      min-width: 44px;
      min-height: 44px;
    }
  }

  @media (prefers-reduced-motion: reduce) {
    openclaw-modal-dialog {
      --show-duration: 0ms;
      --hide-duration: 0ms;
    }

    .actions .action,
    .navigation {
      transition: none;
    }
  }
`})))()}function bk(e){return e.split(`;`,1)[0]?.trim().toLowerCase()??``}function xk(e){let t=/^data:([^,]*)/i.exec(e)?.[1];return t===void 0?void 0:bk(t)}function Sk(e,t,n,r,i){return R`<button
    class=${`action `+e}
    type="button"
    aria-label=${j(t)}
    aria-disabled=${n}
    @click=${r}
  >
    ${i}
  </button>`}var Ck,wk,Tk,Ek,Dk,Ok,kk,$;function Ak(){return(Ak=e((()=>{Yc(),B(),H(),F(),M(),L(),pk(),_k(),yk(),tr(),Ck=new Set([`image/avif`,`image/gif`,`image/jpeg`,`image/png`,`image/webp`]),wk=4,Tk=2.5,Ek=56,Dk=8,Ok=180,kk=[`src`,`originalSrc`,`gallery`,`loadFullResolution`,`connectVideo`,`imageWidth`,`imageHeight`,`mediaKind`],$=class extends Ut{constructor(...e){super(...e),this.mediaKind=`image`,this.src=``,this.originalSrc=``,this.imageTitle=``,this.openOriginalUrl=``,this.resolvingOriginal=!1,this.originalBlobUrl=``,this.originalUrlRequest=0,this.scale=1,this.imageReady=!1,this.galleryController=new fk(()=>this.requestUpdate()),this.displayedIndex=0,this.displayedSource=``,this.touchPointers=new Set,this.suppressDoubleClick=!1,this.handleImageLoad=e=>{let t=e.currentTarget;t instanceof HTMLImageElement&&t===this.image&&this.initializePanzoom(t)},this.handleImageError=e=>{e.currentTarget===this.image&&(this.destroyPanzoom(),this.scale=1)},this.handlePanzoomChange=e=>{if(!(e instanceof CustomEvent))return;let t=e.detail;typeof t==`object`&&t&&`scale`in t&&typeof t.scale==`number`&&(this.scale=t.scale)},this.handleWheel=e=>{this.panzoom&&(e.preventDefault(),this.panzoom.zoomWithWheel(e))},this.handleDoubleClick=e=>{if(this.panzoom&&!this.suppressDoubleClick){if(e.preventDefault(),this.scale>1){this.resetZoom();return}this.panzoom?.zoomToPoint(Tk,e)}},this.handleStagePointerDown=e=>{if(e.pointerType===`touch`&&(this.touchPointers.add(e.pointerId),this.touchPointers.size>1)){this.cancelSwipe(),this.backdropPointer=void 0;return}this.suppressDoubleClick=!1;let t=e.currentTarget;if(e.button!==0||!e.isPrimary||!(t instanceof HTMLElement)){this.backdropPointer=void 0;return}let n=e.target===t||e.target===this.slide;this.backdropPointer=n?{pointerId:e.pointerId,clientX:e.clientX,clientY:e.clientY}:void 0,e.pointerType===`touch`&&this.hasGallery&&!this.galleryController.busy&&this.scale<=1&&(this.mediaKind!==`video`||lk(this.video,e))?(this.slideAnimation?.cancel(),this.swipe={pointerId:e.pointerId,x:e.clientX,y:e.clientY,offset:0,horizontal:!1},this.mediaKind!==`video`&&t.setPointerCapture(e.pointerId)):n&&t.setPointerCapture?.(e.pointerId)},this.handleStagePointerMove=e=>{let t=this.swipe;if(!t||t.pointerId!==e.pointerId)return;if(this.scale>1||this.touchPointers.size!==1){this.cancelSwipe();return}let n=e.clientX-t.x,r=e.clientY-t.y;if(!t.horizontal){if(Math.max(Math.abs(n),Math.abs(r))<Dk)return;if(this.backdropPointer=void 0,this.suppressDoubleClick=!0,Math.abs(r)>=Math.abs(n)){this.cancelSwipe();return}t.horizontal=!0,this.stage?.setPointerCapture(e.pointerId)}let i=n*this.direction<0?1:-1;t.offset=this.galleryController.canMove(i)?n:n*.2,this.slide&&(this.slide.style.transform=`translateX(${t.offset}px)`)},this.handleStagePointerUp=e=>{this.touchPointers.delete(e.pointerId);let t=this.swipe;if(t?.pointerId===e.pointerId&&(this.swipe=void 0,t.horizontal)){this.backdropPointer=void 0;let e=t.offset*this.direction<0?1:-1;Math.abs(t.offset)>=Ek&&this.scale<=1&&this.galleryController.canMove(e)?this.navigate(e,t.offset):this.animateSlide(t.offset);return}let n=this.backdropPointer;this.backdropPointer=void 0;let r=this.shadowRoot?.elementFromPoint?.(e.clientX,e.clientY);e.button===0&&e.isPrimary&&n?.pointerId===e.pointerId&&(r===this.stage||r===this.slide)&&Math.hypot(e.clientX-n.clientX,e.clientY-n.clientY)<=4&&this.emitClose()},this.handleStagePointerCancel=e=>{this.touchPointers.delete(e.pointerId),this.backdropPointer=void 0,this.cancelSwipe()},this.handleMotionPreferenceChange=e=>{this.panzoom?.setOptions({duration:e.matches?0:200}),e.matches&&this.slideAnimation?.cancel()},this.zoomIn=()=>this.panzoom?.zoomIn(),this.zoomOut=()=>this.panzoom?.zoomOut(),this.resetZoom=()=>this.panzoom?.reset({animate:!1}),this.handleKeydown=e=>{if(e.key===`Escape`&&uk(this.video,e)||mk(e,this.panzoom))return;let t=e.composedPath().some(e=>e instanceof HTMLVideoElement);if(this.hasGallery&&!t&&!e.shiftKey&&!e.altKey&&!e.ctrlKey&&!e.metaKey&&(e.key===`ArrowLeft`||e.key===`ArrowRight`)){e.preventDefault(),e.stopPropagation(),this.navigate((e.key===`ArrowRight`?1:-1)*this.direction);return}let n=e.key===`+`||e.key===`=`?this.zoomIn:e.key===`-`?this.zoomOut:e.key===`0`?this.resetZoom:void 0;if(this.panzoom&&n){e.preventDefault(),n();return}dk(e,this.focusables)},this.emitClose=e=>{e?.type===`modal-cancel`&&uk(this.video,e)||(this.galleryController.stopPlayer(),this.dispatchEvent(new CustomEvent(`image-lightbox-close`,{bubbles:!0,composed:!0})))}}get currentImage(){return this.galleryController.current}get hasGallery(){return this.galleryController.count>1}get direction(){return getComputedStyle(this).direction===`rtl`?-1:1}static{this.styles=vk}connectedCallback(){super.connectedCallback(),this.motionQuery=globalThis.matchMedia?.(`(prefers-reduced-motion: reduce)`),this.motionQuery?.addEventListener(`change`,this.handleMotionPreferenceChange),this.hasUpdated&&(this.resetGallery(),this.requestUpdate(),this.resolveOriginalUrl(),this.updateComplete.then(()=>{if(!this.isConnected)return;let e=this.image;e?.complete&&e.naturalWidth>0&&this.initializePanzoom(e)}))}disconnectedCallback(){this.galleryController.dispose(),this.cancelSwipe(),this.touchPointers.clear(),this.slideAnimation?.cancel(),this.motionQuery?.removeEventListener(`change`,this.handleMotionPreferenceChange),this.motionQuery=void 0,this.destroyPanzoom(),this.originalUrlRequest+=1,this.revokeOriginalBlobUrl(),super.disconnectedCallback()}resetGallery(){this.galleryController.reset(this.gallery,{kind:this.mediaKind,connectVideo:this.connectVideo,src:this.src,originalSrc:this.originalSrc,title:this.imageTitle,width:this.imageWidth,height:this.imageHeight,loadFullResolution:this.loadFullResolution})}willUpdate(e){this.isConnected&&kk.some(t=>e.has(t))&&(this.cancelSwipe(),this.resetGallery())}updated(e){if(!this.isConnected)return;let t=kk.some(t=>e.has(t))||this.displayedIndex!==this.galleryController.index;t&&(this.displayedIndex=this.galleryController.index,this.destroyPanzoom(),this.scale=1),this.galleryController.connectPlayer(this.video);let n=this.video?.getAttribute(`src`)??this.currentImage?.src??this.src;(t||this.displayedSource!==n)&&(this.displayedSource=n,this.resolveOriginalUrl(),this.image?.complete&&this.image.naturalWidth>0&&this.initializePanzoom(this.image))}render(){let e=(this.hasGallery?this.currentImage?.title??this.imageTitle:this.imageTitle).trim()||j(`chat.imageLightbox.untitled`),t=this.mediaKind===`video`?j(`chat.mediaPlayer.videoPreview`,{title:e}):j(`chat.imageLightbox.label`,{title:e}),n=this.mediaKind===`video`?j(`chat.mediaPlayer.closeVideoPreview`):j(`chat.imageLightbox.close`),r=this.imageReady&&this.panzoom!==void 0,i=this.currentImage?.width,a=this.currentImage?.height,o=Number.isFinite(i)&&i>0&&Number.isFinite(a)&&a>0?`width: min(${i}px, 100cqw, calc(100cqh * ${i/a}))`:z;return R`
      <openclaw-modal-dialog
        class="mobile-edge-to-edge viewport-edge-to-edge"
        label=${t}
        @modal-cancel=${this.emitClose}
        @keydown=${{handleEvent:this.handleKeydown,capture:!0}}
      >
        <section class="lightbox">
          <header class="header">
            <strong class="title">${e}</strong>
            <div class="actions">
              ${this.openOriginalUrl||this.hasGallery&&this.resolvingOriginal?R`
                      <a
                        class="action open-original"
                        href=${this.openOriginalUrl||z}
                        aria-disabled=${!this.openOriginalUrl}
                        tabindex=${this.openOriginalUrl?0:-1}
                        target="_blank"
                        rel="noreferrer"
                        aria-label=${j(`chat.imageLightbox.openOriginal`)}
                      >
                        <span class="open-original-label">
                          ${j(`chat.imageLightbox.openOriginal`)}
                        </span>
                        <span class="open-original-icon" aria-hidden="true">
                          ${I.externalLink}
                        </span>
                      </a>
                    `:z}
              <button
                class="action close"
                type="button"
                autofocus
                aria-label=${n}
                @click=${this.emitClose}
              >
                ${I.x}
              </button>
            </div>
          </header>
          <div
            class=${this.mediaKind===`video`?`stage stage--video`:this.hasGallery?`stage stage--gallery`:`stage`}
            @pointerdown=${{handleEvent:this.handleStagePointerDown,capture:!0}}
            @pointermove=${this.handleStagePointerMove}
            @pointerup=${this.handleStagePointerUp}
            @pointercancel=${this.handleStagePointerCancel}
            @dblclick=${this.handleDoubleClick}
          >
            ${this.mediaKind===`video`?R`<video
                    class="video"
                    @loadeddata=${()=>this.galleryController.updateVideoStatus(`ready`)}
                    @playing=${()=>this.galleryController.updateVideoStatus(`ready`)}
                    @error=${()=>this.galleryController.updateVideoStatus(`unavailable`)}
                    aria-label=${e}
                    controls
                    autoplay
                    playsinline
                    tabindex="0"
                  ></video>`:R`<div class="slide">
                    <img
                      class=${this.scale>1?`image zoomed`:`image`}
                      style=${o}
                      src=${this.currentImage?.src??this.src}
                      alt=${e}
                      referrerpolicy="no-referrer"
                      @load=${this.handleImageLoad}
                      @error=${this.handleImageError}
                      @dragstart=${e=>e.preventDefault()}
                    />
                  </div>`}
          </div>
          ${this.hasGallery?R`
                  ${Sk(`navigation previous`,this.mediaKind===`video`?`common.previous`:`chat.imageLightbox.previous`,!this.galleryController.canMove(-1)||this.galleryController.busy,()=>this.navigate(-1),I.chevronLeft)}
                  ${Sk(`navigation next`,this.mediaKind===`video`?`common.next`:`chat.imageLightbox.next`,!this.galleryController.canMove(1)||this.galleryController.busy,()=>this.navigate(1),I.chevronRight)}
                  <p
                    class="gallery-counter"
                    dir="ltr"
                    role="status"
                    aria-live="polite"
                    aria-atomic="true"
                  >
                    ${j(`chat.imageLightbox.position`,{current:String(this.galleryController.index+1),total:String(this.galleryController.count)})}
                  </p>
                  ${this.galleryController.failed?R`<p class="gallery-error" role="alert">${j(`chat.imageLightbox.loadFailed`)}</p>`:z}
                `:z}
          ${this.mediaKind===`video`&&this.galleryController.videoStatus!==`ready`?R`<p class="gallery-error" role="status">
                  ${this.galleryController.videoStatus===`preparing`?j(`chat.mediaPlayer.preparing`):j(`chat.attachments.previewUnavailable`)}
                  ${this.galleryController.videoStatus===`unavailable`&&this.galleryController.videoRetryable?R`<button class="action" @click=${()=>this.galleryController.retryVideo()}>${j(`common.retry`)}</button>`:z}
                </p>`:z}
          ${this.mediaKind===`image`?R`<div class="zoom-controls">
                  ${Sk(`zoom-control`,`chat.imageLightbox.zoomOut`,!r||this.scale<=1,this.zoomOut,`−`)}
                  ${Sk(`zoom-control zoom-level`,`chat.imageLightbox.resetZoom`,!r||this.scale===1,this.resetZoom,R`${Math.round(this.scale*100)}%`)}
                  ${Sk(`zoom-control`,`chat.imageLightbox.zoomIn`,!r||this.scale>=wk,this.zoomIn,`+`)}
                </div>`:z}
        </section>
      </openclaw-modal-dialog>
    `}initializePanzoom(e){let t=this.stage;this.isConnected&&e.isConnected&&t&&e===this.image&&(e!==this.panzoomImage||t!==this.panzoomStage)&&(this.destroyPanzoom(),this.panzoomImage=e,this.panzoomStage=t,this.panzoom=Hc(e,{duration:this.motionQuery?.matches?0:200,maxScale:wk,minScale:1,panOnlyWhenZoomed:!0}),e.addEventListener(`panzoomchange`,this.handlePanzoomChange),t.addEventListener(`wheel`,this.handleWheel,{passive:!1}),this.imageReady=!0)}destroyPanzoom(){let e=this.panzoomImage;e?.removeEventListener(`panzoomchange`,this.handlePanzoomChange),this.panzoomStage?.removeEventListener(`wheel`,this.handleWheel),this.panzoom?.destroy(),this.panzoom?.resetStyle(),e?.style.removeProperty(`transform`),e?.style.removeProperty(`transition`),this.panzoom=void 0,this.panzoomImage=void 0,this.panzoomStage=void 0,this.imageReady=!1}cancelSwipe(){let e=this.swipe?.offset??0;this.swipe=void 0,this.animateSlide(e)}animateSlide(e){this.slideAnimation?.cancel();let t=this.slide;t&&(t.style.removeProperty(`transform`),e&&!this.motionQuery?.matches&&this.isConnected&&(this.slideAnimation=t.animate([{transform:`translateX(${e}px)`},{transform:`translateX(0)`}],{duration:Ok,easing:`ease-out`})))}async navigate(e,t=0){if(!this.hasGallery||!this.galleryController.canMove(e)){this.animateSlide(t);return}this.video?.pause();let n=await this.galleryController.move(e);this.isConnected&&(await this.updateComplete,this.animateSlide(n?e*this.direction*(this.stage?.clientWidth??0):t))}revokeOriginalBlobUrl(){this.originalBlobUrl&&=(URL.revokeObjectURL(this.originalBlobUrl),``)}async resolveOriginalUrl(){let e=++this.originalUrlRequest;if(this.revokeOriginalBlobUrl(),this.resolvingOriginal=!1,this.currentImage?.loadFullResolution){this.openOriginalUrl=``;return}let t=this.currentImage,n=(t?.connectVideo?this.video?.getAttribute(`src`)??``:t?.originalSrc||t?.src||this.originalSrc||this.src).trim();if(!n){this.openOriginalUrl=``;return}let r=n.slice(0,5).toLowerCase(),i=r===`data:`,a=r===`blob:`;if(!i&&!a){this.openOriginalUrl=n;return}this.openOriginalUrl=``;let o=i?xk(n):void 0;if(!i||o&&Ck.has(o)){this.resolvingOriginal=!0;try{let t=await(await fetch(n)).blob();if(!this.isConnected||e!==this.originalUrlRequest||!Ck.has(bk(t.type)))return;if(a){this.openOriginalUrl=n;return}this.originalBlobUrl=URL.createObjectURL(t),this.openOriginalUrl=this.originalBlobUrl}catch{}finally{e===this.originalUrlRequest&&(this.resolvingOriginal=!1)}}}},w([W({attribute:!1})],$.prototype,`connectVideo`,void 0),w([W({attribute:!1})],$.prototype,`gallery`,void 0),w([W({attribute:!1})],$.prototype,`loadFullResolution`,void 0),w([W()],$.prototype,`mediaKind`,void 0),w([W()],$.prototype,`src`,void 0),w([W()],$.prototype,`originalSrc`,void 0),w([W({attribute:!1})],$.prototype,`imageTitle`,void 0),w([W({attribute:!1})],$.prototype,`imageWidth`,void 0),w([W({attribute:!1})],$.prototype,`imageHeight`,void 0),w([_a(`.slide`)],$.prototype,`slide`,void 0),w([_a(`.stage`)],$.prototype,`stage`,void 0),w([_a(`.video`)],$.prototype,`video`,void 0),w([_a(`.image`)],$.prototype,`image`,void 0),w([Sa(`.action, video[controls]`)],$.prototype,`focusables`,void 0),w([V()],$.prototype,`openOriginalUrl`,void 0),w([V()],$.prototype,`resolvingOriginal`,void 0),w([V()],$.prototype,`scale`,void 0),w([V()],$.prototype,`imageReady`,void 0),customElements.get(`openclaw-image-lightbox`)||customElements.define(`openclaw-image-lightbox`,$)})))()}function jk(e){let{snapshot:t,session:n,batchRows:r=null,cloudWorkerStopAction:i}=e,a=e=>{let n=on(t,e);return n.allowed?void 0:n.reason},o=a({method:`sessions.setInvolvement`,requiredScope:`operator.read`}),s=(e,t=!1)=>a({method:`sessions.patch`,params:{key:n.key,...e},sessionScope:t,session:n}),c=s({label:null},!0),l=s({pinned:!0},!0),u=s({icon:null}),d=s({color:null}),f=r?ct(r):n,p=(e,t=!1)=>r?a({method:`sessions.patchMany`,sessionScope:t,session:f,params:{patch:e}}):s(e,t),m=p({unread:!0}),h=p({category:null}),g=(r??[n]).some(e=>!e.sessionId?.trim())?`Session lifecycle action requires a durable session identity.`:p({archived:!0},!0),_=a({method:`sessions.groups.put`,requiredScope:`operator.write`}),v=(r??[n]).map(e=>a({method:`sessions.delete`,params:{key:e.key,...e.sessionId?{expectedSessionId:e.sessionId}:{},...e.archived?{archivedOnly:!0}:{}}})).find(e=>!!e),y=r?void 0:a({method:`sessions.create`,params:{parentSessionKey:n.key,fork:!0}}),b=i?a(i):void 0;return{...l?{"toggle-pin":l}:{},...c?{rename:c}:{},...u?{"set-icon":u}:{},...d?{"set-color":d}:{},...n.pinnable===!1?{"toggle-pin":j(`sessionsView.pinRootSessionsOnly`)}:{},...m?{"toggle-unread":m}:{},...o?{"toggle-involving-me":o}:{},...h?{"move-to-group":h}:{},...g?{"toggle-archived":g}:{},..._||h?{"new-group":_??h}:{},...y?{fork:y}:{},...b?{"stop-cloud-worker":b}:{},...v?{delete:v}:{}}}function Mk(){return(Mk=e((()=>{F(),Re()})))()}function Nk(e){let t=new CustomEvent(Kk,{detail:e,cancelable:!0});return window.dispatchEvent(t),t.defaultPrevented?`accepted`:t.rejection?`rejected`:`unhandled`}function Pk(e){return Math.min(1,Math.max(0,e))}function Fk(e){if(e.points.length===0)return null;let t=1,n=1,r=0,i=0;for(let a of e.points)t=Math.min(t,Pk(a.x)),n=Math.min(n,Pk(a.y)),r=Math.max(r,Pk(a.x)),i=Math.max(i,Pk(a.y));return{x:t,y:n,width:r-t,height:i-n}}function Ik(e){return String(Math.round(Pk(e)*100))}function Lk(e,t){return h(e.replace(/\s+/g,` `).trim(),t)}function Rk(e){let t=Lk(e,Jk);try{let e=new URL(t);return!e.username&&!e.password?t:(e.username=``,e.password=``,h(e.href,Jk))}catch{let e=t.replace(/^([a-z][a-z\d+.-]*:\/\/)[^/?#\s]*@/i,`$1`);return h(e,Jk)}}function zk(e){try{let t=new URL(e).hostname;if(t)return Lk(t,Yk)}catch{}return h(e,Yk)}function Bk(e,t=40){return e.replace(/[^\w-]/g,``).slice(0,t)}function Vk(e){let t=e.classes.slice(0,3).map(e=>Bk(e)).filter(e=>e.length>0).map(e=>`.${e}`).join(``),n=Bk(e.tag)||`element`,r=Bk(e.id),i=`${n}${r?`#${r}`:``}${t}`,a=Lk(e.name,qk);return`${i}${a?` "${a}"`:``}${e.role?` (role=${Lk(e.role,40)})`:``}`}function Hk(e){let t=Rk(e.url),n=Lk(e.title,qk),r=zk(t),i=e.strokes.flatMap(e=>Fk(e)??[]),a=e.element?{descriptor:Vk(e.element),width:String(Math.round(e.element.rect.width)),height:String(Math.round(e.element.rect.height)),x:String(Math.round(e.element.rect.x)),y:String(Math.round(e.element.rect.y))}:null,o=[n?j(`browser.annotatePrompt.introTitled`,{url:t,title:n}):j(`browser.annotatePrompt.introUntitled`,{url:t})];return e.browserTab&&o.push(j(`browser.annotatePrompt.browserTarget`,{target:JSON.stringify(e.browserTab)})),i.slice(0,Xk).forEach((e,t)=>{o.push(j(`browser.annotatePrompt.region`,{index:String(t+1),x:Ik(e.x+e.width/2),y:Ik(e.y+e.height/2),width:Ik(e.width),height:Ik(e.height)}))}),i.length>Xk&&o.push(j(`browser.annotatePrompt.moreRegions`,{count:String(i.length-Xk)})),a&&o.push(j(`browser.annotatePrompt.elementDetail`,a)),o.push(j(`browser.annotatePrompt.outro`)),{modelContext:o.join(`
`),card:{title:n||h(r,qk),displayUrl:r,markedRegionCount:i.length,inspectedElement:a!==null}}}function Uk(e){return Math.max(4,Math.round(e*.005))}function Wk(e,t){e.lineCap=`round`,e.lineJoin=`round`,e.strokeStyle=Zk,e.lineWidth=Uk(t.width);for(let n of t.strokes)if(n.points.length!==0){if(e.beginPath(),n.points.forEach((n,r)=>{let i=Pk(n.x)*t.width,a=Pk(n.y)*t.height;r===0?e.moveTo(i,a):e.lineTo(i,a)}),n.points.length===1){let r=n.points[0];r&&e.lineTo(Pk(r.x)*t.width+.1,Pk(r.y)*t.height)}e.stroke()}if(t.highlight){let{x:n,y:r,width:i,height:a}=t.highlight;e.strokeRect(Pk(n)*t.width,Pk(r)*t.height,Math.max(2,i*t.width),Math.max(2,a*t.height))}}function Gk(e){let t=document.createElement(`canvas`);t.width=e.width,t.height=e.height;let n=t.getContext(`2d`);if(!n)throw Error(j(`browser.errors.canvasUnavailable`));return n.drawImage(e.image,0,0,e.width,e.height),Wk(n,e),t.toDataURL(`image/png`)}var Kk,qk,Jk,Yk,Xk,Zk;function Qk(){return(Qk=e((()=>{F(),ts(),yo(),Kk=`openclaw:browser-annotation`,qk=80,Jk=500,Yk=160,Xk=8,Zk=`#e0442d`})))()}async function $k(e,t){if(t===null)return[];if(t!==void 0)try{return[await e.request(`environments.status`,{environmentId:t})]}catch(e){if(e instanceof Xn&&e.code===`INVALID_REQUEST`&&e.message===`unknown environmentId`)return[];throw e}return(await e.request(`environments.list`,{})).environments}async function eA(e,t){let n=await t.target;if(!t.isCurrent())return;let r=await $k(e,n);if(!t.isCurrent())return;let i=r.find(e=>e.id===n);if(i?.status===`starting`)return{environments:[i],selectedSource:void 0,pendingSource:i.id};if(i?.status===`error`||!t.recoverToPicker&&i&&i.status!==`available`)throw Error(i.worker?.error??`Desktop environment is unavailable`);if(!(t.recoverToPicker&&n!==void 0&&!r.some(e=>e.id===n&&e.desktop)&&(r=await $k(e,void 0),!t.isCurrent())))return{selectedSource:r.find(e=>e.id===n&&e.status===`available`&&e.desktop===!0)?.id,environments:r.filter(e=>e.desktop===!0)}}function tA(e){return e.id===`gateway`?{kind:`host`}:e.id.startsWith(`node:`)&&e.id.length>5?{kind:`node`,nodeId:e.id.slice(5)}:{kind:`environment`,environmentId:e.id}}function nA(){return(nA=e((()=>{li()})))()}var rA;function iA(){return(iA=e((()=>{Vo(),rA=class{constructor(e,t){this.host=e,this.options=t,this.connected=!1,this.store=null,this.stopUpdates=null,this.client=null,this.hello=null,this.retry=()=>{this.target?.sessionKey&&this.store?.load(this.target).catch(()=>void 0)},this.refresh=e=>{this.connected&&(this.synchronize(),this.target&&this.store?.refresh(this.target,e))},this.dismiss=e=>this.target?this.store?.dismiss(this.target,e)??Promise.resolve(!1):Promise.resolve(!1),this.handleStoreUpdate=()=>{let e=this.presentation,t=this.readPresentation();this.presentation=t,t&&(!e||t.card!==e.card||t.error!==e.error||t.refreshState!==e.refreshState||t.client!==e.client||t.hello!==e.hello||t.phase!==e.phase)&&this.host.requestUpdate()},e.addController(this)}get card(){return this.target?this.store?.get(this.target)??null:null}get lifetime(){return this.target?this.store?.getLifetime(this.target):void 0}get loading(){return!this.target||this.store?.get(this.target)===void 0}get error(){return this.target?this.store?.getError(this.target):void 0}get refreshState(){return this.target?this.store?.getRefreshState(this.target):void 0}hostConnected(){this.connected=!0,this.synchronize()}hostUpdate(){this.connected&&this.synchronize()}hostDisconnected(){this.connected=!1,this.release()}readPresentation(){let e=this.options.gateway()?.snapshot;return this.target?{card:this.store?.get(this.target),error:this.error,refreshState:this.refreshState,client:e?.client,hello:e?.hello,phase:e?.phase}:void 0}synchronize(){let e=this.options.gateway()??null,t=this.options.target()??void 0,n=e?.snapshot.client??null,r=e?.snapshot.hello??null,i=e?Ec(e):null;i!==this.store&&(this.release(),this.store=i,this.stopUpdates=i?.subscribe(this.handleStoreUpdate)??null),(t?.sessionKey!==this.target?.sessionKey||t?.agentId!==this.target?.agentId||t&&(n!==this.client||r!==this.hello))&&(this.target=t,this.client=n,this.hello=r,this.store?.watch(this,t?[t]:[],{admitAutomaticRead:()=>{let i=this.options.target();return this.connected&&this.options.gateway()===e&&e?.snapshot.client===n&&e?.snapshot.hello===r&&i?.sessionKey===t?.sessionKey&&i?.agentId===t?.agentId}}),this.presentation=this.readPresentation())}release(){this.store?.unwatch(this),this.stopUpdates?.(),this.stopUpdates=null,this.store=null,this.target=void 0,this.client=null,this.hello=null,this.presentation=void 0}}})))()}function aA(e){let t=e.busy||e.disabled===!0;return R`
    <form class="mcp-server-form" @submit=${t=>{t.preventDefault();let n=t.currentTarget,r=new FormData(n),i=r.get(`mcp-name`),a=r.get(`mcp-transport`),o=r.get(`mcp-target`);e.onSubmit({name:typeof i==`string`?i.trim():``,transport:a===`sse`||a===`stdio`?a:`streamable-http`,target:typeof o==`string`?o.trim():``})}}>
      <label>
        <span>${j(`mcpServers.nameLabel`)}</span>
        <input
          name="mcp-name"
          class="settings-input"
          type="text"
          required
          placeholder="context7"
          autocomplete="off"
          ?autofocus=${e.autofocus??!1}
          title=${e.blockedReason??``}
          ?disabled=${t}
        />
      </label>
      <label>
        <span>${j(`mcpServers.transportLabel`)}</span>
        <select
          name="mcp-transport"
          class="settings-select"
          title=${e.blockedReason??``}
          ?disabled=${t}
        >
          <option value="streamable-http">${j(`mcpServers.transportStreamableHttp`)}</option>
          <option value="sse">${j(`mcpServers.transportSse`)}</option>
          <option value="stdio">${j(`mcpServers.transportStdio`)}</option>
        </select>
      </label>
      <label class="mcp-server-form__target">
        <span>${j(`mcpServers.targetLabel`)}</span>
        <input
          name="mcp-target"
          class="settings-input"
          type="text"
          required
          placeholder="https://mcp.example.com/mcp  ·  npx some-mcp-server"
          autocomplete="off"
          title=${e.blockedReason??``}
          ?disabled=${t}
        />
      </label>
      <div class="mcp-server-form__actions">
        <button
          type="submit"
          class="btn btn--sm"
          title=${e.blockedReason??``}
          ?disabled=${t}
        >
          ${e.busy?j(`mcpServers.adding`):j(`mcpServers.add`)}
        </button>
        <button type="button" class="btn btn--sm" ?disabled=${e.busy} @click=${e.onCancel}>
          ${j(`common.cancel`)}
        </button>
      </div>
    </form>
  `}function oA(){return(oA=e((()=>{B(),F(),Go(),Yo()})))()}function sA(e,t={}){let n=[`settings-page`,t.wide?`settings-page--wide`:``,t.carapace?`oc-app-surface`:``].filter(Boolean).join(` `);return R`<div
    class=${n}
    ${Wi({settingsPage:!0,settingsWide:t.wide})}
  >
    ${e}
  </div>`}function cA(e,t){return R`<a href=${e} target=${Sc} rel=${Es()}
    >${t}</a
  >`}function lA(e){let t=e.icon===`info`?I.info:I.circleQuestionMark;return R`
    <openclaw-tooltip .content=${e.tooltip}>
      <button
        id=${e.id}
        type="button"
        class="settings-section__help-button"
        aria-label=${e.label}
        aria-controls=${e.popoverId}
        aria-haspopup="dialog"
      >
        <span aria-hidden="true">${t}</span>
      </button>
    </openclaw-tooltip>
  `}function uA(e){return R`<a
    class="learn-more-link"
    href=${e}
    target=${Sc}
    rel=${Es()}
    >${j(`common.learnMore`)}</a
  >`}function dA(e){return R`
    <section
      class="content-header content-header--settings"
      ${Wi({toolbarHeader:!0})}
    >
      <div>
        <h1 class="page-title">${e.title}</h1>
        ${e.subtitle?R`<div class="page-subtitle">${e.subtitle}</div>`:z}
      </div>
      ${e.actions&&e.actions!==z?R`<div class="page-header-actions">${e.actions}</div>`:z}
    </section>
  `}function fA(e,t){let n=e.description?R`<p class="settings-section__desc">${e.description}</p>`:z,r=e.title||e.description?R`
          <div
            class="settings-section__copy ${e.carapace?`oc-settings-section-heading`:``}"
          >
            ${e.title?R`
                    <h2
                      class="settings-section__heading ${e.carapace?`oc-settings-section-title`:``}"
                    >
                      ${e.title}${e.count===void 0?z:R` <span class="settings-count">${e.count}</span>`}
                    </h2>
                  `:z}
            ${n}
          </div>
        `:z,i=r||e.actions?R`
          <div
            class="settings-section__header ${e.carapace?`oc-settings-section-header`:``}"
          >
            ${r}
            ${e.actions?R`<div class="settings-section__actions">${e.actions}</div>`:z}
          </div>
        `:z;return R`
    <section class="settings-section ${e.carapace?`oc-settings-section`:``}">
      ${i} ${e.notice??z} ${mA(t,e)}
    </section>
  `}function pA(e){return R`<dl class="settings-summary">
    ${e.map(e=>R`<div class="settings-group settings-summary__tile">
        <dt>${e.label}</dt>
        <dd>${e.value}</dd>
      </div>`)}
  </dl>`}function mA(e,t={}){let n=[`settings-group`,t.danger?`settings-group--danger`:``,t.carapace?`oc-settings-group`:``].filter(Boolean).join(` `);return R`<div class=${n}>${e}</div>`}function hA(e,t,n=!1){return R`
    <div class="settings-row__text ${n?`oc-settings-row-content`:``}">
      <span class="settings-row__title ${n?`oc-settings-row-title`:``}">${e}</span>
      ${t?R`<span class="settings-row__desc ${n?`oc-settings-row-description`:``}"
              >${t}</span
            >`:z}
    </div>
  `}function gA(e){let t=[`settings-row`,e.stacked?`settings-row--stacked`:``,e.stackedOnNarrow?`settings-row--stacked-on-narrow`:``,e.carapace?`oc-settings-row${e.stacked?` oc-settings-row-stacked`:``}`:``].filter(Boolean).join(` `);return R`
    <div class=${t} role=${e.role??z}>
      ${hA(e.title,e.description,e.carapace)}
      ${e.control!==void 0&&e.control!==z?R`<div
              class="settings-row__control ${e.carapace?`oc-settings-row-control`:``}"
            >
              ${e.control}
            </div>`:z}
    </div>
  `}function _A(e){return R`
    <button type="button" class="settings-row settings-row--nav" @click=${e.onClick}>
      ${hA(e.title,e.description)}
      <div class="settings-row__control">
        ${e.control??z}
        <span class="settings-row__chevron">${I.chevronRight}</span>
      </div>
    </button>
  `}function vA(e){return R`
    <wa-switch
      class="settings-toggle"
      size="s"
      .checked=${Ta(e.checked)}
      ?disabled=${e.disabled??!1}
      aria-disabled=${e.ariaDisabled?`true`:`false`}
      @change=${t=>{let n=t.currentTarget;e.onChange(n.checked)===!1&&(n.checked=e.checked)}}
    >
      <span class="settings-control__sr-label">${e.ariaLabel}</span>
    </wa-switch>
  `}function yA(e){let t=t=>{if(!t.composedPath().some(e=>e instanceof HTMLInputElement)||t instanceof KeyboardEvent&&t.key!==`ArrowLeft`&&t.key!==`ArrowRight`)return;let n=t.currentTarget.checked;n!==e.checked&&e.onAct?.(n)};return R`
    <div
      class="settings-row settings-row--toggle"
      @click=${t=>{let n=t.target;if(e.disabled||n instanceof Element&&n.closest(`wa-switch`)!==null)return;let r=!e.checked;e.onAct?.(r),e.onChange(r)}}
    >
      ${e.icon??z} ${hA(e.title,e.description)}
      <div class="settings-row__control">
        <wa-switch
          class="settings-toggle"
          size="s"
          .checked=${Ta(e.checked)}
          ?disabled=${e.disabled??!1}
          @click=${t}
          @keydown=${t}
          @change=${t=>{let n=t.currentTarget;e.onChange(n.checked)===!1&&(n.checked=e.checked)}}
        >
          <span class="settings-control__sr-label">${e.ariaLabel??e.title}</span>
        </wa-switch>
      </div>
    </div>
  `}function bA(e,t){return t?R`${j(`configForm.defaultValue`,{value:e})}`:void 0}function xA(e){return e.mode===`buttons`?R`<div
      class="settings-segmented ${e.variant?`settings-segmented--${e.variant}`:``} ${e.className??``}"
      role=${e.ariaLabel?`group`:z}
      aria-label=${e.ariaLabel??z}
    >
      ${e.options.map(t=>R`<button
          type="button"
          class="settings-segmented__btn ${t.value===e.value?`settings-segmented__btn--active`:``} ${e.variant===`accent`?`btn btn--sm`:``}"
          aria-pressed=${e.ariaPressed===!1?z:String(t.value===e.value)}
          aria-label=${t.ariaLabel??z}
          data-compact-label=${t.compactLabel??z}
          data-test-id=${t.testId??z}
          title=${t.title??z}
          ?disabled=${e.disabled||t.disabled}
          @click=${n=>{e.onClick?.(n,t.value),!(n.defaultPrevented||e.disabled||t.disabled)&&(t.value===e.value?e.onReselect?.(t.value):e.onChange(t.value))}}
        >
          ${t.label}
        </button>`)}
    </div>`:R`
    <wa-radio-group
      class="settings-segmented ${e.carapace?`oc-segmented`:``} ${e.className??``}"
      size="s"
      aria-describedby=${e.descriptionId??z}
      orientation="horizontal"
      .value=${Ta(e.value)}
      ?disabled=${Ta(e.disabled??!1)}
      @change=${t=>{let n=t.currentTarget,r=n.value;if(r!==void 0){let t=[...n.querySelectorAll(`wa-radio`)].find(e=>e.getAttribute(`value`)===r);e.onChange(r,t??n)===!1&&(n.value=e.value)}}}
    >
      ${e.ariaLabel?R`<span slot="label" class="settings-control__sr-label">${e.ariaLabel}</span>`:z}
      ${e.options.map(t=>R`
          <wa-radio
            class="settings-segmented__btn ${e.carapace?`oc-segmented-item`:``} ${t.value===e.value?`settings-segmented__btn--active`:``}"
            appearance="button"
            value=${t.value}
            .checked=${Ta(t.value===e.value)}
            ?disabled=${Ta(t.disabled??!1)}
            title=${t.title??z}
            data-test-id=${t.testId??z}
            @click=${n=>{t.value===e.value&&n.currentTarget instanceof HTMLElement&&e.onReselect?.(t.value,n.currentTarget)}}
          >
            ${t.label}
          </wa-radio>
        `)}
    </wa-radio-group>
  `}function SA(e){let t=e.kind===`muted`?``:` settings-status--${e.kind}`;return R`
    <span
      class="settings-status${t}${e.carapace?` oc-status ${DA[e.kind]}`:``}"
    >
      ${e.dot===!1?z:R`<span
              class="settings-status__dot ${e.carapace?`oc-status-indicator`:``}"
            ></span>`}
      <span class=${e.carapace?`oc-status-label`:``}>${e.label}</span>
    </span>
  `}function CA(e,t={}){let n=t.mono?`settings-row__value settings-row__value--mono`:`settings-row__value`;return R`<span class=${n}>${e}</span>`}function wA(e,t={}){return t.carapace?R`<div class="settings-empty oc-empty">
        <div class="oc-empty-content"><p class="oc-empty-description">${e}</p></div>
      </div>`:R`<div class="settings-empty">${e}</div>`}function TA(e={}){let t=Math.max(1,e.rows??3);return R`
    <div
      class="settings-loading-skeleton"
      role="status"
      aria-busy="true"
      aria-label=${e.label??j(`common.loading`)}
    >
      <div class="settings-loading-skeleton__rows" aria-hidden="true">
        ${Array.from({length:t},(t,n)=>R`
            <div
              class="settings-row settings-loading-skeleton__row ${e.carapace?`oc-settings-row`:``}"
            >
              <div class="settings-row__text ${e.carapace?`oc-settings-row-content`:``}">
                <span
                  class="skeleton settings-loading-skeleton__title ${e.carapace?`oc-skeleton-line oc-skeleton-line-short`:``}"
                ></span>
                <span
                  class="skeleton settings-loading-skeleton__description ${e.carapace?`oc-skeleton-line`:``}"
                ></span>
              </div>
              <div class="settings-row__control">
                <span
                  class="skeleton settings-loading-skeleton__control ${n%2==0?`settings-loading-skeleton__control--wide`:``}"
                ></span>
              </div>
            </div>
          `)}
      </div>
    </div>
  `}function EA(e){return R`
    <span class="settings-secret">
      <input
        class="settings-input"
        type=${e.visible?`text`:`password`}
        aria-label=${e.ariaLabel}
        autocomplete="off"
        spellcheck="false"
        .value=${e.value}
        placeholder=${e.placeholder??``}
        ?disabled=${e.disabled??!1}
        @input=${t=>e.onInput(t.target.value)}
      />
      <openclaw-tooltip .content=${e.visible?e.hideLabel:e.showLabel}>
        <button
          type="button"
          class="settings-secret__toggle"
          aria-label=${e.toggleLabel}
          aria-pressed=${e.visible}
          ?disabled=${e.disabled??!1}
          @click=${e.onToggle}
        >
          ${e.visible?I.eye:I.eyeOff}
        </button>
      </openclaw-tooltip>
    </span>
  `}var DA;function OA(){return(OA=e((()=>{Vc(),Wc(),Kc(),B(),xa(),Ni(),F(),vc(),L(),ta(),DA={accent:`oc-status-info`,danger:`oc-status-error`,muted:``,ok:`oc-status-success`,warn:`oc-status-warning`}})))()}async function kA(e,t){switch(t.kind){case`device-pairing`:{let t=e.gateway.snapshot;return t.phase!==`connected`||!Qi(t).canAdmin?!1:e.overlays.openDevicePairSetup()}default:return t.kind,!1}}function AA(){return(AA=e((()=>{Zr()})))()}function jA(){return typeof window<`u`&&window.event!==void 0}function MA(e){return e.connected&&e.directComposerSend&&!e.isCommand&&(e.message.trim().length>0||e.hasAttachments)}function NA(e){try{e.setItem(FA,`1`)}catch{}}function PA(e){let t;try{if(t=localStorage,t.getItem(FA)!==null)return}catch{return}let n=e.nativeNotifications;if(n){if(n.snapshot.permission!==`notDetermined`)return;NA(t);try{n.requestPermission()}catch{}return}let r=e.webPush.snapshot;if(r.supported&&r.permission==="default"&&r.subscription!==`registered`&&r.subscription!==`vapid-mismatch`&&!r.loading){NA(t);try{Notification.requestPermission().then(t=>{t===`granted`&&e.webPush.run({kind:`enable`})}).catch(()=>{})}catch{}}}var FA;function IA(){return(IA=e((()=>{FA=`openclaw.control.notificationsAutoPrompt.v1`})))()}function LA(e,t){if(e.key===`Escape`)return e.preventDefault(),t.close(),!0;if(![`ArrowDown`,`ArrowUp`,`Home`,`End`,`Enter`,`Tab`].includes(e.key)||[`ArrowDown`,`ArrowUp`,`Home`,`End`].includes(e.key)&&(e.shiftKey||e.altKey||e.ctrlKey||e.metaKey)||t.count===0&&!t.consumeEmpty)return!1;if(e.preventDefault(),t.count>0){if(e.key===`Home`||e.key===`End`)BA(t.move(e.key===`Home`?0:t.count-1));else if(e.key===`ArrowDown`||e.key===`ArrowUp`){let n=e.key===`ArrowDown`?1:t.count-1;BA(t.move((t.index+n)%t.count))}else(e.key===`Enter`||e.key===`Tab`)&&t.select(e.key)}return!0}function RA(e){return R`<div
    id=${e.id}
    class="slash-menu ${e.className??``}"
    role="listbox"
    aria-label=${e.label}
    ${HA(e.activeId)}
  >
    <div class="slash-menu__scroll" ${cS(!1,e.trackScroll)}>
      ${e.content}
    </div>
  </div>`}function zA(e){return R`<div
    id=${e.id}
    class="slash-menu-item ${e.active?`slash-menu-item--active`:``}"
    role="option"
    aria-selected=${e.active}
    @mousedown=${e.preserveFocus===!1?z:e=>e.preventDefault()}
    @click=${e.select}
    @pointermove=${t=>{!e.active&&t.pointerType!==`touch`&&e.hover()}}
  >
    <span class="slash-menu-icon" aria-hidden=${e.iconHidden?`true`:z}
      >${e.icon}</span
    >
    <span class="slash-menu-copy">
      <span class="slash-menu-name">${e.name}</span>
      <span class="slash-menu-desc">${e.description}</span>
    </span>
  </div>`}function BA(e){e&&requestAnimationFrame(()=>{let t=document.getElementById(e),n=t?.closest(`.slash-menu__scroll`);t&&n&&aS(n,t)})}var VA,HA;function UA(){return(UA=e((()=>{B(),sa(),lS(),VA=class extends Na{render(e){return z}update(e,[t]){return t!==this.activeId&&(this.activeId=t,BA(t??null)),z}},HA=pa(VA)})))()}var WA,GA;function KA(){return(KA=e((()=>{iS(),WA=[`direction`,`font-family`,`font-size`,`font-size-adjust`,`font-style`,`font-weight`,`font-stretch`,`font-variant`,`font-kerning`,`font-feature-settings`,`font-variation-settings`,`line-height`,`letter-spacing`,`word-spacing`,`tab-size`,`text-align`,`text-indent`,`text-transform`,`padding-top`,`padding-right`,`padding-bottom`,`padding-left`,`white-space`,`overflow-wrap`,`word-break`],GA=class{constructor(e){this.onOutOfView=e,this.popup=null,this.textarea=null,this.start=0,this.value=``,this.range=null,this.mirror=null,this.prefix=null,this.suffix=null,this.anchor=null,this.resizeObserver=null,this.frame=null,this.stylesDirty=!0,this.lineHeight=0,this.invalidateStyles=()=>{this.stylesDirty=!0,this.schedule()},this.schedule=()=>{let e=this.textarea?.ownerDocument.defaultView;e&&this.frame===null&&(this.frame=e.requestAnimationFrame(this.measure))},this.measure=()=>{this.frame=null;let{textarea:e,popup:t,mirror:n,prefix:r,suffix:i,anchor:a}=this;if(!e?.isConnected||!t?.isConnected||!n||!r||!i||!a){this.close();return}if(this.stylesDirty){let t=e.ownerDocument.defaultView.getComputedStyle(e);for(let e of WA)n.style.setProperty(e,t.getPropertyValue(e));n.style.whiteSpace=e.wrap===`off`?`pre`:`pre-wrap`,this.lineHeight=Number.parseFloat(t.lineHeight)||Number.parseFloat(t.fontSize)*1.2,this.stylesDirty=!1}n.style.width=`${e.clientWidth}px`;let o=Math.max(0,Math.min(this.start,e.value.length)),s=e.value.slice(0,o),c=e.value.indexOf(`
`,o),l=e.value.slice(o,c<0?void 0:c)||`​`;if(r.data!==s&&(r.data=s),i.textContent!==l&&(i.textContent=l),!i.firstChild||!this.range)return;this.range.setStart(i.firstChild,0),this.range.collapse(!0);let u=this.range.getClientRects()[0];if(!u)return;let d=e.getBoundingClientRect(),f=n.getBoundingClientRect(),p=e.offsetWidth?d.width/e.offsetWidth:1,m=e.offsetHeight?d.height/e.offsetHeight:1,h=d.left+(e.clientLeft+u.left-f.left-e.scrollLeft)*p,g=d.top+(e.clientTop+u.top-f.top-(this.lineHeight-u.height)/2-e.scrollTop)*m,_=d.left+e.clientLeft*p,v=d.top+e.clientTop*m;if(h<_||h>_+e.clientWidth*p||g+this.lineHeight*m<=v||g>=v+e.clientHeight*m){this.onOutOfView();return}a.style.left=`${h}px`,a.style.top=`${g}px`,a.style.height=`${this.lineHeight*m}px`,t.active=!0,t.reposition()}}update(e,t,n){if(this.popup!==e||this.textarea!==t){this.close(),this.popup=e,this.textarea=t;let n=t.ownerDocument;this.mirror=n.createElement(`div`),this.mirror.setAttribute(`aria-hidden`,`true`),this.mirror.style.cssText=`position:fixed;left:0;top:0;visibility:hidden;pointer-events:none;box-sizing:border-box;border:0;margin:0;height:auto;min-height:0;overflow:hidden;contain:layout style paint;`,this.prefix=n.createTextNode(``),this.suffix=n.createElement(`span`),this.range=n.createRange(),this.mirror.append(this.prefix,this.suffix),this.anchor=n.createElement(`span`),this.anchor.setAttribute(`aria-hidden`,`true`),this.anchor.style.cssText=`position:fixed;left:0;top:0;width:0;visibility:hidden;pointer-events:none;`,n.body.append(this.mirror,this.anchor),tS(e,this.anchor,`top`,`start`),this.resizeObserver=new ResizeObserver(this.invalidateStyles),this.resizeObserver.observe(t),n.addEventListener(`scroll`,this.schedule,!0),n.defaultView?.addEventListener(`resize`,this.invalidateStyles),n.defaultView?.visualViewport?.addEventListener(`resize`,this.invalidateStyles),n.defaultView?.visualViewport?.addEventListener(`scroll`,this.schedule)}let r=t.value;(this.value!==r||this.start!==n||this.stylesDirty)&&(this.value=r,this.start=n,this.schedule())}close(){let e=this.textarea?.ownerDocument,t=e?.defaultView;this.frame!==null&&(t?.cancelAnimationFrame(this.frame),this.frame=null),this.resizeObserver?.disconnect(),this.resizeObserver=null,e?.removeEventListener(`scroll`,this.schedule,!0),t?.removeEventListener(`resize`,this.invalidateStyles),t?.visualViewport?.removeEventListener(`resize`,this.invalidateStyles),t?.visualViewport?.removeEventListener(`scroll`,this.schedule),this.popup&&(this.popup.active=!1),this.mirror?.remove(),this.anchor?.remove(),this.popup=null,this.textarea=null,this.mirror=null,this.prefix=null,this.suffix=null,this.anchor=null,this.value=``,this.range=null,this.stylesDirty=!0}}})))()}function qA(e){if(!(e instanceof Gc)||JA.has(e))return;JA.add(e);let t=()=>{let t=e.dialog;if(!e.isConnected||!t)return;let n=e.ariaLabelledByElements,r=e.getAttribute(`aria-label`)?.trim();t.ariaLabel=r||null,t.ariaLabelledByElements=n?.length?n:!r&&e.anchor?[e.anchor]:null},n=new MutationObserver(t);e.addController({hostConnected(){n.observe(e,{attributes:!0,attributeFilter:[`aria-label`,`aria-labelledby`]}),e.updateComplete.then(t)},hostUpdated:t,hostDisconnected(){n.disconnect()}}),t()}var JA;function YA(){return(YA=e((()=>{qc(),JA=new WeakSet})))()}function XA(e){let t=Ja(e??``);return t?R`<span
        class="session-color-dot"
        style=${`--session-color: var(--session-color-${t})`}
        role="img"
        aria-label=${j(`sessionsView.sessionColor`,{color:j(`sessionsView.colors.${t}`)})}
      ></span>`:z}function ZA(){return(ZA=e((()=>{B(),Qa(),F()})))()}var QA;function $A(){return($A=e((()=>{B(),H(),bo(),M(),L(),QA=class extends Sn{constructor(...e){super(...e),this.routeUrl=null,this.authTokens=[],this.authReady=!1,this.undecodableRouteUrl=null,this.loader=new Co(this,{cacheNotFound:!0,retryUnavailable:!0})}render(){return this.loader.withActiveRoutes(()=>this.renderContent())}renderContent(){let e=this.routeUrl,t=e&&this.authReady&&this.undecodableRouteUrl!==e?this.loader.resolve(e,this.authTokens):null;return t?R`<img
      class="workspace-icon"
      src=${t}
      alt=""
      aria-hidden="true"
      decoding="async"
      @error=${()=>{this.undecodableRouteUrl=e}}
    />`:R`<span class="workspace-icon-fallback" aria-hidden="true">${I.folder}</span>`}},w([W({attribute:!1})],QA.prototype,`routeUrl`,void 0),w([W({attribute:!1})],QA.prototype,`authTokens`,void 0),w([W({attribute:!1})],QA.prototype,`authReady`,void 0),w([V()],QA.prototype,`undecodableRouteUrl`,void 0),customElements.get(`openclaw-workspace-icon`)||customElements.define(`openclaw-workspace-icon`,QA)})))()}function ej(e){return typeof e==`string`&&e.length>0}function tj(e){return g(e)&&ej(e.catalogId)&&ej(e.hostId)&&ej(e.threadId)?{catalogId:e.catalogId,hostId:e.hostId,threadId:e.threadId,...ej(e.sourceHomeId)?{sourceHomeId:e.sourceHomeId}:{}}:null}function nj(e){if(!g(e))return null;if(e.kind===`attach`)return ej(e.sessionId)&&typeof e.agentOwned==`boolean`?{kind:`attach`,sessionId:e.sessionId,agentOwned:e.agentOwned}:null;let t=e.agentId;if(t!==null&&!ej(t))return null;if(e.kind===`restore`||e.kind===`open`)return{kind:e.kind,agentId:t};if(e.kind===`catalog`){let n=tj(e.catalog);return n?{kind:`catalog`,agentId:t,catalog:n}:null}return null}function rj(e){try{let t=globalThis.sessionStorage?.getItem(e),n=t?JSON.parse(t):null;return Array.isArray(n)?n:[]}catch{return[]}}function ij(e=``){return rj(cj+e).filter(ej)}function aj(e,t=``){try{globalThis.sessionStorage?.setItem(cj+t,JSON.stringify(e))}catch{}}function oj(){return rj(lj).flatMap(e=>{let t=nj(e);return t?[t]:[]})}function sj(e){try{if(e.length===0){globalThis.sessionStorage?.removeItem(lj);return}globalThis.sessionStorage?.setItem(lj,JSON.stringify(e))}catch{}}var cj,lj;function uj(){return(uj=e((()=>{cj=`openclaw.terminal.sessions.v1`,lj=`openclaw.terminal.actions.v1`})))()}function dj(e,t){let n=e instanceof CustomEvent&&typeof e.detail==`object`&&e.detail!==null?e.detail:null;if(!n||n.open===!1)return null;let r=n.agentId?.trim()||t;return n.newSession===!0?{kind:`open`,agentId:r}:n.terminalSessionId?{kind:`attach`,sessionId:n.terminalSessionId,agentOwned:n.agentOwned??!0}:n.open===!0?{kind:`restore`,agentId:r}:null}var fj,pj;function mj(){return(mj=e((()=>{uj(),fj=class{constructor(e=!0){this.persistent=e,this.refreshPending=!1,this.refreshTimedOut=!1,this.refreshTimer=null,this.drainScheduled=!1,this.hosts=[],this.fenceHost=null,this.fenceGeneration=0,this.timeoutHost=null,this.actions=[],this.rehydrate()}rehydrate(){if(!this.persistent)return;let e=oj(),t=e.some(e=>e.kind!==`restore`)?e.filter(e=>e.kind!==`restore`):e;this.actions.splice(0,this.actions.length,...t),t.length!==e.length&&this.persist()}persist(){this.persistent&&sj(this.actions)}get host(){return this.hosts.at(-1)??null}bindHost(e){this.hosts.length===0&&this.rehydrate(),this.hosts=[...this.hosts.filter(t=>t!==e),e],this.drain()}releaseHost(e){this.hosts=this.hosts.filter(t=>t!==e),this.fenceHost===e&&this.resetLifecycle(e),this.hosts.length===0&&(this.clearRefreshTimer(),this.refreshTimedOut=!1,this.timeoutHost=null,this.rehydrate())}get hasActions(){return this.actions.length>0}get fenced(){return this.refreshPending}get waitingForRefresh(){return this.refreshPending&&!this.refreshTimedOut&&this.actions.length>0}beginRefreshFence(e,t){this.refreshPending=!0,this.fenceHost=e,this.fenceGeneration=t,this.clearRefreshFailure(),this.clearRefreshTimer(),this.armRefreshTimer()}releaseRefreshFence(e){this.fenceHost===e&&(this.clearRefreshTimer(),this.refreshPending=!1,this.fenceHost=null,this.clearRefreshFailure(),this.drain())}resetLifecycle(e){(this.fenceHost===null||this.fenceHost===e)&&(this.clearRefreshTimer(),this.refreshPending=!1,this.fenceHost=null,this.clearRefreshFailure())}async queue(e,t={}){let n=!1;if(e.kind!==`restore`)for(let e=this.actions.length-1;e>=0;--e)this.actions[e]?.kind===`restore`&&(this.actions.splice(e,1),n=!0);let r=this.actions.some(e=>e.kind!==`restore`),i=JSON.stringify(e);if(!(e.kind===`restore`&&r)&&!this.actions.some(e=>JSON.stringify(e)===i)&&(this.actions.push(e),n=!0),n&&this.persist(),t.deferUntilHostChange)return;this.armRefreshTimer();let a=this.host;this.refreshPending?a?.requestUpdate():a&&!a.hasTabs()&&a.setBooting(!0),await this.drain()}async drain(){let e=this.host;if(!this.drainScheduled&&this.actions.length!==0&&e&&this.canRun(e)){this.drainScheduled=!0;try{await e.bootQueue.enqueue(async t=>{let n=this.actions[0];if(!n||!t()||!this.canRun(e))return;let r=await this.execute(e,n,()=>this.retireAction(n));r&&t()&&(this.retireAction(n),r===`cancelled-restore`&&this.host===e&&e.cancelledRestoreCompleted())})}finally{this.drainScheduled=!1;let e=this.host;this.actions.length>0&&e&&this.canRun(e)?this.drain():this.actions.length===0&&e&&!e.hasTabs()&&e.setBooting(!1)}}}retireAction(e){let t=this.actions.indexOf(e);t!==-1&&(this.actions.splice(t,1),this.persist())}cancel(e){this.host===e&&(this.actions.splice(0),this.persist(),e.setBooting(!1),this.clearRefreshFailure())}canRun(e){return!this.refreshPending&&e.canRun()}async execute(e,t,n){if(t.kind===`attach`)return e.attach(t.sessionId,t.agentOwned,n);if(t.kind===`open`)return e.open(void 0,t.agentId,n);let r=await e.reattach(t.kind===`restore`?n:void 0);return this.canRun(e)?t.kind===`catalog`?e.open(t.catalog,t.agentId,n):r?`cancelled-restore`:e.ensureInitial(t.agentId,n):!1}clearRefreshTimer(){this.refreshTimer!==null&&(globalThis.clearTimeout(this.refreshTimer),this.refreshTimer=null)}clearRefreshFailure(){this.refreshTimedOut&&=(this.timeoutHost?.clearTimeout(),this.timeoutHost=null,!1)}armRefreshTimer(){let e=this.fenceHost;if(!this.refreshPending||!e||this.refreshTimer!==null||this.actions.length===0)return;let t=this.fenceGeneration;this.refreshTimer=globalThis.setTimeout(()=>{this.refreshTimer=null,this.fenceHost===e&&t===e.currentGeneration()&&this.refreshPending&&this.actions.length!==0&&(this.refreshTimedOut=!0,this.timeoutHost=e,e.showTimeout(),e.setBooting(!1))},e.timeoutMs())}},pj=new fj})))()}function hj(e,t){let n=e??_j;switch(t.type){case`mount`:return{..._j,open:t.manualOpen===void 0?t.open:!!t.manualOpen,manualOpen:t.manualOpen,readingHistory:t.readingHistory};case`history`:return{...n,readingHistory:t.readingHistory,gestures:t.readingHistory?n.gestures:0,distancePx:t.readingHistory?n.distancePx:0};case`gesture`:return{...n,gestures:n.gestures+1,distancePx:n.distancePx+t.distancePx};case`settle`:{if(!n.readingHistory)return{...n,gestures:0,distancePx:0};let e=n.manualReopens>0;return!n.open||n.manualOpen===!1||n.manualReopens>=gj.pinnedAfterReopens||n.gestures<(e?gj.reopenedGestures:gj.gestures)||n.distancePx<(e?gj.reopenedDistancePx:gj.distancePx)?n:{...n,open:!1,manualOpen:void 0,gestures:0,distancePx:0}}case`takeover`:return{...n,gestures:0,distancePx:0};case`extent`:return{...n,open:t.extent>0,manualOpen:t.extent!==0&&t.extent,manualReopens:n.manualReopens+Number(!n.open&&t.extent>0),gestures:0,distancePx:0};case`clamp`:return typeof n.manualOpen==`number`&&n.manualOpen>t.limit?{...n,manualOpen:t.limit,open:t.limit>0}:n;case`click`:return{...n,open:t.open,manualOpen:t.open,manualReopens:n.manualReopens+Number(!n.open&&t.open),gestures:0,distancePx:0}}return t}var gj,_j;function vj(){return(vj=e((()=>{gj={gestures:2,distancePx:320,reopenedGestures:3,reopenedDistancePx:640,pinnedAfterReopens:2,gesturePauseMs:200,touchGesturePx:24,scrollSettleMs:300},_j={open:!1,manualOpen:void 0,manualReopens:0,readingHistory:!1,gestures:0,distancePx:0}})))()}var yj,bj,xj,Sj;function Cj(){return(Cj=e((()=>{B(),ba(),sa(),nr(),Jl(),vj(),yj=new WeakMap,bj=class{constructor(e,t){this.element=e,this.transcript=null,this.disposed=!1,this.scrollSettled=!1,this.suppressClick=!1,this.touching=!1,this.scrolling=!1,this.scheduleCollapse=()=>{clearTimeout(this.settleTimer),this.scrollSettled=!1,this.settleTimer=setTimeout(()=>{this.settleTimer=void 0,this.scrollSettled=!0,this.settleDisclosure()},gj.scrollSettleMs)},this.handleTranscriptScroll=e=>{if(e.type!==`input`&&e.type!==`offset`)return;if(this.touching=e.touching,e.type===`offset`){this.scrolling=e.scrolling,e.programmatic&&this.gesture?.distancePx===0&&(this.gesture=void 0),!e.programmatic&&e.delta!==0&&(this.gesture&&(this.gesture.distancePx+=Math.max(0,-e.delta)),this.scheduleCollapse()),!this.scrolling&&this.scrollSettled&&this.settleDisclosure();return}let{event:t}=e;if(t instanceof WheelEvent){if(t.ctrlKey)return;let e=performance.now();(this.gesture?.kind!==`wheel`||this.lastWheelAt===void 0||e-this.lastWheelAt>gj.gesturePauseMs)&&(this.flushGesture(),this.scrollSettled=!1,this.gesture={kind:`wheel`,valid:!0,distancePx:0}),this.lastWheelAt=e,this.scheduleCollapse()}else typeof TouchEvent<`u`&&t instanceof TouchEvent?(t.type===`touchstart`&&t.touches.length===1&&(this.flushGesture(),this.scrollSettled=!1,this.gesture={kind:`touch`,valid:!0,distancePx:0}),this.gesture?.kind===`touch`&&(t.touches.length>1||t.type===`touchcancel`||t.type===`touchend`&&t.touches.length>0)&&(this.gesture.valid=!1),!this.touching&&this.scrollSettled&&this.settleDisclosure()):this.flushGesture()},this.clampExtent=()=>{typeof this.state.manualOpen==`number`&&this.state.manualOpen>this.limit()&&(this.dispatch({type:`clamp`,limit:this.limit()}),this.cancelDrag()),this.apply()},this.click=e=>{if(e.defaultPrevented||this.isControl(e)||!(e.target instanceof Element)||e.target.closest(`summary`)?.parentElement!==this.element)return;if(e.preventDefault(),this.suppressClick&&e.detail!==0){this.suppressClick=!1;return}this.cancelDrag();let t=this.chosen(),n=typeof t==`boolean`&&this.element.open||typeof t==`number`&&t>0&&(t>=this.limit()||!!(this.body&&this.body.clientHeight>0&&this.body.scrollHeight<=this.body.clientHeight+1));this.resetScrollInput(),this.dispatch({type:`click`,open:!n}),this.apply()},this.wheel=e=>{if(e.defaultPrevented||this.isControl(e)||this.drag||e.ctrlKey||e.metaKey||e.shiftKey||!Number.isFinite(e.deltaY)||!Number.isFinite(e.deltaX)||!e.deltaY||Math.abs(e.deltaX)>=Math.abs(e.deltaY))return;let t=e.deltaMode===WheelEvent.DOM_DELTA_LINE?Number.parseFloat(getComputedStyle(this.summary).lineHeight)||18:e.deltaMode===WheelEvent.DOM_DELTA_PAGE?this.limit():1,n=this.extent(),r=Math.max(0,Math.min(this.limit(),n-e.deltaY*t));e.preventDefault(),this.move(r)},this.pointerDown=e=>{!e.isPrimary||e.button!==0||this.isControl(e)||e.defaultPrevented||(this.suppressClick=!1,this.drag={id:e.pointerId,x:e.clientX,y:e.clientY,extent:this.extent(),active:!1},this.summary?.setPointerCapture(e.pointerId))},this.pointerMove=e=>{let t=this.drag;if(!t||t.id!==e.pointerId)return;let n=e.clientX-t.x,r=e.clientY-t.y;if(!t.active){if(Math.max(Math.abs(n),Math.abs(r))<3)return;if(Math.abs(n)>=Math.abs(r)){this.cancelDrag();return}this.takeover(),t.active=!0,this.suppressClick=!0}e.preventDefault();let i=t.extent-r;this.move(i),(i<0||i>this.limit())&&(t.extent=this.extent(),t.y=e.clientY)},this.otherPointer=e=>{this.drag&&e.pointerId!==this.drag.id&&this.cancelDrag()},this.pointerEnd=e=>{e.pointerId===this.drag?.id&&this.cancelDrag()},this.cancelDrag=()=>{let e=this.drag;this.drag=void 0,e&&this.summary?.hasPointerCapture(e.id)&&this.summary.releasePointerCapture(e.id)},this.sessionKey=t[0],this.gatewayScope=t[2]?.gatewayScope,this.cardLifetime=t[2]?.cardLifetime,this.state=this.mount(t),this.element.addEventListener(`click`,this.click)}mount([,e,t]){return this.resetScrollInput(),this.cancelDrag(),this.rememberedChoice=this.cardLifetime?yj.get(this.cardLifetime):void 0,hj(void 0,{type:`mount`,open:e&&!$i(),manualOpen:this.rememberedChoice?.choice,readingHistory:t?.readingHistory===!0})}update(e){let[t,,n]=e;this.lifecycle=n,(t!==this.sessionKey||n?.gatewayScope!==this.gatewayScope||n?.cardLifetime!==this.cardLifetime)&&(this.sessionKey=t,this.gatewayScope=n?.gatewayScope,this.cardLifetime=n?.cardLifetime,this.state=this.mount(e));let r=n?.readingHistory===!0;r!==this.state.readingHistory&&(r||this.resetScrollInput(),this.dispatch({type:`history`,readingHistory:r})),n?.presented===!1&&(this.takeover(),this.disconnectHeader()),this.connectHeader(),this.apply(),queueMicrotask(()=>{this.disposed||(this.connectHeader(),this.connectTranscript(),this.apply())})}dispatch(e){let t=this.state;if(this.state=hj(t,e),!this.cardLifetime)return;let n=e.type===`click`||e.type===`extent`||e.type===`clamp`,r=e.type===`settle`&&t.open&&!this.state.open;(n||r&&yj.get(this.cardLifetime)===this.rememberedChoice)&&(this.rememberedChoice={choice:this.state.manualOpen??this.state.open},yj.set(this.cardLifetime,this.rememberedChoice))}resetScrollInput(){clearTimeout(this.settleTimer),this.settleTimer=void 0,this.scrollSettled=!1,this.lastWheelAt=void 0,this.gesture=void 0,this.touching=!1,this.scrolling=!1}flushGesture(){let e=this.gesture;this.gesture=void 0,e?.valid&&e.distancePx>0&&(e.kind===`wheel`||e.distancePx>gj.touchGesturePx)&&this.dispatch({type:`gesture`,distancePx:e.distancePx})}settleDisclosure(){this.touching||this.scrolling||((!this.gesture?.valid||this.gesture.distancePx>0)&&this.flushGesture(),this.state.distancePx>0&&(this.dispatch({type:`settle`}),this.apply()))}connectTranscript(){if(this.disposed)return;let e=this.lifecycle?.presented===!1?null:this.element.closest(`.chat-main`)?.querySelector(`.chat-thread`)??null;e!==this.transcript&&(this.resetScrollInput(),this.unsubscribeTranscript?.(),this.transcript=e,this.unsubscribeTranscript=e?Yl(e,this.handleTranscriptScroll):void 0)}connectHeader(){if(this.disposed||this.lifecycle?.presented===!1||(this.summary??=this.element.querySelector(`summary`)??void 0,this.body??=this.element.querySelector(`.session-progress-card__body`)??void 0,!this.summary||this.listeners))return;this.listeners=new AbortController;let e=this.listeners.signal;this.summary.addEventListener(`wheel`,this.wheel,{passive:!1,signal:e}),this.summary.addEventListener(`pointerdown`,this.pointerDown,{signal:e}),this.summary.addEventListener(`pointermove`,this.pointerMove,{signal:e}),this.summary.addEventListener(`pointerup`,this.pointerEnd,{signal:e}),this.summary.addEventListener(`pointercancel`,this.pointerEnd,{signal:e}),this.summary.addEventListener(`lostpointercapture`,this.pointerEnd,{signal:e}),this.summary.ownerDocument.addEventListener(`pointerdown`,this.otherPointer,{capture:!0,signal:e}),this.summary.ownerDocument.defaultView?.addEventListener(`blur`,this.cancelDrag,{signal:e}),this.summary.ownerDocument.defaultView?.addEventListener(`resize`,this.clampExtent,{signal:e}),typeof ResizeObserver<`u`&&this.body&&(this.resizeObserver=new ResizeObserver(this.clampExtent),this.resizeObserver.observe(this.body))}disconnectHeader(){this.cancelDrag(),this.listeners?.abort(),this.listeners=void 0,this.resizeObserver?.disconnect(),this.resizeObserver=void 0}chosen(){return this.state.manualOpen??this.state.open}limit(){return this.body&&Number.parseFloat(getComputedStyle(this.body).maxHeight)||300}extent(){let e=this.chosen();return typeof e==`number`?Math.min(e,this.limit()):e?this.body?.getBoundingClientRect().height??0:0}apply(){this.body??=this.element.querySelector(`.session-progress-card__body`)??void 0;let e=this.chosen(),t=typeof e==`number`,n=t?Math.min(e,this.limit()):0;this.element.open=t?n>0:e,this.body&&(this.body.style.height=t?n+`px`:``,this.body.style.minHeight=t?n+`px`:``),this.element.dataset.reveal=t?`partial`:e?`open`:`closed`}isControl(e){return e.target instanceof Element&&!!e.target.closest(`button, a, input, select, textarea`)}move(e){this.takeover(),this.dispatch({type:`extent`,extent:Math.max(0,Math.min(this.limit(),e))}),this.lifecycle?.onManipulate?.(),this.apply()}takeover(){this.resetScrollInput(),this.dispatch({type:`takeover`})}dispose(){this.disposed=!0,this.unsubscribeTranscript?.(),this.unsubscribeTranscript=void 0,this.element.removeEventListener(`click`,this.click),this.disconnectHeader(),this.resetScrollInput()}},xj=class extends ua{render(...e){return z}update(e,t){return e.element instanceof HTMLDetailsElement&&(this.element=e.element,this.input=t,this.isConnected&&this.reconnected()),z}disconnected(){this.controller?.dispose(),this.controller=void 0}reconnected(){this.element&&this.input&&(this.controller??=new bj(this.element,this.input),this.controller.update(this.input))}},Sj=pa(xj)})))()}function wj(e,t){if(!t)return z;let n=t.state===`pending`,r=t.state===`failed`||t.state===`timeout`,i=j(n?`sessionProgressCard.refresh.pending`:r?`sessionProgressCard.refresh.retry`:`sessionProgressCard.refresh.label`);return R`<button
    class="session-progress-card__refresh"
    type="button"
    data-state=${t.state??`idle`}
    aria-label=${i}
    title=${r&&t.state?j(Ij[t.state]):i}
    aria-busy=${String(n)}
    ?disabled=${n}
    @click=${r=>{r.preventDefault(),r.stopPropagation(),n||t.onRefresh(e)}}
  >
    ${n?I.loader:t.state===`updated`?I.check:I.refresh}
  </button>`}function Tj(e){if(e.length>Rj)return $T(e,{progressBars:!0});let t=`${Dn.getLocale()}\0${e}`,n=zj.get(t);if(n!==void 0)return zj.delete(t),zj.set(t,n),n;let r=$T(e,{progressBars:!0});return zj.set(t,r),oe(zj,Lj),r}function Ej(e){let t=e.steps;return t?.length?{completed:t.filter(e=>e.status===`completed`).length,total:t.length}:null}function Dj(e){return e.find(e=>e.status===`in_progress`)??e.find(e=>e.status===`pending`)}function Oj(e,t){let n=le(t),r=le(e.updatedAt);return n!==void 0&&r!==void 0&&r<n}function kj(e,t,n,r=!0){let i=e?Oj(e,n):!1;if(t&&Vj[t]&&!i)return null;let a=e?Ej(e):null;if(!a||!e?.steps)return null;let o=Dj(e.steps);if(!o)return null;let s=o.status===`in_progress`&&(i||!r)?`paused`:o.status;return{...a,status:s,step:o.step}}function Aj(e){return Dj(e)??e.findLast(e=>e.status===`completed`)}function jj(e,t){let n=t&&Vj[t];if(e===`in_progress`&&n)return n===`completed`?I.check:I.circleX;switch(e){case`completed`:return I.check;case`in_progress`:return R`<span class="session-run-spinner"></span>`;case`paused`:case`pending`:return I.clock}return e}function Mj(e){let t=document.createElement(`template`);t.innerHTML=e;let n=t.content.querySelector(`progress`);if(!n)return e;let r=n.getAttribute(`value`)?.trim(),i=n.getAttribute(`max`)?.trim(),a=n.getAttribute(`aria-label`)?.trim()||(r&&i?`${j(`sessionProgressCard.title`)} · ${r}/${i}`:j(`sessionProgressCard.title`));n.setAttribute(`aria-label`,a);let o=n.parentElement,s=document.createElement(`div`);s.className=`session-progress-card__progress`;let c=document.createElement(`span`);return c.className=`session-progress-card__progress-label`,c.textContent=a,s.append(c,n),o?.tagName===`P`&&o.children.length===0&&!o.textContent?.trim()&&o.remove(),t.content.prepend(s),t.innerHTML}function Nj(e,t={}){if(!e)return z;let n=Tj(e);return R`<div class="session-progress-card__markdown sidebar-markdown">
    ${Da(t.promoteProgress?Mj(n):n)}
  </div>`}function Pj(e,t,n){let r=e.steps;return r?.length?R`<ol class="session-progress-card__steps">
    ${r.map(e=>{let r=e.status===`in_progress`&&n?Vj[n]:void 0,i=e.status===`in_progress`&&!t&&!r?`paused`:e.status,a=j(r?`sessionProgressCard.status.${r}`:i===`paused`?`sessionProgressCard.status.paused`:Bj[i]);return R`<li
        class="session-progress-card__step session-progress-card__step--${i}"
        aria-label=${j(`sessionProgressCard.stepLabel`,{status:a,step:e.step})}
      >
        <span
          class="session-progress-card__step-marker"
          data-status=${i}
          data-outcome=${r?n:z}
          aria-hidden="true"
          >${jj(i,n)}</span
        >
        <span class="session-progress-card__step-text">${e.step}</span>
      </li>`})}
  </ol>`:z}function Fj(e,t,n,r,i,a,o=!0,s=!1,c,l){if(!e)return z;let u=Ej(e),d=u?j(`sessionProgressCard.countLabel`,{completed:String(u.completed),total:String(u.total)}):j(`sessionProgressCard.noteLabel`),f=le(i),p=le(a),m=le(e.updatedAt),h=f!==void 0&&p!==void 0&&p>=f&&m!==void 0&&m>=f&&m<=p,g=o&&!Oj(e,i)&&(m===void 0||r!==`queued`&&(f!==void 0||r===void 0)),_=r&&Vj[r]&&h?p:void 0,v=r&&Vj[r]&&!_?void 0:r,y=_??m??Date.now(),b=_?`sessionProgressCard.activity.${Vj[r]}`:`sessionProgressCard.activity.updated`,x=Uj(y,b),S=n?R`<button
        class="rail-header__action session-progress-card__dismiss"
        type="button"
        aria-label=${j(`sessionProgressCard.dismiss`)}
        title=${j(`sessionProgressCard.dismiss`)}
        @click=${t=>{t.preventDefault(),t.stopPropagation(),n?.(e)}}
      >
        ${I.x}
      </button>`:z;if(t===`composer`){let t=e.steps??[],n=Aj(t),r=Math.max(1,n?t.indexOf(n)+1:0),i=t.length>0&&t.every(e=>e.status===`completed`),a=n?.step??j(`sessionProgressCard.noteLabel`),o=v?Vj[v]:void 0,f=o?j(`sessionProgressCard.outcome.${o}`):null,p=`${a}. ${f??d}`,m=u?j(`sessionProgressCard.shortCount`,{completed:String(r),total:String(u.total)}):z,h=n?.status===`in_progress`&&!g&&!o?`paused`:n?.status,_=o?o===`completed`?I.check:I.circleX:i?I.check:n?.status===`in_progress`?jj(h??`pending`):I.clock;return R`<details
      class="session-progress-card session-progress-card--composer"
      data-progress-card-placement="composer"
      data-complete=${String(i)}
      ${Sj(c?.sessionIdentity??e.sessionKey,!s,c)}
    >
      <summary class="session-progress-card__summary" aria-label=${p}>
        <span
          class="session-progress-card__summary-indicator session-progress-card__current-marker${i||v===`done`?` session-progress-card__summary-indicator--complete`:``}"
          data-status=${h??`pending`}
          data-outcome=${v??z}
          aria-hidden="true"
        >
          ${_}
        </span>
        <span class="session-progress-card__summary-collapsed">
          <span class="session-progress-card__current">${a}</span>
        </span>
        ${u?R`<span
                class="session-progress-card__summary-count session-progress-card__summary-count--collapsed"
                data-outcome=${v??z}
                >${f??`${r}/${u.total}`}</span
              >`:z}
        <span class="session-progress-card__summary-expanded">
          <span class="session-progress-card__summary-title"
            >${j(`sessionProgressCard.composerTitle`)}</span
          >
          <span class="session-progress-card__heading-actions"
            ><span>${x}${u?R` · ${m}`:z}</span></span
          >
        </span>
        <span class="session-progress-card__summary-controls">
          ${wj(e,l)} ${S}
          <span
            class="session-progress-card__summary-chevron session-progress-card__chevron"
            aria-hidden="true"
            >${I.chevronDown}</span
          >
        </span>
        ${l?.state?R`<span
                class="session-progress-card__refresh-status"
                data-state=${l.state}
                role="status"
                >${j(Ij[l.state])}</span
              >`:z}
      </summary>
      <div
        class="session-progress-card__body"
        role="region"
        aria-label=${d}
        ${cS()}
      >
        ${Nj(e.markdown)}
        ${Pj(e,g,v)}
      </div>
    </details>`}return R`<section
    class="session-progress-card session-progress-card--${t}"
    data-progress-card-placement=${t}
    aria-label=${d}
  >
    <div class="session-progress-card__heading">
      <span>${j(`sessionProgressCard.title`)}</span>
      <span class="session-progress-card__heading-actions">
        <span
          >${x}${u?R` · ${u.completed}/${u.total}`:z}</span
        >${S}
      </span>
    </div>
    <div class="session-progress-card__body">
      ${Nj(e.markdown)}
      ${Pj(e,g,v)}
    </div>
  </section>`}var Ij,Lj,Rj,zj,Bj,Vj,Hj,Uj;function Wj(){return(Wj=e((()=>{me(),B(),ba(),sa(),ka(),F(),_t(),L(),vE(),lS(),Cj(),Ij={pending:`sessionProgressCard.refresh.pending`,failed:`sessionProgressCard.refresh.failed`,timeout:`sessionProgressCard.refresh.timeout`,updated:`sessionProgressCard.refresh.updated`},Lj=16,Rj=14e4,zj=new Map,Bj={completed:`sessionProgressCard.status.completed`,in_progress:`sessionProgressCard.status.inProgress`,pending:`sessionProgressCard.status.pending`},Vj={done:`completed`,failed:`failed`,killed:`stopped`,timeout:`failed`},Hj=class extends ua{constructor(...e){super(...e),this.timestamp=0,this.labelKey=`sessionProgressCard.activity.updated`}render(e,t){return this.timestamp=e,this.labelKey=t,this.isConnected&&this.startTimer(),this.renderTime()}disconnected(){this.stopTimer()}reconnected(){this.setValue(this.renderTime()),this.startTimer()}startTimer(){this.timer||=setInterval(()=>this.setValue(this.renderTime()),3e4)}stopTimer(){this.timer&&=(clearInterval(this.timer),void 0)}renderTime(){let e=j(this.labelKey,{time:st(this.timestamp)});return R`<time
      datetime=${new Date(this.timestamp).toISOString()}
      aria-label=${e}
      title=${e}
      >${e}</time
    >`}},Uj=pa(Hj)})))()}function Gj(e){let{widget:t}=e,n=t.declared?.netOrigins??[],r=t.declared?.tools??[];return R`
    <div class="board-widget__grant board-widget__grant--pending" data-test-id="board-pending">
      <div class="board-widget__grant-mark" aria-hidden="true">!</div>
      <strong>${j(`board.widget.needsApproval`)}</strong>
      ${n.length>0||r.length>0?R`<div class="board-widget__grant-groups">
              ${[[`board.widget.networkAccess`,n],[`board.widget.hostTools`,r]].map(([e,t])=>t.length>0?R`<section>
                      <strong>${j(e)}</strong>
                      <ul class="board-widget__grant-summary">
                        ${t.map(e=>R`<li>${e}</li>`)}
                      </ul>
                    </section>`:z)}
            </div>`:t.declaredSummary?.length?R`<ul class="board-widget__grant-summary">
                ${t.declaredSummary.map(e=>R`<li>${e}</li>`)}
              </ul>`:R`<span>${j(`board.widget.needsApprovalDetail`)}</span>`}
      <div class="board-widget__grant-actions">
        <button
          class="btn btn--small btn--primary"
          type="button"
          data-test-id="board-grant-allow"
          ?disabled=${e.disabled}
          @click=${()=>e.onGrant(`granted`)}
        >
          ${j(`board.widget.allow`)}
        </button>
        <button
          class="btn btn--small"
          type="button"
          data-test-id="board-grant-reject"
          ?disabled=${e.disabled}
          @click=${()=>e.onGrant(`rejected`)}
        >
          ${j(`board.widget.reject`)}
        </button>
      </div>
      ${e.error??z}
    </div>
  `}function Kj(e,t=`tooltip`){if(e.grantState!==`granted`||!e.declared)return z;let n=[...(e.declared.netOrigins??[]).map(e=>j(`board.widget.networkCapability`,{capability:e})),...(e.declared.tools??[]).map(e=>j(`board.widget.toolCapability`,{capability:e}))];return n.length===0?z:t===`details`?R`<div
      class="board-widget__menu-capabilities"
      role="note"
      aria-label=${j(`board.widget.activeCapabilities`)}
    >
      <strong>${j(`board.widget.activeCapabilities`)}</strong>
      <ul>
        ${n.map(e=>R`<li>${e}</li>`)}
      </ul>
    </div>`:R`
    <openclaw-tooltip
      .content=${`${j(`board.widget.activeCapabilities`)}\n${n.join(`
`)}`}
    >
      <span class="board-widget__capabilities" data-test-id="board-capabilities-granted">
        ${j(`board.widget.granted`)}
      </span>
    </openclaw-tooltip>
  `}function qj(){return(qj=e((()=>{B(),F()})))()}function Jj(e){let t=e.querySelector(`.board-widget__menu`);t&&(t.open=!1)}function Yj(e){let{onSelect:t}=e;return R`
    <wa-dropdown class="board-widget__menu" placement="bottom-end" @wa-select=${t}>
      <button
        class="board-widget__menu-trigger"
        slot="trigger"
        type="button"
        aria-label=${j(`board.widget.menuLabel`)}
        title=${j(`board.widget.menuLabel`)}
      >
        ⋮
      </button>
      ${Xj(e)}
    </wa-dropdown>
  `}function Xj(e){let{widget:t,tabs:n,disabled:r,prefix:i=``}=e,a=n.filter(e=>e.tabId!==t.tabId);return R`
    <div class="board-widget__menu-heading">${j(`board.widget.moveToTab`)}</div>
    ${a.length>0?a.map(e=>R`
              <wa-dropdown-item value=${`${i}move:${e.tabId}`} ?disabled=${r}>
                ${e.title}
              </wa-dropdown-item>
            `):R`<span class="board-widget__menu-empty">${j(`board.widget.noOtherTabs`)}</span>`}
    <div class="board-widget__menu-heading">${j(`board.widget.resize`)}</div>
    ${Object.entries(tM).map(([e,t])=>R`
        <wa-dropdown-item
          class="board-widget__preset"
          value=${`${i}resize:${e}`}
          ?disabled=${r}
        >
          ${e.toUpperCase()}
          <span slot="details">${t.w}×${t.h}</span>
        </wa-dropdown-item>
      `)}
    ${t.contentKind===`html`?R`<wa-dropdown-item
            class="board-widget__preset"
            type="checkbox"
            value=${`${i}height:auto`}
            ?checked=${t.heightMode!==`fixed`}
            ?disabled=${r}
          >
            ${j(`board.widget.autoHeight`)}
          </wa-dropdown-item>`:z}
    <div class="board-widget__menu-separator" role="separator"></div>
    <wa-dropdown-item
      class="board-widget__menu-danger"
      value=${`${i}remove`}
      ?disabled=${r}
    >
      <span slot="icon" class="board-widget__menu-icon" aria-hidden="true">${I.trash}</span>
      ${j(`board.widget.remove`)}
    </wa-dropdown-item>
  `}function Zj(e){return R`
    <div class="board-widget__grant board-widget__grant--rejected" data-test-id="board-rejected">
      <strong>${j(`board.widget.rejected`)}</strong>
      <span>${j(`board.widget.rejectedDetail`)}</span>
      <button
        class="btn btn--small"
        type="button"
        ?disabled=${e.disabled}
        @click=${e.onRemove}
      >
        ${j(`board.widget.remove`)}
      </button>
    </div>
  `}function Qj(e){return R`
    <div class="board-widget__disabled-plugin" data-test-id="board-disabled-plugin">
      ${e.content??R`<strong>${j(`board.widget.disabledPlugin`,{pluginId:e.pluginId})}</strong>`}
      <button
        class="btn btn--small"
        type="button"
        ?disabled=${e.disabled}
        @click=${e.onRemove}
      >
        ${j(`board.widget.remove`)}
      </button>
    </div>
  `}function $j(e,t){let n=E(e);return R`
    <div class="board-widget__error" role="alert" data-test-id="board-widget-error">
      <strong>${j(`board.widget.errorTitle`)}</strong>
      <span>${j(`board.widget.errorDetail`)}</span>
      <details>
        <summary>${j(`board.widget.errorShow`)}</summary>
        <code>${n}</code>
      </details>
      ${t?R`<button class="btn btn--small" type="button" @click=${t}>
              ${j(`board.widget.retry`)}
            </button>`:z}
    </div>
  `}function eM(e,t=!1){return R`
    <div
      class=${`board-widget__error ${t?`board-widget__error--inline`:``}`}
      role="alert"
      data-test-id="board-widget-action-error"
    >
      <strong>${j(`board.widget.actionErrorTitle`)}</strong>
      <span>${j(`board.widget.actionErrorDetail`)}</span>
      <details>
        <summary>${j(`board.widget.errorShow`)}</summary>
        <code>${e}</code>
      </details>
    </div>
  `}var tM;function nM(){return(nM=e((()=>{B(),F(),P(),L(),tM={sm:{w:3,h:3},md:{w:6,h:4},lg:{w:8,h:6},xl:{w:12,h:8}}})))()}function rM(e){e.currentTarget.querySelector(`.chat-copy-btn`)?.click()}function iM(e,t=`inline`){let n=j(`connection.help.copyCommand`);return R`
    <openclaw-tooltip .content=${n}>
      <div
        class=${t===`hero`?`login-gate__command login-gate__command--hero`:`login-gate__command`}
        role="button"
        tabindex="0"
        aria-label=${j(`connection.help.copyCommandAria`,{command:e})}
        @click=${e=>{e.target?.closest(`.chat-copy-btn`)||rM(e)}}
        @keydown=${e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),rM(e))}}
      >
        <code translate="no">${e}</code>
        ${yS(e,n)}
      </div>
    </openclaw-tooltip>
  `}function aM(){return(aM=e((()=>{B(),F(),CS(),ta()})))()}function oM(e,t){return e>t?j(`execApproval.expiresIn`,{time:dt(e,t,!0)}):j(`execApproval.expired`)}function sM(e,t,n){return t?R`<div class="exec-approval-meta-row">
    <span>${e}</span><span>${n?.path?qn(t):t}</span>
  </div>`:z}function cM(e){let t=[...e.commandSpans??[]].filter(t=>Number.isSafeInteger(t.startIndex)&&Number.isSafeInteger(t.endIndex)&&t.startIndex>=0&&t.endIndex>t.startIndex&&t.endIndex<=e.command.length).toSorted((e,t)=>e.startIndex-t.startIndex||t.endIndex-e.endIndex),n=[],r=0;for(let i of t)i.startIndex<r||(i.startIndex>r&&n.push(e.command.slice(r,i.startIndex)),n.push(R`<mark class="exec-approval-command-span"
        >${e.command.slice(i.startIndex,i.endIndex)}</mark
      >`),r=i.endIndex);return r<e.command.length&&n.push(e.command.slice(r)),R`<div class="exec-approval-command mono">${n}</div>`}function lM(e){return R`<details class="exec-approval-details">
    <summary>${j(`execApproval.details`)}</summary>
    <div class="exec-approval-meta">${e}</div>
  </details>`}function uM(e,t){return t?R`<span class="exec-approval-chip mono" data-approval-chip=${e}>${t}</span>`:z}function dM(e){switch(e.kind){case`standing-grant`:return e.expiresInDays===void 0?j(`execApproval.scope.standingGrant`,{automation:e.automation}):j(`execApproval.scope.standingGrantDays`,{automation:e.automation,count:String(e.expiresInDays)});case`message-send`:return j(`execApproval.scope.messageSend`,{count:String(e.recipientCount),target:e.target});case`payment`:return j(`execApproval.scope.payment`,{amount:e.amount,currency:e.currency,target:e.target});case`external-post`:return j(`execApproval.scope.externalPost`,{target:e.target})}return e}function fM(e,t){return R` ${cM(e)}
    ${e.scope?R`<div class="exec-approval-scope">${dM(e.scope)}</div>`:z}
    <div class="exec-approval-meta">
      ${sM(j(`execApproval.labels.host`),e.host)}
      ${sM(j(`execApproval.labels.cwd`),e.cwd,{path:!0})}
    </div>
    ${lM(R`
      ${sM(j(`execApproval.labels.resolved`),e.resolvedPath,{path:!0})}
      ${sM(j(`execApproval.labels.security`),e.security)}
      ${sM(j(`execApproval.labels.ask`),e.ask)}
      ${t===`modal`?sM(j(`execApproval.labels.session`),e.sessionKey):z}
    `)}`}function pM(e,t){return R` ${e.pluginDescription?R`<pre class="exec-approval-command mono">${e.pluginDescription}</pre>`:z}
  ${e.pluginDetail?R`<pre class="exec-approval-command mono" dir="ltr">${e.pluginDetail}</pre>`:z}
  ${t===`modal`&&e.request.sessionKey?lM(R`${sM(j(`execApproval.labels.session`),e.request.sessionKey)}`):z}`}function mM(e,t){return j(e===`allow-once`?`execApproval.allowOnce`:e===`allow-always`?t===`exec`?`execApproval.alwaysAllowHere`:`execApproval.alwaysAllow`:`execApproval.deny`)}function hM(e){return e===`allow-once`?`btn primary`:e===`deny`?`btn danger`:`btn`}function gM(e){return e===`allow-once`?`Ctrl/Cmd+Enter`:e===`allow-always`?`Ctrl/Cmd+Shift+Enter`:`Ctrl/Cmd+D`}function _M(e){return e.request.allowedDecisions?.length?e.request.allowedDecisions:e.kind===`exec`&&e.request.ask===`always`?[`allow-once`,`deny`]:xM}function vM(e){return e.kind===`exec`?j(`execApproval.execApprovalNeeded`):e.pluginTitle??j(`execApproval.pluginApprovalNeeded`)}function yM(e){let t=e.approval,n=Date.now(),r=t.expiresAtMs<=n,i=bb(t.request.command),a=t.request.sessionKey?.trim(),o=e.sessionTitle??(a?lt(a):vM(t)),s=r||t.expiresAtMs-n<12e4,c=oM(t.expiresAtMs,n),l=j(`execApproval.reviewOnly`),u=!e.canGrant&&e.error===l;return R`<article
    class="sidebar-approval-row sidebar-issues-panel__details--warning"
    data-attention-kind="pendingApproval"
    data-approval-id=${t.id}
  >
    <span class="sidebar-issues-panel__icon sidebar-approval-row__icon" aria-hidden="true"
      >${I.shieldQuestion}</span
    >
    <div class="sidebar-approval-row__content">
      <div class="sidebar-approval-row__header" data-issue-row-focus tabindex="-1">
        <span class="sidebar-issues-panel__entity" title=${o}>${o}</span>
        <openclaw-approval-countdown
          class="sidebar-approval-row__timer ${s?`sidebar-approval-row__timer--urgent`:``}"
          role="timer"
          aria-label=${c}
          title=${c}
          .expiresAtMs=${t.expiresAtMs}
          .compact=${!0}
        ></openclaw-approval-countdown>
      </div>
      <div class="sidebar-approval-row__command mono" title=${t.request.command}>
        <span aria-hidden="true">$ </span>${i}
      </div>
      ${t.request.scope?R`<div class="exec-approval-scope">
              ${dM(t.request.scope)}
            </div>`:z}
      <div
        class="sidebar-approval-row__actions"
        role="group"
        aria-label=${j(`approvalPage.actionsLabel`)}
      >
        ${_M(t).map(n=>{let a=mM(n,t.kind);return R`<button
            type="button"
            class="btn btn--xs ${n===`deny`?`btn--ghost`:``} sidebar-approval-row__action sidebar-approval-row__action--${n}"
            aria-label=${j(`execApproval.decisionRequest`,{decision:a,command:i})}
            ?disabled=${e.busy||!e.canGrant||r}
            @click=${r=>e.onDecision(r,t.id,n)}
          >
            ${a}
          </button>`})}
        ${e.openSessionHref&&e.onOpenSession?R`<a
                class="sidebar-approval-row__open-session"
                href=${e.openSessionHref}
                aria-label=${j(`sessionsView.openSession`)}
                title=${j(`sessionsView.openSession`)}
                @click=${e.onOpenSession}
              >
                ${I.arrowUpRight}
              </a>`:z}
      </div>
      ${e.canGrant?z:R`<div class="sidebar-approval-row__message" role=${u?`alert`:`note`}>
              ${l}
            </div>`}
      ${e.error&&!u?R`<div
              class="sidebar-approval-row__message sidebar-approval-row__message--error"
              role="alert"
            >
              ${e.error}
            </div>`:z}
    </div>
  </article>`}function bM(e){let t=e.approval,n=_M(t),r=j(`execApproval.reviewOnly`),i=!e.canGrant&&e.error===r,a=t.pluginSeverity?.trim().toLowerCase(),o=t.kind===`exec`||a===`warning`||a===`warn`?`warning`:a===`danger`||a===`critical`||a===`error`?`danger`:`info`,s=t.kind===`plugin`?t.pluginId?.trim():null,c=e.variant===`modal`?t.request.agentId?.trim():null;return R` <div
    class="exec-approval-card exec-approval-card--${e.variant} exec-approval-card--severity-${o}"
    data-approval-id=${t.id}
  >
    <div class="exec-approval-header">
      <div>
        <div class="exec-approval-title">${vM(t)}</div>
        ${s||c?R`<div class="exec-approval-chips">
                ${uM(`plugin`,s)} ${uM(`agent`,c)}
              </div>`:z}
        <openclaw-approval-countdown
          class="exec-approval-sub exec-approval-countdown"
          role="timer"
          .expiresAtMs=${t.expiresAtMs}
        ></openclaw-approval-countdown>
      </div>
      ${(e.queueCount??0)>1?R`<div class="exec-approval-queue">
              ${j(`execApproval.pending`,{count:String(e.queueCount)})}
            </div>`:z}
    </div>
    ${e.variant===`inline`&&t.sourceSessionKey?R`<div class="exec-approval-warning" role="note">
            ${j(`execApproval.requestedBySession`,{session:lt(t.sourceSessionKey,e.sourceSession)})}
          </div>`:z}
    ${t.kind===`exec`?fM(t.request,e.variant):pM(t,e.variant)}
    ${t.kind===`exec`&&!n.includes(`allow-always`)?R`<div class="exec-approval-warning">${j(`execApproval.allowAlwaysUnavailable`)}</div>`:z}
    ${e.canGrant?z:R`<div
            class=${i?`exec-approval-error`:`exec-approval-warning`}
            role=${i?`alert`:`note`}
          >
            ${r}
          </div>`}
    ${e.error&&!i?R`<div class="exec-approval-error" role="alert">${e.error}</div>`:z}
    <div class="exec-approval-actions">
      ${n.map(n=>{let r=mM(n,e.approval.kind);return R`<button
          class=${hM(n)}
          type="button"
          aria-label=${r}
          ?disabled=${e.busy||!e.canGrant}
          title=${e.variant===`modal`&&e.canGrant?`${r} (${gM(n)})`:r}
          @click=${()=>e.onDecision(t.id,n)}
        >
          <span>${r}</span>
        </button>`})}
    </div>
  </div>`}var xM,SM;function CM(){return(CM=e((()=>{B(),H(),xb(),F(),_t(),ln(),M(),rc(),L(),xM=[`allow-once`,`allow-always`,`deny`],SM=class extends Sn{constructor(...e){super(...e),this.expiresAtMs=0,this.compact=!1,this.polling=new Ro(this,1e3,()=>{this.requestUpdate(),this.compact||this.closest(`openclaw-modal-dialog`)?.setAttribute(`description`,oM(this.expiresAtMs,Date.now()))},!1)}connectedCallback(){super.connectedCallback(),this.polling.start()}render(){let e=Date.now();return R`${this.compact?dt(this.expiresAtMs,e,!0):oM(this.expiresAtMs,e)}`}},w([W({type:Number})],SM.prototype,`expiresAtMs`,void 0),w([W({type:Boolean})],SM.prototype,`compact`,void 0),customElements.get(`openclaw-approval-countdown`)||customElements.define(`openclaw-approval-countdown`,SM)})))()}function wM(e,t){let n=wr(e,t);return n?.reader.linkReader.previewMethod?n:null}function TM(e,t=ni.providerFor(e),n=wM){let r=t?.client&&t.readers?n(e.href,t.readers):null;return r&&Rr(e)?r:null}async function EM(e,t){let n=TM(e),r=ni.providerFor(e);if(!n||!r?.client?.connected||t.aborted)return;let{client:i,agentId:a,readers:o}=r;await ni.define();let s=ni.providerFor(e);await s?.updateComplete,!(t.aborted||!e.isConnected||e.href!==n.href||document.hidden||s!==r||s.client!==i||s.agentId!==a||s.readers!==o)&&await s.prefetch(n,t)}function DM(){return(DM=e((()=>{oa(),na()})))()}var OM,kM,AM,jM,MM;function NM(){return(NM=e((()=>{B(),ba(),sa(),oa(),DM(),na(),OM=8,kM=150,AM=500,jM=class extends ua{constructor(...e){super(...e),this.provider=null,this.handleCapabilities=()=>{this.release(),this.attempted.clear(),this.scheduleScan()},this.active=!1,this.observer=null,this.mutations=null,this.scope=new AbortController,this.observed=new Map,this.attempted=new Set,this.claims=new Map,this.resolveClaim=(e,t)=>{t!==this.claimReaders&&(this.claims.clear(),this.claimReaders=t);let n=this.claims.get(e);return n===void 0&&(n=wM(e,t),this.claims.set(e,n)),n},this.handleVisibilityChange=()=>{this.active&&!document.hidden?this.mutations||this.scheduleScan():this.release()}}render(e,t=!0,n=!0){return z}update(e,[t,n=!0,r=!0]){(t!==this.sessionKey||!r)&&(this.release(),this.attempted.clear(),this.sessionKey=t),this.root=e.element instanceof HTMLElement?e.element:void 0;let i=this.root?.closest(`openclaw-link-reader-hovercard-provider`)??null;return i!==this.provider&&(this.provider?.removeEventListener(`link-reader-capabilities-changed`,this.handleCapabilities),this.provider=i,this.provider?.addEventListener(`link-reader-capabilities-changed`,this.handleCapabilities),this.release(),this.attempted.clear()),this.active=n&&r,document.addEventListener(`visibilitychange`,this.handleVisibilityChange),this.handleVisibilityChange(),z}disconnected(){this.provider?.removeEventListener(`link-reader-capabilities-changed`,this.handleCapabilities),document.removeEventListener(`visibilitychange`,this.handleVisibilityChange),this.release()}reconnected(){this.provider?.addEventListener(`link-reader-capabilities-changed`,this.handleCapabilities),document.addEventListener(`visibilitychange`,this.handleVisibilityChange),this.handleVisibilityChange()}release(){this.cancelScan?.(),this.cancelScan=void 0,this.observer?.disconnect(),this.observer=null,this.mutations?.disconnect(),this.mutations=null,this.observed.clear(),this.claims.clear(),this.claimReaders=void 0,clearTimeout(this.timer),this.timer=void 0,this.scope.abort(),this.scope=new AbortController,this.pendingKey&&this.attempted.delete(this.pendingKey),this.pendingKey=void 0}canPrefetch(){return this.active&&this.isConnected&&!!this.root?.isConnected&&!document.hidden}scheduleScan(){if(this.cancelScan||this.attempted.size>=OM)return;let e=()=>{this.cancelScan=void 0,this.canPrefetch()&&this.attempted.size<OM&&this.scan()};if(typeof requestIdleCallback==`function`){let t=requestIdleCallback(e,{timeout:AM});this.cancelScan=()=>cancelIdleCallback(t)}else{let t=setTimeout(e,AM);this.cancelScan=()=>clearTimeout(t)}}scan(){let e=this.root;if(e&&typeof IntersectionObserver<`u`){if(!this.observer){let t=new IntersectionObserver(e=>{if(this.observer===t&&this.canPrefetch()){for(let t of e){if(!(t.target instanceof HTMLAnchorElement))continue;let e=this.observed.get(t.target);e&&(e.visible=t.isIntersecting)}this.schedulePrefetch()}});this.observer=t,this.mutations=new MutationObserver(()=>this.scheduleScan()),this.mutations.observe(e,{childList:!0,subtree:!0,attributes:!0,attributeFilter:[`href`]})}for(let[t,{key:n}]of this.observed){let r=TM(t,ni.providerFor(t),this.resolveClaim);(!e.contains(t)||!r||ar(r)!==n)&&(this.observer.unobserve(t),this.observed.delete(t))}for(let t of e.querySelectorAll(`a[href]`)){if(this.observed.has(t))continue;let e=TM(t,ni.providerFor(t),this.resolveClaim);if(!e)continue;let n=ar(e);this.attempted.has(n)||(this.observed.set(t,{key:n,visible:!1}),this.observer.observe(t))}}}schedulePrefetch(){this.timer!==void 0||this.pendingKey!==void 0||!this.canPrefetch()||this.attempted.size>=OM||(this.timer=setTimeout(()=>{this.timer=void 0,this.prefetchNext()},kM))}async prefetchNext(){if(this.canPrefetch())for(let[e,{key:t,visible:n}]of this.observed){if(!n||!this.root?.contains(e)||this.attempted.has(t))continue;this.attempted.add(t);let r=this.scope;this.pendingKey=t;try{await EM(e,r.signal)}catch{}finally{r===this.scope&&(this.pendingKey=void 0,this.attempted.size>=OM?this.release():this.schedulePrefetch())}return}}},MM=pa(jM)})))()}function PM(e,t){return e?R`<openclaw-tooltip open-on-click .content=${e}>${t}</openclaw-tooltip>`:t}function FM(){return(FM=e((()=>{B(),ta()})))()}function IM(e){for(let t of e)for(let e of t.addedNodes)if(e instanceof Element&&(e.matches(`a.markdown-session-link, [data-session-href]`)||e.querySelector(`a.markdown-session-link, [data-session-href]`))){BM.define();return}}async function LM(e,t){if(t===`pointer`&&(e instanceof PointerEvent&&e.pointerType===`touch`||!globalThis.matchMedia?.(`(hover: hover)`).matches))return;let n=gx(e);if(!n||!BM.providerFor(n))return;await BM.define();let r=e.target;r instanceof EventTarget&&n.isConnected&&Dr(n,t,!0)&&r.dispatchEvent(new Event(t===`pointer`?`pointerover`:`focusin`,{bubbles:!0,composed:!0}))}var RM,zM,BM;function VM(){return(VM=e((()=>{sr(),Sx(),n(),RM=`openclaw-session-progress-hovercard-provider`,zM=null,BM=new Cr({tag:RM,load:async()=>(await T(async()=>{let{SessionProgressHovercardProvider:e}=await import(`./session-progress-hovercard.runtime-B-RMvw4i.js`);return{SessionProgressHovercardProvider:e}},__vite__mapDeps([40,1,2,3,4,5,6,41,23,24,42,25,43,44,45,7,10,8,9,27,28,46,29,47,48,49,50]),import.meta.url)).SessionProgressHovercardProvider,onDefined:()=>{zM?.disconnect(),zM=null}}),BM.install(LM),customElements.get(RM)||(zM=new MutationObserver(IM),zM.observe(document,{childList:!0,subtree:!0}),document.querySelector(`a.markdown-session-link, [data-session-href]`)&&BM.define())})))()}var HM;function UM(){return(UM=e((()=>{B(),H(),ii(),zr(),F(),M(),P_(),ta(),HM=class extends Sn{constructor(...e){super(...e),this.basePath=``,this.gatewayVersion=null,this.updateAttentionDismissed=!1,this.variant=`compact`}render(){let e=this.variant===`settings`?k_(Vr,this.gatewayVersion):this.variant===`identity`?this.updateAttentionDismissed?k_(Vr,this.gatewayVersion):O_(Vr):E_(Vr);return!e&&!this.updateAttentionDismissed?z:R`
      <openclaw-tooltip class="sidebar-hover-tooltip" .delay=${600} .closeDelay=${300}>
        <a
          class="sidebar-footer-build"
          href=${gi(`about`,this.basePath)}
          role=${this.variant===`identity`?`menuitem`:z}
          aria-label=${this.updateAttentionDismissed?`${j(`aboutPage.artifactDetails`)}. ${j(`updates.sidebar.availableTitle`)}`:j(`aboutPage.artifactDetails`)}
          @click=${e=>{k(e)&&(e.preventDefault(),this.onNavigate?.(`about`))}}
          >${e?R`<span class="sidebar-footer-build__text">${e}</span>`:z}
          ${this.updateAttentionDismissed?R`<span class="agent-select__badge sidebar-footer-build__update"
                  >${j(`updates.sidebar.availableTitle`)}</span
                >`:z}</a
        >
        <div slot="content" class="sidebar-hover-card sidebar-build-hover-card">
          ${j_(Vr,this.gatewayVersion)}
        </div>
      </openclaw-tooltip>
    `}},w([W({attribute:!1})],HM.prototype,`basePath`,void 0),w([W({attribute:!1})],HM.prototype,`gatewayVersion`,void 0),w([W({attribute:!1})],HM.prototype,`updateAttentionDismissed`,void 0),w([W({attribute:!1})],HM.prototype,`onNavigate`,void 0),w([W({attribute:!1})],HM.prototype,`variant`,void 0),globalThis.customElements&&!customElements.get(`openclaw-sidebar-build-chip`)&&customElements.define(`openclaw-sidebar-build-chip`,HM)})))()}function WM(e,t,n){if(!n||JM?.hubId!==e||JM.tab!==t)return;let r=JM;if(Date.now()-r.at>KM){JM=null;return}window.setTimeout(()=>{if(JM!==r)return;JM=null;let e=document.activeElement;n.isConnected&&Date.now()-r.at<=KM&&(e===r.source||e===document.body||e===document.documentElement)&&n.focus()},0)}function GM(e){let t=e.variant??`primary`,n=e.requestedActive??e.active,r=`hub-tabs hub-tabs--${t} ${e.id}-hub-tabs${e.carapace?` oc-segmented`:``}${e.className?` ${e.className}`:``}`,i=e.active===null?e.tabs.find(e=>!e.disabled)?.value:null;return R`
    <wa-tab-group
      class=${r}
      aria-label=${e.ariaLabel}
      .active=${e.active??qM}
      activation="manual"
      without-scroll-controls
      ${la(t=>AD(t,e.ariaLabel))}
    >
      ${e.tabs.map(t=>{let r=e.active===t.value;return R`
          <wa-tab
            id=${`${e.id}-tab-${t.value}`}
            panel=${t.value}
            aria-controls=${e.panelId}
            class="hub-tab ${e.carapace?`oc-segmented-item`:``}"
            ?active=${r}
            ?disabled=${t.disabled}
            .tabIndex=${r||t.value===i?0:-1}
            aria-selected=${r?`true`:`false`}
            data-test-id=${t.testId??z}
            @click=${r=>{let i=r.currentTarget;i instanceof HTMLElement&&!t.disabled&&(r.detail>0||r.isTrusted)&&t.value!==n&&(e.onSelect(t.value),e.onActivate?.(i))}}
            @keydown=${r=>{let i=r.currentTarget;i instanceof HTMLElement&&!t.disabled&&!r.repeat&&(r.key===`Enter`||r.key===` `)&&t.value!==n&&(r.preventDefault(),JM={hubId:e.id,tab:t.value,at:Date.now(),source:i},e.onSelect(t.value),e.onActivate?.(i))}}
            ${r?la(n=>WM(e.id,t.value,n)):z}
          >
            ${t.label}${t.count==null?z:R`<span class="hub-tab__badge hub-tab__badge--count">${t.count}</span>`}${t.badge==null?z:R`<span class="hub-tab__badge">${t.badge}</span>`}
          </wa-tab>
        `})}
    </wa-tab-group>
  `}var KM,qM,JM;function YM(){return(YM=e((()=>{B(),da(),jD(),KM=2e3,qM=`__openclaw-hub-tabs-no-active__`,JM=null})))()}var XM;function ZM(){return(ZM=e((()=>{me(),B(),H(),_t(),M(),rc(),XM=class extends Fn{constructor(...e){super(...e),this.timestampMs=null,this.polling=new Ro(this,6e4,()=>this.requestUpdate(),!1,`visible`)}connectedCallback(){super.connectedCallback(),this.polling.start(),this.requestUpdate()}render(){let e=le(this.timestampMs);return e===void 0?z:R`<time
          datetime=${new Date(e).toISOString()}
          title=${Le(e)}
          >${st(e)}</time
        >`}},w([W({attribute:!1})],XM.prototype,`timestampMs`,void 0),customElements.get(`openclaw-relative-time`)||customElements.define(`openclaw-relative-time`,XM)})))()}function QM(e,t,n){if(!t)return z;let r=j(`attention.dismissItem`,{item:e});return R`<button
    type="button"
    class="sidebar-issues-panel__dismiss"
    aria-label=${r}
    aria-busy=${n?`true`:z}
    title=${n?j(`attention.mentions.dismissing`):r}
    ?disabled=${n}
    @click=${e=>{e.preventDefault(),e.stopPropagation(),t()}}
  >
    ${I.x}
  </button>`}function $M(e){return R`<details
    class="sidebar-issues-panel__details ${e.severity?`sidebar-issues-panel__details--${e.severity}`:``}"
  >
    <summary class="sidebar-issues-panel__summary" data-issue-row-focus>
      <span
        class="sidebar-issues-panel__icon ${e.critical?`sidebar-issues-panel__icon--critical`:``}"
        aria-hidden="true"
        >${e.icon}</span
      >
      <span class="sidebar-issues-panel__content">
        <span class="sidebar-issues-panel__entity" title=${e.title}>${e.title}</span>
        <span class="sidebar-issues-panel__state-row sidebar-issues-panel__notification-meta">
          <span class="sidebar-issues-panel__state" title=${e.detail}>${e.detail}</span>
          ${e.timestampMs==null?z:R`
                  <span aria-hidden="true">·</span>
                  <openclaw-relative-time
                    class="sidebar-issues-panel__age"
                    .timestampMs=${e.timestampMs}
                  ></openclaw-relative-time>
                `}
        </span>
      </span>
      ${QM(e.title,e.onDismiss,e.dismissing)}
      <span class="sidebar-issues-panel__chevron" aria-hidden="true">${I.chevronRight}</span>
    </summary>
    <div class="sidebar-issues-panel__body ${e.bodyClass??``}">${e.body}</div>
  </details>`}function eN(){return(eN=e((()=>{B(),F(),L(),ZM()})))()}function tN(e){let{mention:t,context:n}=e,r={id:t.senderProfileId,identity:{type:`profile`,id:t.senderProfileId},name:t.senderLabel,avatarUrl:t.senderAvatarUrl,watchedSessions:[]},i=j(`attention.mentions.from`,{sender:t.senderLabel}),a=Bn({face:`chat`,sessionKey:t.sessionKey,fallbackAgentId:t.agentId,basePath:n.basePath,row:{key:t.sessionKey,displayName:t.sessionTitle},exactKey:!0});return R`<article
    class="sidebar-mention-row"
    data-attention-kind="mention"
    data-mention-id=${t.id}
    aria-label=${i}
  >
    ${Ca(t.id,$M({title:t.sessionTitle,detail:i,timestampMs:t.createdAt,icon:R`<openclaw-viewer-avatar
          .user=${r}
          .markAsViewer=${!1}
          variant="footer"
        ></openclaw-viewer-avatar>`,onDismiss:e.onDismiss,dismissing:e.dismissing,body:R`
          ${t.excerpt?R`<p class="sidebar-mention-row__excerpt">${t.excerpt}</p>`:z}
          <div class="sidebar-issues-panel__actions sidebar-mention-row__actions">
            <a
              class="sidebar-issues-panel__action sidebar-issues-panel__action--primary"
              href=${a.href}
              @click=${t=>{k(t)&&(t.preventDefault(),e.onNavigate(`chat`,a.options))}}
              >${j(`attention.mentions.open`)}</a
            >
          </div>
        `}))}
  </article>`}function nN(e){let t=e.context,n=t.overlays.snapshot,r=e.approval.request.sessionKey?.trim(),i=r?t.sessions.state.result?.sessions.find(e=>O(e.key,r)):void 0,a=r?Bn({context:t,face:`chat`,sessionKey:r}):null;return yM({approval:e.approval,busy:n.approvalBusy,canGrant:n.approvalCanGrant,error:n.approvalErrors.get(e.approval.id)??null,openSessionHref:a?.href,sessionTitle:i?.displayName?.trim()||i?.label?.trim(),onDecision:e.onDecision,onOpenSession:a?t=>{k(t)&&(t.preventDefault(),e.onNavigate(`chat`,a.options))}:void 0})}function rN(e){let t=e.context,n=t.overlays.snapshot,r=t.gateway.snapshot;return R`<openclaw-sidebar-update-card
    class="sidebar-issues-panel__update"
    data-attention-kind="updateAvailable"
    .compact=${!0}
    .updateAvailable=${n.updateAvailable}
    .updateSchedule=${n.updateSchedule}
    .heldUpdateCampaignId=${n.heldUpdateCampaignId}
    .updateBusy=${n.updateRunning||n.updateReconciliationPending}
    .updateRun=${n.updateRun}
    .updateRunAcknowledged=${n.updateRunAcknowledged}
    .connected=${r.phase===`connected`}
    .onAcknowledge=${()=>t.overlays.acknowledgeUpdateRun()}
    .onCheckStatus=${()=>t.overlays.refreshUpdateStatus()}
    .statusBanner=${n.updateStatusBanner}
    .watchUpdateProgress=${e.watchUpdateProgress}
    .canUpdate=${ao(r,`update.run`,`operator.admin`)}
    .canHoldUpdate=${ao(r,`update.hold`,`operator.admin`)}
    .onUpdate=${()=>void t.overlays.runUpdate()}
    .refreshRequired=${!1}
    .onHoldUpdate=${()=>t.overlays.holdUpdate()}
    .onReviewUpdate=${e.onNavigate}
    .onDismiss=${e.onDismiss}
  ></openclaw-sidebar-update-card>`}function iN(e){switch(e.phase){case`guidance`:return j(`connection.scopeUpgrade.guidance`);case`available`:return j(`connection.scopeUpgrade.limited`);case`requesting`:return j(`connection.scopeUpgrade.requesting`);case`pending`:return j(`connection.scopeUpgrade.pending`,{command:`openclaw devices approve ${e.requestId}`});case`rejected`:return j(e.expired?`connection.scopeUpgrade.expired`:`connection.scopeUpgrade.rejected`);case`error`:return j(`connection.scopeUpgrade.error`,{error:e.message})}return e}function aN(e){if(e.state.phase===`hidden`)return z;let t=iN(e.state),n=j(`connection.scopeUpgrade.inboxState`),r=e.state.phase===`error`?e.state.retryable:e.state.phase===`pending`||e.state.phase===`rejected`;return R`<details
    class="sidebar-issues-panel__details sidebar-issues-panel__details--${e.state.phase===`error`||e.state.phase===`rejected`?`error`:`warning`}"
    data-attention-kind="scopeUpgrade"
  >
    <summary class="sidebar-issues-panel__summary" data-issue-row-focus>
      <span class="sidebar-issues-panel__icon" aria-hidden="true">${I.shieldQuestion}</span>
      <span class="sidebar-issues-panel__content">
        <span class="sidebar-issues-panel__entity">${j(`connection.scopeUpgrade.status`)}</span>
        <span class="sidebar-issues-panel__state" title=${n}>${n}</span>
      </span>
      ${QM(j(`connection.scopeUpgrade.status`),e.onDismiss)}
      <span class="sidebar-issues-panel__chevron" aria-hidden="true">${I.chevronRight}</span>
    </summary>
    <div class="sidebar-issues-panel__body" role="status" aria-live="polite">
      <div>${t}</div>
      ${e.state.phase===`available`||e.state.phase===`requesting`?R`<div class="sidebar-issues-panel__actions">
              <button
                type="button"
                class="sidebar-issues-panel__action sidebar-issues-panel__action--primary"
                ?disabled=${e.state.phase===`requesting`}
                @click=${e.state.phase===`available`?e.onRequest:z}
              >
                ${j(e.state.phase===`available`?`connection.scopeUpgrade.request`:`connection.scopeUpgrade.requestingAction`)}
              </button>
            </div>`:r||e.state.phase===`error`?R`<div class="sidebar-issues-panel__actions">
                ${r?R`<button
                        type="button"
                        class="sidebar-issues-panel__action sidebar-issues-panel__action--primary"
                        @click=${e.onRetry}
                      >
                        ${j(`connection.scopeUpgrade.retry`)}
                      </button>`:z}
                <button
                  type="button"
                  class="sidebar-issues-panel__action"
                  @click=${e.onCancel}
                >
                  ${j(`connection.scopeUpgrade.cancel`)}
                </button>
              </div>`:z}
    </div>
  </details>`}function oN(e){return e.meta?R`<span class="sidebar-issues-panel__state-row" title=${e.detail}>
    ${e.meta.context?R`<span class="sidebar-issues-panel__meta-context">${e.meta.context}</span>
            <span aria-hidden="true">·</span>`:z}
    <span class="sidebar-issues-panel__meta-status">${e.meta.status}</span>
    <span aria-hidden="true">·</span>
    <span class="sidebar-issues-panel__meta-time">${e.meta.time}</span>
  </span>`:R`<span class="sidebar-issues-panel__state" title=${e.detail}
      >${e.detail}</span
    >`}function sN(e,t){if(e.action.kind!==`navigate`)return z;let n=e.action.routeId;return R`<div
    class="sidebar-issues-panel__details sidebar-issues-panel__details--${e.severity}"
    data-attention-kind=${e.kind}
  >
    <div class="sidebar-issues-panel__summary sidebar-issues-panel__summary--navigation">
      <a
        class="sidebar-issues-panel__navigation-link"
        href=${gi(n,t.basePath)}
        data-issue-row-focus
        @click=${e=>{k(e)&&(e.preventDefault(),t.onNavigate(n))}}
      >
        <span class="sidebar-issues-panel__icon" aria-hidden="true">${I[e.icon]}</span>
        <span class="sidebar-issues-panel__content">
          <span class="sidebar-issues-panel__entity" title=${e.label}>${e.label}</span>
          ${oN(e)}
        </span>
      </a>
      ${QM(e.label,t.onDismiss)}
      <span class="sidebar-issues-panel__chevron" aria-hidden="true">${I.chevronRight}</span>
    </div>
  </div>`}function cN(e,t){if(e.action.kind===`navigate`)return sN(e,t);let n=e.action.alert.facts.filter(t=>t!==e.label),r=e.inlineAction;return R`<details
    class="sidebar-issues-panel__details sidebar-issues-panel__details--${e.severity}"
    data-attention-kind=${e.kind}
  >
    <summary class="sidebar-issues-panel__summary" data-issue-row-focus>
      <span
        class="sidebar-issues-panel__icon ${e.kind===`modelAuthExpired`?`sidebar-issues-panel__icon--critical`:``}"
        aria-hidden="true"
        >${I[e.icon]}</span
      >
      <span class="sidebar-issues-panel__content">
        <span class="sidebar-issues-panel__entity" title=${e.label}>${e.label}</span>
        ${oN(e)}
      </span>
      ${QM(e.label,t.onDismiss)}
      <span class="sidebar-issues-panel__chevron" aria-hidden="true">${I.chevronRight}</span>
    </summary>
    <div class="sidebar-issues-panel__body">
      ${n.length?R`<ul class="sidebar-issues-panel__facts">
              ${n.map(e=>R`<li>${e}</li>`)}
            </ul>`:z}
      <div class="sidebar-issues-panel__actions">
        ${r?R`<button
                type="button"
                class="sidebar-issues-panel__action sidebar-issues-panel__action--primary"
                @click=${()=>t.onNavigate(r.routeId)}
              >
                ${r.label}
              </button>`:z}
        <button
          type="button"
          class="sidebar-issues-panel__action ${r?``:`sidebar-issues-panel__action--primary`}"
          @click=${()=>t.onOpen(e)}
        >
          ${j(`nav.askOpenClaw`)}
        </button>
      </div>
    </div>
  </details>`}function lN(){return(lN=e((()=>{B(),Ea(),ii(),F(),js(),so(),Qt(),N(),CM(),L(),eN(),Xl(),lh(),dc()})))()}function uN(e){return j(fN[e])}var dN,fN;function pN(){return(pN=e((()=>{F(),js(),dc(),dN=[`all`,`approvals`,`mentions`,`automations`,`system`],fN={all:`attention.tabs.all`,approvals:`attention.tabs.approvals`,mentions:`attention.tabs.mentions`,automations:`attention.tabs.automations`,system:`attention.tabs.system`}})))()}function mN(e){let{entry:t,context:n}=e,r=n.gateway.connectionRevision,i=n.gateway.snapshot.client?.recoveryScope,a=fn(n,t.sessionKey,t.agentId),o=Ve(a?.displayName?.trim()||a?.label?.trim()||j(`attention.outbox.conversation`),100),s=n.agents.state.agentsList?.agents.find(e=>e.id===t.agentId),c=s?`${Ve(Qe(s),60)} · ${o}`:o,l=j(t.command?t.unconfirmed?`attention.outbox.commandUnconfirmed`:`attention.outbox.commandFailed`:t.unconfirmed?`attention.outbox.unconfirmed`:`attention.outbox.failed`),u=Bn({context:n,face:`chat`,sessionKey:t.sessionKey,agentId:t.agentId,exactKey:!0,focusComposer:!0}),d=n.gateway.snapshot.phase!==`connected`,f=[j(t.unconfirmed?t.command?`attention.outbox.checkCommandBeforeRetry`:`attention.outbox.checkBeforeRetry`:`attention.outbox.reviewHint`),...d?[j(`attention.outbox.offlineHint`)]:[]].join(` `);return R`<article
    class="sidebar-issues-panel__details sidebar-issues-panel__details--${t.severity}"
    data-attention-kind="outbox"
    data-outbox-id=${t.id}
  >
    <div class="sidebar-issues-panel__summary sidebar-outbox-row">
      <span
        class="sidebar-issues-panel__icon sidebar-outbox-row__icon sidebar-outbox-row__icon--${t.severity}"
        aria-hidden="true"
        >${I.alertTriangle}</span
      >
      <div class="sidebar-issues-panel__content">
        <span class="sidebar-issues-panel__entity">${l}</span>
        <span class="sidebar-outbox-row__meta">
          <span class="sidebar-issues-panel__state" title=${c}>${c}</span>
          ${d?R`<span class="sidebar-outbox-row__offline"><span aria-hidden="true">·</span> ${j(`attention.outbox.offline`)}</span>`:z}
        </span>
      </div>
      <openclaw-tooltip .content=${f}>
        <a
          class="sidebar-issues-panel__action sidebar-outbox-row__review"
          href=${u.href}
          aria-label=${j(`attention.outbox.review`)}
          data-issue-row-focus
          @click=${a=>{k(a)&&(a.preventDefault(),n.gateway.connectionRevision===r&&n.gateway.snapshot.client?.recoveryScope===i&&n.sidebarAttention.entries.some(e=>e.type===`outbox`&&e.id===t.id&&e.sessionKey===t.sessionKey&&e.agentId===t.agentId)&&(e.onNavigate(`chat`,u.options),t.dismissal&&n.sidebarAttention.dismiss(t.dismissal)))}}
          >${j(`attention.outbox.reviewShort`)}</a
        >
      </openclaw-tooltip>
    </div>
  </article>`}function hN(){return(hN=e((()=>{B(),F(),js(),pt(),_t(),Qt(),L(),ta(),dc()})))()}var gN;function _N(){return(_N=e((()=>{li(),P(),yr(),gN=class{constructor(e,t){this.onChange=t,this.operation=null,this.value={phase:`hidden`},this.current=e,this.sync(e)}get state(){return this.value}sync(e){this.current=e;let t=e.client,n=Mr(e);if(!t||n.phase!==`available`){this.retireOperation(),this.setState(n);return}this.operation&&this.operation.client!==t&&(this.retireOperation(),this.setState({phase:`available`})),(this.value.phase===`hidden`||this.value.phase===`guidance`)&&this.setState({phase:`available`})}request(){this.start(!1)}retry(){this.start(!0)}cancel(){this.retireOperation(),this.setState(Mr(this.current))}dispose(){this.retireOperation()}start(e){let t=this.current.client;if(!t||Mr(this.current).phase!==`available`)return;if(this.operation){if(!e)return;this.retireOperation()}let n={client:t};this.operation=n,this.setState({phase:`requesting`}),t.requestScopeUpgrade({onPending:e=>{this.isCurrent(n)&&this.setState({phase:`pending`,requestId:e})}}).then(e=>{this.isCurrent(n)&&e.status!==`approved`&&this.setState({phase:`rejected`,requestId:e.requestId,expired:e.status===`expired`})}).catch(e=>{!this.isCurrent(n)||e instanceof Error&&e.name===`AbortError`||this.setState({phase:`error`,message:E(e),retryable:!(e instanceof Xn)||e.retryable})}).finally(()=>{this.isCurrent(n)&&(this.operation=null)})}isCurrent(e){return this.operation===e&&this.current.client===e.client}retireOperation(){let e=this.operation;this.operation=null,e?.client.cancelScopeUpgrade()}setState(e){JSON.stringify(this.value)!==JSON.stringify(e)&&(this.value=e,this.onChange())}}})))()}function vN(e){let{anchor:t}=e.panelPosition,n=e.panelPosition.anchor===`top`?e.panelPosition.top:e.panelPosition.bottom,r=`left:${e.panelPosition.left}px;${t}:${n}px;--sidebar-issues-panel-${t}:${n}px`,i=e.entries.filter(t=>Oh(t,e.selectedTab)),a=i.flatMap(e=>e.dismissal?[e.dismissal]:[]),o=e.mentions.snapshot,s=i.flatMap(e=>e.type===`mention`?[e.mention.id]:[]),c=s.filter(e=>!o.dismissing.includes(e)),l=a.length>0||s.length>0,u=a.length>0||c.length>0,d=e.selectedTab===`mentions`,f=e.context.gateway.snapshot.phase===`connected`&&(d||e.selectedTab===`all`)&&(o.error!==null||o.phase===`loading`||d&&o.phase===`unavailable`),p=kh(e.entries);return R`<button
      type="button"
      class="sidebar-issues-panel__backdrop"
      aria-label=${j(`common.close`)}
      @click=${()=>e.onClose(!0)}
    ></button>
    <openclaw-menu-surface>
      <section
        id="sidebar-issues-panel"
        class="sidebar-issues-panel"
        role="dialog"
        aria-modal=${$i()?`true`:z}
        aria-labelledby="sidebar-issues-panel-heading"
        style=${r}
        @keydown=${e.onKeydown}
      >
        <div class="sidebar-issues-panel__grabber" aria-hidden="true"></div>
        <header class="sidebar-issues-panel__header">
          <h2 id="sidebar-issues-panel-heading" class="sidebar-issues-panel__heading">
            <span class="sidebar-issues-panel__heading-icon" aria-hidden="true"
              >${I.inbox}</span
            >
            ${j(`attention.issues`)}
          </h2>
          <div class="sidebar-issues-panel__header-actions">
            <button
              type="button"
              class="btn btn--xs btn--ghost sidebar-issues-panel__dismiss-shown"
              style=${l?z:`visibility:hidden`}
              ?disabled=${!u}
              aria-hidden=${l?z:`true`}
              @click=${()=>{for(let t of a)e.onDismiss(t);c.length>0&&e.mentions.dismiss(c)}}
            >
              ${j(`attention.dismissShown`)}
            </button>
            <openclaw-tooltip .content=${j(`attention.mentions.notifications`)}>
              <a
                class="sidebar-brand__icon"
                aria-label=${j(`attention.mentions.notifications`)}
                href=${gi(`notifications`,e.context.basePath)}
                @click=${t=>{k(t)&&(t.preventDefault(),e.onNavigate(`notifications`))}}
                >${I.settings}</a
              >
            </openclaw-tooltip>
            <button
              type="button"
              class="sidebar-brand__icon sidebar-issues-panel__mobile-close"
              aria-label=${j(`common.close`)}
              @click=${()=>e.onClose(!0)}
            >
              ${I.x}
            </button>
          </div>
        </header>
        ${GM({id:`sidebar-issues`,active:e.selectedTab,tabs:dN.map(e=>({value:e,label:uN(e),count:p[e]>0?p[e]:null})),ariaLabel:j(`attention.tabs.label`),panelId:`sidebar-issues-tabpanel`,className:`sidebar-issues-panel__tabs`,variant:`sub`,onSelect:e.onSelectTab})}
        <div class="sidebar-issues-panel__list-wrap">
          <div
            id="sidebar-issues-tabpanel"
            class="sidebar-issues-panel__list"
            role="tabpanel"
            aria-labelledby=${`sidebar-issues-tab-${e.selectedTab}`}
            tabindex="0"
            @scroll=${e.onScroll}
          >
            ${f?R`<div class="sidebar-issues-panel__mentions-note" role="status">
                    <span
                      >${j(o.error===null?o.phase===`loading`?`attention.mentions.loading`:`attention.mentions.unavailable`:`attention.mentions.error`)}</span
                    >
                    ${o.error===null?z:R`<span>${o.error}</span>
                            <button
                              type="button"
                              class="sidebar-issues-panel__action"
                              ?disabled=${o.phase===`loading`}
                              @click=${()=>void e.mentions.refresh()}
                            >
                              ${j(`attention.mentions.refresh`)}
                            </button>`}
                  </div>`:z}
            ${i.length===0&&!f?R`<div class="sidebar-issues-panel__empty">
                    <span class="sidebar-issues-panel__empty-icon" aria-hidden="true"
                      >${I.inbox}</span
                    >
                    <strong
                      >${j(d?`attention.mentions.emptyTitle`:`attention.emptyTitle`)}</strong
                    >
                    <span
                      >${j(d?`attention.mentions.emptyBody`:`attention.emptyBody`)}</span
                    >
                  </div>`:z}
            ${i.map(t=>{let n=t.dismissal,r=n?()=>e.onDismiss(n):void 0;switch(t.type){case`outbox`:return mN({entry:t,context:e.context,onNavigate:e.onNavigate});case`approval`:return nN({approval:t.approval,context:e.context,onNavigate:e.onNavigate,onDecision:e.onApprovalDecision});case`attention`:return cN(t,{basePath:e.context.basePath,onDismiss:r,onNavigate:e.onNavigate,onOpen:e.onOpen});case`mention`:return tN({mention:t.mention,context:e.context,dismissing:o.dismissing.includes(t.mention.id),onDismiss:()=>void e.mentions.dismiss([t.mention.id]),onNavigate:e.onNavigate});case`scopeUpgrade`:return aN({state:t.state,onCancel:()=>e.context.scopeUpgrade.cancel(),onDismiss:r,onRequest:()=>e.context.scopeUpgrade.request(),onRetry:()=>e.context.scopeUpgrade.retry()});case`update`:return rN({context:e.context,onDismiss:r,onNavigate:()=>e.onNavigate(`updates`),watchUpdateProgress:e.watchUpdateProgress})}return t})}
          </div>
          <div
            class="sidebar-issues-panel__overflow-cue sidebar-issues-panel__overflow-cue--top"
            ?hidden=${!e.overflowAbove}
            aria-hidden="true"
          ></div>
          <div
            class="sidebar-issues-panel__overflow-cue sidebar-issues-panel__overflow-cue--bottom"
            ?hidden=${!e.overflowBelow}
            aria-hidden="true"
          ></div>
        </div>
        ${d?R`<footer class="sidebar-issues-panel__mentions-note">
                <span>${j(`attention.mentions.retention`)}</span>
              </footer>`:z}
      </section>
    </openclaw-menu-surface>`}function yN(){return(yN=e((()=>{B(),ii(),nr(),F(),js(),YM(),L(),Ah(),lN(),pN(),hN(),jm(),_N(),dc()})))()}function bN(e){return[...e?.querySelectorAll(`:scope > wa-dropdown-item:not([disabled]), :scope > .sidebar-agent-menu__agent-grid > wa-dropdown-item:not([disabled])`)??[]]}function xN(e,t){e.forEach(e=>e.active=e===t),t.focus({preventScroll:!0}),t.scrollIntoView?.({block:`nearest`})}function SN(e,t){e.target===e.currentTarget&&t(Kf(e))}function CN(e){if(![`ArrowDown`,`ArrowUp`,`Home`,`End`].includes(e.key)||e.target instanceof HTMLInputElement&&(e.key===`Home`||e.key===`End`))return!1;let t=e.currentTarget.closest(`wa-dropdown`),n=bN(t),r=t?.querySelector(`.sidebar-identity-menu__footer`),i=[...n,...r?.querySelectorAll(`a[href], button:not([disabled])`)??[]],a=e.target instanceof HTMLElement?e.target:null,o=a?i.indexOf(a):-1;if(r&&o<0)return!1;let s=e.key===`ArrowDown`?1:-1,c=e.key===`Home`?n[0]:e.key===`End`?n.at(-1):o<0?n.at(s===1?0:-1):i[(o+s+i.length)%i.length];return!c||r&&!r.contains(a)&&!r.contains(c)?!1:(e.preventDefault(),e.stopPropagation(),xN(n,c),!0)}function wN(e){if(e.key.length!==1||e.metaKey||e.ctrlKey||e.altKey)return!1;let t=e.currentTarget;if(!(t instanceof HTMLElement))return!1;let n=PN.get(t);if(e.key===` `&&!n?.query)return!1;e.preventDefault(),e.stopPropagation(),n&&clearTimeout(n.timeout);let r=`${n?.query??``}${e.key}`.trim().toLowerCase(),i=setTimeout(()=>PN.delete(t),1e3);PN.set(t,{query:r,timeout:i});let a=bN(t),o=a.find(e=>(e.textContent??``).trim().toLowerCase().startsWith(r));return o&&xN(a,o),!0}function TN(e){let{agents:t}=e,n=new Set(e.pinnedAgentIds.map(b));return t.toSorted((e,t)=>+!n.has(b(e.id))-!n.has(b(t.id)))}function EN(e,t,n){let r=b(e.id),i=t.identities.get(r)??null,a=Qe(e,i),o=r===t.activeId,s=o?0:t.agentUnreadCount(r),c={value:r,label:a,agent:e},l=vt(e,i),u=l?t.resolveAvatarUrl(l):null;return R`
    <wa-dropdown-item
      class="sidebar-customize-menu__item sidebar-agent-menu__agent-switch agent-select__option ${o?`sidebar-agent-menu__agent-switch--active`:``}"
      value=${`${jN}${encodeURIComponent(r)}`}
      type="checkbox"
      role="menuitemradio"
      aria-checked=${String(o)}
      ?autofocus=${n}
      ${la(e=>qf(e,o))}
    >
      <span class="sidebar-agent-menu__agent-tile">
        <span class="sidebar-agent-menu__agent-avatar">
          ${ip(c,i,u,l?t.avatarErrorHandler(l):void 0)}
        </span>
        ${ap(c)}
        <span class="sidebar-agent-menu__agent-status">
          ${s>0?R`<span
                  class="session-unread-dot"
                  role="img"
                  aria-label=${j(`sessionsView.unread`)}
                ></span>`:z}
        </span>
      </span>
    </wa-dropdown-item>
  `}function DN(){return R`
    ${AN.map(e=>R`
        <wa-dropdown-item
          slot="submenu"
          class="sidebar-customize-menu__item"
          value=${`${NN}${encodeURIComponent(e.href)}`}
          data-new-tab-action
          @click=${e=>{e.target instanceof Element&&e.target.closest(`a`)&&(e.currentTarget.dataset.nativeNavigation=`true`)}}
        >
          <a
            href=${e.href}
            target=${Sc}
            rel=${Es()}
            tabindex="-1"
          >
            <span slot="icon" class="nav-item__icon" aria-hidden="true">${I[e.icon]}</span>
            <span class="sidebar-customize-menu__text">${e.label()}</span>
          </a>
        </wa-dropdown-item>
      `)}
  `}function ON(){return R`
    <wa-dropdown-item
      class="sidebar-customize-menu__item sidebar-identity-menu__help"
      value="command:help"
    >
      <span slot="icon" class="nav-item__icon" aria-hidden="true">${I.circleQuestionMark}</span>
      <span class="sidebar-customize-menu__text">${j(`agentChip.help`)}</span>
      ${DN()}
    </wa-dropdown-item>
  `}function kN(e){let t=e.position,{activeId:n,activeName:r,agents:i}=e,a=!e.rosterMode&&i.length>1?TN(e):[],o=e.openMode===`click`?a.find(e=>b(e.id)===n)??a[0]:void 0,s=j(e.rosterMode?`agentChip.workspaceMenuLabel`:`agentChip.menuLabel`);return R`
    <wa-dropdown
      class="sidebar-customize-menu sidebar-agent-menu"
      data-chat-autotype-exempt
      .open=${!0}
      placement="bottom-start"
      .distance=${0}
      aria-label=${s}
      @pointerenter=${e.onPointerEnter}
      @pointerleave=${e.onPointerLeave}
      @wa-select=${t=>{t.preventDefault();let r=t.detail.item;if(r.dataset.nativeNavigation){delete r.dataset.nativeNavigation,e.onClose(!1);return}let i=r.value;if(i){if(e.onClose(!1),i.startsWith(`link:`)){xn(decodeURIComponent(i.slice(5)));return}if(i.startsWith(jN)){e.onSwitchAgent(decodeURIComponent(i.slice(6)));return}switch(i){case`${MN}sidebar-agents`:e.onToggleRoster();break;case`${MN}all-agents`:e.onNavigate(`agents-home`);break;case`${MN}new-agent`:e.onNavigate(`custodian`,{search:`?intent=new-agent`});break;case`${MN}capabilities`:e.onAskCapabilities(n);break;case`${MN}agent-settings`:e.onNavigate(`agents`,{pathname:pi(n,null,e.basePath)})}}}}
      @wa-after-show=${e.onAfterShow}
      @keydown=${t=>{if(CN(t)||wN(t))return;let n=t.target instanceof HTMLElement?t.target.closest(`.sidebar-agent-menu__agent-grid > wa-dropdown-item:not([disabled])`):null;if((t.key===`Enter`||t.key===` `)&&n){t.preventDefault(),t.stopPropagation(),n.click();return}Gf(t,e.onTabAway)}}
      @wa-after-hide=${t=>SN(t,e.onClose)}
    >
      ${Qh({x:t.x,y:t.top},s)}
      ${a.length>0?R`
              <div class="sidebar-customize-menu__title">${j(`agentChip.agents`)}</div>
              <div class="sidebar-agent-menu__agent-grid">
                ${a.map(t=>EN(t,e,t===o))}
              </div>
              <div class="sidebar-customize-menu__separator" role="separator"></div>
            `:z}
      <wa-dropdown-item
        class="sidebar-customize-menu__item"
        value="command:sidebar-agents"
        type=${e.rosterMode?`normal`:`checkbox`}
      >
        ${j(e.rosterMode?`agentChip.showOneAgent`:`agentChip.showAllAgents`)}
      </wa-dropdown-item>
      ${e.rosterMode?z:R`
              ${Zh(`command:all-agents`,j(`agentChip.allAgents`),`bot`)}
              ${Zh(`command:new-agent`,j(`custodian.newAgent`),`users`)}
              ${Zh(`command:capabilities`,j(`agentChip.whatCanAgentDo`,{name:r}),`bot`,{disabled:!e.connected})}
            `}
      ${Zh(`command:agent-settings`,j(`agentChip.agentSettings`),`settings`)}
      ${e.rosterMode?ON():z}
    </wa-dropdown>
  `}var AN,jN,MN,NN,PN;function FN(){return(FN=e((()=>{B(),da(),ii(),F(),pt(),$e(),vc(),Rt(),N(),sp(),og(),L(),rp(),AN=[{href:`https://docs.openclaw.ai`,icon:`book`,label:()=>j(`common.docs`)},{href:`https://docs.openclaw.ai/help`,icon:`messageSquare`,label:()=>j(`agentChip.getHelp`)},{href:`https://discord.gg/clawd`,icon:`users`,label:()=>j(`agentChip.discord`)},{href:`https://docs.openclaw.ai/releases`,icon:`scrollText`,label:()=>j(`agentChip.viewChangelog`)}],jN=`agent:`,MN=`command:`,NN=`link:`,PN=new WeakMap})))()}function IN(e){let t=pd();if(!t)return z;let n=t.snapshot,r=n?.gateways.find(e=>e.id===n.currentId);return R`
    <div class="sidebar-customize-menu__title">${j(`nav.gateway.sectionLabel`)}</div>
    ${n?.gateways.map((r,i)=>{let a=r.id===n.currentId,o={ok:j(`nav.gateway.connected`),error:j(`nav.gateway.unreachable`),unknown:j(`nav.gateway.unknown`)}[r.health],s=n=>{(n.metaKey||n.ctrlKey)&&(n.preventDefault(),n.stopPropagation(),t.openWindow(r.id),e(!1))};return R`<wa-dropdown-item
        class="sidebar-customize-menu__item"
        value=${`gateway:${encodeURIComponent(r.id)}`}
        role="menuitemradio"
        aria-checked=${String(a)}
        ${la(e=>qf(e,a))}
        @click=${s}
        @contextmenu=${s}
      >
        <span
          slot="icon"
          class="sidebar-gateway-health"
          data-health=${r.health}
          role="img"
          aria-label=${o}
        ></span>
        <span class="sidebar-customize-menu__text">${r.name}</span>
        <span slot="details" class="sidebar-gateway-details">
          ${r.isPrimary?R`<span class="sidebar-gateway-primary">${j(`nav.gateway.primaryTag`)}</span>`:z}
          ${!a&&i<9?cr([`⌘`,String(i+1)],{className:`session-menu__shortcut`,ariaHidden:!0}):z}
          ${a?R`<span class="sidebar-gateway-check" aria-hidden="true">${I.check}</span>`:z}
        </span>
      </wa-dropdown-item>`})}
    ${r?.canPromote?Zh(`command:gateway-set-primary`,j(`nav.gateway.setPrimary`),`star`):z}
    ${Zh(`command:gateway-settings`,j(`nav.gateway.openSettings`),`server`)}
    <div class="sidebar-customize-menu__separator" role="separator"></div>
  `}function LN(e){let t=e.position,n=e.profileViewer?.name??e.profileViewer?.email??j(`nav.owner`),r={id:`owner`,watchedSessions:[],...e.profileViewer,name:n},i=e.profileViewer?.email&&e.profileViewer.email!==n?e.profileViewer.email:null;return R`
    <wa-dropdown
      class="sidebar-customize-menu sidebar-identity-menu"
      style=${`--sidebar-identity-menu-min-width: ${e.triggerWidth}px`}
      .open=${!0}
      placement="top-start"
      .distance=${0}
      aria-label=${j(`profilePage.identity.menuLabel`)}
      @wa-select=${t=>{t.preventDefault();let n=t.detail.item;if(n.dataset.nativeNavigation){delete n.dataset.nativeNavigation,e.onClose(!1);return}let r=n.value;if(!r)return;e.onClose(!1);let i=pd();if(r.startsWith(`gateway:`)){let e=decodeURIComponent(r.slice(8));e!==i?.snapshot?.currentId&&i?.select(e);return}if(r.startsWith(`link:`)){xn(decodeURIComponent(r.slice(NN.length)));return}switch(r){case`${MN}gateway-set-primary`:{let e=i?.snapshot?.gateways.find(e=>e.id===i.snapshot?.currentId);e?.canPromote&&i?.setPrimary(e.id);break}case`${MN}gateway-settings`:i?.openSettings();break;case`${MN}profile`:e.onNavigate(`profile`,{hash:`#settings-profile-identity`});break;case`${MN}settings`:e.onNavigate(`appearance`);break;case`${MN}usage`:e.onNavigate(`usage`);break;case`${MN}pair-mobile`:e.onPairMobile();break;case`${MN}apps`:e.onNavigate(`apps`);break;case`${MN}debug-overlay`:Gl();break;case`${MN}retry-connect`:e.onRetryConnect?.()}}}
      @keydown=${t=>{CN(t)||Gf(t,e.onTabAway)}}
      @wa-after-hide=${t=>SN(t,e.onClose)}
    >
      ${Qh({x:t.x,y:t.bottom},j(`profilePage.identity.menuLabel`),`bottom`)}
      <wa-dropdown-item
        class="sidebar-customize-menu__item sidebar-identity-menu__header"
        value="command:profile"
      >
        <span slot="icon" class="sidebar-identity-menu__avatar" aria-hidden="true">
          <openclaw-viewer-avatar .user=${r} variant="footer"></openclaw-viewer-avatar>
        </span>
        <span class="sidebar-identity-menu__identity">
          <span class="sidebar-identity-menu__name" title=${n}>${n}</span>
          ${i?R`<span class="sidebar-identity-menu__email" title=${i}
                  >${i}</span
                >`:z}
        </span>
      </wa-dropdown-item>
      <div class="sidebar-customize-menu__separator" role="separator"></div>
      ${IN(e.onClose)}
      ${Zh(`command:settings`,j(`nav.settings`),`settings`,{details:mr(Nt.appearanceSettings,{slot:`details`,className:`session-menu__shortcut`,ariaHidden:!0})})}
      ${Zh(`command:usage`,br(`usage`),`coins`)}
      <div class="sidebar-customize-menu__separator" role="separator"></div>
      ${Zh(`command:pair-mobile`,j(`devices.pairing.button`),`smartphone`,{className:`sidebar-pair-mobile`,disabled:!e.canPairDevice,title:e.canPairDevice?void 0:j(`devices.pairing.adminRequired`)})}
      ${Zh(`command:apps`,j(`agentChip.getApps`),`layoutGrid`)}
      ${Zh(`command:debug-overlay`,j(`debug.overlay.title`),`activity`,{details:mr(Nt.debugOverlay,{slot:`details`,className:`session-menu__shortcut`,ariaHidden:!0})})}

      <div class="sidebar-customize-menu__separator" role="separator"></div>
      ${ON()}
      ${e.canRetryConnection?R`<div class="sidebar-customize-menu__separator" role="separator"></div>
              <wa-dropdown-item
                class="sidebar-customize-menu__item sidebar-identity-menu__retry"
                value="command:retry-connect"
              >
                <span class="sidebar-customize-menu__text">${j(`connection.retryNow`)}</span>
              </wa-dropdown-item>`:z}
      <div class="sidebar-customize-menu__separator" role="separator"></div>
      <div class="sidebar-identity-menu__footer">
        <openclaw-sidebar-build-chip
          .variant=${`identity`}
          .basePath=${e.basePath}
          .gatewayVersion=${e.gatewayVersion}
          .updateAttentionDismissed=${e.updateAttentionDismissed}
          .onNavigate=${t=>{e.onClose(),e.onNavigate(t)}}
        ></openclaw-sidebar-build-chip>
        <span class="sidebar-mode-switch">
          <openclaw-theme-mode-toggle
            .mode=${e.themeMode}
            .menuItem=${!0}
          ></openclaw-theme-mode-toggle>
        </span>
      </div>
    </wa-dropdown>
  `}function RN(){return(RN=e((()=>{B(),da(),Xi(),gd(),F(),qt(),Rt(),ql(),FN(),og(),L(),Ur(),UM(),lh(),rp()})))()}function zN(e,t){let n=[...e.querySelectorAll(BN)].filter(e=>e.tabIndex>=0&&e.checkVisibility()),r=t.shiftKey?n[0]:n.at(-1),i=t.shiftKey?n.at(-1):n[0],a=e.ownerDocument.activeElement;(!i||a===e||a===r)&&(t.preventDefault(),i?.focus({preventScroll:!0}))}var BN,VN;function HN(){return(HN=e((()=>{jc(),B(),H(),nr(),F(),Ze(),M(),iS(),jm(),BN=`a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]`,VN=class extends Sn{constructor(...e){super(...e),this.anchor=null,this.label=``,this.content=z,this.onClose=()=>{},this.focused=!1,this.handleOutsidePointer=e=>{let t=e.composedPath();!t.includes(this)&&(!this.anchor||!t.includes(this.anchor))&&this.onClose(!1)},this.handleKeydown=e=>{e.key===`Escape`&&!e.defaultPrevented?(e.preventDefault(),e.stopPropagation(),this.onClose(!0)):e.key===`Tab`&&!e.defaultPrevented&&$i()&&e.currentTarget instanceof HTMLElement&&zN(e.currentTarget,e)},this.handleFocusOut=e=>{e.relatedTarget instanceof Node&&!this.contains(e.relatedTarget)&&e.relatedTarget!==this.anchor&&this.onClose(!1)},this.focusInitialControl=()=>{this.focused||(this.focused=!0,this.querySelector(`#sidebar-sessions-owner, #sidebar-sessions-status .settings-segmented__btn--active`)?.focus({preventScroll:!0}))}}connectedCallback(){super.connectedCallback(),Tt(this),this.ownerDocument.addEventListener(`pointerdown`,this.handleOutsidePointer,!0)}disconnectedCallback(){this.ownerDocument.removeEventListener(`pointerdown`,this.handleOutsidePointer,!0),super.disconnectedCallback()}updated(){let e=this.querySelector(`wa-popup`);e&&this.anchor?tS(e,this.anchor,`bottom`):requestAnimationFrame(this.focusInitialControl)}render(){let e=$i(),t=R`<div
      class="sidebar-session-filter-panel"
      tabindex="-1"
      role="dialog"
      aria-label=${this.label}
      aria-modal=${e?`true`:z}
      @keydown=${this.handleKeydown}
      @focusout=${this.handleFocusOut}
    >
      <div class="sidebar-session-filter-panel__grabber" aria-hidden="true"></div>
      ${this.content}
    </div>`;return e?R`<button
            type="button"
            class="sidebar-session-filter-panel__backdrop"
            tabindex="-1"
            aria-label=${j(`common.close`)}
            @click=${()=>this.onClose(!0)}
          ></button>
          <openclaw-menu-surface>${t}</openclaw-menu-surface>`:R`<wa-popup active @wa-reposition=${this.focusInitialControl}>${t}</wa-popup>`}},w([W({attribute:!1})],VN.prototype,`anchor`,void 0),w([W({attribute:!1})],VN.prototype,`label`,void 0),w([W({attribute:!1})],VN.prototype,`content`,void 0),w([W({attribute:!1})],VN.prototype,`onClose`,void 0),customElements.define(`openclaw-sidebar-session-filter-popover`,VN)})))()}function UN(e){return R`
    <wa-dropdown-item
      slot=${e.submenu?`submenu`:z}
      class="sidebar-session-sort-menu__item"
      value=${e.value}
      role="menuitemradio"
      aria-label=${e.label}
      aria-checked=${String(e.checked)}
      ${la(t=>qf(t,e.checked))}
    >
      <span slot="details" class="session-menu__check" aria-hidden="true"
        >${e.checked?I.check:z}</span
      >
      <span class="row session-menu__label">
        ${e.owner?dh(e.owner,`row`,`owned`):z}
        <span class="session-menu__text">${e.label}</span>
      </span>
    </wa-dropdown-item>
  `}function WN(e){return e.owners.map(t=>UN({value:`owner:${t.id}`,checked:e.ownerFilterId===t.id,label:t.id===e.selfOwnerId?j(`sessionsView.ownerYou`,{name:t.label??t.id}):t.label??t.id,owner:t,submenu:e.submenu}))}function GN(e){let{owners:t,ownerFilterId:n,involvingMe:r}=e;if(t.length===0&&n===null&&!r)return z;let i=t.find(e=>e.id===n),a=i?.label??i?.id,o=a?j(`sessionsView.specificOwnerSelected`,{name:a}):j(`sessionsView.specificOwnerAvailable`,{count:String(t.length)}),s=i?R`${mh(i)}
        <span class="sidebar-session-owner-selection__name">${a}</span>`:R`<span class="sidebar-session-owner-count">${t.length}</span>`;return R`
    <div class="session-menu__separator" role="separator"></div>
    <div class="sidebar-session-sort-menu__title">${j(`sessionsView.owners`)}</div>
    ${UN({value:`owner:`,checked:n===null&&!r,label:j(`sessionsView.allOwners`)})}
    ${UN({value:`involving-me`,checked:r,label:j(`sessionsView.involvingMe`)})}
    ${t.length>0?e.compact?Ym({value:`compact:open-specific-owner`,label:j(`sessionsView.specificOwner`),icon:I.users,details:R`<span class="session-menu__shortcut sidebar-session-owner-selection"
                >${s}</span
              >`,accessibleLabel:o}):R`<wa-dropdown-item
              class="sidebar-session-sort-menu__item sidebar-session-owner-submenu sidebar-session-choice-submenu"
              aria-label=${o}
            >
              <span class="session-menu__text">${j(`sessionsView.specificOwner`)}</span>
              <span
                slot="details"
                class="session-menu__shortcut sidebar-session-owner-selection"
                aria-hidden="true"
                >${s}</span
              >
              ${WN({...e,submenu:!0})}
            </wa-dropdown-item>`:z}
  `}function KN(e){return Xm(R`${WN({...e,submenu:!1})}`)}function qN(e){return e===`compact:open-specific-owner`?`specific-owner`:e===`compact:back`?`root`:null}function JN(e){let t=e.menu,n=(t,n,r)=>R`<wa-dropdown-item
    class=${`session-menu__item${t===`delete-group`?` session-menu__item--destructive`:``}`}
    value=${t}
    variant=${t===`delete-group`?`danger`:z}
    ?disabled=${!e.connected||!!e.actionDisabledReasons?.[t]}
    title=${e.actionDisabledReasons?.[t]??z}
  >
    <span slot="icon" class="session-menu__icon" aria-hidden="true">${r}</span>
    <span class="session-menu__text">${n}</span>
  </wa-dropdown-item>`;return Ca(t,R`
      <wa-dropdown
        class="session-menu sidebar-session-group-menu"
        .open=${!0}
        placement="bottom-start"
        .distance=${0}
        aria-label=${j(`sessionsView.groupMenu`,{group:t.group})}
        @wa-select=${n=>{n.preventDefault();let r=n.detail.item.value;(r===`group-defaults`||r===`rename-group`||r===`new-group`||r===`delete-group`)&&!e.actionDisabledReasons?.[r]&&e.onAction(r,t.group)}}
        @keydown=${t=>Gf(t,()=>e.trigger?.focus())}
        @wa-after-hide=${t=>e.onClose(Kf(t))}
      >
        ${Qh(t,j(`sessionsView.groupMenu`,{group:t.group}))}
        ${n(`group-defaults`,e.groupDefaultsUnavailable?`${j(`common.retry`)}: ${j(`sessionsView.groupDefaultsMenu`)}`:j(`sessionsView.groupDefaultsMenu`),I.settings)}
        ${n(`rename-group`,j(`sessionsView.renameGroupMenu`),I.edit)}
        ${n(`new-group`,j(`sessionsView.newGroup`),I.folder)}
        <div class="session-menu__separator" role="separator"></div>
        ${n(`delete-group`,j(`sessionsView.deleteGroupMenu`),I.trash)}
      </wa-dropdown>
    `)}function YN(e){let t=e.position,n=[{grouping:`project`,label:j(`chat.sidebar.catalogGroupByProject`)},{grouping:`person`,label:j(`chat.sidebar.catalogGroupByPerson`)},{grouping:`none`,label:j(`sessionsView.groupByNone`)}];return Ca(`${t.catalogId}:${t.x}:${t.y}`,R`
      <wa-dropdown
        class=${`sidebar-session-sort-menu sidebar-catalog-view-menu${e.compact?` session-menu--compact`:``}`}
        .open=${!0}
        placement="bottom-start"
        .distance=${0}
        aria-label=${j(`chat.sidebar.catalogViewOptions`)}
        @wa-select=${t=>{t.preventDefault();let n=t.detail.item.value,r=qN(n);r?e.onViewChange(r):n?.startsWith(`grouping:`)?e.onGroupingChange(n.slice(9)):n?.startsWith(`owner:`)?e.onOwnerFilterChange(n.slice(6)||null):n===`involving-me`?e.onOwnerFilterChange(null,!0):n===`hide-catalog`&&e.onHide()}}
        @keydown=${t=>Gf(t,()=>e.trigger?.focus())}
        @wa-after-hide=${t=>e.onClose(Kf(t))}
      >
        ${Qh(t,j(`chat.sidebar.catalogViewOptions`))}
        ${e.compact&&e.view===`specific-owner`?KN(e):R`<div class="sidebar-session-sort-menu__title">${j(`sessionsView.groupBy`)}</div>
                ${n.map(t=>UN({value:`grouping:${t.grouping}`,checked:e.grouping===t.grouping,label:t.label}))}
                ${GN(e)}
                <div class="session-menu__separator" role="separator"></div>
                <wa-dropdown-item class="sidebar-session-sort-menu__item" value="hide-catalog">
                  <span class="session-menu__text">${j(`chat.sidebar.hideFromSidebar`)}</span>
                </wa-dropdown-item>`}
      </wa-dropdown>
    `)}function XN(e){let t=e.owners.length>0||e.ownerFilterId!==null||e.involvingMe,n=$i(),r=e.involvingMe?`involving-me`:e.ownerFilterId===null?`all`:`owner:${e.ownerFilterId}`,i=(e,t,n,r,i,a=t)=>R`<div id=${e} class="sidebar-session-menu-row">
    <span aria-hidden="true" title=${t}>${a}</span>
    ${xA({value:n,options:r.map(e=>({...e,title:e.label})),ariaLabel:t,className:`sidebar-session-menu-segmented`,onChange:i})}
  </div>`,a=(e,t,n,r)=>R`<button
    type="button"
    role="switch"
    id=${e}
    aria-checked=${String(n)}
    class="sidebar-session-menu-switch"
    @click=${()=>r(!n)}
  >
    <span>${t}</span
    ><span inert aria-hidden="true">
      <wa-switch size="s" .checked=${n} tabindex="-1"></wa-switch>
    </span>
  </button>`;return Ca(e.position,R`<openclaw-sidebar-session-filter-popover
      class="sidebar-session-sort-menu"
      .anchor=${e.trigger}
      .label=${j(`chat.sidebar.sortSessions`)}
      .onClose=${e.onClose}
      .content=${R`
        <section
          class="sidebar-session-menu-section"
          aria-labelledby="sidebar-sessions-filters-label"
        >
          <div class="sidebar-session-menu-heading">
            <h3 id="sidebar-sessions-filters-label">${j(`chat.sidebar.menuFilters`)}</h3>
            ${e.filtersChanged?R`<button
                    type="button"
                    id="sidebar-sessions-reset"
                    class="sidebar-session-menu-reset"
                    @click=${t=>{t.currentTarget.closest(`.sidebar-session-filter-panel`)?.querySelector(`#sidebar-sessions-status wa-radio[value="active"]`)?.focus(),e.onResetFilters()}}
                  >
                    ${j(`common.reset`)}
                  </button>`:z}
          </div>
          ${t?R`<div class="sidebar-session-menu-row">
                  <label for="sidebar-sessions-owner">${j(`sessionsView.owners`)}</label>
                  ${dS({id:`sidebar-sessions-owner`,label:j(`sessionsView.owners`),value:r,searchable:`always`,sheet:n,showOptionTooltips:!1,renderLeading:t=>{let n=e.owners.find(e=>`owner:${e.id}`===t.value);return n?mh(n):z},options:[{value:`all`,label:j(`sessionsView.allOwners`)},{value:`involving-me`,label:j(`sessionsView.involvingMe`)},...e.owners.map(t=>({value:`owner:${t.id}`,label:t.id===e.selfOwnerId?j(`sessionsView.ownerYou`,{name:t.label??t.id}):t.label??t.id})),...e.ownerFilterId!==null&&!e.owners.some(t=>t.id===e.ownerFilterId)?[{value:`owner:${e.ownerFilterId}`,label:e.ownerFilterId}]:[]],onChange:t=>e.onOwnerFilterChange(t.startsWith(`owner:`)?t.slice(6):null,t===`involving-me`)})}
                </div>`:z}
          ${i(`sidebar-sessions-status`,j(`sessionsView.status`),e.statusFilter,o_.map(e=>({value:e,label:j(e===`active`?`common.active`:e===`archived`?`sessionsView.archived`:`sessionsView.all`)})),e.onStatusFilterChange)}
          ${a(`sidebar-sessions-cron`,j(`sessionsView.showCronSessions`),e.showCron,e.onShowCronChange)}
          ${a(`sidebar-sessions-system`,j(`sessionsView.showSystemSessions`),e.showSystem,e.onShowSystemChange)}
        </section>
        <section
          class="sidebar-session-menu-section"
          aria-labelledby="sidebar-sessions-display-label"
        >
          <div class="sidebar-session-menu-heading">
            <h3 id="sidebar-sessions-display-label">${j(`chat.sidebar.menuDisplay`)}</h3>
          </div>
          ${e.rosterMode?z:dS({id:`sidebar-sessions-group`,label:j(`sessionsView.groupBy`),value:e.grouping,variant:`submenu`,sheet:n,showOptionTooltips:!1,options:[{value:`category`,label:j(`sessionsView.groupByCategory`)},{value:`project`,label:j(`chat.sidebar.catalogGroupByProject`)},...e.peopleSortAvailable?[{value:`person`,label:j(`sessionsView.groupByPerson`)}]:[],{value:`none`,label:j(`sessionsView.groupByNone`)}],onChange:t=>e.onGroupingChange(t)})}
          ${dS({id:`sidebar-sessions-sort`,label:j(`chat.sidebar.sortBy`),value:e.sortMode,variant:`submenu`,sheet:n,showOptionTooltips:!1,options:a_.filter(t=>t.mode!==`people`||e.peopleSortAvailable).map(e=>({value:e.mode,label:j(e.labelKey)})),onChange:t=>{let n=a_.find(e=>e.mode===t);n&&e.onSortModeChange(n.mode)}})}
          ${e.rosterMode?z:dS({id:`sidebar-sessions-empty`,label:j(`sessionsView.hideEmptyGroups`),value:e.emptyGroupsMode,variant:`submenu`,sheet:n,showOptionTooltips:!1,options:ZN.map(e=>({value:e.mode,label:j(e.labelKey)})),onChange:t=>{let n=ZN.find(e=>e.mode===t);n&&e.onEmptyGroupsModeChange(n.mode)}})}
          ${a(`sidebar-sessions-preview`,j(`sessionsView.showSessionPreview`),e.showPreview,e.onShowPreviewChange)}
        </section>
        <footer class="sidebar-session-menu-footer">
          <a
            id="sidebar-sessions-sources"
            class="sidebar-session-filter-footer"
            href=${e.sessionSourcesHref}
            @click=${t=>{k(t)&&(t.preventDefault(),e.onOpenSessionSources())}}
          >
            <span aria-hidden="true">${I.settings}</span>${j(`chat.sidebar.sessionSources`)}
          </a>
        </footer>
      `}
    ></openclaw-sidebar-session-filter-popover>`)}var ZN;function QN(){return(QN=e((()=>{B(),Ea(),da(),nr(),F(),og(),K(),Kc(),L(),mS(),Qm(),HN(),gh(),OA(),rp(),ZN=[{mode:`filtering`,labelKey:`sessionsView.emptyGroupsWhenFiltering`},{mode:`always`,labelKey:`sessionsView.emptyGroupsAlways`},{mode:`never`,labelKey:`sessionsView.emptyGroupsNever`}]})))()}function $N(e){let{host:t}=e,n=e.customizeMenuPosition;if(!n)return z;let r=e.customizeMenuTrigger,i=e=>{let n=t.reconciledSidebarZone().sidebarEntries;t.onUpdateSidebarEntries?.(n.includes(e)?n.filter(t=>t!==e):[...n,e])};return ag({position:n,sidebarEntries:t.sidebarEntries,preferencesBrowserOnly:t.preferencesBrowserOnly,isRouteEnabled:t=>e.isRouteEnabled(t),pluginNavigation:t.pluginNavigation(),onTabAway:()=>r?.focus(),onClose:t=>{e.customizeMenuPosition===n&&e.closeCustomizeMenu({restoreFocus:t})},onToggleRoute:e=>i(ir({type:`route`,route:e})),onTogglePlugin:e=>i(ir({type:`plugin`,key:e})),onReset:()=>{let n=t.reconciledSidebarZone().sidebarEntries.filter(e=>e.startsWith(`session:`));t.onUpdateSidebarEntries?.([...Pi,...n]),e.closeCustomizeMenu({restoreFocus:!0})}})}function eP(e){let{host:t}=e,n=e.agentMenuPosition;if(!n)return z;let r=e.agentMenuTrigger,{activeId:i,agent:a,agents:o,identity:s,identities:c}=t.activeChipAgent();return kN({position:n,basePath:t.basePath,activeId:i,activeName:Qe(a??{id:i},s),agents:o,identities:c,pinnedAgentIds:t.pinnedAgentIds,rosterMode:t.sidebarAgentsMode===`roster`,onToggleRoster:()=>{t.sidebarAgentsMode=t.sidebarAgentsMode===`roster`?`chip`:`roster`,Pr({sidebarAgentsMode:t.sidebarAgentsMode}),t.updateComplete.then(()=>{t.querySelector(`.sidebar-workspace-header__main, .sidebar-agent-card__main`)?.focus()})},connected:t.connected,resolveAvatarUrl:t=>e.agentMenuAvatars.resolve(t),avatarErrorHandler:t=>e.agentMenuAvatars.imageErrorHandler(t),openMode:e.agentMenuInteractionState===`open-hover`?`hover`:`click`,agentUnreadCount:e=>t.agentUnreadCount(e),onPointerEnter:()=>e.handleAgentMenuPointerEnter(),onPointerLeave:()=>e.handleAgentMenuPointerLeave(),onAfterShow:()=>e.restoreFocusAfterAgentMenuHoverOpen(),onSwitchAgent:e=>t.switchChipAgent(e),onAskCapabilities:e=>t.askAgentCapabilities(e),onTabAway:()=>r?.focus(),onClose:t=>{e.agentMenuPosition===n&&e.closeAgentMenu({restoreFocus:t})},onNavigate:(e,n)=>t.onNavigate?.(e,n)})}function tP(e){let{host:t}=e,n=e.identityMenuPosition;if(!n)return z;let r=e.identityMenuTrigger,i=t.sessionDataContext?Yi(t.sessionDataContext.gateway).displayUser:null,a=t.sessionDataContext,o=a?.overlays.snapshot,s=Ai({gatewayBootId:a?.gateway.snapshot.hello?.server?.bootId,updateAvailable:o?.updateAvailable,updateSchedule:o?.updateSchedule}),c=!!(a&&s&&Ei(o?.updateAvailable,o?.updateSchedule,!!(o?.updateRunning||o?.updateReconciliationPending))&&!o?.updateRunning&&!o?.updateReconciliationPending&&o?.updateSchedule?.campaign?.state!==`applying`&&!Yr(o?.updateStatusBanner?.tone)&&Kr(Or(Ki(a.gateway)),s));return LN({position:n,canPairDevice:t.canPairDevice,basePath:t.basePath,gatewayVersion:t.gatewayVersion,updateAttentionDismissed:c,profileViewer:i?{...i,watchedSessions:[]}:void 0,canRetryConnection:ji(t.connectionStatus),themeMode:t.themeMode,triggerWidth:n.width,onTabAway:()=>r?.focus(),onClose:t=>{e.identityMenuPosition===n&&e.closeIdentityMenu({restoreFocus:t})},onNavigate:(e,n)=>t.onNavigate?.(e,n),onPairMobile:()=>t.onPairMobile?.(),onRetryConnect:t.onRetryConnect})}function nP(e){let{host:t}=e,n=e.sessionMenu;if(!n)return z;let r=t.sessionDataContext,i=e.pluginActionLifetime.signal,a=t.findSidebarSessionByKey(n.session.key),o=()=>t.sessionData.sessionsResult?.sessions.find(e=>e.key===n.session.key&&e.sessionId===n.session.sessionId),s=o(),c=a&&a.sessionId===n.session.sessionId?a:n.session,l=$t({agentsList:t.sessionDataContext?.agents.state.agentsList,hello:t.sessionDataContext?.gateway.snapshot.hello}),u=t.selectedVisibleSessions(),d=u.length>1&&u.some(e=>e.key===c.key)?u:null,f=d??[c],p=f.every(e=>ht(e,l)),m=Ie(f,l),h=f.every(e=>e.unread),g=f.every(e=>e.archived===!0),_=f.every(e=>(e.category??null)===(f[0]?.category??null))?f[0]?.category??null:null,v=c.cloudWorkerStopAction,y=!(d||!v||v.blocksActiveRun&&c.hasActiveRun||!r||oo(r.gateway.snapshot,v.method)!==!0),b=r?.gateway.snapshot.selfUser??null,x=t.readSessionMutationAccess({method:`sessions.assignOwner`,params:{key:c.key,owner:{type:`human`,id:b?.id??`profile`}},requiredScope:`operator.write`}),S={...jk({snapshot:r?.gateway.snapshot,session:c,batchRows:d,cloudWorkerStopAction:c.cloudWorkerStopAction}),...x.allowed?{}:{"assign-owner":x.reason}};return Ca(n,R`
      <openclaw-session-menu
        .session=${{label:c.label,sessionId:c.sessionId??null,isChild:c.isChild,pinned:c.pinned,pinnable:c.pinnable,unread:d?h:c.unread,hiddenFromInvolvingMe:c.hiddenFromInvolvingMe,archived:g,archiving:f.some(e=>r?.sessions.archiveVisibility(e.key)===`pending`),category:d?_:c.category??null,icon:d?null:c.icon??null,color:d?null:c.color??null,categoryClearReturnsToGroups:_!==null&&f.every(e=>lc(e,t.sessionsGrouping))}}
        .selectionCount=${f.length}
        .compact=${$i()}
        .lastActive=${d?``:cp(c.updatedAt)}
        .anchor=${n}
        .trigger=${e.sessionMenuTrigger}
        .disabled=${!t.connected}
        .actionDisabledReasons=${S}
        .navigationAllowed=${!!r}
        .copyMarkdownAllowed=${Xs(r?.gateway.snapshot)}
        .splitAllowed=${ac()}
        .forkDisabled=${t.sessionData.sessionsLoading||c.modelSelectionLocked}
        .forkFromLastCompleted=${c.gatewayHasActiveRun??c.hasActiveRun}
        .archiveAllowed=${p}
        .deleteAllowed=${m}
        .cloudWorkerStopAllowed=${y}
        .groups=${t.knownSessionGroups()}
        .currentOwner=${c.owner?.actor??null}
        .work=${d?null:e.sessionMenuWork}
        .pluginActions=${!d&&r?.plugins&&s?Hl(r.plugins,s):[]}
        .onClose=${()=>{e.sessionMenu===n&&e.closeSessionMenu()}}
        .onAction=${e=>{if(d){t.sessionOrganizer.runBatchSessionAction(e,d,h);return}switch(e.kind){case`open-pr`:xn(e.url);break;case`open-in`:cc(e.editor,e.path);break;case`copy-session-id`:case`copy-session-link`:case`copy-session-preview-link`:case`copy-markdown`:case`open-new-tab`:case`open-new-window`:case`split-right`:case`split-below`:if(r){let n=t.getSessionNavigationState().selectedAgentId;Cs(e.kind,{context:r,session:c,agentId:n,isCurrent:()=>t.sessionDataContext===r&&t.getSessionNavigationState().selectedAgentId===n})}break;case`toggle-pin`:t.sessionOrganizer.patchSession(c,{pinned:!c.pinned},{sessionScope:!0});break;case`toggle-involving-me`:t.sessionOrganizer.setSessionInvolvement(c,!c.hiddenFromInvolvingMe);break;case`toggle-unread`:t.sessionOrganizer.patchSession(c,{unread:!c.unread});break;case`rename`:t.sessionOrganizer.renameSession(c);break;case`set-color`:t.sessionOrganizer.patchSession(c,{color:e.color});break;case`set-icon`:t.sessionOrganizer.patchSession(c,{icon:e.icon});break;case`reset-appearance`:t.sessionOrganizer.patchSession(c,{icon:null,color:null});break;case`assign-owner`:t.sessionOrganizer.assignSessionOwner(c,e.owner);break;case`fork`:t.sessionOrganizer.forkSession(c);break;case`plugin`:r?.plugins&&Vl({runtime:r.plugins,id:e.id,placement:`session`,sessionKey:n.session.key,session:o(),signal:i}).catch(e=>{i.aborted||kt({message:e instanceof Error?e.message:String(e)})});break;case`move-to-group`:(e.category===null||c.category!==e.category)&&t.sessionOrganizer.assignSessionCategory(c,e.category);break;case`new-group`:t.sessionOrganizer.createSessionGroup([c]);break;case`toggle-archived`:c.archived?t.sessionOrganizer.patchSession(c,{archived:!1},{sessionScope:!0}):t.sessionOrganizer.archiveSessionWithUndo(c);break;case`stop-cloud-worker`:t.sessionOrganizer.stopCloudWorker(c);break;case`delete`:t.sessionOrganizer.deleteSession(c)}}}
      ></openclaw-session-menu>
    `)}function rP(e){let{host:t}=e,n=e.sessionGroupMenu;if(!n)return z;let r=t.sessionDataContext?.sessions.groupsStatus()??`idle`,i={"group-defaults":on(t.sessionDataContext?.gateway.snapshot,{method:`sessions.groups.update`,requiredScope:`operator.write`}),"rename-group":on(t.sessionDataContext?.gateway.snapshot,{method:`sessions.groups.rename`,requiredScope:`operator.write`}),"new-group":on(t.sessionDataContext?.gateway.snapshot,{method:`sessions.groups.put`,requiredScope:`operator.write`}),"delete-group":on(t.sessionDataContext?.gateway.snapshot,{method:`sessions.groups.delete`,requiredScope:`operator.write`})};return JN({menu:n,trigger:e.sessionGroupMenuTrigger,connected:t.connected,groupDefaultsUnavailable:r===`unavailable`,actionDisabledReasons:Object.fromEntries(Object.entries(i).flatMap(([e,t])=>t.allowed?e===`group-defaults`&&r!==`ready`&&r!==`unavailable`?[[e,j(`common.loading`)]]:[]:[[e,t.reason]])),onAction:(n,i)=>{switch(e.closeSessionGroupMenu({restoreFocus:!0}),n){case`group-defaults`:if(r===`unavailable`){t.sessionDataContext?.sessions.groupsInvalidate(),t.sessionDataContext?.sessions.groupsLoad();break}t.sessionOrganizer.editSessionGroupDefaults(i);break;case`rename-group`:t.sessionOrganizer.renameSessionGroupFromMenu(i);break;case`new-group`:t.sessionOrganizer.createSessionGroup();break;case`delete-group`:t.sessionOrganizer.deleteSessionGroupFromMenu(i)}},onClose:t=>{e.sessionGroupMenu===n&&e.closeSessionGroupMenu({restoreFocus:t})}})}function iP(e){let{host:t}=e,n=e.sessionSortMenuPosition;if(!n)return z;let r=On.sessionSources;return XN({position:n,trigger:e.sessionSortMenuTrigger,sessionSourcesHref:gi(r.routeId,t.basePath)+r.search+r.hash,grouping:t.effectiveSessionsGrouping(),rosterMode:t.sidebarAgentsMode===`roster`,sortMode:t.effectiveSessionSortMode(),peopleSortAvailable:t.sessionPeopleSortAvailable(),statusFilter:t.sessionsStatusFilter,showCron:t.sessionsShowCron,showPreview:t.sessionsShowPreview,showSystem:t.sessionsShowSystem,emptyGroupsMode:t.sessionsEmptyGroupsMode,owners:t.sessionOwnershipVisibility.filters?t.sessionOwnerOptions:[],ownerFilterId:t.sessionOwnerFilterActive?t.sessionOwnerFilterId:null,involvingMe:t.sessionInvolvingMeFilterActive,selfOwnerId:t.sessionDataContext?.gateway.snapshot.selfUser?.id??null,filtersChanged:cg(t)>0||t.sessionsShowCron||t.sessionsShowSystem,onResetFilters:()=>{t.setSessionOwnerFilter(null),t.sessionOrganizer.setSessionsStatusFilter(`active`),t.sessionOrganizer.setSessionsShowCron(!1),t.sessionOrganizer.setSessionsShowSystem(!1)},onGroupingChange:e=>{t.sessionOrganizer.setSessionsGrouping(e)},onSortModeChange:e=>{t.setSessionSortMode(e)},onStatusFilterChange:e=>{t.sessionOrganizer.setSessionsStatusFilter(e)},onOwnerFilterChange:(e,n=!1)=>{t.setSessionOwnerFilter(e,n)},onShowCronChange:e=>{t.sessionOrganizer.setSessionsShowCron(e)},onShowPreviewChange:e=>{t.sessionOrganizer.setSessionsShowPreview(e)},onShowSystemChange:e=>{t.sessionOrganizer.setSessionsShowSystem(e)},onEmptyGroupsModeChange:r=>{e.sessionSortMenuPosition===n&&t.setSessionsEmptyGroupsMode(r)},onOpenSessionSources:()=>{e.closeSessionSortMenu(),t.onNavigate?.(r.routeId,{search:r.search,hash:r.hash})},onClose:t=>{e.sessionSortMenuPosition===n&&e.closeSessionSortMenu({restoreFocus:t})}})}function aP(e){let{host:t}=e,n=e.catalogViewMenuPosition;return n?YN({position:n,trigger:e.catalogViewMenuTrigger,grouping:t.catalogProjectGrouping,owners:t.sessionOwnershipVisibility.filters?t.sessionOwnerOptions:[],ownerFilterId:t.sessionOwnerFilterActive?t.sessionOwnerFilterId:null,involvingMe:t.sessionInvolvingMeFilterActive,selfOwnerId:t.sessionDataContext?.gateway.snapshot.selfUser?.id??null,compact:$i(),view:e.filterMenuView,onViewChange:t=>e.setFilterMenuView(t),onGroupingChange:n=>{t.setCatalogProjectGrouping(n),e.closeCatalogViewMenu({restoreFocus:!0})},onHide:()=>{e.catalogViewMenuPosition===n&&(t.hideSessionCatalog(n.catalogId),e.closeCatalogViewMenu())},onOwnerFilterChange:(n,r=!1)=>{t.setSessionOwnerFilter(n,r),e.closeCatalogViewMenu({restoreFocus:!0})},onClose:t=>{e.catalogViewMenuPosition===n&&e.closeCatalogViewMenu({restoreFocus:t})}}):z}function oP(e){let{host:t}=e,n=e.moreMenuPosition;if(!n)return z;let r=e.moreMenuTrigger;return ig({position:n,basePath:t.basePath,activeRouteId:t.activeRouteId,sidebarEntries:t.sidebarEntries,isRouteEnabled:t=>e.isRouteEnabled(t),onTabAway:()=>r?.focus(),onClose:t=>{e.moreMenuPosition===n&&e.closeMoreMenu({restoreFocus:t})},onNavigateRoute:n=>{e.closeMoreMenu({restoreFocus:!0}),t.onNavigate?.(n)},onPreloadRoute:(t,n)=>e.preloadRoute(t,n),onCancelPreload:t=>e.cancelPreload(t),onEditPinnedItems:()=>{let t=e.moreMenuPosition,n=e.moreMenuTrigger;t&&e.openCustomizeMenu(t.x,t.y,n)}})}function sP(){return(sP=e((()=>{B(),Ea(),Xi(),ii(),oi(),nr(),fi(),Fi(),F(),pt(),ec(),so(),Rt(),Re(),xs(),N(),Ls(),wt(),Mt(),Kl(),FN(),RN(),og(),_p(),pg(),QN(),Hi(),Mk(),qr()})))()}export{aj as $,zf as $a,xh as $i,NE as $n,id as $o,iS as $r,ok as $t,iM as A,_m as Aa,cv as Ai,gD as An,Id as Ao,dC as Ar,fA as At,qj as B,Rp as Ba,K as Bi,CD as Bn,vd as Bo,hS as Br,iA as Bt,MM as C,Om as Ca,Zv as Ci,mD as Cn,of as Co,MC as Cr,lA as Ct,bM as D,wm as Da,kv as Di,sD as Dn,zd as Do,YS as Dr,dA as Dt,CM as E,Tm as Ea,Ev as Ei,ED as En,Bd as Eo,mC as Er,sA as Et,eM as F,Gp as Fa,S_ as Fi,iD as Fn,Ed as Fo,LS as Fr,yA as Ft,Nj as G,kp as Ga,Jh as Gi,aD as Gn,ad as Go,pS as Gr,Hk as Gt,Gj as H,wp as Ha,Wg as Hi,dD as Hn,pd as Ho,CS as Hr,nA as Ht,$j as I,Wp as Ia,__ as Ii,uD as In,Td as Io,J as Ir,CA as It,mj as J,ip as Ja,Bh as Ji,KE as Jn,Yu as Jo,lS as Jr,Qk as Jt,Fj as K,op as Ka,Kh as Ki,qE as Kn,Wu as Ko,mS as Kr,Gk as Kt,Yj as L,Op as La,s_ as Li,oD as Ln,yd as Lo,OS as Lr,oA as Lt,Jj as M,rm as Ma,ov as Mi,bD as Mn,Pd as Mo,GS as Mr,SA as Mt,nM as N,Qp as Na,tv as Ni,yD as Nn,Od as No,zS as Nr,pA as Nt,_M as O,ym as Oa,jv as Oi,SD as On,Rd as Oo,QS as Or,gA as Ot,Qj as P,Yp as Pa,C_ as Pi,fD as Pn,Ad as Po,RS as Pr,vA as Pt,ij as Q,Wf as Qa,bh as Qi,PE as Qn,td as Qo,tS as Qr,Ak as Qt,Xj as R,Sp as Ra,u_ as Ri,hD as Rn,bd as Ro,TS as Rr,aA as Rt,NM as S,Dm as Sa,ry as Si,pD as Sn,af as So,NC as Sr,mA as St,vM as T,xm as Ta,Ov as Ti,lD as Tn,Hd as To,pC as Tr,_A as Tt,Wj as U,Mp as Ua,pg as Ui,_D as Un,ld as Uo,bS as Ur,eA as Ut,Kj as V,Cp as Va,jg as Vi,ZE as Vn,gd as Vo,vS as Vr,tA as Vt,kj as W,jp as Wa,fg as Wi,xD as Wn,ud as Wo,yS as Wr,Kk as Wt,dj as X,qf as Xa,Sh as Xi,LE as Xn,od as Xo,cS as Xr,Mk as Xt,pj as Y,rp as Ya,wh as Yi,HE as Yn,cd as Yo,aS as Yr,Wk as Yt,uj as Z,Vf as Za,yh as Zi,UE as Zn,ed as Zo,oS as Zr,jk as Zt,GM as _,Wm as _a,Ay as _i,ND as _n,hf as _o,Aw as _r,OA as _t,tP as a,ih as aa,Px as ai,oO as an,Af as ao,$T as ar,ou as as,GA as at,FM as b,jm as ba,sy as bi,eD as bn,uf as bo,GC as br,bA as bt,nP as c,nh as ca,Ex as ci,HD as cn,wf as co,sT as cr,iu as cs,UA as ct,vN as d,Jm as da,vx as di,zD as dn,Sf as do,Fw as dr,PA as dt,gh as ea,eS as ei,sk as en,Rf as eo,SE as er,Eu as es,$A as et,gN as f,Qm as fa,Sx as fi,RD as fn,vf as fo,zw as fr,jA as ft,YM as g,qm as ga,xb as gi,MD as gn,lf as go,Dw as gr,AA as gt,$M as h,Gm as ha,bb as hi,PD as hn,Yd as ho,kw as hr,kA as ht,$N as i,lh as ia,Mx as ii,tk as in,kf as io,QT as ir,vu as is,qA as it,tM as j,vm as ja,av as ji,wD as jn,Fd as jo,JS as jr,xA as jt,aM as k,bm as ka,Av as ki,kD as kn,Ld as ko,$S as kr,EA as kt,iP as l,th as la,Dx as li,VD as ln,Tf as lo,Vw as lr,RA as lt,eN as m,Ym as ma,gx as mi,BD as mn,rf as mo,Ow as mr,MA as mt,eP as n,dh as na,$x as ni,ik as nn,Pf as no,xE as nr,su as ns,XA as nt,oP as o,eh as oa,Ox as oi,aO as on,Nf as oo,nE as or,uu as os,KA as ot,_N as p,Xm as pa,_x as pi,JD as pn,gf as po,Mw as pr,IA as pt,fj as q,sp as qa,Hh as qi,JE as qn,nd as qo,dS as qr,Nk as qt,aP as r,fh as ra,Xx as ri,nk as rn,jf as ro,vE as rr,au as rs,YA as rt,rP as s,$m as sa,Tx as si,tO as sn,Ef as so,$w as sr,Zl as ss,LA as st,sP as t,mh as ta,Qx as ti,ak as tn,Lf as to,wE as tr,Cu as ts,ZA as tt,yN as u,rh as ua,bx as ui,ID as un,Cf as uo,Jw as ur,zA as ut,UM as v,Fm as va,Dy as vi,jD as vn,df as vo,Tw as vr,cA as vt,oM as w,Em as wa,Dv as wi,cD as wn,Wd as wo,AC as wr,TA as wt,PM as x,km as xa,iy as xi,$E as xn,nf as xo,VC as xr,wA as xt,VM as y,Nm as ya,cy as yi,AD as yn,sf as yo,RC as yr,uA as yt,Zj as z,Ep as za,i_ as zi,TD as zn,xd as zo,wS as zr,rA as zt};