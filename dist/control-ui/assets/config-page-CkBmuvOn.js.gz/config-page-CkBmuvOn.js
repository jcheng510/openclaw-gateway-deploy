import{n as e}from"./rolldown-runtime-8BhlS34s.js";import{An as t,Ba as n,Bn as r,Br as i,D as a,E as o,Fn as s,Gi as c,Hn as l,Ii as u,In as d,Ji as ee,Jn as f,Kn as p,Ln as m,Mn as h,Nn as g,Pa as te,Pn as ne,Qn as _,Rn as re,Ti as ie,Ui as v,Un as ae,Vn as oe,Xa as se,Xn as ce,Yn as le,Zn as y,_r as ue,ar as de,cr as fe,d as pe,dr as me,er as he,f as ge,fr as _e,gi as ve,gr as ye,hi as be,hr as xe,ir as Se,j as Ce,jn as we,lr as Te,m as Ee,mr as De,or as Oe,p as ke,pr as Ae,qn as je,qr as b,ro as Me,rr as Ne,sr as Pe,to as Fe,tr as Ie,u as Le,ur as Re,vr as ze,zn as Be,zr as Ve}from"./control-ui-foundation-C3MHh_P-.js";import{A as He,Gl as x,Go as Ue,Jc as We,Jo as Ge,Kl as Ke,N as qe,P as Je,Qa as Ye,Qi as Xe,R as Ze,Si as Qe,Ti as $e,Xi as et,Ya as tt,Yc as nt,Yo as rt,Za as it,_i as at,_u as ot,bs as st,cc as ct,di as lt,fi as ut,hu as S,lu as dt,mi as ft,nl as pt,pi as mt,pu as ht,qc as gt,ql as _t,sc as vt,su as yt,uu as C,vi as bt,xi as xt,yu as St}from"./control-ui-core-pYNj5S1a.js";import{An as Ct,Fn as wt,In as Tt,Ln as Et,Ma as Dt,Mn as Ot,Nn as kt,On as At,Pn as jt,Sn as Mt,Ui as Nt,Vi as Pt,Vn as Ft,Vr as It,Xi as w,Zi as Lt,_ as Rt,_a as zt,_r as Bt,an as Vt,at as Ht,b as Ut,cn as Wt,co as Gt,d as Kt,dn as T,dt as qt,fn as Jt,fr as Yt,g as Xt,gn as Zt,go as Qt,gr as $t,gt as en,h as tn,hn as nn,hr as rn,ht as an,in as on,ja as sn,jn as cn,kn as ln,l as un,lt as dn,m as fn,mn as pn,mt as mn,or as E,po as hn,pt as gn,rt as _n,sr as D,u as vn,un as yn,ut as bn,v as xn,va as Sn,vi as Cn,vn as wn,vr as Tn,wi as En,xn as Dn,y as On,yi as kn,yn as An}from"./control-ui-core-D6clmJs8.js";import{$ as O,D as jn,E as Mn,X as k,Y as A,at as Nn,c as Pn,ct as j,i as Fn,j as In,k as Ln,m as Rn,mt as zn,nt as M,o as Bn,p as Vn,r as Hn,s as Un,t as Wn,ut as N,vt as Gn}from"./lit-runtime-DZL1fcCI.js";import{c as P,d as Kn,l as qn}from"./gateway-runtime-iOL78mIi.js";import{At as Jn,Dt as Yn,Et as Xn,I as Zn,Ki as Qn,Mt as $n,Nt as er,Ot as tr,Pt as nr,R as rr,Tt as ir,Wn as ar,ct as or,di as sr,fi as cr,jt as lr,kt as ur,no as dr,qi as fr,ro as pr,st as mr}from"./control-ui-boot-shared-3Hl8ksFq.js";import{L as hr,R as gr,St as _r,V as F,g as vr,h as yr,v as br,xt as xr,y as Sr,z as Cr}from"./control-ui-boot-shared-D-LYw3KU.js";import{n as wr,t as Tr}from"./response-body-kWQ8kctw.js";import{Ao as Er,Ar as Dr,At as I,Ba as Or,Bi as kr,Dt as Ar,Et as jr,Ft as L,Ha as Mr,Hi as Nr,It as R,Kr as Pr,Lt as Fr,Mt as z,Ot as B,Rt as Ir,St as Lr,Tt as Rr,Ua as zr,Vi as Br,_ as Vr,_t as V,bt as H,g as Hr,jt as Ur,ko as Wr,kr as Gr,qr as Kr,vt as qr,wt as Jr,xt as U,yt as Yr,zi as Xr}from"./control-ui-boot-shared-DJ4XCcp6.js";import{J as Zr,Y as Qr,at as $r,ct as ei,it as ti,ot as ni,rt as ri}from"./control-ui-boot-shared-DCY2wZcy.js";import{n as ii,t as ai}from"./theme-palette-CdSxAkZT.js";import{t as oi}from"./update-run-view-DoYR45zB.js";import{n as W,t as G}from"./en-settings-DlF4_5vi.js";import{C as si,S as ci,_ as li,b as ui,c as di,d as fi,f as pi,g as mi,h as hi,l as gi,m as _i,p as vi,u as yi,x as bi,y as xi}from"./control-ui-boot-new-CaEHEcx2.js";import{i as Si,o as Ci,t as wi}from"./settings-targets-B7PGvUUs.js";import"./css-config-njfbfHBk.js";import{_ as Ti,a as Ei,c as Di,d as Oi,f as ki,g as Ai,l as ji,m as Mi,n as Ni,o as Pi,p as Fi,r as Ii,s as Li,t as Ri}from"./setup-schema-DZqA992e.js";import{n as zi,t as Bi}from"./settings-workspace-DKW0BVnu.js";import{c as Vi,d as Hi,l as Ui,n as Wi,t as Gi,u as Ki}from"./tool-catalog-DMlGNWJO.js";import{n as qi,t as Ji}from"./model-picker-Cr4HKWDk.js";import{a as Yi,c as Xi,n as Zi,s as Qi,t as $i}from"./config-form-Dai8zEXZ.js";import{G as ea,K as ta,U as na,V as ra,W as ia}from"./config-form.node.shared-nwEUEYxd.js";import{n as aa,r as oa,t as sa}from"./system-info-BXt4emol.js";import{n as ca,r as la,t as ua}from"./system-info-DJYC6ElX.js";import{n as da,t as fa}from"./wizard-login-controller-CVVvSr5l.js";import{n as pa,t as ma}from"./en-transcripts-WNUnclke.js";import{n as ha,t as ga}from"./en-memory-import-D52tmpPI.js";import{n as K,t as _a}from"./settings-select-row-DZ7qblW0.js";import{i as va,r as ya,t as ba}from"./settings-model-CBF6_YZP.js";function xa(e){return L({title:S(`browserLinkPreferences.openInControlUi`),checked:e.enabled,onChange:e.onChange})}function Sa(){return(Sa=e((()=>{V(),C()})))()}var Ca;function wa(){return(wa=e((()=>{Ca=class{constructor(e){this.host=e,this.targetId=null,this.frame=null,e.addController(this)}setTarget(e){this.frame!==null&&(cancelAnimationFrame(this.frame),this.frame=null),this.targetId=e}hostDisconnected(){this.setTarget(null)}hostUpdated(){this.targetId&&this.frame===null&&(this.frame=requestAnimationFrame(()=>{this.frame=null;let e=this.targetId;if(!this.host.isConnected||!e)return;let t=[...this.host.renderRoot.querySelectorAll(`[id]`)].find(t=>t.id===e);t&&(t.scrollIntoView?.({behavior:ar(),block:`start`}),this.targetId=null)}))}}})))()}var Ta,Ea;function Da(){return(Da=e((()=>{_t(),Ta={url:``,busy:!1,message:null,expanded:!1,focusToken:0},Ea=class{constructor(e){this.publish=e,this.requestRevision=0,this.activationIntent={revision:0,theme:null},this.gatewayScope=``,this.serverSelectionRevision=0,this.state=Ta}get snapshot(){return this.state}connect(e,t){this.gatewayScope=e,this.serverSelectionRevision=this.selectionForScope(e,t)?.revision??0}synchronizeScope(e,t){this.gatewayScope&&e!==this.gatewayScope&&this.retireImport(),this.connect(e,t)}adoptSettings(e,t,n){let r=this.selectionForScope(this.gatewayScope,n),i=this.serverSelectionRevision!==(r?.revision??0);return this.serverSelectionRevision=r?.revision??0,t.customTheme?.importedAt===e.customTheme?.importedAt?(i&&this.recordActivation(r?.theme??null),t.theme!==e.theme&&this.recordActivation(t.theme),t):(this.retireImport(),t)}recordActivation(e){this.activationIntent={revision:this.activationIntent.revision+1,theme:e}}open(){this.update({expanded:!0,focusToken:this.state.focusToken+1})}setUrl(e){e!==this.state.url&&this.retireImport(),this.update({url:e,...this.state.message?.kind===`error`?{message:null}:{}})}retireForConfigMutation(e){this.state.busy&&(this.retireImport(),this.update({message:{kind:`error`,text:e}}))}async import(e){let t=this.blockedReason(e.config);if(t){this.update({expanded:!0,message:{kind:`error`,text:e.messages.blocked(t)}});return}let n=this.beginImport(),r=this.state.url;this.update({expanded:!0,busy:!0,message:null});try{let t=await e.load(r);if(!this.ownsImport(n))return;e.apply(t,!e.hasCustomTheme&&this.mayActivate(n)),this.update({url:``,message:{kind:`success`,text:e.messages.imported(t.label)}})}catch(e){if(!this.ownsImport(n))return;this.update({message:{kind:`error`,text:x(e)}})}finally{this.ownsImport(n)&&this.update({busy:!1})}}clear(e){this.retireImport(),e.apply(),this.update({expanded:!0,message:{kind:`success`,text:e.message}})}retireImport(){this.requestRevision+=1,this.state.busy&&this.update({busy:!1})}beginImport(){return this.requestRevision+=1,{requestRevision:this.requestRevision,activationRevision:this.activationIntent.revision}}ownsImport(e){return e.requestRevision===this.requestRevision}mayActivate(e){return e.activationRevision===this.activationIntent.revision||this.activationIntent.theme===`custom`}blockedReason(e){return e.connected&&(e.configLoading||!e.configSnapshot)?`loading`:e.configFormDirty||e.configSaving||e.configApplying||e.configAutoSaveStatus===`saving`?`unsaved`:null}update(e){this.state={...this.state,...e},this.publish(this.state)}selectionForScope(e,t){return t?.scope===e?t:null}}})))()}function Oa(e){let t=e.split(`/`).filter(Boolean),n=t.at(-1);return n&&(t.length===2&&t[0]===`themes`||t.length===3&&t[0]===`r`&&t[1]===`themes`)?(Ft(n),n):null}function ka(e){let t=Me(e);if(!t)throw Error(`Paste a tweakcn theme link to import.`);let n=t.replace(/[.,;:]+$/,``);return wt.test(n)?`https://tweakcn.com/themes/${n}`:n.startsWith(`/themes/`)||n.startsWith(`/r/themes/`)?`https://tweakcn.com${n}`:/^(?:www\.)?tweakcn\.com\//i.test(n)?`https://${n}`:n.match(/https?:\/\/(?:www\.)?tweakcn\.com\/[^\s<>"')]+/i)?.[0]?.replace(/[.,;:]+$/,``)??n}function Aa(e){let t=Oa(e.pathname);if(t)return t;let n=e.searchParams.get(`theme`)??e.searchParams.get(`themeId`)??e.searchParams.get(`id`);if(n)return Ft(n),n;throw Error(`Unsupported tweakcn link. Expected a theme share URL.`)}function ja(e){let t=ka(e),n;try{n=new URL(t)}catch{throw Error(`Paste a full tweakcn URL.`)}if(!Ia.has(n.hostname))throw Error(`Only tweakcn.com theme links are supported.`);let r=Aa(n);return{themeId:r,sourceUrl:`https://tweakcn.com/themes/${r}`,fetchUrl:`https://tweakcn.com/r/themes/${r}`}}function Ma(e,t){let n=v(e),r=v(n?.cssVars),i=v(r?.light),a=v(r?.dark),o=r?.theme===void 0?void 0:v(r.theme);if(!n||!r||!i||!a||o===null)throw Error(`tweakcn returned an invalid theme payload.`);return{sourceUrl:t.sourceUrl,themeId:t.themeId,label:Tt(Me(n.name)),importedAt:new Date().toISOString(),light:ii(`light`,i,o),dark:ii(`dark`,a,o)}}function Na(e){if(!e)return;let t;try{t=new URL(e)}catch{throw Error(`Unexpected tweakcn import response URL.`)}if(t.protocol!==`https:`||!Ia.has(t.hostname))throw Error(`Unexpected redirect during tweakcn import.`)}async function Pa(e){let t=await wr(e,{maxBytes:La,tooLargeMessage:`tweakcn theme payload is too large.`,missingBodyMessage:`tweakcn returned an unreadable theme payload.`});try{return JSON.parse(t)}catch{throw Error(`tweakcn returned invalid JSON.`)}}async function Fa(e,t=fetch){let n=ja(e),r=new AbortController,i=setTimeout(()=>r.abort(),Ra);try{let e=await t(n.fetchUrl,{headers:{accept:`application/json`},redirect:`error`,signal:r.signal});if(Na(e.url),!e.ok)throw Error(`tweakcn import failed (${e.status}).`);return Ma(await Pa(e),n)}catch(e){throw r.signal.aborted?Error(`tweakcn import timed out.`,{cause:e}):e}finally{clearTimeout(i)}}var Ia,La,Ra;function za(){return(za=e((()=>{Et(),ai(),Tr(),Ia=new Set([`tweakcn.com`,`www.tweakcn.com`]),La=2e5,Ra=1e4})))()}function Ba(e,t){return{chatMessageMaxWidth:e.chatMessageMaxWidth,setChatMessageMaxWidth:e=>t({chatMessageMaxWidth:e}),chatShowTaskProgress:e.chatShowTaskProgress??T.chatShowTaskProgress,setChatShowTaskProgress:e=>t({chatShowTaskProgress:e}),openLinksExternally:e.openLinksExternally===!0,setOpenLinksExternally:e=>t({openLinksExternally:e}),chatCollapseTaskProgress:e.chatCollapseTaskProgress===!0,setChatCollapseTaskProgress:e=>t({chatCollapseTaskProgress:e})}}function Va(){return(Va=e((()=>{Jt()})))()}function Ha(e){return/^[A-Za-z0-9._:/-]+$/.test(e)?e:`'${e.replaceAll(`'`,`'\\''`)}'`}function Ua(e){switch(e){case`verify-off`:return S(`mcpPage.tlsVerifyOff`);case`mtls`:return S(`mcpPage.mtls`);default:return null}}var Wa;function Ga(){return(Ga=e((()=>{i(),A(),M(),kn(),Bt(),C(),er(),We(),ur(),_t(),qn(),dt(),ct(),Lt(),Fr(),V(),da(),nr(),Wa=class extends yt{constructor(...e){super(...e),this.pluginsHref=``,this.docsUrl=`https://docs.openclaw.ai/tools/mcp`,this.rows=null,this.busy=!1,this.message=null,this.formOpen=!1,this.feedbackGeneration=0,this.login=new fa(this,{getClient:()=>this.context?.gateway.snapshot.client??null,getAgentId:()=>null,onClose:()=>this.login.reset(),requestFailedMessage:()=>S(`mcpServers.signInFailed`),sessionExpiredMessage:()=>S(`mcpServers.signInExpired`)}),this.subscriptions=new vt(this).effect(()=>this.context?.runtimeConfig,e=>{let t=this.feedbackGeneration;this.syncRows(),e.ensureLoaded().catch(n=>{t===this.feedbackGeneration&&this.isConnected&&e===this.context?.runtimeConfig&&(this.message={kind:`error`,text:x(n)})});let n=e.subscribe(()=>this.syncRows());return()=>{this.feedbackGeneration+=1,this.busy=!1,this.message=null,n()}}).effect(()=>this.context?.gateway,e=>e.subscribe(()=>this.requestUpdate())).effect(()=>this.context?.gateway.snapshot.hello,()=>()=>this.login.reset()).effect(()=>this.context?.agentSelection,e=>e.subscribe(()=>this.login.reset()))}disconnectedCallback(){this.login.reset(),this.subscriptions.clear(),super.disconnectedCallback()}syncRows(){let e=this.context?.runtimeConfig.state.configSnapshot;this.rows=$n(nt(e))}mutationBlockedReason(){let e=this.context?.gateway;return e?.snapshot.phase===`connected`?Yt(e.snapshot.hello?.auth??null)?null:S(`mcpServers.adminRequired`):S(`mcpServers.connectRequired`)}canMutate(){return this.context!==void 0&&this.mutationBlockedReason()===null&&this.login.runner.state.phase===`idle`}signIn(e){!this.busy&&this.canMutate()&&e.enabled&&e.signIn===`operator`&&P(this.context?.gateway.snapshot,`mcp.authLogin`,`operator.admin`)&&(this.message=null,this.login.runner.prepareSignIn(`oauth`,e.name),this.login.runner.startMcpLogin(e.name))}async mutate(e){if(!this.context||!this.canMutate()||this.busy)return!1;let t=this.feedbackGeneration;this.busy=!0,this.message=null;let n=await lr(this.context.runtimeConfig,e);return t===this.feedbackGeneration&&(this.busy=!1,n.ok?(this.syncRows(),this.message={kind:`success`,text:e.successText},!0):(this.message={kind:`error`,text:n.error},!1))}async addServer(e){let t=e.name.trim();if(!ir.test(t)){this.message={kind:`error`,text:S(`mcpServers.nameInvalid`)};return}let n=Jn(e.target,e.transport);if(!n){this.message={kind:`error`,text:S(`mcpServers.targetInvalid`)};return}await this.mutate({buildPatch:e=>Xn(e,t,n),note:`mcp settings: add server ${t}`,successText:S(`mcpServers.addedSuccess`,{name:t})})&&(this.formOpen=!1)}async toggleServer(e,t){await this.mutate({buildPatch:n=>tr(n,e,t),note:`mcp settings: ${t?`enable`:`disable`} server ${e}`,successText:S(t?`mcpServers.enabledSuccess`:`mcpServers.disabledSuccess`,{name:e})})}async removeServer(e){await this.mutate({buildPatch:t=>Yn(t,e),note:`mcp settings: remove server ${e}`,successText:S(`mcpServers.removedSuccess`,{name:e})})}renderRow(e){let t=`openclaw mcp ${e.auth===`oauth`?`login`:`probe`} ${Ha(e.name)}`,n=[e.transport,e.auth,e.toolFilter?S(`mcpPage.toolFilter`):null,e.parallel?S(`mcpPage.parallel`):null,Ua(e.tls)].filter(e=>!!e),r=this.mutationBlockedReason(),i=this.busy||!this.canMutate();return O`
      <div class="settings-row mcp-server-row" data-mcp-name=${e.name}>
        <div class="settings-row__text">
          <span class="settings-row__title">${e.name}</span>
          <span class="settings-row__desc mcp-server-row__launch">
            ${e.target||S(`mcpServers.missingTransport`)}
          </span>
          <span class="settings-row__desc">${n.join(` · `)}</span>
        </div>
        <div class="settings-row__control">
          ${z({kind:e.enabled?`ok`:`muted`,label:e.enabled?S(`common.enabled`):S(`common.disabled`)})}
          ${e.signIn===`profile`?O`<span class="settings-row__desc">${S(`mcpServers.profileSignIn`)}</span>`:e.signIn===`requester`?O`<span class="settings-row__desc">${S(`mcpServers.requesterSignIn`)}</span>`:O`<code>${t}</code>`}
          ${e.enabled&&e.signIn===`operator`&&P(this.context?.gateway.snapshot,`mcp.authLogin`,`operator.admin`)?O`<button
                  type="button"
                  class="btn btn--sm"
                  ?disabled=${i}
                  @click=${()=>this.signIn(e)}
                >
                  ${S(`mcpServers.signIn`)}
                </button>`:k}
          <button
            type="button"
            class="btn btn--sm"
            title=${r??``}
            ?disabled=${i}
            @click=${()=>void this.toggleServer(e.name,!e.enabled)}
          >
            ${this.busy?S(`mcpServers.working`):e.enabled?S(`mcpServers.disable`):S(`mcpServers.enable`)}
          </button>
          <button
            type="button"
            class="btn btn--sm btn--icon mcp-server-remove"
            aria-label=${S(`mcpServers.removeNamed`,{name:e.name})}
            title=${r??S(`mcpServers.removeNamed`,{name:e.name})}
            ?disabled=${i}
            @click=${()=>void this.removeServer(e.name)}
          >
            ${w.trash}
          </button>
        </div>
      </div>
    `}render(){let e=this.mutationBlockedReason(),t=this.rows,n=t?t.length===0?U(O`
            ${S(`mcpPage.noServers`)} ${qr(this.docsUrl,S(`mcpPage.setUpFirstServer`))}
          `):t.map(e=>this.renderRow(e)):Jr({rows:2});return O`
      <div class="mcp-server-list">
        ${I({title:S(`mcpPage.configuredServers`),description:O`
              ${S(`mcpPage.runtimeHint`)} ${Yr(this.pluginsHref)}
            `,actions:O`
              <button
                type="button"
                class="btn btn--sm"
                title=${e??``}
                ?disabled=${this.busy||!this.canMutate()}
                @click=${()=>{this.formOpen=!this.formOpen,this.formOpen&&(this.message=null)}}
              >
                <span aria-hidden="true">${w.plus}</span>
                ${S(`mcpServers.add`)}
              </button>
            `},O`
            ${this.formOpen?Ir({busy:this.busy,disabled:!this.canMutate(),blockedReason:e,onSubmit:e=>void this.addServer(e),onCancel:()=>{this.formOpen=!1}}):k}
            ${this.message?O`<div
                    class="mcp-server-message mcp-server-message--${this.message.kind}"
                    role=${this.message.kind===`error`?`alert`:`status`}
                  >
                    ${this.message.text}
                  </div>`:k}
            ${n}
          `)}
      </div>
      ${this.login.render({doneMessage:S(`mcpServers.authenticationSaved`)})}
    `}},b([Ve({context:Cn,subscribe:!0})],Wa.prototype,`context`,void 0),b([N()],Wa.prototype,`pluginsHref`,void 0),b([N()],Wa.prototype,`docsUrl`,void 0),b([j()],Wa.prototype,`rows`,void 0),b([j()],Wa.prototype,`busy`,void 0),b([j()],Wa.prototype,`message`,void 0),b([j()],Wa.prototype,`formOpen`,void 0),customElements.get(`openclaw-mcp-servers-card`)||customElements.define(`openclaw-mcp-servers-card`,Wa)})))()}function Ka(){return O`${S(`mcpPage.intro`)} ${Yr(Ja)}`}function qa(e){let t=$n(e.configObject)??[];return O`
    <section class="mcp-page">
      <div class="settings-page" ${D({settingsPage:!0})}>
        <section class="settings-section mcp-page__summary">
          <div class="settings-section__header">
            <h2 class="settings-section__heading">${S(`mcpPage.servers`)}</h2>
          </div>
          <div class="settings-group">
            ${[[`mcpPage.servers`,t.length],[`common.enabled`,t.filter(e=>e.enabled).length],[`mcpPage.oauth`,t.filter(e=>e.auth===`oauth`).length],[`mcpPage.filtered`,t.filter(e=>e.toolFilter).length]].map(([e,t])=>B({title:S(e),control:R(t)}))}
          </div>
        </section>

        <section class="settings-section">
          <div class="settings-section__header">
            <h2 class="settings-section__heading">${S(`mcpPage.operatorCommands`)}</h2>
          </div>
          <p class="settings-section__desc">${S(`mcpPage.operatorCommandsHint`)}</p>
          <div class="settings-group">
            <div class="settings-row settings-row--stacked">
              <div class="mcp-command-card__grid">
                <code>openclaw mcp status --verbose</code>
                <code>openclaw mcp doctor --probe</code>
                <code>openclaw mcp login &lt;name&gt;</code>
                <code>openclaw mcp reload</code>
              </div>
            </div>
          </div>
        </section>

        <openclaw-mcp-servers-card
          .pluginsHref=${e.pluginsHref}
          .docsUrl=${Ja}
        ></openclaw-mcp-servers-card>
      </div>

      ${e.editor}
    </section>
  `}var Ja;function Ya(){return(Ya=e((()=>{A(),E(),V(),Ga(),C(),er(),ur(),nr(),Ja=`https://docs.openclaw.ai/tools/mcp`})))()}function Xa(e){return e?.availability===`enabled`&&e.canStart!==!1&&!!e.autoStart}function Za(e){return O`<openclaw-meeting-capture-settings
    .mutationDisabled=${e.mutationDisabled}
    .advancedExpanded=${e.advancedExpanded}
    .editor=${e.editor}
  ></openclaw-meeting-capture-settings>`}var Qa,$a,eo;function to(){return(to=e((()=>{i(),hr(),A(),M(),Vn(),Un(),kn(),Bt(),E(),Lt(),V(),C(),ma(),_t(),pr(),dt(),ct(),Ci(),pa(),Qa=[`accountId`,`guildId`,`channelId`,`meetingUrl`],$a=[`title`,...Qa,`sessionId`],eo=class extends yt{constructor(...e){super(...e),this.mutationDisabled=!1,this.editor=k,this.advancedExpanded=!1,this.editing=null,this.editError=null,this.editedProviderId=``,this.sourceDraft={},this.gateway=new dr(this,{getGateway:()=>this.context?.gateway,invalidateRequests:()=>this.statusTask.abort(),onSnapshot:({snapshot:{hello:e}})=>{(e!==this.connectionHello||e?.auth!==this.connectionAuth)&&(this.gateway.invalidate(),this.statusTask.abort()),this.connectionHello=e,this.connectionAuth=e?.auth}}),this.subscriptions=new vt(this).watch(()=>this.context?.runtimeConfig,(e,t)=>e.subscribe(t)),this.statusTask=new gr(this,{args:()=>[this.client,this.gateway.epoch,this.context?.runtimeConfig.state.configSnapshot?.hash],task:async([e,,t],{signal:n})=>{if(!e)return Cr;let r=this.gateway.capture(),i=this.context.gateway,a=i.snapshot.hello,o=a?.auth,s=await e.request(`transcripts.status`,{},{signal:n}),c=()=>this.client===e&&r!==null&&this.gateway.isCurrent(r)&&this.context.gateway===i&&i.snapshot.hello===a&&a?.auth===o&&this.context.runtimeConfig.state.configSnapshot?.hash===t;return c()?{status:s,isCurrent:c}:Cr},onComplete:e=>{e.isCurrent()&&this.retainLocatorRequirements(e.status)}})}get client(){let e=this.context?.gateway.snapshot;return this.isConnected&&e?.phase===`connected`&&rn(e.hello?.auth??null)?e.client:null}disconnectedCallback(){this.statusTask.abort(),this.subscriptions.clear(),this.editSource(null),super.disconnectedCallback()}get disabled(){let e=this.context.runtimeConfig;return this.mutationDisabled||!e.canSet||!e.state.connected||e.state.configLoading||e.state.configSaving||e.state.configApplying||this.rawDraftPending||!Yt(this.context.gateway.snapshot.hello?.auth??null)}get rawDraftPending(){let e=this.context.runtimeConfig.state;return e.configFormMode===`raw`&&e.configFormDirty}get config(){let e=this.context.runtimeConfig.state;return v(v(e.configForm??e.configSnapshot?.config)?.transcripts)}get sources(){return Array.isArray(this.config?.autoStart)?this.config.autoStart:[]}editSource(e){if(this.editing===e)return;this.editing=e,this.editedSource=typeof e==`number`?this.sources[e]:void 0,this.sourceDraft={...v(this.editedSource)},this.locatorRequirements=this.originalLocatorRequirements=void 0;let t=v(this.editedSource)?.providerId;this.selectProvider(typeof t==`string`?t:``),this.editError=null}selectProvider(e){this.editedProviderId!==e&&(this.locatorRequirements=void 0),this.editedProviderId=e,this.retainLocatorRequirements(this.knownCaptureStatus)}retainLocatorRequirements(e){if(this.editing===null)return;let t=(t,n)=>{let r=e?.providers.find(e=>e.providerId===Me(t))?.autoStart;return r?{...n,...r}:n},n=v(this.editedSource)?.providerId;this.originalLocatorRequirements=t(n,this.originalLocatorRequirements),this.locatorRequirements=Me(this.editedProviderId)===Me(n)?this.originalLocatorRequirements:t(this.editedProviderId,this.locatorRequirements)}saveSource(e){if(e.preventDefault(),this.disabled||this.editing===null)return;let t=[...this.sources];if(this.editing!==`new`&&t[this.editing]!==this.editedSource){this.editError=S(`meetingCapture.sourceChanged`);return}let n=e.currentTarget;if(!n.reportValidity())return;let r=new FormData(n),i={...v(this.editedSource)},a=Me(r.get(`providerId`)),o=this.captureStatus?.providers.find(e=>e.providerId===a);if((this.editing===`new`||this.editedProviderId!==i.providerId)&&!Xa(o)){this.editError=S(`meetingCapture.autoStartUnavailable`);return}for(let e of[`providerId`,...$a]){let t=e===`providerId`?this.editedProviderId:this.sourceDraft[e];if(!r.has(e)||this.editing!==`new`&&t===i[e])continue;let n=Me(r.get(e));n?i[e]=n:delete i[e]}let s=Qa.find(e=>this.locatorRequirements?.[e]===`required`&&!Me(i[e]));if(s){this.editError=S(`meetingCapture.requiredLocator`,{field:S(`meetingCapture.fields.${s}`)});return}this.editing===`new`?t.push(i):t[this.editing]=i,this.context.runtimeConfig.patchForm([`transcripts`,`autoStart`],[...t]),this.editSource(null)}renderSourceEditor(e){if(this.editing===null)return k;let t=this.sourceDraft,n=e?.providers.filter(Xa).toSorted((e,t)=>e.name.localeCompare(t.name))??[],r=typeof t?.providerId==`string`?t.providerId:``,i=n.map(e=>({id:e.providerId,label:`${e.name} · ${S(`meetingCapture.availability.${e.availability}`)}`}));for(let e of[r,this.editedProviderId])e&&!i.some(t=>t.id===e)&&i.push({id:e,label:e});let a=e?.providers.find(e=>e.providerId===this.editedProviderId),o=[`title`,...Qa.filter(e=>this.locatorRequirements?.[e]||t?.[e]!==void 0),`sessionId`];return O`<form @submit=${e=>this.saveSource(e)}>
      ${I({title:S(this.editing===`new`?`meetingCapture.addSource`:`meetingCapture.editSource`)},O`
          ${B({title:S(`meetingCapture.fields.providerId`),control:O`<select
              class="settings-select"
              name="providerId"
              aria-label=${S(`meetingCapture.fields.providerId`)}
              required
              ?disabled=${this.disabled}
              .value=${this.editedProviderId}
              @change=${e=>{this.selectProvider(e.target.value)}}
            >
              <option value="">${S(`meetingCapture.chooseProvider`)}</option>
              ${Pn(i,e=>e.id,e=>O`<option value=${e.id} ?selected=${e.id===this.editedProviderId}>
                    ${e.label}
                  </option>`)}
            </select>`})}
          ${this.editedProviderId&&!Xa(a)?U(S(`meetingCapture.autoStartUnavailable`)):k}
          ${Pn(o,e=>e,e=>B({title:S(`meetingCapture.fields.${e}`),description:e===`sessionId`?S(t.whenOccupied===!0?`meetingCapture.occupancySessionIdHint`:`meetingCapture.sessionIdHint`):e===`title`?S(`meetingCapture.titleHint`):void 0,control:O`<input
                  class="settings-input"
                  name=${e}
                  type=${e===`meetingUrl`?`url`:`text`}
                  aria-label=${S(`meetingCapture.fields.${e}`)}
                  ?disabled=${this.disabled||e===`sessionId`&&t.whenOccupied===!0}
                  ?required=${e!==`title`&&e!==`sessionId`&&this.locatorRequirements?.[e]===`required`}
                  .value=${typeof t?.[e]==`string`?t[e]:``}
                  @input=${t=>{this.sourceDraft[e]=t.target.value}}
                />`}))}
          ${B({title:S(`meetingCapture.locatorsHint`),control:O` <button
                type="button"
                class="btn"
                @click=${()=>{this.editSource(null)}}
              >
                ${S(`common.cancel`)}
              </button>
              <button
                type="submit"
                class="btn"
                ?disabled=${this.disabled||!this.editedProviderId}
              >
                ${S(`meetingCapture.saveSource`)}
              </button>`})}
          ${this.editError?U(O`<span role="alert">${this.editError}</span>`):k}
        `)}
    </form>`}get knownCaptureStatus(){let e=this.statusTask.value;return e?.isCurrent()?e.status:null}get captureStatus(){return this.statusTask.status===F.COMPLETE?this.knownCaptureStatus:null}render(){let e=this.captureStatus,t=this.statusTask.status===F.ERROR?x(this.statusTask.error):null,n=e?.latestTranscript,r=this.sources.map((t,n)=>{let r=v(t),i=e?.providers.find(e=>e.providerId===r?.providerId);return B({title:typeof r?.title==`string`?r.title:Me(r?.providerId)??S(`transcripts.unknown`),description:[i?.name,r?.accountId,r?.guildId,r?.channelId,r?.meetingUrl].filter(e=>typeof e==`string`&&e).join(` · `),control:O`<button
            class="btn"
            ?disabled=${this.disabled}
            aria-label=${S(`meetingCapture.editSourceNumber`,{number:String(n+1)})}
            @click=${()=>this.editSource(n)}
          >
            ${w.edit}${S(`meetingCapture.edit`)}
          </button>
          <button
            class="btn"
            ?disabled=${this.disabled}
            aria-label=${S(`meetingCapture.removeSourceNumber`,{number:String(n+1)})}
            @click=${()=>{this.disabled||(this.context.runtimeConfig.patchForm([`transcripts`,`autoStart`],this.sources.filter((e,t)=>t!==n)),this.editSource(null))}}
          >
            ${w.trash}${S(`common.remove`)}
          </button>`})});return O`${jr(O`
        <div class="settings-stack" id=${wi.meetingCapture}>
          ${I({title:S(`meetingCapture.title`),description:S(`meetingCapture.description`)},O`
              ${L({title:S(`meetingCapture.enabled`),description:S(`meetingCapture.enabledHint`),checked:this.config?.enabled!==!1,disabled:this.disabled,onChange:e=>{this.disabled||this.context.runtimeConfig.patchForm([`transcripts`,`enabled`],e)}})}
              ${Rr({title:S(`transcripts.library`),description:S(`meetingCapture.libraryHint`),onClick:()=>this.context.navigate(`meetings`)})}
              ${B({title:S(`meetingCapture.observedState`),description:S(`meetingCapture.stateHint`),control:z({kind:`muted`,label:S(e?e.enabled?`meetingCapture.states.enabled`:`meetingCapture.states.disabled`:`meetingCapture.states.unknown`)})})}
              ${B({title:S(`meetingCapture.latestTranscript`),description:n?n.title:S(e?`meetingCapture.noSaved`:`transcripts.unknown`),control:R(n?S(`transcripts.savedCount`,{count:String(n.utteranceCount)}):S(`transcripts.unknown`))})}
              ${n?B({title:S(`meetingCapture.lastUtterance`),control:R(n.lastUtteranceAt?new Date(n.lastUtteranceAt).toLocaleString():S(`transcripts.unknown`))}):k}
              ${B({title:S(`meetingCapture.health`),control:O`<button
                  class="btn"
                  ?disabled=${!this.client||this.statusTask.status===F.PENDING}
                  @click=${()=>void this.statusTask.run()}
                >
                  ${w.refresh}${S(`common.refresh`)}
                </button>`})}
              ${t?U(O`<span role="alert">${S(`meetingCapture.healthError`)} ${t}</span>`):k}
              ${this.statusTask.status===F.PENDING?U(O`<span role="status">${S(`common.loading`)}</span>`):k}
              ${Yt(this.context.gateway.snapshot.hello?.auth??null)?k:U(S(`configView.adminRequired`))}
              ${this.rawDraftPending?U(S(`meetingCapture.rawDraftPending`)):k}
            `)}
          ${I({title:S(`meetingCapture.sources`),description:S(`meetingCapture.sourcesHint`),actions:O`<button
                class="btn"
                ?disabled=${this.disabled||!e?.providers.some(Xa)}
                @click=${()=>this.editSource(`new`)}
              >
                ${w.plus}${S(`meetingCapture.addSource`)}
              </button>`},r.length?r:U(S(`meetingCapture.noSources`)))}
          ${Rn(this.editing,this.renderSourceEditor(e))}
          ${e&&!e.providers.some(Xa)?U(S(`meetingCapture.noAutoStartProviders`)):k}
          ${e?.configuredSources.length?I({title:S(`meetingCapture.sourceHealth`),description:S(`meetingCapture.armedHint`)},e.configuredSources.map(e=>B({title:e.title??e.source.providerId,description:[e.source.accountId,e.source.guildId,e.source.channelId,e.source.meetingUrl,e.startDiagnostic?S(`meetingCapture.startDiagnostics.${e.startDiagnostic}`):void 0].filter(Boolean).join(` · `),control:z({kind:`muted`,label:S(`meetingCapture.states.${e.state}`)})}))):k}
          ${e&&Object.values(e.omitted).some(e=>e>0)?O`<p class="settings-page__intro">
                  ${S(`meetingCapture.omitted`,{count:String(Object.values(e.omitted).reduce((e,t)=>e+t,0))})}
                </p>`:k}
          <p class="settings-page__intro">${S(`meetingCapture.safetyHint`)}</p>
          <p class="settings-page__intro">${S(`meetingCapture.durationHint`)}</p>
          <p class="settings-page__intro">${S(`meetingCapture.sttHint`)}</p>
        </div>
      `)}
      <details
        class="settings-page"
        ?open=${this.advancedExpanded}
        ${D({settingsPage:!0})}
      >
        <summary class="settings-section__heading">${S(`meetingCapture.advancedSettings`)}</summary>
        ${this.editor}
      </details>`}},b([Ve({context:Cn,subscribe:!0})],eo.prototype,`context`,void 0),b([N({type:Boolean})],eo.prototype,`mutationDisabled`,void 0),b([N({attribute:!1})],eo.prototype,`editor`,void 0),b([N({type:Boolean})],eo.prototype,`advancedExpanded`,void 0),b([j()],eo.prototype,`editing`,void 0),b([j()],eo.prototype,`editError`,void 0),b([j()],eo.prototype,`editedProviderId`,void 0),customElements.get(`openclaw-meeting-capture-settings`)||customElements.define(`openclaw-meeting-capture-settings`,eo)})))()}var no;function ro(){return(ro=e((()=>{A(),M(),dt(),Vi(),no=class extends yt{constructor(...e){super(...e),this.agentId=null}render(){return O`
      ${this.agentId?O`<openclaw-agent-memory-panel
              .agentId=${this.agentId}
            ></openclaw-agent-memory-panel>`:k}
    `}},b([N()],no.prototype,`agentId`,void 0),customElements.get(`openclaw-memory-dreaming`)||customElements.define(`openclaw-memory-dreaming`,no)})))()}function io(e,t){return`${t}:${e.path}:${e.startLine}:${e.endLine}`}function ao(e){let t=e.path.replaceAll(`\\`,`/`),n=!t.startsWith(`/`)&&!t.startsWith(`sessions/`)&&!/^[a-zA-Z]:\//.test(t)&&t.split(`/`).every(e=>e&&e!==`.`&&e!==`..`),r=t===`MEMORY.md`||t.startsWith(`memory/`);return e.source===`memory`&&n&&r}function oo(e,t){let n=e.split(/\r?\n/),r=Math.max(0,t.startLine-1),i=Math.min(n.length,t.endLine),a=n.slice(0,r),o=n.slice(r,i),s=n.slice(i);return O`<pre class="memory-memories__file" tabindex="0"><span
      >${a.join(`
`)}${a.length?`
`:``}</span
    ><mark data-memory-match="true">${o.join(`
`)}</mark
    ><span>${s.length?`\n${s.join(`
`)}`:``}</span></pre>`}var q;function so(){return(so=e((()=>{A(),M(),E(),C(),G(),_t(),dt(),W(),q=class extends yt{constructor(...e){super(...e),this.client=null,this.connected=!1,this.methodAdvertised=!0,this.agentId=null,this.query=``,this.searchState={kind:`idle`},this.openResultKey=null,this.details=new Map,this.searchRequest=null}updated(e){(e.has(`agentId`)||e.has(`client`)||e.has(`connected`)||e.has(`methodAdvertised`))&&this.resetSearch()}resetSearch(){this.searchRequest=null,this.query=``,this.searchState={kind:`idle`},this.openResultKey=null,this.details=new Map}async search(e){let t=e.trim(),n=this.connected?this.client:null,r=this.agentId;if(!t||!n||!r||!this.methodAdvertised)return;let i={client:n,agentId:r,query:t};this.searchRequest=i,this.query=t,this.searchState={kind:`loading`,query:t},this.openResultKey=null,this.details=new Map;try{let e=await n.request(`memory.search`,{query:t,agentId:r});if(this.searchRequest!==i||this.agentId!==r||this.client!==n)return;this.searchState={kind:`ready`,query:t,...e}}catch(e){if(this.searchRequest!==i||this.agentId!==r||this.client!==n)return;this.searchState={kind:`error`,query:t,message:x(e)}}}toggleResult(e,t){let n=io(e,t);if(this.openResultKey===n){this.openResultKey=null;return}this.openResultKey=n,this.details.has(e.path)||this.loadDetail(e.path)}async loadDetail(e){let t=this.connected?this.client:null,n=this.agentId;if(!t||!n)return;let r={kind:`loading`};this.details=new Map(this.details).set(e,r);try{let i=await t.request(`agents.workspace.get`,{agentId:n,path:e});if(this.details.get(e)!==r||this.agentId!==n)return;let a=i.file.encoding===`utf8`?{kind:`ready`,content:i.file.content}:{kind:`error`,message:S(`memoryPage.memories.fileUnsupported`)};this.details=new Map(this.details).set(e,a)}catch(t){if(this.details.get(e)!==r||this.agentId!==n)return;this.details=new Map(this.details).set(e,{kind:`error`,message:x(t)})}}renderDetail(e,t,n){if(this.openResultKey!==e)return k;let r=this.details.get(n.path);return O`<div id=${t} class="memory-memories__detail">
      ${!r||r.kind===`loading`?O`<p role="status">${S(`memoryPage.memories.fileLoading`)}</p>`:r.kind===`error`?O`<p class="memory-memories__detail-error" role="alert">
                ${S(`memoryPage.memories.fileError`,{message:r.message})}
              </p>`:oo(r.content,n)}
    </div>`}renderResults(e){let t=e.searchMode===`hybrid`?S(`memoryPage.memories.hybridSearch`):S(`memoryPage.memories.keywordSearch`);return O`
      ${e.stale?O`<div class="callout warn" role="status">
              ${e.warning?O`<p>${e.warning}</p>`:k}
              ${e.action?O`<p>${e.action}</p>`:k}
            </div>`:k}
      <div class="memory-memories__results-heading">
        <span>${S(`memoryPage.memories.results`,{count:String(e.results.length)})}</span>
        <span class="memory-memories__mode">${t}</span>
      </div>
      ${e.results.length===0?O`<p class="memory-memories__state">
              ${S(`memoryPage.memories.empty`,{query:e.query})}
            </p>`:O`<div class="settings-group memory-memories__results">
              ${e.results.map((e,t)=>{let n=io(e,t),r=this.openResultKey===n,i=ao(e),a=`memory-detail-${t}`,o=O`
                  <span class="settings-row__text">
                    <span class="settings-row__title">${e.snippet}</span>
                    <span class="settings-row__desc memory-memories__path"
                      >${e.path} ·
                      ${S(`memoryPage.memories.lineRange`,{start:String(e.startLine),end:String(e.endLine)})}</span
                    >
                  </span>
                  <span class="settings-row__control memory-memories__meta">
                    <span class="memory-memories__source"
                      >${S(e.source===`sessions`?`memoryPage.memories.sourceSessions`:`memoryPage.memories.sourceMemory`)}</span
                    >
                    <span
                      >${S(`memoryPage.memories.score`,{score:e.score.toFixed(2)})}</span
                    >
                  </span>
                `;return O`<article class="memory-memories__result">
                  ${i?O`<button
                          type="button"
                          class="settings-row settings-row--nav"
                          aria-expanded=${String(r)}
                          aria-controls=${a}
                          @click=${()=>this.toggleResult(e,t)}
                        >
                          ${o}
                        </button>`:O`<div class="settings-row">${o}</div>`}
                  ${i?this.renderDetail(n,a,e):k}
                </article>`})}
            </div>`}
    `}renderSearchState(){switch(this.searchState.kind){case`loading`:return O`<p class="memory-memories__state" role="status">
          ${S(`memoryPage.memories.searching`)}
        </p>`;case`error`:{let e=this.searchState;return O`<div class="memory-memories__state" role="alert">
          <p>${S(`memoryPage.memories.error`,{message:e.message})}</p>
          <button class="btn btn--sm" @click=${()=>void this.search(e.query)}>
            ${S(`memoryPage.memories.retry`)}
          </button>
        </div>`}case`ready`:return this.renderResults(this.searchState);default:return O`<p class="memory-memories__state">${S(`memoryPage.memories.idle`)}</p>`}}render(){return O`<div
      class="settings-page memory-memories"
      ${D({settingsPage:!0})}
    >
      ${this.methodAdvertised?O`<form
                class="memory-memories__search"
                role="search"
                @submit=${e=>{e.preventDefault(),this.search(this.query)}}
              >
                <label class="settings-control__sr-label" for="memory-search-input"
                  >${S(`memoryPage.memories.searchLabel`)}</label
                >
                <input
                  id="memory-search-input"
                  type="search"
                  class="settings-input"
                  .value=${this.query}
                  placeholder=${S(`memoryPage.memories.searchPlaceholder`)}
                  @input=${e=>{this.query=e.currentTarget.value}}
                />
                <button
                  class="btn btn--sm primary"
                  type="submit"
                  ?disabled=${!this.connected||!this.agentId||!this.query.trim()||this.searchState.kind===`loading`}
                >
                  ${S(`memoryPage.memories.searchButton`)}
                </button>
              </form>
              ${this.renderSearchState()}`:O`<p class="memory-memories__unavailable">
              ${S(`memoryPage.memories.gatewayUpdateRequired`)}
            </p>`}
    </div>`}},b([N({attribute:!1})],q.prototype,`client`,void 0),b([N({type:Boolean})],q.prototype,`connected`,void 0),b([N({type:Boolean})],q.prototype,`methodAdvertised`,void 0),b([N()],q.prototype,`agentId`,void 0),b([j()],q.prototype,`query`,void 0),b([j()],q.prototype,`searchState`,void 0),b([j()],q.prototype,`openResultKey`,void 0),b([j()],q.prototype,`details`,void 0),customElements.get(`openclaw-memory-memories`)||customElements.define(`openclaw-memory-memories`,q)})))()}function co(e,t){return[`plugins`,`entries`,e,`config`,`dreaming`,...t]}function lo(e){let t=v(e?.agents),n=v(t?.defaults)?.userTimezone;return typeof n==`string`&&n.trim()?n.trim():null}function uo(){return(uo=e((()=>{})))()}function fo(e,t){let n=e;for(let e of t)n=v(n)?.[e];return t.length?n:void 0}function po(e,t){let n=e;for(let[e,r]of t.entries()){if(!n||!Object.hasOwn(n,r))return!1;if(e===t.length-1)return!0;n=v(n[r])}return!1}function mo(e){return To.find(t=>t===e)??Eo}function ho(e){let t=fo(e,[`execution`,`defaults`,`model`]);return typeof t==`string`&&t.trim()?t.trim():S(`memoryPage.dreaming.model.default`)}function go(e,t){let n=Number(e);return!Number.isFinite(n)||n<t.min||t.integer&&!Number.isInteger(n)||t.max!==void 0&&n>t.max?null:n}function _o(e,t){let n=fo(e.dreaming,t.path),r=po(e.dreaming,t.path),i=t.kind===`toggle`?t.fallback?S(`common.enabled`):S(`common.disabled`):t.kind===`number`?String(t.defaultValue):t.path[0]===`timezone`?e.timezoneDefault??S(`memoryPage.dreaming.timezone.default`):t.path[0]===`model`?ho(e.dreaming):t.defaultValue??``,a=H(i,r);if(t.kind===`toggle`)return L({title:S(t.labelKey),description:O`${S(t.helpKey)} ${a}`,checked:typeof n==`boolean`?n:t.fallback,disabled:e.disabled,onChange:n=>e.onPatch(t.path,n)});let o=t.kind===`number`?typeof n==`number`?String(n):``:typeof n==`string`?n:``,s=t.kind===`number`?t.bounds:null;if(t.kind===`text`&&t.path[0]===`model`){let n=Mr(i);return B({title:S(t.labelKey),description:O`${S(t.helpKey)} ${a}`,control:qi({label:S(t.labelKey),value:o,options:[{value:``,label:i,...n?{provider:n}:{}}],disabled:e.disabled,custom:{label:S(`cron.form.customModel`),placeholder:t.placeholderKey?S(t.placeholderKey):``,commit:`change`},onChange:n=>e.onPatch(t.path,n.trim()||void 0)})})}return B({title:S(t.labelKey),description:O`${S(t.helpKey)} ${a}`,control:O`
      <input
        class="settings-input"
        type=${t.kind===`number`?`number`:`text`}
        min=${s?String(s.min):k}
        max=${s?.max===void 0?k:String(s.max)}
        step=${s?s.integer?`1`:`any`:k}
        spellcheck="false"
        aria-label=${S(t.labelKey)}
        ?disabled=${e.disabled}
        .value=${o}
        placeholder=${i}
        @change=${n=>{let r=n.currentTarget,i=r.value.trim();if(!i){e.onPatch(t.path,void 0);return}if(s){let n=go(i,s);if(n===null){r.value=o;return}e.onPatch(t.path,n);return}e.onPatch(t.path,i)}}
      />
    `})}function vo(e){let t=mo(fo(e.dreaming,[`storage`,`mode`])),n=H(S(`memoryPage.dreaming.storage.modes.separate`),po(e.dreaming,[`storage`,`mode`]));return O`
    ${I({title:S(`memoryPage.dreaming.schedule.title`),description:S(`memoryPage.dreaming.schedule.description`)},Co.map(t=>_o(e,t)))}
    ${I({title:S(`memoryPage.dreaming.storage.title`),description:S(`memoryPage.dreaming.storage.description`)},O`
        ${B({title:S(`memoryPage.dreaming.storage.modeLabel`),description:O`
            ${S(`memoryPage.dreaming.storage.modeHelp`)} ${n}
          `,stacked:!0,control:Ur({value:t,options:To.map(e=>({value:e,label:S(`memoryPage.dreaming.storage.modes.${e}`)})),ariaLabel:S(`memoryPage.dreaming.storage.modeLabel`),disabled:e.disabled,onChange:t=>e.onPatch([`storage`,`mode`],t)})})}
        ${_o(e,{kind:`toggle`,path:[`storage`,`separateReports`],labelKey:`memoryPage.dreaming.storage.separateReportsLabel`,helpKey:`memoryPage.dreaming.storage.separateReportsHelp`,fallback:!1})}
      `)}
    ${Object.entries(wo).map(([t,n])=>I({title:S(`memoryPage.dreaming.phases.${t}.title`),description:S(`memoryPage.dreaming.phases.${t}.description`)},[_o(e,{kind:`toggle`,path:[`phases`,t,`enabled`],labelKey:`memoryPage.dreaming.phaseFields.enabled`,helpKey:`memoryPage.dreaming.phaseFields.enabledHelp`,fallback:!0}),...n.map(([n,r,i])=>_o(e,{kind:`number`,path:[`phases`,t,n],labelKey:`memoryPage.dreaming.phaseFields.${n}`,helpKey:`memoryPage.dreaming.phaseFields.${n}Help`,bounds:r,defaultValue:i}))]))}
  `}function yo(e){return I({title:S(`memoryPage.dreaming.unsupported.title`)},B({title:S(`memoryPage.dreaming.unsupported.rowTitle`),description:S(`memoryPage.dreaming.unsupported.description`,{plugin:e})}))}var bo,xo,So,Co,wo,To,Eo;function Do(){return(Do=e((()=>{A(),Ji(),Or(),V(),C(),G(),W(),bo={integer:!0,min:0},xo={integer:!0,min:1},So={integer:!1,min:0,max:1},Co=[...[`frequency`,`timezone`,`model`].map(e=>({kind:`text`,path:[e],labelKey:`memoryPage.dreaming.${e}.label`,helpKey:`memoryPage.dreaming.${e}.help`,placeholderKey:`memoryPage.dreaming.${e}.placeholder`,defaultValue:e===`frequency`?`0 3 * * *`:void 0})),{kind:`toggle`,path:[`verboseLogging`],labelKey:`memoryPage.dreaming.verboseLogging.label`,helpKey:`memoryPage.dreaming.verboseLogging.help`,fallback:!1}],wo={light:[[`lookbackDays`,bo,2],[`limit`,bo,100],[`dedupeSimilarity`,So,.9]],deep:[[`limit`,bo,10],[`minScore`,So,.75],[`minRecallCount`,bo,3],[`minUniqueQueries`,bo,3],[`recencyHalfLifeDays`,bo,14],[`maxAgeDays`,xo,30],[`maxPromotedSnippetTokens`,xo,160]],rem:[[`lookbackDays`,bo,7],[`limit`,bo,10],[`minPatternStrength`,So,.75]]},To=[`inline`,`separate`,`both`],Eo=`separate`})))()}function Oo(e){return!e.embedding.ok&&e.embedding.checked!==!1}function ko(e){return e.provider===`none`?S(`memoryPage.overview.hero.keywordSearch`):S(`memoryPage.overview.hero.hybridSearch`)}function Ao(e){let t=Fi(e.engineSelection),n=e.engineSelection.kind===`off`||e.engineDisabled,r=e.status.kind===`ready`?e.status.payload:null,i=r?.searchRuntimeRegistered===!1,a=e.status.kind===`error`||!i&&r!==null&&Oo(r),o=gi(bi(e.agentId??`memory`)),s=n?S(`memoryPage.overview.hero.hibernating`):e.status.kind===`loading`||e.status.kind===`idle`?S(`memoryPage.overview.hero.waking`):S(i?`memoryPage.overview.hero.noSearchRuntime`:a?`memoryPage.overview.hero.needsAttention`:`memoryPage.overview.hero.awake`),c=n?S(e.engineDisabled?`memoryPage.overview.hero.disabledDescription`:`memoryPage.overview.hero.offDescription`):e.status.kind===`error`?e.status.message:r?i?S(`memoryPage.overview.hero.noSearchRuntimeDescription`,{engine:t??S(`common.unknown`)}):Oo(r)?r.embedding.error??S(`memoryPage.overview.health.unavailable`):S(`memoryPage.overview.hero.activeDescription`,{engine:t??S(`common.unknown`),mode:ko(r)}):S(`memoryPage.overview.hero.loadingDescription`),l=n?{sleeping:!0}:a?{grumpy:!0,standalone:!0}:r&&!i?{reading:!0,standalone:!0}:{standalone:!0};return O`
    <section class="memory-overview__hero ${n?`memory-overview__hero--sleeping`:``}">
      <div class="memory-overview__lobster" style=${fi(o)}>
        ${pi(o,l)}
      </div>
      <div class="memory-overview__hero-copy">
        <h2>${s}</h2>
        <p class=${a?`memory-overview__hero-error`:``}>${c}</p>
        <div class="memory-overview__hero-actions">
          ${n?O`<button class="btn btn--sm" @click=${()=>e.onNavigate(`settings`)}>
                  ${S(`memoryPage.overview.hero.openSettings`)}
                </button>`:O`<button class="btn btn--sm" @click=${e.onRefresh}>
                  ${e.status.kind===`error`?S(`memoryPage.overview.hero.retry`):S(`memoryPage.overview.hero.refresh`)}
                </button>`}
        </div>
      </div>
    </section>
  `}function jo(e,t,n){return[e.cron||S(`common.na`),t,n&&e.nextRunAtMs?S(`memoryPage.overview.schedule.nextRun`,{time:qe(e.nextRunAtMs)}):null,e.lastRunAtMs?S(`memoryPage.overview.schedule.lastRun`,{time:qe(e.lastRunAtMs)}):null].filter(e=>!!e).join(` · `)}function Mo(e){let t=[[`light`,e.phases.light],[`rem`,e.phases.rem],[`deep`,e.phases.deep]];return I({title:S(`memoryPage.overview.schedule.title`)},O`
      ${t.map(([t,n])=>B({title:S(`memoryPage.dreaming.phases.${t}.title`),description:O`
            ${S(`memoryPage.overview.schedule.${t}Description`)}<br />
            ${jo(n,e.timezone,e.enabled&&n.enabled&&n.managedCronPresent)}
          `,control:z({kind:e.enabled&&n.enabled&&n.managedCronPresent?`ok`:`muted`,label:!e.enabled||!n.enabled?S(`common.disabled`):n.managedCronPresent?S(`common.enabled`):S(`memoryPage.overview.schedule.notScheduled`)})}))}
      ${B({title:S(`memoryPage.overview.schedule.learnMore`),control:O`<a
          class="memory-page__link"
          href="https://docs.openclaw.ai/concepts/dreaming"
          target="_blank"
          rel="noreferrer noopener"
          >${S(`memoryPage.overview.schedule.openDocs`)}</a
        >`})}
    `)}function No(e){let t=[[`promotedToday`,e.promotedToday],[`promotedTotal`,e.promotedTotal],[`shortTermCount`,e.shortTermCount],[`phaseHitCount`,e.phaseSignalCount],[`lightPhaseHitCount`,e.lightPhaseHitCount],[`remPhaseHitCount`,e.remPhaseHitCount]];return I({title:S(`memoryPage.overview.activity.title`)},t.map(([e,t])=>B({title:S(`memoryPage.overview.activity.${e}`),control:R(t)})))}function Po(e,t){let n=e.embedding.checked===!1,r=e.embedding.ok?`ok`:n?`muted`:`danger`,i=t.probingEmbeddings?S(`memoryPage.overview.health.checking`):e.embedding.ok?S(`memoryPage.overview.health.healthy`):S(n?`memoryPage.overview.health.notChecked`:`memoryPage.overview.health.unavailable`);return I({title:S(`memoryPage.overview.health.title`)},O`
      ${B({title:S(`memoryPage.overview.health.provider`),control:R(e.provider??S(`common.unknown`),{mono:!0})})}
      ${B({title:S(`memoryPage.overview.health.embeddings`),description:e.embedding.ok?k:n?S(`memoryPage.overview.health.notCheckedDescription`):e.embedding.error,control:O`
          ${z({kind:r,label:i})}
          ${n?O`<button
                  type="button"
                  class="btn btn--sm"
                  ?disabled=${t.probingEmbeddings}
                  @click=${t.onProbeEmbeddings}
                >
                  ${t.probingEmbeddings?S(`memoryPage.overview.health.testing`):S(`memoryPage.overview.health.test`)}
                </button>`:k}
        `})}
      ${e.embeddingRuntime?B({title:S(`memoryPage.overview.health.runtime`),description:e.embeddingRuntime.loadError,control:R([e.embeddingRuntime.engine,e.embeddingRuntime.backend,e.embeddingRuntime.buildInfo,e.embeddingRuntime.model?.id,e.embeddingRuntime.endpoints?Object.entries(e.embeddingRuntime.endpoints).map(([e,t])=>`${e}=${t}`).join(` `):void 0].filter(Boolean).join(` · `))}):k}
    `)}function Fo(e){return e.status.kind===`ready`?O`
    ${e.status.payload.dreaming?Mo(e.status.payload.dreaming):k}
    ${e.status.payload.dreaming?No(e.status.payload.dreaming):k}
    ${e.status.payload.searchRuntimeRegistered===!1?k:Po(e.status.payload,e)}
  `:k}function Io(e){return I({title:S(`memoryPage.overview.shortcuts.title`)},[[`memories`,`memoryPage.overview.shortcuts.memories`],[`dreams`,`memoryPage.overview.shortcuts.diary`],[`settings`,`memoryPage.overview.shortcuts.settings`]].map(([t,n])=>Rr({title:S(n),onClick:()=>e.onNavigate(t)})))}function Lo(e){let t=e.engineSelection.kind!==`off`&&!e.engineDisabled;return O`
    <div class="settings-page memory-overview" ${D({settingsPage:!0})}>
      ${Ao(e)} ${t?Fo(e):k} ${Io(e)}
    </div>
  `}function Ro(){return(Ro=e((()=>{A(),E(),ui(),yi(),V(),C(),G(),Ze(),Li(),W()})))()}function zo(e,t){if(e.kind!==`ready`)return[];let n=e.plugins.filter(e=>e.installed&&e.kind?.includes(`memory`)===!0).map(e=>({id:e.id,label:e.id===Ei?S(`memoryPage.engine.openClawMemory`):e.name,available:!0})).toSorted((e,t)=>{let n=e.id===Ei;return n===(t.id===Ei)?e.label.localeCompare(t.label):n?-1:1}),r=Fi(t);if(r&&!n.some(e=>e.id===r)){let e={id:r,label:r===Ei?S(`memoryPage.engine.openClawMemory`):r,available:!1};r===Ei?n.unshift(e):n.push(e)}return n}function Bo(e,t){return e.kind===`ready`?!t?.installed||t.state===`not-installed`||t.state===`error`?`unknown`:t.enabled?`enabled`:`disabled`:e.kind===`loading`?`loading`:`unknown`}function Vo(e,t){return e.kind===`ready`&&t?e.plugins.find(e=>e.id===t):void 0}function Ho(e,t){return Xo.map(n=>{let r=Vo(e,n.id);return{id:n.id,label:S(n.labelKey),description:r?.description??n.id,state:Bo(e,r),busy:t.busy.has(n.id),error:t.errors.get(n.id)??null,notice:[t.notices.get(n.id)?.message,t.refreshWarnings.get(n.id)].filter(Boolean).join(` `)||null}})}function Uo(e){switch(e.kind){case`auto`:return`memoryPage.engine.autoHint`;case`off`:return`memoryPage.engine.offHint`;default:return`memoryPage.engine.explicitHint`}}function Wo(e){let t=Fi(e.engineSelection),n=e.engineOptions.find(e=>e.id===Ei)?.label??S(`memoryPage.engine.openClawMemory`),r=H(n,e.engineSelection.kind!==`auto`);if(e.engineOptions.length===0)return I({title:S(`memoryPage.engine.title`),description:S(`memoryPage.engine.description`)},B({title:S(`memoryPage.engine.rowTitle`),description:O`
          ${S(`memoryPage.engine.catalogUnavailable`)} ${S(Uo(e.engineSelection))}
          ${r}
        `,control:R(t??S(`memoryPage.engine.off`),{mono:!0})}));let i=[...e.engineOptions.map(e=>({value:e.id,label:e.available?e.label:`${e.label} (${S(`memoryPage.engine.unavailable`)})`})),{value:$o,label:S(`memoryPage.engine.off`)}];return I({title:S(`memoryPage.engine.title`),description:S(`memoryPage.engine.description`)},O`
      ${B({title:S(`memoryPage.engine.rowTitle`),description:O`${S(Uo(e.engineSelection))} ${r}`,stacked:!0,control:Ur({value:t??$o,options:i,disabled:e.engineBusy,ariaLabel:S(`memoryPage.engine.rowTitle`),onChange:t=>e.onEngineChange(t||null)})})}
      ${Go(e,t)}
      ${e.engineOutcome===null?k:B({title:S(e.engineOutcome.kind===`error`?`memoryPage.engine.changeFailed`:`pluginsPage.needsAttention`),description:e.engineOutcome.message,control:z({kind:e.engineOutcome.kind===`error`?`danger`:`warn`,label:S(e.engineOutcome.kind===`error`?`common.failed`:`pluginsPage.needsAttention`)})})}
    `)}function Go(e,t){return t===null||e.engineState!==`disabled`?k:B({title:S(`memoryPage.engine.disabledTitle`),description:S(`memoryPage.engine.disabledHint`),control:O`
      <button
        class="btn btn--sm"
        ?disabled=${e.engineBusy}
        @click=${()=>e.onEngineChange(t)}
      >
        ${S(`memoryPage.engine.enable`)}
      </button>
    `})}function Ko(e){switch(e){case`enabled`:return z({kind:`ok`,label:S(`common.enabled`)});case`disabled`:return z({kind:`muted`,label:S(`common.disabled`)});case`loading`:return z({kind:`muted`,label:S(`common.loading`)});default:return z({kind:`muted`,label:S(`memoryPage.addons.stateUnknown`)})}}function qo(e){return I({title:S(`memoryPage.addons.title`),description:S(`memoryPage.addons.description`)},O`
      ${e.addons.map(t=>O`
          ${e.canToggleAddons&&(t.state===`enabled`||t.state===`disabled`)?L({title:t.label,ariaLabel:S(`memoryPage.addons.toggleAriaLabel`,{plugin:t.label}),description:t.description,checked:t.state===`enabled`,disabled:t.busy,onChange:n=>e.onAddonChange(t.id,n)}):B({title:t.label,description:t.description,control:Ko(t.state)})}
          ${t.error===null?k:B({title:S(`memoryPage.addons.changeFailed`,{plugin:t.label}),description:t.error,control:z({kind:`danger`,label:S(`common.failed`)})})}
          ${t.notice===null?k:B({title:S(`pluginsPage.needsAttention`),description:t.notice,control:z({kind:`warn`,label:S(`pluginsPage.needsAttention`)})})}
        `)}
      ${B({title:S(`memoryPage.addons.manage`),control:O`<a class="memory-page__link" href=${e.pluginsHref}
          >${S(`memoryPage.addons.manageLink`)}</a
        >`})}
    `)}function Jo(e){return O`
    <div class="settings-page" ${D({settingsPage:!0})}>
      ${Wo(e)} ${qo(e)}
      <p class="settings-page__intro">${S(`memoryPage.search.intro`)}</p>
    </div>
    ${e.editor}
    <div class="settings-page" ${D({settingsPage:!0})}>
      ${e.dreamingSettings}
      ${I({title:S(`memoryPage.import.title`),description:S(`memoryPage.import.description`)},B({title:S(`tabs.memoryImport`),description:S(`subtitles.memoryImport`),control:e.canImportMemory?O`<a class="memory-page__link" href=${e.memoryImportHref}
                >${S(`memoryPage.import.link`)}</a
              >`:R(S(`memoryImport.adminRequired`))}))}
    </div>
  `}function Yo(e){return O`
    <section class="memory-page" ${D({memoryPage:!0})}>
      <section
        class="content-header content-header--settings content-header--page hub-page-header"
        ${D({toolbarHeader:!0})}
      >
        <div class="hub-page-header__title">
          <div class="page-title">${S(`tabs.memory`)}</div>
          <div class="page-subtitle">
            ${S(`memoryPage.intro`)} ${Yr(Qo)}
          </div>
        </div>
        <div class="hub-page-header__tabs">
          ${Vr({id:`memory`,active:e.activeTab,tabs:[{value:`overview`,label:S(`memoryPage.tabs.overview`)},{value:`memories`,label:S(`memoryPage.tabs.memories`)},{value:`dreams`,label:S(`memoryPage.tabs.dreams`)},{value:`settings`,label:S(`memoryPage.tabs.settings`)}],ariaLabel:S(`memoryPage.tablistLabel`),panelId:Zo,onSelect:t=>e.onTabChange(t)})}
        </div>
      </section>
      <div id=${Zo} class="memory-page__panel" role="tabpanel">
        ${e.activeTab===`overview`?e.overview:e.activeTab===`memories`?e.memories:e.activeTab===`dreams`?e.dreams:Jo(e)}
      </div>
    </section>
  `}var Xo,Zo,Qo,$o;function es(){return(es=e((()=>{A(),E(),Hr(),V(),C(),ga(),sr(),G(),Li(),W(),cr(),ha(),Xo=[{id:`active-memory`,labelKey:`memoryPage.addons.activeMemory.title`},{id:`memory-wiki`,labelKey:`memoryPage.addons.memoryWiki.title`}],Zo=`memory-settings-panel`,Qo=`https://docs.openclaw.ai/concepts/memory`,$o=``})))()}function ts(e){return O`
    <openclaw-memory-settings
      .configObject=${e.configObject}
      .mutationDisabled=${e.mutationDisabled}
      .pluginsHref=${e.pluginsHref}
      .memoryImportHref=${e.memoryImportHref}
      .routeData=${e.routeData}
      .buildEditor=${e.buildEditor}
    ></openclaw-memory-settings>
  `}var ns,rs,is,J;function as(){return(as=e((()=>{i(),A(),M(),Gt(),kn(),Bt(),V(),C(),G(),We(),_t(),qn(),pt(),dt(),ct(),Ui(),ro(),so(),uo(),Do(),Ro(),Li(),es(),W(),ns=`none`,rs=[`plugins`,`slots`,`memory`],is=`https://docs.openclaw.ai/concepts/dreaming`,J=class extends yt{constructor(...e){super(...e),this.configObject={},this.mutationDisabled=!1,this.pluginsHref=``,this.memoryImportHref=``,this.routeData=null,this.buildEditor=()=>O``,this.catalog={kind:`unavailable`},this.engineBusy=!1,this.engineOutcome=null,this.addonBusy=new Set,this.addonErrors=new Map,this.addonNotices=new Map,this.addonRefreshWarnings=new Map,this.selectedAgentId=null,this.overviewStatus={kind:`idle`},this.probingEmbeddings=!1,this.support=`unknown`,this.connection=null,this.catalogRequest=0,this.overviewRequest=null,this.supportPluginId=null,this.supportProbe=null,this.addonNoticeOperations=new Map,this.normalizedLocation=``,this.subscriptions=new vt(this).effect(()=>this.context?.settingsAgentSelection,()=>{this.syncRouteAgent()}).watch(()=>this.context?.settingsAgentSelection,(e,t)=>e.subscribe(t),e=>this.selectAgent(e.state.selectedId)).watch(()=>this.context?.gateway,(e,t)=>e.subscribe(t),e=>this.syncGateway(e.snapshot)).watch(()=>this.context?.runtimeConfig,(e,t)=>e.subscribe(t),e=>this.syncSupport(e)).watch(()=>this.context?.agents,(e,t)=>e.subscribe(t),()=>void this.loadOverviewStatus())}disconnectedCallback(){this.subscriptions.clear(),this.connection=null,this.overviewRequest=null,this.probingEmbeddings=!1,this.catalog={kind:`unavailable`},this.supportPluginId=null,this.supportProbe=null,this.addonNoticeOperations.clear(),super.disconnectedCallback()}connectedCallback(){super.connectedCallback(),this.syncCanonicalLocation()}syncRouteAgent(){let e=new URLSearchParams(this.routeData?.search).get(`agent`)?.trim(),t=this.routeData?.agentSelectionIntent,n=this.context.settingsAgentSelection;e&&t?.owner===n&&t.revision===n.intentRevision&&n.set(te(e))}willUpdate(e){if(e.has(`routeData`)){let t=e.get(`routeData`),n=this.activeTab(t??null),r=this.activeTab();n!==r&&(this.overviewRequest=null,this.probingEmbeddings=!1),this.syncRouteAgent(),n!==r&&this.loadOverviewStatus()}}updated(e){if(e.has(`routeData`)&&this.syncCanonicalLocation(),e.has(`configObject`)){let t=e.get(`configObject`),n=t?Fi(ki(t)):null,r=Fi(ki(this.configObject));t&&n!==r&&(this.overviewRequest=null,this.probingEmbeddings=!1,this.loadOverviewStatus())}}activeTab(e=this.routeData){return ji(e??{},this.context?.basePath??``)??`overview`}syncCanonicalLocation(){let e=this.context,t=this.routeData;if(!e||!t)return;let n=Pi(t,e.basePath);if(!n){this.normalizedLocation=``;return}let r=`${t.pathname}${t.search}${t.hash}`;this.normalizedLocation!==r&&(this.normalizedLocation=r,e.replace(`memory`,n))}syncGateway(e){let{client:t}=e,n=e.phase===`connected`,r=e.hello?.server?.bootId,i=e.pluginCapabilities?.generation,a=i!==this.pluginGeneration;if(this.pluginGeneration=i,this.connection?.client===t&&this.connection.connected===n&&this.connection.bootId===r){a&&t&&n&&this.refreshPluginReads(t,this.connection);return}let o={client:t,connected:n,bootId:r};if(this.connection=o,this.engineBusy=!1,this.engineOutcome=null,this.addonBusy=new Set,this.addonRefreshWarnings=new Map,this.overviewRequest=null,this.probingEmbeddings=!1,!t||!n){this.catalog={kind:`unavailable`},this.activeTab()===`overview`&&(this.overviewStatus={kind:`error`,message:S(`memoryPage.overview.hero.gatewayOffline`)});return}this.catalog={kind:`loading`},this.addonNotices=new Map([...this.addonNotices].filter(([,e])=>e.bootId&&e.bootId===r)),this.refreshPluginReads(t,o)}refreshPluginReads(e,t){this.overviewRequest=null,this.probingEmbeddings=!1,this.supportPluginId=null,this.supportProbe=null,this.syncSupport(this.context.runtimeConfig),this.loadCatalog(e,t),this.loadOverviewStatus()}async loadCatalog(e,t){let n=++this.catalogRequest;try{let r=await tt(e);this.applyCatalog(t,n,{kind:`ready`,plugins:r.plugins,mutationAllowed:r.mutationAllowed})}catch{this.applyCatalog(t,n,{kind:`unavailable`})}}applyCatalog(e,t,n){this.isConnected&&this.connection===e&&this.catalogRequest===t&&(this.catalog=n)}selectAgent(e){this.selectedAgentId!==e&&(this.selectedAgentId=e,this.overviewRequest=null,this.overviewStatus={kind:`idle`},this.probingEmbeddings=!1,this.loadOverviewStatus())}async loadOverviewStatus(e={}){if(this.activeTab()!==`overview`)return;if(ki(this.configObject).kind===`off`){this.overviewRequest=null,this.overviewStatus={kind:`idle`},this.probingEmbeddings=!1;return}let t=this.connection,n=t?.connected?t.client:null,r=this.selectedAgentId;if(!t||!n){this.overviewStatus={kind:`error`,message:S(`memoryPage.overview.hero.gatewayOffline`)},this.probingEmbeddings=!1;return}if(!r||!e.force&&this.overviewRequest?.connection===t&&this.overviewRequest.agentId===r)return;let i=e.probeEmbeddings===!0,a={connection:t,agentId:r,probeEmbeddings:i};this.overviewRequest=a,this.probingEmbeddings=i,i||(this.overviewStatus={kind:`loading`});try{let e=await n.request(`doctor.memory.status`,{agentId:r,...i?{probe:!0}:{}});if(!this.isConnected||this.overviewRequest!==a)return;this.overviewStatus={kind:`ready`,payload:e}}catch(e){if(!this.isConnected||this.overviewRequest!==a)return;this.overviewStatus={kind:`error`,message:x(e)}}finally{this.overviewRequest===a&&(this.probingEmbeddings=!1)}}engineState(e){let t=Fi(e);return t===null?`unknown`:Bo(this.catalog,Vo(this.catalog,t))}applyPluginRefreshOutcome(e,t,n){if(this.connection!==e)return;if(!t){this.addonRefreshWarnings=new Map,this.engineOutcome?.kind===`warning`&&(this.engineOutcome=null);return}let r=S(`pluginsPage.configRefreshFailed`,{error:t});n?this.addonRefreshWarnings=new Map(this.addonRefreshWarnings).set(n,r):this.engineOutcome={kind:`warning`,message:r}}async changeAddon(e,t){if(this.addonBusy.has(e)||this.mutationDisabled||this.catalog.kind!==`ready`||!this.catalog.mutationAllowed||!Tn(this.context.gateway.snapshot).canAdmin)return;let n=Vo(this.catalog,e),r=Bo(this.catalog,n),i=this.connection,a=i?.connected?i.client:null;if(!i||!a||r!==`enabled`&&r!==`disabled`)return;let o={};this.addonNoticeOperations.set(e,o),this.addonBusy=new Set(this.addonBusy).add(e);let s=new Map(this.addonErrors);s.delete(e),this.addonErrors=s;let c=new Map(this.addonRefreshWarnings);c.delete(e),this.addonRefreshWarnings=c;try{let n=await it(this.context.runtimeConfig,a,async n=>{let r=this.context.gateway.snapshot.hello?.server?.bootId;return{result:await Ye(n,e,t),bootId:r}},{canDispatch:()=>this.canDispatchPluginMutation(i)}),{result:r,bootId:s}=n.value,c=(`warnings`in r?r.warnings??[]:[]).join(` `);if(this.addonNoticeOperations.get(e)===o){this.applyPluginRefreshOutcome(i,n.refreshError,e);let t=new Map(this.addonNotices),r=this.context.gateway.snapshot.hello?.server?.bootId;c&&(s&&r?s===r:this.connection===i)?t.set(e,{message:c,bootId:s}):t.delete(e),this.addonNotices=t}let l=this.connection;l?.connected&&l.client&&await this.loadCatalog(l.client,l)}catch(t){this.connection===i&&(this.addonErrors=new Map(this.addonErrors).set(e,x(t)))}finally{if(this.addonNoticeOperations.get(e)===o&&this.addonNoticeOperations.delete(e),this.connection===i){let t=new Set(this.addonBusy);t.delete(e),this.addonBusy=t}}}canDispatchPluginMutation(e){return this.connection===e&&!this.mutationDisabled&&(this.catalog.kind!==`ready`||this.catalog.mutationAllowed)&&Tn(this.context.gateway.snapshot).canAdmin}async changeEngine(e,t){if(this.engineBusy||this.mutationDisabled||this.catalog.kind===`ready`&&!this.catalog.mutationAllowed||e===Fi(t)&&(e===null||this.engineState(t)===`enabled`))return;if(this.engineOutcome=null,!e){this.context.runtimeConfig.patchForm(rs,ns);return}let n=this.connection,r=n?.connected?n.client:null;if(n&&r){this.engineBusy=!0;try{let t=await it(this.context.runtimeConfig,r,t=>Ye(t,e,!0),{canDispatch:()=>this.canDispatchPluginMutation(n)});this.applyPluginRefreshOutcome(n,t.refreshError);let i=this.connection;i?.connected&&i.client&&await this.loadCatalog(i.client,i)}catch(e){this.connection===n&&(this.engineOutcome={kind:`error`,message:x(e)})}finally{this.connection===n&&(this.engineBusy=!1)}}}dreamingPluginId(){return Ki(gt(this.context.runtimeConfig.state)).pluginId}syncSupport(e){let t=Ki(gt(e.state)).pluginId;t!==this.supportPluginId&&(this.supportPluginId=t,this.support=`unknown`);let n=e.state.connected;if(this.supportProbe&&(this.supportProbe.pluginId!==t||!n)&&(this.supportProbe=null),this.support!==`unknown`||this.supportProbe||!n)return;let r={pluginId:t};this.supportProbe=r,Hi(e,t).then(e=>{this.supportProbe===r&&(this.supportProbe=null,this.isConnected&&(this.support=e))})}patchDreaming(e,t){if(this.mutationDisabled)return;let n=co(this.dreamingPluginId(),e);if(t===void 0){this.context.runtimeConfig.removeFormValue(n);return}this.context.runtimeConfig.patchForm(n,t)}renderDreamingControls(){let e=gt(this.context.runtimeConfig.state),{pluginId:t}=Ki(e),n=v(e?.plugins),r=v(v(n?.entries)?.[t]);return O`
      <p class="settings-page__intro">
        ${S(`memoryPage.dreaming.intro`,{plugin:t})}
        ${Yr(is)}
      </p>
      ${this.support===`unsupported`?yo(t):vo({dreaming:v(v(r?.config)?.dreaming),timezoneDefault:lo(e),disabled:this.mutationDisabled,onPatch:(e,t)=>this.patchDreaming(e,t)})}
    `}navigateTab(e){this.context.navigate(`memory`,{pathname:hn(e,this.context.basePath)})}render(){let e=ki(this.configObject),t=this.mutationDisabled||this.catalog.kind===`ready`&&!this.catalog.mutationAllowed,n=this.activeTab(),r=this.selectedAgentId,i=r?null:this.context.agents.state.agentsError,a=this.engineState(e);return Yo({activeTab:n,onTabChange:e=>this.navigateTab(e),engineOptions:zo(this.catalog,e),engineSelection:e,engineState:a,engineBusy:this.engineBusy||t,engineOutcome:this.engineOutcome,onEngineChange:t=>void this.changeEngine(t,e),addons:Ho(this.catalog,{busy:this.addonBusy,errors:this.addonErrors,notices:this.addonNotices,refreshWarnings:this.addonRefreshWarnings}),canToggleAddons:this.catalog.kind===`ready`&&this.catalog.mutationAllowed&&!this.mutationDisabled&&Tn(this.context.gateway.snapshot).canAdmin,onAddonChange:(e,t)=>void this.changeAddon(e,t),pluginsHref:this.pluginsHref,memoryImportHref:this.memoryImportHref,canImportMemory:Tn(this.context.gateway.snapshot).canAdmin,overview:Lo({agentId:r,engineSelection:e,engineDisabled:a===`disabled`,status:i?{kind:`error`,message:i}:this.overviewStatus,probingEmbeddings:this.probingEmbeddings,onRefresh:()=>r?void this.loadOverviewStatus({force:!0}):void this.context.agents.ensureList(),onProbeEmbeddings:()=>void this.loadOverviewStatus({force:!0,probeEmbeddings:!0}),onNavigate:e=>this.navigateTab(e)}),memories:O`
        <openclaw-memory-memories
          .client=${this.context.gateway.snapshot.client}
          .connected=${this.context.gateway.snapshot.phase===`connected`}
          .methodAdvertised=${Kn(this.context.gateway.snapshot,`memory.search`)===!0}
          .agentId=${r}
        ></openclaw-memory-memories>
      `,dreams:O` <openclaw-memory-dreaming .agentId=${r}></openclaw-memory-dreaming> `,editor:n===`settings`?this.buildEditor(Di(`settings`)):O``,dreamingSettings:n===`settings`?this.renderDreamingControls():O``})}},b([Ve({context:Cn,subscribe:!0})],J.prototype,`context`,void 0),b([N({attribute:!1})],J.prototype,`configObject`,void 0),b([N({type:Boolean})],J.prototype,`mutationDisabled`,void 0),b([N()],J.prototype,`pluginsHref`,void 0),b([N()],J.prototype,`memoryImportHref`,void 0),b([N({attribute:!1})],J.prototype,`routeData`,void 0),b([N({attribute:!1})],J.prototype,`buildEditor`,void 0),b([j()],J.prototype,`catalog`,void 0),b([j()],J.prototype,`engineBusy`,void 0),b([j()],J.prototype,`engineOutcome`,void 0),b([j()],J.prototype,`addonBusy`,void 0),b([j()],J.prototype,`addonErrors`,void 0),b([j()],J.prototype,`addonNotices`,void 0),b([j()],J.prototype,`addonRefreshWarnings`,void 0),b([j()],J.prototype,`selectedAgentId`,void 0),b([j()],J.prototype,`overviewStatus`,void 0),b([j()],J.prototype,`probingEmbeddings`,void 0),b([j()],J.prototype,`support`,void 0),customElements.get(`openclaw-memory-settings`)||customElements.define(`openclaw-memory-settings`,J)})))()}function os(e){let{gatewayAuth:t,execPolicy:n,browserEnabled:r,browserEnabledOverridden:i,toolProfile:a,toolProfileOverridden:o}=e.security,s=a.trim(),c=Gi.map(e=>({value:e.id,label:S(e.labelKey)}));return s&&!c.some(e=>e.value===s)&&c.push({value:s,label:s}),I({title:S(`quickSettings.security.title`)},[B({title:S(`quickSettings.security.gatewayAuth`),control:z({kind:t===`none`?`warn`:t===`unknown`?`muted`:`ok`,label:t})}),B({title:S(`quickSettings.security.execPolicy`),control:R(n)}),L({title:S(`quickSettings.security.browserEnabled`),description:H(S(`common.enabled`),i),checked:r,disabled:e.configBusy,onChange:t=>e.onBrowserEnabledToggle?.(t)}),B({title:S(`quickSettings.security.toolProfile`),description:o?void 0:S(`quickSettings.security.toolProfileDefault`),stacked:!0,control:Ur({value:s,options:c,ariaLabel:S(`quickSettings.security.toolProfile`),disabled:e.configBusy,onChange:t=>e.onToolProfileChange?.(t)})}),B({title:S(`devices.pairing.title`),control:O`
        <button
          class="btn"
          title=${e.canPairDevice?``:S(`devices.pairing.adminRequired`)}
          ?disabled=${!e.canPairDevice}
          @click=${e.onPairMobile}
        >
          ${w.smartphone} ${S(`devices.pairing.button`)}
        </button>
      `})])}function ss(e){return O`
    <section class="security-page">
      <div class="settings-page" ${D({settingsPage:!0})}>
        ${os(e)}
      </div>
      ${e.editor}
    </section>
  `}function cs(){return(cs=e((()=>{A(),E(),Lt(),V(),C(),Wi()})))()}function ls(e){return{gateway:{controlUi:{sessionObserver:e?null:!1}}}}function us(e){return{agents:{defaults:{utilityModel:e.kind===`auto`?null:e.kind===`disabled`?``:e.model}}}}function ds(e){return!e||e.status===`unavailable`?S(`configView.sessionObserver.modelUnavailable`):e.status===`disabled`?S(`configView.sessionObserver.modelDisabled`):S(e.status===`auto`?`configView.sessionObserver.modelAuto`:`configView.sessionObserver.modelConfigured`,{model:e.model})}function fs(e){let t=new Set;return e.filter(e=>e.available!==!1).map(e=>({value:e.id.startsWith(`${e.provider}/`)?e.id:`${e.provider}/${e.id}`,label:e.name||e.id,provider:e.provider})).filter(e=>!t.has(e.value)&&(t.add(e.value),!0)).toSorted((e,t)=>e.label.localeCompare(t.label))}function ps(e){let t=e.utilityModel===void 0?ms:e.utilityModel,n=fs(e.models),r=n.some(e=>e.value===t),i=Mr(t);return O`
    <div class="settings-group">
      ${L({title:S(`configView.sessionObserver.toggle`),description:S(`configView.sessionObserver.toggleHint`),checked:e.enabled,disabled:e.disabled,onChange:e.onEnabledChange})}
      ${B({title:S(`configView.sessionObserver.resolvedModel`),description:ds(e.resolvedUtilityModel)})}
      ${B({title:S(`configView.sessionObserver.modelPicker`),description:e.modelsUnavailable?S(`configView.sessionObserver.modelCatalogUnavailable`):S(`configView.sessionObserver.modelPickerHint`),control:qi({label:S(`configView.sessionObserver.modelPicker`),value:t,options:[{value:ms,label:S(`configView.sessionObserver.auto`)},{value:``,label:S(`configView.sessionObserver.disabled`)},...t!==ms&&t!==``&&!r?[{value:t,label:t,disabled:e.modelsUnavailable,...i?{provider:i}:{}}]:[],...n.map(({value:t,label:n,provider:r})=>({value:t,label:n,provider:r,disabled:e.modelsUnavailable}))],disabled:e.disabled,onChange:t=>e.onUtilityModelChange(t===ms?{kind:`auto`}:t===``?{kind:`disabled`}:{kind:`model`,model:t})})})}
    </div>
  `}var ms;function hs(){return(hs=e((()=>{A(),Ji(),Or(),V(),C(),G(),W(),ms=`__openclaw_observer_auto__`})))()}function gs(e){return ie(e,{style:`iec`,maxUnit:`tera`,separator:` `,fractionDigits:(e,t)=>t===`byte`?0:1})}function _s(e){return O`<openclaw-session-storage-settings
    .mutationDisabled=${e.mutationDisabled}
    .advancedExpanded=${e.advancedExpanded}
    .editor=${e.editor}
  ></openclaw-session-storage-settings>`}var Y;function vs(){return(vs=e((()=>{i(),hr(),A(),M(),Fn(),kn(),Bt(),E(),V(),C(),G(),_t(),Ze(),pr(),dt(),fr(),ct(),Ci(),W(),Y=class extends yt{constructor(...e){super(...e),this.mutationDisabled=!1,this.editor=k,this.advancedExpanded=!1,this.ageDraft=null,this.runBusy=!1,this.runError=null,this.runOutcome=null,this.runOperation=null,this.followingRun=!1,this.gateway=new dr(this,{getGateway:()=>this.context?.gateway,invalidateRequests:()=>this.retireRequests(),onSnapshot:({snapshot:{hello:e}})=>{(e!==this.connectionHello||e?.auth!==this.connectionAuth)&&(this.gateway.invalidate(),this.retireRequests()),this.connectionHello=e,this.connectionAuth=e?.auth}}),this.subscriptions=new vt(this).watch(()=>this.context?.runtimeConfig,(e,t)=>(this.gateway.invalidate(),this.retireRequests(),e.subscribe(t))),this.statusTask=new gr(this,{args:()=>[this.client,this.gateway.epoch,this.context?.gateway.snapshot.hello,this.context?.gateway.snapshot.hello?.auth,this.context?.runtimeConfig.state.configSnapshot?.appliedConfigHash],task:async([e,,t,n,r],{signal:i})=>{if(!e)return Cr;let a=this.gateway.capture(),o=this.context.gateway,s=await e.request(`sessions.storage.status`,{},{signal:i}),c=()=>this.client===e&&a!==null&&this.gateway.isCurrent(a)&&this.context.gateway===o&&o.snapshot.hello===t&&t?.auth===n&&this.context.runtimeConfig.state.configSnapshot?.appliedConfigHash===r;return c()?{status:s,isCurrent:c}:Cr},onComplete:e=>{e.isCurrent()&&this.observeMaintenance(e.status)},onError:()=>{this.maintenancePoll.stop(),this.runOutcome=null}}),this.maintenancePoll=new Qn(this,2e3,()=>{this.client?this.statusTask.status!==F.PENDING&&this.statusTask.run():this.maintenancePoll.stop()},!1)}retireRequests(){this.statusTask.abort(),this.maintenancePoll.stop(),this.followingRun=!1,this.ageDraft=null,this.runOperation=null,this.runBusy=!1,this.runError=null,this.runOutcome=null}get client(){let e=this.context?.gateway.snapshot;return this.isConnected&&e?.phase===`connected`&&Yt(e.hello?.auth??null)?e.client:null}observeMaintenance(e){if(e.maintenance.running){this.followingRun=!0,this.maintenancePoll.start();return}this.maintenancePoll.stop(),this.followingRun&&=(this.runOutcome=e.maintenance.lastError?null:[S(`configView.sessionStorage.runCompleted`,{count:String(e.maintenance.archivedTranscripts)}),e.maintenance.externalizedTranscripts>0?S(`configView.sessionStorage.externalized`,{count:String(e.maintenance.externalizedTranscripts)}):``].filter(Boolean).join(` `),this.runError=null,!1)}disconnectedCallback(){this.retireRequests(),this.subscriptions.clear(),super.disconnectedCallback()}get disabled(){let e=this.context.runtimeConfig;return this.mutationDisabled||this.runBusy||!this.client||!e.canSet||!e.state.connected||e.state.configLoading||e.state.configSaving||e.state.configApplying||e.state.configFormMode===`raw`&&e.state.configFormDirty}get coldStorage(){let e=this.context.runtimeConfig.state,t=v(v(e.configForm??e.configSnapshot?.config)?.session),n=v(v(t?.maintenance)?.coldStorage);return{enabled:n?.enabled===!0,afterDays:typeof n?.afterDays==`number`?n.afterDays:30}}get canRun(){let e=this.context.runtimeConfig.state,t=v(v(e.configSnapshot?.config)?.session),n=v(v(t?.maintenance)?.coldStorage),r=this.statusTask.value;return!this.disabled&&this.ageDraft===null&&!e.configFormDirty&&!e.configNeedsApply&&typeof e.configSnapshot?.appliedConfigHash==`string`&&n?.enabled===!0&&this.statusTask.status===F.COMPLETE&&r?.isCurrent()===!0&&!r.status.maintenance.running}async runNow(){let e=this.client,t=this.gateway.capture();if(!this.canRun||!e||!t)return;let n={},r=this.context.gateway,i=r.snapshot.hello;this.runOperation=n,this.runBusy=!0,this.runError=null,this.runOutcome=null;let a=()=>this.runOperation===n&&this.client===e&&this.gateway.isCurrent(t)&&this.context.gateway===r&&r.snapshot.hello===i;try{let t=await e.request(`sessions.storage.run`,{});if(!a())return;this.followingRun=!0,this.runOutcome=t.maintenance.running?S(`configView.sessionStorage.runStarted`):null,this.observeMaintenance(t),await this.statusTask.run()}catch(e){a()&&(this.runError=x(e))}finally{a()&&(this.runBusy=!1,this.runOperation=null)}}setAge(e){let t=e.currentTarget;this.ageDraft!==null&&!this.disabled&&t.reportValidity()&&(this.context.runtimeConfig.patchForm([`session`,`maintenance`,`coldStorage`,`afterDays`],t.valueAsNumber),this.ageDraft=null)}renderInventory(e){let t=e.agents.reduce((e,t)=>({transcripts:e.transcripts+t.hotTranscripts+t.coldTranscripts,cold:e.cold+t.coldTranscripts,database:e.database+t.databaseBytes,wal:e.wal+t.walBytes,archives:e.archives+t.archiveBytes,embedded:e.embedded+t.embeddedArchiveBytes}),{transcripts:0,cold:0,database:0,wal:0,archives:0,embedded:0}),n=e.maintenance.externalizedTranscripts>0?S(`configView.sessionStorage.externalized`,{count:String(e.maintenance.externalizedTranscripts)}):``;return O`
      ${B({title:S(`configView.sessionStorage.transcripts`),description:S(`configView.sessionStorage.transcriptCounts`,{hot:String(t.transcripts-t.cold),cold:String(t.cold)}),control:R(String(t.transcripts))})}
      ${B({title:S(`configView.sessionStorage.database`),description:S(`configView.sessionStorage.walSize`,{size:gs(t.wal)}),control:R(gs(t.database))})}
      ${B({title:S(`configView.sessionStorage.archives`),control:R(gs(t.archives))})}
      ${B({title:S(`configView.sessionStorage.embeddedArchives`),description:S(`configView.sessionStorage.embeddedArchivesHint`),control:R(gs(t.embedded))})}
      ${e.agents.length>1?O`<details class="settings-row settings-row--stacked">
              <summary>${S(`configView.sessionStorage.byAgent`)}</summary>
              ${e.agents.map(e=>B({title:e.agentId,description:S(`configView.sessionStorage.agentCounts`,{hot:String(e.hotTranscripts),cold:String(e.coldTranscripts),database:gs(e.databaseBytes),wal:gs(e.walBytes),archives:gs(e.archiveBytes),embedded:gs(e.embeddedArchiveBytes)})}))}
            </details>`:k}
      ${B({title:S(`configView.sessionStorage.worker`),description:e.maintenance.running?S(`configView.sessionStorage.runningProgress`,{archived:String(e.maintenance.archivedTranscripts),externalized:String(e.maintenance.externalizedTranscripts)}):e.maintenance.lastCompletedAt?[S(`configView.sessionStorage.completed`,{time:He(e.maintenance.lastCompletedAt),count:String(e.maintenance.archivedTranscripts)}),n].filter(Boolean).join(` `):S(`configView.sessionStorage.notRun`),control:z({kind:e.maintenance.lastError?`danger`:e.maintenance.running?`accent`:`muted`,label:S(e.maintenance.running?`configView.sessionStorage.running`:e.maintenance.lastError?`configView.sessionStorage.failed`:`configView.sessionStorage.idle`)})})}
      ${e.maintenance.lastError?U(O`<span role="alert">${e.maintenance.lastError}</span>`):k}
    `}render(){let e=this.statusTask.value,t=this.statusTask.status!==F.ERROR&&e?.isCurrent()?e.status:null,n=this.coldStorage;return O`
      ${jr(O`
        <div class="settings-stack" id=${Si}>
          ${I({title:S(`configView.sessionStorage.title`),description:S(`configView.sessionStorage.description`),actions:O`<button
                class="btn"
                ?disabled=${!this.client||this.statusTask.status===F.PENDING}
                @click=${()=>void this.statusTask.run()}
              >
                ${S(`common.refresh`)}
              </button>`},t?this.renderInventory(t):U(this.statusTask.status===F.ERROR?O`<span role="alert"
                        >${x(this.statusTask.error)}
                        ${S(`configView.sessionStorage.refreshAfterError`)}</span
                      >`:S(this.client?`common.loading`:this.context.gateway.snapshot.phase===`connected`?`configView.sessionStorage.adminRequired`:`configView.sessionStorage.disconnected`)))}
          ${I({title:S(`configView.sessionStorage.automatic`)},O`
              ${L({title:S(`configView.sessionStorage.enabled`),description:S(`configView.sessionStorage.enabledHint`),checked:n.enabled,disabled:this.disabled,onChange:e=>{this.disabled||this.context.runtimeConfig.patchForm([`session`,`maintenance`,`coldStorage`,`enabled`],e)}})}
              ${B({title:S(`configView.sessionStorage.afterDays`),description:S(`configView.sessionStorage.afterDaysHint`),control:O`<input
                  type="number"
                  class="settings-input"
                  aria-label=${S(`configView.sessionStorage.afterDays`)}
                  min="1"
                  max=${2**53-1}
                  step="1"
                  required
                  ?disabled=${this.disabled}
                  .value=${Bn(this.ageDraft??String(n.afterDays))}
                  @input=${e=>{this.ageDraft=e.currentTarget.value}}
                  @change=${e=>this.setAge(e)}
                  @blur=${()=>{this.ageDraft===String(n.afterDays)&&(this.ageDraft=null)}}
                />`})}
              ${B({title:S(`configView.sessionStorage.runNow`),description:S(`configView.sessionStorage.runHint`),control:O`<button
                  class="btn"
                  ?disabled=${!this.canRun}
                  @click=${()=>void this.runNow()}
                >
                  ${S(this.runBusy||t?.maintenance.running?`configView.sessionStorage.running`:`configView.sessionStorage.runNow`)}
                </button>`})}
              ${this.runError&&this.runError!==t?.maintenance.lastError?U(O`<span role="alert">${this.runError}</span>`):this.runOutcome?U(O`<span role="status">${this.runOutcome}</span>`):k}
            `)}
          <p class="settings-page__intro">${S(`configView.sessionStorage.backupHint`)}</p>
          ${Yr(`https://docs.openclaw.ai/gateway/config-agents/sessions#cold-storage`)}
        </div>
      `)}
      <details
        class="settings-page"
        ?open=${this.advancedExpanded}
        ${D({settingsPage:!0})}
      >
        <summary class="settings-section__heading">
          ${S(`configView.sessionStorage.advanced`)}
        </summary>
        ${this.editor}
      </details>
    `}},b([Ve({context:Cn,subscribe:!0})],Y.prototype,`context`,void 0),b([N({type:Boolean})],Y.prototype,`mutationDisabled`,void 0),b([N({attribute:!1})],Y.prototype,`editor`,void 0),b([N({type:Boolean})],Y.prototype,`advancedExpanded`,void 0),b([j()],Y.prototype,`ageDraft`,void 0),b([j()],Y.prototype,`runBusy`,void 0),b([j()],Y.prototype,`runError`,void 0),b([j()],Y.prototype,`runOutcome`,void 0),customElements.get(`openclaw-session-storage-settings`)||customElements.define(`openclaw-session-storage-settings`,Y)})))()}function ys(e){let t=c(c(e.talk)?.realtime),n=c(t?.providers)??{},r={};for(let[e,t]of Object.entries(n)){let n=c(t);n&&(r[e]={model:Fe(n.model),speakerVoice:Fe(n.speakerVoice)??Fe(n.voice)})}return{provider:Fe(t?.provider),model:Fe(t?.model),speakerVoice:Fe(t?.speakerVoice)??Fe(t?.speakerVoiceId),transport:Fe(t?.transport),consultRouting:Fe(t?.consultRouting)?.toLowerCase()??null,providerEntries:r}}function bs(e){let t=e?.trim().toLowerCase();return t===`gpt-live`||t?.startsWith(`gpt-live-`)===!0}function xs(e,t){return e!==void 0&&e.length>0&&!e.includes(t)}function Ss(){return(Ss=e((()=>{})))()}function Cs(e){let t=e.snapshot?.voice.locale;if(!t)return null;let n=Ds.get(e),r=n?.primary??t.primary;return{primary:r,additional:[...new Set(n?.additional??t.additional)].filter(e=>e!==r)}}function ws(e,t){let n=Ds.get(e);if(n)Object.assign(n,t);else{let n={...t};Ds.set(e,n);let r=e.subscribe(t=>{let i=t.voice.locale;if(!i){Ds.delete(e),r();return}n.primary===i.primary&&delete n.primary,n.additional&&n.additional.length===i.additional.length&&n.additional.every((e,t)=>e===i.additional[t])&&delete n.additional,n.primary===void 0&&n.additional===void 0&&(Ds.delete(e),r())})}t.additional&&e.set(`voice.locale.additional`,t.additional),t.primary!==void 0&&e.set(`voice.locale.primary`,t.primary)}function Ts(e,t,n){return I({title:S(`configPage.deviceTalk.triggerWords`)},B({title:S(`configPage.deviceTalk.triggerWords`),description:S(`configPage.deviceTalk.triggerWordsHint`),stacked:!0,control:O`
        ${e.kind===`ready`?O`<textarea
                class="settings-input"
                aria-label=${S(`configPage.deviceTalk.triggerWords`)}
                rows="4"
                .value=${e.text}
                @input=${e=>{t(e.currentTarget.value)}}
              ></textarea>`:k}
        ${e.kind===`error`||e.kind===`ready`&&e.error?O`<div class="callout danger" role="alert">
                ${e.error}
                <button class="btn btn--sm" type="button" @click=${n}>
                  ${S(`common.retry`)}
                </button>
              </div>`:e.kind===`unavailable`?O`<span class="muted"
                  >${S(`configPage.deviceTalk.triggerWordsUnavailable`)}</span
                >`:O`<span class="muted" role="status"
                  >${e.kind===`loading`?S(`common.loading`):e.kind===`ready`&&e.phase!==`saved`?S(`common.saving`):S(`configPage.deviceTalk.saved`)}</span
                >`}
      `}))}function Es(e){if(!e)return k;let t=e.snapshot?.voice;if(!t)return I({title:S(zt(e.snapshot))},B({title:S(`common.loading`)}));let n=t.microphone,r=[{value:``,label:S(`configPage.deviceTalk.systemDefault`)},...n?.devices.map(({id:e,name:t})=>({value:e,label:t}))??[]];n?.selectedId&&!n.devices.some(({id:e})=>e===n.selectedId)&&r.push({value:n.selectedId,label:S(`configPage.deviceTalk.disconnectedMicrophone`,{id:n.selectedId})});let i=(t.locale?.available??[]).map(({id:e,name:t})=>({value:e,label:t})),a=Cs(e);return I({title:S(zt(e.snapshot))},[...[`wakeEnabled`,`wakeTriggersTalkMode`,`pushToTalkEnabled`,`talkShiftToStopEnabled`,`talkPhaseSoundsEnabled`,`realtimeRelayEnabled`,`triggerChime`,`sendChime`,`talkEnabled`,`talkButtonEnabled`,`talkBackgroundEnabled`,`speakerphoneEnabled`].map(n=>{let r=t[n];return r===void 0?k:L({title:S(`configPage.deviceTalk.${n}`),checked:r,disabled:n===`wakeEnabled`&&!t.supported&&!t.wakeEnabled,description:n===`wakeEnabled`&&!t.supported?S(e.snapshot?.device.platform===`macos`?`configPage.deviceTalk.unsupported`:`configPage.deviceTalk.unsupportedDevice`):n===`realtimeRelayEnabled`?S(`configPage.deviceTalk.realtimeRelayHint`):void 0,onChange:t=>e.set(`voice.${n}`,t)})}),n?K({title:S(`configPage.deviceTalk.microphone`),value:n.selectedId??``,options:r,onChange:t=>e.set(`voice.microphone`,t||null)}):k,a?K({title:S(`configPage.deviceTalk.primaryLanguage`),value:a.primary,options:i,onChange:t=>{let n=Cs(e);n&&ws(e,{primary:t,...n.additional.includes(t)?{additional:n.additional.filter(e=>e!==t)}:{}})}}):k,a?B({title:S(`configPage.deviceTalk.additionalLanguages`),stacked:!0,control:O`
            ${a.additional.map(t=>{let n=i.find(e=>e.value===t)?.label??t;return O`<div>
                ${n}
                <button
                  class="btn btn--sm"
                  type="button"
                  aria-label=${S(`configPage.deviceTalk.removeLanguage`,{name:n})}
                  @click=${()=>{let n=Cs(e);n&&ws(e,{additional:n.additional.filter(e=>e!==t)})}}
                >
                  ${S(`common.remove`)}
                </button>
              </div>`})}
            <select
              class="settings-select"
              aria-label=${S(`configPage.deviceTalk.addLanguage`)}
              @change=${t=>{let n=t.currentTarget,r=Cs(e);n.value&&r&&n.value!==r.primary&&!r.additional.includes(n.value)&&(ws(e,{additional:[...r.additional,n.value]}),n.value=``)}}
            >
              <option value="">${S(`configPage.deviceTalk.addLanguage`)}</option>
              ${i.filter(({value:e})=>e!==a.primary&&!a.additional.includes(e)).map(({value:e,label:t})=>O`<option value=${e}>${t}</option>`)}
            </select>
          `}):k,n?B({title:S(`configPage.deviceTalk.microphoneTest`),control:O`<button
            class="btn btn--sm"
            type="button"
            @click=${()=>e.openPanel(`microphone-test`)}
          >
            ${S(`configPage.deviceTalk.microphoneTest`)}
          </button>`}):k])}var Ds;function Os(){return(Os=e((()=>{A(),Sn(),V(),C(),G(),_a(),W(),Ds=new WeakMap})))()}function ks(e,t){if(t)return e.find(e=>e.id===t||e.aliases.includes(t))}function As(e,t){if(e.kind===`ready`)return ks(e.providers,t.provider||e.activeProvider)}function js(e,t){return se([e.provider,t?.id,...t?.aliases??[]].flatMap(t=>t&&t in e.providerEntries?[t]:[]))}function Ms(e,t){let n=e.model,r=e.speakerVoice;for(let i of js(e,t)){let t=e.providerEntries[i];n??=t?.model??null,r??=t?.speakerVoice??null}return{model:n,speakerVoice:r}}function Ns(e){let t=e.catalog;return t.kind===`loading`?B({title:S(`talkPage.status.title`),control:z({kind:`muted`,label:S(`common.loading`)})}):t.kind===`unavailable`?B({title:S(`talkPage.status.title`),description:S(`talkPage.status.unavailableHint`),control:z({kind:`muted`,label:S(`talkPage.status.unavailable`)})}):B({title:S(`talkPage.status.title`),description:t.activeProvider?S(`talkPage.status.activeProvider`,{provider:t.activeProvider}):S(`talkPage.status.noProvider`),control:t.ready?z({kind:`ok`,label:S(`talkPage.status.ready`)}):z({kind:`warn`,label:S(`talkPage.status.notReady`)})})}function Ps(e){if(e.catalog.kind!==`ready`||e.catalog.providers.length===0)return B({title:S(`talkPage.provider.title`),description:S(`talkPage.provider.description`),control:R(e.selection.provider??S(`talkPage.provider.auto`),{mono:!0})});let t=ks(e.catalog.providers,e.selection.provider),n=e.selection.provider&&!t?e.selection.provider:null;return B({title:S(`talkPage.provider.title`),description:S(`talkPage.provider.description`),stacked:!0,control:Ur({value:t?.id??n??zs,options:[...e.catalog.providers.map(e=>({value:e.id,label:e.label})),...n?[{value:n,label:n}]:[],{value:zs,label:S(`talkPage.provider.auto`)}],disabled:e.configBusy,ariaLabel:S(`talkPage.provider.title`),onChange:t=>e.onProviderChange(t||null)})})}function Fs(e){let t=As(e.catalog,e.selection),{model:n}=Ms(e.selection,t);if(!t)return B({title:S(`talkPage.model.title`),description:S(`talkPage.model.description`),control:R(n??S(`talkPage.model.default`),{mono:!0})});let r=t.models.length?t.models:t.defaultModel?[t.defaultModel]:[],i=[{value:zs,label:t.defaultModel?S(`talkPage.model.defaultNamed`,{model:t.defaultModel}):S(`talkPage.model.default`)},...r.map(e=>({value:e,label:e})),...n&&!r.includes(n)?[{value:n,label:n}]:[]];return B({title:S(`talkPage.model.title`),description:S(`talkPage.model.description`),control:qi({label:S(`talkPage.model.title`),value:n??zs,options:i.map(({value:e,label:n})=>({value:e,label:n,provider:t.id})),disabled:e.configBusy,onChange:t=>e.onModelChange(t||null)})})}function Is(e){let t=As(e.catalog,e.selection),{model:n,speakerVoice:r}=Ms(e.selection,t),i=e.modelDefaultPending?t?.defaultModel:n,a=t?.voicesByModel?.[i??``],o=e.modelDefaultPending!==!0&&(n===null||bs(n)&&a===void 0),s=o?t?.activeVoices??t?.voices??[]:a??t?.voices??[],c=o&&t?.activeVoiceSelectionPolicy===`allowlist-default`&&r!==null&&!s.includes(r);if(s.length===0)return B({title:S(`talkPage.voice.title`),description:S(`talkPage.voice.description`),control:R(r??S(`talkPage.voice.default`),{mono:!0})});let l=[{value:zs,label:S(`talkPage.voice.default`)},...s.map(e=>({value:e,label:e})),...r&&!s.includes(r)?[{value:r,label:c?`${r} (${S(`talkPage.voice.unsupported`)})`:r}]:[]];return K({title:S(`talkPage.voice.title`),description:S(c?`talkPage.voice.unsupportedDefault`:`talkPage.voice.description`),value:r??zs,options:l,disabled:e.configBusy,onChange:t=>e.onVoiceChange(t||null)})}function Ls(e){let t=As(e.catalog,e.selection),{model:n}=Ms(e.selection,t);return t?.id!==`openai`||!bs(n)?k:B({title:S(`talkPage.gptLive.title`),description:S(`talkPage.gptLive.hint`),control:t.configured?z({kind:`ok`,label:S(`talkPage.gptLive.ready`)}):z({kind:`warn`,label:S(`talkPage.status.notReady`)})})}function Rs(e){return O`
    <section class="talk-page">
      <div class="settings-page" ${D({settingsPage:!0})}>
        ${Es(e.nativeDeviceSettings)}
        ${e.voiceWake?Ts(e.voiceWake.state,e.voiceWake.onInput,e.voiceWake.onRetry):k}
        ${I({title:S(`talkPage.voiceSection.title`),description:S(`talkPage.voiceSection.description`)},O`
            ${Ns(e)} ${Ps(e)} ${Fs(e)}
            ${Is(e)} ${Ls(e)}
          `)}
      </div>
      ${e.editor}
    </section>
  `}var zs;function Bs(){return(Bs=e((()=>{n(),A(),E(),Ji(),V(),C(),_a(),Os(),Ss(),zs=``})))()}function Vs(e){return e?.configRevisionHash??e?.hash??null}function Hs(e){return{id:e.id,label:e.label,configured:e.configured,aliases:e.aliases??[],models:e.models??[],voices:e.voices??[],activeVoices:e.activeVoices,activeVoiceSelectionPolicy:e.activeVoiceSelectionPolicy,voicesByModel:e.voicesByModel,transports:e.transports??[],defaultModel:e.defaultModel??null}}function Us(e,t){return bs(e)&&t===`provider-websocket`}function Ws(e){let t=qs.get(e);return t||(t=new Js(e),qs.set(e,t)),t}function Gs(e){return O`
    <openclaw-talk-settings
      .configObject=${e.configObject}
      .mutationDisabled=${e.mutationDisabled}
      .buildEditor=${e.buildEditor}
    ></openclaw-talk-settings>
  `}var Ks,qs,Js,Ys;function Xs(){return(Xs=e((()=>{i(),A(),M(),kn(),C(),qn(),dt(),ct(),Ss(),Bs(),Ks=new Set([`webrtc`,`provider-websocket`]),qs=new WeakMap,Js=class{constructor(e){this.gateway=e,this.value={kind:`unavailable`},this.connection=null,this.voiceWakeWrite=null,this.listeners=new Set,e.subscribe(()=>this.sync())}get state(){return this.value}update(e){this.value=e;for(let e of this.listeners)e()}subscribe(e){this.listeners.add(e),this.sync();let t=this.connection;return t?.connected&&t.voiceWake&&this.state.kind!==`loading`&&(this.state.kind!==`ready`||this.state.phase===`saved`)&&this.loadVoiceWake(t),()=>{this.listeners.delete(e)}}flush(){this.voiceWakeTimer!==void 0&&(clearTimeout(this.voiceWakeTimer),this.voiceWakeTimer=void 0,this.saveVoiceWake())}retry(){this.state.kind===`ready`?this.saveVoiceWake():this.connection&&this.loadVoiceWake(this.connection)}sync(){let e=this.gateway.snapshot,t=this.gateway.connection.gatewayUrl,n=e.client,r=e.phase===`connected`,i=Kn(e,`voicewake.get`)===!0&&Kn(e,`voicewake.set`)===!0;if(this.connection?.gatewayUrl===t&&this.connection.client===n&&this.connection.connected===r&&this.connection.voiceWake===i)return;clearTimeout(this.voiceWakeTimer),this.voiceWakeTimer=void 0,this.voiceWakeWrite&&=(this.voiceWakeWrite.next=null,null);let a=this.connection?.gatewayUrl===t&&this.state.kind===`ready`&&this.state.phase!==`saved`?this.state:null,o={gatewayUrl:t,client:n,connected:r,voiceWake:i};this.connection=o,this.update(a?{...a,phase:`pending`,error:S(`configPage.deviceTalk.triggerWordsDisconnected`)}:{kind:`unavailable`}),n&&r&&i&&!a&&this.listeners.size>0&&this.loadVoiceWake(o)}async loadVoiceWake(e){if(e.client&&e.voiceWake){this.update({kind:`loading`});try{let t=await e.client.request(`voicewake.get`,{});this.connection===e&&this.update({kind:`ready`,text:t.triggers.join(`
`),phase:`saved`,error:null})}catch(t){this.connection===e&&this.update({kind:`error`,error:S(`configPage.deviceTalk.triggerWordsLoadError`,{error:String(t)})})}}}edit(e){if(this.state.kind!==`ready`)return;this.update({kind:`ready`,text:e,phase:`pending`,error:null});let t=this.voiceWakeWrite;t?.connection===this.connection&&t.next!==null&&(t.next=e===t.text?null:e),clearTimeout(this.voiceWakeTimer),this.voiceWakeTimer=setTimeout(()=>{this.voiceWakeTimer=void 0,this.saveVoiceWake()},400)}async saveVoiceWake(){let e=this.connection,t=this.state;if(t.kind!==`ready`||t.phase===`saved`)return;if(!e?.client||!e.connected||!e.voiceWake){this.update({...t,phase:`pending`,error:S(`configPage.deviceTalk.triggerWordsDisconnected`)});return}if(this.voiceWakeWrite?.connection===e){this.voiceWakeWrite.next=t.text===this.voiceWakeWrite.text?null:t.text;return}let n={connection:e,text:t.text,next:t.text};for(this.voiceWakeWrite=n;n.next!==null;){n.text=n.next,n.next=null;let t=this.state;this.connection===e&&t.kind===`ready`&&t.text===n.text&&this.update({...t,phase:`saving`,error:null});try{let t=await e.client.request(`voicewake.set`,{triggers:n.text.split(`
`)});this.connection===e&&this.state.kind===`ready`&&this.state.text===n.text&&this.update({kind:`ready`,text:t.triggers.join(`
`),phase:`saved`,error:null})}catch(t){this.connection===e&&this.state.kind===`ready`&&this.update({...this.state,phase:`pending`,error:S(`configPage.deviceTalk.triggerWordsError`,{error:String(t)})})}}this.voiceWakeWrite===n&&(this.voiceWakeWrite=null)}},Ys=class extends yt{constructor(...e){super(...e),this.configObject={},this.mutationDisabled=!1,this.buildEditor=()=>O``,this.catalog={kind:`unavailable`},this.modelDefaultResetIntent=null,this.connection=null,this.catalogRequestId=0,this.subscriptions=new vt(this).watch(()=>this.context?.gateway?Ws(this.context.gateway):void 0,(e,t)=>e.subscribe(t)).watch(()=>this.context?.nativeDeviceSettings,(e,t)=>e.subscribe(t)).watch(()=>this.context?.gateway,(e,t)=>e.subscribe(t),e=>this.syncCatalog(e.connection.gatewayUrl,e.snapshot.client,e.snapshot.phase===`connected`,Kn(e.snapshot,`voicewake.get`)===!0&&Kn(e.snapshot,`voicewake.set`)===!0)).watch(()=>this.context?.runtimeConfig,(e,t)=>e.subscribe(t),e=>this.refreshCatalogOnConfigChange(e.state)),this.refreshOnFocus=()=>{let e=this.connection;e?.client&&e.connected&&this.loadCatalog(e.client,e)}}connectedCallback(){super.connectedCallback(),window.addEventListener(`focus`,this.refreshOnFocus)}disconnectedCallback(){window.removeEventListener(`focus`,this.refreshOnFocus),Ws(this.context.gateway).flush(),this.subscriptions.clear(),this.connection=null,this.catalog={kind:`unavailable`},super.disconnectedCallback()}syncCatalog(e,t,n,r){if(this.modelDefaultResetIntent&&this.modelDefaultResetIntent.gatewayUrl!==e&&(this.modelDefaultResetIntent=null),this.connection?.gatewayUrl===e&&this.connection.client===t&&this.connection.connected===n&&this.connection.voiceWake===r)return;let i={gatewayUrl:e,client:t,connected:n,voiceWake:r};if(this.connection=i,!t||!n){this.catalog={kind:`unavailable`};return}this.catalog={kind:`loading`},this.loadCatalog(t,i)}async loadCatalog(e,t){let n=++this.catalogRequestId;try{let r=await e.request(`talk.catalog`,{});this.applyCatalog(t,n,{kind:`ready`,ready:r.realtime.ready===!0,activeProvider:r.realtime.activeProvider??null,providers:r.realtime.providers.map(Hs)})&&this.acknowledgeModelDefaultReset(t)}catch{this.applyCatalog(t,n,{kind:`unavailable`})}}applyCatalog(e,t,n){return!this.isConnected||this.connection!==e||this.catalogRequestId!==t?!1:(this.catalog=n,!0)}acknowledgeModelDefaultReset(e){let t=this.modelDefaultResetIntent,n=this.lastCatalogConfigRevision;n!=null&&t?.gatewayUrl===e.gatewayUrl&&t.configRevision!==n&&(this.modelDefaultResetIntent=null)}refreshCatalogOnConfigChange(e){let t=Vs(e.configSnapshot);if(this.lastCatalogConfigRevision===void 0){this.lastCatalogConfigRevision=t;return}if(t===null||t===this.lastCatalogConfigRevision)return;this.lastCatalogConfigRevision=t;let n=this.connection;n?.client&&n.connected&&this.loadCatalog(n.client,n)}changeModel(e){if(this.mutationDisabled)return;let t=this.context.runtimeConfig;if(e!==null){this.modelDefaultResetIntent=null,t.patchForm([`talk`,`realtime`,`model`],e);let n=this.liveSelection(),r=n.transport,i=As(this.catalog,n),a=r!==null&&(Us(e,r)||xs(i?.transports,r));bs(e)&&a?t.removeFormValue([`talk`,`realtime`,`transport`]):i?.id===`openai`&&bs(e)&&r===`gateway-relay`&&n.consultRouting===`force-agent-consult`&&t.removeFormValue([`talk`,`realtime`,`consultRouting`]);return}this.modelDefaultResetIntent={gatewayUrl:this.context.gateway.connection.gatewayUrl,configRevision:Vs(t.state.configSnapshot)},t.removeFormValue([`talk`,`realtime`,`model`]);for(let e of this.selectedProviderConfigKeys())t.removeFormValue([`talk`,`realtime`,`providers`,e,`model`])}changeVoice(e){if(this.mutationDisabled)return;let t=this.context.runtimeConfig;if(e!==null){t.patchForm([`talk`,`realtime`,`speakerVoice`],e);return}t.removeFormValue([`talk`,`realtime`,`speakerVoice`]),t.removeFormValue([`talk`,`realtime`,`speakerVoiceId`]);for(let e of this.selectedProviderConfigKeys())t.removeFormValue([`talk`,`realtime`,`providers`,e,`speakerVoice`]),t.removeFormValue([`talk`,`realtime`,`providers`,e,`voice`])}selectedProviderConfigKeys(){let e=this.liveSelection();return js(e,As(this.catalog,e))}liveSelection(){let e=this.context.runtimeConfig.state.configForm;return ys(e??this.configObject)}changeProvider(e){if(this.mutationDisabled)return;this.modelDefaultResetIntent=null;let t=this.context.runtimeConfig,n=this.liveSelection();for(let e of[`model`,`speakerVoice`,`speakerVoiceId`])t.removeFormValue([`talk`,`realtime`,e]);if(e===null){t.removeFormValue([`talk`,`realtime`,`provider`]);return}let r=n.transport,i=this.catalog.kind===`ready`?this.catalog.providers.find(t=>t.id===e):void 0,a=Ms({...n,provider:e,model:null,speakerVoice:null},i).model??i?.defaultModel,o=r!==null&&(Us(a??null,r)||xs(i?.transports,r));o&&t.removeFormValue([`talk`,`realtime`,`transport`]),t.patchForm([`talk`,`realtime`,`provider`],e);let s=i!==void 0&&i.transports.length>0&&!i.transports.some(e=>Ks.has(e)),c=o?null:r;s&&r!==`gateway-relay`&&(t.patchForm([`talk`,`realtime`,`transport`],`gateway-relay`),c=`gateway-relay`),i?.id===`openai`&&bs(a??null)&&c===`gateway-relay`&&n.consultRouting===`force-agent-consult`&&t.removeFormValue([`talk`,`realtime`,`consultRouting`])}render(){let e=this.context.runtimeConfig.state,t=Ws(this.context.gateway);return Rs({nativeDeviceSettings:this.context.nativeDeviceSettings,voiceWake:{state:t.state,onInput:e=>t.edit(e),onRetry:()=>t.retry()},selection:ys(this.configObject),catalog:this.catalog,modelDefaultPending:this.modelDefaultResetIntent!==null,configBusy:this.mutationDisabled||e.configLoading||e.configSaving||e.configApplying,onProviderChange:e=>this.changeProvider(e),onModelChange:e=>this.changeModel(e),onVoiceChange:e=>this.changeVoice(e),editor:this.buildEditor()})}},b([Ve({context:Cn,subscribe:!0})],Ys.prototype,`context`,void 0),b([N({attribute:!1})],Ys.prototype,`configObject`,void 0),b([N({type:Boolean})],Ys.prototype,`mutationDisabled`,void 0),b([N({attribute:!1})],Ys.prototype,`buildEditor`,void 0),b([j()],Ys.prototype,`catalog`,void 0),b([j()],Ys.prototype,`modelDefaultResetIntent`,void 0),customElements.get(`openclaw-talk-settings`)||customElements.define(`openclaw-talk-settings`,Ys)})))()}function Zs(e){let t=e?.snapshot,n=t?.updates;return!e||!t||!n?k:I({title:S(zt(t))},[B({title:S(`updates.device.version`),control:R(S(`updates.device.versionBuild`,{version:t.device.appVersion,build:t.device.appBuild}))}),n.available?O`${L({title:S(`updates.device.automatic`),checked:n.automatic,onChange:t=>e.set(`updates.automatic`,t)})}${B({title:S(`updates.device.check`),control:O`<button
            class="btn btn--sm"
            type="button"
            @click=${()=>e.checkForUpdates()}
          >
            ${S(`updates.device.check`)}
          </button>`})}`:B({title:S(`updates.device.unavailable`),description:n.unavailableReason})])}function Qs(e){let t=e.update.updateRun;if(!t&&!e.update.updateStatusBanner)return k;let n=t?!Ee(t)&&ge(t):!e.update.recordedUpdateAttempt||Le(e.update.recordedUpdateAttempt)!==`noop`,r=e.update.updateStatusBanner?.source===`read`,i=e.canUpdate&&!e.updateBusy&&!e.update.updateStatusRefreshing;return I({title:S(`updates.page.latestAttempt`)},[t?O`<div class="settings-row settings-row--stacked">
          <openclaw-update-run-view
            .run=${t}
            .connected=${e.connected}
          ></openclaw-update-run-view>
        </div>`:e.update.updateStatusBanner&&!e.updateBusy&&(e.update.updateStatusRefreshing||e.update.updateStatusCheckBanner)?B({title:S(`updates.page.failedStep`),description:e.update.updateStatusBanner.text}):k,...!n&&!r?[]:[B({title:S(`updates.page.recoveryActions`),control:O`<div class="updates-status-control">
              <button
                class="btn btn--sm"
                type="button"
                title=${e.canCheckStatus?``:S(`updates.adminRequired`)}
                ?disabled=${!e.canCheckStatus||e.updateBusy||e.update.updateStatusRefreshing}
                @click=${()=>void e.onCheckStatus()}
              >
                ${S(`updates.page.checkStatus`)}
              </button>
              ${e.update.diagnosableUpdateFailureId?O`<button
                      class="btn btn--sm"
                      type="button"
                      title=${e.canDiagnose?``:S(`updates.adminRequired`)}
                      ?disabled=${!e.canDiagnose||e.updateBusy||e.update.updateStatusRefreshing||e.update.updateFailureReportBusy}
                      @click=${()=>e.onDiagnoseFailure(e.update.diagnosableUpdateFailureId)}
                    >
                      ${S(`updates.page.diagnoseFailure`)}
                    </button>`:k}
              ${n?O`<button
                      class="btn btn--sm primary"
                      type="button"
                      title=${i?``:S(`updates.adminRequired`)}
                      ?disabled=${!i}
                      @click=${e.onUpdateNow}
                    >
                      ${S(`updates.page.retryUpdate`)}
                    </button>`:k}
              ${n&&e.update.reportableUpdateFailureId?O`<button
                      class="btn btn--sm"
                      type="button"
                      title=${e.canReport?``:S(`updates.page.reportOwnerRequired`)}
                      ?disabled=${!e.canReport||e.updateBusy||e.update.updateStatusRefreshing||e.update.updateFailureReportBusy}
                      @click=${()=>void e.onReportFailure(e.update.reportableUpdateFailureId)}
                    >
                      ${e.update.updateFailureReportBusy?S(`updates.page.reportSubmitting`):S(`updates.page.reportFailure`)}
                    </button>`:k}
            </div>`}),n&&t?.target.installationMethod!==`ocm`?B({title:S(`updates.page.cliFallback`),description:S(`updates.triage.hostHint`),stacked:!0,control:O`<details class="updates-attempt-details">
                  <summary>${S(`updates.page.showCliFallback`)}</summary>
                  <pre><code>openclaw triage</code></pre>
                </details>`}):k],e.update.updateFailureReportNotice?$s(e.update.updateFailureReportNotice):k])}function $s(e){let t=e.result,n=t.status===`created`?S(`updates.page.reportCreated`):t.status===`fallback`?S(`updates.page.reportFallback`):t.status===`pending`?S(`updates.page.reportPending`):t.status===`retryable`?S(`updates.page.reportRetryable`):t.status===`duplicate`?S(`updates.page.reportDuplicate`):S(`updates.page.reportError`),r=`url`in t&&t.url?t.url:null,i=`fallbackUrl`in t&&t.fallbackUrl?t.fallbackUrl:null;return B({title:S(`updates.page.reportResult`),stacked:!0,control:O`<div class="updates-attempt-details" role="status">
      <div>${n}</div>
      ${r?O`<div>
              <a href=${r} target="_blank" rel="noreferrer">${S(`updates.page.openIssue`)}</a>
            </div>`:k}
      ${i?O`<div>
              <a href=${i} target="_blank" rel="noreferrer"
                >${S(`updates.page.openPrefilledIssue`)}</a
              >
            </div>`:k}
      ${`message`in t&&t.message?O`<div>${t.message}</div>`:k}
    </div>`})}function ec(e,t){let n=v(e.update),r=v(n?.auto),i=cc.find(e=>e===n?.channel)??cc.find(e=>e===t?.channel)??`stable`;return{channel:i,autoEnabled:typeof r?.enabled==`boolean`?r.enabled:t?.autoEnabled??!1,extendedStable:i===`extended-stable`}}function tc(e){return ve(e)??null}function nc(e,t=Date.now()){let n=Je(Math.max(0,t-e));return R(O`<time datetime=${new Date(e).toISOString()} title=${n}
      >${He(e,{dateStyle:`medium`,timeStyle:`short`})}
      <span class="muted">· ${n}</span></time
    >`)}function rc(e){let t=e.update.updateSchedule?.install?.kind,n=e.update.updateSchedule?.install?.git,r=tc(e.controlUiBuiltAt),i=n?.commitAtMs??tc(e.controlUiCommitAt);return I({title:S(`updates.page.buildTitle`)},[B({title:S(`updates.page.gatewayVersion`),control:R(e.gatewayVersion?O`<code dir="ltr" title=${e.gatewayVersion}>${e.gatewayVersion}</code>`:S(`common.na`),{mono:!0})}),B({title:S(`updates.page.controlUiCommit`),control:R(e.controlUiCommit?O`<code dir="ltr" title=${e.controlUiCommit}
              >${e.controlUiCommit.slice(0,12)}</code
            >`:S(`common.na`),{mono:!0})}),r===null?k:B({title:S(`updates.page.builtAt`),control:nc(r,e.nowMs)}),t===`git`?B({title:S(`updates.page.installedAt`),control:n?.installedAtMs===void 0?R(S(`updates.page.installedAtUnknown`)):nc(n.installedAtMs,e.nowMs)}):k,i===null?k:B({title:S(`updates.page.lastCommitAt`),control:nc(i,e.nowMs)}),t?B({title:S(`updates.page.installKind`),control:R(S(`updates.installKind.${t}`))}):k])}function ic(e){let t=e.update.updateRun,n=t?.status===`running`,r=e.update.updateSchedule?.campaign,i=dn(e.update.updateSchedule,e.nowMs),a=bn(e.update.updateSchedule,e.update.updateAvailable),o=`muted`,s;if(n)o=`accent`,s=S(`updates.page.activePhase`,{phase:S(`updates.run.phase.${t.phase}`)});else if(e.update.updateStatusRefreshing&&!e.updateBusy)s=S(`updates.page.checking`);else if(e.update.updateStatusCheckBanner&&!e.updateBusy)o=`warn`,s=e.update.updateStatusCheckBanner.text;else if(i)o=r?.state===`waiting-for-idle`?`warn`:`accent`,s=i;else if(e.update.updateStatusBanner)o=e.update.updateStatusBanner.tone===`danger`?`danger`:e.update.updateStatusBanner.tone===`warn`?`warn`:`accent`,s=e.update.updateStatusBanner.text;else if(e.update.updateSchedule?.install?.kind===`git`){let t=e.update.updateSchedule.install.git;if(!t)s=S(`updates.page.statusUnavailable`);else if(t.status===`current`)o=`ok`,s=S(`updates.page.upToDate`);else if(t.status===`behind`){o=`accent`;let e=S(t.commitsBehind===1?`updates.target.commitBehind`:`updates.target.commitsBehind`,{count:String(t.commitsBehind)});s=S(`updates.page.available`,{target:e})}else t.status===`ahead`?s=S(t.commitsAhead===1?`updates.page.gitCommitAhead`:`updates.page.gitCommitsAhead`,{count:String(t.commitsAhead)}):t.status===`diverged`?(o=`warn`,s=S(`updates.page.gitDiverged`,{ahead:String(t.commitsAhead),behind:String(t.commitsBehind)})):(o=`warn`,s=t.reason===`fetch-failed`?S(`updates.page.gitFetchFailed`):t.reason===`no-upstream`?S(`updates.page.gitNoUpstream`):S(`updates.page.gitComparisonFailed`))}else a?(o=`accent`,s=S(`updates.page.available`,{target:a})):e.update.updateSchedule?.install?.kind===`package`?(o=`ok`,s=S(`updates.page.upToDate`)):s=S(`updates.page.statusUnavailable`);let c=e.update.updateStatusCheckBanner&&!e.update.updateStatusRefreshing&&!e.updateBusy,l=!n&&(r?.state===`waiting-for-idle`||r?.state===`countdown`);return O`<span
    class=${c?`updates-status-check-failed`:k}
    role=${l?`timer`:k}
    aria-live=${l?`off`:k}
    >${z({kind:o,label:s,dot:!1})}</span
  >`}function ac(e){let t=e.update.updateAvailable,n=qt(e.update.updateSchedule,t);return n&&n.commitsBehind===t?.commitsBehind&&n.currentSha===t?.currentSha&&n.upstreamSha===t?.upstreamSha?t?.commits??[]:[]}function oc(e){let t=ac(e);return t.length===0?k:B({title:S(`updates.page.commits`),stacked:!0,control:O`
      <div class="updates-commit-list" role="list" aria-label=${S(`updates.page.commits`)}>
        ${t.map(e=>O`
            <div class="updates-commit-list__row" role="listitem">
              <code title=${e.sha}>${e.sha}</code>
              <span>${e.subject}</span>
            </div>
          `)}
      </div>
    `})}function sc(e){let t=e.update.updateRun?.status===`running`?e.update.updateRun:null,n=t?.steps.findLast(e=>e.status===`in_progress`&&e.step!==t.phase&&!e.step.startsWith(`notice:`)),r=t?.target.sha??t?.target.version??t?.target.tag,i=ec(e.configObject,e.update.updateSchedule),a=[{value:`stable`,label:S(`updates.channel.stable`)},{value:`beta`,label:S(`updates.channel.beta`)},{value:`dev`,label:S(`updates.channel.dev`)}];i.extendedStable&&a.push({value:`extended-stable`,label:S(`updates.channel.extendedStable`)});let o=i.channel!==`extended-stable`,s=v(e.configObject.update)?.checkOnStart===!1,c=i.channel===`dev`&&e.update.updateSchedule?.install?.kind===`package`,l=e.update.updateSchedule?.campaign,u=t&&l&&t.origin.campaignId!==l.id,d=l?.holdUntilMs!==void 0&&l.holdUntilMs>(e.nowMs??Date.now()),ee=!!(!t&&l&&l.state!==`applying`&&e.canUpdate&&e.canHoldUpdate&&!d&&e.update.heldUpdateCampaignId!==l.id),f=[B({title:S(`updates.page.channel`),description:S(`updates.page.channelDescription`),stacked:!0,control:Ur({value:i.channel,options:a,ariaLabel:S(`updates.page.channel`),disabled:e.configBusy,onChange:e.onChannelChange})}),L({title:S(`updates.page.checkForUpdates`),description:S(`updates.page.checkForUpdatesDescription`),checked:!s,disabled:e.configBusy,onChange:e.onUpdateChecksChange}),L({title:S(`updates.page.automaticUpdates`),description:S(o?c?`updates.page.devPackageAutomaticHint`:s?`updates.page.checksDisabledAutomaticHint`:`updates.page.automaticUpdatesDescription`:`updates.page.extendedStableAutomaticHint`),checked:o&&i.autoEnabled,disabled:e.configBusy||s||!o||c,onChange:e.onAutomaticUpdatesChange})],p=!(!e.update.updateStatusCheckBanner||mn(e.update.updateAvailable,e.update.updateSchedule,e.updateBusy)||e.update.updateSchedule?.target?.kind===`package`||e.update.updateSchedule?.install?.git?.status===`behind`||e.update.updateSchedule?.install?.git?.status===`diverged`),m=e.update.updateStatusRefreshing&&!e.updateBusy?S(`updates.page.checking`):e.canAdmin?p?S(`updates.page.checkRequired`):``:S(`updates.adminRequired`);return O`
    <div id="config-section-update">
      ${jr([Zs(e.nativeDeviceSettings),e.canAdmin?k:O`<div class="callout warning" role="note">${S(`updates.adminRequired`)}</div>`,rc(e),Qs(e),I({title:S(`updates.page.policyTitle`)},f),I({title:S(`updates.page.statusTitle`)},[B({title:S(`updates.page.scheduleStatus`),description:t&&e.update.updateStatusBanner?.source===`read`?e.update.updateStatusBanner.text:void 0,control:O`
              <div class="updates-status-control">
                <div>
                  ${ic(e)}
                  ${!t&&!e.update.updateStatusRefreshing?Er(e.update.updateSchedule,e.update.updateAvailable):k}
                </div>
                ${e.update.updateStatusCheckBanner?O`
                        <button
                          type="button"
                          class="btn btn--sm"
                          title=${e.update.updateStatusRefreshing?S(`updates.page.checking`):e.canCheckStatus?``:S(`updates.adminRequired`)}
                          ?disabled=${!e.canCheckStatus||e.update.updateStatusRefreshing||e.updateBusy}
                          @click=${()=>void e.onCheckStatus()}
                        >
                          ${S(`updates.page.checkForUpdates`)}
                        </button>
                      `:k}
                ${ee?O`
                        <button
                          type="button"
                          class="btn btn--sm"
                          ?disabled=${e.updateBusy||e.update.updateStatusRefreshing}
                          @click=${()=>void e.onHoldUpdate()}
                        >
                          ${S(`updates.holdOneHour`)}
                        </button>
                      `:k}
              </div>
            `}),n?B({title:S(`updates.page.currentStep`),control:R(n.step)}):k,r?B({title:S(`updates.page.runTarget`),control:R(O`<code dir="ltr" title=${r}
                    >${t?.target.sha?r.slice(0,12):r}</code
                  >`)}):k,t?B({title:S(`updates.page.lastProgress`),control:nc(t.updatedAtMs,e.nowMs)}):k,u?B({title:S(`updates.page.scheduledUpdate`),control:O`<div>
                  <span role="timer" aria-live="off"
                    >${dn(e.update.updateSchedule,e.nowMs)}</span
                  >
                  ${Er(e.update.updateSchedule,e.update.updateAvailable)}
                </div>`}):k,t?k:oc(e),B({title:S(`updates.page.updateNow`),description:S(`updates.page.updateNowDescription`),control:O`
              <button
                type="button"
                class="btn primary"
                title=${m}
                ?disabled=${e.updateBusy||e.update.updateStatusRefreshing||!e.canUpdate||p}
                @click=${e.onUpdateNow}
              >
                ${w.download}
                ${e.updateBusy?S(`updates.page.updating`):S(`updates.page.updateNow`)}
              </button>
            `})]),O`<p class="settings-page__hint">
          <a href="https://docs.openclaw.ai/install/update-troubleshooting" target="_blank"
            >${S(`updates.page.troubleshoot`)}</a
          >
        </p>`])}
    </div>
  `}var cc;function lc(){return(lc=e((()=>{be(),A(),ke(),pe(),oi(),Sn(),gn(),Lt(),V(),Wr(),C(),G(),Ze(),W(),cc=[`stable`,`beta`,`dev`,`extended-stable`]})))()}function uc({context:e,configObject:t,configBusy:n,updateBusy:r}){let i=e.runtimeConfig,a=e.gateway.snapshot,o=e.overlays.snapshot,s=Yt(a.hello?.auth??null);return sc({update:o,nativeDeviceSettings:e.nativeDeviceSettings,configObject:t,gatewayVersion:e.config.current.serverVersion??a.hello?.server?.version??null,controlUiCommit:Pt.commit,controlUiCommitAt:Pt.commitAt,controlUiBuiltAt:Pt.builtAt,connected:a.phase===`connected`,configBusy:n,canAdmin:s,canUpdate:P(a,`update.run`,`operator.admin`),canCheckStatus:P(a,`update.status`,`operator.admin`),canHoldUpdate:P(a,`update.hold`,`operator.admin`),canReport:an(a),canDiagnose:P(a,`openclaw.chat`,`operator.admin`),updateBusy:r,onChannelChange:e=>i.patchForm([`update`,`channel`],e),onUpdateChecksChange:e=>i.patchForm([`update`,`checkOnStart`],e),onAutomaticUpdatesChange:e=>i.patchForm([`update`,`auto`,`enabled`],e),onUpdateNow:()=>void un({startGatewayUpdate:()=>void e.overlays.runUpdate(),watchUpdateProgress:vn(e),onCheckStatus:()=>e.overlays.refreshUpdateStatus(),onAcknowledge:()=>e.overlays.acknowledgeUpdateRun(),updateAvailable:o.updateAvailable,updateSchedule:o.updateSchedule,viaNativeApp:!1}),onHoldUpdate:()=>e.overlays.holdUpdate(),onCheckStatus:()=>e.overlays.refreshUpdateStatus(),onReportFailure:t=>e.overlays.reportUpdateFailure(t),onDiagnoseFailure:t=>e.overlays.diagnoseUpdateFailure(t)})}function dc(){return(dc=e((()=>{Bt(),Kt(),en(),Nt(),qn(),lc()})))()}function fc(e){return`${String(Math.floor(e/60)).padStart(2,`0`)}:${String(e%60).padStart(2,`0`)}`}function pc(e,t){let n=/^(\d{2}):(\d{2})$/u.exec(e);return n?Number(n[1])*60+Number(n[2]):t}function mc(e){return e.currentTarget}function hc(e){return e===`identified`||e===`detailed`?e:`private`}function gc(){return[{value:`private`,label:S(`configView.notifications.private`)},{value:`identified`,label:S(`configView.notifications.namesOnly`)},{value:`detailed`,label:S(`configView.notifications.detailed`)}]}function _c(e){return[{value:`inherit`,label:e},{value:`on`,label:S(`configForm.enumOn`)},{value:`off`,label:S(`configForm.enumOff`)}]}function vc(e,t){return O`
    ${B({title:S(`configView.notifications.quietHoursWindow`),control:O`
        <input
          type="time"
          class="settings-input"
          aria-label=${S(`configView.notifications.quietHoursStart`)}
          .value=${fc(e.startMinute)}
          @change=${n=>t({...e,startMinute:pc(mc(n).value,e.startMinute)})}
        />
        <span class="settings-row__value" aria-hidden="true">–</span>
        <input
          type="time"
          class="settings-input"
          aria-label=${S(`configView.notifications.quietHoursEnd`)}
          .value=${fc(e.endMinute)}
          @change=${n=>t({...e,endMinute:pc(mc(n).value,e.endMinute)})}
        />
      `})}
    ${B({title:S(`configView.notifications.timeZone`),control:O`<input
        type="text"
        class="settings-input"
        aria-label=${S(`configView.notifications.timeZone`)}
        .value=${e.timeZone}
        @change=${n=>t({...e,timeZone:mc(n).value})}
      />`})}
  `}function yc(e,t){return B({title:S(`configView.notifications.onlyAgents`),control:O`<input
      type="text"
      class="settings-input"
      aria-label=${S(`configView.notifications.onlyAgents`)}
      .value=${e.join(`, `)}
      @change=${e=>t(mc(e).value.split(`,`).map(e=>e.trim()).filter(Boolean))}
    />`})}function bc(e,t){let n=n=>t({...e,...n});return O`
    <section class="settings-section">
      <div class="settings-section__header">
        <h2 class="settings-section__heading">${S(`configView.notifications.accountDefaults`)}</h2>
      </div>
      <div class="settings-group">
        ${wc.map(([t,r])=>L({title:r(),checked:e.categories[t]===!0,onChange:r=>n({categories:{...e.categories,[t]:r}})}))}
        ${K({title:S(`configView.notifications.lockScreenDetail`),description:S(`configView.notifications.lockScreenDetailHint`),value:e.detailLevel,options:gc(),onChange:e=>n({detailLevel:hc(e)})})}
        ${L({title:S(`configView.notifications.quietHours`),checked:e.quietHours.enabled,onChange:t=>n({quietHours:{...e.quietHours,enabled:t}})})}
        ${e.quietHours.enabled?vc(e.quietHours,e=>n({quietHours:e})):k}
        ${yc(e.agentIds,e=>n({agentIds:e}))}
      </div>
    </section>
  `}function xc(e,t){let n=n=>t({...e,...n}),r=e.quietHours;return O`
    <section class="settings-section">
      <div class="settings-section__header">
        <h2 class="settings-section__heading">${S(`configView.notifications.installedApp`)}</h2>
      </div>
      <div class="settings-group">
        ${L({title:S(`configView.notifications.deliverDevice`),checked:e.enabled,onChange:e=>n({enabled:e})})}
        ${B({title:S(`configView.notifications.notificationLabel`),control:O`<input
            type="text"
            class="settings-input"
            aria-label=${S(`configView.notifications.notificationLabel`)}
            maxlength="80"
            .value=${e.label}
            @change=${e=>n({label:mc(e).value})}
          />`})}
        ${K({title:S(`configView.notifications.lockScreenDetail`),value:e.detailLevel??`inherit`,options:[{value:`inherit`,label:S(`configView.notifications.inheritDetail`)},...gc()],onChange:e=>n({detailLevel:e===`inherit`?void 0:hc(e)})})}
        ${K({title:S(`configView.notifications.quietHours`),value:r===void 0?`inherit`:r.enabled?`on`:`off`,options:_c(S(`configView.notifications.inheritQuietHours`)),onChange:e=>n({quietHours:e===`inherit`?void 0:{enabled:e===`on`,startMinute:r?.startMinute??1320,endMinute:r?.endMinute??420,timeZone:r?.timeZone??`UTC`}})})}
        ${r?.enabled?vc(r,e=>n({quietHours:e})):k}
        ${K({title:S(`configView.notifications.onlyAgents`),value:e.agentIds===void 0?`inherit`:`override`,options:[{value:`inherit`,label:S(`configView.notifications.inherit`)},{value:`override`,label:S(`configView.notifications.overrideAgents`)}],onChange:e=>n({agentIds:e===`inherit`?void 0:[]})})}
        ${e.agentIds===void 0?k:yc(e.agentIds,e=>n({agentIds:e}))}
        ${wc.map(([t,r])=>K({title:r(),value:e.categories?.[t]===void 0?`inherit`:e.categories[t]?`on`:`off`,options:_c(S(`configView.notifications.inherit`)),onChange:r=>{let i={...e.categories};r===`inherit`?delete i[t]:i[t]=r===`on`,n({categories:i})}}))}
      </div>
    </section>
  `}function Sc(e){switch(e){case`granted`:return{kind:`ok`,label:S(`configView.notifications.granted`)};case`denied`:return{kind:`danger`,label:S(`configView.notifications.denied`)};case`notDetermined`:return{kind:`accent`,label:S(`configView.notifications.notRequested`)};default:return{kind:`muted`,label:S(`configView.notifications.checking`)}}}function Cc(e){let t=e.nativeNotifications;if(t){let n=Sc(t.permission),r=t.test?.state===`pending`,i=t.permission===`notDetermined`?O`
            <button
              class="btn primary"
              @click=${()=>e.onNativeNotificationsRequestPermission?.()}
            >
              ${S(`configView.notifications.enable`)}
            </button>
          `:t.permission===`denied`?O`
              <button class="btn" @click=${()=>e.onNativeNotificationsRequestPermission?.()}>
                ${S(`configView.notifications.openSystemSettings`)}
              </button>
            `:t.permission===`granted`?O`
                <button
                  class="btn primary"
                  ?disabled=${r}
                  @click=${()=>e.onNativeNotificationsSendTest?.()}
                >
                  ${r?w.loader:w.send}
                  ${S(r?`configView.notifications.sendingTest`:`configView.notifications.sendTest`)}
                </button>
              `:k;return O`
      <div class="settings-page" ${D({settingsPage:!0})}>
        <section class="settings-section" id=${wi.notifications}>
          <div class="settings-section__header">
            <h2 class="settings-section__heading">${S(`configView.notifications.nativeTitle`)}</h2>
            <div class="settings-section__actions">${z(n)}</div>
          </div>
          <div class="settings-group">
            ${B({title:S(`configView.notifications.permission`),control:R(n.label)})}
            ${i===k?k:O`
                    <div class="settings-row">
                      <div class="settings-row__control">${i}</div>
                    </div>
                  `}
            ${t.permission===`denied`?B({title:S(`configView.notifications.blocked`),description:S(`configView.notifications.nativeBlockedHint`),control:z({kind:`danger`,label:S(`configView.notifications.denied`)})}):k}
            ${t.test?B({title:S(`configView.notifications.testOutcome`),description:t.test.state===`error`?t.test.message:void 0,control:z(t.test.state===`pending`?{kind:`accent`,label:S(`configView.notifications.sendingTest`)}:t.test.state===`sent`?{kind:`ok`,label:S(`configView.notifications.testQueued`)}:{kind:`danger`,label:S(`configView.notifications.testFailed`)})}):k}
          </div>
        </section>
      </div>
    `}let n=e.webPush;if(!n)return O`
      <div class="settings-page" ${D({settingsPage:!0})}>
        <section class="settings-section" id=${wi.notifications}>
          <div class="settings-section__header">
            <h2 class="settings-section__heading">${S(`configView.notifications.title`)}</h2>
            <div class="settings-section__actions">
              ${z({kind:`muted`,label:S(`configView.notifications.unavailable`)})}
            </div>
          </div>
          <div class="settings-group">
            <div class="settings-row">
              <div class="settings-row__text">
                <span class="settings-row__desc">
                  ${S(`configView.notifications.unavailableHint`)}
                </span>
              </div>
            </div>
          </div>
        </section>
      </div>
    `;let r=n.permission===`granted`?S(`configView.notifications.granted`):n.permission===`denied`?S(`configView.notifications.denied`):n.permission==="default"?S(`configView.notifications.notRequested`):S(`configView.notifications.unsupported`),i=n.subscription===`registered`,a=i||n.subscription===`vapid-mismatch`,o=i?S(`configView.notifications.subscribed`):n.subscription===`unknown`?S(`configView.notifications.checking`):S(`configView.notifications.notSubscribed`),s=n.supported?n.permission===`denied`?S(`configView.notifications.blocked`):i?S(`configView.notifications.subscribed`):n.subscription===`vapid-mismatch`?S(`configView.notifications.unavailable`):n.subscription===`unknown`?S(`configView.notifications.checking`):S(`configView.notifications.ready`):S(`configView.notifications.unsupported`),c=n.supported?n.permission===`denied`||n.subscription===`vapid-mismatch`?`danger`:i?`ok`:`accent`:`muted`,l=n.supported&&n.permission!==`denied`?a?O`
            <button
              class="btn"
              ?disabled=${n.loading||!e.connected}
              @click=${()=>e.onWebPushUnsubscribe?.()}
            >
              ${w.x} ${S(`configView.notifications.unsubscribe`)}
            </button>
            ${i?O`<button
                    class="btn primary"
                    ?disabled=${n.loading||!e.connected}
                    @click=${()=>e.onWebPushTest?.()}
                  >
                    ${w.send} ${S(`configView.notifications.sendTest`)}
                  </button>`:k}
          `:O`
            <button
              class="btn primary"
              ?disabled=${n.loading||!e.connected}
              @click=${()=>e.onWebPushSubscribe?.()}
            >
              ${n.loading?w.loader:k}
              ${n.loading?S(`configView.notifications.subscribing`):S(`configView.notifications.enable`)}
            </button>
          `:k;return O`
    <div class="settings-page" ${D({settingsPage:!0})}>
      <section class="settings-section" id=${wi.notifications}>
        <div class="settings-section__header">
          <h2 class="settings-section__heading">${S(`configView.notifications.title`)}</h2>
          <div class="settings-section__actions">
            ${z({kind:c,label:s})}
          </div>
        </div>
        ${n.permission===`install-required`?O`<p class="settings-section__desc">
                ${S(`configView.notifications.iosInstallRequired`)}
              </p>`:k}
        <div class="settings-group">
          ${B({title:S(`configView.notifications.browserSupport`),control:R(n.supported?S(`configView.notifications.available`):S(`configView.notifications.notSupported`))})}
          ${B({title:S(`configView.notifications.permission`),control:R(r)})}
          ${B({title:S(`configView.notifications.status`),control:z({kind:i?`ok`:`muted`,label:o})})}
          ${l===k?k:O`
                  <div class="settings-row">
                    <div class="settings-row__control">${l}</div>
                  </div>
                `}
          ${n.permission===`denied`?B({title:S(`configView.notifications.blocked`),description:S(`configView.notifications.blockedHint`),control:z({kind:`danger`,label:S(`configView.notifications.denied`)})}):k}
          ${n.error?O`
                  <div class="settings-row">
                    <div class="settings-row__text">
                      <span class="cfg-field__error">${Ke(n.error)}</span>
                    </div>
                  </div>
                `:k}
        </div>
      </section>
      ${i&&n.preferences?O`<div class="settings-stack" ?inert=${n.loading}>
              ${n.preferences.durableIdentity?bc(n.preferences.user,t=>e.onWebPushSetUserPreferences?.(t)):k}
              ${xc(n.preferences.device,t=>e.onWebPushSetDevicePreferences?.(t))}
            </div>`:k}
    </div>
  `}var wc;function Tc(){return(Tc=e((()=>{A(),E(),Lt(),V(),C(),G(),_t(),_a(),Ci(),W(),wc=[[`approvalRequested`,()=>S(`configView.notifications.approvalRequested`)],[`agentFinished`,()=>S(`configView.notifications.agentFinished`)],[`agentQuestion`,()=>S(`configView.notifications.agentQuestion`)],[`humanMentioned`,()=>S(`configView.notifications.humanMentioned`)],[`scheduledTaskFailed`,()=>S(`configView.notifications.scheduledTaskFailed`)]]})))()}function Ec(e,t,n){let r=ee(t.formValue?.wizard)?t.formValue.wizard:{};return jr(O`
    <details
      class="settings-section config-advanced-disclosure"
      id="config-section-wizard"
      ?open=${t.forceAdvancedSection===`wizard`}
    >
      <summary class="settings-section__heading config-advanced-disclosure__summary">
        ${S(`configForm.sections.wizard.label`)}
      </summary>
      <p class="settings-section__desc">${S(`configForm.sections.wizard.description`)}</p>
      ${Lr(Object.entries(Ri).map(([i,a])=>{let o=e.properties?.[i];return o?Xi({schema:{...o,default:a},value:r[i],path:[`wizard`,i],hints:t.uiHints,unsupported:new Set,disabled:n,onPatch:t.onFormPatch,onRemove:t.onFormRemove}):k}))}
      ${Lr(Ni.flatMap(n=>{let i=r[n];if(typeof i!=`string`||!i)return[];let a=xt([`wizard`,n],t.uiHints);return[B({title:a?.label??e.properties?.[n]?.title??bt(n),description:i})]}))}
    </details>
  `)}function Dc(){return(Dc=e((()=>{A(),Qi(),na(),V(),C(),G(),Ii(),W()})))()}function Oc(e,t){if(!e||$e(e)!==`object`||!e.properties)return e;let n=t.include,r=t.exclude,i={};for(let t of Object.keys(e.properties)){if(n&&n.size>0&&!n.has(t)||r&&r.size>0&&r.has(t))continue;let a=e.properties[t];a&&(i[t]=a)}return{...e,properties:i}}function kc(e){return ee(e)?e:null}function Ac(e){return e?.length?e.join(``):``}function jc(e,t,n,r,i,a){let o=Ac(n),s=Ac(r),c=e.schemaAnalysisCache;if(c&&c.schema===t&&c.includeKey===o&&c.excludeKey===s)return c.analysis;let l=Oc(t,{include:i,exclude:a}),u=Zi(l);return e.schemaAnalysisCache={schema:t,includeKey:o,excludeKey:s,analysis:u},u}function Mc(e,t){if(!e||t===`<root>`)return!1;let n=t.split(`.`),r=(e,t)=>{if(t===n.length)return e!==void 0;if(typeof e!=`object`||!e)return!1;let i=n[t];return i===`*`?Object.values(e).some(e=>r(e,t+1)):!i||!Object.hasOwn(e,i)?!1:r(e[i],t+1)};return r(e,0)}function Nc(e){let t=`__OPENCLAW_CONFIG_PATHS__`,n=e.length===1?`configView.formUnsafeCount`:`configView.formUnsafeCountPlural`,[r,i=``]=S(n,{count:String(e.length),paths:t}).split(t);return O`
    <span class="config-content-callout__text">
      ${r}${e.slice(0,3).map((e,t)=>O`${t>0?`, `:``}<code>${e}</code>`)}${i}${e.length>3?O` ${S(`configView.formUnsafeMore`,{count:String(e.length-3)})}`:k}
    </span>
  `}function Pc(){return(Pc=e((()=>{A(),na(),$i(),C()})))()}function Fc(e){let t=kc(e.schema),n=Ic.filter(t=>e.installedSessionSourcePluginIds?.has(t.pluginId)).map(e=>{let n=ya(t,e.pluginId)?.properties?.[e.key]?.properties?.enabled;return Object.assign({},e,{enabledSchema:n})}),r=!e.connected||e.mutationAllowed===!1||e.loading||e.schemaLoading||e.saving||e.applying||e.updating||e.rawDraftPending===!0;return O`
    <section id=${Ue.sessionSources} class="settings-section">
      <div class="settings-section__header">
        <h2 class="settings-section__heading">${S(`configView.sessionSources.title`)}</h2>
        ${e.pluginsHref?O`<a class="btn btn--sm" href=${e.pluginsHref}
                >${S(`configView.sessionSources.managePlugins`)}</a
              >`:k}
      </div>
      <p class="settings-section__desc">${S(`configView.sessionSources.hint`)}</p>
      ${n.length>0?O`<div class="settings-group">
              ${n.map(({pluginId:t,plugin:n,icon:i,key:a,labelKey:o,enabledSchema:s})=>{let c=v(va(e.formValue,t).config),l=v(c?.[a])?.enabled;return L({icon:zr(i,{className:`session-source__icon`}),title:S(o),description:s?S(`configView.sessionSources.sourceHint`,{plugin:n}):S(e.schemaLoading?`common.loading`:`configView.sessionSources.unavailable`),checked:typeof l==`boolean`?l:s?.default===!0,disabled:r||!s,onChange:n=>e.onFormPatch([`plugins`,`entries`,t,`config`,a,`enabled`],n)})})}
            </div>`:O`<p class="settings-section__desc">
              ${S(e.sessionSourcePluginsLoading?`common.loading`:e.installedSessionSourcePluginIds?`configView.sessionSources.empty`:`configView.sessionSources.unavailable`)}
            </p>`}
      <p class="settings-section__desc">${S(`configView.sessionSources.scope`)}</p>
    </section>
  `}var Ic;function Lc(){return(Lc=e((()=>{A(),Or(),V(),C(),ba(),rt(),Pc(),Ic=[{pluginId:`anthropic`,plugin:`Anthropic`,icon:`claude`,key:`sessionCatalog`,labelKey:`configView.sessionSources.claude`},{pluginId:`codex`,plugin:`Codex`,icon:`codex`,key:`sessionCatalog`,labelKey:`configView.sessionSources.codex`},{pluginId:`opencode`,plugin:`OpenCode`,icon:`opencode`,key:`sessionCatalog`,labelKey:`configView.sessionSources.opencode`},{pluginId:`acpx`,plugin:`ACPX`,icon:`pi`,key:`piSessionCatalog`,labelKey:`configView.sessionSources.pi`}]})))()}var Rc;function zc(){return(zc=e((()=>{A(),Rc=zn`
  :host {
    --current-text-color: var(--wa-color-brand-on-loud);

    display: block;
    color: var(--wa-color-text-normal);
    -webkit-user-select: none;
    user-select: none;

    position: relative;
    display: flex;
    align-items: center;
    font: inherit;
    padding: 0.5em 1em 0.5em 0.25em;
    border-radius: var(--wa-border-radius-s);
    line-height: var(--wa-line-height-condensed);
    transition: var(--wa-transition-fast) background-color var(--wa-transition-easing);
    cursor: pointer;
  }

  :host(:focus) {
    outline: none;
  }

  @media (hover: hover) {
    :host(:not(:state(disabled), :state(current)):is(:state(hover), :hover)) {
      background-color: var(--wa-color-neutral-fill-normal);
      color: var(--wa-color-neutral-on-normal);
    }
  }

  :host(:state(current)),
  :host(:state(disabled):state(current)) {
    background-color: var(--wa-form-control-activated-color);
    color: var(--current-text-color);
    opacity: 1;
  }

  :host(:state(disabled)) {
    outline: none;
    opacity: 0.5;
    cursor: not-allowed;
  }

  .label {
    flex: 1 1 auto;
    display: inline-block;
  }

  .check {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: var(--wa-font-size-smaller);
    visibility: hidden;
    width: 2em;
  }

  :host(:state(selected)) .check {
    visibility: visible;
  }

  .start,
  .end {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
  }

  .start::slotted(*) {
    margin-inline-end: 0.5em;
  }

  .end::slotted(*) {
    margin-inline-start: 0.5em;
  }

  @media (forced-colors: active) {
    :host(:hover:not([aria-disabled='true'])) {
      outline: dashed 1px SelectedItem;
      outline-offset: -1px;
    }
  }
`})))()}function Bc(e,t=0){if(!e||!globalThis.Node)return``;if(typeof e[Symbol.iterator]==`function`)return(Array.isArray(e)?e:[...e]).map(e=>Bc(e,--t)).join(``);let n=e;if(n.nodeType===Node.TEXT_NODE)return n.textContent??``;if(n.nodeType===Node.ELEMENT_NODE){let e=n;if(e.hasAttribute(`slot`)||e.matches(`style, script`))return``;if(e instanceof HTMLSlotElement){let n=e.assignedNodes({flatten:!0});if(n.length>0)return Bc(n,--t)}return t>-1?Bc(e,--t):e.textContent??``}return n.hasChildNodes()?Bc(n.childNodes,--t):``}var X;function Vc(){return(Vc=e((()=>{zc(),ce(),je(),_(),A(),M(),X=class extends le{constructor(){super(...arguments),this.localize=new p(this),this.cachedDefaultLabel=``,this.isInitialized=!1,this.isDefaultLabelDirty=!0,this.current=!1,this.value=``,this.disabled=!1,this.selected=!1,this.defaultSelected=!1,this._label=``,this.handleHover=e=>{e.type===`mouseenter`?this.customStates.set(`hover`,!0):e.type===`mouseleave`&&this.customStates.set(`hover`,!1)}}set label(e){let t=this._label;this._label=e||``,this._label!==t&&this.requestUpdate(`label`,t)}get label(){return this._label?this._label:this.defaultLabel}get defaultLabel(){return(this.isDefaultLabelDirty||!this.cachedDefaultLabel)&&this.updateDefaultLabel(),this.cachedDefaultLabel}connectedCallback(){super.connectedCallback(),this.setAttribute(`role`,`option`),this.setAttribute(`aria-selected`,`false`),this.addEventListener(`mouseenter`,this.handleHover),this.addEventListener(`mouseleave`,this.handleHover)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener(`mouseenter`,this.handleHover),this.removeEventListener(`mouseleave`,this.handleHover)}handleDefaultSlotChange(){this.isDefaultLabelDirty=!0,this.isInitialized?(customElements.whenDefined(`wa-select`).then(()=>{let e=this.closest(`wa-select`);e&&e.handleDefaultSlotChange?.()}),customElements.whenDefined(`wa-combobox`).then(()=>{let e=this.closest(`wa-combobox`);e&&e.handleDefaultSlotChange?.()})):this.isInitialized=!0}willUpdate(e){e.has(`defaultSelected`)&&(this.didSSR&&this.hasUpdated||!this.didSSR)&&this.syncDefaultSelected(),super.willUpdate(e)}syncDefaultSelected(){if(`closest`in this&&!this.closest(`wa-combobox, wa-select`)?.hasInteracted&&this.defaultSelected){let e=this.selected;this.selected=this.defaultSelected,this.requestUpdate(`selected`,e)}}updated(e){e.has(`disabled`)&&(this.setAttribute(`aria-disabled`,this.disabled?`true`:`false`),this.customStates.set(`disabled`,this.disabled)),e.has(`selected`)&&(this.setAttribute(`aria-selected`,this.selected?`true`:`false`),this.customStates.set(`selected`,this.selected)),e.has(`value`)&&(typeof this.value!=`string`&&(this.value=String(this.value)),this.handleDefaultSlotChange()),e.has(`current`)&&this.customStates.set(`current`,this.current),super.updated(e)}async firstUpdated(e){if(super.firstUpdated(e),this.didSSR&&!this.hasUpdated&&await this.updateComplete,this.syncDefaultSelected(),this.selected&&!this.defaultSelected){let e=this.closest(`wa-select, wa-combobox`);e&&!e.hasInteracted&&(await customElements.whenDefined(e?.localName),await e.updateComplete,e.selectionChanged?.())}}updateDefaultLabel(){let e=this.cachedDefaultLabel;this.cachedDefaultLabel=Bc(this).trim(),this.isDefaultLabelDirty=!1;let t=this.cachedDefaultLabel!==e;return!this._label&&t&&this.requestUpdate(`label`,e),t}render(){let e=this.selected;return this.didSSR&&!this.hasUpdated?(this.updateComplete.then(()=>{this.requestUpdate()}),k):O`
      ${e?O`<wa-icon
            part="checked-icon"
            class="check"
            name="check"
            library="system"
            variant="solid"
            aria-hidden="true"
          ></wa-icon>`:O`<span part="checked-icon" class="check" aria-hidden="true"></span>`}
      <slot part="start" name="start" class="start"></slot>
      <slot part="label" class="label" @slotchange=${this.handleDefaultSlotChange}></slot>
      <slot part="end" name="end" class="end"></slot>
    `}},X.css=Rc,y([Nn(`.label`)],X.prototype,`defaultSlot`,2),y([j()],X.prototype,`current`,2),y([N({reflect:!0})],X.prototype,`value`,2),y([N({type:Boolean})],X.prototype,`disabled`,2),y([N({type:Boolean,attribute:!1})],X.prototype,`selected`,2),y([N({type:Boolean,attribute:`selected`})],X.prototype,`defaultSelected`,2),y([N()],X.prototype,`label`,1),X=y([Gn(`wa-option`)],X)})))()}function Hc(){return(Hc=e((()=>{Vc(),zc(),t(),we(),ce(),je(),f()})))()}var Uc;function Wc(){return(Wc=e((()=>{A(),Uc=zn`
  :host {
    --tag-max-size: 10ch;
    --show-duration: var(--wa-transition-fast);
    --hide-duration: var(--wa-transition-fast);
  }

  /* Add ellipses to multi select options */
  :host wa-tag::part(content) {
    display: initial;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    max-width: var(--tag-max-size);
  }

  :host .disabled [part~='combobox'] {
    opacity: 0.5;
    cursor: not-allowed;
    outline: none;
  }

  :host .enabled:is(.open, :focus-within) [part~='combobox'] {
    outline-color: var(--wa-color-focus);
  }

  /** The popup */
  .select {
    flex: 1 1 auto;
    display: inline-flex;
    width: 100%;
    position: relative;
    vertical-align: middle;

    /* Pass through from select to the popup */
    --show-duration: inherit;
    --hide-duration: inherit;

    &::part(popup) {
      z-index: 900;
    }

    &[data-current-placement^='top']::part(popup) {
      transform-origin: bottom;
    }

    &[data-current-placement^='bottom']::part(popup) {
      transform-origin: top;
    }
  }

  /* Combobox */
  .combobox {
    flex: 1;
    display: flex;
    width: 100%;
    min-width: 0;
    align-items: center;
    justify-content: start;

    min-height: var(--wa-form-control-height);

    background-color: var(--wa-form-control-background-color);
    border-color: var(--wa-form-control-border-color);
    border-radius: var(--wa-form-control-border-radius);
    border-style: var(--wa-form-control-border-style);
    border-width: var(--wa-form-control-border-width);
    color: var(--wa-form-control-value-color);
    cursor: pointer;
    font-family: inherit;
    font-weight: var(--wa-form-control-value-font-weight);
    line-height: var(--wa-form-control-value-line-height);
    overflow: hidden;
    padding: 0 var(--wa-form-control-padding-inline);
    position: relative;
    vertical-align: middle;
    transition:
      background-color var(--wa-transition-normal),
      border-color var(--wa-transition-normal),
      outline-color var(--wa-transition-fast);
    transition-timing-function: var(--wa-transition-easing);
    outline: var(--wa-focus-ring-style) var(--wa-focus-ring-width) transparent;
    outline-offset: var(--wa-focus-ring-offset);

    /* Pills */
    :host([pill]) & {
      border-radius: var(--wa-border-radius-pill);
    }
  }

  /* Appearance modifiers */
  :host([appearance='outlined']) .combobox {
    background-color: var(--wa-form-control-background-color);
    border-color: var(--wa-form-control-border-color);
  }

  :host([appearance='filled']) .combobox {
    background-color: var(--wa-color-neutral-fill-quiet);
    border-color: var(--wa-color-neutral-fill-quiet);
  }

  :host([appearance='filled-outlined']) .combobox {
    background-color: var(--wa-color-neutral-fill-quiet);
    border-color: var(--wa-form-control-border-color);
  }

  .display-input {
    position: relative;
    width: 100%;
    font: inherit;
    border: none;
    background: none;
    line-height: var(--wa-form-control-value-line-height);
    color: var(--wa-form-control-value-color);
    cursor: inherit;
    overflow: hidden;
    padding: 0;
    margin: 0;
    -webkit-appearance: none;

    &:focus {
      outline: none;
    }

    &::placeholder {
      color: var(--wa-form-control-placeholder-color);
    }
  }

  /* Manage spacing when tags are present */
  :host([multiple]) {
    --_padding-with-tags: calc(var(--wa-form-control-height) * 0.1 - var(--wa-form-control-border-width));

    & .combobox:has(.tags wa-tag) {
      padding-block: var(--_padding-with-tags);
      padding-inline-start: var(--_padding-with-tags);
    }
  }

  /* Visually hide the display input when multiple is enabled */
  :host([multiple]) .combobox:has(.tags wa-tag) .display-input {
    position: absolute;
    z-index: -1;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
  }

  .value-input {
    position: absolute;
    z-index: -1;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    padding: 0;
    margin: 0;
  }

  .tags {
    display: flex;
    flex: 1;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.25em;

    /* Nested inside the box, so a step down from the box's radius */
    & wa-tag:not([pill]) {
      border-radius: var(--wa-border-radius-s);
    }

    .disabled & {
      cursor: not-allowed !important;
    }
  }

  /* Start and End */

  .start,
  .end {
    flex: 0;
    display: inline-flex;
    align-items: center;
    color: var(--wa-color-neutral-on-quiet);
  }

  .end::slotted(*) {
    margin-inline-start: var(--wa-form-control-padding-inline);
  }

  .start::slotted(*) {
    margin-inline-end: var(--wa-form-control-padding-inline);
  }

  :host([multiple]) .combobox:has(.tags wa-tag) .start::slotted(*) {
    margin-inline-start: calc(var(--wa-form-control-padding-inline) - var(--_padding-with-tags));
  }

  /* Clear button */
  [part~='clear-button'] {
    flex: 0 0 auto;
    display: inline-flex;
    align-self: stretch;
    align-items: center;
    justify-content: center;
    inline-size: 1.5em;
    font-size: inherit;
    color: var(--wa-color-neutral-on-quiet);
    border: none;
    background: none;
    padding: 0;
    transition: color var(--wa-transition-normal);
    cursor: pointer;
    /* The box is wider than the glyph, so overhang half that growth on each side. Keeps the glyph
       on the same trailing axis as the segmented-field pickers' clear buttons. */
    margin-inline-start: calc(var(--wa-form-control-padding-inline) - 0.125em);
    margin-inline-end: -0.125em;

    &:focus {
      outline: none;
    }

    @media (hover: hover) {
      &:hover {
        color: color-mix(in oklab, currentColor, var(--wa-color-mix-hover));
      }
    }

    &:active {
      color: color-mix(in oklab, currentColor, var(--wa-color-mix-active));
    }
  }

  /* Expand icon */
  .expand-icon {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    color: var(--wa-color-neutral-on-quiet);
    transition: rotate var(--wa-transition-slow) var(--wa-transition-easing);
    rotate: 0deg;
    margin-inline-start: var(--wa-form-control-padding-inline);

    .open & {
      rotate: -180deg;
    }
  }

  /* Listbox */
  .listbox {
    display: block;
    position: relative;
    font: inherit;
    box-shadow: var(--wa-shadow-m);
    background: var(--wa-color-surface-raised);
    border-color: var(--wa-color-surface-border);
    border-radius: var(--wa-border-radius-m);
    border-style: var(--wa-border-style);
    border-width: var(--wa-border-width-s);
    padding: 0.25em;
    overflow: auto;
    overscroll-behavior: none;

    /* Make sure it adheres to the popup's auto size */
    max-width: var(--auto-size-available-width);
    max-height: var(--auto-size-available-height);

    &::slotted(wa-divider) {
      --spacing: 0.5em;
    }
  }

  /* Space options with half the listbox's padding */
  .listbox slot:not([name]) {
    display: flex;
    flex-direction: column;
    gap: 0.125em;
  }

  slot:not([name])::slotted(small) {
    display: block;
    font-size: var(--wa-font-size-smaller);
    font-weight: var(--wa-font-weight-semibold);
    color: var(--wa-color-text-quiet);
    padding-block: 0.5em;
    padding-inline: 2.25em;
  }
`})))()}var Gc;function Kc(){return(Kc=e((()=>{Gc=class extends Event{constructor(){super(`wa-clear`,{bubbles:!0,cancelable:!1,composed:!0})}}})))()}var Z;function qc(){return(qc=e((()=>{Wc(),ue(),ye(),De(),_e(),Re(),Kc(),de(),vr(),Sr(),ae(),Se(),Be(),m(),je(),_(),A(),M(),Mn(),Wn(),Z=class extends l{constructor(){super(...arguments),this.assumeInteractionOn=[`blur`,`input`],this.cachedOptions=null,this.hasSlotController=new Ne(this,`hint`,`label`),this.localize=new p(this),this.selectionOrder=new Map,this.typeToSelectString=``,this.slotChangePending=!1,this.openTransition={open:!1},this.displayLabel=``,this.selectedOptions=[],this.name=``,this._defaultValue=null,this.size=`m`,this.placeholder=``,this.multiple=!1,this.maxOptionsVisible=3,this.disabled=!1,this.withClear=!1,this.open=!1,this.appearance=`outlined`,this.pill=!1,this.label=``,this.placement=`bottom`,this.hint=``,this.withLabel=!1,this.withHint=!1,this.required=!1,this.getTag=e=>O`
        <wa-tag
          part="tag"
          exportparts="
            base:tag__base,
            content:tag__content,
            remove-button:tag__remove-button,
            remove-button__base:tag__remove-button__base
          "
          ?pill=${this.pill}
          size=${this.size}
          with-remove
          data-value=${e.value}
          @wa-remove=${t=>this.handleTagRemove(t,e)}
        >
          ${e.label}
        </wa-tag>
      `,this.handleDocumentFocusIn=e=>{let t=e.composedPath();this&&!t.includes(this)&&this.hide()},this.handleDocumentKeyDown=e=>{let t=e.target,n=t.closest(`[part~="clear-button"]`)!==null,r=t.closest(`wa-button`)!==null;if(!(n||r)){if(e.key===`Escape`&&this.open&&Oe(this)&&(e.preventDefault(),e.stopPropagation(),this.hide(),this.displayInput.focus({preventScroll:!0})),e.key===`Enter`||e.key===` `&&this.typeToSelectString===``){if(e.preventDefault(),e.stopImmediatePropagation(),!this.open){this.show();return}this.currentOption&&!this.currentOption.disabled&&(this.valueHasChanged=!0,this.hasInteracted=!0,this.multiple?this.toggleOptionSelection(this.currentOption):this.setSelectedOptions(this.currentOption),this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent(`input`,{bubbles:!0,composed:!0})),this.dispatchEvent(new Event(`change`,{bubbles:!0,composed:!0}))}),this.multiple||(this.hide(),this.displayInput.focus({preventScroll:!0})));return}if([`ArrowUp`,`ArrowDown`,`Home`,`End`].includes(e.key)){let t=this.getAllOptions(),n=t.indexOf(this.currentOption),r=Math.max(0,n);if(e.preventDefault(),!this.open&&(this.show(),this.currentOption))return;e.key===`ArrowDown`?(r=n+1,r>t.length-1&&(r=0)):e.key===`ArrowUp`?(r=n-1,r<0&&(r=t.length-1)):e.key===`Home`?r=0:e.key===`End`&&(r=t.length-1),this.setCurrentOption(t[r])}if(e.key?.length===1||e.key===`Backspace`){let t=this.getAllOptions();if(e.metaKey||e.ctrlKey||e.altKey)return;if(!this.open){if(e.key===`Backspace`)return;this.show()}e.stopPropagation(),e.preventDefault(),clearTimeout(this.typeToSelectTimeout),this.typeToSelectTimeout=window.setTimeout(()=>this.typeToSelectString=``,1e3),e.key===`Backspace`?this.typeToSelectString=this.typeToSelectString.slice(0,-1):this.typeToSelectString+=e.key.toLowerCase();for(let e of t)if(e.label.toLowerCase().startsWith(this.typeToSelectString)){this.setCurrentOption(e);break}}}},this.handleDocumentMouseDown=e=>{let t=e.composedPath();this&&!t.includes(this)&&this.hide()}}static get validators(){let e=[yr({validationElement:Object.assign(document.createElement(`select`),{required:!0})})];return[...super.validators,...e]}get validationTarget(){return this.valueInput}set defaultValue(e){this._defaultValue=this.convertDefaultValue(e)}get defaultValue(){return this.convertDefaultValue(this._defaultValue)}rawValuesEqual(e,t){return e==null&&t==null?!0:e==null||t==null||e.length!==t.length?!1:e.every((e,n)=>e===t[n])}convertDefaultValue(e){return!(this.multiple||this.hasAttribute(`multiple`))&&Array.isArray(e)&&(e=e[0]),e}set value(e){let t=this.value;e instanceof FormData&&(e=e.getAll(this.name)),e!=null&&!Array.isArray(e)&&(e=[e]);let n=this._value;this._value=e??null,this.rawValuesEqual(n,this._value)||(this.valueHasChanged=!0,this.requestUpdate(`value`,t))}get value(){let e=this._value??this.defaultValue??null;e!=null&&(e=Array.isArray(e)?e:[e]),this.optionValues=new Set(this.getAllOptions().filter(e=>!e.disabled).map(e=>e.value));let t=e;return e!=null&&(t=e.filter(e=>this.optionValues.has(e)),t=this.multiple?t:t[0],t??=null),t}handleSizeChange(){r(this.localName,this.size)}connectedCallback(){super.connectedCallback(),this.processSlotChange(),this.open=!1}disconnectedCallback(){super.disconnectedCallback(),this.openTransition.controller?.abort(),this.openTransition={open:!1},this.popup?.popup?.classList.remove(`show`,`hide`),this.listbox&&(this.listbox.hidden=!0),this.popup&&(this.popup.active=!1),fe(this),this.cachedOptions=null}updateDefaultValue(){let e=this.getAllOptions().filter(e=>e.hasAttribute(`selected`)||e.defaultSelected);if(e.length>0){let t=e.map(e=>e.value);this._defaultValue=this.multiple?t:t[0]}this.hasAttribute(`value`)&&(this._defaultValue=this.getAttribute(`value`)||null)}handleFocus(){this.displayInput.setSelectionRange(0,0)}handleLabelClick(){this.displayInput.focus()}handleComboboxClick(e){e.preventDefault()}handleComboboxMouseDown(e){let t=e.composedPath().some(e=>e instanceof Element&&e.tagName.toLowerCase()===`wa-button`);this.disabled||t||(e.preventDefault(),this.displayInput.focus({preventScroll:!0}),this.open=!this.open)}handleComboboxKeyDown(e){e.stopPropagation(),this.handleDocumentKeyDown(e)}handleClearClick(e){e.stopPropagation(),this.hasInteracted=!0,this.valueHasChanged=!0,this.value!==null&&(this.displayLabel=``,this.selectionOrder.clear(),this.setSelectedOptions([]),this.displayInput.focus({preventScroll:!0}),this.updateComplete.then(()=>{this.dispatchEvent(new Gc),this.dispatchEvent(new InputEvent(`input`,{bubbles:!0,composed:!0})),this.dispatchEvent(new Event(`change`,{bubbles:!0,composed:!0}))}))}handleClearMouseDown(e){e.stopPropagation(),e.preventDefault()}handleOptionClick(e){let t=e.target.closest(`wa-option`);t&&!t.disabled&&(this.hasInteracted=!0,this.valueHasChanged=!0,this.multiple?this.toggleOptionSelection(t):this.setSelectedOptions(t),this.updateComplete.then(()=>this.displayInput.focus({preventScroll:!0})),this.requestUpdate(`value`),this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent(`input`,{bubbles:!0,composed:!0})),this.dispatchEvent(new Event(`change`,{bubbles:!0,composed:!0}))}),this.multiple||(this.hide(),this.displayInput.focus({preventScroll:!0})))}handleDefaultSlotChange(){this.slotChangePending||(this.slotChangePending=!0,queueMicrotask(()=>{this.slotChangePending=!1,this.processSlotChange()}))}processSlotChange(){if(customElements.get(`wa-option`)||customElements.whenDefined(`wa-option`).then(()=>this.handleDefaultSlotChange()),this.didSSR&&!this.hasUpdated){this.updateComplete.then(()=>{this.handleDefaultSlotChange()});return}this.cachedOptions=null;let e=this.getAllOptions();this.updateDefaultValue();let t=this.value;if(t==null||!this.valueHasChanged&&!this.hasInteracted){this.selectionChanged();return}Array.isArray(t)||(t=[t]);let n=e.filter(e=>t.includes(e.value));this.setSelectedOptions(n)}handleTagRemove(e,t){if(e.stopPropagation(),this.disabled)return;this.hasInteracted=!0,this.valueHasChanged=!0;let n=t;if(!n){let t=e.target.closest(`wa-tag[data-value]`);if(t){let e=t.dataset.value;n=this.selectedOptions.find(t=>t.value===e)}}n&&(this.toggleOptionSelection(n,!1),this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent(`input`,{bubbles:!0,composed:!0})),this.dispatchEvent(new Event(`change`,{bubbles:!0,composed:!0}))}))}getAllOptions(){return this.cachedOptions?this.cachedOptions:this?.querySelectorAll?(this.cachedOptions=[...this.querySelectorAll(`wa-option`)],this.cachedOptions):[]}getFirstOption(){return this.querySelector(`wa-option`)}setCurrentOption(e){this.getAllOptions().forEach(e=>{e.current=!1,e.tabIndex=-1}),e&&(this.currentOption=e,e.current=!0,e.tabIndex=0,e.focus({preventScroll:!0}),this.open&&!this.listbox.hidden&&ze(e,this.listbox,`vertical`,`auto`))}setSelectedOptions(e){let t=this.getAllOptions(),n=Array.isArray(e)?e:[e];t.forEach(e=>{n.includes(e)||(e.selected=!1)}),n.length&&n.forEach(e=>e.selected=!0),this.selectionChanged()}toggleOptionSelection(e,t){e.selected=t===!0||t===!1?t:!e.selected,this.selectionChanged()}selectionChanged(){let e=this.getAllOptions().filter(e=>{if(!this.hasInteracted&&!this.valueHasChanged){let t=this.defaultValue,n=Array.isArray(t)?t:[t];return e.hasAttribute(`selected`)||e.defaultSelected||e.selected||n?.includes(e.value)}return e.selected}),t=new Set(e.map(e=>e.value));for(let e of this.selectionOrder.keys())t.has(e)||this.selectionOrder.delete(e);let n=(this.selectionOrder.size>0?Math.max(...this.selectionOrder.values()):-1)+1;for(let t of e)this.selectionOrder.has(t.value)||this.selectionOrder.set(t.value,n++);this.selectedOptions=e.sort((e,t)=>(this.selectionOrder.get(e.value)??0)-(this.selectionOrder.get(t.value)??0));let r=new Set(this.selectedOptions.map(e=>e.value));if(r.size>0||this._value){let e=this._value;if(this._value==null){let e=this.defaultValue??[];this._value=Array.isArray(e)?e:[e]}this._value=this._value?.filter(e=>!this.optionValues?.has(e))??null,this._value?.unshift(...r),this.requestUpdate(`value`,e)}if(this.multiple)this.displayLabel=this.placeholder&&!this.value?.length?``:this.localize.term(`numOptionsSelected`,this.selectedOptions.length);else{let e=this.selectedOptions[0];this.displayLabel=e?.label??``}this.updateComplete.then(()=>{this.updateValidity()})}get tags(){return this.selectedOptions.map((e,t)=>{if(t<this.maxOptionsVisible||this.maxOptionsVisible<=0){let n=this.getTag(e,t);return n?typeof n==`string`?Hn(n):n:null}return t===this.maxOptionsVisible?O`
          <wa-tag
            part="tag"
            exportparts="
              base:tag__base,
              content:tag__content,
              remove-button:tag__remove-button,
              remove-button__base:tag__remove-button__base
            "
            ?pill=${this.pill}
            size=${this.size}
            >+${this.selectedOptions.length-t}</wa-tag
          >
        `:null})}updated(e){super.updated(e),(e.has(`value`)||e.has(`displayLabel`))&&this.customStates.set(`blank`,!this.value&&!this.displayLabel)}handleDisabledChange(){this.disabled&&this.open&&(this.open=!1,this.handleOpenChange())}handleValueChange(){let e=this.getAllOptions(),t=Array.isArray(this.value)?this.value:[this.value],n=e.filter(e=>t.includes(e.value));this.setSelectedOptions(n),this.updateValidity()}async handleOpenChange(){let e=this.open&&!this.disabled;if(!this.isConnected||this.openTransition.open===e)return this.openAnimation;e&&this.setCurrentOption(this.selectedOptions[0]||this.getFirstOption());let t=e?new xe:new Ae;if(this.dispatchEvent(t),t.defaultPrevented&&!this.disabled)return this.open=this.openTransition.open,this.openAnimation;if(!this.isConnected||(this.open&&!this.disabled)!==e)return this.openAnimation;this.openTransition.controller?.abort(),this.openTransition={open:e,controller:new AbortController};let{signal:n}=this.openTransition.controller,r=()=>!n.aborted&&this.isConnected&&(this.open&&!this.disabled)===e;if(e){document.addEventListener(`focusin`,this.handleDocumentFocusIn,{signal:n}),document.addEventListener(`keydown`,this.handleDocumentKeyDown,{signal:n}),document.addEventListener(`mousedown`,this.handleDocumentMouseDown,{signal:n}),Pe(this);let e=this.getRootNode();e!==document&&e.addEventListener(`focusin`,this.handleDocumentFocusIn,{signal:n}),this.listbox.hidden=!1,this.popup.active=!0,requestAnimationFrame(()=>{r()&&this.setCurrentOption(this.currentOption)})}else fe(this);this.popup.popup.classList.remove(`show`,`hide`);let i=this.openAnimation;return this.openAnimation=(async()=>{await i,r()&&(await Ie(this.popup.popup,e?`show`:`hide`),r()&&(e&&this.currentOption&&ze(this.currentOption,this.listbox,`vertical`,`auto`),e||(this.listbox.hidden=!0,this.popup.active=!1),this.dispatchEvent(e?new Te:new me)))})(),this.openAnimation}async show(){if(this.disabled){this.open=!1;return}if(this.isConnected)return this.open=!0,await this.updateComplete,this.handleOpenChange()}async hide(){if(this.open=!1,this.isConnected)return await this.updateComplete,this.openAnimation}focus(e){this.displayInput.focus(e)}blur(){this.displayInput.blur()}formResetCallback(){this.selectionOrder.clear(),this.value=this.defaultValue,super.formResetCallback(),this.handleValueChange(),this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent(`input`,{bubbles:!0,composed:!0})),this.dispatchEvent(new Event(`change`,{bubbles:!0,composed:!0}))})}render(){let e=this.hasSlotController.test(`label`,`withLabel`),t=this.hasSlotController.test(`hint`,`withHint`),n=this.label?!0:!!e,r=this.hint?!0:!!t,i=(this.hasUpdated||!1)&&this.withClear&&!this.disabled&&(this.displayLabel||this.value&&this.value.length>0);return O`
      <div
        part="form-control"
        class=${jn({"form-control":!0,"form-control-has-label":n})}
      >
        <label
          id="label"
          part="form-control-label label"
          class=${jn({label:!0,"has-label":n})}
          aria-hidden=${n?`false`:`true`}
          @click=${this.handleLabelClick}
        >
          <slot name="label">${this.label}</slot>
        </label>

        <div part="form-control-input" class="form-control-input">
          <wa-popup
            class=${jn({select:!0,open:this.open,disabled:this.disabled,enabled:!this.disabled,multiple:this.multiple})}
            placement=${this.placement}
            flip
            shift
            sync="width"
            auto-size="vertical"
            auto-size-padding="10"
          >
            <div
              part="combobox"
              class="combobox"
              slot="anchor"
              @keydown=${this.handleComboboxKeyDown}
              @mousedown=${this.handleComboboxMouseDown}
              @click=${this.handleComboboxClick}
            >
              <slot part="start" name="start" class="start"></slot>

              <input
                part="display-input"
                class="display-input"
                type="text"
                placeholder=${this.placeholder}
                .disabled=${this.disabled}
                .value=${this.displayLabel}
                ?required=${this.required}
                autocomplete="off"
                spellcheck="false"
                autocapitalize="off"
                readonly
                aria-invalid=${!this.validity.valid}
                aria-controls="listbox"
                aria-expanded=${this.open?`true`:`false`}
                aria-haspopup="listbox"
                aria-labelledby="label"
                aria-disabled=${this.disabled?`true`:`false`}
                aria-describedby="hint"
                role="combobox"
                tabindex="0"
                @focus=${this.handleFocus}
              />

              <!-- Tags need to wait for first hydration before populating otherwise it will create a hydration mismatch. -->
              ${this.multiple&&this.hasUpdated?O`<div part="tags" class="tags" @wa-remove=${this.handleTagRemove}>${this.tags}</div>`:``}

              <input
                class="value-input"
                type="text"
                ?disabled=${this.disabled}
                ?required=${this.required}
                .value=${Array.isArray(this.value)?this.value.join(`, `):this.value}
                tabindex="-1"
                aria-hidden="true"
                @focus=${()=>this.focus()}
              />

              ${i?O`
                    <button
                      part="clear-button"
                      type="button"
                      aria-label=${this.localize.term(`clearEntry`)}
                      @mousedown=${this.handleClearMouseDown}
                      @click=${this.handleClearClick}
                      tabindex="-1"
                    >
                      <slot name="clear-icon">
                        <wa-icon name="circle-xmark" library="system" variant="regular"></wa-icon>
                      </slot>
                    </button>
                  `:``}

              <slot name="end" part="end" class="end"></slot>

              <slot name="expand-icon" part="expand-icon" class="expand-icon">
                <wa-icon library="system" name="chevron-down" variant="solid"></wa-icon>
              </slot>
            </div>

            <div
              id="listbox"
              role="listbox"
              aria-expanded=${this.open?`true`:`false`}
              aria-multiselectable=${this.multiple?`true`:`false`}
              aria-labelledby="label"
              part="listbox"
              class="listbox"
              tabindex="-1"
              @mouseup=${this.handleOptionClick}
            >
              <slot @slotchange=${this.handleDefaultSlotChange}></slot>
            </div>
          </wa-popup>
        </div>

        <slot
          id="hint"
          name="hint"
          part="hint"
          class=${jn({"has-slotted":r})}
          aria-hidden=${r?`false`:`true`}
          >${this.hint}</slot
        >
      </div>
    `}},Z.css=[Uc,br,re],y([Nn(`.select`)],Z.prototype,`popup`,2),y([Nn(`.combobox`)],Z.prototype,`combobox`,2),y([Nn(`.display-input`)],Z.prototype,`displayInput`,2),y([Nn(`.value-input`)],Z.prototype,`valueInput`,2),y([Nn(`.listbox`)],Z.prototype,`listbox`,2),y([j()],Z.prototype,`displayLabel`,2),y([j()],Z.prototype,`currentOption`,2),y([j()],Z.prototype,`selectedOptions`,2),y([N({reflect:!0})],Z.prototype,`name`,2),y([N({attribute:!1})],Z.prototype,`defaultValue`,1),y([N({attribute:`value`,reflect:!1})],Z.prototype,`value`,1),y([N({reflect:!0})],Z.prototype,`size`,2),y([he(`size`)],Z.prototype,`handleSizeChange`,1),y([N()],Z.prototype,`placeholder`,2),y([N({type:Boolean,reflect:!0})],Z.prototype,`multiple`,2),y([N({attribute:`max-options-visible`,type:Number})],Z.prototype,`maxOptionsVisible`,2),y([N({type:Boolean})],Z.prototype,`disabled`,2),y([N({attribute:`with-clear`,type:Boolean})],Z.prototype,`withClear`,2),y([N({type:Boolean,reflect:!0})],Z.prototype,`open`,2),y([N({reflect:!0})],Z.prototype,`appearance`,2),y([N({type:Boolean,reflect:!0})],Z.prototype,`pill`,2),y([N()],Z.prototype,`label`,2),y([N({reflect:!0})],Z.prototype,`placement`,2),y([N({attribute:`hint`})],Z.prototype,`hint`,2),y([N({attribute:`with-label`,type:Boolean})],Z.prototype,`withLabel`,2),y([N({attribute:`with-hint`,type:Boolean})],Z.prototype,`withHint`,2),y([N({type:Boolean,reflect:!0})],Z.prototype,`required`,2),y([N({attribute:!1})],Z.prototype,`getTag`,2),y([he(`disabled`,{waitUntilFirstUpdate:!0})],Z.prototype,`handleDisabledChange`,1),y([he(`value`,{waitUntilFirstUpdate:!0})],Z.prototype,`handleValueChange`,1),y([he(`open`,{waitUntilFirstUpdate:!0})],Z.prototype,`handleOpenChange`,1),Z=y([Gn(`wa-select`)],Z),Z.disableWarning?.(`change-in-update`)})))()}var Jc;function Yc(){return(Yc=e((()=>{Jc=class extends Event{constructor(){super(`wa-remove`,{bubbles:!0,cancelable:!1,composed:!0})}}})))()}var Xc;function Zc(){return(Zc=e((()=>{A(),Xc=zn`
  @layer wa-component {
    :host {
      display: inline-flex;
      gap: 0.5em;
      border-radius: var(--wa-border-radius-m);
      align-items: center;
      background-color: var(--wa-color-fill-quiet, var(--wa-color-neutral-fill-quiet));
      border-color: var(--wa-color-border-normal, var(--wa-color-neutral-border-normal));
      border-style: var(--wa-border-style);
      border-width: var(--wa-border-width-s);
      color: var(--wa-color-on-quiet, var(--wa-color-neutral-on-quiet));
      font-size: inherit;
      line-height: 1;
      white-space: nowrap;
      user-select: none;
      -webkit-user-select: none;
      height: calc(var(--wa-form-control-height) * 0.8);
      line-height: calc(var(--wa-form-control-height) - var(--wa-form-control-border-width) * 2);
      padding: 0 0.75em;
    }

    /* Appearance modifiers */
    :host([appearance='outlined']) {
      color: var(--wa-color-on-quiet, var(--wa-color-neutral-on-quiet));
      background-color: transparent;
      border-color: var(--wa-color-border-loud, var(--wa-color-neutral-border-loud));
    }

    :host([appearance='filled']) {
      color: var(--wa-color-on-quiet, var(--wa-color-neutral-on-quiet));
      background-color: var(--wa-color-fill-quiet, var(--wa-color-neutral-fill-quiet));
      border-color: transparent;
    }

    :host([appearance='filled-outlined']) {
      color: var(--wa-color-on-quiet, var(--wa-color-neutral-on-quiet));
      background-color: var(--wa-color-fill-quiet, var(--wa-color-neutral-fill-quiet));
      border-color: var(--wa-color-border-normal, var(--wa-color-neutral-border-normal));
    }

    :host([appearance='accent']) {
      color: var(--wa-color-on-loud, var(--wa-color-neutral-on-loud));
      background-color: var(--wa-color-fill-loud, var(--wa-color-neutral-fill-loud));
      border-color: transparent;
    }
  }

  .content {
    font-size: var(--wa-font-size-smaller);
  }

  [part='remove-button'] {
    line-height: 1;
  }

  [part='remove-button']::part(base) {
    padding: 0;
    height: 1em;
    width: 1em;
    color: currentColor;
  }

  @media (hover: hover) {
    :host(:hover) > [part='remove-button']::part(base) {
      background-color: transparent;
      color: color-mix(in oklab, currentColor, var(--wa-color-mix-hover));
    }
  }

  :host(:active) > [part='remove-button']::part(base) {
    background-color: transparent;
    color: color-mix(in oklab, currentColor, var(--wa-color-mix-active));
  }

  /*
   * Pill modifier
   */
  :host([pill]) {
    border-radius: var(--wa-border-radius-pill);
  }
`})))()}var Q;function Qc(){return(Qc=e((()=>{Yc(),Zc(),Be(),m(),s(),ce(),je(),_(),A(),M(),Q=class extends le{constructor(){super(...arguments),this.localize=new p(this),this.variant=`neutral`,this.appearance=`filled-outlined`,this.size=`m`,this.pill=!1,this.withRemove=!1}handleSizeChange(){r(this.localName,this.size)}handleRemoveClick(){this.dispatchEvent(new Jc)}render(){return O`
      <slot part="content" class="content"></slot>

      ${this.withRemove?O`
            <wa-button
              part="remove-button"
              exportparts="base:remove-button__base"
              class="remove"
              appearance="plain"
              size=${this.size}
              @click=${this.handleRemoveClick}
              tabindex="-1"
            >
              <wa-icon name="xmark" library="system" variant="solid" label=${this.localize.term(`remove`)}></wa-icon>
            </wa-button>
          `:``}
    `}},Q.css=[Xc,d,re],y([N({reflect:!0})],Q.prototype,`variant`,2),y([N({reflect:!0})],Q.prototype,`appearance`,2),y([N({reflect:!0})],Q.prototype,`size`,2),y([he(`size`)],Q.prototype,`handleSizeChange`,1),y([N({type:Boolean,reflect:!0})],Q.prototype,`pill`,2),y([N({attribute:`with-remove`,type:Boolean})],Q.prototype,`withRemove`,2),Q=y([Gn(`wa-tag`)],Q)})))()}function $c(){return($c=e((()=>{qc(),Qc(),Zc(),Wc(),Vc(),zc(),xr(),_r(),Sr(),ne(),h(),g(),ae(),oe(),m(),s(),t(),we(),ce(),je(),f()})))()}function el(){return(el=e((()=>{Hc(),$c()})))()}function tl(e){let t=e.replace(/-([a-zA-Z])/g,(e,t)=>t.toUpperCase());return S(`languages.${t}`)}function nl(e,t,n){let r=e??`system`,i=`${S(`common.system`)} (${tl(t)})`;return O`
    <wa-select
      class="settings-select"
      .value=${r}
      @change=${e=>{let t=e.currentTarget.value;n(t===`system`?void 0:t)}}
    >
      <span slot="label" class="settings-control__sr-label">${S(`quickSettings.language`)}</span>
      <wa-option value="system" .label=${i} .selected=${r===`system`}>
        ${i}
      </wa-option>
      ${ot.map(e=>{let t=tl(e);return O`
          <wa-option value=${e} .label=${t} .selected=${e===r}>
            ${t}
          </wa-option>
        `})}
    </wa-select>
  `}function rl(){return(rl=e((()=>{A(),el(),C()})))()}function il(e){return S(e===`profile`?`configView.profileSyncedHint`:e===`device-local`?`quickSettings.personal.browserOnly`:e===`pending`?`configView.syncPendingHint`:`configView.syncedHint`)}function al(e){let t=H(e.localeResetValue?tl(e.localeResetValue):S(`common.system`),e.localeOverridden),n=il(e.localeProvenance);return O`
    <section id=${Ue.language} class="settings-section">
      <div class="settings-section__header">
        <h2 class="settings-section__heading">${S(`quickSettings.language`)}</h2>
      </div>
      <div class="settings-group">
        ${B({title:S(`quickSettings.language`),description:O`${t} ${n}`,control:nl(e.localeOverride,e.systemLocale,e.onLocaleChange)})}
      </div>
    </section>
  `}function ol(e){let t=e.state;if(!t||!e.onSelect)return k;let n=t.selectedDeviceId.trim(),r=t.devices.some(e=>e.deviceId===n),i=[{label:e.systemDefaultLabel,value:``},...t.devices.map(e=>({label:e.label,value:e.deviceId})),...n&&!r?[{label:e.fallbackLabel(t.devices.length+1),value:n}]:[]],a=!1,o=()=>{!a&&t.permissionRequired&&(a=!0,e.onRefresh?.())},s=e=>{e.button===0&&o()},c=e=>{[`Enter`,` `,`ArrowDown`,`ArrowUp`,`F4`].includes(e.key)&&o()},l=t.error?O`<span role="alert">${t.error}</span>`:!t.loading&&t.devices.length===0?e.emptyLabel:void 0;return B({title:e.title,description:O`${l?O`${l}<br />`:k}${S(`quickSettings.personal.browserOnly`)}`,control:O`
      <select
        class="settings-select settings-select--media-device"
        data-settings-microphone=${e.dataAttribute===`microphone`?``:k}
        data-settings-camera=${e.dataAttribute===`camera`?``:k}
        aria-label=${e.title}
        .value=${n}
        @pointerdown=${s}
        @keydown=${c}
        @change=${t=>e.onSelect?.(t.currentTarget.value)}
      >
        ${i.map(e=>O`
            <option value=${e.value} ?selected=${e.value===n}>
              ${e.label}
            </option>
          `)}
      </select>
    `})}function sl(e){return ol({state:e.microphone,title:S(`chat.composer.microphoneInput`),systemDefaultLabel:S(`chat.composer.systemDefaultMicrophone`),emptyLabel:S(`chat.composer.noMicrophones`),fallbackLabel:e=>S(`chat.composer.microphoneFallback`,{number:String(e)}),dataAttribute:`microphone`,onRefresh:e.onMicrophoneRefresh,onSelect:e.onMicrophoneSelect})}function cl(e){return ol({state:e.camera,title:S(`chat.composer.cameraInput`),systemDefaultLabel:S(`chat.composer.systemDefaultCamera`),emptyLabel:S(`chat.composer.noCameras`),fallbackLabel:e=>S(`chat.composer.cameraFallback`,{number:String(e)}),dataAttribute:`camera`,onRefresh:e.onCameraRefresh,onSelect:e.onCameraSelect})}function ll(e,t){let n=e.chatFollowUpMode??`server`,r=e.serverQueueMode??S(`chat.followUpModeLoading`),i=e.chatFollowUpMode?S(`chat.followUpModeOverriding`,{mode:r}):k,a=H(T.chatMessageMaxWidth,e.chatMessageMaxWidth!==void 0),o=H(e.chatSendShortcutResetValue===`modifier-enter`?S(`chat.sendShortcutModifierEnter`):S(`chat.sendShortcutEnter`),e.chatSendShortcutOverridden),s=il(e.chatSendShortcutProvenance),c=il(e.chatFollowUpModeProvenance),l=H(S(`chat.catalogOpenTargetViewer`),e.catalogOpenTarget!==T.catalogOpenTarget),u=H(S(`common.enabled`),(e.composerHoldToRecord??T.composerHoldToRecord)!==T.composerHoldToRecord),d=H(S(`common.enabled`),e.chatShowTaskProgress!==T.chatShowTaskProgress),ee=H(S(`common.disabled`),e.chatCollapseTaskProgress!==T.chatCollapseTaskProgress);return O`
    <section id=${Ue.chat} class="settings-section">
      <div class="settings-section__header">
        <h2 class="settings-section__heading">${S(`configView.chatPrefs.title`)}</h2>
      </div>
      <div class="settings-group">
        ${B({title:S(`configView.chatPrefs.messageWidth`),description:O`${S(`configView.chatPrefs.messageWidthHint`)}<br />
            ${a} ${S(`quickSettings.personal.browserOnly`)}`,control:t})}
        ${L({title:S(`configView.chatPrefs.showTaskProgress`),description:O`${S(`configView.chatPrefs.showTaskProgressHint`)}<br />
            ${d} ${S(`quickSettings.personal.browserOnly`)}`,checked:e.chatShowTaskProgress,onChange:e.setChatShowTaskProgress})}
        ${L({title:S(`configView.chatPrefs.collapseTaskProgress`),description:O`${S(`configView.chatPrefs.collapseTaskProgressHint`)}<br />
            ${ee} ${S(`quickSettings.personal.browserOnly`)}`,checked:e.chatCollapseTaskProgress,onChange:e.setChatCollapseTaskProgress,disabled:!e.chatShowTaskProgress})}
        ${K({title:S(`chat.sendShortcut`),value:e.chatSendShortcut,setting:`send-shortcut`,description:O`${o} ${s}`,options:[{value:`enter`,label:S(`chat.sendShortcutEnter`)},{value:`modifier-enter`,label:S(`chat.sendShortcutModifierEnter`)}],onChange:t=>e.setChatSendShortcut(An(t))})}
        ${B({title:S(`chat.followUpMode`),description:O`${i} ${c}`,control:O`
            <select
              class="settings-select"
              data-settings-follow-up-mode
              aria-label=${S(`chat.followUpMode`)}
              .value=${n}
              @change=${t=>{let n=t.currentTarget.value;e.setChatFollowUpMode(n===`server`?void 0:Zt(n))}}
            >
              <option value="server" ?selected=${n===`server`}>
                ${S(`chat.followUpModeServer`,{mode:r})}
              </option>
              <option value="steer" ?selected=${n===`steer`}>
                ${S(`chat.followUpModeSteer`)}
              </option>
              <option value="queue" ?selected=${n===`queue`}>
                ${S(`chat.followUpModeQueue`)}
              </option>
            </select>
            ${e.chatFollowUpModeOverridden?O`<button
                    type="button"
                    class="btn btn--sm"
                    @click=${e.resetChatFollowUpMode}
                  >
                    ${S(`chat.followUpModeReset`)}
                  </button>`:k}
          `})}
        ${K({title:S(`chat.catalogOpenTarget`),value:e.catalogOpenTarget,setting:`catalog-open-target`,description:O`${l}
          ${S(`quickSettings.personal.browserOnly`)}`,options:[{value:`viewer`,label:S(`chat.catalogOpenTargetViewer`)},{value:`terminal`,label:S(`chat.catalogOpenTargetTerminal`)}],onChange:t=>e.setCatalogOpenTarget(nn(t))})}
        ${e.setOpenLinksExternally?L({title:S(`configView.chatPrefs.openLinksExternally`),description:O`${S(`configView.chatPrefs.openLinksExternallyHint`)}<br />
                  ${S(`configView.chatPrefs.openLinksExternallyStorage`)}`,checked:e.openLinksExternally===!0,onChange:e.setOpenLinksExternally}):k}
        ${sl(e)} ${cl(e)}
        ${e.setComposerHoldToRecord?L({title:S(`chat.composer.holdToRecordSetting`),description:O`${S(`chat.composer.holdToRecordSettingDescription`)}<br />
                  ${u} ${S(`quickSettings.personal.browserOnly`)}`,checked:e.composerHoldToRecord??T.composerHoldToRecord,onChange:e.setComposerHoldToRecord}):k}
      </div>
    </section>
  `}function ul(e){if(!e.setLobsterPetVisits||!e.setLobsterPetSounds)return k;let t=e.lobsterPetVisits??T.lobsterPetVisits,n=e.lobsterPetSounds??T.lobsterPetSounds,r=o.find(t=>t.id===e.theme)??e.themeCatalog?.themes.find(t=>t.id===e.theme),i=Ce(r).mascot===`none`?O`<br />${S(`quickSettings.appearance.lobsterVisitsThemeHidden`,{theme:r?.source===`builtin`?S(`configView.themes.${r.id}.label`):r?.name??e.theme})}`:k,a=H(S(`common.enabled`),t!==T.lobsterPetVisits),s=H(S(`common.disabled`),n!==T.lobsterPetSounds),c=ci(),l=vi.filter(e=>c.has(e.id)).length;return O`
    <section class="settings-section">
      <div class="settings-section__header">
        <h2 class="settings-section__heading">${S(`quickSettings.appearance.lobsterdex`)}</h2>
      </div>
      <div class="settings-group">
        ${L({title:S(`quickSettings.appearance.lobsterVisits`),description:t?O`${S(`quickSettings.appearance.lobsterVisitsOn`)}<br />
                ${a}
                ${S(`quickSettings.personal.browserOnly`)}${i}`:O`${S(`quickSettings.appearance.lobsterVisitsOff`)}<br />
                ${a}
                ${S(`quickSettings.personal.browserOnly`)}${i}`,checked:t,onChange:t=>e.setLobsterPetVisits?.(t)})}
        ${L({title:S(`quickSettings.appearance.lobsterSounds`),description:n?O`${S(`quickSettings.appearance.lobsterSoundsOn`)}<br />
                ${s} ${S(`quickSettings.personal.browserOnly`)}`:O`${S(`quickSettings.appearance.lobsterSoundsOff`)}<br />
                ${s} ${S(`quickSettings.personal.browserOnly`)}`,checked:n,onChange:t=>e.setLobsterPetSounds?.(t),onAct:e=>{e&&xi()}})}
        ${B({title:S(`quickSettings.appearance.lobsterdex`),description:S(`quickSettings.appearance.lobsterdexSeen`,{seen:String(l),total:String(vi.length)}),stacked:!0,control:O`
            <div class="lobsterdex__gallery">
              <div class="lobsterdex">
                ${vi.map(e=>{let t=di(e),n=c.get(e.id),r=n!==void 0,i=n?.shinySeenAt!=null,a=r?n.name??li(e.id):`?`,o=i?`${a} ✦`:a,s=hi[e.id],l=r?s.flavor:s.hint,u=r&&n.firstSeenAt!==null?S(`quickSettings.appearance.lobsterdexFirstVisited`,{name:a,date:new Date(n.firstSeenAt).toLocaleDateString()}):null,d=[o,l,u].filter(e=>e!==null).join(`
`);return O`
                    <openclaw-tooltip>
                      <span
                        class="lobsterdex__mini lobster-pet--palette-${e.id} ${r?``:`lobsterdex__mini--unseen`}"
                        style=${fi(t)}
                        tabindex="0"
                        role="img"
                        aria-label=${d}
                      >
                        ${pi(t,{standalone:!0})}
                        ${i?O`<span class="lobsterdex__mini-star" aria-hidden="true">✦</span>`:k}
                      </span>
                      <span slot="content" class="lobsterdex__tooltip">
                        <strong>${o}</strong>
                        <span>${l}</span>
                        ${u?O`<span>${u}</span>`:k}
                      </span>
                    </openclaw-tooltip>
                  `})}
              </div>
              ${e.lobsterdexHref?O`<a
                      class="btn btn--sm lobsterdex__open"
                      href=${e.lobsterdexHref}
                      @click=${t=>{st(t)&&(t.preventDefault(),e.onOpenLobsterdex?.())}}
                      >${S(`quickSettings.appearance.lobsterdexOpen`)}</a
                    >`:k}
            </div>
          `})}
      </div>
    </section>
  `}function dl(e){let t=[...e.hiddenSessionCatalogIds].toSorted(),n=H(S(`common.enabled`),e.sidebarLiveActivity!==T.sidebarLiveActivity),r=e.setSessionDeleteConfirm,i=e.sessionDeleteConfirm??T.sessionDeleteConfirm,a=H(S(`common.enabled`),i!==T.sessionDeleteConfirm);return O`
    <section id=${Ue.sidebar} class="settings-section">
      <div class="settings-section__header">
        <h2 class="settings-section__heading">${S(`configView.sidebarPrefs.title`)}</h2>
      </div>
      <p class="settings-section__desc">${S(`configView.sidebarPrefs.hint`)}</p>
      <div class="settings-group">
        ${L({title:S(`configView.sidebarPrefs.liveActivity`),description:O`${S(`configView.sidebarPrefs.liveActivityHint`)}<br />
            ${n} ${S(`quickSettings.personal.browserOnly`)}`,checked:e.sidebarLiveActivity,onChange:e.setSidebarLiveActivity})}
        ${r?L({title:S(`configView.sidebarPrefs.deleteConfirm`),description:O`${S(`configView.sidebarPrefs.deleteConfirmHint`)}<br />
                  ${a} ${S(`quickSettings.personal.browserOnly`)}`,checked:i,onChange:r}):k}
      </div>
      ${t.length>0?O`
              <div class="settings-section__header settings-section__header--subsection">
                <h3 class="settings-section__heading">
                  ${S(`chat.sidebar.hiddenSessionSections`)}
                </h3>
              </div>
              <div class="settings-group">
                ${t.map(t=>B({title:e.hiddenSessionCatalogLabels.get(t)??t,description:S(`quickSettings.personal.browserOnly`),control:O`<button
                      type="button"
                      class="btn btn--sm"
                      @click=${()=>e.setSessionCatalogHidden(t,!1)}
                    >
                      ${S(`chat.sidebar.showSessionSection`)}
                    </button>`}))}
              </div>
            `:k}
      <div class="settings-section__header settings-section__header--subsection">
        <h3 class="settings-section__heading">${S(`configView.sessionObserver.title`)}</h3>
      </div>
      <p class="settings-section__desc">${S(`configView.sessionObserver.hint`)}</p>
      ${ps({enabled:e.sessionObserverEnabled!==!1,utilityModel:e.sessionObserverUtilityModel,resolvedUtilityModel:e.sessionObserverResolvedModel,models:e.sessionObserverModels??[],modelsUnavailable:e.sessionObserverModelsUnavailable===!0,disabled:e.sessionObserverDisabled===!0,onEnabledChange:t=>e.setSessionObserverEnabled?.(t),onUtilityModelChange:t=>e.setSessionObserverUtilityModel?.(t)})}
    </section>
  `}function fl(){return(fl=e((()=>{A(),a(),Jt(),si(),yi(),mi(),_i(),En(),V(),C(),rl(),rt(),hs(),_a()})))()}function pl(e,t){return(e===`custom`||e.includes(`/`))&&t!==e?O`<span class="settings-theme-card__icon" aria-hidden="true"
      >${w.download}</span
    >`:O`
    <span class="settings-theme-card__palette" aria-hidden="true">
      <span class="settings-theme-card__chip settings-theme-card__chip--accent"></span>
      <span class="settings-theme-card__chip settings-theme-card__chip--accent-2"></span>
      <span class="settings-theme-card__chip settings-theme-card__chip--bg"></span>
    </span>
  `}function ml(e){return e.hasCustomTheme&&e.customThemeLabel?e.customThemeLabel:S(`configView.appearance.importedTheme`)}function hl(){(typeof requestAnimationFrame==`function`?requestAnimationFrame:e=>window.setTimeout(()=>e(0),0))(()=>{let e=globalThis.document?.querySelector(`[data-custom-theme-import-input]`);e&&(typeof e.scrollIntoView==`function`&&e.scrollIntoView({block:`center`,behavior:ar()}),e.focus(),e.select())})}function gl(e,t){let n=Object.entries(At).map(([e,t])=>({value:e,label:e===`system`?S(`configView.appearance.fonts.system`):t.label,description:S(`configView.appearance.fontNotes.${e}`),labelStyle:`font-family: ${t.stack}`}));return O`
    <section id=${Ue.typography} class="settings-section">
      <div class="settings-section__header">
        <h2 class="settings-section__heading">${S(`configView.appearance.typography`)}</h2>
      </div>
      <div class="settings-group">
        ${[`ui`,`chat`].map(r=>{let i=r===`ui`,a=S(`configView.appearance.fonts.${r}`),o=Ot(t.id)[r];return B({title:a,description:il(i?e.fontUiProvenance:e.fontChatProvenance),stackedOnNarrow:!0,control:Kr({id:`settings-font-${r}`,label:a,value:(i?e.fontUi:e.fontChat)??`theme`,options:[{value:`theme`,label:S(`configView.appearance.fonts.themeDefault`),description:S(`configView.appearance.fonts.themeFace`,{theme:t.label,face:At[o].label}),labelStyle:`font-family: ${At[o].stack}`},...n],onOpen:Ct,onChange:t=>(i?e.setFontUi:e.setFontChat)(cn(t))})})})}
        <div class="settings-row settings-row--stacked">
          <div class="settings-typography-preview">
            <div class="settings-typography-preview__caption">
              ${S(`configView.appearance.fonts.previewCaption`)}
            </div>
            <p class="settings-typography-preview__prose">
              ${S(`configView.appearance.fonts.previewProse`)}
            </p>
            <code class="settings-typography-preview__code"
              >${S(`configView.appearance.fonts.previewCode`)}</code
            >
          </div>
        </div>
      </div>
    </section>
  `}function _l(e,t){let n=e.viewState,r=e.hasCustomTheme||e.customThemeImportExpanded===!0;r&&e.customThemeImportFocusToken!=null&&e.customThemeImportFocusToken!==n.lastCustomThemeImportFocusToken&&(n.lastCustomThemeImportFocusToken=e.customThemeImportFocusToken,hl());let i=ml(e),a=[...(e.themeCatalog?.themes.length?e.themeCatalog.themes:o).map(e=>({id:e.id,label:e.source===`builtin`?S(`configView.themes.${e.id}.label`):e.name,description:e.source===`builtin`?S(`configView.themes.${e.id}.description`):e.description})),{id:`custom`,label:e.hasCustomTheme?i:S(`configView.appearance.import`),description:e.hasCustomTheme?S(`configView.appearance.importedFrom`,{name:i}):S(`configView.appearance.importHint`)}],s=a.find(t=>t.id===e.theme),c=e.themeCatalog?.unavailableId===e.theme||e.theme.includes(`/`)&&!!e.themeCatalog?.themes.length&&!s,l=s??{id:T.theme,label:S(`configView.themes.claw.label`)},u=a.find(t=>t.id===e.themeResetValue)?.label??S(`configView.themes.claw.label`),d=e.themeModeResetValue===`light`?S(`common.light`):e.themeModeResetValue===`dark`?S(`common.dark`):S(`common.system`),ee=il(e.themeProvenance),f=il(e.themeModeProvenance),p=il(e.accentProvenance),m=e.accent===`theme`,h=m?void 0:e.accent,g=e.accent===e.accentResetValue||m&&e.accentResetValue===void 0,te=e.accentResetValue&&e.accentResetValue!==`theme`?e.accentResetValue:`var(--theme-chip-accent)`,ne=!(g||m||!e.accent||yl.some(t=>t.hex===e.accent)),_=yl.find(t=>t.hex!==void 0&&t.hex===e.accent),re=m?S(`configView.appearance.usingThemeAccent`):g?null:S(`configView.appearance.usingAccent`,{value:S(_?_.labelKey:`configView.appearance.customAccent`)});return O`
    <div class="settings-page" ${D({settingsPage:!0})}>
      ${al(e)}
      <section id=${Ue.theme} class="settings-section">
        <div class="settings-section__header">
          <h2 class="settings-section__heading">${S(`configView.appearance.theme`)}</h2>
        </div>
        <p class="settings-section__desc">
          ${S(`configView.appearance.chooseTheme`)}
          ${H(u,e.themeOverridden)}
          ${ee}
        </p>
        ${c?O`<p class="settings-section__desc" role="status">
                ${S(`configView.appearance.themeUnavailable`,{id:e.theme})}
              </p>`:k}
        ${e.themeCatalog?.error?O`<p class="settings-status settings-status--error" role="alert">
                ${e.themeCatalog.error}
                <button type="button" class="btn btn--sm" @click=${e.onRetryThemeCatalog}>
                  ${S(`common.retry`)}
                </button>
              </p>`:k}
        <div class="settings-group">
          <div class="settings-row settings-row--stacked">
            <div class="settings-theme-grid">
              ${a.map(t=>O`
                  <button
                    class="settings-theme-card settings-theme-card--${t.id.includes(`/`)?`custom`:t.id} ${t.id===l.id?`settings-theme-card--active`:``}"
                    aria-pressed=${t.id===`custom`&&!e.hasCustomTheme?k:String(t.id===l.id)}
                    title=${t.description}
                    data-theme-id=${t.id}
                    @click=${()=>{if(t.id===`custom`&&!e.hasCustomTheme){e.onOpenCustomThemeImport?.();return}(t.id!==e.theme||t.id===e.themeResetValue&&e.themeOverridden)&&e.setTheme(t.id)}}
                  >
                    ${pl(t.id,l.id)}
                    <span class="settings-theme-card__label">${t.label}</span>
                  </button>
                `)}
            </div>
          </div>
          ${B({title:S(`common.colorMode`),description:O`${H(d,e.themeModeOverridden)}
            ${f}`,stackedOnNarrow:!0,control:Ur({value:e.themeMode,options:[{value:`system`,label:S(`common.system`)},{value:`light`,label:S(`common.light`)},{value:`dark`,label:S(`common.dark`)}],ariaLabel:S(`common.colorMode`),onChange:t=>e.setThemeMode(t),onReselect:t=>{e.themeModeOverridden&&t===e.themeModeResetValue&&e.setThemeMode(t)}})})}
          <div class="settings-row settings-row--stacked">
            ${r?O`
                    <div class="settings-theme-import">
                      <div class="settings-theme-import__copy">
                        <div class="settings-theme-import__title">
                          ${S(`configView.appearance.importFromTweakcn`)}
                        </div>
                        <p class="settings-theme-import__hint">
                          ${S(`configView.appearance.tweakcnInstructions`)}
                        </p>
                      </div>
                      <a
                        class="settings-theme-import__external"
                        href="https://tweakcn.com/editor/theme"
                        target="_blank"
                        rel="noreferrer noopener"
                      >
                        ${S(`configView.appearance.browseTweakcn`)} ${w.externalLink}
                      </a>
                      <label class="settings-theme-import__field">
                        <span class="settings-theme-import__label"
                          >${S(`configView.appearance.themeLink`)}</span
                        >
                        ${t.customThemeImport}
                      </label>
                      <div class="settings-theme-import__actions">
                        <button
                          class="btn btn--sm primary"
                          ?disabled=${e.customThemeImportBusy||e.customThemeImportUrl.trim().length===0}
                          @click=${e.onImportCustomTheme}
                        >
                          ${e.customThemeImportBusy?S(`common.importing`):e.hasCustomTheme?S(`configView.appearance.replace`,{name:i}):S(`configView.appearance.importTheme`)}
                        </button>
                        ${e.hasCustomTheme?O`<button
                                class="btn btn--sm danger"
                                @click=${e.onClearCustomTheme}
                              >
                                ${S(`configView.appearance.clear`,{name:i})}
                              </button>`:k}
                      </div>
                      ${e.hasCustomTheme?O`<div class="settings-theme-import__meta">
                              <span class="settings-theme-import__meta-label"
                                >${S(`configView.appearance.loaded`)}</span
                              >
                              <span class="settings-theme-import__meta-value"
                                >${i} · ${e.customThemeSourceUrl??`tweakcn`}</span
                              >
                            </div>`:k}
                      ${e.customThemeImportMessage?O`<div
                              class="settings-theme-import__message settings-theme-import__message--${e.customThemeImportMessage.kind}"
                              role=${e.customThemeImportMessage.kind===`error`?`alert`:`status`}
                            >
                              ${e.customThemeImportMessage.text}
                            </div>`:k}
                    </div>
                  `:O`<p class="settings-theme-import__inline-hint">
                    ${S(`configView.appearance.inlineHintBefore`)}
                    <strong>${S(`configView.appearance.import`)}</strong>
                    ${S(`configView.appearance.inlineHintAfter`)}
                  </p>`}
          </div>
        </div>
      </section>

      <section id=${Ue.accent} class="settings-section">
        <div class="settings-section__header">
          <h2 class="settings-section__heading">${S(`configView.appearance.accent`)}</h2>
        </div>
        <p class="settings-section__desc">${S(`configView.appearance.accentHint`)}</p>
        <div class="settings-group">
          <div class="settings-row settings-row--stacked">
            <div class="settings-accent-swatches">
              ${yl.map(t=>{let n=t.hex===void 0,r=n?g:!g&&t.hex===e.accent,i=S(t.labelKey),a=n?` settings-accent-theme--${l.id.includes(`/`)?`custom`:l.id}`:``;return O`
                  <button
                    type="button"
                    class="settings-accent-swatch${a} ${r?`settings-accent-swatch--active`:``}"
                    style=${In({"--settings-accent-swatch":t.hex??te})}
                    data-accent-preset=${t.id}
                    aria-label=${i}
                    aria-pressed=${String(r)}
                    title=${i}
                    @click=${()=>e.setAccent(t.hex)}
                  >
                    ${n&&!g?O`<span class="settings-accent-swatch__reset" aria-hidden="true"
                            >${w.rotateCcw}</span
                          >`:r?O`<span class="settings-accent-swatch__check" aria-hidden="true"
                              >${w.check}</span
                            >`:k}
                  </button>
                `})}
              <span
                class="settings-accent-swatch settings-accent-swatch--custom ${ne?`settings-accent-swatch--active`:``}"
                style=${In({"--settings-accent-swatch":h??yl[1].hex,"--settings-accent-swatch-ink":Wt(h??yl[1].hex)})}
              >
                <input
                  type="color"
                  class="settings-accent-swatch__input"
                  data-accent-custom
                  aria-label=${S(`configView.appearance.customAccent`)}
                  aria-describedby="settings-accent-status"
                  title=${S(`configView.appearance.customAccent`)}
                  .value=${h??yl[1].hex}
                  @input=${t=>e.setAccent(t.currentTarget.value)}
                />
                <span class="settings-accent-swatch__picker" aria-hidden="true"
                  >${w.pipette}</span
                >
              </span>
            </div>
          </div>
        </div>
        <p id="settings-accent-status" class="settings-section__desc settings-accent-status">
          ${re?O`<span class="settings-accent-status__selection"
                  >${re}</span
                >`:k}
          <span class="settings-accent-status__scope">${p}</span>
        </p>
      </section>

      ${gl(e,l)}

      <section id=${Ue.textSize} class="settings-section">
        <div class="settings-section__header">
          <h2 class="settings-section__heading">${S(`configView.appearance.textSize`)}</h2>
        </div>
        <p class="settings-section__desc">
          ${H(`${T.textScale}%`,e.textScaleOverridden)}
          ${S(`quickSettings.personal.browserOnly`)}
        </p>
        <div class="settings-group">
          <div class="settings-row settings-row--stacked">
            <div class="settings-text-scale">
              <div class="settings-text-scale__options">
                ${yn.map(t=>O`
                    <button
                      type="button"
                      class="settings-text-scale__btn ${t===e.textScale?`active`:``}"
                      aria-pressed=${String(t===e.textScale)}
                      @click=${()=>e.setTextScale(t)}
                    >
                      <span class="settings-text-scale__sample">${S(vl[t])}</span>
                      <span class="settings-text-scale__label">${t}%</span>
                    </button>
                  `)}
              </div>
            </div>
          </div>
        </div>
      </section>

      ${dl(e)} ${ul(e)}
      ${ll(e,t.chatMessageWidth)} ${Fc(e)}

      <section id=${Ue.connection} class="settings-section">
        <div class="settings-section__header">
          <h2 class="settings-section__heading">${S(`configView.connection.title`)}</h2>
        </div>
        <div class="settings-group">
          ${B({title:S(`configView.connection.gateway`),control:R(e.gatewayUrl||`-`,{mono:!0})})}
          ${B({title:S(`configView.connection.status`),control:z({kind:e.connected?`ok`:`muted`,label:e.connected?S(`common.connected`):S(`common.offline`)})})}
          ${e.assistantName?B({title:S(`configView.connection.assistant`),control:R(e.assistantName)}):k}
        </div>
      </section>
    </div>
  `}var vl,yl;function bl(){return(bl=e((()=>{A(),Ln(),a(),Jt(),E(),ln(),Lt(),Pr(),V(),C(),rt(),Lc(),fl(),vl={90:`configView.textSizes.small`,100:`configView.textSizes.default`,110:`configView.textSizes.large`,125:`configView.textSizes.xl`,140:`configView.textSizes.xxl`},yl=[{id:`default`,hex:void 0,labelKey:`configView.appearance.accents.default`},{id:`claw`,hex:`#ff5c5c`,labelKey:`configView.appearance.accents.claw`},{id:`coral`,hex:`#ff8066`,labelKey:`configView.appearance.accents.coral`},{id:`amber`,hex:`#f5b942`,labelKey:`configView.appearance.accents.amber`},{id:`mint`,hex:`#52c99a`,labelKey:`configView.appearance.accents.mint`},{id:`teal`,hex:`#35b9b0`,labelKey:`configView.appearance.accents.teal`},{id:`blue`,hex:`#5b9cf6`,labelKey:`configView.appearance.accents.blue`},{id:`violet`,hex:`#a78bfa`,labelKey:`configView.appearance.accents.violet`},{id:`pink`,hex:`#f472b6`,labelKey:`configView.appearance.accents.pink`},{id:`slate`,hex:`#8795a8`,labelKey:`configView.appearance.accents.slate`}]})))()}function xl(e){return e.length>0?e.join(`.`):S(`configView.root`)}function Sl(e,t){let n=[],r=0;function i(e,t,r){n.length<jl&&n.push({path:e,from:t,to:r})}function a(e,t,n){if(e.length!==t.length||e.length>Ml)return!0;for(let r=0;r<e.length;r+=1)if(s(e[r],t[r],n+1))return!0;return!1}function o(e,t,n){let r=Object.keys(e),i=Object.keys(t);if(r.length!==i.length)return!0;for(let i of r)if(!Object.hasOwn(t,i)||s(e[i],t[i],n+1))return!0;return!1}function s(e,t,n){return r+=1,r>Al||n>kl?!0:e===t?!1:typeof e==typeof t?typeof e!=`object`||!e||t===null?e!==t:Array.isArray(e)||Array.isArray(t)?Array.isArray(e)&&Array.isArray(t)?a(e,t,n+1):!0:o(e,t,n+1):!0}function c(e,t,o,s){if(r+=1,r>Al||s>kl||n.length>=jl||e===t)return;if(typeof e!=typeof t||typeof e!=`object`||!e||t===null){i(o,e,t);return}if(Array.isArray(e)||Array.isArray(t)){(Array.isArray(e)&&Array.isArray(t)&&a(e,t,s+1)||!Array.isArray(e)||!Array.isArray(t))&&i(o,e,t);return}let l=e,u=t,d=new Set([...Object.keys(l),...Object.keys(u)]);for(let e of d)c(l[e],u[e],[...o,e],s+1)}return c(e,t,[],0),n}function Cl(e,t,n){if(e.rawDiffCache?.original===t&&e.rawDiffCache.current===n)return e.rawDiffCache.diff;if(t.length>Nl||n.length>Nl)return e.rawDiffCache={original:t,current:n,diff:[]},e.rawDiffCache.diff;try{let r=v(mt(t)),i=v(mt(n));if(!r||!i)return e.rawDiffCache={original:t,current:n,diff:[]},[];let a=Sl(r,i);return e.rawDiffCache={original:t,current:n,diff:a},a}catch{return ut()&&(e.rawDiffCache={original:t,current:n,diff:[]}),[]}}function wl(e,t=40){if(Array.isArray(e))return S(e.length===1?`configView.itemCount`:`configView.itemCountPlural`,{count:String(e.length)});let n;try{n=JSON.stringify(e)??String(e)}catch{n=String(e)}return n.length<=t?n:u(n,t-3)+`...`}function Tl(e,t){let n=e.split(`.`);return n.length===t.length&&n.every((e,n)=>e===`*`||e===t[n])}function El(e,t){return Object.entries(t).some(([t,n])=>!!n.sensitive&&Tl(t,e))}function Dl(e,t){for(let n=1;n<=e.length;n+=1){let r=e.slice(0,n),i=xl(r);if((at(r,t)?.sensitive??!1)||El(r,t)||ta(i))return!0}return!1}function Ol(e,t,n,r){let i=ra(t,e,n)>0;return!r&&t!=null&&(Dl(e,n)||i)?ia():wl(t)}var kl,Al,jl,Ml,Nl;function Pl(){return(Pl=e((()=>{ea(),na(),C(),lt(),kl=64,Al=2e4,jl=1e3,Ml=2e3,Nl=2e5})))()}function Fl(e){return Il.has(e)}var Il;function Ll(){return(Ll=e((()=>{Il=new Set([`defaults`,`modelByChannel`])})))()}function Rl(e,t){let n=Object.entries(e.properties??{}),r=n.filter(([e])=>!Fl(e)).map(([e,n])=>({key:e,label:xt([`channels`,e],t)?.label??n.title??bt(e),keys:[e]})).toSorted((e,t)=>e.label.localeCompare(t.label)||e.key.localeCompare(t.key)),i=n.filter(([e])=>Fl(e)).map(([e])=>e);return[...r,...i.length>0?[{key:null,label:S(`configView.categories.other`),keys:i}]:[]]}function zl(e){return Vl[e]??w.file}function Bl(e,t,n){return O`
    <div class="config-accordion-nav">
      ${t.map(t=>{let r=t.sections.some(t=>t.key===e.activeSection),i=`config-accordion-panel-${t.id}`;return O`
          <div class="config-accordion-group">
            <button
              class="config-accordion-group__header ${r?`config-accordion-group__header--active`:``}"
              aria-expanded=${r?`true`:`false`}
              aria-controls=${i}
              @click=${i=>{let a=t.sections[0]?.key??null;e.onSectionChange(r?null:a),n(i.currentTarget)}}
            >
              <span class="config-accordion-group__icon">
                ${zl(t.sections[0]?.key??`default`)}
              </span>
              <span>${t.label}</span>
              <svg
                class="config-accordion-group__chevron ${r?`config-accordion-group__chevron--open`:``}"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                width="14"
                height="14"
              >
                <polyline points="9 6 15 12 9 18"></polyline>
              </svg>
            </button>
            <div id=${i} class="config-accordion-group__items" ?hidden=${!r}>
              ${t.sections.map(t=>O`<button
                  class="config-accordion-group__item ${e.activeSection===t.key?`config-accordion-group__item--active`:``}"
                  aria-current=${e.activeSection===t.key?`true`:k}
                  @click=${r=>{e.onSectionChange(t.key),n(r.currentTarget)}}
                >
                  <span class="config-accordion-group__item-icon">
                    ${zl(t.key)}
                  </span>
                  ${t.label}
                </button>`)}
            </div>
          </div>
        `})}
    </div>
  `}var Vl,Hl,Ul;function Wl(){return(Wl=e((()=>{A(),Ll(),na(),Lt(),C(),Vl={all:w.layoutGrid,env:w.settings,update:w.download,agents:w.bot,auth:w.lock,channels:w.messageSquare,messages:w.mail,commands:w.terminal,hooks:w.link,skills:w.star,tools:w.wrench,gateway:w.globe,wizard:w.wandSparkles,meta:w.penLine,logging:w.fileText,browser:w.chrome,ui:w.panelsTopLeft,models:w.box,bindings:w.server,broadcast:w.radio,tts:w.music,transcripts:w.book,session:w.users,cron:w.clock,discovery:w.search,talk:w.mic,plugins:w.asterisk,diagnostics:w.activity,cli:w.terminal,secrets:w.key,acp:w.users,mcp:w.server,__appearance__:w.sun,__notifications__:w.bell},Hl=[{id:`core`,sections:[`env`,`auth`,`update`,`meta`,`logging`,`diagnostics`,`cli`,`secrets`,`wizard`]},{id:`ai`,sections:[`agents`,`models`,`skills`,`tools`,`memory`,`session`]},{id:`communication`,sections:[`channels`,`messages`,`broadcast`,`__notifications__`,`talk`,`tts`,`transcripts`]},{id:`security`,sections:[`security`,`approvals`]},{id:`automation`,sections:[`commands`,`hooks`,`bindings`,`cron`,`plugins`]},{id:`infrastructure`,sections:[`gateway`,`browser`,`nodeHost`,`discovery`,`acp`,`mcp`]},{id:`appearance`,sections:[`__appearance__`,`ui`]}],Ul=new Set(Hl.flatMap(e=>e.sections))})))()}function Gl(){return{rawRevealed:!1,rawDiffOpen:!1,envRevealed:!1,validityDismissed:!1,revealedSensitivePaths:new Set,lastCustomThemeImportFocusToken:null,lastConfigContextKey:null,lastFormModeForScroll:null}}function Kl(e){e.rawRevealed=!1,e.rawDiffOpen=!1,e.envRevealed=!1,e.validityDismissed=!1,e.revealedSensitivePaths.clear(),e.lastCustomThemeImportFocusToken=null,e.rawDiffCache=void 0}function ql(e){let t=e.includeSections?.join(``)??``,n=e.excludeSections?.join(``)??``;return[e.configPath??``,e.gatewayUrl,e.navRootLabel??``,t,n].join(``)}function Jl(e,t){let n=Qe(t);return n?e.revealedSensitivePaths.has(n):!1}function Yl(e,t){let n=Qe(t);n&&(e.revealedSensitivePaths.has(n)?e.revealedSensitivePaths.delete(n):e.revealedSensitivePaths.add(n))}function Xl(){return(Xl=e((()=>{na()})))()}function Zl(e){return _l(e,{chatMessageWidth:O`
      <input
        class="settings-input"
        data-settings-chat-message-width
        aria-label=${S(`configView.chatPrefs.messageWidth`)}
        type="text"
        spellcheck="false"
        placeholder="48rem"
        .value=${e.chatMessageMaxWidth??``}
        @change=${t=>{let n=t.currentTarget,r=wn(n.value);if(n.value.trim()&&!r){n.setCustomValidity(S(`configView.chatPrefs.messageWidthInvalid`)),n.reportValidity();return}n.setCustomValidity(``),n.value=r??``,e.setChatMessageMaxWidth(r)}}
      />
    `,customThemeImport:O`
      <input
        class="settings-theme-import__input"
        data-custom-theme-import-input
        type="text"
        spellcheck="false"
        placeholder="https://tweakcn.com/editor/theme?theme=... or amethyst-haze"
        .value=${e.customThemeImportUrl}
        @input=${t=>e.onCustomThemeImportUrlChange(t.currentTarget.value)}
      />
    `})}function Ql(e){let t=e.renderSection??(e=>e),n=e.viewState,r=e.showModeToggle??!1,i=e.showRootTab??!0,a=e.valid==null?`unknown`:e.valid?`valid`:`invalid`,o=e.includeVirtualSections??!0,s=e.includeSections?.length?new Set(e.includeSections):null,c=e.excludeSections?.length?new Set(e.excludeSections):null,l=jc(n,kc(e.schema),e.includeSections,e.excludeSections,s,c),u=l.unsupportedPaths.filter(t=>t!==`<root>`&&(!e.activeSection||t===e.activeSection||t.startsWith(`${e.activeSection}.`))&&Mc(e.formValue,t)),d=u.length>0,ee=e.forceShowAdvanced===!0||e.showAdvancedSettings,f=e.rawAvailable??!0,p=!!e.rawDraftPending&&f,m=r&&f?e.formMode:`form`,h=p?`raw`:m,g=e.onViewStateChange,te=e=>{queueMicrotask(()=>{let t=[(e instanceof Element?e:null)?.closest(`.config-lead`)?.parentElement?.querySelector(`.config-content`)??globalThis.document?.querySelector(`.config-content`),globalThis.document?.querySelector(`.shell--settings .content`)];for(let e of t)e&&(typeof e.scrollTo==`function`?e.scrollTo({top:0,left:0,behavior:`auto`}):(e.scrollTop=0,e.scrollLeft=0))})};n.lastFormModeForScroll!==null&&n.lastFormModeForScroll!==h&&te(null),n.lastFormModeForScroll=h;let ne=ql(e);n.lastConfigContextKey!==ne&&(Kl(n),n.lastConfigContextKey=ne);let _=n.envRevealed,re=l.schema?.properties??{},ie=new Set([`__appearance__`,`__notifications__`]),v=e=>o&&ie.has(e)&&(e===`__appearance__`||s?.has(e)===!0),ae=e=>S(`configView.sections.${e===`__appearance__`?`theme`:e===`__notifications__`?`notifications`:e}`),oe=Hl.map(e=>({id:e.id,label:S(`configView.categories.${e.id}`),sections:e.sections.filter(e=>(v(e)||e in re)&&(!s||s.has(e))&&(!c||!c.has(e))).map(e=>({key:e,label:ae(e)}))})).filter(e=>e.sections.length>0),se=Object.keys(re).filter(e=>!Ul.has(e)).map(e=>({key:e,label:e.charAt(0).toUpperCase()+e.slice(1)})),ce=se.length>0?{id:`other`,label:S(`configView.categories.other`),sections:se}:null,le=e.activeSection===`channels`?re.channels:void 0,y=le?Rl(le,e.uiHints):[],ue=y.find(t=>t.key===e.activeSubsection)??y[0],de=le&&ue?{...l.schema,properties:{...re,channels:{...le,properties:Object.fromEntries(Object.entries(le.properties??{}).filter(([e])=>ue.keys.includes(e))),required:le.required?.filter(e=>ue.keys.includes(e)),additionalProperties:!1}}}:l.schema,fe=de?.properties?.wizard,pe=fe&&(!e.activeSection||e.activeSection===`wizard`),me=fe?{...de,properties:Object.fromEntries(Object.entries(de.properties??{}).filter(([e])=>e!==`wizard`))}:de,he=[...oe,...ce?[ce]:[]],ge=[...i?[{key:null,label:e.navRootLabel??S(`nav.settings`)}]:[],...he.flatMap(e=>e.sections.map(e=>({key:e.key,label:e.label})))],_e=e.settingsLayout??`tabs`,ve=h===`raw`&&e.raw!==e.originalRaw;ve||(n.rawDiffOpen=!1),(!ve||!n.rawDiffOpen)&&(n.rawDiffCache=void 0);let ye=ve&&n.rawDiffOpen?Cl(n,e.originalRaw,e.raw):[];ve&&n.rawDiffOpen&&!ut()&&ft().then(()=>g()).catch(()=>void 0);let be=e.loading||e.saving||e.applying||e.updating,xe=e.mutationAllowed!==!1,Se=e.connected&&xe&&!be&&ve,Ce=o&&h===`form`&&e.activeSection===null&&!!s?.has(`__appearance__`),we=ve?O`<details
        class="config-diff"
        ?open=${n.rawDiffOpen}
        @toggle=${e=>{let t=e.target;n.rawDiffOpen!==t.open&&(n.rawDiffOpen=t.open,t.open||(n.rawDiffCache=void 0),g())}}
      >
        <summary class="config-diff__summary">
          <span>${S(`configView.viewPendingChangesRaw`)}</span>
          <svg
            class="config-diff__chevron"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <polyline points="9 6 15 12 9 18"></polyline>
          </svg>
        </summary>
        <div class="config-diff__content">
          ${ye.length>0?ye.map(t=>O`<div class="config-diff__item">
                    <div class="config-diff__path">${xl(t.path)}</div>
                    <div class="config-diff__values">
                      <span class="config-diff__from"
                        >${Ol(t.path,t.from,e.uiHints,n.rawRevealed)}</span
                      >
                      <span class="config-diff__arrow">→</span>
                      <span class="config-diff__to"
                        >${Ol(t.path,t.to,e.uiHints,n.rawRevealed)}</span
                      >
                    </div>
                  </div>`):O`<div class="config-diff__item">${S(`configView.rawDiffUnavailable`)}</div>`}
        </div>
      </details>`:k,Te=_e!==`accordion`&&ge.length>1,Ee=Te?Vr({id:`config-sections`,active:e.activeSection??`root`,tabs:ge.map(e=>({value:e.key??`root`,label:e.label})),ariaLabel:S(`common.settingsSections`),panelId:`config-section-panel`,onSelect:t=>e.onSectionChange(t===`root`?null:t),onActivate:te}):k,De=r||Te,Oe=a===`invalid`&&!n.validityDismissed,ke=De||_e===`accordion`||Oe||!!ue,Ae=O`<div class="config-lead">
    ${De?O`<div class="config-toolbar">
            ${r?Ur({mode:`buttons`,variant:`primary`,value:h,onChange:e.onFormModeChange,onReselect:e.onFormModeChange,options:[{value:`form`,label:S(`configView.form`),disabled:e.schemaLoading||!e.schema||p,title:p?S(`configView.rawDraftPendingFormTitle`):d?S(`configView.formUnsafeTitle`):``},{value:`raw`,label:S(`configView.raw`),disabled:!f,title:S(f?`configView.rawTitle`:`configView.rawUnavailableTitle`)}]}):k}
            ${Ee}
          </div>`:k}
    ${_e===`accordion`?Bl(e,he,te):k}
    ${ue&&h===`form`?O`<div class="config-toolbar">
            <label class="field">
              <span>${S(`configView.channelSettings`)}</span>
              <select
                class="settings-select"
                .value=${ue.key??``}
                @change=${t=>{let n=t.currentTarget;e.onSubsectionChange(n.value||null),te(t.currentTarget)}}
              >
                ${y.map(e=>O`<option
                      value=${e.key??``}
                      ?selected=${e.key===ue.key}
                    >
                      ${e.label}
                    </option>`)}
              </select>
            </label>
          </div>`:k}
    ${Oe?O`<div class="config-validity-warning">
            <svg
              class="config-validity-warning__icon"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              width="16"
              height="16"
            >
              <path
                d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"
              ></path>
              <line x1="12" y1="9" x2="12" y2="13"></line>
              <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
            <span class="config-validity-warning__text">${S(`configView.invalidConfig`)}</span>
            <button
              class="btn btn--sm"
              @click=${()=>{n.validityDismissed=!0,g()}}
            >
              ${S(`configView.dismissWarning`)}
            </button>
          </div>`:k}
  </div>`;return O`
    ${ke?Ae:k}
    <div
      id="config-section-panel"
      class="config-content"
      role=${Te?`tabpanel`:`region`}
      aria-labelledby=${Te?`config-sections-tab-${e.activeSection??`root`}`:k}
      aria-label=${Te?k:S(`common.settingsSections`)}
    >
      ${e.activeSection===`__appearance__`?o?Zl(e):k:e.activeSection===`__notifications__`?o?Cc(e):k:h===`form`?O`
                  ${d&&r&&f?O`<div class="config-content-callout">
                          <div class="callout info">
                            ${Nc(u)}
                            <button
                              type="button"
                              class="btn btn--sm"
                              @click=${()=>e.onFormModeChange(`raw`)}
                            >
                              ${S(`configView.openRawEditor`)}
                            </button>
                          </div>
                        </div>`:k}
                  ${Ce?Zl(e):k}
                  ${e.schemaLoading?O`<div class="config-loading">
                          <div class="config-loading__spinner"></div>
                          <span>${S(`configView.loadingSchema`)}</span>
                        </div>`:t(Yi({schema:me,uiHints:e.uiHints,value:e.formValue,embedded:e.embeddedEditor===!0||!!pe,rawAvailable:f,disabled:be||!e.formValue||!xe,unsupportedPaths:l.unsupportedPaths,onPatch:e.onFormPatch,onRemove:e.onFormRemove,activeSection:e.activeSection,activeSubsection:null,showAdvanced:ee,forceAdvancedSection:e.forceAdvancedSection,onShowAdvanced:()=>e.setShowAdvancedSettings(!0),onHideAdvanced:e.forceShowAdvanced?void 0:()=>e.setShowAdvancedSettings(!1),sectionActions:e.activeSection===`env`?O`<button
                                    class="btn btn--sm ${_?`active`:``}"
                                    aria-pressed=${_?`true`:`false`}
                                    title=${S(_?`configView.hideEnvValues`:`configView.revealEnvValues`)}
                                    @click=${()=>{n.envRevealed=!n.envRevealed,g()}}
                                  >
                                    ${_?w.eyeOff:w.eye}
                                    ${S(`configView.peek`)}
                                  </button>`:void 0,showSectionDocs:e.showSectionDocs,sectionPrelude:e.sectionPrelude,revealSensitive:e.activeSection===`env`&&_,isSensitivePathRevealed:e=>Jl(n,e),onToggleSensitivePath:e=>{Yl(n,e),g()}}))}
                  ${pe&&!e.schemaLoading?Ec(fe,e,be||!e.formValue||!xe):k}
                `:(()=>{let t=ra(e.formValue,[],e.uiHints),r=t>0&&!n.rawRevealed;return O`<div
                    class="settings-page"
                    ${D({settingsPage:!0})}
                  >
                    ${we}
                    <!-- Raw editor: one group surface owning file-level operations. -->
                    <div class="settings-group">
                      <div class="settings-row settings-row--stacked">
                        <div class="config-raw-actions">
                          ${e.onOpenFile&&e.openFileAllowed!==!1?O`<button class="btn btn--sm" @click=${e.onOpenFile}>
                                  ${w.fileText} ${S(`configView.open`)}
                                </button>`:k}
                          <button
                            class="btn btn--sm"
                            ?disabled=${be||!ve}
                            @click=${e.onRawDiscard}
                          >
                            ${S(`configView.rawDiscard`)}
                          </button>
                          <button
                            class="btn btn--sm primary"
                            ?disabled=${!Se}
                            aria-busy=${e.saving?`true`:`false`}
                            @click=${e.onSave}
                          >
                            ${e.saving?O`<span class="config-action-spinner" aria-hidden="true"
                                      >${w.loader}</span
                                    >${S(`common.saving`)}`:S(`common.save`)}
                          </button>
                        </div>
                        <div class="field config-raw-field">
                          <span style="display:flex;align-items:center;gap:8px;">
                            ${S(`configView.rawConfig`)}
                            ${t>0?O`<span class="settings-count"
                                      >${S(t===1?`configView.secretCount`:`configView.secretCountPlural`,{count:String(t)})}
                                      ${S(r?`configView.redacted`:`configView.visible`)}</span
                                    >
                                    <openclaw-tooltip
                                      .content=${S(r?`configView.revealSensitive`:`configView.hideSensitive`)}
                                    >
                                      <button
                                        class="btn btn--icon config-raw-toggle ${r?``:`active`}"
                                        aria-label=${S(`configView.toggleRawRedaction`)}
                                        aria-pressed=${!r}
                                        @click=${()=>{n.rawRevealed=!n.rawRevealed,g()}}
                                      >
                                        ${r?w.eyeOff:w.eye}
                                      </button>
                                    </openclaw-tooltip>`:k}
                          </span>
                          ${r?O`<div class="callout info" style="margin-top: 12px">
                                  ${S(t===1?`configView.sensitiveHidden`:`configView.sensitiveHiddenPlural`,{count:String(t)})}
                                </div>`:O`<textarea
                                  aria-label=${S(`configView.rawConfig`)}
                                  placeholder=${S(`configView.rawConfig`)}
                                  .value=${e.raw}
                                  ?disabled=${be||!xe}
                                  @input=${t=>{e.onRawChange(t.target.value)}}
                                ></textarea>`}
                        </div>
                      </div>
                    </div>
                  </div>`})()}
      ${e.issues.length>0?O`<div class="config-content-callout">
              <div class="callout danger">
                <pre class="code-block">
${Hn(Gr(JSON.stringify(e.issues,null,2)))}</pre>
              </div>
            </div>`:k}
    </div>
  `}function $l(){return($l=e((()=>{A(),Wn(),Jt(),E(),na(),$i(),Hr(),Lt(),En(),Dr(),V(),C(),G(),lt(),Tc(),Dc(),bl(),Pl(),Wl(),Pc(),Xl(),W(),ft().catch(()=>void 0)})))()}function eu(){return{devices:[],permissionRequired:!0,loading:!1,error:null,loaded:!1,requestsPermission:!1}}function tu(e){let t=Ai(e)?.[0]??null;if(t===null&&e!==`advanced`)throw Error(`Unknown config page`);return{activeSection:t,activeSubsection:null}}function nu(e,t,n){let r=Ai(e)??null;return e===`advanced`&&t&&Mi.has(t)?{activeSection:null,activeSubsection:null}:r&&(!t||!r.includes(t))?tu(e):{activeSection:t,activeSubsection:n}}function ru(e,t){let n=new URLSearchParams(t).get(`section`);return n?nu(e,n,null):tu(e)}function iu(e){switch(e){case`appearance`:return O`${S(`configView.appearance.intro`)}
      ${Yr(`https://docs.openclaw.ai/web/control-ui`)}`;case`mcp`:return Ka();case`security`:return O`${S(`quickSettings.security.intro`)}
      ${Yr(`https://docs.openclaw.ai/gateway/security`)}`;case`talk`:return O`${S(`talkPage.intro`)}
      ${Yr(`https://docs.openclaw.ai/nodes/talk`)}`;case`updates`:return S(`updates.page.intro`);default:return sn(e)}}function au(e){let t=v(e?.configForm)??v(e);if(!t)return{gatewayAuth:`unknown`,execPolicy:`unknown`,browserEnabled:!0,browserEnabledOverridden:!1,toolProfile:``,toolProfileOverridden:!1};let n=v(t.gateway),r=v(n?.auth),i=v(t.tools),a=v(i?.exec)??{},o=v(t.browser),s=`unknown`;r&&(s=(typeof r.mode==`string`?r.mode.trim():``)||(r.password?`password`:r.token?`token`:r.trustedProxy?`trusted-proxy`:`none`));let c=i?.profile,l=a.security;return{gatewayAuth:s,execPolicy:typeof l==`string`&&l.trim()?l.trim():`allowlist`,browserEnabled:o?.enabled!==!1,browserEnabledOverridden:o!==null&&Object.hasOwn(o,`enabled`),toolProfile:typeof c==`string`?c.trim():``,toolProfileOverridden:i!==null&&Object.hasOwn(i,`profile`)}}function ou(e){typeof document<`u`&&document.documentElement.style.setProperty(`--control-ui-text-scale`,(Dn(e)/100).toFixed(2))}var su,$;function cu(){return(cu=e((()=>{i(),hr(),A(),M(),Sn(),Gt(),kn(),Bt(),_n(),Rt(),On(),fn(),Jt(),on(),kt(),kr(),V(),Bi(),C(),G(),Zn(),_t(),et(),qn(),mr(),aa(),pr(),dt(),fr(),ct(),$r(),Zr(),ua(),Sa(),wa(),Ti(),Da(),za(),Va(),Ya(),to(),as(),Li(),rt(),cs(),hs(),vs(),Xs(),dc(),$l(),W(),su=new Map,$=class extends yt{constructor(...e){super(...e),this.pageId=`advanced`,this.routeData=null,this.settings=pn(),this.hiddenSessionCatalogIds=Br(),this.systemInfo=null,this.systemInfoUnavailable=!1,this.sessionObserverModels=[],this.sessionObserverModelsUnavailable=!1,this.mediaDeviceWatch=null,this.mediaDevices={microphone:eu(),camera:eu()},this.cameraSelectionRequest=0,this.formModes={},this.selections={},this.customThemeImport=Ta,this.customThemeImportOwner=new Ea(e=>{this.customThemeImport=e}),this.configViewState=Gl(),this.runtimeConfigSource=null,this.updateStatusClient=null,this.systemInfoPolling=new Qn(this,sa,()=>{this.systemInfoTask.status!==F.PENDING&&this.systemInfoTask.run()},!1,`visible`),this.updateCountdownPolling=new Qn(this,1e3,()=>this.requestUpdate(),!1),this.systemInfoTask=new gr(this,{autoRun:!1,args:()=>[this.gateway.gateway,this.systemInfoRequestClient()],task:([e,t],{signal:n})=>e&&t?oa(e,n).then(e=>e.value):Cr,onComplete:e=>{this.systemInfo=e,this.systemInfoPolling.stop(),this.systemInfoPolling.start(),this.sessionObserverModelsTask.status!==F.PENDING&&this.sessionObserverModelsTask.run()},onError:e=>{(Xe(e)||ca(e))&&(this.systemInfo=null,this.systemInfoUnavailable=!0,this.systemInfoPolling.stop())}}),this.sessionObserverModelsTask=new gr(this,{args:()=>[this.gateway.gateway,this.systemInfo?this.systemInfoRequestClient():null,this.context?.settingsAgentSelection.state.selectedId??null],task:async([e,t,n],{signal:r})=>{if(!e||!t||!n)return this.resetSessionObserverModels(!n),Cr;let i=this.sessionObserverModelsTask.value;(i?.gateway!==e||i.client!==t||i.agentId!==n)&&this.resetSessionObserverModels();let{models:a}=await or(t,{agentId:n,preparedOnly:!0,signal:r});return{gateway:e,client:t,agentId:n,models:a}},onComplete:({models:e})=>{this.sessionObserverModels=e,this.sessionObserverModelsUnavailable=!1},onError:()=>this.resetSessionObserverModels(!0)}),this.sessionSourcePluginsTask=new gr(this,{args:()=>{let e=this.context?.gateway.snapshot;return[this.gateway.gateway,this.pageId===`appearance`&&P(e,`plugins.list`,`operator.read`)?e?.client:null]},task:async([,e],{signal:t})=>{if(!e)return null;let n=await e.request(`plugins.list`,{},{signal:t});return new Set(n.plugins.filter(e=>e.installed).map(e=>e.id))}}),this.hiddenSessionCatalogLabelsTask=new gr(this,{args:()=>{let e=this.context?.gateway.snapshot,t=[...this.hiddenSessionCatalogIds].toSorted();return[this.pageId===`appearance`&&t.length>0&&P(e,`sessions.catalog.list`,`operator.read`)?e?.client:null,this.context?.settingsAgentSelection.state.selectedId??null,t.join(`\0`)]},task:async([e,t],{signal:n})=>{if(!e)return su;try{let r=await e.request(`sessions.catalog.list`,{...t?{agentId:t}:{},metadataOnly:!0},{signal:n});return new Map(r.catalogs.map(e=>[e.id,e.label]))}catch{return su}}}),this.routeTargetScroll=new Ca(this),this.gateway=new dr(this,{getGateway:()=>this.context?.gateway,invalidateRequests:()=>this.invalidateSystemInfoRequest(),onSnapshot:e=>this.handleGatewaySnapshot(e),onPageActivation:()=>this.syncSystemInfoPolling()}),this.subscriptions=new vt(this).watch(()=>this.context?.runtimeConfig,(e,t)=>e.subscribe(t),e=>this.synchronizeRuntimeConfig(e)).watch(()=>this.context?.overlays,(e,t)=>e.subscribe(t)).watch(()=>this.context?.config,(e,t)=>e.subscribe(t)).watch(()=>this.context?.settingsAgentSelection,(e,t)=>e.subscribe(t)).watch(()=>this.context?.nativeDeviceSettings??void 0,(e,t)=>e.subscribe(t)).watch(()=>this.context?.nativeNotifications??void 0,(e,t)=>e.subscribe(t)).watch(()=>this.context?.webPush,(e,t)=>e.subscribe(t)).watch(()=>this.context?.theme,(e,t)=>e.subscribe(t),()=>{this.settings=this.customThemeImportOwner.adoptSettings(this.settings,pn(),this.context.theme.serverSelection)}),this.hiddenSessionCatalogsChanged=()=>{this.hiddenSessionCatalogIds=Br()}}retireMediaPermissionRequests(){for(let e of Object.values(this.mediaDevices))e.requestsPermission=!1}connectedCallback(){super.connectedCallback(),this.hiddenSessionCatalogsChanged(),window.addEventListener(Xr,this.hiddenSessionCatalogsChanged),this.customThemeImportOwner.connect(this.context.gateway.connection.gatewayUrl,this.context.theme.serverSelection),this.settings=pn(),this.mediaDeviceWatch=ni(()=>{this.refreshMediaDevices(`microphone`,!1),this.refreshMediaDevices(`camera`,!1)}),this.syncRouteData()}disconnectedCallback(){window.removeEventListener(Xr,this.hiddenSessionCatalogsChanged),this.customThemeImportOwner.retireImport(),this.retireMediaPermissionRequests(),this.mediaDeviceWatch?.(),this.mediaDeviceWatch=null,this.systemInfoPolling.stop(),this.updateCountdownPolling.stop(),this.runtimeConfigSource=null,this.resetConfigViewState(),this.updateStatusClient=null,this.subscriptions.clear(),super.disconnectedCallback()}willUpdate(e){e.get(`pageId`)===`appearance`&&this.pageId!==`appearance`&&(this.customThemeImportOwner.retireImport(),this.retireMediaPermissionRequests()),(e.has(`pageId`)||e.has(`routeData`))&&this.syncRouteData()}updated(e){if(e.has(`pageId`)&&e.get(`pageId`)!==void 0&&this.invalidateSystemInfoRequest(),this.syncSystemInfoPolling(),this.syncUpdateStatusRefresh(),this.syncUpdateCountdownPolling(),this.pageId===`appearance`)for(let e of[`microphone`,`camera`])this.mediaDevices[e].loaded||(this.mediaDevices[e].loaded=!0,this.refreshMediaDevices(e,!1))}async refreshMediaDevices(e,t){let n=this.mediaDevices[e];if(n.loading){n.requestsPermission||=t;return}n.loading=!0,n.requestsPermission=t,n.error=null,this.requestUpdate();try{let t=await(e===`microphone`?ti:ri)(()=>n.requestsPermission);n.devices=t.devices,n.permissionRequired=t.permissionRequired,n.error=t.issue?ei(t.issue,e===`microphone`?`audioinput`:`videoinput`):null}catch(e){n.error=x(e)}finally{n.loading=!1,n.requestsPermission=!1,this.requestUpdate()}}syncRouteData(){let e=this.routeData?nu(this.pageId,this.routeData.section,null):ru(this.pageId,globalThis.location?.search??``);this.selections={...this.selections,[this.pageId]:e};let t=this.routeData?.targetBlockId??Ge(globalThis.location?.hash??``);this.routeTargetScroll.setTarget(t)}isSystemInfoVisible(){return this.pageId===`appearance`}syncUpdateCountdownPolling(){let e=this.context?.overlays.snapshot.updateSchedule?.campaign;if(this.pageId===`updates`&&(e?.state===`countdown`||e?.state===`waiting-for-idle`)){this.updateCountdownPolling.start();return}this.updateCountdownPolling.stop()}syncUpdateStatusRefresh(){let e=this.context.gateway.snapshot,t=this.pageId===`updates`&&e.phase===`connected`&&P(e,`update.status`,`operator.admin`)?e.client:null;t!==this.updateStatusClient&&(this.updateStatusClient=t,t&&this.context.overlays.refreshUpdateStatus())}synchronizeRuntimeConfig(e){e!==this.runtimeConfigSource&&(this.runtimeConfigSource&&this.customThemeImportOwner.retireImport(),this.runtimeConfigSource=e,this.resetConfigViewState());let t=e.state;if(!t.configSnapshot&&!t.configLoading){e.ensureLoaded().then(()=>this.runtimeConfigSource===e&&this.pageId!==`updates`?e.ensureSchemaLoaded():void 0).catch(()=>void 0);return}this.pageId!==`updates`&&!t.configSchema&&!t.configSchemaLoading&&e.ensureSchemaLoaded().catch(()=>void 0)}resetConfigViewState(){this.configViewState=Gl()}handleGatewaySnapshot({snapshot:e,initial:t,sourceChanged:n,clientChanged:r}){this.customThemeImportOwner.synchronizeScope(this.context.gateway.connection.gatewayUrl,this.context.theme.serverSelection),(t||n)&&(this.systemInfoPolling.stop(),this.resetConfigViewState(),this.updateStatusClient=null),t||n||r?(this.systemInfo=null,this.systemInfoUnavailable=!1,this.resetSessionObserverModels()):e.phase!==`connected`&&(this.systemInfo=null),e.phase===`connected`&&e.hello&&(this.systemInfoUnavailable=!la(e.hello),this.systemInfoUnavailable&&(this.invalidateSystemInfoRequest(),this.systemInfo=null)),this.syncSystemInfoPolling(r),this.syncUpdateStatusRefresh()}syncSystemInfoPolling(e=!1){if(!this.systemInfoRequestClient()){this.systemInfoPolling.stop(),this.systemInfoTask.status===F.PENDING&&this.systemInfoTask.run([null,null]);return}(this.systemInfoPolling.start()||e)&&this.systemInfoTask.run()}invalidateSystemInfoRequest(){this.systemInfoTask.run([null,null]),this.sessionObserverModelsTask.run([null,null,null]),this.resetSessionObserverModels()}systemInfoRequestClient(){let e=this.gateway.gateway,t=e?.snapshot;return!e||!t||!this.isConnected||document.visibilityState===`hidden`||!this.isSystemInfoVisible()||this.context.gateway!==e||t.phase!==`connected`||!la(t.hello)||this.systemInfoUnavailable?null:t.client}resetSessionObserverModels(e=!1){this.sessionObserverModels=[],this.sessionObserverModelsUnavailable=e}setFormMode(e){this.formModes={...this.formModes,[this.pageId]:e}}setActiveSection(e){this.selections={...this.selections,[this.pageId]:{activeSection:e,activeSubsection:null}}}setActiveSubsection(e){this.selections={...this.selections,[this.pageId]:{...this.selections[this.pageId]??tu(this.pageId),activeSubsection:e}}}applySettings(e,t){this.settings=t?xn(t,e):Mt(e),ou(this.settings.textScale),this.context.theme.refresh()}setLocale(e){if(e===void 0){this.resetLocale();return}this.settings=Mt({locale:e}),ht.setLocale(e)}currentSyncedPref(e){let t=Ut(e);return Xt(this.context.runtimeConfig.state.configSnapshot?.config,e,this.context.gateway.connection.gatewayUrl,this.settings,{canSync:this.serverUiPrefsCanSync(t?e:void 0),profileId:t?this.context.gateway.snapshot?.selfUser?.id:void 0})}setFont(e,t){let n=this.currentSyncedPref(e);n.overridden&&t===n.resetValue?this.resetSyncedAppearancePref(e):this.applySettings({[e]:t})}serverUiPrefsCanSync(e){let t=this.context.runtimeConfig;if(!t.state.connected)return null;let n=this.context.gateway.snapshot;return(e===`fontUi`||e===`fontChat`)&&!n?.selfUser?!1:e&&n?.selfUser?$t(n.hello?.auth??null):t.canPatch!==!1}resetLocale(){this.settings=tn(`locale`,this.currentSyncedPref(`locale`),this.context.gateway.connection.gatewayUrl),St(this.settings.locale)?ht.setLocale(this.settings.locale):ht.useSystemLocale()}resetSyncedAppearancePref(e){this.settings=tn(e,this.currentSyncedPref(e),this.context.gateway.connection.gatewayUrl,this.context.gateway.snapshot?.selfUser?.id),this.context.theme.refresh()}setTheme(e){let t=this.currentSyncedPref(`theme`),n=t.overridden&&e===t.resetValue;this.customThemeImportOwner.recordActivation(n?null:e),Vt({currentTheme:jt(this.settings.theme,this.settings.themeMode),nextTheme:jt(e,this.settings.themeMode),applyTheme:()=>n?this.resetSyncedAppearancePref(`theme`):this.applySettings({},e)})}setThemeMode(e){let t=this.currentSyncedPref(`themeMode`);t.overridden&&e===t.resetValue?this.resetSyncedAppearancePref(`themeMode`):this.context.theme.setMode(e)}selectMicrophone(e){this.applySettings({realtimeTalkInputDeviceId:e.trim()||void 0})}async selectCamera(e){let t=++this.cameraSelectionRequest,n=e.trim()||void 0;this.mediaDevices.camera.error=null,this.requestUpdate();try{if(await Qr(n),t!==this.cameraSelectionRequest)return;this.applySettings({realtimeTalkVideoDeviceId:n})}catch(e){t===this.cameraSelectionRequest&&(this.mediaDevices.camera.error=x(e),this.requestUpdate())}}async importCustomTheme(){await this.customThemeImportOwner.import({config:this.context.runtimeConfig.state,hasCustomTheme:!!this.settings.customTheme,load:Fa,apply:(e,t)=>this.applySettings({customTheme:e},t?`custom`:this.settings.theme),messages:{blocked:e=>S(e===`loading`?`common.loading`:`common.unsavedChanges`),imported:e=>S(`configPage.themeImported`,{name:e})}})}clearCustomTheme(){this.customThemeImportOwner.clear({apply:()=>this.applySettings({customTheme:void 0},this.settings.theme===`custom`?`claw`:this.settings.theme),message:S(`configPage.themeRemoved`)})}isUpdateBusy(){let e=this.context.overlays.snapshot;return e.updateRunning||e.updateReconciliationPending}isCuratedConfigMutationDisabled(){let e=this.context.runtimeConfig.state;return!e.connected||e.configLoading||e.configSaving||e.configApplying||this.isUpdateBusy()||this.context.overlays.snapshot.updateStatusRefreshing||!this.context.runtimeConfig.canSet||!Yt(this.context.gateway.snapshot.hello?.auth??null)}renderAdvancedConfig(e){let t=this.context.runtimeConfig,n=t.state;if(this.pageId===`updates`)return uc({context:this.context,configObject:e,configBusy:this.isCuratedConfigMutationDisabled(),updateBusy:this.isUpdateBusy()});let r=Ai(this.pageId),i=this.pageId===`advanced`?[...Mi]:void 0,a=this.selections[this.pageId]??tu(this.pageId),o=nu(this.pageId,a.activeSection,a.activeSubsection),s=this.pageId===`mcp`?`mcp`:o.activeSection,c=Ht(this.context.gateway.snapshot),l=this.pageId===`mcp`?null:o.activeSubsection,u=v(e.gateway),d=v(u?.controlUi),ee=v(v(e.agents)?.defaults),f=this.currentSyncedPref(`theme`),p=this.currentSyncedPref(`themeMode`),m=this.currentSyncedPref(`accent`),h=this.currentSyncedPref(`locale`),g=this.currentSyncedPref(`chatSendShortcut`),te=this.currentSyncedPref(`chatFollowUpMode`),ne=!n.connected||n.configSaving||n.configApplying||this.isUpdateBusy()||this.context.overlays.snapshot.updateStatusRefreshing||!Yt(this.context.gateway.snapshot.hello?.auth??null),_={raw:n.configRaw,originalRaw:n.configRawOriginal,valid:n.configValid,issues:n.configIssues,loading:n.configLoading,saving:n.configSaving,applying:n.configApplying,updating:this.isUpdateBusy()||this.context.overlays.snapshot.updateStatusRefreshing,connected:n.connected,mutationAllowed:t.canSet,openFileAllowed:t.canOpenFile,schema:n.configSchema,schemaLoading:n.configSchemaLoading,uiHints:n.configUiHints,formMode:this.formModes[this.pageId]??`form`,rawDraftPending:n.configFormMode===`raw`&&n.configFormDirty,viewState:this.configViewState,rawAvailable:!!(n.configSnapshot?.config||n.configForm||n.configRaw),showModeToggle:this.pageId===`advanced`,formValue:n.configForm,originalValue:n.configFormOriginal,activeSection:s,activeSubsection:l,onRawChange:e=>{this.customThemeImportOwner.retireForConfigMutation(S(`common.unsavedChanges`)),t.setRaw(e)},onFormModeChange:e=>this.setFormMode(e),onViewStateChange:()=>this.requestUpdate(),onFormPatch:(e,n)=>{this.customThemeImportOwner.retireForConfigMutation(S(`common.unsavedChanges`)),t.patchForm(e,n)},onFormRemove:e=>{this.customThemeImportOwner.retireForConfigMutation(S(`common.unsavedChanges`)),t.removeFormValue(e)},onSectionChange:e=>this.setActiveSection(e),onSubsectionChange:e=>this.setActiveSubsection(e),onSave:()=>void t.save(),onRawDiscard:()=>void t.discardDraft(),onOpenFile:()=>void t.openFile(),theme:this.settings.theme,themeOverridden:f.overridden,themeProvenance:f.provenance,themeResetValue:f.resetValue??T.theme,themeMode:this.settings.themeMode,themeModeOverridden:p.overridden,themeModeProvenance:p.provenance,themeModeResetValue:p.resetValue??T.themeMode,accent:this.settings.accent,accentProvenance:m.provenance,accentResetValue:m.resetValue,fontUi:this.settings.fontUi,fontChat:this.settings.fontChat,fontUiProvenance:this.currentSyncedPref(`fontUi`).provenance,fontChatProvenance:this.currentSyncedPref(`fontChat`).provenance,setFontUi:e=>this.setFont(`fontUi`,e),setFontChat:e=>this.setFont(`fontChat`,e),systemLocale:ht.getSystemLocale(),localeOverride:St(h.value)?h.value:void 0,localeOverridden:h.overridden,localeProvenance:h.provenance,localeResetValue:St(h.resetValue)?h.resetValue:void 0,onLocaleChange:e=>this.setLocale(e),themeCatalog:this.pageId===`appearance`?this.context.theme.catalog:void 0,onRetryThemeCatalog:()=>this.context.theme.retryCatalog?.(),setTheme:e=>this.setTheme(e),setThemeMode:e=>this.setThemeMode(e),setAccent:e=>e===void 0?this.resetSyncedAppearancePref(`accent`):this.applySettings({accent:e}),hasCustomTheme:!!this.settings.customTheme,customThemeLabel:this.settings.customTheme?.label??null,customThemeSourceUrl:this.settings.customTheme?.sourceUrl??null,customThemeImportUrl:this.customThemeImport.url,customThemeImportBusy:this.customThemeImport.busy,customThemeImportMessage:this.customThemeImport.message,customThemeImportExpanded:this.customThemeImport.expanded,customThemeImportFocusToken:this.customThemeImport.focusToken,onCustomThemeImportUrlChange:e=>this.customThemeImportOwner.setUrl(e),onImportCustomTheme:()=>void this.importCustomTheme(),onClearCustomTheme:()=>this.clearCustomTheme(),onOpenCustomThemeImport:()=>this.customThemeImportOwner.open(),textScale:this.settings.textScale??T.textScale,textScaleOverridden:this.settings.textScale!==void 0,setTextScale:e=>this.applySettings({textScale:e===T.textScale?void 0:Dn(e)}),sidebarLiveActivity:this.settings.sidebarLiveActivity??T.sidebarLiveActivity,setSidebarLiveActivity:e=>this.applySettings({sidebarLiveActivity:e}),hiddenSessionCatalogIds:this.hiddenSessionCatalogIds,hiddenSessionCatalogLabels:this.hiddenSessionCatalogLabelsTask.status===F.COMPLETE?this.hiddenSessionCatalogLabelsTask.value??su:su,setSessionCatalogHidden:Nr,...Ba(this.settings,e=>this.applySettings(e)),showAdvancedSettings:this.settings.showAdvancedSettings===!0,setShowAdvancedSettings:e=>this.applySettings({showAdvancedSettings:e}),forceShowAdvanced:this.pageId===`advanced`,forceAdvancedSection:this.routeData?.advanced?this.routeData.section:null,sessionObserverEnabled:d?.sessionObserver!==!1,sessionObserverUtilityModel:typeof ee?.utilityModel==`string`?ee.utilityModel:void 0,sessionObserverResolvedModel:this.systemInfo?.defaultAgentUtilityModel,sessionObserverModels:this.sessionObserverModels,sessionObserverModelsUnavailable:this.sessionObserverModelsUnavailable,sessionObserverDisabled:ne,setSessionObserverEnabled:e=>{t.patch({raw:ls(e),note:S(`configView.sessionObserver.toggleNote`)})},setSessionObserverUtilityModel:e=>{t.patch({raw:us(e),note:S(`configView.sessionObserver.modelNote`)}).then(e=>{e&&this.systemInfoTask.run()})},lobsterPetVisits:this.settings.lobsterPetVisits??T.lobsterPetVisits,setLobsterPetVisits:e=>this.applySettings({lobsterPetVisits:e}),sessionDeleteConfirm:this.settings.sessionDeleteConfirm??T.sessionDeleteConfirm,setSessionDeleteConfirm:e=>this.applySettings({sessionDeleteConfirm:e}),lobsterPetSounds:this.settings.lobsterPetSounds??T.lobsterPetSounds,setLobsterPetSounds:e=>this.applySettings({lobsterPetSounds:e}),lobsterdexHref:Qt(`lobsterdex`,this.context.basePath),onOpenLobsterdex:()=>this.context.navigate(`lobsterdex`),chatSendShortcut:An(this.settings.chatSendShortcut),chatSendShortcutOverridden:g.overridden,chatSendShortcutProvenance:g.provenance,chatSendShortcutResetValue:g.resetValue??T.chatSendShortcut,setChatSendShortcut:e=>this.applySettings({chatSendShortcut:e}),chatFollowUpMode:this.settings.chatFollowUpMode,chatFollowUpModeOverridden:te.overridden,chatFollowUpModeProvenance:te.provenance,serverQueueMode:n.configSnapshot?rr(n.configSnapshot.runtimeConfig,{configNeedsApply:n.configNeedsApply}):void 0,setChatFollowUpMode:e=>this.applySettings({chatFollowUpMode:e}),resetChatFollowUpMode:()=>this.resetSyncedAppearancePref(`chatFollowUpMode`),catalogOpenTarget:nn(this.settings.catalogOpenTarget),pluginsHref:Qt(`plugin-settings`,this.context.basePath),installedSessionSourcePluginIds:this.sessionSourcePluginsTask.status===F.COMPLETE?this.sessionSourcePluginsTask.value:null,sessionSourcePluginsLoading:this.sessionSourcePluginsTask.status===F.PENDING,setCatalogOpenTarget:e=>this.applySettings({catalogOpenTarget:e}),microphone:{...this.mediaDevices.microphone,selectedDeviceId:this.settings.realtimeTalkInputDeviceId??``},composerHoldToRecord:this.settings.composerHoldToRecord!==!1,setComposerHoldToRecord:e=>this.applySettings({composerHoldToRecord:e}),onMicrophoneRefresh:()=>void this.refreshMediaDevices(`microphone`,!0),onMicrophoneSelect:e=>this.selectMicrophone(e),camera:{...this.mediaDevices.camera,selectedDeviceId:this.settings.realtimeTalkVideoDeviceId??``},onCameraRefresh:()=>void this.refreshMediaDevices(`camera`,!0),onCameraSelect:e=>void this.selectCamera(e),gatewayUrl:this.context.gateway.connection.gatewayUrl,assistantName:this.context.config.current.assistantIdentity.name,configPath:n.configSnapshot?.path??null,navRootLabel:this.pageId===`advanced`?void 0:Dt(this.pageId),showSectionDocs:this.pageId!==`communications`,renderSection:this.pageId===`communications`&&s===`transcripts`?e=>Za({mutationDisabled:this.isCuratedConfigMutationDisabled(),advancedExpanded:this.routeData?.advanced===!0||this.routeData?.targetBlockId===`config-section-transcripts`,editor:e}):this.pageId===`ai-agents`&&s===`session`?e=>_s({mutationDisabled:this.isCuratedConfigMutationDisabled(),advancedExpanded:this.routeData?.advanced===!0||this.routeData?.targetBlockId===`config-section-session`,editor:e}):void 0,sectionPrelude:s===`browser`&&c&&!It()?xa({enabled:this.settings.openLinksInControlUiBrowser===!0,onChange:e=>this.applySettings({openLinksInControlUiBrowser:e})}):void 0,showRootTab:!r?.length,includeSections:r?[...r]:void 0,excludeSections:i,includeVirtualSections:this.pageId===`appearance`||this.pageId===`notifications`,settingsLayout:this.pageId===`advanced`?`accordion`:void 0,nativeNotifications:this.context.nativeNotifications?.snapshot,onNativeNotificationsRequestPermission:()=>this.context.nativeNotifications?.requestPermission(),onNativeNotificationsSendTest:()=>this.context.nativeNotifications?.sendTest(),webPush:this.context.webPush.snapshot,onWebPushSubscribe:()=>void this.context.webPush.run({kind:`enable`}),onWebPushUnsubscribe:()=>void this.context.webPush.run({kind:`disable`}),onWebPushTest:()=>void this.context.webPush.run({kind:`test`}),onWebPushSetUserPreferences:e=>void this.context.webPush.run({kind:`set`,scope:`user`,preferences:e}),onWebPushSetDevicePreferences:e=>void this.context.webPush.run({kind:`set`,scope:`device`,preferences:e})};if(this.pageId===`mcp`)return qa({configObject:e,pluginsHref:Qt(`plugins`,this.context.basePath),editor:Ql({..._,activeSection:`mcp`,activeSubsection:null,showModeToggle:!1,embeddedEditor:!0,navRootLabel:`MCP`})});if(this.pageId===`memory`)return ts({configObject:e,mutationDisabled:this.isCuratedConfigMutationDisabled(),pluginsHref:Qt(`plugins`,this.context.basePath),memoryImportHref:Qt(`memory-import`,this.context.basePath),routeData:this.routeData,buildEditor:e=>Ql({..._,schema:Oi(_.schema,e),activeSection:`memory`,activeSubsection:null,showModeToggle:!1,embeddedEditor:!0,navRootLabel:S(`tabs.memory`)})});if(this.pageId===`talk`)return Gs({configObject:e,mutationDisabled:this.isCuratedConfigMutationDisabled(),buildEditor:()=>Ql({..._,activeSection:`talk`,activeSubsection:null,showModeToggle:!1,embeddedEditor:!0,navRootLabel:S(`tabs.talk`)})});if(this.pageId===`security`){let n=t.state,r=this.isCuratedConfigMutationDisabled();return ss({security:au(e),configBusy:r,canPairDevice:n.connected&&Yt(this.context.gateway.snapshot.hello?.auth??null),onPairMobile:()=>void this.context.overlays.openDevicePairSetup(),onBrowserEnabledToggle:e=>{if(e){t.removeFormValue([`browser`,`enabled`]);return}t.patchForm([`browser`,`enabled`],!1)},onToolProfileChange:e=>{t.patchForm([`tools`,`profile`],e)},editor:Ql({..._,embeddedEditor:!0})})}return Ql(_)}render(){let e=this.context.runtimeConfig.state,t=v(e.configForm??e.configSnapshot?.config)??{},n=this.renderAdvancedConfig(t);return O`
      ${this.pageId===`memory`?k:O`
              ${Ar({title:Dt(this.pageId),subtitle:iu(this.pageId)})}
            `}
      ${zi(n)}
    `}},b([Ve({context:Cn,subscribe:!0})],$.prototype,`context`,void 0),b([N({attribute:`page-id`})],$.prototype,`pageId`,void 0),b([N({attribute:!1})],$.prototype,`routeData`,void 0),b([j()],$.prototype,`settings`,void 0),b([j()],$.prototype,`hiddenSessionCatalogIds`,void 0),b([j()],$.prototype,`systemInfo`,void 0),b([j()],$.prototype,`systemInfoUnavailable`,void 0),b([j()],$.prototype,`sessionObserverModels`,void 0),b([j()],$.prototype,`sessionObserverModelsUnavailable`,void 0),b([j()],$.prototype,`formModes`,void 0),b([j()],$.prototype,`selections`,void 0),b([j()],$.prototype,`customThemeImport`,void 0),customElements.get(`openclaw-config-page`)||customElements.define(`openclaw-config-page`,$)})))()}cu();