const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./composer-draft-store.runtime-Df-g8rja.js","./plugin-contracts-runtime-DSgjMI0R.js","./markdown-runtime-Hc-lvqnn.js","./config-runtime-CgOgfOrG.js","./sidebar-update-runtime-BZGhWGH_.js","./control-ui-core-D-VUH4Gq.css","./control-ui-boot-shared-BJ_QKfFn.css","./sidebar-update-runtime-ah7rgQE7.css","./pasted-text-excerpt-DvJPa5Ex.js","./chat-diff-highlight.runtime-BtePPJGS.js","./dist-BwVqDVly.js","./code-language-DL6Hp5_V.js","./mcp-app-view-registration-CmvjRgVO.js","./canvas-widget-view-CeY5vbTq.js","./widget-sandbox-host-BrTUURIA.js","./chat-html-preview-element-Bq8JPIhe.js","./file-editor-view-FK2Mdezs.js"])))=>i.map(i=>d[i]);
import{n as e}from"./rolldown-runtime-8BhlS34s.js";import{Bi as t,Br as n,Et as r,Gi as i,Hi as a,Ii as o,Ji as s,Mi as c,Oa as l,Pa as u,Qt as d,Ti as f,Tt as p,Ui as m,Vi as h,Zt as g,_n as _,ca as v,di as y,eo as b,et as x,fn as S,hi as C,hn as w,ii as T,ka as E,ln as D,pn as O,qr as k,ro as ee,un as te,zi as ne,zr as re}from"./control-ui-foundation-C3MHh_P-.js";import{Al as ie,As as ae,At as oe,Bl as A,Bs as j,Cu as M,D as se,Di as ce,E as le,Fl as ue,Fs as de,Gl as N,Il as fe,Jr as pe,Kl as me,Ml as he,N as ge,Na as _e,Nc as ve,Ns as ye,P as be,Pc as xe,Pl as Se,Ql as Ce,R as we,Rl as Te,S as Ee,Sl as De,Su as P,T as F,Ul as Oe,Vc as ke,Wl as I,Xa as Ae,Zc as je,Zl as Me,al as Ne,an as Pe,bl as Fe,bs as Ie,c as Le,cc as Re,ci as ze,cn as Be,cr as Ve,cu as He,dl as Ue,ei as We,eu as Ge,ft as Ke,gl as qe,hu as L,i as Je,js as Ye,ks as Xe,kt as Ze,l as Qe,la as $e,li as et,lu as tt,ml as nt,n as rt,nl as it,nn as at,nu as ot,ol as st,on as ct,ou as lt,pa as ut,pu as dt,ql as ft,qr as pt,sc as mt,sn as ht,su as gt,tl as _t,tn as vt,tu as yt,u as bt,ui as xt,ut as St,uu as R,vl as Ct,zl as wt}from"./control-ui-core-pYNj5S1a.js";import{$ as Tt,O as Et,nt as Dt}from"./control-ui-boot-shared-DhhSjjdA.js";import{$i as Ot,$n as kt,$r as At,$t as jt,Ai as Mt,Ba as Nt,Bi as Pt,Br as Ft,Ci as It,Dn as Lt,Fa as Rt,Fi as zt,G as Bt,Gi as Vt,Ia as Ht,Ii as Ut,Ji as Wt,K as Gt,Li as Kt,Mi as qt,Oi as Jt,Qi as Yt,Qt as Xt,Si as Zt,Sn as Qt,St as $t,U as en,Ur as tn,Va as nn,Wi as rn,Xi as z,Yt as an,Zi as B,_r as on,at as sn,bn as cn,ca as ln,co as un,ea as dn,ei as fn,en as pn,er as mn,fn as hn,fr as gn,go as _n,ia as vn,ii as yn,ki as bn,mn as xn,mo as Sn,n as Cn,nn as wn,nr as Tn,qi as En,r as Dn,ri as On,rn as kn,rt as An,ta as jn,ti as Mn,tn as Nn,ua as Pn,vi as Fn,wi as V,wn as In,xt as Ln,yi as Rn,yn as zn,za as Bn,zi as Vn}from"./control-ui-core-D6clmJs8.js";import{$ as H,B as Hn,C as Un,F as U,I as Wn,M as W,Q as Gn,R as Kn,S as qn,T as Jn,V as Yn,X as G,Y as K,Z as Xn,_ as Zn,c as q,ct as J,d as Qn,g as $n,gt as er,i as tr,j as nr,k as rr,m as Y,mt as ir,nt as ar,o as or,p as sr,q as cr,r as lr,s as ur,t as dr,tt as fr,u as pr,ut as X,v as mr,x as hr,z as gr}from"./lit-runtime-DZL1fcCI.js";import{A as _r,O as vr,f as yr,p as br}from"./control-ui-boot-shared-CnK2ZXzW.js";import{A as xr,L as Sr,R as Cr,Ut as wr,Vt as Tr,j as Er,v as Dr}from"./control-ui-boot-shared-CES8Ypkl.js";import{c as Or,d as kr,l as Ar}from"./gateway-runtime-iOL78mIi.js";import{$o as jr,$r as Mr,$s as Nr,A as Pr,Ar as Fr,B as Ir,Bc as Lr,Bn as Rr,C as zr,Cc as Br,Cn as Vr,Cs as Hr,Ct as Ur,Dl as Wr,Dr as Gr,Ec as Kr,El as qr,En as Jr,Er as Yr,Fn as Xr,Fs as Zr,G as Qr,Gc as $r,Gs as ei,Hr as ti,Hs as ni,Ic as ri,In as ii,Is as ai,J as oi,Ji as si,Jr as ci,Js as li,K as ui,Kc as di,Kn as fi,Kr as pi,Ks as mi,Lc as hi,Ln as gi,Ls as _i,M as vi,Mn as yi,Ms as bi,N as xi,Nn as Si,Nt as Ci,O as wi,Oc as Ti,Or as Ei,Os as Di,Pn as Oi,Pt as ki,Qc as Ai,Qo as ji,Qr as Mi,Qs as Ni,Rc as Pi,Rs as Fi,S as Ii,Sc as Li,Ss as Ri,St as zi,T as Bi,Tc as Vi,Tr as Hi,Ts as Ui,U as Wi,Uc as Gi,Ur as Ki,Vc as qi,Vr as Ji,Vs as Yi,Wc as Xi,Wn as Zi,Wr as Qi,Ws as $i,Xc as ea,Xi as ta,Xn as na,Xr as ra,Xs as ia,Yn as aa,Yr as oa,Ys as sa,Zc as ca,Zn as la,Zr as ua,Zs as da,_ as fa,_a as pa,_n as ma,_r as ha,_s as ga,_t as _a,ac as va,al as ya,ao as ba,at as xa,b as Sa,bc as Ca,bi as wa,bn as Ta,bs as Ea,bt as Da,cc as Oa,cr as ka,dc as Aa,dl as ja,dn as Ma,dr as Na,ds as Pa,ei as Fa,el as Ia,et as La,fc as Ra,fn as za,fr as Ba,fs as Va,g as Ha,ga as Ua,gc as Wa,gi as Ga,gn as Ka,gs as qa,gt as Ja,h as Ya,hc as Xa,hn as Za,hr as Qa,ht as $a,ic as eo,il as to,io as no,j as ro,jr as io,k as ao,kl as oo,kn as so,kr as co,li as lo,lr as uo,ls as fo,m as po,mc as mo,mi as ho,mn as go,mr as _o,ms as vo,nc as yo,ni as bo,nl as xo,no as So,oc as Co,oi as wo,ol as To,oo as Eo,or as Do,p as Oo,pn as ko,pr as Ao,ps as jo,qc as Mo,qn as No,qr as Po,rc as Fo,rl as Io,ro as Lo,rr as Ro,sc as zo,si as Bo,sl as Vo,so as Ho,tc as Uo,ti as Wo,tl as Go,ts as Ko,uc as qo,ui as Jo,ul as Yo,ur as Xo,v as Zo,va as Qo,vc as $o,vr as es,vs as ts,w as ns,wc as rs,wr as is,wt as as,x as os,xc as ss,xi as cs,xr as ls,xs as us,xt as ds,y as fs,ya as ps,yc as ms,yi as hs,yn as gs,yr as _s,ys as vs,yt as ys,zc as bs,zn as xs}from"./control-ui-boot-shared-3Hl8ksFq.js";import{I as Ss,L as Cs,R as ws,V as Ts,W as Es,a as Ds,bt as Os,c as ks,d as As,f as js,i as Ms,l as Ns,n as Ps,o as Fs,p as Is,s as Ls,t as Rs,u as zs,z as Bs}from"./control-ui-boot-shared-D-LYw3KU.js";import{s as Vs}from"./control-ui-boot-shared-C-yZTZmO.js";import{$i as Hs,$r as Us,$t as Ws,A as Gs,Ar as Ks,B as qs,Ba as Js,Bo as Ys,Br as Xs,C as Zs,Ca as Qs,Cr as $s,Da as ec,Dr as tc,Ea as nc,Er as rc,Hr as ic,Jn as ac,Jr as oc,K as sc,Kn as cc,Lo as lc,Lr as uc,Mr as dc,N as fc,Ni as pc,Nr as mc,Oa as hc,Pa as gc,Qa as _c,Qi as vc,Qt as yc,R as bc,Ra as xc,Ro as Sc,Rr as Cc,S as wc,Sa as Tc,Ta as Ec,Tr as Dc,U as Oc,Ua as kc,Ur as Ac,V as jc,Va as Mc,Vr as Nc,Wr as Pc,Xa as Fc,Xr as Ic,Ya as Lc,Za as Rc,Zi as zc,Zr as Bc,_t as Vc,aa as Hc,an as Uc,ar as Wc,at as Gc,ba as Kc,bi as qc,br as Jc,ca as Yc,ci as Xc,ct as Zc,da as Qc,dr as $c,ea as el,ei as tl,en as nl,eo as rl,et as il,fa as al,fn as ol,fr as sl,hr as cl,in as ll,ir as ul,it as dl,jr as fl,jt as pl,k as ml,ka as hl,la as gl,li as _l,lr as vl,lt as yl,ma as bl,mr as xl,na as Sl,nn as Cl,no as wl,nt as Tl,oa as El,oi as Dl,on as Ol,or as kl,ot as Al,pa as jl,pn as Ml,pr as Nl,qn as Pl,rn as Fl,rr as Il,rt as Ll,sn as Rl,st as zl,tn as Bl,to as Vl,tt as Hl,ua as Ul,ur as Wl,ut as Gl,vn as Kl,wr as ql,xa as Jl,xr as Yl,yi as Xl,yn as Zl,za as Ql,zo as $l}from"./control-ui-boot-shared-DJ4XCcp6.js";import{$t as eu,At as tu,C as nu,Ct as ru,D as iu,Dt as au,Et as ou,Fn as su,In as cu,Jt as lu,Ln as uu,Mn as du,Nn as fu,O as pu,Ot as mu,Pn as hu,Qt as gu,Rn as _u,S as vu,St as yu,T as bu,Tn as xu,Tt as Su,Xt as Cu,Zt as wu,_ as Tu,_t as Eu,at as Du,bn as Ou,bt as ku,cn as Au,ct as ju,dt as Mu,fn as Nu,ft as Pu,gt as Fu,hn as Iu,ht as Lu,in as Ru,it as zu,jn as Bu,kt as Vu,ln as Hu,lt as Uu,mn as Wu,mt as Gu,n as Ku,nn as qu,nt as Ju,on as Yu,ot as Xu,pn as Zu,pt as Qu,qt as $u,r as ed,rn as td,rt as nd,st as rd,tn as id,un as ad,ut as od,v as sd,xt as cd,yn as ld}from"./control-ui-boot-shared-og7lWkK4.js";import{F as ud,I as dd,O as fd,a as pd,c as md,d as hd,gt as gd,ht as _d,i as vd,k as yd,l as bd,m as xd,n as Sd,o as Cd,p as wd,r as Td,s as Ed,u as Dd}from"./control-ui-boot-shared-TgR3hRAg.js";import{i as Od,n as kd,r as Ad,t as jd}from"./control-ui-boot-shared-vP4joK1k.js";import{$ as Md,An as Nd,C as Pd,Ci as Fd,Cr as Id,D as Ld,Dr as Rd,Er as zd,Gn as Bd,Hr as Vd,Kn as Hd,Pr as Ud,Q as Wd,Qn as Gd,Ti as Kd,Tr as qd,Yn as Jd,_ as Yd,at as Xd,bi as Zd,br as Qd,ct as $d,et as ef,gn as tf,gr as nf,it as rf,jr as af,k as of,kr as sf,mn as cf,nr as lf,nt as uf,or as df,ot as ff,sr as pf,tr as mf,un as hf,w as gf,wi as _f,wr as vf,zr as yf}from"./control-ui-boot-shared-DCY2wZcy.js";import"./css-chat-Ckz95ikh.js";import{a as bf,i as xf,n as Sf,o as Cf,r as wf,t as Tf}from"./chat-transcript-layout-hEyp1qZw.js";import"./css-chat-custodian-new-session-CbWc8vdc.js";function Ef(e){return e.trim().length===0?``:e}function Df(e){return{gatewayOwner:Wa(e.settings?.gatewayUrl).gatewayOwner,recoveryScope:e.client?.recoveryScope?.trim()??``,client:e.client}}function Of(e,t){return t.gatewayOwner===Wa(e.settings?.gatewayUrl).gatewayOwner&&t.recoveryScope===(e.client?.recoveryScope?.trim()??``)&&(t.client===e.client||e.client?.recoveryScopeReady===!0)}function kf(e,t){return E(t.sessionKey)||!!(e.selectedChatSessionIncognito&&e.sessionKey&&j(qe(e,e.sessionKey))===j(t))}function Af(){return(Af=e((()=>{l(),Aa(),it()})))()}function jf(e,t,n,r){if(!n?.draft&&!n?.goalMode&&!n?.replyTarget&&n?.draftRevision===void 0&&r.length===0){delete e.sessions[t];return}e.sessions[t]={...n?.awaitingDefaults?{awaitingDefaults:!0}:{},...n?.draft?{draft:n.draft}:{},...n?.draftMentions?{draftMentions:n.draftMentions}:{},...n?.goalMode?{goalMode:n.goalMode}:{},...n?.replyTarget?{replyTarget:n.replyTarget}:{},...n?.draftRevision===void 0?{}:{draftRevision:n.draftRevision},...r.length?{queue:r}:{},updatedAt:Date.now()}}function Mf(e){if(!e.id?.trim()||!e.text?.trim()&&!e.attachments?.length&&!e.attachmentPayload&&!e.attachmentStorageError||e.pendingRunId||e.sendState===`sending`&&!e.sendRunId)return null;let t=(e.attachments??[]).map(t=>{let{dataUrl:n,previewUrl:r,...i}=t;if(e.attachmentPayload)return i;let a=fu(t);return a?Object.assign(i,{dataUrl:a}):e.attachmentStorageError?i:null});return e.attachments?.length&&t.some(e=>e===null)?null:Pi({...e,attachments:t.length?t:void 0,...e.sendState===`waiting-model`?{sendError:ri}:{}})}function Nf(e,t){let n=Mf(e);return n?zo(n,t):null}function Pf(e,t,n){let r=Nf(t,n);return!!(r&&bs(e,r))}function Ff(e,t,n){let r=Nf(e,n);return!!(r&&JSON.stringify(r)===JSON.stringify(t))}function If(){return(If=e((()=>{hi(),Aa(),cu()})))()}function Lf(e){return JSON.stringify([e.gatewayOwner,e.recoveryScope])}function Rf(e){return JSON.stringify([e.gatewayOwner,e.recoveryScope,e.scopeKey])}function zf(e,t){let n=Lf(e);Gf.has(n)||(Gf.add(n),t())}function Bf(e,t,n,r,i){return JSON.stringify([e,n??null,r??[],i?[i.messageId,i.text,i.senderLabel??null,i.sourceMessageId??null]:null,t.map(e=>[e.id,e.mimeType,e.origin??null,e.fileName??``,e.sizeBytes??-1,e.browserAnnotation??null,e.selectionAnnotation??null])])}function Vf(e){return new Promise((t,n)=>{let r=new FileReader;r.addEventListener(`error`,()=>n(r.error??Error(`Blob read failed`)),{once:!0}),r.addEventListener(`load`,()=>typeof r.result==`string`?t(r.result):n(Error(`Blob read returned no data`)),{once:!0}),r.readAsDataURL(e)})}function Hf(e){let t=[];for(let n of e){let e=du(n);if(!e)return null;t.push({blob:e,mimeType:n.mimeType,...n.origin?{origin:n.origin}:{},...n.fileName?{fileName:n.fileName}:{},...typeof n.sizeBytes==`number`?{sizeBytes:n.sizeBytes}:{},...n.browserAnnotation?{browserAnnotation:{...n.browserAnnotation}}:{},...n.selectionAnnotation?{selectionAnnotation:{...n.selectionAnnotation}}:{}})}return t}async function Uf(e){return Promise.all(e.map(async({blob:e,selectionAnnotation:t,...n})=>{let r=Xi(t),i=e.type===n.mimeType?e:e.slice(0,e.size,n.mimeType);return{...n,id:Bu(),...n.browserAnnotation?{browserAnnotation:{...n.browserAnnotation}}:{},...r?{selectionAnnotation:r}:{},dataUrl:await Vf(i)}}))}async function Wf(e){let{writeDurableComposerDraft:t}=await Kf,n=e.storedAttachments===null;return{result:await t(e.scope,{revision:e.revision,text:n?``:e.text,...e.mentions?.length&&!n?{mentions:e.mentions}:{},...e.goalMode?{goalMode:e.goalMode}:{},...e.replyTarget?{replyTarget:e.replyTarget}:{},...e.modelSelection?{modelSelection:e.modelSelection}:{},attachments:e.storedAttachments??[]},{expectedRevision:e.expectedRevision,...e.expectedWriteId?{expectedWriteId:e.expectedWriteId}:{},...e.expectedWriteIds?.length?{expectedWriteIds:e.expectedWriteIds}:{},writeId:e.writeId}),payloadUnavailable:n}}var Gf,Kf,qf;function Jf(){return(Jf=e((()=>{Gi(),cu(),t(),Gf=new Set,Kf=ne(()=>import(`./composer-draft-store.runtime-Df-g8rja.js`),__vite__mapDeps([0,1,2,3,4,5,6,7]),import.meta.url),qf=class{constructor(e,t){this.onStorageError=e,this.onConflict=t,this.restoreGeneration=0,this.restoredScopeKey=``}resetRestoreScope(){this.restoreGeneration+=1,this.restoredScopeKey=``}persist(e){(async()=>{let{result:t,payloadUnavailable:n}=await Wf(e);n&&zf(e.scope,this.onStorageError),t.status===`storage-failed`||t.status===`payload-too-large`?zf(e.scope,this.onStorageError):t.status===`conflict`&&(this.resetRestoreScope(),this.onConflict())})()}retire(e,t){this.resetRestoreScope(),(async()=>{let{retireDurableComposerDraft:n}=await Kf;(await n(e,t)).status===`storage-failed`&&zf(e,this.onStorageError)})()}restore(e,t,n,r){let i=Rf(e);if(this.restoredScopeKey===i)return;let{onCurrentWins:a,...o}=t();this.restoredScopeKey=i;let s=++this.restoreGeneration;this.restoreScope({scope:e,...o},s,n,r,a)}async restoreScope(e,t,n,r,i){let{readDurableComposerDraft:a,prepareDurableComposerRecovery:o}=await Kf;if(e.scope.scopeKey.startsWith(`chat:v3:`)&&(await o(e.scope)).status===`storage-failed`){zf(e.scope,this.onStorageError);return}let s=await a(e.scope);if(s.status===`storage-failed`){zf(e.scope,this.onStorageError);return}let c=s.status===`found`?s.draft.revision:s.revision;if(c===void 0||c<e.latestRevision){this.isBaselineCurrent(e,t,n())&&i(c??0);return}let l=[];if(s.status===`found`)try{l=await Uf(s.draft.attachments)}catch{zf(e.scope,this.onStorageError);return}this.isBaselineCurrent(e,t,n())&&r({revision:c,text:s.status===`found`?s.draft.text:``,...s.status===`found`&&s.draft.mentions?{mentions:s.draft.mentions}:{},...s.status===`found`&&s.draft.goalMode?{goalMode:s.draft.goalMode}:{},...s.status===`found`&&s.draft.replyTarget?{replyTarget:s.draft.replyTarget}:{},attachments:l})}isBaselineCurrent(e,t,n){return t===this.restoreGeneration&&n.scope?.gatewayOwner===e.scope.gatewayOwner&&n.scope.recoveryScope===e.scope.recoveryScope&&n.scope.scopeKey===e.scope.scopeKey&&n.signature===e.signature&&n.revision===e.latestRevision}}})))()}function Yf(e,t){let n={snapshot:null,revisions:{committed:0,latestAttempt:0}},r=M();if(!r)return n;try{let n=Wa(e.settings?.gatewayUrl),i=mo(r,n);if(Xa(i,e))try{$o(r,n,i)}catch{}let a=j(t),o=i.sessions[a];if(o&&kf(e,t)&&qo(o))try{$o(r,n,i),Ra()}catch{}Vi(r,n.key,a,o?.draftRevision);let s=Li(r,n.key,a,o?.draftRevision),c=Ef(o?.draft??``);return!o||!c&&!o.goalMode&&!o.replyTarget&&!o.queue?.length?{snapshot:null,revisions:s}:{revisions:s,snapshot:{draft:c,...o.draftMentions?{mentions:o.draftMentions}:{},...o.goalMode?{goalMode:o.goalMode}:{},...o.replyTarget?{replyTarget:{...o.replyTarget}}:{},queue:(o.queue??[]).filter(t=>Ti(e,t)).map(e=>Nf(e,t)).filter(e=>e!==null)}}}catch{return n}}function Xf(e,t,n,r){let i=qe(e,e.sessionKey),a=Ef(e.chatMessage),o=e.chatGoalDraftMode?{...e.chatGoalDraftMode}:void 0,s=e.chatReplyTarget?{...e.chatReplyTarget}:void 0,c=Wr(e.chatMessage,e.chatMentions),l=(e.chatAttachments??[]).map(e=>Object.assign({},e,e.browserAnnotation?{browserAnnotation:Object.assign({},e.browserAnnotation)}:{},e.selectionAnnotation?{selectionAnnotation:Object.assign({},e.selectionAnnotation)}:{})),u=t?{scope:t,expectedRevision:r,revision:n,text:a,...c?{mentions:c}:{},...o?{goalMode:o}:{},...s?{replyTarget:s}:{},storedAttachments:Hf(l),writeId:`${n}:${Math.random().toString(36).slice(2)}`}:void 0;return{owner:Df(e),scope:i,incognito:kf(e,i),awaitingDefaults:!_t(e),sessionKey:e.sessionKey,chatMessage:a,...c?{mentions:c}:{},...o?{goalMode:o}:{},...s?{replyTarget:{...s}}:{},expectedDraftRevision:r,draftRevision:n,attachments:l,...u?{durable:u}:{}}}function Zf(){return(Zf=e((()=>{qr(),Kr(),Ca(),Aa(),it(),Af(),If(),Jf()})))()}function Qf(e,t){let n=qe(e,e.sessionKey),r=t??ss(Yf(e,n).revisions.latestAttempt);rs(M()??e,Wa(e.settings?.gatewayUrl).key,j(n),r)}function $f(e,t,n){let r=qe(e,t,n),{revisions:i}=Yf(e,r);return ms(M()??e,Wa(e.settings?.gatewayUrl).key,j(r),i.latestAttempt)}function ep(e,t,n){return Yf(e,qe(e,t,n)).revisions.latestAttempt}function tp(e,t,n){return Yf(e,qe(e,t,n)).revisions.committed}function np(e,t,n){return Yf(e,qe(e,t,n)).snapshot}function rp(e,t=e.sessionKey,n={}){return ip(e,Oa(e,t,n.agentId),n)}function ip(e,t,n={}){let r=M();if(!r||!t.scope.sessionKey.trim())return`storage-failed`;try{let i=Df(e),a=Wa(e.settings?.gatewayUrl),o=mo(r,a),s=j(t.scope),c=o.sessions[s]??null,l=t.incognito||kf(e,t.scope),u=l?``:Ef(Object.hasOwn(n,`draft`)?n.draft??``:e.chatMessage),d=l?null:Object.hasOwn(n,`goalMode`)?n.goalMode:e.chatGoalDraftMode,f=l?null:Object.hasOwn(n,`replyTarget`)?n.replyTarget:e.chatReplyTarget,p=Wr(u,Object.hasOwn(n,`mentions`)?n.mentions:e.chatMentions),m=c?.draftRevision;Vi(r,a.key,s,m);let{committed:h,latestAttempt:g}=Li(r,a.key,s,m),_=n.draftRevision??ss(g);if(!Number.isSafeInteger(_)||_<=0)return`conflict`;let v=Ef(c?.draft??``),y=v===u&&JSON.stringify(c?.draftMentions??[])===JSON.stringify(p??[])&&JSON.stringify(c?.goalMode??null)===JSON.stringify(d??null)&&JSON.stringify(c?.replyTarget??null)===JSON.stringify(f??null),b=n.expectedDraftRevision;if(!(b===void 0||h===b||m===_&&y)||_<g||m===_&&!y)return`conflict`;Br(r,a.key,s,_),o.sessions[s]={...t.awaitingDefaults?{awaitingDefaults:!0}:{},...u?{draft:u}:{},...p?{draftMentions:p}:{},...d?{goalMode:d}:{},...f?{replyTarget:{...f}}:{},draftRevision:_,...c?.queue?.length?{queue:c.queue}:{},updatedAt:Date.now()},$o(r,a,o);let x=mo(r,a).sessions[s];return x?.draftRevision===_&&(x.draft??``)===u&&JSON.stringify(x.draftMentions??[])===JSON.stringify(p??[])&&JSON.stringify(x.goalMode??null)===JSON.stringify(d??null)&&JSON.stringify(x.replyTarget??null)===JSON.stringify(f??null)?(!!(v||c?.replyTarget)!=!!(u||f)&&Ra(),!l&&Of(e,i)&&kf(e,t.scope)&&Yf(e,t.scope),`persisted`):(x?.draftRevision??0)>=_?`conflict`:`storage-failed`}catch{return`storage-failed`}}function ap(e,t=e.sessionKey,n={}){return rp(e,t,n)===`persisted`}function op(e,t,n,r){return sp(e,t,n,r)===`admitted`}function sp(e,t,n,r){let i=M();if(!i||!t.scope.sessionKey.trim())return`storage-failed`;try{let a=Wa(e.settings?.gatewayUrl),o=mo(i,a),s=t.scope,c=Nf(n,s);if(!c)return`storage-failed`;let l=Xa(o,e),u=j(s),d=o.sessions[u]??null,f=d?.queue??[];if(r&&!f.some(e=>e.id===r.id&&Pf(e,r.expected,s)))return`source-changed`;let p=f.filter(e=>e.id!==r?.id),m=p.find(e=>e.id===c.id);if(m)return Ff(m,c,s)?(l&&($o(i,a,o),Ra()),`admitted`):`storage-failed`;if(p.length>=50)return`full`;jf(o,u,d,[...p,c]),t.awaitingDefaults&&(o.sessions[u].awaitingDefaults=!0),$o(i,a,o);let h=mo(i,a).sessions[u]?.queue?.find(e=>e.id===c.id),g=!!(h&&Ff(h,c,s));return Ra(),g?`admitted`:`storage-failed`}catch{return`storage-failed`}}function cp(e,t,n,r){if(n.length===0)return!0;let i=M();if(!i||!t.trim()||n.some(({expected:e,next:t})=>e.id!==t.id))return!1;try{let a=Wa(e.settings?.gatewayUrl),o=mo(i,a),s={sessionKey:t,agentId:r??n[0].expected.agentId??n[0].next.agentId},c=j(s),l=o.sessions[c]??null,u=(l?.queue??[]).slice();for(let{expected:e,next:t}of n){let n=u.findIndex(t=>t.id===e.id),r=n>=0?u[n]:void 0,i=r&&Pf(r,e,s)?Nf(t,s):null;if(!i)return!1;u[n]=i}jf(o,c,l,u),$o(i,a,o),Ra();let d=mo(i,a).sessions[c]?.queue??[];return n.every(({next:e})=>{let t=Nf(e,s),n=d.find(t=>t.id===e.id);return!!(n&&t&&Ff(n,t,s))})}catch{return!1}}function lp(e,t,n,r,i){return cp(e,t,[{expected:n,next:r}],i)}function up(e,t,n,r,i){let a=M();if(!a||!t.trim()||!n.trim())return!1;try{let o=Wa(e.settings?.gatewayUrl),s=mo(a,o),c={sessionKey:t,agentId:i??r?.agentId},l=j(c),u=s.sessions[l]??null,d=u?.queue??[],f=d.findIndex(e=>e.id===n);if(f<0)return!0;let p=d[f];return!p||r&&!Pf(p,r,c)?!1:(jf(s,l,u,d.filter((e,t)=>t!==f)),$o(a,o,s),Ra(),!mo(a,o).sessions[l]?.queue?.some(e=>e.id===n))}catch{return!1}}function dp(e,t={}){e.chatMessage=Ef(e.chatMessage);let n=t.sessionKey??e.sessionKey,r=np(e,n);return r?(!kf(e,qe(e,n))&&(!t.preserveCurrent||!e.chatMessage&&!e.chatGoalDraftMode&&!e.chatReplyTarget)&&(e.chatMessage=Ef(r.draft),e.chatMentions=r.mentions,e.chatGoalDraftMode=r.goalMode??null,e.chatReplyTarget=r.replyTarget??null),(!t.preserveCurrent&&r.queue.length>0||e.chatQueue.length===0)&&(e.chatQueue=r.queue),!0):!1}var fp,pp,mp;function hp(){return(hp=e((()=>{qr(),hi(),Ca(),Aa(),it(),cu(),Zf(),Af(),If(),Jf(),Ui(),fp=200,pp=`Could not store the previous draft in browser storage. It remains available in this tab.`,mp=class{constructor(e){this.getState=e,this.timer=null,this.ready=!1,this.pending=null,this.publishing=!1,this.lastPersisted=null,this.committedDraftRevision=0,this.latestDraftRevision=0,this.durableRestoreProtected=!1,this.durableOwner=null,this.durableRetiredScopeKey=``,this.forceDurableOwnerRestore=!1,this.durablePersistence=new qf(()=>{let e=this.getState();e&&(e.lastError=pp,e.chatError=pp,e.requestUpdate?.())},()=>this.getState()?.requestUpdate?.())}get active(){return this.ready}get durableScope(){let e=this.getState();return e?this.resolveDurableScope(e):null}get draftRevision(){return this.latestDraftRevision}start(){let e=this.getState();if(!e)return;this.ready=!0,this.pending=null;let{revisions:t,snapshot:n}=Yf(e,qe(e,e.sessionKey));this.committedDraftRevision=t.committed,this.latestDraftRevision=t.latestAttempt,this.durableRestoreProtected=(e.chatAttachments?.length??0)>0||(n?.draft??``)!==e.chatMessage||JSON.stringify(n?.mentions??[])!==JSON.stringify(e.chatMentions??[])||JSON.stringify(n?.goalMode??null)!==JSON.stringify(e.chatGoalDraftMode??null)||JSON.stringify(n?.replyTarget??null)!==JSON.stringify(e.chatReplyTarget??null),this.durablePersistence.resetRestoreScope(),this.lastPersisted=this.snapshot(e,t.committed,t.committed),this.synchronizeDurablePersistence()}stop(){this.persistNow(),this.ready=!1,this.pending=null,this.clearTimer()}restore(e={}){let t=this.getState();if(!t)return!1;let n=dp(t,e);this.pending=null,this.clearTimer();let r=this.readDraftRevisions(t);return this.committedDraftRevision=r.committed,this.latestDraftRevision=r.latestAttempt,this.lastPersisted=this.snapshot(t,r.committed,r.committed),this.durableRestoreProtected=!1,this.durablePersistence.resetRestoreScope(),n}schedule(){let e=this.getState();if(!this.ready||!e)return;let t=this.isUnchanged(e);if(t&&!this.pending){this.clearTimer();return}if(!t||!this.pending||!this.matchesCurrentContent(this.pending,e)){let t=Math.max(this.latestDraftRevision,this.pending?.draftRevision??0),n=ss(t);this.latestDraftRevision=n,this.pending=this.snapshot(e,n,this.committedDraftRevision),Qf(e,n)}this.clearTimer(),this.timer=globalThis.setTimeout(()=>this.persistNow(),fp)}persistNow(){let e=this.getState();if(!this.ready||!e||this.publishing)return;let t=this.pending;if(!t){if(this.isUnchanged(e))return;t=this.snapshot(e,ss(this.latestDraftRevision),this.committedDraftRevision),this.latestDraftRevision=t.draftRevision}this.clearTimer(),this.persistSnapshot(e,t)}persistChangedState(){this.persistNow(),this.synchronizeDurablePersistence()}scopeForRouteSwitch(){let e=this.getState();return e?(this.pending??(this.isUnchanged(e)?this.lastPersisted:null))?.scope??qe(e,e.sessionKey):null}persistForRouteSwitchResult(){let e=this.getState();if(!e)return{status:`persisted`};let t=this.pending,n=!1;if(!t&&this.ready&&this.isUnchanged(e)){let r=this.lastPersisted;if(!r.chatMessage&&!r.goalMode&&!r.replyTarget&&r.attachments.length===0)return this.pending=null,this.clearTimer(),{status:`persisted`};let{revisions:i,snapshot:a}=Yf(e,r.scope),o=i.committed;if(r.attachments.length===0&&o===r.draftRevision&&a?.draft===r.chatMessage&&JSON.stringify(a?.mentions??[])===JSON.stringify(r.mentions??[])&&JSON.stringify(a?.goalMode??null)===JSON.stringify(r.goalMode??null)&&JSON.stringify(a?.replyTarget??null)===JSON.stringify(r.replyTarget??null))return this.pending=null,this.clearTimer(),{status:`persisted`};if(o!==r.draftRevision||a?.draft||a?.goalMode||a?.replyTarget||i.latestAttempt>r.draftRevision)return{status:`conflict`};t={...r,expectedDraftRevision:o,draftRevision:ss(Math.max(o,i.latestAttempt,this.latestDraftRevision))},this.latestDraftRevision=t.draftRevision,n=!0}else if(!t&&!this.ready&&!Ef(e.chatMessage)&&!e.chatGoalDraftMode&&!e.chatReplyTarget)return this.pending=null,this.clearTimer(),{status:`persisted`};return t??=this.snapshot(e,ss(this.latestDraftRevision),this.committedDraftRevision),this.latestDraftRevision=Math.max(this.latestDraftRevision,t.draftRevision),this.clearTimer(),this.persistSnapshot(e,t,n)}persistSnapshot(e,t,n=!1){this.pending=t,this.publishing=!0;let r;try{r=Of(e,t.owner)?ip(e,t,{draft:t.chatMessage,mentions:t.mentions,goalMode:t.goalMode??null,replyTarget:t.replyTarget??null,draftRevision:t.draftRevision,...n?{expectedDraftRevision:t.expectedDraftRevision}:{}}):`persisted`}finally{this.publishing=!1}return t.durable&&(t.incognito||Of(e,t.owner)&&kf(e,t.scope)?this.retireDurableScope(t.durable.scope,t.draftRevision):this.durablePersistence.persist(t.durable)),r===`persisted`&&this.pending===t?(this.pending=null,this.committedDraftRevision=t.draftRevision,this.latestDraftRevision=Math.max(this.latestDraftRevision,t.draftRevision),this.lastPersisted=t,{status:r}):r===`storage-failed`?{status:r,expectedDraftRevision:t.expectedDraftRevision,draftRevision:t.draftRevision}:{status:r}}clearTimer(){this.timer!==null&&(globalThis.clearTimeout(this.timer),this.timer=null)}isUnchanged(e){let t=this.lastPersisted;return!!(t&&t.sessionKey===e.sessionKey&&t.incognito===kf(e,t.scope)&&this.matchesCurrentContent(t,e))}matchesCurrentContent(e,t){return Bf(e.chatMessage,e.attachments,e.goalMode,e.mentions,e.replyTarget)===Bf(Ef(t.chatMessage),t.chatAttachments??[],t.chatGoalDraftMode,t.chatMentions,t.chatReplyTarget)}snapshot(e,t=this.latestDraftRevision,n=this.committedDraftRevision){return Xf(e,this.resolveDurableScope(e),t,n)}resolveDurableScope(e,t=qe(e,e.sessionKey)){return kf(e,t)?null:this.resolveConnectedDurableScope(e,t)??(this.durableOwner&&!e.connected&&this.durableOwner.client===e.client&&this.durableOwner.gatewayOwner===Wa(e.settings?.gatewayUrl).gatewayOwner?{...this.durableOwner,scopeKey:`chat:v3:${j(t)}`}:null)}resolveConnectedDurableScope(e,t=qe(e,e.sessionKey)){let n=e.client?.recoveryScope?.trim();return!e.connected||!e.client?.recoveryScopeReady||!n?null:{gatewayOwner:Wa(e.settings?.gatewayUrl).gatewayOwner,recoveryScope:n,scopeKey:`chat:v3:${j(t)}`}}retireDurableScope(e,t){let n=Rf(e);this.durableRetiredScopeKey!==n&&(this.durableRetiredScopeKey=n,this.durableOwner=null,this.forceDurableOwnerRestore=!1,this.durableRestoreProtected=!1,this.durablePersistence.retire(e,t))}synchronizeDurablePersistence(){let e=this.getState();if(!this.ready||!e||this.publishing)return;let t=this.resolveConnectedDurableScope(e);if(kf(e,qe(e,e.sessionKey))){t&&((!this.isUnchanged(e)||this.lastPersisted&&!Of(e,this.lastPersisted.owner))&&Yf(e,qe(e,e.sessionKey)),this.retireDurableScope(t,this.latestDraftRevision));return}this.durableRetiredScopeKey=``;let n=this.resolveDurableScope(e);if(!n)return;let r=this.durableOwner;if(this.durableOwner={client:e.client,gatewayOwner:n.gatewayOwner,recoveryScope:n.recoveryScope},r&&(r.gatewayOwner!==n.gatewayOwner||r.recoveryScope!==n.recoveryScope)){at(e.chatAttachments),e.chatMessage=``,e.chatMentions=[],e.chatGoalDraftMode=null,e.chatReplyTarget=null,e.chatAttachments=[],this.pending=null;let t=this.readDraftRevisions(e);this.committedDraftRevision=t.committed,this.latestDraftRevision=ss(t.latestAttempt),rp(e,e.sessionKey,{draft:``,goalMode:null,replyTarget:null,draftRevision:this.latestDraftRevision}),this.committedDraftRevision=this.latestDraftRevision,this.lastPersisted=this.snapshot(e,this.latestDraftRevision,this.latestDraftRevision),this.durableRestoreProtected=!1,this.forceDurableOwnerRestore=!0,this.durablePersistence.resetRestoreScope()}if(this.durableRestoreProtected){this.durableRestoreProtected=!1;let t=this.snapshot(e,ss(this.latestDraftRevision),this.committedDraftRevision);this.latestDraftRevision=t.draftRevision,this.persistSnapshot(e,t);return}this.durablePersistence.restore(n,()=>{let t=this.snapshot(e,this.latestDraftRevision,this.committedDraftRevision);return{latestRevision:this.forceDurableOwnerRestore?0:this.latestDraftRevision,signature:Bf(e.chatMessage,e.chatAttachments??[],e.chatGoalDraftMode,e.chatMentions,e.chatReplyTarget),onCurrentWins:n=>{this.forceDurableOwnerRestore=!1,t.durable&&(e.chatMessage||e.chatGoalDraftMode||e.chatReplyTarget||(e.chatAttachments?.length??0)>0)&&this.durablePersistence.persist({...t.durable,expectedRevision:n})}}},()=>({scope:this.resolveDurableScope(e),signature:Bf(e.chatMessage,e.chatAttachments??[],e.chatGoalDraftMode,e.chatMentions,e.chatReplyTarget),revision:this.forceDurableOwnerRestore?0:this.latestDraftRevision}),t=>{let n=this.forceDurableOwnerRestore;this.forceDurableOwnerRestore=!1;let r=e.chatAttachments??[];e.chatMessage=Ef(t.text),e.chatMentions=t.mentions,e.chatGoalDraftMode=t.goalMode??null,e.chatReplyTarget=t.replyTarget??null,e.chatAttachments=t.attachments,at(r);let i=n?ss(Math.max(this.latestDraftRevision,t.revision)):t.revision;this.committedDraftRevision=i,this.latestDraftRevision=i,this.lastPersisted=this.snapshot(e,i,i),rp(e,e.sessionKey,{agentId:qe(e,e.sessionKey).agentId,draft:e.chatMessage,mentions:e.chatMentions,goalMode:e.chatGoalDraftMode,replyTarget:e.chatReplyTarget,draftRevision:i}),n&&this.lastPersisted.durable&&this.durablePersistence.persist({...this.lastPersisted.durable,expectedRevision:t.revision}),e.requestUpdate?.()})}readDraftRevisions(e,t=qe(e,e.sessionKey)){return Yf(e,t).revisions}}})))()}function gp(e){let t=e?.archivedBy,n=t?.id?L(`sessionsView.archivedBy`,{name:t.label??t.id}):e?.archiveReason?Mi(e.archiveReason):void 0;return e?.archived&&e.archivedAt!==void 0&&n?{kind:`notice`,key:`archive:${e.sessionId??e.key}:${e.archivedAt}`,label:n,text:``,timestamp:e.archivedAt}:void 0}function _p(e){return H`
    <div
      class="chat-divider__rule"
      role=${e.compaction?`status`:`separator`}
      aria-live=${e.compaction?`polite`:G}
      aria-label=${e.metric?`${e.label}, ${e.metric}`:e.label}
    >
      <span class="chat-divider__line"></span>
      <span class="chat-divider__label">
        ${e.compaction?H`<span class="chat-compaction__glyph" aria-hidden="true">
                <span class="chat-compaction__line"></span>
                <span class="chat-compaction__line"></span>
                <span class="chat-compaction__line"></span>
                <span class="chat-compaction__line"></span>
                <span class="chat-compaction__line"></span>
                ${z.check}
              </span>`:e.icon?H`<span class="chat-divider__icon" aria-hidden="true"
                  >${dn[e.icon]}</span
                >`:G}
        <span class="chat-divider__title">${e.label}</span>
        ${e.metric?H`
                <span class="chat-divider__separator" aria-hidden="true">·</span>
                <span class="chat-divider__metric">${e.metric}</span>
              `:G}
      </span>
      <span class="chat-divider__line"></span>
    </div>
  `}function vp(e){return H`
    <div
      class="chat-divider ${e.compaction?`chat-compaction chat-compaction--${e.compaction}`:``}"
      data-chat-row-key=${e.key}
      data-ts=${String(e.timestamp)}
    >
      ${_p(e)}
      ${e.description?H`
              <div class="chat-divider__details">
                <span class="chat-divider__description">${e.description}</span>
              </div>
            `:G}
    </div>
  `}function yp(e){let t=e.text?H`
        <div class="chat-text chat-notice__body" dir=${ra(e.text)}>
          ${lr(Wc(e.text,{codeBlockChrome:`none`}))}
        </div>
      `:G;return H`
    <div
      class="chat-notice ${e.tone===`danger`?`chat-notice--danger callout danger`:``}"
      data-chat-row-key=${e.key}
      data-ts=${String(e.timestamp)}
      role=${e.tone===`danger`?`alert`:G}
    >
      ${e.label?_p({icon:e.icon,label:e.label}):G}
      ${e.collapsedBody&&e.text?H`
              <details class="chat-notice__collapse">
                <summary class="chat-notice__toggle">${L(`chat.systemNotice.showContent`)}</summary>
                ${t}
              </details>
            `:t}
    </div>
  `}function bp(){return(bp=e((()=>{K(),dr(),Yt(),B(),Il(),R(),Mr(),ua()})))()}function xp(e,t=0){if(e||t!==0)return JSON.stringify([t,e?.permissionMode,e?.permissionModePending,e?.execNode,e?.execCwd,e?.sessionRoot,e?.spawnedWorkspaceDir,e?.spawnedCwd,e?.worktree?.id])}function Sp(e,t){return`${e}\0${t}`}function Cp(e){let t=Jp.get(e);return t||(t={resources:new Map,children:new Set},Jp.set(e,t)),t}function wp(e,t){!t.owner&&t.children.size===0&&t.resources.size===0&&Jp.delete(e)}function Tp(e,t){if(e.subscribers.delete(t),e.subscribers.size>0)return;e.releaseAuthRecovery?.(),e.releaseAuthRecovery=void 0,Mp(e);let n=Sp(e.kind,e.cacheKey);qp.get(n)===e&&(qp.delete(n),e.retainUntil!==void 0&&e.retainUntil>Date.now()&&!e.discardWhenIdle&&!e.pending&&(qp.set(n,e),Op())),e.abortController?.abort(),e.abortController=void 0}function Ep(e,t){return qp.get(Sp(e,t))}function Dp(e,t,n,r=t,i){let a=Sp(e,t),o=Ep(e,t);o&&o.subscribers.size===0&&(o.discardWhenIdle||o.retainUntil!==void 0&&o.retainUntil<=Date.now())&&(qp.delete(a),o.abortController?.abort(),Mp(o),o=void 0),o||(o={kind:e,cacheKey:t,cacheScope:i,discardWhenIdle:!1,value:void 0,pending:void 0,subscribers:new Set,retryAttempted:!1,unavailableAt:void 0,abortController:void 0,refresh:void 0,retainUntil:void 0},qp.set(a,o));let s=!n||!o.subscribers.has(n);if(n){let t=Cp(n).resources,i=Sp(e,r),a=t.get(i);o.subscribers.add(n),a&&a!==o&&Tp(a,n),t.set(i,o)}if(i!==void 0&&s)for(let[t,n]of qp)n!==o&&n.kind===e&&n.cacheScope===i&&(n.discardWhenIdle=!0,n.subscribers.size===0&&!n.pending&&qp.delete(t));return o}function Op(){let e=[...qp.entries()].filter(([,e])=>e.retainUntil!==void 0&&e.subscribers.size===0);for(let[t]of e.slice(0,-64))qp.delete(t)}function kp(e){return qp.get(Sp(e.kind,e.cacheKey))===e}function Ap(){return Zp}function jp(e){if(kp(e)){Zp=(Zp+1)%(2**53-1);for(let t of Array.from(e.subscribers))e.subscribers.has(t)&&t()}}function Mp(e){e.refresh&&=(clearTimeout(e.refresh.timer),void 0)}function Np(e,t,n){if(e.refresh?.at===t||(Mp(e),t===void 0||e.subscribers.size===0))return;let r={at:t,timer:setTimeout(()=>{kp(e)&&e.refresh===r&&(e.refresh=void 0,n())},Math.max(0,t-Date.now()))};e.refresh=r}function Pp(e,t){let n=Cp(t);if(n.owner!==e){if(n.owner){let e=n.owner,r=Jp.get(e);r&&(r.children.delete(t),wp(e,r))}Cp(e).children.add(t),n.owner=e}}function Fp(e){let t=e&&Jp.get(e);if(e&&t){Jp.delete(e);for(let e of t.children)Fp(e);if(t.owner){let n=Jp.get(t.owner);n&&(n.children.delete(e),wp(t.owner,n))}for(let n of new Set(t.resources.values()))Tp(n,e)}}function Ip(){let e=[...qp.entries()].filter(([,e])=>e.kind===`managed-image`&&e.value===null&&e.subscribers.size===0&&!e.pending);for(let[t]of e.slice(0,-64))qp.delete(t)}function Lp(e){let t=Yp.get(e);if(t)return Yp.delete(e),Yp.set(e,t),t.url}function Rp(e){return Yp.get(e)?.blob}function zp(){for(;Yp.size>Xp;){let e=[...Yp].find(([,e])=>e.retainCount===0);if(!e)return;let[t,n]=e;Yp.delete(t);let r=Sp(`managed-image`,t),i=qp.get(r);i?.value===n.url&&i.subscribers.size===0&&qp.delete(r),URL.revokeObjectURL(n.url)}}function Bp(e){let t=Yp.get(e);if(!t)return;t.retainCount+=1;let n=!1;return()=>{if(n)return;n=!0;let t=Yp.get(e);t&&t.retainCount>0&&--t.retainCount,zp()}}function Vp(e,t){let n=URL.createObjectURL(t),r=Yp.get(e);return Yp.delete(e),Yp.set(e,{blob:t,url:n,retainCount:r?.retainCount??0}),r&&r.url!==n&&URL.revokeObjectURL(r.url),zp(),n}function Hp(e,t){return!e.some(e=>t.factIndex===void 0?e.factIndex===void 0&&e.url===t.url&&e.artifactId===t.artifactId&&e.alt===t.alt:e.factIndex===t.factIndex)&&(e.push(t),!0)}function Up(e){let t=e.mimeType?.split(`;`,1)[0]?.trim().toLowerCase()??``,n=!t||t===`application/octet-stream`;if(e.kind===`image`||e.kind===`document`&&(ia(e.url,t)||n&&ia(e.label,void 0)))return t===`image/svg+xml`||n&&(da(e.url,void 0)||da(e.label,void 0))?`svg`:`raster`}function Wp(e,t,n=Date.now()){let r=h(e),i=[],a=[],o=[],s=[],c=[],l=new Set,u=new Set,d=0,f,p=e=>e.type===`attachment_error`||!u.has(e.attachment.url)?(a.push(e),e.type===`attachment`&&u.add(e.attachment.url),!0):!1,m=e=>{if(e.url&&da(e.url,e.mimeType)){try{let t=new URL(e.url,window.location.href);if(t.protocol!==`http:`&&t.protocol!==`https:`||t.origin===window.location.origin)return}catch{return}return{type:`attachment`,attachment:{url:e.url,kind:`image`,label:e.fileName?.trim()||e.alt?.trim()||Nr(e.url),mimeType:e.mimeType??`image/svg+xml`,...e.artifactId===void 0?{}:{artifactId:e.artifactId},...e.sizeBytes===void 0?{}:{sizeBytes:e.sizeBytes}}}}},g=h(h(r.__openclaw).mediaImageLayout),_=Array.isArray(g.slots)?g.slots.map(h):[],v=_.length>0?new Set(_.map(e=>e.factIndex)):void 0,y=v!==void 0&&!(Array.isArray(g.suppressedFactIndexes)&&g.suppressedFactIndexes.length>0)&&_.every(e=>(e.kind===`inline`||e.kind===`offloaded`)&&typeof e.factIndex==`number`&&Number.isSafeInteger(e.factIndex)&&e.factIndex>=0)&&v.size===_.length,b=y?_.filter(e=>e.kind===`inline`):[],x=0;for(let e of t){if(e.type===`text`&&typeof e.text==`string`){let t=o.at(-1);t?.type===`text`?t.text+=`\n${e.text}`:o.push({type:`text`,text:e.text});continue}if(e.type===`attachment`||e.type===`attachment_error`){if(e.type===`attachment`&&(l.add(e.attachment.url),Up(e.attachment)===`raster`)){let t={...e.attachment,alt:e.attachment.label,fileName:e.attachment.label};i.push(t),o.push({type:`image`,image:t});continue}p(e),o.push(e);continue}if(e.type===`omitted_media`){x+=1;continue}if(e.type!==`image`)continue;if(e.expiresAtMs!==void 0){if(e.expiresAtMs<=n){d+=1;continue}f=Math.min(f??e.expiresAtMs,e.expiresAtMs)}let t=e.inlineSlot?b[x++]?.factIndex:void 0,r=[],a=new Set;for(let n of e.sources){let{url:e,dataUrl:i,preferData:s,mimeType:c,...u}=n;e!==void 0&&l.add(e);let d=m(n);d&&!a.has(d.attachment.url)&&(p(d),o.push(d),a.add(d.attachment.url));let f=s?i??(d?void 0:e):(d?void 0:e)??i;f===void 0?u.artifactId&&Hp(r,{...u,artifactId:u.artifactId}):Hp(r,{...u,url:f,...typeof t==`number`?{factIndex:t}:{}})}i.push(...r),o.push(...r.map(e=>({type:`image`,image:e})))}if(x!==b.length)for(let e of i)delete e.factIndex;for(let{path:t,mediaType:n,fileName:r,origin:a,sizeBytes:o,durationMs:u,width:d,height:f,factIndex:m}of eo(e)){if(!y&&l.has(t))continue;let e=Up({kind:`document`,url:t,label:r?.trim()||Nr(t),mimeType:n});if(e===`raster`){let e={url:t,fileName:r,sizeBytes:o,...y&&v.has(m)?{factIndex:m}:{}};Hp(i,e)&&!l.has(t)&&s.push(e)}else{let i={type:`attachment`,attachment:{url:t,kind:e===`svg`?`image`:sa(t,n)?`audio`:Ni(t,n)?`video`:`document`,label:r?.trim()||Nr(t),...a?{origin:a}:{},...typeof n==`string`?{mimeType:n}:{},...o===void 0?{}:{sizeBytes:o},...u===void 0?{}:{durationMs:u},...d===void 0?{}:{width:d},...f===void 0?{}:{height:f}}};p(i)&&!l.has(t)&&c.push(i)}}return{images:i,attachments:a,orderedContent:o,supplementalImages:s,supplementalAttachments:c,expiredPairingQrCount:d,nextPairingQrExpiresAt:f}}function Gp(e,t,n){if(!n)return;if(t===void 0){let t=Jp.get(n),r=Sp(`pairing-qr`,e),i=t?.resources.get(r);t&&i&&(t.resources.delete(r),Tp(i,n),wp(n,t));return}let r=Dp(`pairing-qr`,e,n);Np(r,t,()=>jp(r))}function Kp(e,t=_i(e).content){let{images:n,attachments:r}=Wp(e,t);return[...n.map(e=>e.fileName?.trim()||e.alt?.trim()||L(`chat.imageLightbox.untitled`)),...t.flatMap(e=>{if(e.type!==`omitted_media`)return[];let t=e.media.sizeBytes===void 0?L(`chat.attachments.omittedFromHistory`):L(`chat.attachments.omittedFromHistoryWithSize`,{size:ve(e.media.sizeBytes)});return[`${L(`chat.attachments.image`)} · ${t}`]}),...r.map(e=>e.attachment.label.trim()||L(`chat.attachments.attachedFile`))].join(`
`)}var qp,Jp,Yp,Xp,Zp;function Qp(){return(Qp=e((()=>{R(),xe(),Fo(),Zr(),li(),qp=new Map,Jp=new Map,Yp=new Map,Xp=64,Zp=0})))()}function $p(e){try{return P()?.getItem(e)===`1`}catch{return!1}}function em(e,t){let n=fm.get(e);if(n){n(t);return}e.remove()}function tm(e){for(let t of mm){let n=pm.get(t);n&&e instanceof Node&&e.contains(n)&&em(t)}}function nm(e){for(let t of mm){let n=pm.get(t);if(n&&e.contains(n)&&t.contains(document.activeElement))return!0}return!1}function rm(){let e=window.visualViewport,t=e?.offsetLeft??0,n=e?.offsetTop??0,r=e?.width??window.innerWidth??document.documentElement.clientWidth;return{bottom:n+(e?.height??window.innerHeight??document.documentElement.clientHeight),left:t,right:t+r,top:n}}function im(e,t,n){return n<t?t:Math.min(Math.max(e,t),n)}function am(e,t){let n=e.getBoundingClientRect(),r=t.getBoundingClientRect(),i=rm(),a=um,o=dm,s=i.right-i.left,c=i.bottom-i.top,l=Math.min(r.width,s-16),u=Math.min(r.height,c-16),d=n.top-i.top-a-o,f=i.bottom-n.bottom-a-o,p=d<u&&f>=d,m=im(n.right-l,i.left+a,i.right-a-l),h=im(p?n.bottom+o:n.top-o-u,i.top+a,i.bottom-a-u);t.style.left=`${Math.round(m)}px`,t.style.top=`${Math.round(h)}px`,t.dataset.placement=p?`below`:`above`}function om(e){let t=L(`chat.messages.rewind`);return H`
    <span class="chat-confirm-wrap chat-rewind-wrap">
      <openclaw-tooltip .content=${t}>
        <button
          class="chat-group-rewind"
          aria-label=${t}
          @click=${t=>sm(t.currentTarget,e)}
        >
          ${z.refresh}
        </button>
      </openclaw-tooltip>
    </span>
  `}function sm(e,t){cm(e,{action:t,confirmLabel:L(`chat.messages.rewind`),confirmText:L(`chat.messages.rewindConfirm`),preferenceName:lm})}function cm(e,t){if($p(t.preferenceName)){t.action();return}let n=e.closest(`.chat-confirm-wrap`);if(!n)return;let r=n,i=hm.get(r);if(i){em(i,{restoreFocus:!0});return}let a=document.createElement(`div`);a.className=`chat-confirm-popover`,a.setAttribute(`role`,`dialog`),a.setAttribute(`aria-modal`,`true`),a.setAttribute(`aria-label`,t.confirmText),a.innerHTML=`
    <p class="chat-confirm-popover__text"></p>
    <label class="chat-confirm-popover__remember">
      <input type="checkbox" class="chat-confirm-popover__check" />
      <span></span>
    </label>
    <div class="chat-confirm-popover__actions">
      <button class="chat-confirm-popover__cancel" type="button"></button>
      <button class="chat-confirm-popover__yes" type="button"></button>
    </div>
  `;let o=a.querySelector(`.chat-confirm-popover__text`),s=a.querySelector(`.chat-confirm-popover__remember span`),c=a.querySelector(`.chat-confirm-popover__cancel`),l=a.querySelector(`.chat-confirm-popover__yes`);o&&(o.textContent=t.confirmText),l&&(l.textContent=t.confirmLabel),s&&(s.textContent=L(`chat.messages.dontAskAgain`)),c&&(c.textContent=L(`common.cancel`)),r.ownerDocument.body.appendChild(a),pm.set(a,r),mm.add(a),hm.set(r,a),am(e,a);let u=a.querySelector(`.chat-confirm-popover__cancel`),d=a.querySelector(`.chat-confirm-popover__yes`),f=a.querySelector(`.chat-confirm-popover__check`),p=!1,m=null;function h(t){p||(p=!0,m?.disconnect(),document.removeEventListener(`click`,g,!0),document.removeEventListener(`contextmenu`,_,!0),window.removeEventListener(`keydown`,v,!0),fm.delete(a),pm.delete(a),mm.delete(a),hm.delete(r),a.remove(),t?.restoreFocus&&e.isConnected&&e.focus({preventScroll:!0}))}function g(t){let n=t.target;n instanceof Node&&!a.contains(n)&&!e.contains(n)&&h()}function _(e){let t=e.target;t instanceof Node&&!a.contains(t)&&h()}function v(e){e.key===`Escape`&&a.contains(document.activeElement)&&(e.preventDefault(),e.stopImmediatePropagation(),h({restoreFocus:!0}))}function y(e){if(e.key!==`Tab`)return;let t=f,n=d;e.shiftKey&&document.activeElement===t?(e.preventDefault(),n.focus()):!e.shiftKey&&document.activeElement===n&&(e.preventDefault(),t.focus())}fm.set(a,h),u.addEventListener(`click`,()=>h({restoreFocus:!0})),d.addEventListener(`click`,()=>{if(f.checked)try{P()?.setItem(t.preferenceName,`1`)}catch{}h(),t.action()}),a.addEventListener(`click`,e=>e.stopPropagation()),a.addEventListener(`keydown`,y),document.addEventListener(`contextmenu`,_,!0),window.addEventListener(`keydown`,v,!0),m=new MutationObserver(()=>{(!n.isConnected||!e.isConnected)&&h()}),m.observe(n.ownerDocument.body,{childList:!0,subtree:!0}),u.focus({preventScroll:!0}),requestAnimationFrame(()=>{!p&&a.isConnected&&(am(e,a),document.addEventListener(`click`,g,!0))})}var lm,um,dm,fm,pm,mm,hm;function gm(){return(gm=e((()=>{K(),B(),R(),$r(),di(),lm=`openclaw:skip-rewind-confirm`,um=8,dm=6,fm=new WeakMap,pm=new WeakMap,mm=new Set,hm=new WeakMap})))()}function _m(e,t=!1){let n=e.colorSeed%360;return H`
    <span
      class="chat-author-avatar__initials ${t?`chat-author-avatar__fallback`:``}"
      style=${`--chat-author-avatar-hue: ${n}`}
      aria-hidden="true"
    >
      ${e.initials}
    </span>
  `}function vm(e){return e.imageUrl?H`
    ${Vl({view:e,fallbackSelector:`.chat-author-avatar`,className:`chat-author-avatar__image`,ariaHidden:!0})}${_m(e.fallback,!0)}
  `:_m(e.fallback)}function ym(e,t=`chat-author-avatar`){let n=Lr(e);if(!e||!n)return G;if(e.identity?.type===`agent`){let r=jr(e);return H`<span class=${t} role="img" aria-label=${n} title=${n}>
      ${rl({id:e.identity.id,avatar:r.kind===`profile`?r.url:null})}
    </span>`}let r=wl(e),i=vm(r);return H`<span
    class=${Rc(`chat-author-avatar`,r)}
    role="img"
    aria-label=${n}
    title=${n}
  >
    ${i}
  </span>`}function bm(e,t){return e&&!t?`footer`:`gutter`}function xm(e,t,n=`user`){let r=H`<div
    class="chat-avatar ${n} chat-avatar--sender-initials"
    style=${`background: hsl(${e.fallback.colorSeed%360} 48% 42%)`}
    role="img"
    aria-label="${t}"
  >
    ${e.fallback.initials}
  </div>`;return e.imageUrl?H`<span class=${Rc(`chat-avatar-slot`,e)}>
    ${Vl({view:e,fallbackSelector:`.chat-avatar-slot`,className:`chat-avatar ${n}`,alt:t})}${r}
  </span>`:r}function Sm(){return(Sm=e((()=>{K(),_c(),qi(),ji()})))()}function Cm(e,t,n){let r=e.at(-1),i=r?.status===`failed`||r?.status===`blocked`,a=i?r:e.findLast(e=>e.status===`running`)??r;if(!a)return;let o=a.status;for(let r of t){let t=[...r.children];for(let i of t){if(n.get(i.card)===a){let t=n.get(r.card);t&&e.includes(t)&&(a=t)}t.push(...i.children)}}return a.title.trim()?{key:a.toolCallId??a.itemId,title:a.title,status:i?o:a.status}:void 0}var wm,Tm,Em;function Dm(){return(Dm=e((()=>{K(),$n(),sr(),wm=3e3,Tm=class extends Wn{constructor(...e){super(...e),this.scope=``,this.shownAt=0}render(e,t,n,r){let i=this.scope!==e;if(this.scope=e,i&&(this.shown=void 0),this.clearTimer(),this.pending=void 0,!t)return this.shown=void 0,H`<span class="chat-activity-group__label">${n}</span>`;let a=t.status===`failed`||t.status===`blocked`,o=wm-(Date.now()-this.shownAt);if(i||!this.shown||a||this.shown.key===t.key||o<=0)this.show(t);else{if(r&&this.shown){let e=r.find(e=>(e.toolCallId??e.itemId)===this.shown?.key);this.shown={...this.shown,status:e?.status}}this.pending=t,this.isConnected&&(this.timer=setTimeout(()=>{this.timer=void 0,this.pending&&(this.show(this.pending),this.pending=void 0,this.setValue(this.content()))},o))}return this.content()}show(e){(this.shown?.key!==e.key||this.shown.title!==e.title)&&(this.shownAt=Date.now()),this.shown=e}content(){let e=this.shown;return Y(e.title,H`<span class="chat-activity-group__label chat-activity-group__label--live"
        >${e.title}${e.status===`running`?`…`:``}</span
      >`)}clearTimer(){this.timer!==void 0&&(clearTimeout(this.timer),this.timer=void 0)}disconnected(){this.clearTimer()}reconnected(){this.pending&&(this.show(this.pending),this.pending=void 0,this.setValue(this.content()))}},Em=Kn(Tm)})))()}function Om(e,t){let n=e.senderSession?.sessionKey,r=n?Ue(n):null,i=/^cron:[^:]+:run:[^:]+$/u.test(r?.rest??``),a=!Ne(n)&&r&&r.agentId!==t.agentId,o=t.linkSource!==!1&&r?n:void 0,s=r?t.agents?.find(e=>e.id===r.agentId)?.identity?.name?.trim()||r.agentId:void 0,c=!!(r&&t.mainKey&&r.rest===t.mainKey),l=e.senderSession?.label??(i?L(`chat.messages.forwardedAutomation`):c?s:void 0),u=!c&&a?s:void 0,d=a?au(r.agentId,t):G,f=i?H`<a
        class="markdown-session-link markdown-session-link--titled markdown-session-link--automation"
        role="link"
        tabindex="0"
        data-session-key=${o}
        ><span class="session-link-icon" aria-hidden="true">${z.clock}</span
        ><span class="session-label" .textContent=${l}></span
      ></a>`:H`<a
        class="markdown-session-link${l?` markdown-session-link--titled`:``}${a&&c?` markdown-session-link--agent`:``}"
        role="link"
        tabindex="0"
        data-session-key=${o}
        ><span class="session-label" .textContent=${l??o}></span
      ></a>`;return H`
    <div class="chat-reply-attribution chat-reply-attribution--forwarded">
      <span class="chat-reply-attribution__icon" aria-hidden="true">${z.forward}</span>
      ${o?H`<span>${L(`chat.messages.forwardedFrom`)}</span>
              ${a?H`<span class="chat-reply-attribution__agent">
                        ${d===G?G:H`<span
                                class="chat-reply-attribution__agent-avatar"
                                aria-hidden="true"
                                >${d}</span
                              >`}
                        ${u?H`<span>${u}</span>`:f}
                      </span>
                      ${u?H`<span aria-hidden="true">·</span> ${f}`:G}`:f} `:n?H`<span>${L(`chat.messages.forwardedFrom`)}</span>
                <span>${l??n}</span>`:H`<span
                >${e.senderSession?.agentId?L(`chat.messages.forwardedFromAgent`,{agentId:e.senderSession.agentId}):L(`chat.messages.forwardedMessage`)}</span
              >`}
    </div>
  `}function km(){return(km=e((()=>{K(),B(),R(),$r(),it(),Su(),di()})))()}var Am;function jm(){return(jm=e((()=>{n(),Cs(),K(),ar(),un(),Rn(),B(),R(),Lo(),tt(),nf(),pf(),yf(),Am=class extends gt{constructor(...e){super(...e),this.dismissed=!1,this.iconUrls={},this.pluginIconUrls={},this.failedImages=new Set,this.gateway=new So(this,{getGateway:()=>this.context?.gateway,invalidateRequests:()=>this.resetIcons(),onPageActivation:()=>{this.gateway.connected&&document.visibilityState===`visible`&&this.statusTask.run()}}),this.catalogIcons=new df({kind:`catalog`,getFetchContext:()=>this.iconFetchContext,isConnected:()=>this.isConnected&&this.gateway.connected,onUrlsChange:e=>{this.iconUrls=e},onLoadingChange:()=>this.requestUpdate()}),this.pluginIcons=new df({getFetchContext:()=>this.iconFetchContext,isConnected:()=>this.isConnected&&this.gateway.connected,onUrlsChange:e=>{this.pluginIconUrls=e},onLoadingChange:()=>this.requestUpdate()}),this.statusTask=new ws(this,{args:()=>[this.gateway.connected?this.gateway.client:null,this.agentId,this.gateway.epoch,this.recommendation?.kind===`plugin`?this.gateway.snapshot?.pluginCapabilities?.generation:void 0,this.recommendation?.id,this.recommendation?.kind,this.recommendation?.kind===`skill`?this.recommendation.registry:void 0],task:async([e,t],{signal:n})=>{let r=this.recommendation;if(!e||!r)return Bs;if(r.kind===`plugin`){let{plugin:t}=await Ae(e,r.id,n);return{...r,name:t.catalog.name,description:t.catalog.summary,iconUrl:t.catalog.imageUrl,pluginId:t.local.pluginId,official:t.catalog.official,installed:t.local.installed,canInstall:t.catalog.official&&t.local.action===`install`}}if(!t)throw Error(`Skill recommendations require an agent.`);let[i,a]=await Promise.all([e.request(`skills.detail`,{slug:r.id},{signal:n}),_e(e,t)]);if(!i.skill||!a)throw Error(`Skill details are unavailable.`);let o=a.skills.some(({clawhub:e})=>e?.status===`linked`&&e.valid&&!e.requestedReference&&e.registry===r.registry&&`@${e.ownerHandle}/${e.slug}`===r.id);return{...r,name:i.skill.displayName,pluginId:void 0,description:i.skill.summary,official:i.skill.isOfficial===!0,installed:o,canInstall:i.skill.isOfficial===!0&&!o}},onComplete:e=>{e.pluginId!==this.iconPluginId&&(this.pluginIcons.reset(),this.iconPluginId=e.pluginId),e.pluginId&&this.pluginIcons.load(e.pluginId),this.catalogIcons.syncCatalog([],e.iconUrl?[e.iconUrl]:[])}})}get iconFetchContext(){return{resourceBasePath:this.context.resourceBasePath,gatewayUrl:this.context.gateway.connection.gatewayUrl,auth:{hello:this.context.gateway.snapshot.hello,settings:{token:this.context.gateway.connection.token},password:this.context.gateway.connection.password}}}resetIcons(){this.catalogIcons.reset(),this.pluginIcons.reset(),this.loadedImage=void 0,this.failedImages=new Set}disconnectedCallback(){this.resetIcons(),super.disconnectedCallback()}openListing(e=!1){let t=this.recommendation;if(t){if(t.kind===`plugin`)this.context.navigate(`plugins`,{pathname:Sn(t.id,this.context.basePath),search:e?`?action=install`:``});else{let e=new URLSearchParams({clawhub:t.id});this.agentId&&e.set(`agent`,this.agentId),this.context.navigate(`skills`,{search:`?${e}`})}}}render(){if(!this.recommendation||this.dismissed)return G;let e=this.statusTask.status===Ts.COMPLETE,t=e?this.statusTask.value:this.recommendation;if(!t)return G;let n=this.statusTask.status===Ts.ERROR,r=e?this.statusTask.value:void 0,i=Vd({pluginId:r?.pluginId,imageUrl:t.iconUrl},{pluginIconUrls:this.pluginIconUrls,iconUrls:this.iconUrls},this.failedImages),a=!e&&!n||(i?this.loadedImage!==i:!!(r?.pluginId&&this.pluginIcons.isLoading(r.pluginId))||!!(t.iconUrl&&this.catalogIcons.isLoading(t.iconUrl))),o=!e&&!n;return H`
      <div
        class="card chat-clawhub-card"
        data-clawhub-id=${t.id}
        aria-busy=${o||a}
      >
        <button class="chat-clawhub-card__listing" type="button" @click=${()=>this.openListing()}>
          <span class="chat-clawhub-card__icon ${a?`skeleton`:``}" aria-hidden="true">
            ${i?H`<img
                    src=${i}
                    alt=""
                    ?hidden=${a}
                    @load=${()=>{this.loadedImage=i}}
                    @error=${()=>{this.failedImages=new Set([...this.failedImages,i])}}
                  />`:a?G:z.plug}
          </span>
          <span class="chat-clawhub-card__identity">
            <span class="card-title chat-clawhub-card__name"
              >${t.name} ${t.official?Qd():G}
            </span>
            ${t.description?H`<span class="card-sub">${t.description}</span>`:G}
          </span>
        </button>
        <div class="chat-clawhub-card__actions" aria-live="polite">
          ${e&&t.installed?H`<span class="chip chip-ok chat-clawhub-card__installed"
                  >${z.check}<span>${L(`pluginsPage.installed`)}</span></span
                >`:e?H`<button
                      type="button"
                      class="btn chat-clawhub-card__dismiss"
                      @click=${()=>{this.dismissed=!0}}
                    >
                      ${L(`common.dismiss`)}
                    </button>
                    <button
                      type="button"
                      class="btn primary chat-clawhub-card__install"
                      @click=${()=>this.openListing(this.statusTask.value?.canInstall===!0)}
                    >
                      ${this.statusTask.value?.canInstall?L(`pluginsPage.install`):L(`chat.clawhub.viewDetails`)}
                    </button>`:n?H`<button
                      type="button"
                      class="btn chat-clawhub-card__dismiss"
                      @click=${()=>this.statusTask.run()}
                    >
                      ${L(`chat.clawhub.retryStatus`)}
                    </button>`:H`<span
                        class="skeleton chat-clawhub-card__status-skeleton"
                        aria-hidden="true"
                      ></span>
                      <span class="sr-only">${L(`common.loading`)}</span>`}
        </div>
      </div>
    `}},k([re({context:Fn,subscribe:!0})],Am.prototype,`context`,void 0),k([X({attribute:!1})],Am.prototype,`recommendation`,void 0),k([X({attribute:!1})],Am.prototype,`agentId`,void 0),k([J()],Am.prototype,`dismissed`,void 0),k([J()],Am.prototype,`iconUrls`,void 0),k([J()],Am.prototype,`pluginIconUrls`,void 0),k([J()],Am.prototype,`loadedImage`,void 0),k([J()],Am.prototype,`failedImages`,void 0),customElements.define(`openclaw-chat-clawhub-card`,Am)})))()}function Mm(e){return[...e.drafts].flatMap(([t,n])=>!e.resolved.has(t)&&n.signature&&(n.edited||n.reopenedAfterBoundary||n.status===`skipped`)?[{itemId:t,signature:n.signature,edited:n.edited===!0,...n.status===`skipped`?{dismissed:!0}:{},answers:[...n.answers.values()].map(e=>({selected:[...e.selected],freeText:e.freeText})),...n.reopenedAfterBoundary?{reopenedAfterBoundary:n.reopenedAfterBoundary}:{}}]:[])}function Nm(e){e.load||=(async()=>{let t=await(await Fm()).readDurableComposerDraft(e.scope);if(t.status===`storage-failed`){e.error=`storage`,e.onChange();return}e.revision=t.status===`found`?t.draft.revision:t.revision??0,e.writeId=t.status===`found`?t.draft.writeId:t.writeId,t.status===`not-found`&&t.revision!==void 0&&t.revision>=(e.intentRevision??0)&&e.drafts.clear();let n=t.status===`found`?t.draft.questionDrafts??[]:[];e.saved=JSON.stringify(n);for(let t of n){let n=e.drafts.get(t.itemId),r=n?.status===`submitted`&&n.admittedQueueId;e.resolved.has(t.itemId)||n?.edited||n?.status&&!r||n?.signature&&n.signature!==t.signature||e.drafts.set(t.itemId,{signature:t.signature,edited:t.edited,status:r?`submitted`:t.dismissed?`skipped`:void 0,admittedQueueId:n?.admittedQueueId,answers:new Map(t.answers.map((e,t)=>[String(t),{selected:new Set(e.selected),freeText:e.freeText}])),reopenedAfterBoundary:n?.reopenedAfterBoundary??t.reopenedAfterBoundary})}e.loaded=!0,e.onChange()})().catch(()=>{e.error=`storage`,e.onChange()})}function Pm(e,t=!1){t&&(e.intentRevision=ss(e.intentRevision)),e.write=(e.write??Promise.resolve()).then(async()=>{if(await e.load,!e.loaded||e.invalidated)return;let t=Mm(e),n=JSON.stringify(t);if(n===e.saved||n===e.attempted)return;e.attempted=n;let r=ss(e.revision),i=`question:${crypto.randomUUID()}`,a=await Fm();if(e.invalidated)return;let o=await a.writeDurableComposerDraft(e.scope,{revision:r,text:``,attachments:[],questionDrafts:t},{expectedRevision:e.revision,expectedWriteId:e.writeId,writeId:i});o.status===`persisted`?(e.revision=r,e.writeId=i,e.saved=n,e.error=void 0):e.error=o.status===`conflict`?`conflict`:`storage`,e.onChange()}).catch(()=>{e.error=`storage`,e.onChange()})}var Fm;function Im(){return(Im=e((()=>{Ca(),t(),Fm=()=>ne(()=>import(`./composer-draft-store.runtime-Df-g8rja.js`),__vite__mapDeps([0,1,2,3,4,5,6,7]),import.meta.url)})))()}function Lm(e,t=!1){let n=t?e?.freeText:e?.freeText.trim();return[...e?.selected??[],...n?[n]:[]]}function Rm(e){let{question:t}=e;return t.options.length===0?G:H`
    <div
      class="chat-question-panel__options"
      role=${t.multiSelect?`group`:`radiogroup`}
      aria-label=${t.header}
    >
      ${t.options.map((n,r)=>{let i=e.selected.has(n.label),a=i||e.selected.size===0&&r===0?0:-1;return H`
          <button
            class="chat-question-panel__option ${i?`chat-question-panel__option--selected`:``}"
            type="button"
            role=${t.multiSelect?`checkbox`:`radio`}
            aria-checked=${i?`true`:`false`}
            tabindex=${t.multiSelect?0:a}
            data-option-index=${r}
            ?disabled=${e.disabled}
            @click=${()=>e.onSelect(n.label)}
          >
            <span class="chat-question-panel__option-marker" aria-hidden="true">
              ${i?`✓`:``}
            </span>
            <span class="chat-question-panel__option-copy">
              <strong>${n.label}</strong>
              ${n.description?H`<small>${n.description}</small>`:G}
            </span>
            ${Vt(r+1)}
          </button>
        `})}
    </div>
  `}function zm(e,t,n,r){let i=t=>{(t.currentTarget instanceof HTMLInputElement||t.currentTarget instanceof HTMLTextAreaElement)&&e.onInput(t.currentTarget.value)};return e.question.isSecret?H`<input
        class=${t}
        type="password"
        autocomplete="off"
        placeholder=${n}
        aria-label=${Jn(r)}
        .value=${e.value}
        ?disabled=${e.disabled}
        @input=${i}
      />`:H`<textarea
        class="${t} chat-question-panel__textarea"
        rows="1"
        placeholder=${n}
        aria-label=${Jn(r)}
        aria-description=${L(`chat.questions.multilineHint`,{shortcut:`Ctrl/⌘+Enter`})}
        .value=${e.value}
        ?disabled=${e.disabled}
        @input=${i}
      ></textarea>`}function Bm(e){let{question:t}=e;if(t.options.length>0&&!t.isOther)return G;let n=t.header||L(`chat.questions.answer`);return H`
    ${t.options.length===0?H`<label class="field">
            <span>${n}</span>
            ${zm(e,`input`,L(`chat.questions.answerPlaceholder`,{label:t.secretStore?.name??n}))}
          </label>`:H`<label
            class="chat-question-panel__option chat-question-panel__option--other ${e.selected?`chat-question-panel__option--selected`:``}"
          >
            <span class="chat-question-panel__option-marker" aria-hidden="true"></span>
            ${zm(e,`chat-question-panel__other`,L(`chat.questions.other`),L(`chat.questions.ownAnswerFor`,{header:t.header}))}
            ${Vt(t.options.length+1)}
          </label>`}
    ${t.isSecret?G:H`<div class="chat-question-panel__input-hint">
            ${Wt(L(`chat.questions.multilineHint`,{shortcut:`{shortcut}`}),Vt([`Ctrl`,`/`,`⌘`,`+`,`Enter`],{inline:!0}))}
          </div>`}
  `}function Vm(){return(Vm=e((()=>{K(),Un(),rn(),R()})))()}function Hm(e,t){let n=t?t.split(`, `):[],r=n.length>0&&n.every(t=>e.options?.includes(t))&&n.join(`, `)===t?new Set(n):new Set;return{selected:r,freeText:r.size>0?``:t}}function Um(e,t){let n=0,r=[];for(let i=0;i<e.questions.length;i+=1){let a=e.questions[i];if(!a)return null;let o=`${Wm(a.title)}\n\n`;if(!t.startsWith(o,n))return null;if(n+=o.length,i===e.questions.length-1){r.push(t.slice(n)),n=t.length;break}let s=e.questions[i+1];if(!s)return null;let c=`\n\n${Wm(s.title)}\n\n`,l=t.indexOf(c,n);if(l<n||t.includes(c,l+c.length))return null;r.push(t.slice(n,l)),n=l+2}return n!==t.length||r.length!==e.questions.length||r.some(e=>!e.trim())?null:new Map(e.questions.map((e,t)=>[String(t),Hm(e,r[t]??``)]))}function Wm(e){let t=new TextEncoder,n=``,r=0;for(let i of e){if(r+=t.encode(i).length,r>512)break;n+=i}return`> ${n.replace(/[\r\n]/g,` `)}`}function Gm(e,t){let n=t.resolved.get(e.itemId),r=n?void 0:t.delivery.get(e.itemId),i=n??t.drafts.get(e.itemId),a=r?Um(e,r.text):i?.status===`submitted`?i.answers:void 0,o=r&&!a?r.text:n?.unparsedText,s=t.archived.has(e.itemId),c=i?.status===`reopening`,l=i?.status===`skipped`||c,u=n?L(`chat.asyncQuestions.sent`):r?L(r.sendState===`failed`?`chat.asyncQuestions.failed`:r.sendState===`unconfirmed`?`chat.queue.deliveryUnconfirmed`:r.sendState===`waiting-reconnect`?`chat.queue.states.waitingForReconnect`:r.sendState===`sending`?`chat.asyncQuestions.sending`:`chat.asyncQuestions.queued`):i?.status===`submitted`?L(`chat.asyncQuestions.awaitingConfirmation`):void 0,d=r?.sendState===`failed`||r?.sendState===`unconfirmed`;return H`<div class="chat-question-summary" role="status" aria-live="polite">
    ${o?H`<div class="chat-question-summary__prompt">${o}</div>`:e.questions.map((e,t)=>H`<div>
              <strong>${e.title}</strong>
              <div>
                ${a?Lm(a.get(String(t))).join(`, `):L(c?`chat.asyncQuestions.reopening`:l?`chat.asyncQuestions.dismissed`:s?`chat.asyncQuestions.archived`:`chat.asyncQuestions.inComposer`)}
              </div>
            </div>`)}
    ${u?H`<div class="chat-question-summary__delivery">
            <span>${u}</span>
            ${d&&t.retry?H`<button
                    type="button"
                    class="btn btn--sm"
                    @click=${()=>t.retry?.(r.id)}
                  >
                    ${L(`chat.asyncQuestions.retry`)}
                  </button>`:G}
            ${r?.sendError?H`<div>${r.sendError}</div>`:G}
          </div>`:G}
    ${s||l?H`<div>
              ${L(l?`chat.asyncQuestions.dismissedReason`:`chat.asyncQuestions.archivedReason`)}
            </div>
            ${l&&t.storageError?H`<div role="alert">${t.storageError}</div>`:G}
            <button
              type="button"
              class="btn btn--sm"
              ?disabled=${c}
              @click=${()=>t.reopen(e.itemId)}
            >
              ${L(`chat.questions.answer`)}
            </button>`:G}
  </div>`}function Km(){return(Km=e((()=>{K(),R(),Vm()})))()}function qm(e){let t=m(e),n=m(t?.__openclaw),r=gd(e),i=typeof t?.stopReason==`string`?t.stopReason.toLowerCase():``;if(t?.role!==`assistant`||t.openclawAsyncDelivery||gu(e)||m(t.provenance)?.kind===`inter_session`||i===`tooluse`)return null;let a=Fd(e)!==null||m(t.openclawAbort)?.aborted===!0||[`aborted`,`cancelled`,`canceled`,`timeout`,`timed_out`,`error`].includes(i);return n?.runTerminal===!0||Kd(e)!==null||n?.mirrorOrigin!==`codex-app-server`&&(r===`final_answer`||i===`stop`||a)?a||r===`commentary`||Bo(e)?`settled`:`successful`:null}function Jm(e){let t=new Map,n=new Map,r=new Map,i=new Map,a=new Map,o=[],s=-1,c;for(let[l,u]of e.entries()){let e=m(u),d=wr(u),f=m(e?.provenance),p=eu(u);d?.role===`user`&&(!f?.kind||f.kind===`external_user`)&&!Ud(u)&&(s=l,c=p,p&&!n.has(p)&&n.set(p,l)),d?.role===`user`&&d.runId&&f?.kind===`internal_system`&&f.sourceTool===`main_session_restart_recovery`&&r.set(d.runId,l);let h=qm(u);if(p){let e=t.get(p);t.set(p,{first:e?.first??l,last:l,settled:h?l:e?.settled})}let g=Qm(u);if(g&&i.set(g.itemId,{question:g,index:l,runId:p,originRunId:p??c}),d?.role===`user`&&d.id&&d.sequence!==null&&!d.isImported&&(!f?.kind||f.kind===`external_user`)){let t=Uo(u);if(t){let n=m(e?.__openclaw)?.replyToId,r=typeof n==`string`?n.trim():``,o=[...i.values()].filter(({question:e})=>!a.has(e.itemId)&&(!r||e.sourceMessageId===r)).map(({question:e})=>({question:e,answers:Um(e,t)})).filter(e=>e.answers!==null||!!(r&&t.trim())),s=o.length===1?o[0]:void 0;s&&a.set(s.question.itemId,{status:`submitted`,answers:s.answers??new Map,...s.answers?{}:{unparsedText:t}})}}h===`successful`&&o.push({index:l,turnStart:p?n.get(p)??-1:s,runId:p,key:JSON.stringify(p?[`run`,p]:[d?.id,d?.sequence,e?.timestamp,Uo(u)])})}let l=new Map,u=new Map,d=new Map;for(let e of o){if(e.runId){l.set(t.get(e.runId).first,e);let n=r.get(e.runId);n!==void 0&&n<e.index&&d.set(n,e)}u.set(e.turnStart,e)}for(let t of[l,u,d]){let n;for(let r=e.length-1;r>=0;--r){let e=t.get(r);e&&(!n||e.index>n.index)&&(n=e),n&&t.set(r,n)}}return{history:[...i.values()].map(({question:e,index:n,runId:r,originRunId:i})=>{let a=i?t.get(i):void 0,o=r?l:u,s=a?a.settled!==void 0&&a.settled>n?o.get(a.last+1):void 0:o.get(n+1),c=d.get(n+1);for(let e of[c,c?l.get(c.index+1):void 0,c?u.get(c.index+1):void 0])e&&(!s||e.index>s.index)&&(s=e);return{question:e,boundary:s?.key}}),resolved:a}}function Ym(e){let t=_f(),n=th.get(e);if(n?.revision===t)return n.history;let r=Jm(e);return th.set(e,{revision:t,history:r}),r}function Xm(e,t){let n=t.asyncQuestionStorage?{...t.asyncQuestionStorage,scopeKey:`questions:v1:${t.asyncQuestionStorage.scopeKey}`}:void 0,r=n?JSON.stringify([n.gatewayOwner,n.recoveryScope,n.scopeKey]):void 0;for(let[t,r]of e.asyncQuestionSessions??[])n&&r.scope.gatewayOwner===n.gatewayOwner&&r.scope.recoveryScope===n.recoveryScope||(r.invalidated=!0,e.asyncQuestionSessions?.delete(t));let i=JSON.stringify([t.sessionKey,t.currentAgentId,t.connectionEpoch,r]),a;if(n&&r){let t=e.asyncQuestionSessions??=new Map;a=t.get(r),a||(a={scope:n,drafts:new Map,resolved:new Set,revision:0,saved:`[]`,loaded:!1,onChange:()=>{}},t.set(r,a))}(e.asyncQuestionScope!==i||a&&e.asyncQuestionDrafts!==a.drafts)&&(e.asyncQuestionScope=i,e.asyncQuestionGeneration=(e.asyncQuestionGeneration??0)+1,e.asyncQuestionDrafts=a?.drafts??new Map);let o=e.asyncQuestionDrafts,s=e.asyncQuestionGeneration,c=()=>e.asyncQuestionScope===i&&e.asyncQuestionGeneration===s&&e.asyncQuestionDrafts===o,{history:l,resolved:u}=Ym(t.messages??[]),d=new Map((t.queue??[]).flatMap(e=>e.asyncQuestionItemId?[[e.asyncQuestionItemId,e]]:[])),f=()=>{c()&&(e.asyncQuestionRevision+=1,t.onRequestUpdate?.())};if(a){a.resolved=new Set(u.keys()),a.onChange=f;for(let{question:e}of l)$m(e,o);Nm(a),a.loaded&&u.size&&Pm(a)}let p=new Map,m=l.flatMap(({question:e,boundary:t})=>{let n=d.get(e.itemId);if(n&&!u.has(e.itemId)){let t=$m(e,o);t.status=`submitted`,t.admittedQueueId=n.id,t.answers=Um(e,n.text)??t.answers}let r=u.get(e.itemId)??o.get(e.itemId);return d.has(e.itemId)||r?.status===`submitted`?[]:r?.status===`skipped`||r?.status===`reopening`?(t&&p.set(e.itemId,t),[]):t&&!r?.edited&&!r?.status&&!r?.error&&r?.reopenedAfterBoundary!==t?(p.set(e.itemId,t),[]):[e]}),h=()=>{c()&&(a&&Pm(a,!0),f())},g=()=>a?.error?L(a.error===`conflict`?`chat.asyncQuestions.draftConflict`:`chat.asyncQuestions.draftStorageFailed`):void 0,_=async n=>{let r=l.find(({question:e})=>e.itemId===n),s=o.get(n);if(c()&&r&&!u.has(n)&&!e.asyncQuestionPresentation?.resolved.has(n)&&s?.status!==`reopening`&&(p.has(n)||s?.status===`skipped`)){let s=$m(r.question,o),l=s.status===`skipped`&&a;if(s.status=l?`reopening`:void 0,s.error=void 0,s.reopenedAfterBoundary=r.boundary,l){for(;;){h(),await l.write;let t=e.asyncQuestionPresentation;if(o.get(n)!==s||s.status!==`reopening`)return;if(!c()||t?.resolved.has(n)){s.status=void 0,l.onChange();return}let r=t?.archived.get(n);if(s.reopenedAfterBoundary===r)break;s.reopenedAfterBoundary=r}s.status=void 0}t.onReopen?.(n,i),h()}},v={scope:i,pending:m,archived:p,historyKey:JSON.stringify([[...p],[...u].map(([e,t])=>[e,t.unparsedText,[...t.answers].map(([e,t])=>[e,Lm(t)])]),[...d].map(([e,t])=>[e,t.id,t.text,t.sendState,t.sendError]),!!(t.onAsyncQuestionSubmit&&t.onQueueRetry)]),drafts:o,resolved:u,delivery:d,discard:e=>{if(!c())return;let t=e.asyncQuestionItemId,n=t?o.get(t):void 0;t&&n?.admittedQueueId===e.id&&!u.has(t)&&(o.set(t,{...n,status:void 0,admittedQueueId:void 0,error:void 0,reopenedAfterBoundary:l.find(({question:e})=>e.itemId===t)?.boundary}),h())},retry:t.onAsyncQuestionSubmit&&t.onQueueRetry?n=>{c()&&e.transcriptRenderContext.onAsyncQuestionSubmit&&t.onQueueRetry?.(n)}:void 0,storageError:g(),onChange:h,reopen:_,dismiss:async t=>{let n=l.find(e=>e.question.itemId===t)?.question;if(!c()||!n||u.has(t))return;let r=$m(n,o);if(r.status)return;r.status=`skipped`,r.error=void 0,h(),await a?.write;let i=e.asyncQuestionPresentation;c()&&i?.drafts.get(t)===r&&r.status===`skipped`&&!i.resolved.has(t)&&I({message:g()??L(`chat.asyncQuestions.dismissedNotice`),actionLabel:L(`common.undo`),onAction:()=>{c()&&e.asyncQuestionPresentation?.reopen(t)}})},submit:t.onAsyncQuestionSubmit?async(t,n,r)=>c()?await e.transcriptRenderContext.onAsyncQuestionSubmit?.(t,n,r)===!0:!1:void 0};return e.asyncQuestionPresentation=v,v}function Zm(e,t){return typeof e==`string`&&e.length<=t&&e.trim().length>0}function Qm(e){if(!s(e)||e.role!==`assistant`)return null;let t=e.openclawAsyncDelivery;if(!s(t)||!Zm(t.itemId,256)||!Array.isArray(t.questions)||t.questions.length===0||t.questions.length>12)return null;let n=[];for(let e of t.questions){if(!s(e)||!Zm(e.title,4096)||e.options!==void 0&&(!Array.isArray(e.options)||e.options.length===0||e.options.length>4||!e.options.every(e=>Zm(e,256))))return null;n.push({title:e.title,options:e.options})}let r=wr(e),i=r?.id&&r.sequence!==null&&!r.isImported?r.id:void 0;return{itemId:t.itemId,...i?{sourceMessageId:i}:{},questions:n}}function $m(e,t){let n=t.get(e.itemId),r=JSON.stringify(e.questions);return(!n||n.signature&&n.signature!==r)&&(n={signature:r,answers:new Map(e.questions.map((e,t)=>[String(t),{selected:new Set(e.options?.slice(0,1)),freeText:``}]))},t.set(e.itemId,n)),n.signature=r,n}function eh(e,t,n){let r=$m(e,t.drafts),i=t.pending.reduce((e,t)=>e+t.questions.length,0);return{model:{requestKey:JSON.stringify([t.scope,e.itemId]),title:L(`chat.asyncQuestions.title`),questions:e.questions.map((e,t)=>({questionId:String(t),header:e.options?e.title:L(`chat.questions.answer`),question:e.title,options:(e.options??[]).map(e=>({label:e})),isOther:!0})),autoFocus:!1,nonBlocking:!0,collapsed:n.collapsed??!1,collapsedLabel:L(i===1?`chat.asyncQuestions.pendingOne`:`chat.asyncQuestions.pendingMany`,{count:String(i)}),disabled:!t.submit,submitting:r.status===`submitting`,drafts:r.answers,error:r.error,notice:t.storageError,requestPosition:n.requestPosition},onChange:()=>{r.edited=!0,t.onChange()},onCollapsedChange:n.onCollapsedChange,onPreviousRequest:n.onPreviousRequest,onNextRequest:n.onNextRequest,onSkip:()=>t.dismiss(e.itemId),onSubmit:async n=>{if(r.status)return;r.status=`submitting`,r.error=void 0,t.onChange();let i=e.questions.map((e,t)=>`${Wm(e.title)}\n\n${n[String(t)]?.join(`, `)??``}`).join(`

`);try{if(!await t.submit?.(i,e.itemId,e.sourceMessageId))throw Error(L(`chat.asyncQuestions.sendFailed`));r.status=`submitted`}catch(e){throw r.status=void 0,r.error=e instanceof Error?e.message:String(e),e}finally{t.onChange()}}}}var th;function nh(){return(nh=e((()=>{Tr(),_d(),R(),Fo(),bo(),Oe(),wu(),af(),Zd(),Im(),Km(),Vm(),th=new WeakMap})))()}function rh(e,t){let n=mi(e),r=t?.split(`;`,1)[0]?.trim().toLowerCase(),i=(n?oh.find(e=>e.extensions.includes(n)):void 0)??(r?oh.find(e=>e.mimeTypes.includes(r)):void 0)??sh,a=n?i.compactByExtension?.[n]??i.compact:i.compact,o=(n?i.accentByExtension?.[n]:void 0)??(r?i.accentByMimeType?.[r]:void 0)??i.accent;return{family:i.family,accent:o,extension:n,extensionLabel:n?.toUpperCase()??(i.family===`unknown`?`FILE`:i.family.toUpperCase()),compact:a}}function ih(e){return Rt(`file-icons/${e}.svg`)}function ah(e){let t=rh(e.filename,e.mimeType),n=e.mode===`large-placeholder`,r=n?`44px`:`20px`,i=e=>ih(n?`large/shell-${e}`:t.compact?`compact/${e}/${t.compact}`:`compact/unknown-${e}`);return H`<span
    class="chat-attachment-file-icon ${e.unavailable?`chat-attachment-file-icon--unavailable`:``} ${e.loading?`skeleton`:``}"
    data-family=${t.family}
    data-mode=${e.mode}
    aria-hidden="true"
    style=${nr({width:r,height:r,"--chat-file-icon-light":`url("${i(`light`)}")`,"--chat-file-icon-dark":`url("${i(`dark`)}")`,"--chat-file-icon-overlay":`url("${ih(`overlays/${t.family}`)}")`,"--chat-file-icon-accent":t.accent})}
  >
    ${n?H`<span class="chat-attachment-file-icon__overlay"></span>`:null}
  </span>`}var oh,sh;function ch(){return(ch=e((()=>{K(),rr(),Ht(),li(),oh=[{family:`unknown`,accent:`#929292`,extensions:[],mimeTypes:[`application/octet-stream`]},{family:`pdf`,accent:`#E94B64`,extensions:[`pdf`],mimeTypes:[`application/pdf`],compact:`pdf`},{family:`document`,accent:`#5B7FD6`,extensions:[`doc`,`docx`,`rtf`,`odt`,`pages`],mimeTypes:[`application/msword`,`application/vnd.openxmlformats-officedocument.wordprocessingml.document`,`application/rtf`,`text/rtf`,`application/vnd.oasis.opendocument.text`],compact:`docx`,compactByExtension:{rtf:`rtf`}},{family:`spreadsheet`,accent:`#3FA66B`,extensions:[`csv`,`xls`,`xlsx`,`ods`,`numbers`],mimeTypes:[`text/csv`,`application/vnd.ms-excel`,`application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`,`application/vnd.oasis.opendocument.spreadsheet`],compact:`xlsx`,compactByExtension:{csv:`csv`}},{family:`image`,accent:`#3FA66B`,extensions:[`gif`,`jpg`,`jpeg`,`png`,`webp`,`avif`,`heic`],mimeTypes:[`image/gif`,`image/jpeg`,`image/png`,`image/webp`,`image/avif`,`image/heic`],compact:`png`,compactByExtension:{gif:`gif`,jpg:`jpg`,jpeg:`jpg`}},{family:`video`,accent:`#E94B64`,extensions:[`mp4`,`mov`,`m4v`,`webm`,`mkv`],mimeTypes:[`video/mp4`,`video/quicktime`,`video/webm`,`video/x-matroska`],compact:`mp4`},{family:`audio`,accent:`#E86672`,extensions:[`mp3`,`wav`,`m4a`,`aac`,`flac`,`ogg`],mimeTypes:[`audio/mpeg`,`audio/wav`,`audio/x-wav`,`audio/mp4`,`audio/aac`,`audio/flac`,`audio/ogg`],compact:`wav`,compactByExtension:{mp3:`mp3`}},{family:`archive`,accent:`#8B7CF6`,extensions:[`zip`,`rar`,`7z`,`tar`,`gz`,`tgz`,`bz2`],mimeTypes:[`application/zip`,`application/x-rar-compressed`,`application/x-7z-compressed`,`application/x-tar`,`application/gzip`],compact:`zip`},{family:`text`,accent:`#5B7FD6`,extensions:[`txt`,`log`],mimeTypes:[`text/plain`],compact:`txt`},{family:`markdown`,accent:`#5B7FD6`,extensions:[`md`,`mdx`,`markdown`],mimeTypes:[`text/markdown`,`text/x-markdown`],compact:`md`},{family:`code`,accent:`#E76F3C`,accentByExtension:{css:`#8B7CF6`},accentByMimeType:{"text/css":`#8B7CF6`},extensions:[`css`,`html`,`htm`,`xml`,`jsx`,`tsx`,`ts`,`sh`,`bash`,`zsh`],mimeTypes:[`text/css`,`text/html`,`application/xml`,`text/xml`,`application/typescript`,`text/x-shellscript`],compact:`html`,compactByExtension:{css:`css`,xml:`xml`}},{family:`javascript`,accent:`#F2A93B`,extensions:[`js`,`cjs`,`mjs`],mimeTypes:[`text/javascript`,`application/javascript`],compact:`js`},{family:`json`,accent:`#F2A93B`,extensions:[`json`,`jsonl`,`geojson`],mimeTypes:[`application/json`,`application/ld+json`,`application/x-ndjson`,`application/geo+json`],compact:`json`},{family:`python`,accent:`#F2A93B`,extensions:[`py`,`pyw`,`pyi`],mimeTypes:[`text/x-python`,`application/x-python-code`],compact:`py`},{family:`svg`,accent:`#E76F3C`,extensions:[`svg`,`svgz`],mimeTypes:[`image/svg+xml`],compact:`svg`},{family:`yaml`,accent:`#E86672`,extensions:[`yaml`,`yml`],mimeTypes:[`application/yaml`,`text/yaml`,`application/x-yaml`,`text/x-yaml`],compact:`yaml`}],sh=oh[0]})))()}function lh(e){return L(e===`file-not-found`?`chat.attachments.failureFileNotFound`:e===`unsupported-format`?`chat.attachments.failureUnsupportedFormat`:`chat.attachments.failureDeliveryFailed`)}function uh(e){return e.length===0?G:H`${e.map(e=>{let t=e.media.sizeBytes===void 0?L(`chat.attachments.omittedFromHistory`):L(`chat.attachments.omittedFromHistoryWithSize`,{size:ve(e.media.sizeBytes)});return dh({label:L(`chat.attachments.image`),badge:L(`chat.attachments.history`),reason:t})})}`}function dh(e){let t=e.reason!==void 0,n=t&&(e.onRetry!==void 0||e.onAllow!==void 0);return H`
    <div
      class="chat-assistant-attachment-card chat-assistant-attachment-card--blocked ${t?n?`chat-assistant-attachment-card--recoverable`:`chat-assistant-attachment-card--definitive`:`chat-assistant-attachment-card--checking`}"
      aria-busy=${t?G:`true`}
    >
      <div class="chat-assistant-attachment-card__header">
        <div class="chat-assistant-attachment-card__identity">
          ${ah({filename:e.label,mimeType:e.mimeType,mode:`large-placeholder`,unavailable:t})}
          <span class="chat-assistant-attachment-card__details">
            <span
              class="chat-assistant-attachment-card__title ${t?`chat-assistant-attachment-card__title--unavailable`:``}"
              title=${e.path??e.label}
              tabindex=${e.path?`0`:G}
              >${e.label}</span
            >
            <span
              class="chat-assistant-attachment-card__meta chat-assistant-attachment-card__status-meta ${t?``:`skeleton skeleton-line`}"
              aria-hidden=${t?G:`true`}
            >
              <span class="chat-assistant-attachment-card__status-badge">${e.badge}</span>
              ${e.reason?H`
                      <span
                        class="chat-assistant-attachment-card__status-separator"
                        aria-hidden="true"
                        >·</span
                      >
                      <span class="chat-assistant-attachment-card__status-reason"
                        >${e.reason}</span
                      >
                    `:G}
            </span>
          </span>
        </div>
        ${e.onAllow?H`<button
                class="chat-assistant-attachment-card__action chat-assistant-attachment-card__action--labeled"
                type="button"
                @click=${e.onAllow}
              >
                ${L(`chat.attachments.allowImage`)}
              </button>`:e.onRetry?H`<button
                  class="chat-assistant-attachment-card__action chat-assistant-attachment-card__action--labeled chat-assistant-attachment-card__retry"
                  type="button"
                  @click=${e.onRetry}
                >
                  ${z.refresh} ${L(`common.retry`)}
                </button>`:t?G:H`<span
                    class="chat-assistant-attachment-card__actions chat-assistant-attachment-card__actions--loading"
                    aria-hidden="true"
                    data-label=${L(`chat.attachments.open`)}
                  >
                    <span
                      class="chat-assistant-attachment-card__action-skeleton skeleton"
                      aria-hidden="true"
                    ></span>
                  </span>`}
      </div>
    </div>
  `}function fh(){return(fh=e((()=>{K(),B(),R(),xe(),ch()})))()}function ph(e,t,n){return H`<div
    ${t?U(t):G}
    class="chat-assistant-attachment-card chat-assistant-attachment-card--compact"
    ?data-openable=${!!e.onExpand}
    @focusin=${n??G}
    @click=${t=>hh(t,e.onExpand)}
  >
    ${_h({...e,visualMode:`large-placeholder`})}
  </div>`}function mh(){return H`<div
    class="sidebar-attachment-preview__loading"
    role="status"
    aria-label=${L(`common.loading`)}
  >
    <div class="skeleton skeleton-line" aria-hidden="true"></div>
    <div class="skeleton skeleton-line skeleton-line--long" aria-hidden="true"></div>
    <div class="skeleton skeleton-line skeleton-line--medium" aria-hidden="true"></div>
  </div>`}function hh(e,t){if(t&&!e.defaultPrevented){for(let t of e.composedPath()){if(t===e.currentTarget)break;if(t instanceof Element&&t.matches(vh))return}t()}}function gh(e,t,n){return e===`audio`?L(`chat.attachments.audio`):e===`video`?L(`chat.attachments.video`):e===`image`?L(`chat.attachments.attachedFile`):rh(t,n).extensionLabel}function _h(e){let t=e.loading?`skeleton`:``,n=e.visualMode===`preview-with-favicon`,r=e.sizeBytes===void 0?void 0:ve(e.sizeBytes),i=[gh(e.kind,e.label,e.mimeType),r].filter(Boolean).join(` · `),a=L(`chat.mediaPlayer.download`,{filename:e.label}),o=e.onExpand!==void 0,s=e.expandLabel??L(`chat.attachments.expand`,{filename:e.label}),c=`chat-assistant-attachment-card__action chat-assistant-attachment-card__download chat-assistant-attachment-card__download--ghost ${o?`chat-assistant-attachment-card__download--secondary`:``}`;return H`
    <div
      class="chat-assistant-attachment-card__header ${n?`chat-assistant-attachment-card__header--preview`:``}"
    >
      <div class="chat-assistant-attachment-card__identity">
        ${ah({filename:e.label,mimeType:e.mimeType,mode:e.visualMode??`large-placeholder`,loading:e.loading})}
        <span
          class="chat-assistant-attachment-card__details ${n?`chat-assistant-attachment-card__details--preview`:``}"
        >
          <span class="chat-assistant-attachment-card__title ${t}" title=${e.label}
            >${e.label}</span
          >
          ${n?r?H`<span class="chat-assistant-attachment-card__separator" aria-hidden="true"
                      >·</span
                    ><span class="chat-assistant-attachment-card__meta ${t}"
                      >${r}</span
                    >`:null:H`<span class="chat-assistant-attachment-card__meta">${i}</span>`}
        </span>
      </div>
      <span class="chat-assistant-attachment-card__actions">
        ${e.voiceNote&&!n?H`<span class="chat-assistant-attachment-badge"
                >${L(`chat.messages.voiceNote`)}</span
              >`:null}
        ${e.onDownload?H`<button
                type="button"
                class=${`${c} ${t}`}
                ?disabled=${e.downloadPending}
                aria-label=${a}
                title=${a}
                @click=${e.onDownload}
              >
                ${z.download}
              </button>`:e.downloadHref||e.downloadPending?H`<a
                  class=${`${c} ${t}`}
                  href=${e.downloadPending?G:e.downloadHref}
                  aria-disabled=${e.downloadPending?`true`:G}
                  tabindex=${e.downloadPending&&e.downloadPendingFocusable?0:G}
                  role="link"
                  download=${e.label}
                  target="_blank"
                  rel="noreferrer"
                  aria-label=${a}
                  title=${a}
                  >${z.download}</a
                >`:null}
        ${o?H`<button
                type="button"
                class="chat-assistant-attachment-card__action ${n?`chat-assistant-attachment-card__expand--icon`:`chat-assistant-attachment-card__action--labeled`} chat-assistant-attachment-card__expand"
                aria-label=${s}
                title=${s}
                @click=${e.onExpand}
              >
                ${n?z.chevronsUpDown:H`<span>${L(`chat.attachments.open`)}</span>`}
              </button>`:null}
      </span>
    </div>
  `}var vh;function yh(){return(yh=e((()=>{K(),W(),B(),R(),$r(),xe(),ch(),di(),vh=`a, button, input, select, textarea, audio, video, iframe, [contenteditable='true'], [tabindex], [role='button']`})))()}function bh(e){try{let t=new URL(e,window.location.href);return(t.protocol===`http:`||t.protocol===`https:`)&&t.origin!==location.origin}catch{return!1}}function xh(e){let t=e.trim();if(t){if(t.startsWith(`/`)&&!t.startsWith(`//`)&&!t.startsWith(`/\\`))return t;try{return wh.has(new URL(t).protocol.toLowerCase())?t:void 0}catch{return}}}function Sh(e,t){let n=e.trim(),r=Th.exec(n),i=r?.[2];return i===void 0?xh(n):(!t||r?.[1]?.toLowerCase()===t)&&i.length%4==0?n:void 0}function Ch(e){let t=e.trim(),n=/^data:text\/plain;base64,([a-z0-9+/]*={0,2})$/i.exec(t)?.[1];return n===void 0?xh(t):n.length%4==0?t:void 0}var wh,Th;function Eh(){return(Eh=e((()=>{wh=new Set([`http:`,`https:`,`blob:`]),Th=/^data:(audio|video)\/[a-z0-9!#$&^_.+-]+;base64,([a-z0-9+/]+={0,2})$/i})))()}function Dh(e,t,n){if(typeof IntersectionObserver!=`function`)return t(),()=>void 0;let r=new IntersectionObserver(e=>{let i=e.at(-1);if(i){if(!(n?i.isIntersecting:e.some(e=>e.isIntersecting))){n?.();return}n||r.disconnect(),t()}},{rootMargin:Oh});return r.observe(e),()=>r.disconnect()}var Oh,kh;function Ah(){return(Ah=e((()=>{Oh=`240px 0px`,kh=class{constructor(e){this.onVisible=e,this.element=null,this.setElement=e=>{let t=e instanceof HTMLElement?e:null;this.element!==t&&(this.disconnect(),this.element=t,t&&(this.stopObserving=Dh(t,this.onVisible)))}}disconnect(){this.stopObserving?.(),this.stopObserving=void 0,this.element=null}}})))()}function jh(e,t){if(Ph?.media===e){Ph.onSuperseded=t;return}Ph?.onSuperseded(),Ph?.media.pause(),Ph={media:e,onSuperseded:t}}function Mh(e){Ph?.media===e&&(Ph=null)}function Nh(e){return Ph===null||Ph.media===e}var Ph;function Fh(){return(Fh=e((()=>{Ph=null})))()}function Ih(e){return e.durationSeconds!==void 0&&Number.isFinite(e.durationSeconds)&&e.durationSeconds>=0&&e.durationSeconds<=Gh&&(e.sizeBytes===void 0||Number.isFinite(e.sizeBytes)&&e.sizeBytes>=0&&e.sizeBytes<=8388608)}function Lh(e){return e.sizeBytes!==void 0&&Ih(e)}function Rh(e,t=Kh){let n=Math.max(1,Math.floor(t));if(e.length<=0||e.numberOfChannels<=0)return Array.from({length:n},()=>0);let r=Array.from({length:e.numberOfChannels},(t,n)=>e.getChannelData(n)),i=Array.from({length:n},()=>0);for(let t=0;t<n;t+=1){let a=Math.floor(t*e.length/n),o=Math.max(a+1,Math.floor((t+1)*e.length/n)),s=0;for(let e of r)for(let t=a;t<Math.min(o,e.length);t+=1)s=Math.max(s,Math.abs(e[t]??0));i[t]=s}let a=Math.max(...i);return a>0?i.map(e=>e/a):i}function zh(e){if(e>Yh)return!1;let t=()=>[...qh.values()].reduce((e,t)=>e+t.sizeBytes,0);for(;qh.size+1>Jh||t()+e>Yh;){let e=[...qh].find(([,e])=>e.retainCount===0);if(!e)return!1;let[t,n]=e;qh.delete(t),URL.revokeObjectURL(n.blobUrl)}return!0}function Bh(e){e.retainCount+=1;let t=!1;return{value:e,release:()=>{t||(t=!0,--e.retainCount)}}}function Vh(e){let t=qh.get(e);return t?(qh.delete(e),qh.set(e,t),Bh(t)):null}function Hh(e,t){let n=qh.get(e);if(n)return n.blobUrl!==t.blobUrl&&URL.revokeObjectURL(t.blobUrl),Vh(e);if(!zh(t.sizeBytes))return URL.revokeObjectURL(t.blobUrl),null;let r={...t,retainCount:0};return qh.set(e,r),Bh(r)}var Uh,Wh,Gh,Kh,qh,Jh,Yh;function Xh(){return(Xh=e((()=>{Uh=8388608,Wh=16e3,Gh=300,Kh=96,qh=new Map,Jh=32,Yh=50331648})))()}function Zh(e){let t=e.trim();return/^\/(?:__openclaw__|media|api\/chat\/media\/outgoing)\//.test(t)?!1:Qh(t)||/^file:/iu.test(t)||t.startsWith(`~`)||t.startsWith(`/`)||/^[a-zA-Z]:[\\/]/.test(t)||!!t&&!/^[a-z][a-z0-9+.-]*:/iu.test(t)}function Qh(e){let t=/^media:\/\/inbound\/([^/?#]+)$/i.exec(e.trim());if(!t?.[1])return!1;try{let e=decodeURIComponent(t[1]);return e!==`.`&&e!==`..`&&!e.includes(`/`)&&!e.includes(`\\`)&&!e.includes(`\0`)}catch{return!1}}function $h(e,t,n,r,i){return Zh(e)?cc(e,t,n,r,i):e}function eg(e,t,n){let r=e.trim();if(!r)return r;let i=r.indexOf(`#`),a=i===-1?``:r.slice(i),o=i===-1?r:r.slice(0,i),s=o.indexOf(`?`),c=s===-1?o:o.slice(0,s),l=new URLSearchParams(s===-1?``:o.slice(s+1));return l.set(t,n),`${c}?${l.toString()}${a}`}function tg(e,t){if(!e.startsWith(`/`)||e.startsWith(`//`))return e;try{let n=new URL(e,window.location.origin),r=v(t??``);return`${r&&n.pathname!==r&&!n.pathname.startsWith(`${r}/`)?`${r}${n.pathname}`:n.pathname}${n.search}${n.hash}`}catch{return e}}function ng(){return(ng=e((()=>{un(),Pl()})))()}function rg(e){return e.reason instanceof Error?e.reason:new DOMException(`playback preparation aborted`,`AbortError`)}function ig(e){return eg(e,`playback`,`1`)}function ag(e){let t=new Headers,n=e?.trim();return n&&t.set(`Authorization`,`Bearer ${n}`),t}async function og(e){let t=new AbortController,n,r=new Promise((e,t)=>{n=t}),i=()=>{let r=rg(e.signal);t.abort(r),n?.(r)};e.signal.addEventListener(`abort`,i,{once:!0}),e.signal.aborted&&i();let a=setTimeout(()=>{let e=new DOMException(`playback readiness request timed out`,`TimeoutError`);t.abort(e),n?.(e)},e.timeoutMs);try{return await Promise.race([fetch(e.source,{method:`HEAD`,headers:e.headers,credentials:`same-origin`,signal:t.signal}),r])}finally{clearTimeout(a),e.signal.removeEventListener(`abort`,i)}}async function sg(e){let t=ag(e.authToken);t.set(`Accept`,`audio/*, video/*`);let n=Date.now()+ug;for(let r=0;;r+=1){if(e.signal.aborted)return`aborted`;try{let i=n-Date.now();if(i<=0)return`unavailable`;let a=await og({source:e.source,headers:t,signal:e.signal,timeoutMs:Math.min(lg,i)});if(a.status!==202)return a.ok?`ready`:`unavailable`;let o=cg[r];if(o===void 0)return`unavailable`;let s=n-Date.now();if(s<=0)return`unavailable`;await d(Math.min(o,s),e.signal)}catch{return e.signal.aborted?`aborted`:`unavailable`}}}var cg,lg,ug;function dg(){return(dg=e((()=>{g(),ng(),cg=[2e3,4e3,8e3,16e3,3e4,3e4,2e4],lg=3e4,ug=12e4})))()}function fg(e){return Number.isFinite(e)&&e>0?e:0}var pg;function mg(){return(mg=e((()=>{dg(),pg=class{constructor(){this.appliedSource=``,this.appliedIdentity=``,this.pendingSource=``,this.pendingIdentity=``,this.restore=null,this.sourceFailed=!1,this.authorizationKey=``,this.readinessRequest=null,this.playbackSource=``,this.playbackReadiness=`idle`}get currentIdentity(){return this.appliedIdentity}get readySource(){return this.playbackSource}get readiness(){return this.playbackReadiness}sync(e,t,n,r,i){let a=t.trim(),o=n.trim(),s=i?.trim()??``;if(!a||!o)return null;let c=`${o}\0${s}`;this.authorizationKey&&c!==this.authorizationKey&&this.reset(e),this.authorizationKey=c;let l=r===`transcode`?ig(a):a;if(r!==`transcode`)return this.abortReadiness(),this.sourceFailed=!1,this.playbackReadiness=`ready`,this.playbackSource=l,this.updateSource(e,l,o),null;let u=[l,o,s].join(`\0`);if(u===this.readinessRequest?.key)return this.playbackSource===l&&this.updateSource(e,l,o),this.readinessRequest.promise;this.abortReadiness();let d=new AbortController,f=()=>this.appliedIdentity===o&&!this.sourceFailed;this.playbackSource=``,this.playbackReadiness=f()?`ready`:`preparing`;let p=sg({source:l,authToken:s||null,signal:d.signal}).then(t=>{if(this.readinessRequest?.controller===d&&t!==`aborted`){if(t!==`ready`){f()?(this.playbackSource=this.appliedSource,this.playbackReadiness=`ready`):this.playbackReadiness=`unavailable`;return}this.playbackSource=l,this.playbackReadiness=`ready`,this.updateSource(e,l,o)}});return this.readinessRequest={key:u,controller:d,promise:p},p}cancel(){this.abortReadiness(),this.cancelPendingResume(),this.playbackSource=``,this.playbackReadiness=`idle`}updateSource(e,t,n=t){let r=t.trim(),i=n.trim();if(r&&i){if(this.playbackReadiness=`ready`,this.appliedIdentity&&i!==this.appliedIdentity){e.paused||e.pause(),this.applySource(e,r,i,null);return}if(!(r===this.pendingSource&&i===this.pendingIdentity||r===this.appliedSource&&i===this.appliedIdentity)){if(e.error){this.applySource(e,r,i,{currentTime:fg(e.currentTime),paused:e.paused});return}if(!this.appliedSource||e.ended||e.paused&&fg(e.currentTime)===0){this.applySource(e,r,i,null);return}this.pendingSource=r,this.pendingIdentity=i}}}handleEnded(e){return this.pendingSource?(this.applySource(e,this.pendingSource,this.pendingIdentity,null),!0):!1}handleError(e){return this.applyPendingSource(e)?!0:(this.sourceFailed=!0,this.playbackSource=``,this.playbackReadiness=`unavailable`,!1)}applyPendingSource(e){return this.pendingSource?(this.applySource(e,this.pendingSource,this.pendingIdentity,{currentTime:fg(e.currentTime),paused:e.paused}),!0):!1}seek(e,t){let n=Math.max(0,fg(t));try{return e.currentTime=n,!0}catch{return this.pendingSource?(this.applySource(e,this.pendingSource,this.pendingIdentity,{currentTime:n,paused:e.paused}),!0):!1}}cancelPendingResume(){this.restore&&!this.restore.paused&&(this.restore={...this.restore,paused:!0})}reset(e){e.paused||e.pause(),this.appliedSource=``,this.appliedIdentity=``,this.pendingSource=``,this.pendingIdentity=``,this.restore=null,this.sourceFailed=!1,this.playbackSource=``,e.removeAttribute(`src`),e.load()}handleLoadedMetadata(e,t=()=>!0){this.sourceFailed=!1;let n=this.restore;if(!n)return;this.restore=null;let r=Number.isFinite(e.duration)?e.duration:n.currentTime;e.currentTime=Math.min(n.currentTime,Math.max(0,r)),!n.paused&&e.isConnected&&t()&&e.play().catch(()=>void 0)}applySource(e,t,n,r){this.appliedSource=t,this.appliedIdentity=n,this.pendingSource=``,this.pendingIdentity=``,this.restore=r,this.sourceFailed=!1,e.src=t}abortReadiness(){this.readinessRequest?.controller.abort(),this.readinessRequest=null}}})))()}async function hg(e,t,n={}){let r=e.headers.get(`Content-Length`),i=r===null?void 0:Number(r);if(!n.truncate&&i!==void 0&&Number.isFinite(i)&&i>t)return await e.body?.cancel().catch(()=>void 0),null;let a=e.body?.getReader();if(!a)return null;let o=[],s=0;try{for(;;){let{done:e,value:r}=await a.read();if(e)break;let i=t-s;if(r.byteLength>i&&!n.truncate)return await a.cancel().catch(()=>void 0),null;let c=r.byteLength>i?r.slice(0,i):r;if(o.push(c),s+=c.byteLength,n.truncate&&s===t){await a.cancel().catch(()=>void 0);break}}}finally{a.releaseLock()}let c=new Uint8Array(s),l=0;for(let e of o)c.set(e,l),l+=e.byteLength;return c.buffer}function gg(e){if(!Number.isFinite(e)||e<0)return`0:00`;let t=Math.floor(e),n=Math.floor(t/60),r=t%60;return`${n}:${String(r).padStart(2,`0`)}`}var _g,vg,yg,Z;function bg(){return(bg=e((()=>{K(),ar(),W(),rr(),B(),R(),tt(),yh(),Eh(),Ah(),Fh(),Xh(),dg(),mg(),_g=5,vg=3e4,yg=1.2,Z=class extends lt{constructor(...e){super(...e),this.src=``,this.sourceIdentity=``,this.label=``,this.mimeType=``,this.playback=`native`,this.authToken=null,this.voiceNote=!1,this.currentTime=0,this.duration=0,this.buffered=0,this.playing=!1,this.muted=!1,this.waveformPeaks=null,this.waveformWidth=0,this.media=null,this.waveformElement=null,this.waveformResizeObserver=null,this.sourceController=new pg,this.cancelPendingResume=()=>this.sourceController.cancelPendingResume(),this.playRequest=null,this.waveformController=null,this.waveformAttempted=!1,this.waveformVisible=!1,this.viewport=new kh(()=>{this.waveformVisible=!0,this.prepareWaveformAudio().catch(()=>void 0)}),this.setMedia=e=>{this.media=e instanceof HTMLAudioElement?e:null,this.media&&(this.media.muted=this.muted),this.syncSource()},this.setWaveform=e=>{let t=e instanceof HTMLElement?e:null;if(this.waveformElement!==t){if(this.waveformResizeObserver?.disconnect(),this.waveformResizeObserver=null,this.waveformElement=t,!t){this.waveformWidth=0;return}this.updateWaveformWidth(t.getBoundingClientRect().width),typeof ResizeObserver<`u`&&(this.waveformResizeObserver=new ResizeObserver(([e])=>{e&&this.waveformElement===e.target&&this.updateWaveformWidth(e.contentRect.width)}),this.waveformResizeObserver.observe(t))}}}connectedCallback(){super.connectedCallback(),queueMicrotask(()=>this.syncSource())}disconnectedCallback(){this.viewport.disconnect(),this.sourceController.cancel(),this.releaseWaveformBlob?.(),this.releaseWaveformBlob=void 0,this.waveformController?.abort(),this.waveformController=null,this.waveformAttempted=!1,this.waveformResizeObserver?.disconnect(),this.waveformResizeObserver=null,this.waveformElement=null,this.media&&(this.media.paused||this.media.pause(),Mh(this.media)),super.disconnectedCallback()}willUpdate(e){this.sourceController.readiness===`unavailable`&&(e.has(`src`)||e.has(`sourceIdentity`)||e.has(`playback`)||e.has(`authToken`))&&(this.releaseWaveformBlob?.(),this.releaseWaveformBlob=void 0,this.sourceController.cancel())}updated(e){(e.has(`src`)||e.has(`sourceIdentity`)||e.has(`playback`)||e.has(`authToken`)||e.has(`sizeBytes`)||e.has(`serverDurationMs`))&&((e.has(`sourceIdentity`)&&this.sourceController.currentIdentity&&this.sourceController.currentIdentity!==this.sourceIdentity.trim()||e.has(`playback`)||e.has(`authToken`))&&(this.waveformController?.abort(),this.waveformController=null,this.releaseWaveformBlob?.(),this.releaseWaveformBlob=void 0,this.waveformPeaks=null,this.waveformAttempted=!1,this.currentTime=0,this.duration=0,this.buffered=0,this.media&&!this.media.paused&&(this.media.pause(),Mh(this.media))),this.syncSource(),this.waveformVisible&&this.prepareWaveformAudio().catch(()=>void 0))}updateWaveformWidth(e){let t=Math.max(0,e);Math.abs(t-this.waveformWidth)>=.5&&(this.waveformWidth=t)}syncSource(){let e=this.media;if(!e||!this.isConnected||this.releaseWaveformBlob)return;let t=this.sourceController.sync(e,this.src,this.sourceIdentity,this.playback,this.authToken);this.requestUpdate(),t?.then(()=>{this.isConnected&&(this.requestUpdate(),this.waveformVisible&&this.prepareWaveformAudio().catch(()=>void 0))})}resolveWaveformCacheKey(){return[this.sourceIdentity.trim(),this.playback,this.src.trim(),this.authToken?.trim()??``].join(`\0`)}applyPreparedAudio(e,t){let n=this.media;if(!n||e!==this.resolveWaveformCacheKey()){t.release();return}this.releaseWaveformBlob?.(),this.releaseWaveformBlob=t.release,this.waveformPeaks=t.value.peaks?.length?t.value.peaks:null,t.value.durationSeconds!==void 0&&(this.duration=t.value.durationSeconds),this.sourceController.updateSource(n,t.value.blobUrl,this.sourceIdentity)}adoptPreparedAudioForPlayback(){let e=this.media;if(e){if(!this.releaseWaveformBlob){let e=this.resolveWaveformCacheKey(),t=Vh(e);t&&this.applyPreparedAudio(e,t)}this.sourceController.applyPendingSource(e)}}async prepareWaveformAudio(){let e=this.media,t=this.sourceController.readySource;if(!e||!t||this.releaseWaveformBlob||this.waveformAttempted)return;let n=this.resolveWaveformCacheKey(),r=Vh(n);if(r){this.applyPreparedAudio(n,r);return}let i=this.serverDurationMs===void 0?void 0:this.serverDurationMs/1e3;if(i===void 0||!Ih({sizeBytes:this.sizeBytes,durationSeconds:i}))return;let a=globalThis.AudioContext;if(!a)return;this.waveformAttempted=!0;let o=ag(this.authToken);o.set(`Accept`,`audio/*`);let s=new AbortController;this.waveformController=s;let c=setTimeout(()=>s.abort(new DOMException(`waveform fetch timed out`,`TimeoutError`)),vg),l,u;try{if(l=await fetch(t,{method:`GET`,headers:o,credentials:`same-origin`,signal:s.signal}),!l.ok)return;let e=await hg(l,Uh);if(!e)return;u=e}finally{clearTimeout(c),this.waveformController===s&&(this.waveformController=null)}let d=new Blob([u],{type:l.headers.get(`Content-Type`)?.split(`;`,1)[0]?.trim()||`audio/mpeg`}),f=URL.createObjectURL(d),p,m;if(Lh({sizeBytes:u.byteLength,durationSeconds:i})){let e=null;try{e=new a({sampleRate:Wh});let t=await e.decodeAudioData(u.slice(0)),n=Number.isFinite(t.duration)?t.duration:void 0;n!==void 0&&n<=i*yg&&(p=Rh(t),m=n)}catch{}finally{await e?.close().catch(()=>void 0)}}if(!this.isConnected||n!==this.resolveWaveformCacheKey()){URL.revokeObjectURL(f);return}let h=Hh(n,{blobUrl:f,sizeBytes:u.byteLength,...p?{peaks:p}:{},...m===void 0?{}:{durationSeconds:m}});h&&this.applyPreparedAudio(n,h)}togglePlayback(){let e=this.media;if(e&&this.sourceController.readiness===`ready`){if(e.paused){this.adoptPreparedAudioForPlayback(),jh(e,this.cancelPendingResume);let t=e.play();this.playRequest?t.catch(()=>{Mh(e),this.playing=!1}):this.playRequest=t.then(()=>this.prepareWaveformAudio().catch(()=>void 0)).catch(()=>{Mh(e),this.playing=!1}).finally(()=>{this.playRequest=null})}else e.pause()}}seekTo(e){let t=this.media;t&&this.sourceController.seek(t,Math.min(e,this.duration||e))&&(this.currentTime=t.currentTime)}toggleMuted(){this.muted=!this.muted,this.media&&(this.media.muted=this.muted)}handlePlayerKeydown(e){let t=e.target instanceof HTMLInputElement&&e.target.type===`range`;if(e.target===e.currentTarget||t){if(!t&&e.key===` `){e.preventDefault(),this.togglePlayback();return}if(e.key===`ArrowLeft`||e.key===`ArrowRight`||t&&(e.key===`ArrowDown`||e.key===`ArrowUp`)){e.preventDefault();let t=e.key===`ArrowLeft`||e.key===`ArrowDown`?-1:1;this.seekTo(this.currentTime+t*_g)}}}updateBuffered(){let e=this.media;if(!e||!this.duration||e.buffered.length===0){this.buffered=0;return}this.buffered=Math.min(1,e.buffered.end(e.buffered.length-1)/this.duration)}renderSeek(e){let t=this.waveformPeaks,n=H`<input
      class=${t?`chat-audio-player__seek chat-audio-player__seek--waveform`:`chat-audio-player__seek`}
      type="range"
      min="0"
      max=${String(this.duration||0)}
      step="0.01"
      .value=${String(Math.min(this.currentTime,this.duration||this.currentTime))}
      aria-label=${L(`chat.mediaPlayer.seek`)}
      aria-valuetext=${`${gg(this.currentTime)} / ${gg(this.duration)}`}
      style=${nr({"--chat-audio-progress":`${e*100}%`,"--chat-audio-buffered":`${Math.max(e,this.buffered)*100}%`})}
      @input=${e=>this.seekTo(Number(e.currentTarget.value))}
    />`;if(!t)return n;let r=this.waveformWidth>0?Math.max(1,Math.min(t.length,Math.floor(this.waveformWidth/5))):t.length,i=Array.from({length:r},(e,n)=>{let i=Math.floor(n*t.length/r),a=Math.max(i+1,Math.floor((n+1)*t.length/r)),o=0;for(let e=i;e<a;e+=1)o+=t[e]??0;let s=o/Math.max(1,a-i);return Math.min(1,Math.max(0,s))});return H`<div class="chat-audio-player__waveform" ${U(this.setWaveform)}>
      <svg viewBox="0 0 ${r} 24" preserveAspectRatio="none" aria-hidden="true">
        ${i.map((t,n)=>{let i=this.voiceNote?6+t*8:Math.max(2,t*20);return fr`<rect
              class=${n/r<e?`is-played`:``}
              x=${String(n+.25)}
              y=${String((24-i)/2)}
              width="0.5"
              height=${String(i)}
              rx="0.25"
            ></rect>`})}
      </svg>
      ${n}
    </div>`}render(){let e=this.duration>0?Math.min(1,this.currentTime/this.duration):0,t=Sh(this.src),n=this.sourceController.readiness===`unavailable`;if(n&&this.voiceNote)return H`<div
        class="chat-assistant-attachment-card chat-assistant-attachment-card--voice-note"
      >
        <div class="chat-audio-player" role="group" aria-label=${L(`chat.messages.voiceNote`)}>
          <span class="chat-assistant-attachment-card__reason" role="status"
            >${L(`chat.attachments.previewUnavailable`)}</span
          >
          ${t?H`<a class="chat-assistant-attachment-card__action" href=${t} download=${this.label} target="_blank" rel="noreferrer" aria-label=${L(`chat.mediaPlayer.download`,{filename:this.label})}>${z.download}</a>`:G}
        </div>
      </div>`;if(n)return ph({kind:`audio`,label:this.label,mimeType:this.mimeType,sizeBytes:this.sizeBytes,downloadHref:t,onExpand:this.onExpand,voiceNote:this.voiceNote});let r=`${gg(this.currentTime)} / ${gg(this.duration)}`;return H`
      <div
        class="chat-assistant-attachment-card chat-assistant-attachment-card--audio ${this.voiceNote?`chat-assistant-attachment-card--voice-note`:``}"
        ${U(this.viewport.setElement)}
        ?data-openable=${!this.voiceNote&&!!this.onExpand}
        @click=${e=>hh(e,this.voiceNote?void 0:this.onExpand)}
      >
        ${this.voiceNote?G:_h({kind:`audio`,label:this.label,mimeType:this.mimeType,sizeBytes:this.sizeBytes,downloadHref:t,onExpand:this.onExpand,visualMode:`preview-with-favicon`,voiceNote:this.voiceNote})}
        ${this.sourceController.readiness===`preparing`?H`<div class="chat-assistant-attachment-card__reason chat-media-preparing">
                ${L(`chat.mediaPlayer.preparing`)}
              </div>`:H`<div
                class="chat-audio-player"
                role="group"
                aria-label=${this.voiceNote?L(`chat.messages.voiceNote`):this.label}
                tabindex="0"
                @keydown=${e=>this.handlePlayerKeydown(e)}
              >
                <button
                  type="button"
                  class="chat-audio-player__toggle"
                  ?disabled=${this.playback===`transcode`&&this.sourceController.readiness!==`ready`}
                  aria-label=${L(this.playing?`chat.mediaPlayer.pause`:`chat.mediaPlayer.play`)}
                  @click=${()=>this.togglePlayback()}
                >
                  ${this.playing?z.pause:z.play}
                </button>
                <div class="chat-audio-player__time" aria-live="off">
                  <span>${r}</span>
                </div>
                <div class="chat-audio-player__timeline">${this.renderSeek(e)}</div>
                <button
                  type="button"
                  class="chat-audio-player__volume"
                  aria-label=${L(this.muted?`chat.mediaPlayer.unmute`:`chat.mediaPlayer.mute`)}
                  @click=${()=>this.toggleMuted()}
                >
                  ${this.muted?z.volumeX:z.volume2}
                </button>
              </div>`}
        <audio
          class="chat-audio-player__media"
          preload="metadata"
          ${U(this.setMedia)}
          @loadedmetadata=${()=>{this.media&&(this.sourceController.handleLoadedMetadata(this.media,()=>Nh(this.media)),this.duration=Number.isFinite(this.media.duration)?this.media.duration:0,this.currentTime=this.media.currentTime,this.updateBuffered(),this.onMediaLoaded?.())}}
          @durationchange=${()=>{this.media&&(this.duration=Number.isFinite(this.media.duration)?this.media.duration:0)}}
          @timeupdate=${()=>{this.media&&(this.currentTime=this.media.currentTime,this.updateBuffered())}}
          @progress=${()=>this.updateBuffered()}
          @play=${()=>{this.media&&jh(this.media,this.cancelPendingResume),this.playing=!0}}
          @pause=${()=>{this.playing=!1}}
          @ended=${()=>{this.media&&(Mh(this.media),this.sourceController.handleEnded(this.media)),this.playing=!1}}
          @error=${()=>{this.media&&!this.sourceController.handleError(this.media)&&(Mh(this.media),this.playing=!1),this.requestUpdate()}}
        ></audio>
      </div>
    `}},k([X()],Z.prototype,`src`,void 0),k([X()],Z.prototype,`sourceIdentity`,void 0),k([X()],Z.prototype,`label`,void 0),k([X()],Z.prototype,`mimeType`,void 0),k([X()],Z.prototype,`playback`,void 0),k([X()],Z.prototype,`authToken`,void 0),k([X({type:Number})],Z.prototype,`sizeBytes`,void 0),k([X({type:Number})],Z.prototype,`serverDurationMs`,void 0),k([X({type:Boolean})],Z.prototype,`voiceNote`,void 0),k([X({attribute:!1})],Z.prototype,`onExpand`,void 0),k([X({attribute:!1})],Z.prototype,`onMediaLoaded`,void 0),k([J()],Z.prototype,`currentTime`,void 0),k([J()],Z.prototype,`duration`,void 0),k([J()],Z.prototype,`buffered`,void 0),k([J()],Z.prototype,`playing`,void 0),k([J()],Z.prototype,`muted`,void 0),k([J()],Z.prototype,`waveformPeaks`,void 0),k([J()],Z.prototype,`waveformWidth`,void 0),customElements.get(`openclaw-chat-audio-player`)||customElements.define(`openclaw-chat-audio-player`,Z)})))()}var xg,Sg,Cg;function wg(){return(wg=e((()=>{K(),ar(),R(),tt(),yh(),Eh(),Ah(),xg=262144,Sg=1e4,Cg=class extends lt{constructor(...e){super(...e),this.src=``,this.sourceIdentity=``,this.label=``,this.mimeType=`image/svg+xml`,this.downloadHref=``,this.failed=!1,this.loadVersion=0,this.handleImageError=()=>{this.renderSource&&=(this.retireSource(this.renderSource),void 0),this.showFallback()},this.handleOpen=()=>{let e=this.renderSource;if(!e||!this.onOpen)return;let t=this.retainSource(e);try{this.onOpen(e.url,t)}catch(e){throw t(),e}}}connectedCallback(){super.connectedCallback(),this.src.trim()&&!this.renderSource&&!this.failed&&this.observeViewport()}disconnectedCallback(){this.stopObservingViewport?.(),this.stopObservingViewport=void 0,this.releaseSource(),super.disconnectedCallback()}updated(e){(e.has(`src`)||e.has(`sourceIdentity`)||e.has(`sizeBytes`))&&(this.releaseSource(),this.failed=!1,this.observeViewport())}observeViewport(){this.stopObservingViewport?.();let e=this.parentElement??this;this.stopObservingViewport=Dh(e,()=>{this.stopObservingViewport=void 0,this.loadSource()})}retireSource(e){e.retired=!0,e.retainCount===0&&URL.revokeObjectURL(e.url)}releaseSource(){this.loadVersion+=1,this.abortController?.abort(),this.abortController=void 0,this.renderSource&&=(this.retireSource(this.renderSource),void 0)}retainSource(e){e.retainCount+=1;let t=!1;return()=>{t||(t=!0,e.retainCount=Math.max(0,e.retainCount-1),e.retired&&e.retainCount===0&&URL.revokeObjectURL(e.url))}}showFallback(){this.failed||(this.failed=!0,this.onMediaLoaded?.())}async loadSource(){let e=this.loadVersion;if(this.sizeBytes!==void 0&&this.sizeBytes>xg){this.showFallback();return}if(bh(this.src)){this.showFallback();return}let t=new AbortController;this.abortController=t;let n;try{let r=await Promise.race([fetch(this.src,{credentials:`same-origin`,headers:{Accept:`image/svg+xml`},method:`GET`,signal:t.signal}),new Promise((e,r)=>{n=setTimeout(()=>{t.abort(),r(new DOMException(`SVG attachment fetch timed out`,`TimeoutError`))},Sg)})]);if(!r.ok)throw await r.body?.cancel().catch(()=>void 0),Error(`SVG attachment is unavailable`);let i=await hg(r,xg);if(!i)throw Error(`SVG attachment exceeds the preview budget`);let a=URL.createObjectURL(new Blob([i],{type:`image/svg+xml`}));if(e!==this.loadVersion||!this.isConnected){URL.revokeObjectURL(a);return}this.renderSource={url:a,retainCount:0,retired:!1}}catch{e===this.loadVersion&&this.showFallback()}finally{clearTimeout(n),this.abortController===t&&(this.abortController=void 0)}}render(){if(this.failed)return ph({kind:`document`,label:this.label,mimeType:this.mimeType,sizeBytes:this.sizeBytes,downloadHref:this.downloadHref,onExpand:this.onExpand});let e=this.renderSource;return e?H`<button
      type="button"
      class="chat-message-image-button"
      aria-label=${L(`chat.imageLightbox.open`,{title:this.label})}
      @click=${this.handleOpen}
    >
      <img
        src=${e.url}
        alt=${this.label}
        class="chat-message-image"
        @load=${this.onMediaLoaded}
        @error=${this.handleImageError}
      />
    </button>`:G}},k([X()],Cg.prototype,`src`,void 0),k([X()],Cg.prototype,`sourceIdentity`,void 0),k([X()],Cg.prototype,`label`,void 0),k([X()],Cg.prototype,`mimeType`,void 0),k([X({type:Number})],Cg.prototype,`sizeBytes`,void 0),k([X()],Cg.prototype,`downloadHref`,void 0),k([X({attribute:!1})],Cg.prototype,`onOpen`,void 0),k([X({attribute:!1})],Cg.prototype,`onExpand`,void 0),k([X({attribute:!1})],Cg.prototype,`onMediaLoaded`,void 0),k([J()],Cg.prototype,`renderSource`,void 0),k([J()],Cg.prototype,`failed`,void 0),customElements.get(`openclaw-chat-svg-attachment`)||customElements.define(`openclaw-chat-svg-attachment`,Cg)})))()}var Tg;function Eg(){return(Eg=e((()=>{K(),ar(),W(),rr(),B(),R(),tt(),yh(),Eh(),Ah(),mg(),Tg=class extends lt{constructor(...e){super(...e),this.src=``,this.preview=!1,this.sourceIdentity=``,this.label=``,this.mimeType=``,this.playback=`native`,this.authToken=null,this.frameReady=!1,this.media=null,this.mediaVisible=!1,this.viewport=new kh(()=>{this.mediaVisible=!0,this.syncSource()}),this.sourceController=new pg,this.setMedia=e=>{this.frameReady=!1,this.media=e instanceof HTMLVideoElement?e:null,this.syncSource()},this.expand=()=>{let e=this.sourceController.readySource;e&&(this.media?.pause(),this.querySelector(`.chat-assistant-attachment-card__expand`)?.focus({preventScroll:!0}),this.onExpand?.(e))}}connectedCallback(){super.connectedCallback(),queueMicrotask(()=>this.syncSource())}disconnectedCallback(){this.viewport.disconnect(),this.sourceController.cancel(),this.media&&this.sourceController.reset(this.media),super.disconnectedCallback()}willUpdate(e){e.has(`src`)&&!this.src&&this.media&&(this.sourceController.cancel(),this.sourceController.reset(this.media)),this.sourceController.readiness===`unavailable`&&(e.has(`src`)||e.has(`sourceIdentity`)||e.has(`playback`)||e.has(`authToken`))&&this.sourceController.cancel()}updated(e){(e.has(`src`)||e.has(`sourceIdentity`)||e.has(`playback`)||e.has(`authToken`))&&this.syncSource()}syncSource(){let e=this.media;if(!e||!this.isConnected||!this.mediaVisible)return;let t=this.sourceController.sync(e,this.src,this.sourceIdentity,this.playback,this.authToken);this.requestUpdate(),t?.then(()=>{this.isConnected&&this.requestUpdate()})}adoptPendingSource(){return!this.media||!this.sourceController.applyPendingSource(this.media)?!1:(this.requestUpdate(),!0)}render(){let e=Sh(this.src),t=this.sourceController.readiness===`preparing`&&!this.preview;if(this.sourceController.readiness===`unavailable`)return ph({kind:`video`,label:this.label,mimeType:this.mimeType,sizeBytes:this.sizeBytes,downloadHref:e,onExpand:this.onFallbackExpand});let n=this.preview&&!this.frameReady,r=this.onExpand&&this.sourceController.readySource?this.expand:void 0,i=this.mediaWidth&&this.mediaHeight?{"aspect-ratio":`${this.mediaWidth} / ${this.mediaHeight}`}:this.preview?{"aspect-ratio":`16 / 9`}:{};return H`
      <div
        class="chat-assistant-attachment-card chat-assistant-attachment-card--video ${n?`chat-assistant-attachment-card--loading`:``}"
        aria-busy=${n?`true`:G}
        ${U(this.viewport.setElement)}
        ?data-openable=${!!r}
        @click=${e=>hh(e,r)}
      >
        ${_h({kind:`video`,label:this.label,mimeType:this.mimeType,sizeBytes:this.sizeBytes,downloadHref:e,downloadPending:this.preview&&!e,loading:n,expandLabel:L(`chat.mediaPlayer.openVideo`,{filename:this.label}),onExpand:r,visualMode:`preview-with-favicon`})}
        ${t?H`<div class="chat-assistant-attachment-card__reason chat-media-preparing">
                ${L(`chat.mediaPlayer.preparing`)}
              </div>`:null}
        <div class="chat-assistant-video-frame" ?hidden=${t}>
          ${n?H`<div
                  class="chat-video-skeleton"
                  role="status"
                  aria-label=${L(`common.loading`)}
                >
                  <div class="chat-video-skeleton__controls" aria-hidden="true">
                    ${z.play}<span>0:00<span>/ 0:00</span></span>
                    ${z.volume2}${z.maximize}${z.moreHorizontal}
                  </div>
                  <div class="chat-video-skeleton__timeline skeleton" aria-hidden="true"></div>
                </div>`:G}
          <video
            controls
            aria-label=${this.label.trim()||L(`chat.attachments.video`)}
            preload=${this.preview?`auto`:`metadata`}
            style=${nr(i)}
            ${U(this.setMedia)}
            @loadeddata=${()=>{this.frameReady=!0}}
            @playing=${()=>{this.frameReady=!0}}
            @emptied=${()=>{this.frameReady=!1}}
            @loadedmetadata=${()=>{this.media&&(this.sourceController.handleLoadedMetadata(this.media),this.onMediaLoaded?.())}}
            @ended=${()=>{this.media&&this.sourceController.handleEnded(this.media)&&this.requestUpdate()}}
            @play=${()=>this.adoptPendingSource()}
            @seeking=${()=>{!this.adoptPendingSource()&&this.media?.error&&this.sourceController.handleError(this.media)&&this.requestUpdate()}}
            @error=${()=>{this.media&&(this.sourceController.handleError(this.media),this.requestUpdate())}}
          ></video>
        </div>
      </div>
    `}},k([X()],Tg.prototype,`src`,void 0),k([X({type:Boolean})],Tg.prototype,`preview`,void 0),k([X()],Tg.prototype,`sourceIdentity`,void 0),k([X()],Tg.prototype,`label`,void 0),k([X()],Tg.prototype,`mimeType`,void 0),k([X()],Tg.prototype,`playback`,void 0),k([X()],Tg.prototype,`authToken`,void 0),k([X({type:Number})],Tg.prototype,`sizeBytes`,void 0),k([X({type:Number})],Tg.prototype,`mediaWidth`,void 0),k([X({type:Number})],Tg.prototype,`mediaHeight`,void 0),k([X({attribute:!1})],Tg.prototype,`onExpand`,void 0),k([X({attribute:!1})],Tg.prototype,`onFallbackExpand`,void 0),k([X({attribute:!1})],Tg.prototype,`onMediaLoaded`,void 0),k([J()],Tg.prototype,`frameReady`,void 0),customElements.get(`openclaw-chat-video-player`)||customElements.define(`openclaw-chat-video-player`,Tg)})))()}function Dg(e,t={},n=!1){if(!Zh(e))return{status:`available`};let r=Ig(e,t),i=r.value,a=null;if(i){let e=Date.now();if(i.status===`unavailable`&&i.recoverable&&!i.retryAttempted&&e-i.checkedAt>=5e3)r.retryAttempted=!0,r.value=void 0;else if(i.status===`available`&&i.mediaTicket&&i.mediaTicketExpiresAt!==void 0&&i.mediaTicketExpiresAt<=e){let e=jg(`Attachment unavailable`,r.retryAttempted,{unconfirmed:!0});return Lg(r,e),e}else if(i.status===`available`&&i.mediaTicket&&(i.refreshAfter===void 0?!i.mediaTicketExpiresAt||i.mediaTicketExpiresAt-e<=3e4:i.refreshAfter<=e)){if(r.pending)return i;a=i}else return Rg(r,i),i}a||Lg(r,{status:`checking`});let o=()=>{if(!a)return null;let e=Date.now(),t=a.mediaTicketExpiresAt,n=a.refreshAttempts??0;return t===void 0||t<=e||n>=2?null:{...a,refreshAfter:Math.min(e+Vg,t),refreshAttempts:n+1}};if(typeof fetch==`function`){let i=new Headers({Accept:`application/json`}),s=t.authToken?.trim();s&&i.set(`Authorization`,`Bearer ${s}`);let c=new AbortController;r.abortController=c;let l=setTimeout(()=>c.abort(new DOMException(`assistant attachment metadata fetch timed out`,`TimeoutError`)),Hg),u=$h(e,t.resourceBasePath,a?.mediaTicket,t),d=jt(`${u}&meta=1${n?`&allow=1`:``}`,{method:n?`POST`:`GET`,headers:i,credentials:`same-origin`,signal:c.signal}).then(async e=>{if(e.status===408||e.status===429||e.status>=500)throw Error(`Attachment metadata temporarily unavailable`);if(!e.ok)return jg(L(`chat.attachments.unavailable`),r.retryAttempted);let t=await e.json();if(t?.available===!1)return jg(t.code===`outside-allowed-folders`?L(`chat.attachments.outsideAllowedFolders`):me(t.reason,L(`chat.attachments.unavailable`)),r.retryAttempted,{recoverable:t.retryable!==!1,canAllow:t.canAllow===!0});if(t?.available===!0){let e=t.mediaTicket?.trim(),n=Date.parse(t.mediaTicketExpiresAt??``);if(e&&!Number.isFinite(n))throw Error(`Attachment metadata has an invalid ticket expiry`);return{status:`available`,...e?{mediaTicket:e,mediaTicketExpiresAt:n}:{},...t.playback===`native`||t.playback===`transcode`?{playback:t.playback}:{},...typeof t.sizeBytes==`number`?{sizeBytes:t.sizeBytes}:{},...typeof t.durationMs==`number`?{durationMs:t.durationMs}:{},...typeof t.width==`number`?{width:t.width}:{},...typeof t.height==`number`?{height:t.height}:{}}}throw Error(`Attachment metadata has no availability result`)}).catch(()=>o()??jg(L(`chat.attachments.unavailable`),r.retryAttempted,{unconfirmed:!0})).then(e=>(r.pending===d&&kp(r)&&(e.status===`available`&&(r.retryAttempted=!1),Lg(r,e)),e)).finally(()=>{clearTimeout(l),r.pending===d&&(r.abortController=void 0,r.pending=void 0,jp(r))});r.pending=d}return a??{status:`checking`}}async function Og(e,t={}){let n=Dg(e,t);if(n.status!==`checking`)return n;let r=Ig(e,t);return await r.pending,kp(r)?r.value??null:null}function kg(e,t={},n=!1){if(!Zh(e)){t.onRequestUpdate?.();return}let r=Ig(e,t);Ag(r),n&&Dg(e,t,!0),jp(r),t.onRequestUpdate?.()}function Ag(e){e.abortController?.abort(),e.abortController=void 0,e.pending=void 0,e.value=void 0,e.retainUntil=void 0,e.retryAttempted=!1,Mp(e)}function jg(e,t,n={}){return{status:`unavailable`,reason:e,checkedAt:Date.now(),recoverable:n.recoverable!==!1,...n.unconfirmed?{unconfirmed:!0}:{},...t?{retryAttempted:!0}:{},...n.canAllow?{canAllow:!0}:{}}}function Mg(e,t){return JSON.stringify([t.connectionEpoch??0,t.resourceBasePath??``,t.authToken?.trim()??``,t.sessionKey,t.agentId,e])}function Ng(e,t){let n=Ep(`assistant-attachment`,JSON.stringify([Mg(e,t),t.policyKey]));return n&&!n.discardWhenIdle&&n.value?.status===`available`&&n.retainUntil!==void 0&&n.retainUntil>Date.now()?n:void 0}function Pg(e,t={}){let n=Ng(e,t),r=n?.retainedImage;return n&&(n.retainedImage=void 0),r}function Fg(e,t,n={},r){let i=Ng(e,n),a=i?.value;i&&a?.status===`available`&&t.complete&&t.naturalWidth>0&&t.getAttribute(`src`)===$h(e,n.resourceBasePath,a.mediaTicket,n,r)&&(i.retainedImage=t)}function Ig(e,t){let n=Mg(e,t),r=Dp(`assistant-attachment`,JSON.stringify([n,t.policyKey]),t.onRequestUpdate,e,n);return r.subscribers.size>0&&!r.releaseAuthRecovery&&(r.releaseAuthRecovery=Nn(()=>{kp(r)&&r.value?.status===`unavailable`&&(Ag(r),jp(r))})),r}function Lg(e,t){kp(e)&&(e.value=t,e.retainedImage=void 0,e.retainUntil=t.status===`available`?t.mediaTicketExpiresAt??1/0:void 0,Rg(e,t))}function Rg(e,t){Np(e,t.status===`unavailable`&&t.recoverable&&!t.retryAttempted?t.checkedAt+Vg:t.status===`available`&&t.mediaTicket&&t.mediaTicketExpiresAt?t.refreshAfter??t.mediaTicketExpiresAt-3e4:void 0,()=>{e.value===t&&jp(e)})}function zg(e){try{let t=new URL(e,window.location.origin);return t.origin===window.location.origin&&t.pathname.startsWith(`/api/chat/media/outgoing/`)}catch{return!1}}function Bg(e){try{let t=new URL(e,window.location.origin).pathname.split(`/`)[5];return t?decodeURIComponent(t):null}catch{return null}}var Vg,Hg;function Ug(){return(Ug=e((()=>{pn(),R(),ft(),ng(),Qp(),Vg=5e3,Hg=3e4})))()}function Wg(e){let t=su(e);return H`
    <span class="chat-attachment-file__preview" aria-hidden="true">
      ${Qn([t],()=>Es(t?.then(e=>e?H`
                  <img src=${e} alt="" />
                  <span class="chat-attachment-video__play">${z.play}</span>
                `:z.play)??z.play,z.play))}
    </span>
  `}function Gg(e,t){let{family:n,extensionLabel:r}=rh(e.fileName??`attachment`,e.mimeType),i=t?.label??e.fileName??L(`chat.attachments.attachedFile`),a=n===`audio`?z.music:z.fileText,o=H`<div
    class=${`chat-attachment-file${n===`video`?` chat-attachment-file--video`:``}`}
    @click=${e=>{e.target instanceof Element&&!e.target.closest(`button`)&&t?.onOpen?.()}}
  >
    ${n===`video`?Wg(e):H`<span class="chat-attachment-file__icon" data-family=${n}>${a}</span>`}
    <span class="chat-attachment-file__body">
      ${t?.onOpen?H`<button
              class="chat-attachment-file__name chat-attachment-file__open"
              type="button"
              title=${i}
              @click=${t.onOpen}
            >
              ${i}
            </button>`:H`<span class="chat-attachment-file__name">${i}</span>`}
      ${t?.metadata??H`<span class="chat-attachment-file__type">${r}</span>`}
    </span>
  </div>`;return t?o:H`<openclaw-tooltip .content=${i}>${o}</openclaw-tooltip>`}function Kg(){return(Kg=e((()=>{K(),pr(),Vs(),B(),R(),cu(),ch()})))()}function qg(e){let t=H`
    <span aria-hidden="true">${e.icon}</span>
    <span
      class=${e.removal?`chat-selection-annotations__label`:`chat-attachment-preview-label`}
      dir="auto"
      >${e.label}</span
    >
  `;return H`<span
    class="chat-attachment-thumb chat-attachment-thumb--file chat-selection-annotations__chip"
    role=${e.removal?G:`button`}
    tabindex=${e.removal?G:`0`}
    @pointerenter=${e.onReveal}
    @focusin=${e.onReveal}
    @click=${e.onClick}
    @keydown=${t=>{!e.removal&&e.keyboardClick!==!1&&(t.key===`Enter`||t.key===` `)&&t.currentTarget instanceof HTMLElement&&(t.preventDefault(),t.currentTarget.click())}}
  >
    ${e.removal?H`<button
            type="button"
            class="chat-attachment-file chat-selection-annotations__trigger"
          >
            ${t}
          </button>`:H`<span class="chat-attachment-file">${t}</span>`}
    ${e.removal?H`<button
            type="button"
            class="chat-selection-annotations__remove"
            aria-label=${e.removal.label}
            ?disabled=${e.removal.disabled}
            @click=${e.removal.onRemove}
          >
            ${z.x}
          </button>`:G}
  </span>`}function Jg(e){return H`<openclaw-tooltip
    class=${e.removal?`chat-comment-preview chat-comment-preview--editable`:`chat-comment-preview`}
    placement="top-start"
    auto-size
    .describe=${!1}
    .openOnClick=${e.openOnClick??!1}
    .hoverDismissDelay=${e.removal?200:void 0}
  >
    ${qg({label:e.label,icon:e.icon,onReveal:e.onReveal,onClick:e.openOnClick?e.onReveal:void 0,keyboardClick:e.openOnClick??!1,removal:e.removal})}
    <div
      slot="content"
      class="chat-comment-preview__scroll"
      tabindex="0"
      role="region"
      aria-label=${e.regionLabel}
      ${Ic()}
    >
      ${e.content}
    </div>
  </openclaw-tooltip>`}function Yg(){return(Yg=e((()=>{K(),B(),oc(),V()})))()}async function Xg(e,t,n,r=`full`){let i=r===`excerpt`,a=r===`html`?Sr:Zg;if(!i&&t!==void 0&&t>a)throw Error(`Text attachment exceeds preview limit`);let o=new AbortController,s=setTimeout(()=>o.abort(),1e4);try{let t=await fetch(e,{credentials:`same-origin`,redirect:`error`,signal:AbortSignal.any([n,o.signal])});if(!t.ok)throw await t.body?.cancel(),Error(`Text attachment unavailable`);let r=await hg(t,a,{truncate:i});if(!r)throw Error(`Text attachment exceeds preview limit`);let s=new TextDecoder(`utf-8`,{fatal:!0,ignoreBOM:!0}).decode(r,{stream:i});if(s.includes(`\0`))throw Error(`Binary attachment`);return s}finally{clearTimeout(s)}}var Zg;function Qg(){return(Qg=e((()=>{Cr(),Zg=262144})))()}function $g(e){let{mimeType:t,origin:n,fileName:r}=e;return t.split(`;`,1)[0]?.trim().toLowerCase()===`text/plain`&&(n===`paste`||n===void 0&&/^pasted-text-\d+\.txt$/.test(r??``))}function e_(e){return e.type===`attachment`&&e.attachment.kind===`document`&&$g({mimeType:e.attachment.mimeType??``,fileName:e.attachment.label,origin:e.attachment.origin})}var t_;function n_(){return(n_=e((()=>{K(),ar(),B(),R(),tt(),Kg(),Yg(),Qg(),t(),t_=class extends lt{constructor(...e){super(...e),this.scope=``,this.excerpt=``,this.key=``}connectedCallback(){super.connectedCallback(),this.requestUpdate()}disconnectedCallback(){this.loading?.abort(),this.key=``,super.disconnectedCallback()}willUpdate(e){let t=JSON.stringify([this.scope,this.src,this.sizeBytes]);if(t===this.key||(this.loading?.abort(),this.key=t,this.excerpt=``,!this.src))return;let n=new AbortController;this.loading=n,this.loadExcerpt(this.src,n)}async loadExcerpt(e,t){let n=()=>this.isConnected&&this.loading===t&&!t.signal.aborted;try{let r=await Xg(e,this.sizeBytes,t.signal,`excerpt`);if(!n())return;let{derivePastedTextExcerpt:i}=await ne(async()=>{let{derivePastedTextExcerpt:e}=await import(`./pasted-text-excerpt-DvJPa5Ex.js`);return{derivePastedTextExcerpt:e}},__vite__mapDeps([8,1,2,3,4,5,6,7]),import.meta.url);n()&&(this.excerpt=i(r))}catch{}}render(){return this.composerAction?H`<div
        class="chat-attachment-thumb chat-attachment-thumb--file chat-attachment-thumb--pasted-text"
      >
        ${Gg({id:this.scope,mimeType:`text/plain`},{label:this.excerpt||L(`chat.attachments.pastedText`),metadata:this.composerAction,onOpen:this.onOpen})}
        ${this.composerRemoveAction}
      </div>`:qg({label:this.excerpt||L(`chat.attachments.pastedText`),icon:z.fileText,onClick:this.onOpen})}},k([X()],t_.prototype,`src`,void 0),k([X({attribute:!1})],t_.prototype,`sizeBytes`,void 0),k([X({attribute:!1})],t_.prototype,`scope`,void 0),k([X({attribute:!1})],t_.prototype,`onOpen`,void 0),k([X({attribute:!1})],t_.prototype,`composerAction`,void 0),k([X({attribute:!1})],t_.prototype,`composerRemoveAction`,void 0),k([J()],t_.prototype,`excerpt`,void 0),customElements.define(`openclaw-chat-pasted-text`,t_)})))()}function r_(e,t){let{attachment:n}=e;return(Zh(n.url)||zg(n.url))&&Up(n)!==`svg`&&(t!==`inline`||n.kind!==`audio`&&n.kind!==`video`)&&(t!==`preview`||n.kind!==`video`)&&!(t===`card`&&e_(e))}var i_,a_;function o_(){return(o_=e((()=>{K(),$n(),sr(),Ah(),Ug(),ng(),Qp(),n_(),i_=class extends Wn{constructor(...e){super(...e),this.key=``,this.generation=0,this.admitted=!1,this.admit=()=>{this.isConnected&&!this.admitted&&(this.admitted=!0,this.stopObserving?.(),this.stopObserving=void 0,this.refresh())},this.observeCard=e=>{if(this.stopObserving?.(),this.stopObserving=void 0,!e||!this.isConnected||this.admitted)return;let t=this.generation;this.stopObserving=Dh(e,()=>{t===this.generation&&this.admit()})},this.refresh=()=>{this.isConnected&&this.input&&this.setValue(this.render(this.input))}}render(e){let{attachment:t,options:n}=e,r=JSON.stringify([t.url,t.artifactId,n.sessionKey,n.agentId,n.connectionEpoch,n.resourceBasePath,n.authToken,n.policyKey]);return r!==this.key&&(this.generation++,this.stopObserving?.(),this.stopObserving=void 0,this.admitted=!1),this.key=r,this.input=e,this.isConnected?(typeof IntersectionObserver!=`function`&&(this.admitted=!0),H`${Y(r,e.render({observeCard:this.admitted?void 0:this.observeCard,onFocus:this.admit}))}`):Gn}disconnected(){this.generation++,this.stopObserving?.(),this.stopObserving=void 0,this.admitted=!1}reconnected(){this.refresh()}},a_=Kn(i_)})))()}function s_(e,t,n,r,i){let a=Be(t,window.location.href,{allowDataImage:!0});if(!a){r?.();return}if(e){let t={src:a,title:n,...r?{release:r}:{}};i===void 0?e(t):e(t,i);return}r?.(),ct(a,{allowDataImage:!0})}function c_(){return(c_=e((()=>{Pe()})))()}var l_,u_;function d_(){return(d_=e((()=>{K(),$n(),W(),B(),R(),is(),Ah(),l_=class extends Wn{constructor(...e){super(...e),this.failed=!1,this.visible=!1,this.setElement=e=>{this.element=e,this.observe()}}render(e){return this.input?.key!==e.key&&(this.release(),this.failed=!1),this.input=e,this.requestPoster(),this.template()}requestPoster(){if(!this.isConnected||!this.visible||!this.input||this.controller||this.failed)return;let e=new AbortController;this.controller=e,Hi({key:this.input.key,src:this.input.src,width:400,height:225,signal:e.signal}).then(t=>{this.controller===e&&!e.signal.aborted&&this.isConnected&&this.visible&&(t?this.posterUrl=URL.createObjectURL(t):this.failed=!0,this.setValue(this.template()))})}release(){this.controller?.abort(),this.controller=void 0,this.posterUrl&&=(URL.revokeObjectURL(this.posterUrl),void 0)}failPoster(e){this.isConnected&&this.posterUrl===e&&(this.release(),this.failed=!0,this.setValue(this.template()))}setVisible(e){this.isConnected&&this.visible!==e&&(this.visible=e,e?this.requestPoster():(this.release(),this.setValue(this.template())))}observe(){this.stopObserving?.(),this.stopObserving=this.element&&this.isConnected?Dh(this.element,()=>this.setVisible(!0),()=>this.setVisible(!1)):void 0}disconnected(){this.stopObserving?.(),this.stopObserving=void 0,this.visible=!1,this.release()}reconnected(){this.setValue(this.template()),this.observe()}template(){let e=this.input;if(!e)return G;let t=this.posterUrl;return H`<div class="chat-video-preview__content" ${U(this.setElement)}>
      ${this.failed?e.fallback:H`<button
              type="button"
              class="chat-message-image-button"
              aria-label=${`${L(`chat.attachments.open`)}: ${e.label}`}
              @click=${e.onOpen}
            >
              ${t?H`<img class="chat-message-image" src=${t} alt=${e.label} @error=${()=>this.failPoster(t)} />`:H`<span class="chat-message-image chat-video-preview__placeholder"></span>`}
              <span class="chat-video-preview__play" aria-hidden="true">${z.play}</span>
            </button>`}
    </div>`}},u_=Kn(l_)})))()}function f_(e){let t=/\n\nSource session: [^\n]+\n(?:Source message: [^\n]+\n)?(?:Source entry: [^\n]+\n)?(?:Selected text UTF-16 length: (\d+)\n)?DOM text UTF-16 range: \[(\d+), (\d+)\)$/.exec(e);if(!t||!e.startsWith(`Selected text:
`))return null;let n=Number(t[2]),r=Number(t[3]),i=t[1]===void 0?r-n:Number(t[1]);if(!Number.isSafeInteger(n)||!Number.isSafeInteger(r)||r<n||!Number.isSafeInteger(i)||i<=0)return null;let a=e.slice(15,t.index),o=a.slice(0,i),s=a.slice(i);return o.length!==i||s&&!s.startsWith(`

User comment:
`)?null:{text:o,comment:s?s.slice(16):``}}function p_(e,t=G){return H`<li class="chat-comment-preview__item">
    <div class="chat-comment-preview__body">
      <span class="muted">${L(`chat.messages.annotationSelectedText`)}</span>
      <div
        class="chat-comment-preview__text chat-comment-preview__text--selection"
        .textContent=${e.text}
      ></div>
      ${e.comment?H`<span class="muted">${L(`chat.messages.annotationUserComment`)}</span>
              <div
                class="chat-comment-preview__text chat-comment-preview__text--comment"
                tabindex="0"
                role="region"
                aria-label=${L(`chat.messages.annotationUserComment`)}
                .textContent=${e.comment}
                ${Ic()}
              ></div>`:G}
    </div>
    ${t}
  </li>`}function m_(e,t,n,r=!1,i){return Jg({label:L(e===1?`chat.messages.annotationCount`:`chat.messages.annotationsCount`,{count:String(e)}),regionLabel:L(`chat.messages.annotations`),icon:z.messageSquare,content:t,onReveal:n,openOnClick:r,removal:i?{...i,label:L(`chat.messages.removeAnnotations`)}:void 0})}function h_(){return(h_=e((()=>{K(),B(),oc(),R(),$r(),Yg(),di()})))()}function g_(e){return e.type===`attachment`&&e.attachment.kind===`document`&&e.attachment.label===`selection-comment.txt`&&e.attachment.mimeType?.split(`;`,1)[0]?.trim().toLowerCase()===`text/plain`}var __;function v_(){return(v_=e((()=>{K(),ar(),R(),tt(),Qg(),h_(),__=class extends lt{constructor(...e){super(...e),this.sources=[],this.scope=``,this.revealed=!1,this.comments=[],this.key=``}disconnectedCallback(){this.loading?.abort(),this.key=``,super.disconnectedCallback()}willUpdate(e){let t=JSON.stringify([this.scope,this.sources.map(({fallback:e,...t})=>t)]);if(this.key!==t&&(this.loading?.abort(),this.loading=void 0,this.key=t,this.comments=this.sources.map(e=>!e.src&&!e.pending?null:void 0)),this.revealed&&!this.loading){let e=new AbortController;this.loading=e,this.sources.forEach((t,n)=>{t.src&&Xg(t.src,t.sizeBytes,e.signal).then(t=>this.accept(n,f_(t),e),()=>this.accept(n,null,e))})}}accept(e,t,n){this.isConnected&&this.loading===n&&!n.signal.aborted&&(this.comments=this.sources.map((n,r)=>r===e?t:this.comments[r]))}render(){let e=this.sources.filter((e,t)=>this.comments[t]!==null);return H`${e.length?m_(e.length,H`<ol class="chat-comment-preview__list" role="list">
              ${this.sources.map((e,t)=>{let n=this.comments[t];return n?p_(n):n===null?G:H`<li class="chat-comment-preview__item muted">
                        ${e.src||e.pending?L(`common.loading`):L(`chat.attachments.textPreviewUnavailable`)}
                      </li>`})}
            </ol>`,()=>{this.revealed=!0},!0):G}
    ${this.sources.map((e,t)=>this.comments[t]===null?e.fallback:G)}`}},k([X({attribute:!1})],__.prototype,`sources`,void 0),k([X()],__.prototype,`scope`,void 0),k([J()],__.prototype,`revealed`,void 0),k([J()],__.prototype,`comments`,void 0),customElements.define(`openclaw-chat-sent-comments`,__)})))()}function y_(e,t,n){return{kind:`video`,src:``,title:e.label,connectVideo:(r,i,a=!1)=>{let o=new pg,s=!0,c=a,l=()=>{s&&i(o.readiness===`idle`?`preparing`:o.readiness)},u=()=>{if(!s)return;let n=t(u);if(n.status!==`available`){if(n.status===`unavailable`&&c&&n.onRetry){c=!1,n.onRetry();return}o.cancel(),o.reset(r),i(n.status===`checking`?`preparing`:`unavailable`,!!n.onRetry);return}let a=Sh(n.source.src,`video`);if(!a){o.cancel(),o.reset(r),i(`unavailable`,!1);return}let d=o.sync(r,a,e.url,n.source.playback,n.source.authToken);l(),d?.then(l)};n&&Pp(n,u);let d=()=>o.handleLoadedMetadata(r,()=>s),f=()=>{o.applyPendingSource(r),l()},p=()=>{o.handleEnded(r),l()},m=()=>{o.handleError(r),l()};return r.addEventListener(`loadedmetadata`,d),r.addEventListener(`play`,f),r.addEventListener(`seeking`,f),r.addEventListener(`ended`,p),r.addEventListener(`error`,m),u(),()=>{s=!1,r.removeEventListener(`loadedmetadata`,d),r.removeEventListener(`play`,f),r.removeEventListener(`seeking`,f),r.removeEventListener(`ended`,p),r.removeEventListener(`error`,m),o.cancel(),o.reset(r),Fp(u)}}}}function b_(){return(b_=e((()=>{Eh(),mg(),Qp()})))()}function x_(){return{status:`unavailable`,reason:L(`chat.attachments.unavailable`),checkedAt:Date.now()}}function S_(e,t,n=Date.now()){let r=e?.expiresAt!==void 0&&e.expiresAt<=n?null:e;return t>=2?r?.expiresAt?{...r,refreshAfter:r.expiresAt,refreshAttempts:t}:x_():{...r??{status:`checking`},refreshAfter:n+Vg*2**t,refreshAttempts:t+1}}function C_(e,t,n=!1){return kp(e)?(e.value=t,Np(e,t.status===`checking`?t.refreshAfter:t.status===`available`&&t.expiresAt!==void 0?n?t.expiresAt:Math.min(t.refreshAfter??t.expiresAt-3e4,t.expiresAt):t.status===`unavailable`&&!e.retryAttempted?t.checkedAt+Vg:void 0,()=>{e.value?.status===`unavailable`&&(e.retryAttempted=!0,e.value=void 0),jp(e)}),t):t}function w_(e,t,n,r){if(!zg(e.url))return{status:`available`,url:e.url};if(!e.artifactId||!t)return new URL(e.url,window.location.origin).searchParams.get(`mediaTicket`)?.trim()?{status:`available`,url:e.url}:x_();let i=Bg(e.url);if(!i)return x_();let a=Dp(`managed-media`,`${r??0}::${e.url}::${e.artifactId}`,n,e.url),o=a.value,s=Date.now();if(o?.status===`unavailable`||o?.status===`checking`&&o.refreshAfter!==void 0&&o.refreshAfter>s)return C_(a,o);if(o?.status===`available`){let e=o.expiresAt!==void 0&&o.expiresAt<=s;if(e&&(o.refreshAttempts??0)>=2)return a.retryAttempted=!0,C_(a,x_());if(e&&(a.pending||o.refreshAfter!==void 0&&o.refreshAfter>s))return C_(a,{status:`checking`,refreshAfter:a.pending?void 0:o.refreshAfter,refreshAttempts:o.refreshAttempts});let t=o.refreshAfter??(o.expiresAt===void 0?void 0:o.expiresAt-3e4);if(t===void 0||t>s)return C_(a,o)}if(a.pending)return o?.status===`available`?o:{status:`checking`};let c=o?.status===`available`&&(o.expiresAt===void 0||o.expiresAt>s)?o:null,l=o?.refreshAttempts??0,u=()=>c||o?.status===`checking`?S_(c,l):x_();c||C_(a,{status:`checking`});let d=Promise.resolve().then(async()=>{let n;try{let r=await t({sessionKey:i,artifactId:e.artifactId}),a=r?.url.trim();if(!a)n=u();else{let e=Date.parse(r?.expiresAt??``),t=Date.now(),i=Number.isFinite(e)?e:t+3e5,o={status:`available`,url:a,expiresAt:i};n=i-t>3e4?o:S_(l>=2&&c?.expiresAt!==void 0&&c.expiresAt>=i?c:o,l,t)}}catch{n=u(),n.status===`unavailable`&&(n={...n,error:!0})}return kp(a)?(n.status===`available`&&n.refreshAttempts===void 0?a.retryAttempted=!1:n.status===`unavailable`&&l>=2&&(a.retryAttempted=!0),C_(a,n)):null}).finally(()=>{a.pending===d&&(a.pending=void 0),jp(a)});return a.pending=d,c&&C_(a,c,!0),c??{status:`checking`}}function T_(e,t,n){if(!e.artifactId||!zg(e.url))return;let r=Dp(`managed-media`,`${n??0}::${e.url}::${e.artifactId}`,t,e.url);r.value=void 0,r.retryAttempted=!1,r.unavailableAt=void 0,jp(r),t?.()}function E_(e,t){let{resourceBasePath:n,authToken:r,onRequestUpdate:i,resolveArtifactDownload:a,connectionEpoch:o}=t,s=Dg(e.url,t);if(s.status!==`available`)return{status:s.status,reason:s.status===`unavailable`?s.reason:void 0,error:s.status===`unavailable`&&s.unconfirmed,onAllow:s.status===`unavailable`&&s.canAllow?()=>kg(e.url,t,!0):void 0,onRetry:s.status===`unavailable`&&s.recoverable?()=>kg(e.url,t):void 0};let c=w_(e,a,i,o);if(c.status!==`available`)return{status:c.status,reason:c.status===`unavailable`?c.reason:void 0,error:c.status===`unavailable`&&c.error,onRetry:c.status===`unavailable`&&e.artifactId&&a?()=>T_(e,i,o):void 0};let l=Zh(e.url),u=l?$h(e.url,n,s.mediaTicket,t,e.label):zg(e.url)?tg(c.url,n):c.url;return u?{status:`available`,source:{src:u,playback:s.playback??e.playback??`native`,authToken:l?r??null:null,sizeBytes:s.sizeBytes??e.sizeBytes,durationMs:s.durationMs??e.durationMs,width:s.width??e.width,height:s.height??e.height}}:{status:`checking`,reason:void 0,onRetry:void 0}}function D_(e){return e.some(e=>e.attachment.kind===`document`&&!g_(e)&&!e_(e))}function O_(e,t,n,r,i=!0){if(e.length===0)return G;let a=i?[]:e.filter(g_),o=e.filter(e=>i||!g_(e)),s=a.map(e=>{let i=E_(e.attachment,t);return{identity:e.attachment.url,...i.status===`available`?{src:/^data:text\/plain;base64,[a-z0-9+/]*={0,2}$/i.test(i.source.src)||xh(i.source.src)&&!bh(i.source.src)?i.source.src:void 0,sizeBytes:i.source.sizeBytes}:{pending:i.status===`checking`},fallback:k_(e,t,n,r,`card`)}}),c=!i&&(a.length>0||o.some(e_));return H`<div
    class="chat-assistant-attachments ${c?`chat-assistant-attachments--preview-chips`:``}"
  >
    ${a.length?H`<openclaw-chat-sent-comments
            .sources=${s}
            .scope=${JSON.stringify([t.sessionKey,t.agentId,t.connectionEpoch,t.resourceBasePath,t.authToken,t.policyKey])}
          ></openclaw-chat-sent-comments>`:G}
    ${o.map(e=>k_(e,t,n,r,i||e.type===`attachment`&&e.attachment.kind===`audio`&&e.attachment.isVoiceNote?`inline`:`card`))}
  </div>`}function k_(e,t,n,r,i=`inline`){let a=a=>A_(e,t,n,r,i,a);return e.type!==`attachment`||!r_(e,i)?a():H`${a_({attachment:e.attachment,options:t,render:a})}`}function A_(e,t,n,r,i=`inline`,a){let{onRequestOpenImage:o,onOpenImage:s,resolveArtifactDownload:c}=t;if(e.type===`attachment_error`){let{attachment:t}=e;return dh({label:t.label,mimeType:t.mimeType,badge:L(`chat.attachments.notSent`),reason:lh(t.code)})}let{attachment:l}=e,u=i===`card`&&e_(e),d=Up(l)===`svg`,f=a?.observeCard?void 0:E_(l,t);if(!u&&(f?.status===`unavailable`||f?.status===`checking`&&!a))return dh({label:l.label,mimeType:l.mimeType,badge:f.status===`unavailable`?L(`chat.attachments.unavailable`):``,reason:f.status===`unavailable`?f.reason:void 0,onRetry:f.onRetry,onAllow:d?f.onAllow:void 0,path:Zh(l.url)?l.url:void 0});let p=f?.status===`available`?f.source:void 0,m=p?.src??``,h=l.kind===`audio`||l.kind===`video`?Sh(m,l.kind):u?Ch(m):xh(m),g=l.kind===`video`&&s&&h?n=>{let r=o?.(),i=e=>y_(e,n=>E_(e,{...t,onRequestUpdate:n}),t.onRequestUpdate),a=t.galleryVideos?.(e),c={...i(l),src:n,originalSrc:h,...a&&a.index>=0&&a.items.length>1?{gallery:{index:a.index,items:a.items.map(({attachment:e})=>async()=>i(e))}}:{}};s(c,r)}:void 0,_=Zh(l.url)||zg(l.url)&&!!(l.artifactId&&c),v=n&&(_||h||u)?()=>n({kind:`attachment`,attachmentKind:l.kind,title:l.label,..._?{}:{src:h},mimeType:l.mimeType,...u?{plainText:!0}:{},sourceIdentity:l.url,playback:p?.playback,authToken:p?.authToken,sizeBytes:p?.sizeBytes,durationMs:p?.durationMs,width:p?.width,height:p?.height,voiceNote:l.isVoiceNote===!0,..._?{resolveSource:(e,t)=>{let n=E_(l,{...t,onRequestUpdate:e});return n.status===`available`?{status:`ready`,...n.source}:n.status===`checking`?{status:`pending`}:n.error?{status:`error`,reason:n.reason??L(`chat.attachments.unavailable`),onRetry:n.onRetry}:{status:`unavailable`,onRetry:n.onRetry}}}:{}}):void 0;if(u)return H`<openclaw-chat-pasted-text
      .src=${h&&!bh(h)?h:void 0}
      .sizeBytes=${p?.sizeBytes??l.sizeBytes}
      .scope=${JSON.stringify([l.url,t.sessionKey,t.agentId,t.connectionEpoch,t.resourceBasePath,t.authToken,t.policyKey])}
      .onOpen=${v}
    ></openclaw-chat-pasted-text>`;let y=ph({kind:l.kind,label:l.label,mimeType:l.mimeType,sizeBytes:p?.sizeBytes??l.sizeBytes,downloadHref:h,downloadPending:!(!a||p),downloadPendingFocusable:!!a,onExpand:v,voiceNote:l.isVoiceNote===!0},a?.observeCard,a?.onFocus);if(a&&!p)return y;if(d){let e=l.label.trim()||L(`chat.imageLightbox.untitled`);return H`<openclaw-chat-svg-attachment
      .src=${m}
      .sourceIdentity=${l.url}
      .label=${e}
      .mimeType=${l.mimeType??`image/svg+xml`}
      .sizeBytes=${p?.sizeBytes}
      .downloadHref=${xh(m)}
      .onOpen=${(t,n)=>s_(s,t,e,n,o?.())}
      .onExpand=${v}
      .onMediaLoaded=${r}
    ></openclaw-chat-svg-attachment>`}return(l.kind===`audio`||l.kind===`video`)&&!h?dh({label:l.label,mimeType:l.mimeType,badge:L(`chat.attachments.unavailable`),reason:L(`chat.attachments.previewUnavailable`)}):i===`inline`&&l.kind===`audio`?H`<openclaw-chat-audio-player
      .src=${h}
      .sourceIdentity=${l.url}
      .label=${l.label}
      .mimeType=${l.mimeType??``}
      .playback=${p?.playback}
      .authToken=${p?.authToken}
      .sizeBytes=${p?.sizeBytes}
      .serverDurationMs=${p?.durationMs}
      .voiceNote=${l.isVoiceNote===!0}
      .onExpand=${l.isVoiceNote?void 0:v}
      .onMediaLoaded=${r}
    ></openclaw-chat-audio-player>`:i===`inline`&&l.kind===`video`?H`<openclaw-chat-video-player
      .src=${h}
      .sourceIdentity=${l.url}
      .label=${l.label}
      .mimeType=${l.mimeType??``}
      .playback=${p?.playback}
      .authToken=${p?.authToken}
      .sizeBytes=${p?.sizeBytes}
      .mediaWidth=${p?.width}
      .mediaHeight=${p?.height}
      .onExpand=${g}
      .onFallbackExpand=${v}
      .onMediaLoaded=${r}
    ></openclaw-chat-video-player>`:i===`preview`&&l.kind===`video`&&p?.playback===`native`&&h&&v?u_({key:JSON.stringify([t.resourceBasePath??``,t.authToken?.trim()??``,t.sessionKey,t.agentId,t.policyKey,t.connectionEpoch??0,l.url,l.artifactId,h,400,225]),src:h,label:l.label,onOpen:v,fallback:y}):y}function j_(){return(j_=e((()=>{K(),R(),yh(),bg(),wg(),Eg(),Eh(),o_(),Ug(),fh(),c_(),ng(),Qp(),d_(),n_(),v_(),b_()})))()}function M_(e){let t=Dt(e);if(!t)return G;let n=t.snapshot;return H`
    <details class="chat-context-attachment">
      <summary class="chat-context-attachment__summary">
        <span aria-hidden="true">${z.layers}</span>
        ${L(`chat.messages.attachedContext.label`)}
        <span class="chat-context-attachment__chevron" aria-hidden="true"
          >${z.chevronRight}</span
        >
      </summary>
      <div class="chat-context-attachment__body">
        <p>${L(`chat.messages.attachedContext.captured`)}</p>
        <dl>
          ${[`title`,`page`,`agentId`,`workspace`,`file`,`selection`].map(e=>n[e]?H`<dt>${L(`chat.messages.attachedContext.${e}`)}</dt>
                  <dd>${n[e]}</dd>`:G)}
        </dl>
        <details class="chat-context-attachment__technical">
          <summary>${L(`chat.messages.attachedContext.technical`)}</summary>
          <pre>${JSON.stringify(n,null,2)}</pre>
        </details>
        <p>${L(`chat.messages.attachedContext.reference`)}</p>
      </div>
    </details>
  `}function N_(){return(N_=e((()=>{K(),Tt(),B(),R(),$r(),di()})))()}function P_(e,t){let n=t===`image/jpeg`?`jpg`:t.split(`/`,2)[1]||`img`,r=Array.from(e,e=>e.codePointAt(0)<=31||`<>:"/\\|?*`.includes(e)?`-`:e).join(``).replace(/\.[a-z0-9]{1,10}$/iu,``).replace(/[. -]+$/u,``);return`${o(r,120)||`generated-image`}.${/^[a-z0-9.+-]{1,12}$/u.test(n)?n:`img`}`}function F_(e,t){let n=URL.createObjectURL(e),r=document.createElement(`a`);r.href=n,r.download=t,r.click(),globalThis.setTimeout(()=>URL.revokeObjectURL(n),3e4)}async function I_(e){if(e.type===`image/png`)return e;let t=await createImageBitmap(e);try{let e=document.createElement(`canvas`);e.width=t.width,e.height=t.height;let n=e.getContext(`2d`);if(!n)throw Error(`image conversion context is unavailable`);return n.drawImage(t,0,0),await new Promise((t,n)=>{e.toBlob(e=>e?t(e):n(Error(`image conversion failed`)),`image/png`)})}finally{t.close()}}function L_(e,t){return H`
    <span class="chat-image-actions">
      ${[[`chat.imageLightbox.download`,z.download,async()=>{try{let n=await t();F_(n,P_(e,n.type))}catch{I({message:L(`chat.imageLightbox.downloadFailed`)})}}],[`chat.imageLightbox.copy`,z.copy,async()=>{ze();try{if(!navigator.clipboard?.write||typeof ClipboardItem>`u`)throw Error(`image clipboard is unavailable`);let e=t().then(I_);e.catch(()=>{}),await navigator.clipboard.write([new ClipboardItem({"image/png":e})]),I({message:L(`common.copied`)})}catch{I({message:L(`chat.imageLightbox.copyFailed`)})}}]].map(([e,t,n])=>H`
          <button
            type="button"
            class="chat-image-action"
            title=${L(e)}
            aria-label=${L(e)}
            @click=${()=>void n()}
          >
            ${t}
          </button>
        `)}
    </span>
  `}function R_(){return(R_=e((()=>{K(),B(),R(),xt(),Oe()})))()}function z_(e,t,n,r=`thumbnail`){let i=e?H_(e,r,t?.resourceBasePath):void 0,a=t?.authToken?.trim()??``,o=n?.trim()??``;return{cacheKey:JSON.stringify([t?.connectionEpoch,t?.resourceBasePath,t?.sessionKey,t?.agentId,t?.policyKey,a,i,o]),subscriberScope:`${i}::${o}`}}function B_(e,t,n){return Lp(z_(e,t,n).cacheKey)}function V_(e,t,n,r=`thumbnail`,i=!1){let{cacheKey:a,subscriberScope:o}=z_(e,t,n,r),s=Dp(`managed-image`,a,t?.onRequestUpdate,o);s.subscribers.size>0&&!s.releaseAuthRecovery&&(s.releaseAuthRecovery=Nn(()=>{kp(s)&&s.value===null&&(s.value=void 0,s.retryAttempted=!1,s.unavailableAt=void 0,Mp(s),jp(s))}));let c=Lp(a);if(c)return s.value=c,s.retryAttempted=!1,s.unavailableAt=void 0,s;if(s.value===null){if(!i&&(s.retryAttempted||s.unavailableAt===void 0||Date.now()-s.unavailableAt<q_))return s;Mp(s),s.retryAttempted=!0}if(s.value=void 0,!s.pending){let i=new AbortController;s.abortController=i;let o=(async()=>{let o=await U_(e,t,n,r,i);if(!o)return G_(s);if(!kp(s))return null;let c=Vp(a,o);return s.value=c,s.retryAttempted=!1,s.unavailableAt=void 0,c})().finally(()=>{s.abortController===i&&(s.abortController=void 0),s.pending===o&&(s.pending=void 0),s.value===null&&s.subscribers.size===0&&!s.pending&&Ip(),jp(s)});s.pending=o}return s}function H_(e,t,n){try{let r=new URL(e,window.location.origin);if(r.pathname=r.pathname.replace(/\/(?:full|thumbnail)$/u,`/${t}`),t===`thumbnail`&&r.searchParams.set(`v`,`2`),/^https?:\/\//iu.test(e))return r.href;let i=v(n??``);return`${i&&(r.pathname===i||r.pathname.startsWith(`${i}/`))?r.pathname:`${i}${r.pathname}`}${r.search}${r.hash}`}catch{return e.replace(/\/(?:full|thumbnail)(?=$|[?#])/u,`/${t}`)}}async function U_(e,t,n,r,i){let a=e?Bg(e):t?.sessionKey,o=a&&n&&t?.resolveArtifactDownload?await t.resolveArtifactDownload({sessionKey:a,artifactId:n},i.signal).catch(()=>null):null;if(i.signal.aborted)return null;if(o?.blob)return o.blob.type.startsWith(`image/`)?o.blob:null;let s=o?.url??e;if(!s||!e&&!s.startsWith(`data:image/`))return null;let c=zg(s)?H_(s,r,t?.resourceBasePath):s,l=new Headers({Accept:`image/*`}),u=t?.authToken?.trim();!o&&u&&l.set(`Authorization`,`Bearer ${u}`),!o&&a&&l.set(`x-openclaw-requester-session-key`,a);let d=globalThis.setTimeout(()=>{i.abort(new DOMException(`managed outgoing image fetch timed out`,`TimeoutError`))},K_);try{let e=await jt(c,{method:`GET`,headers:l,credentials:`same-origin`,signal:i.signal});if(!e.ok)return null;let t=await e.blob();return t.type.startsWith(`image/`)?t:null}catch{return null}finally{globalThis.clearTimeout(d)}}async function W_(e,t,n){let r=V_(e,t,n,`full`,!0);r.pending&&await r.pending;let i=Rp(r.cacheKey);if(!i||!kp(r))throw Error(`managed image is unavailable`);return i}function G_(e){return kp(e)?(e.value=null,e.unavailableAt=Date.now(),e.retryAttempted||Np(e,Date.now()+q_,()=>{e.value===null&&(e.retryAttempted=!0,e.value=void 0,e.unavailableAt=void 0,jp(e))}),null):null}var K_,q_;function J_(){return(J_=e((()=>{un(),pn(),Ug(),Qp(),K_=3e4,q_=5e3})))()}function Y_(e){return e?.startsWith(`data:image/`)===!0||e?.startsWith(`blob:`)===!0}function X_(e){return e.alt?.trim()||e.fileName?.trim()||L(`chat.imageLightbox.untitled`)}function Z_(e,t,n){let r=X_(e),i=n?.onRequestOpenImage?.(),a=n?.galleryImages,o=a?.indexOf(e)??-1,s=n?.onOpenImage,c=t=>{let r={...t,width:e.width,height:e.height},c=a&&a.length>1&&o>=0?{...r,gallery:{index:o,items:a.map(e=>(t=!1)=>Q_(e,n,t))}}:r;i===void 0?s?.(c):s?.(c,i)};if(e.url!==void 0&&!zg(e.url)){s_(s?c:void 0,t,r);return}if(s){c({src:t,title:r,release:Bp(V_(e.url,n,e.artifactId).cacheKey),loadFullResolution:()=>Q_(e,n,!0)});return}let l=V_(e.url,n,e.artifactId,`full`,!0);if(l.value){s_(void 0,l.value,r);return}let u=ht(),d=()=>{u?.close(),I({message:L(`chat.imageLightbox.loadFailed`)})};(l.pending??Promise.resolve(null)).then(e=>{let t=e?Be(e,window.location.href,{allowDataImage:!0}):null;t?u?u.location.replace(t):s_(void 0,t,r):d()}).catch(d)}async function Q_(e,t,n){let r,i;if(e.url===void 0||zg(e.url)){let a=V_(e.url,t,e.artifactId,`full`,n);if(r=a.value??await a.pending??null,!r||!kp(a))return null;i=Bp(a.cacheKey)}else{let n=await Og(e.url,t);if(n?.status!==`available`)return null;r=$h(e.url,t?.resourceBasePath,n.mediaTicket,t,e.fileName)}let a=Be(r,window.location.href,{allowDataImage:!0});return a?{src:a,title:X_(e),width:e.width,height:e.height,release:i}:(i?.(),null)}var $_,ev,tv,nv,rv,iv;function av(){return(av=e((()=>{K(),$n(),Hn(),sr(),W(),ur(),R(),Pe(),Oe(),Ah(),R_(),Ug(),fh(),J_(),c_(),ng(),Qp(),$_=3e4,ev=160,tv=class extends Wn{constructor(...e){super(...e),this.managed=!1,this.presentationKey=Symbol(`image-presentation`),this.admitted=!1,this.observeFrame=e=>{if(this.stopObserving?.(),this.stopObserving=void 0,!e||!this.isConnected||this.admitted||Y_(this.image?.url))return;let t=this.presentationKey;this.stopObserving=Dh(e,()=>{t===this.presentationKey&&this.admit()})},this.admit=()=>{this.isConnected&&!this.admitted&&(this.admitted=!0,this.stopObserving?.(),this.stopObserving=void 0,this.refreshImage())},this.refreshImage=()=>{this.isConnected&&this.image&&this.setValue(this.render(this.image,this.options))},this.onSettled=e=>{let t=e.currentTarget;this.isConnected&&t===this.previewElement&&t instanceof HTMLImageElement&&t.isConnected&&(this.element=e.type===`load`?t:void 0,this.retained?.status===`retaining`&&this.element?.getAttribute(`src`)!==this.retained.previewUrl&&(e.type===`error`?this.failRetainedImage():this.releaseRetainedImage()))}}render(e,t){let n=this.image;if(n?.url!==e.url||n?.artifactId!==e.artifactId){this.managed=e.url===void 0||zg(e.url),this.pendingPreview=void 0,this.releaseRetainedImage(),this.retained=e.factIndex!==void 0&&n&&Y_(n.url)&&n.artifactId===e.artifactId&&e.url!==void 0&&Qh(e.url)&&this.element?.getAttribute(`src`)===n.url&&this.element.naturalWidth>0?{status:`retaining`,previewUrl:n.url}:void 0;let r=t?.localSubmission&&n&&Y_(n.url)&&Y_(e.url);!this.retained&&!r&&(this.element=void 0,this.previewElement=void 0,this.admitted=!1,this.presentationKey=Symbol(`image-presentation`)),Fp(this.refreshImage)}if(this.image=e,this.options=t,!this.isConnected)return this.releaseRetainedImage(),Fp(this.refreshImage),Gn;if(this.admitted||(this.managed?this.admitted=!!B_(e.url,t,e.artifactId):e.url&&!this.element&&(this.element=Pg(e.url,t),this.previewElement=this.element,this.admitted=!!this.element)),!this.admitted&&!Y_(e.url)&&!this.retained&&typeof IntersectionObserver==`function`)return this.present(this.renderImagePlaceholder(e));this.admitted=!0;let r=t?.onRequestUpdate;r?(this.pendingPreview=void 0,Pp(r,this.refreshImage)):Fp(this.refreshImage);let i=r?{...t,onRequestUpdate:this.refreshImage}:t,a=e.url;if(a===void 0)return this.renderManagedImage(e,t,i);let o=Dg(a,i),s=this.retained?.status===`unavailable`,c=o.status===`checking`||o.status===`unavailable`&&o.unconfirmed,l=o.status===`available`?$h(a,t?.resourceBasePath,o.mediaTicket,t,e.fileName):c?this.element?.getAttribute(`src`):void 0;if(!l||s){this.element=void 0,this.previewElement=void 0,s||this.releaseRetainedImage();let t=o.status===`unavailable`?o.reason:s?L(`chat.imageLightbox.loadFailed`):void 0;return t===void 0?this.present(this.renderImagePlaceholder(e)):this.present(this.renderImageFrame(e,dh({label:e.fileName??e.alt??L(`chat.imageLightbox.untitled`),badge:L(`chat.attachments.unavailable`),reason:t,path:Zh(a)?a:void 0,onAllow:!s&&o.status===`unavailable`&&o.canAllow?()=>kg(a,i,!0):void 0,onRetry:!s&&o.status===`unavailable`&&o.recoverable?()=>kg(a,i):void 0}),`unavailable`))}if(!this.managed){let n=this.retained;return o.status===`available`&&n?.status===`retaining`&&n.timeout===void 0&&(n.timeout=setTimeout(()=>this.failRetainedImage(),$_)),this.present(this.renderImageElement(e,l,t))}return this.renderManagedImage(e,t,i,l)}renderManagedImage(e,t,n,r=e.url){let i=V_(r,n,e.artifactId),a=i.pending;return!t?.onRequestUpdate&&a&&this.pendingPreview!==a&&(this.pendingPreview=a,a.then(e=>{this.pendingPreview===a&&this.isConnected&&this.image&&(this.pendingPreview=void 0,this.setValue(this.present(e?this.renderImageElement(this.image,e,this.options):this.renderImagePlaceholder(this.image,L(`chat.imageLightbox.loadFailed`)))))})),this.present(i.value?this.renderImageElement(e,i.value,t):this.renderImagePlaceholder(e,i.value===null?L(`chat.imageLightbox.loadFailed`):void 0))}renderImageElement(e,t,n){let r=X_(e);return this.renderImageFrame(e,H`
        <button
          type="button"
          class="chat-message-image-button"
          aria-label=${L(`chat.imageLightbox.open`,{title:r})}
          aria-disabled=${t?G:`true`}
          @focus=${this.admit}
          @click=${r=>{r.stopPropagation(),t?Z_(e,t,n):this.admit()}}
        >
          ${t?this.renderPreviewElement(e,t,r):H`<span class="chat-image-skeleton skeleton" aria-hidden="true"></span>`}
        </button>
        ${this.managed&&t?L_(r,()=>W_(e.url,n,e.artifactId)):G}
      `,t?void 0:`loading`)}renderPreviewElement(e,t,n){let r=this.previewElement??=document.createElement(`img`);r.addEventListener(`load`,this.onSettled),r.addEventListener(`error`,this.onSettled),r.alt=n,r.className=`chat-message-image`,r.referrerPolicy=`no-referrer`;for(let t of[`width`,`height`])e[t]===void 0?r.removeAttribute(t):r.setAttribute(t,String(e[t]));return r.getAttribute(`src`)!==t&&r.setAttribute(`src`,t),r}renderImageFrame(e,t,n){let r=Number.isFinite(e.width)&&e.width>0&&Number.isFinite(e.height)&&e.height>0,i=n===`loading`,a=n===`unavailable`,o=r?e.width/e.height:3/2,s=r?e.width<ev?ev:Math.min(e.width,400,360*o):400,c=a?Math.max(ev,s):s,l=Math.min(360,c/o);return H`<span
      ${U(this.observeFrame)}
      class="chat-image-frame ${r||i||a?`chat-image-frame--image`:``} ${this.managed&&!a?`chat-image-frame--managed`:``} ${a?`chat-image-frame--compact`:``}"
      style=${`--chat-image-width: ${c}px; --chat-image-min-width: ${ev}px; --chat-image-ratio: ${a?`auto`:`${c} / ${l}`}`}
      aria-busy=${i?`true`:`false`}
      role=${i?`status`:G}
      aria-label=${i?L(`common.loading`):G}
      >${t}</span
    >`}renderImagePlaceholder(e,t){return t===void 0?this.renderImageElement(e,void 0,this.options):this.renderImageFrame(e,dh({label:e.fileName??e.alt??L(`chat.imageLightbox.untitled`),badge:L(`chat.attachments.unavailable`),reason:t,onRetry:this.managed?()=>{V_(e.url,this.options?.onRequestUpdate?{...this.options,onRequestUpdate:this.refreshImage}:this.options,e.artifactId,`thumbnail`,!0),this.refreshImage()}:void 0}),`unavailable`)}releaseRetainedImage(){let e=this.retained;this.retained=void 0,e?.status===`retaining`&&clearTimeout(e.timeout)}failRetainedImage(){this.releaseRetainedImage(),this.retained={status:`unavailable`},this.refreshImage()}present(e){return H`${Y(this.presentationKey,e)}`}disconnected(){this.previewElement&&(this.previewElement.removeEventListener(`load`,this.onSettled),this.previewElement.removeEventListener(`error`,this.onSettled),this.previewElement.remove()),this.element&&this.image?.url&&Fg(this.image.url,this.element,this.options,this.image.fileName),this.previewElement=void 0,this.stopObserving?.(),this.stopObserving=void 0,this.admitted=!1,this.releaseRetainedImage(),this.element=void 0,this.pendingPreview=void 0,this.presentationKey=Symbol(`image-presentation`),Fp(this.refreshImage)}reconnected(){this.refreshImage()}},nv=Kn(tv),rv=class extends gr{constructor(...e){super(...e),this.slots=[],this.scope=``,this.localSubmission=!1}render(e,t,n=[]){let r=JSON.stringify([t?.connectionEpoch,t?.authToken?.trim(),t?.resourceBasePath,t?.sessionKey,t?.agentId]),i=this.scope===r&&(!this.localSubmission||t?.localSubmission!==!1)&&(this.canonicalMessageKey===t?.canonicalMessageKey||this.localSubmission&&!this.canonicalMessageKey),a=i?this.localSubmission:t?.localSubmission===!0,o=i&&a&&e.length===this.slots.length&&this.slots.every(({image:e})=>Y_(e.url))&&e.every(e=>e.factIndex!==void 0)?e.toSorted((e,t)=>(e.factIndex??0)-(t.factIndex??0)):this.slots.map(({image:e})=>e),s=new Map(o.map((e,t)=>[e.factIndex,this.slots[t]?.key]));this.slots=e.map((e,n)=>{let r=this.slots[n],a=e.factIndex===void 0?r?.image.factIndex===void 0?r?.key:void 0:s.get(e.factIndex),o=this.policyKey===t?.policyKey||Y_(e.url)||e.url!==void 0&&Qh(e.url);return{image:e,key:i&&o&&a||Symbol(`image-slot`)}}),this.scope=r,this.policyKey=t?.policyKey,this.canonicalMessageKey=t?.canonicalMessageKey,this.localSubmission=a&&!(t?.canonicalMessageKey&&e.every(e=>e.factIndex!==void 0));let c=e.length+n.length;if(!c)return G;let l=[`chat-message-images`,c===1?`chat-message-images--single`:`chat-message-images--gallery`,c===2||c===4?`chat-message-images--two-column`:``,c===5?`chat-message-images--five`:``].filter(Boolean).join(` `);return H`<div class=${l}>
      ${q(this.slots,({key:e})=>e,({image:n})=>H`${nv(n,{...t,galleryImages:t?.galleryImages??e})}`)}
      ${n}
    </div>`}},iv=Kn(rv)})))()}function ov(e){let t=_i(e),n=Jo(e,t),r=m(e),i=m(r?.__openclaw),a;return r?.role===`user`&&i?.humanMentions&&(typeof r.content==`string`?r.content:Array.isArray(r.content)?r.content.flatMap(e=>{let t=m(e);return t?.type===`text`&&typeof t.text==`string`?[t.text]:[]}).join(`
`):null)===n&&(a=Wr(n,i.humanMentions)),{message:e,normalizedMessage:t,displayMarkdown:n,humanMentions:a}}function sv(e,t=_i(e),n=Jo(e,t)){return n||Kp(e,t.content)}function cv({message:e,normalizedMessage:t,displayMarkdown:n},r){let{messageId:i,canFetchFullMessage:a,onReply:s,senderLabel:c}=r,l=Fi(t.role),u=Iu(e)?.startsWith(xr)===!0,d=a?Wu(e,l):void 0,f=d?{messageId:d,state:r.getAssistantMessageExpansion?.(d)}:void 0,p=f?.state,m=p?.status===`loaded`?p.markdown:n,h=l===`assistant`?Co(m):m,g=l===`assistant`||l===`user`||u?h:void 0,_=sv(e,t,h),v=s&&!u?o(_,500):``;if(!_&&!g&&!v&&!f)return null;let y=td(e);return{copyMarkdown:_,...g===void 0?{}:{markdown:g},fullMessage:f,...v?{replyTarget:{messageId:i,text:v,senderLabel:c,...y?{sourceMessageId:y}:{}}}:{}}}function lv(e,t){return H`
    ${e.replyTarget&&t.onReply?uv(e.replyTarget,t.onReply):G}
    ${e.markdown?Ac(e.markdown):G}
  `}function uv(e,t){return H`
    <openclaw-tooltip .content=${L(`chat.messages.reply`)}>
      <button
        class="chat-reply-btn"
        type="button"
        aria-label=${L(`chat.messages.replyToMessage`)}
        @click=${()=>t(e)}
      >
        ${z.messageSquare}
      </button>
    </openclaw-tooltip>
  `}function dv(){return(dv=e((()=>{K(),Er(),ic(),B(),R(),$r(),qr(),lo(),Zr(),va(),Nu(),rd(),Qp(),di()})))()}function fv(e,t){let n=e.flatMap(e=>e.type===`text`?[e.text]:[]).join(`
`),r=`OPENCLAWMEDIASLOT`;for(;n.includes(r);)r+=`X`;let i=[];return{markdown:e.map(e=>e.type===`text`?e.text:(i.push(e),`${r}${i.length-1}END`)).join(`
`),media:{prefix:r,text:n,items:i,render:t}}}function pv(e){return Array.from(e.childNodes).some(e=>e.nodeType===Node.TEXT_NODE?e.textContent?.trim():e.nodeName!==`BR`)}function mv(e,t){let n=Array.from(e.childNodes,e=>({node:e,key:e instanceof Element?e.getAttribute(`data-markdown-key`):null})),r=new Map;for(let{key:e}of n)e&&r.set(e,(r.get(e)??0)+1);return q(n,({key:e},t)=>e&&r.get(e)===1?e:t,({node:e})=>yv(e,t))}var hv,gv,_v,vv,yv,bv,xv;function Sv(){return(Sv=e((()=>{K(),Zn(),Hn(),ur(),dr(),mr(),hv=class extends gr{constructor(...e){super(...e),this.previous=new Map}render(e){return Gn}update(e,[t]){let n=new Map(Array.from(t.attributes,e=>[e.name,e.value]));for(let t of new Set([...this.previous.keys(),...n.keys()])){let r=this.previous.get(t),i=n.get(t);if(r!==i){if(t===`class`){let t=new Set(r?.split(/\s+/).filter(Boolean)),n=new Set(i?.split(/\s+/).filter(Boolean));for(let r of t)n.has(r)||e.element.classList.remove(r);for(let r of n)t.has(r)||e.element.classList.add(r)}else i===void 0?e.element.removeAttribute(t):e.element.setAttribute(t,i)}}return this.previous=n,Gn}},gv=Kn(hv),_v=new Set([`br`,`hr`,`img`,`input`]),vv=class extends gr{update(e,[t,n]){let r=this.render(t,n);if(typeof r==`string`&&typeof Yn(e)==`string`){let t=e.startNode?.nextSibling;(!(t instanceof Text)||t.nextSibling!==e.endNode)&&cr(e)}return r}render(e,t){let n=t.slots.get(e);if(n!==void 0){this.previous=void 0;let e=t.media?.items[n];return e?t.media?.render(e,n):G}let r=`${e.nodeType}:${e instanceof Element?e.outerHTML:e.textContent}`,i=this.previous===r;if(this.previous=r,i&&!t.mediaAncestors.has(e))return Gn;if(e.nodeType===Node.TEXT_NODE)return e.textContent;if(!(e instanceof Element))return G;if(!t.incremental&&!t.mediaAncestors.has(e)||e.classList.contains(`markdown-mermaid`)||e.localName.includes(`-`))return lr(e.outerHTML);let a=hr(e.localName);return _v.has(e.localName)?qn`<${a} ${gv(e)}>`:qn`<${a} ${gv(e)}>${mv(e,t)}</${a}>`}},yv=Kn(vv),bv=class extends gr{constructor(...e){super(...e),this.source=``,this.prefix=``,this.slots=new Map,this.mediaAncestors=new Set}render(e,t,n=!1){if(!n&&!t)return lr(e);let r=t?.prefix??``;if(this.source!==e||this.prefix!==r||!this.template){this.source=e,this.prefix=r;let t=document.createElement(`template`);t.innerHTML=e,this.template=t,this.slots.clear(),this.mediaAncestors.clear();let n=RegExp(`${r}(\\d+)END`,`g`),i=document.createTreeWalker(t.content,NodeFilter.SHOW_TEXT),a=[],o=[];for(let e=i.nextNode();e;e=i.nextNode())r&&e instanceof Text&&e.data.includes(r)&&a.push(e);for(let e of a){let t=document.createDocumentFragment(),r=0;for(let i of e.data.matchAll(n)){t.append(e.data.slice(r,i.index));let n=document.createComment(i[0]);o.push(n),this.slots.set(n,Number(i[1])),t.append(n),r=i.index+i[0].length}t.append(e.data.slice(r)),e.replaceWith(t)}for(let e of o){let t=e.parentElement?.closest(`p`);if(!t)continue;let n=t.cloneNode(!1),r=document.createRange();r.setStart(t,0),r.setEndBefore(e),n.appendChild(r.extractContents()),pv(n)&&t.before(n),t.before(e),pv(t)||t.remove()}for(let e of o)for(let t=e.parentNode;t;t=t.parentNode)this.mediaAncestors.add(t)}let i={media:t,slots:this.slots,mediaAncestors:this.mediaAncestors,incremental:n};return mv(this.template.content,i)}},xv=Kn(bv)})))()}function Cv(e,t){let n=e.filter(e=>e.width>0&&e.bottom>e.top).toSorted((e,t)=>e.top-t.top),r,i=[];for(let e of n)if(!r||e.top>=Math.min(r.bottom,r.top+r.lineHeight)-wv){if(i.length>t)break;r={...e},i.push(r)}else r.bottom=Math.max(r.bottom,e.bottom),r.glyphTop=Math.min(r.glyphTop,e.glyphTop),r.lineHeight=Math.max(r.lineHeight,e.lineHeight);if(!(i.length<t))for(let e=t-1;e>=0;e--){let t=i[e],n=i[e+1],r=Math.min(t.top+t.lineHeight*Tv,n?.glyphTop??1/0);if(r>=t.top+t.lineHeight*Ev)return{...t,clamp:r}}}var wv,Tv,Ev;function Dv(){return(Dv=e((()=>{wv=.5,Tv=.74,Ev=.66})))()}function Ov(e,t,n,r){let i=[ul(e,r)],a=H`<div class="chat-text">${lr(i[0])}</div>`;return Nv(e.text,t,n,a,i)}function kv(e){return e.length>Lv||e.split(`
`,41).length>Rv}function Av(e){Hv.add(e),!Uv&&(Uv=!0,queueMicrotask(()=>{Uv=!1;let e=[...Hv];Hv.clear();for(let t of e)t.element.style.removeProperty(`--chat-disclosure-clamp`);let t=e.map(e=>e.read());for(let e of t)e?.()}))}function jv(e,t){let n=null,r,i,a=0;return o=>{let s=++a;if(i&&=(Hv.delete(i),void 0),n?.disconnect(),n=null,r&&=(document.fonts?.removeEventListener(`loadingdone`,r),void 0),!(o instanceof HTMLElement))return;let c=i={element:o,read:()=>{if(a!==s)return;let n=o.parentElement,r=n?.querySelector(`:scope > .chat-message-disclosure__toggle`);if(!n||!r)return;let i,c,l=o.querySelector(`:scope > .chat-text`),u=o.scrollHeight,d=u>o.clientHeight+1;if(!t&&!e&&d&&l&&o.clientWidth>0){let e=o.getBoundingClientRect().top-o.scrollTop,t=Number.parseFloat(getComputedStyle(l).lineHeight),n=document.createTreeWalker(l,NodeFilter.SHOW_TEXT),r=document.createRange(),a=[];for(let i=n.nextNode();i;i=n.nextNode()){if(!i.textContent?.trim()||!i.parentElement?.checkVisibility()||i.parentElement.matches(`details:not([open])`))continue;let n=Number.parseFloat(getComputedStyle(i.parentElement).lineHeight)||t;r.selectNodeContents(i);for(let t of r.getClientRects()){let r=Math.floor((n-t.height)/2);a.push({top:t.top-e-r,glyphTop:t.top-e,bottom:t.bottom-e-r,width:t.width,lineHeight:n})}}for(let n of l.querySelectorAll(`details:not(:has(> summary))`)){if(!n.checkVisibility())continue;let r=getComputedStyle(n),i=Number.parseFloat(r.lineHeight)||t,o=n.getBoundingClientRect(),s=o.top-e+Number.parseFloat(r.borderTopWidth)+Number.parseFloat(r.paddingTop);a.push({top:s,glyphTop:s,bottom:s+i,width:o.width,lineHeight:i})}let s=Cv(a,zv);s&&(i=`${s.clamp}px`,c=`${s.clamp-s.top-s.lineHeight*Bv}px`)}let f=!e&&(t&&l?u<=Number.parseFloat(getComputedStyle(l).lineHeight)*Vv+1:!d);return()=>{if(a===s){for(let[e,t]of[[`--chat-disclosure-clamp`,i],[`--chat-disclosure-fade-size`,c]])t===void 0?o.style.removeProperty(e):o.style.getPropertyValue(e)!==t&&o.style.setProperty(e,t);r.hidden=f}}}},l=()=>{a===s&&Av(c)};queueMicrotask(()=>{if(a!==s)return;let e=o.querySelector(`:scope > .chat-text`);e&&n?.observe(e)}),l(),r=l,document.fonts?.addEventListener(`loadingdone`,r),typeof ResizeObserver==`function`&&(n=new ResizeObserver(l),n.observe(o))}}function Mv(e,t,n,r,i,a){let o=n.assistantMessageDisclosure,s=n.role===`assistant`,c=s||n.role===`user`&&o?.onRetryFullMessage,l=c&&o?.expanded,{content:u,parts:d}=Pv(l?o.markdown??e:e,t,n.isStreaming,l?{...r,mode:`document`}:r,i,s&&n.isStreaming?t:void 0,a);return c&&o?.onRetryFullMessage?H`
      ${u}
      <div class="chat-message-load-error">
        ${L(`chat.messages.fullContentLoadExhausted`)}
        <button
          type="button"
          class="chat-message-load-error__retry"
          @click=${o.onRetryFullMessage}
        >
          ${L(`common.retry`)}
        </button>
      </div>
    `:Nv(e,t,n,u,d)}function Nv(e,t,n,r,i){if(!n.onToggleUserMessageExpanded||(n.isForwarded?n.isStreaming:n.role!==`user`||!kv(e)))return r;let a=`${n.isForwarded?`forwarded`:`user`}-message:${t}`,o=n.isUserMessageExpanded?.(a)??!1;return H`
    <div
      class="chat-message-disclosure ${n.isForwarded?`chat-message-disclosure--forwarded`:``} ${o?`is-expanded`:``}"
    >
      <div
        class="chat-message-disclosure__content"
        ${Qn([...i,o,n.isForwarded],()=>U(jv(o,!!n.isForwarded)))}
      >
        ${r}
      </div>
      <button
        class="chat-message-disclosure__toggle"
        type="button"
        aria-expanded=${String(o)}
        @click=${()=>n.onToggleUserMessageExpanded?.(a)}
      >
        ${L(o?`chat.messages.showLess`:`chat.messages.showMore`)}
        ${o?z.chevronUp:z.chevronDown}
      </button>
    </div>
  `}function Pv(e,t,n,r,i,a,o){let s=n?kl(e,r,a):[Wc(e,r),``];if(i){let e=+!!s[1].trim();s[e]=Fv(s[e],i)}let c=Gv(t,e,s,o);return{parts:s,content:H`
      <div class="chat-text" dir="${ra(o?.text??e)}">${c}</div>
    `}}function Fv(e,t){let n=document.createElement(`template`);n.innerHTML=e;let r=n.content.lastElementChild,i=r?Iv(r):null,a=document.createElement(`span`);return a.className=`chat-duplicate-count`,a.setAttribute(`aria-label`,t.label),a.textContent=`×${t.count}`,(i??n.content).append(document.createTextNode(`\xA0`),a),n.innerHTML}function Iv(e){if(/^(?:P|H[1-6])$/u.test(e.tagName))return e;if(!/^(?:BLOCKQUOTE|LI|OL|UL)$/u.test(e.tagName))return null;let t=e.lastElementChild;return t?Iv(t):e.textContent?.trim()?e:null}var Lv,Rv,zv,Bv,Vv,Hv,Uv,Wv,Gv;function Kv(){return(Kv=e((()=>{K(),$n(),pr(),sr(),W(),dr(),B(),Il(),R(),$r(),ua(),Dv(),Sv(),di(),Lv=1200,Rv=40,zv=5,Bv=.24,Vv=3,Hv=new Set,Uv=!1,Wv=class extends Wn{constructor(...e){super(...e),this.source=``,this.stableHtml=``,this.fragments=[],this.generation={},this.mediaSlots=new Map,this.mediaRender={}}disconnected(){for(let e of this.mediaSlots.values())e.part?.setConnected(!1)}reconnected(){for(let e of this.mediaSlots.values())e.part?.setConnected(!0)}render(e,t,[n,r],i){if(this.messageKey!==e){for(let e of this.mediaSlots.values())Xn(G,e.element);this.mediaSlots.clear()}if((this.messageKey!==e||!t.startsWith(this.source)||!n.startsWith(this.stableHtml))&&(this.fragments=[],this.tail=void 0,this.stableHtml=``,this.generation={}),n.length>this.stableHtml.length){let e=n.slice(this.stableHtml.length);this.tail?(this.tail.html=e,this.tail=void 0):this.fragments.push({html:e,incremental:!1})}r?this.tail?this.tail.html=r:(this.tail={html:r,incremental:!0},this.fragments.push(this.tail)):this.tail&&=(this.fragments.pop(),void 0),this.messageKey=e,this.source=t,this.stableHtml=n;let a=new Set,o=this.mediaRender={},s=i?{...i,render:(e,t)=>{let n=this.mediaSlots.get(t);return n||(n={element:document.createElement(`div`)},this.mediaSlots.set(t,n)),a.add(t),n.part=Xn(i.render(e,t),n.element),n.part.setConnected(this.isConnected),n.element}}:void 0;return queueMicrotask(()=>{if(this.mediaRender===o)for(let[e,t]of this.mediaSlots)a.has(e)||(Xn(G,t.element),this.mediaSlots.delete(e))}),Y(this.generation,H`${this.fragments.map(e=>Qn([e.html,s],()=>xv(e.html,s,e.incremental)))}`)}},Gv=Kn(Wv)})))()}function qv(e,t,n,r,i){if(!e)return G;let a=e.kind===`id`?e.id:null,s=t?.senderLabel?.trim()?t.senderLabel:e.kind===`current`?L(`chat.messages.currentMessage`):L(`chat.messages.message`),c=t?.text.trim()??``,l=e=>{e&&a&&!t&&r?.(a)},u=H`
    <span class="chat-reply-preview__icon"
      >${i?H`<span class="session-run-spinner" aria-hidden="true"></span>`:z.messageSquare}</span
    >
    <span class="chat-reply-preview__label"> ${L(`chat.messages.replyingTo`,{name:s})} </span>
    ${c?H`<span class="chat-reply-preview__text"
            >${o(c,120)}${c.length>120?`...`:``}</span
          >`:G}
  `;return a&&n?H`
      <button
        ${U(l)}
        type="button"
        class="chat-reply-preview chat-reply-preview--message"
        ?disabled=${i}
        aria-busy=${i?`true`:`false`}
        @click=${()=>n(a)}
      >
        ${u}
      </button>
    `:H`
    <div
      ${U(l)}
      class="chat-reply-preview chat-reply-preview--message chat-reply-preview--unavailable"
    >
      ${u}
    </div>
  `}function Jv(){return(Jv=e((()=>{K(),W(),B(),R()})))()}function Yv(e){let t=[],n=0,r=!0;for(;n<e.length;){let i=e.charAt(n);if(/\s/.test(i)){let r=n;for(;r<e.length&&/\s/.test(e.charAt(r));)r++;t.push({text:e.slice(n,r),cls:`ws`}),n=r;continue}if(i===`'`||i===`"`){let a=n+1;for(;a<e.length&&e.charAt(a)!==i;)a+=e.charAt(a)===`\\`?2:1;a=Math.min(a+1,e.length),t.push({text:e.slice(n,a),cls:`str`}),n=a,r=!1;continue}if(Qv.has(i)){let i=n;for(;i<e.length&&Qv.has(e.charAt(i));)i++;t.push({text:e.slice(n,i),cls:`op`}),n=i,r=!0;continue}let a=n;for(;a<e.length&&!/\s/.test(e.charAt(a))&&!Qv.has(e.charAt(a))&&e.charAt(a)!==`'`&&e.charAt(a)!==`"`;)a++;let o=e.slice(n,a),s=r?`name`:o.startsWith(`-`)?`flag`:/^\d+(?:[.,]\d+)?$/.test(o)?`num`:`plain`;t.push({text:o,cls:s}),n=a,r=!1}return t}function Xv(e){return e.length>Zv?H`${e}`:H`${Yv(e).map(e=>e.cls===`ws`||e.cls===`plain`?H`${e.text}`:H`<span class="chat-cmd--${e.cls}">${e.text}</span>`)}`}var Zv,Qv;function $v(){return($v=e((()=>{K(),Zv=2e3,Qv=new Set([`|`,`;`,`&`,`<`,`>`])})))()}var ey,ty;function ny(){return(ny=e((()=>{$n(),t(),ey=class extends Wn{constructor(...e){super(...e),this.highlighted=new Map,this.renderLine=e=>this.highlighted.get(e)??e.text}render(e,t,n){let{path:r,oldPath:i=r}=t;return this.renderDiff=n,(this.lines!==e||this.path!==r||this.oldPath!==i)&&(this.lines=e,this.path=r,this.oldPath=i,this.highlighted=new Map,ne(async()=>{let{highlightDiffLines:e}=await import(`./chat-diff-highlight.runtime-BtePPJGS.js`);return{highlightDiffLines:e}},__vite__mapDeps([9,10,11,5]),import.meta.url).then(({highlightDiffLines:t})=>t(e,r,i)).then(t=>{this.lines===e&&this.path===r&&this.oldPath===i&&(this.highlighted=t,this.isConnected&&this.setValue(this.renderDiff?.(this.renderLine)))}).catch(()=>{})),n(this.renderLine)}reconnected(){this.setValue(this.renderDiff?.(this.renderLine))}},ty=Kn(ey)})))()}function ry(e){return e.modified===void 0?H`<span class="chat-diffstat">
      <span class="chat-diffstat__add">+${e.added}</span>
      <span class="chat-diffstat__del">-${e.removed}</span>
    </span>`:e.added===0&&e.removed===0&&!e.modified?G:H`<span class="chat-diffstat">
    ${e.added>0?H`<span class="chat-diffstat__add">+${e.added}</span>`:G}
    ${e.removed>0?H`<span class="chat-diffstat__del">-${e.removed}</span>`:G}
    ${e.modified>0?H`<span class="chat-diffstat__mod">~${e.modified}</span>`:G}
  </span>`}function iy(e,t=`succeeded`,n,r={path:``}){let i=e.some(e=>e.lineNo!==void 0);return ty(e,r,r=>H`
      <div
        class="chat-diff code-highlight"
        role="figure"
        aria-label=${L(t===`succeeded`?`chat.toolCards.fileChanges`:`chat.toolCards.attemptedChanges`)}
      >
        ${e.map(e=>{let t=e.kind===`skip`,a=e.kind===`ctx`?``:`chat-diff__row--${e.kind}`,o=e.kind===`add`?`+`:e.kind===`del`?`-`:``;return H`<div class="chat-diff__row ${a}">
            ${i?H`<span class="chat-diff__gutter">${t?``:e.lineNo??``}</span>`:G}
            <span class="chat-diff__sign">${o}</span>
            <span class="chat-diff__text"
              >${t?(n?.(e)??e.text)||`⋯`:r(e)}</span
            >
          </div>`})}
      </div>
    `)}function ay(){return(ay=e((()=>{K(),R(),ny()})))()}function oy(e){let t=e.currentTarget,n=(t?.closest(`.chat-tool-card__raw`))?.querySelector(`.chat-tool-card__raw-body`);if(!t||!n)return;let r=t.getAttribute(`aria-expanded`)===`true`;t.setAttribute(`aria-expanded`,String(!r)),n.hidden=r}function sy(e,t){return e.kind!==`canvas`||e.render!==`url`||!e.viewId||!e.url?null:{kind:`canvas`,docId:e.viewId,entryUrl:e.url,...e.title?{title:e.title}:{},...e.preferredHeight?{preferredHeight:e.preferredHeight}:{},...e.sandbox?{sandbox:e.sandbox}:{},...t?{rawText:t}:{}}}function cy(e){return H`
    <div class="chat-tool-card__raw">
      <button
        class="chat-inline-disclosure chat-tool-card__raw-toggle"
        type="button"
        aria-expanded="false"
        @click=${oy}
      >
        <span>${L(`chat.toolCards.rawDetails`)}</span>
        <span class="chat-inline-disclosure__chevron" aria-hidden="true">${z.chevronDown}</span>
      </button>
      <div class="chat-tool-card__raw-body" hidden>${ly({text:e})}</div>
    </div>
  `}function ly(e){let{label:t,text:n}=e,r=Cc(n)?`markdown-block-art`:``;return H`
    <div class="chat-tool-card__block">
      ${t?H`<div class="chat-tool-card__block-header">
              <span class="chat-tool-card__block-icon">${z.zap}</span>
              <span class="chat-tool-card__block-label">${t}</span>
            </div>`:G}
      <pre class="chat-tool-card__block-content"><code class=${r}>${n}</code></pre>
    </div>
  `}function uy(e){if(typeof e==`string`)return o(e,Sy);if(e==null||typeof e==`number`||typeof e==`boolean`||typeof e==`bigint`)return String(e);try{return o(JSON.stringify(e),Sy)}catch{return Object.prototype.toString.call(e)}}function dy(e){return H`
    <div class="chat-tool-kv">
      ${Object.entries(e).map(([e,t])=>H`
          <div class="chat-tool-kv__row">
            <span class="chat-tool-kv__key">${e}:</span>
            <span class="chat-tool-kv__value">${uy(t)}</span>
          </div>
        `)}
    </div>
  `}function fy(e){if(!s(e))return!1;let t=Object.keys(e);return t.length>0&&t.length<=xy}function py(e,t){if(!s(e))return null;let n=Cy[t];if(!n)return e;let r=Object.fromEntries(Object.entries(e).filter(([e])=>!n.has(e)));return Object.keys(r).length>0?r:null}function my(e,t){if(t.kind!==`read`&&t.kind!==`edit`&&t.kind!==`write`)return null;let n=t.fileOperations?.length===1?t.fileOperations[0]:void 0;if(n?.operation===`delete`)return null;let r=m(e.args);if(r)for(let e of[`path`,`file_path`,`filePath`,`notebook_path`]){let t=r[e];if(typeof t==`string`&&t.trim())return t}let i=`${t.targetDetail?`${t.targetDetail}/`:``}${t.target??``}`.trim();return t.fileOperations?n?.path===i?n.path:null:i||null}function hy(e,t,n){return t&&n?H`
        <button
          class="chat-tool-card__detail chat-tool-card__detail-link"
          type="button"
          title=${L(`chat.toolCards.openFile`)}
          @click=${()=>n({path:t})}
        >
          ${e}
        </button>
      `:H`<div class="chat-tool-card__detail">${e}</div>`}function gy(e,t){let n=e===`skipped`?L(`chat.toolCards.skipped`):e===`failed`?t===void 0?L(`chat.toolCards.failed`):L(`chat.toolCards.exitCode`,{code:String(t)}):L(e===`running`?`chat.toolCards.running`:e===`succeeded`?`chat.toolCards.completed`:e===`blocked`?`chat.toolCards.blocked`:`chat.toolCards.outcomeUnknown`);return H`<div class="chat-tool-card__outcome">${n}</div>`}function _y(e,t){return H`
    <div class="chat-tool-term">
      <div class="chat-tool-term__cmd">
        <span class="chat-tool-term__prompt">$</span
        ><code>${Xv(e)}</code>
      </div>
      ${t===void 0?G:H`<pre class="chat-tool-term__out"><code>${t}</code></pre>`}
    </div>
  `}function vy(e,t,n,r,i,a){let o=`${t}:${e.id}`,s=i||r===`skipped`?`raw`:`diff`,c=L(`chat.toolCards.viewMode`),l=[[`diff`,`chat.toolCards.diff`,iy(n,r,void 0,a)],[`raw`,`chat.toolCards.raw`,ly({...i?{label:L(`chat.toolCards.toolError`)}:{},text:e.outputText})]];return H`
    <wa-tab-group
      class="chat-tool-card__modes"
      aria-label=${c}
      .active=${s}
      activation="auto"
      without-scroll-controls
      ${U(e=>Zl(e,c))}
    >
      ${l.map(([e,t])=>H`<wa-tab
          slot="nav"
          id=${`${o}-${e}-tab`}
          aria-controls=${`${o}-${e}-panel`}
          panel=${e}
          ?active=${s===e}
        >
          ${L(t)}
        </wa-tab>`)}
      ${l.map(([e,,t])=>H`<wa-tab-panel
          id=${`${o}-${e}-panel`}
          aria-labelledby=${`${o}-${e}-tab`}
          name=${e}
          ?active=${s===e}
        >
          ${t}
        </wa-tab-panel>`)}
    </wa-tab-group>
  `}function yy(e){return e.map(e=>`${e.kind===`add`?`+`:e.kind===`del`?`-`:` `}${e.text}`).join(`
`)}function by(e,{messageKey:t,sessionKey:n,agentId:r,onOpenSidebar:i,runActive:a,onOpenWorkspaceFile:s}){let c={kind:`tool-output`,card:e,sessionKey:n,agentId:r},l=Ba(e),u=Xo(e),d=Math.max(u?.length??0,e.outputText?.length??0)>uo,f=d&&i&&!l?{...e,outputText:o(u??``,uo)}:{...e,outputText:u},p=H`
    ${u!==e.outputText&&e.outputText!==void 0&&!(d&&i)?cy(e.outputText):G}
    ${l?H`<p role="status">${L(`chat.toolCards.fullOutputUnavailable`)}</p>`:(d||f.outputTruncated)&&i?H`<button
              class="btn btn--sm"
              type="button"
              @click=${()=>i(c)}
            >
              ${L(`chat.toolCards.showFullOutput`)}
            </button>`:G}
  `,h=Qa({name:f.name,args:f.args,details:f.details}),g=io({name:f.name,args:f.args}),_=h.kind===`read`||h.kind===`search`||h.kind===`fetch`,v=_?g.detail:Yr(g),y=f.outputText!==void 0,b=!!f.inputText?.trim(),x=qa(f),S=vs(f,a),C=my(f,h),w=!!i,T=(f.preview?.kind===`canvas`?sy(f.preview,f.outputText):null)??c,E=w?H`
        <openclaw-tooltip content=${L(`chat.toolCards.openDetails`)}>
          <button
            class="chat-tool-card__action-btn"
            type="button"
            @click=${()=>i?.(T)}
            aria-label=${L(`chat.toolCards.openDetails`)}
          >
            <span class="chat-tool-card__action-icon">${z.panelRightOpen}</span>
          </button>
        </openclaw-tooltip>
      `:G,D=h.diff&&h.diff.length>0?Pc(yy(h.diff),L(`common.copy`)):G;if(h.kind===`command`&&(h.command||h.code)&&!f.preview){let e=m(f.args),t=h.code?e?.code===h.code?`code`:`input`:`command`,n=Object.fromEntries(Object.entries(e??{}).filter(([e])=>e!==t));return H`
      <div class="chat-tool-card chat-tool-card--flush ${x?`chat-tool-card--error`:``}">
        <div class="chat-tool-card__actions">${E}</div>
        ${h.code?t===`input`?H`${y?ly({text:f.outputText}):G}
                  <details class="chat-tool-card__input">
                    <summary>${L(`chat.toolCards.toolInput`)}</summary>
                    ${ly({text:h.code})}
                  </details>`:H`${ly({label:L(`chat.toolCards.toolInput`),text:h.code})}
                ${y?ly({text:f.outputText}):G}`:_y(h.command,f.outputText)}
        ${Object.keys(n).length>0?dy(n):G}
        ${p} ${gy(S,f.exitCode)}
      </div>
    `}if((h.kind===`edit`||h.kind===`write`)&&h.diff&&h.diff.length>0){let e=h.fileOperations?.[0]??{path:h.target??``};return H`
      <div class="chat-tool-card ${x?`chat-tool-card--error`:``}">
        <div class="chat-tool-card__header">
          ${hy(C??h.target??``,C,s)}
          <div class="chat-tool-card__actions">${D}${E}</div>
        </div>
        ${y?vy(f,t,h.diff,S,x,e):iy(h.diff,S,void 0,e)}
        ${p} ${gy(S,f.exitCode)}
      </div>
    `}let O=_?py(f.args,h.kind):f.args,k=b&&(!_||O!==null);return H`
    <div class="chat-tool-card ${x?`chat-tool-card--error`:``}">
      ${v||w?H`
              <div class="chat-tool-card__header">
                ${v?h.kind===`read`?hy(v,C,s):H`<div class="chat-tool-card__detail">${v}</div>`:G}
                <div class="chat-tool-card__actions">${E}</div>
              </div>
            `:G}
      ${k?fy(O)?dy(O):ly({label:L(`chat.toolCards.toolInput`),text:f.inputText}):G}
      ${y?f.preview?.kind===`canvas`?cy(f.outputText):ly({...x?{label:L(`chat.toolCards.toolError`)}:{},text:f.outputText}):x?ly({label:L(`chat.toolCards.toolError`),text:L(`chat.toolCards.noOutputFailed`)}):G}
      ${p} ${gy(S,f.exitCode)}
    </div>
  `}var xy,Sy,Cy;function wy(){return(wy=e((()=>{K(),W(),ic(),B(),uc(),V(),Kl(),R(),_o(),vo(),Gr(),Na(),$v(),ay(),xy=12,Sy=400,Cy={read:new Set([`path`,`file_path`,`filePath`,`notebook_path`]),search:new Set([`pattern`,`query`,`glob`,`path`]),fetch:new Set([`url`])}})))()}function Ty(e,t=!0,n){let r=e.filter(qa),i=n?_r(n).outcomes:void 0,a=i?.failed??r.length,o=i?.skipped??e.filter(ga).length,s=r[0];if(a===0&&o===0)return G;let c=s?.exitCode===void 0?L(`chat.toolCards.failed`):L(`chat.toolCards.exitCode`,{code:String(s.exitCode)});return H`${a>0?H`<span class="chat-tool-failure"
          >${t?L(`chat.toolCards.failureCount`,{count:String(a)}):c}</span
        >`:G}${o>0?H`<span class="chat-tool-skipped"
          >${t?L(`chat.toolCards.skippedCount`,{count:String(o)}):L(`chat.toolCards.skipped`)}</span
        >`:G}`}function Ey(){return(Ey=e((()=>{K(),vr(),R(),vo()})))()}function Dy(e,t={}){let n=e.contentWindow;if(!n)return Promise.reject(Error(`widget frame is unavailable`));let r=t.id??Array.from(crypto.getRandomValues(new Uint32Array(4)),e=>e.toString(16).padStart(8,`0`)).join(``),i=t.timeoutMs??My;return new Promise((e,t)=>{let a=()=>{window.removeEventListener(`message`,s),globalThis.clearTimeout(c)},o=e=>{a(),t(e)},s=t=>{if(t.source!==n)return;let i=t.data;i&&i.type===jy&&i.id===r&&(typeof i.error==`string`?o(Error(i.error)):typeof i.dataUrl!=`string`||!i.dataUrl.startsWith(`data:image/png;base64,`)||i.dataUrl.length>Ny?o(Error(`widget returned an invalid snapshot`)):(a(),e(i.dataUrl)))};window.addEventListener(`message`,s);let c=globalThis.setTimeout(()=>o(new Py(`widget snapshot request timed out`)),i);try{n.postMessage({type:Ay,id:r},`*`)}catch(e){o(e instanceof Error?e:Error(String(e)))}})}function Oy(e,t){let n=document.createElement(`a`);n.href=e,n.download=t,n.click()}async function ky(e,t,n,r={}){let i=Array.from((n??``).trim(),e=>{let t=e.codePointAt(0)??0;return t<=31||t===127||`<>:"/\\|?*`.includes(e)?`-`:e}).join(``).replace(/\s+/g,`-`).replace(/-+/g,`-`).replace(/^[. -]+|[. -]+$/g,``),a=o(i,120).replace(/[. -]+$/g,``)||`widget`,s=(r.requestSnapshot??Dy)(t,r.timeoutMs===void 0?{}:{timeoutMs:r.timeoutMs});if(e===`copy`){ze();let e=r.copyImage??(e=>{if(!navigator.clipboard?.write||typeof ClipboardItem>`u`)throw Error(`image clipboard is unavailable`);let t=e.then(async e=>(await globalThis.fetch(e)).blob());return t.catch(()=>{}),navigator.clipboard.write([new ClipboardItem({"image/png":t})])});try{return await e(s),`png`}catch(e){let t=await s.then(()=>null,e=>e);if(t instanceof Py)return`rerender-required`;throw t??e}}try{let e=await s;return(r.download??Oy)(e,`${a}.png`),`png`}catch(e){if(!(e instanceof Py))throw e;let n;if(r.documentHtml!==void 0)n=new Blob([r.documentHtml],{type:`text/html`});else{let i=t.getAttribute(`src`);if(!i)throw Error(`widget document URL is unavailable`,{cause:e});let a=new URL(i,window.location.href);if(a.origin!==window.location.origin)throw Error(`widget document URL is not same-origin`,{cause:e});let o=await(r.fetch??globalThis.fetch)(a.href);if(!o.ok)throw Error(`widget document download failed (${o.status})`,{cause:e});n=await o.blob()}let i=URL.createObjectURL(n);try{(r.download??Oy)(i,`${a}.html`)}finally{URL.revokeObjectURL(i)}return`html`}}var Ay,jy,My,Ny,Py;function Fy(){return(Fy=e((()=>{xt(),Ay=`openclaw:widget-snapshot-request`,jy=`openclaw:widget-snapshot`,My=5e3,Ny=33554432,Py=class extends Error{}})))()}var Iy;function Ly(){return(Ly=e((()=>{n(),K(),ar(),Rn(),an(),Ln(),An(),$l(),B(),Lc(),At(),R(),_s(),xt(),Ar(),fi(),Pe(),tt(),Re(),mf(),Iy=class extends He{constructor(){super(),this.latest=!1,this.failedImages=new Set,this.subscriptions=new mt(this),this.open=()=>{this.opensExternally?this.openExternal():this.openPanel()},this.openPanel=()=>{let e=Ys(this.preview);e&&this.dispatchEvent(new CustomEvent(tn,{detail:{open:!0,browserTab:e},bubbles:!0,composed:!0}))},this.onMenuSelect=e=>{let t=this.preview?.url;t&&(e.detail.item.value===`copy-url`?et(t,()=>this.isConnected&&this.preview?.url===t):e.detail.item.value===`open-new-tab`?this.openExternal():e.detail.item.value===`open-within-openclaw`&&this.openPanel())},this.subscriptions.watch(()=>this.context?.gateway,(e,t)=>e.subscribe(t)),this.subscriptions.watch(()=>this.context?.config,(e,t)=>e.subscribe(t)),this.subscriptions.watch(()=>this.context?.theme,(e,t)=>e.subscribe(t))}static{this.styles=[er(lf),ir`
      :host {
        display: block;
        max-width: 320px;
        margin-block: 6px;
      }
      .card {
        overflow: hidden;
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
      }
      .shot {
        display: block;
        width: 100%;
        padding: 0;
        background: none;
        border: 0;
        cursor: default;
      }
      .shot img {
        display: block;
        width: 100%;
        height: auto;
        max-height: 240px;
        object-fit: cover;
        object-position: top;
      }
      .shot.social img {
        aspect-ratio: 1.91;
        object-fit: contain;
        object-position: center;
      }
      .bar {
        position: relative;
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
        padding: 7px 8px 7px 10px;
      }
      .shot + .bar {
        border-top: 1px solid var(--border);
      }
      .icon {
        display: flex;
        flex: 0 0 20px;
        align-items: center;
        justify-content: center;
        color: var(--muted);
      }
      .icon svg,
      .icon img {
        width: 16px;
        height: 16px;
      }
      .icon img {
        box-sizing: border-box;
        width: 20px;
        height: 20px;
        padding: 2px;
        object-fit: contain;
        /* Site icons are often dark on transparent; retain their colors on a light plate. */
        background: var(--button-icon-bg);
        border-radius: 4px;
      }
      .identity {
        display: grid;
        flex: 1;
        min-width: 0;
        gap: 1px;
      }
      .title,
      .url {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .title {
        font-size: 0.8rem;
        font-weight: 500;
      }
      .url {
        color: var(--muted);
        font-size: 0.72rem;
      }
      .actions {
        display: flex;
        flex: none;
        gap: 2px;
        align-items: center;
        opacity: 0;
        transition: opacity 120ms ease;
      }
      .card:hover .actions,
      .card:focus-within .actions,
      .actions:has(wa-dropdown[open]) {
        opacity: 1;
      }
      .actions button {
        display: flex;
        align-items: center;
        padding: 4px 8px;
        color: var(--text);
        font: inherit;
        font-size: 0.75rem;
        background: none;
        border: 0;
        border-radius: var(--radius-sm);
        cursor: default;
      }
      .actions button:hover {
        background: var(--panel-hover);
      }
      .actions button:focus-visible {
        outline: 2px solid var(--accent);
        outline-offset: -2px;
      }
      .actions .more svg {
        width: 16px;
        height: 16px;
      }
      .shot[data-new-tab-action],
      .actions button[data-new-tab-action] {
        cursor: pointer;
      }
    `]}get canLoadPagePreview(){return!!(this.context?.config.current.automaticallyFetchFavicons&&Or(this.context.gateway.snapshot,`controlUi.linkPreview`,`operator.read`,{requireAdvertisement:!1}))}updatePagePreview(){let e=this.context?.gateway.snapshot.client,t=this.preview?.url;if(!this.canLoadPagePreview||!e||!t){this.pageIdentity=void 0,this.pagePreview=void 0;return}if(this.pagePreviewCurrent)return;let n={client:e,url:t,generation:e.connectionGeneration,recoveryScope:e.recoveryScope};this.pageIdentity=n,this.pagePreview=void 0,this.failedImages.clear(),No(e,t).then(e=>{this.isConnected&&this.pageIdentity===n&&this.pagePreviewCurrent&&(this.pagePreview=e)})}get pagePreviewCurrent(){let e=this.pageIdentity,t=this.context?.gateway.snapshot.client;return!!(e&&t&&this.canLoadPagePreview&&e.client===t&&e.url===this.preview?.url&&e.generation===t.connectionGeneration&&e.recoveryScope===t.recoveryScope)}disconnectedCallback(){this.pageIdentity=void 0,this.pagePreview=void 0,super.disconnectedCallback()}updated(){this.updatePagePreview();let e=this.preview,t=this.context,n=t?.gateway.snapshot,r=n?.client,i=this.revision;if(!e||!t||!n||!r||!sn(n)||!this.latest||!i){(!this.latest||!n||!sn(n))&&(this.requestIdentity=void 0,this.thumbnailSrc=void 0);return}let a=JSON.stringify([Sc(e),i]);if(this.requestIdentity?.key===a&&this.requestIdentity.client===r)return;let o={client:r,key:a};this.requestIdentity=o,this.thumbnailSrc=void 0,ls({client:r,tab:e,revision:i,resourceBasePath:t.resourceBasePath,authToken:Xt({hello:n.hello,settings:{token:t.gateway.connection.token},password:t.gateway.connection.password})}).then(e=>{this.requestIdentity===o&&(this.thumbnailSrc=e)})}get opensExternally(){return this.context?.theme.settings.openLinksExternally===!0}openExternal(){let e=Be(this.preview?.url??``,window.location.href);e&&!$t(e)&&ct(e)}render(){let e=this.preview;if(!e)return G;let t=this.requestIdentity?.client===this.context?.gateway.snapshot.client&&this.requestIdentity?.key===JSON.stringify([Sc(e),this.revision])?this.thumbnailSrc:void 0,n=this.pagePreviewCurrent?this.pagePreview:void 0,r=n?.faviconDataUrl,i=t&&!this.failedImages.has(t)?t:n?.imageDataUrl,a=e.url;try{a=new URL(e.url??``).host||e.url}catch{}let o=e.title?.trim()||n?.title||a||L(`browser.title`),s=e.url?`${o} — ${e.url}`:o;return H`
      <div class="card">
        ${i&&!this.failedImages.has(i)?H`
                <button
                  type="button"
                  class=${i===t?`shot`:`shot social`}
                  aria-label=${s}
                  title=${this.opensExternally?L(`browser.openExternal`):L(`browser.openPanel`)}
                  ?data-new-tab-action=${this.opensExternally}
                  @click=${this.open}
                >
                  <img
                    src=${i}
                    alt=""
                    @error=${()=>{this.failedImages.add(i),this.requestUpdate()}}
                  />
                </button>
              `:G}
        <div class="bar">
          <span class="icon" aria-hidden="true"
            >${r&&!this.failedImages.has(r)?H`<img
                    src=${r}
                    alt=""
                    @error=${()=>{this.failedImages.add(r),this.requestUpdate()}}
                  />`:z.globe}</span
          >
          <span class="identity">
            <span class="title">${o}</span>
            ${e.url?H`<span class="url">${e.url}</span>`:G}
          </span>
          <span class="actions">
            <button
              type="button"
              title=${this.opensExternally?L(`browser.openExternal`):L(`browser.openPanel`)}
              ?data-new-tab-action=${this.opensExternally}
              @click=${this.open}
            >
              ${L(`browser.open`)}
            </button>
            <wa-dropdown
              class="session-menu"
              placement="bottom-end"
              @wa-select=${this.onMenuSelect}
            >
              <button
                slot="trigger"
                type="button"
                class="more"
                aria-label=${L(`browser.moreActions`)}
                aria-haspopup="menu"
                title=${L(`browser.moreActions`)}
              >
                ${z.moreHorizontal}
              </button>
              <wa-dropdown-item class="session-menu__item" value="copy-url">
                <span slot="icon" class="session-menu__icon" aria-hidden="true">${z.copy}</span>
                ${L(`browser.copyUrl`)}
              </wa-dropdown-item>
              <wa-dropdown-item
                class="session-menu__item"
                value=${this.opensExternally?`open-within-openclaw`:`open-new-tab`}
                ?data-new-tab-action=${!this.opensExternally}
              >
                <span slot="icon" class="session-menu__icon" aria-hidden="true"
                  >${this.opensExternally?z.globe:z.externalLink}</span
                >
                ${this.opensExternally?L(`browser.openWithinOpenClaw`):L(`browser.openNewTab`)}
              </wa-dropdown-item>
            </wa-dropdown>
          </span>
        </div>
      </div>
    `}},k([re({context:Fn,subscribe:!0}),X({attribute:!1})],Iy.prototype,`context`,void 0),k([X({attribute:!1})],Iy.prototype,`preview`,void 0),k([X({attribute:!1})],Iy.prototype,`revision`,void 0),k([X({type:Boolean})],Iy.prototype,`latest`,void 0),k([J()],Iy.prototype,`thumbnailSrc`,void 0),k([J()],Iy.prototype,`pagePreview`,void 0),customElements.get(`openclaw-browser-tab-card`)||customElements.define(`openclaw-browser-tab-card`,Iy)})))()}async function Ry(e,t,n,r,i){let a=i||t.viewId?.trim();if(!a)return;let o=e.currentTarget;if(o instanceof HTMLButtonElement){o.disabled=!0,o.title=o.ariaLabel=L(`chat.toolCards.pinToDashboardPending`);try{let e={name:r,...t.title?.trim()?{title:t.title.trim()}:{}};await(i?n.pinMcpApp({...e,viewId:a}):n.pinWidget({...e,docId:a})),o.title=o.ariaLabel=L(`chat.toolCards.pinnedToDashboard`),o.dataset.pinned=`true`}catch{o.disabled=!1,o.ariaLabel=L(`chat.toolCards.pinToDashboard`);let e=L(`chat.toolCards.pinToDashboardFailed`);o.title=e,I({message:e})}}}function zy(e){let t=e.viewId?.trim(),n=e.url?.trim();if(!t||!n)return!1;try{let e=new URL(n,`http://localhost`);if(e.origin!==`http://localhost`||!e.pathname.startsWith(`/__openclaw__/canvas/documents/`))return!1;let[r,i]=e.pathname.slice(31).split(`/`,2);if(!r||!i)return!1;let a=decodeURIComponent(r);return/^[A-Za-z0-9._-]+$/u.test(a)&&a===t}catch{return!1}}function By(e,t){if(!ob.has(e)&&ob.size>=cb){let e=ob.keys().next().value;e!==void 0&&ob.delete(e)}ob.set(e,t)}function Vy(e,t){let n=t;n&&n.type===eb&&ol(e,n.prompt,e.getAttribute(`src`)??``)}function Hy(e){let t=e.contentWindow;if(pb.has(e)||!fb.has(e)||!t)return;let n=ub.get(t);n&&(pb.add(e),ub.delete(t),n.addEventListener(`message`,t=>{Vy(e,t.data)}),n.start(),n.postMessage({type:tb}))}function Uy(){typeof window>`u`||mb.has(window)||(mb.add(window),window.addEventListener(`message`,e=>{let t=e.data;if(!t||t.type!==$y)return;let n=e.source,r=e.ports[0];if(n&&r&&e.origin===`null`){if(db.has(n)){r.close();return}db.add(n),ub.set(n,r);for(let e of ab)if(e.contentWindow===n){Hy(e);return}}}))}function Wy(){typeof window>`u`||lb.has(window)||(lb.add(window),window.addEventListener(`message`,e=>{let t=e.data;if(t&&t.type===Qy&&typeof t.height==`number`)for(let n of ab){if(!n.isConnected){ab.delete(n);continue}if(n.contentWindow===e.source){let e=Math.min(Math.max(Math.trunc(t.height),rb),ib);n.style.height=`${e}px`,n.style.minHeight=`${e}px`;let r=n.getAttribute(sb)??n.getAttribute(`src`);r&&By(r,e);return}}}))}function Gy(e){return Y(`${e.sandbox??``}\u0000${e.frameKey??``}\u0000${+!!e.src}\u0000${e.connectionGeneration??0}\u0000${e.height??``}`,gb(e))}function Ky(e){return bn(`mcp-app-view`,_b).catch(e=>{console.error(`[openclaw] failed to load MCP App view`,e)}),H`<mcp-app-view
    .sessionKey=${e.sessionKey}
    .viewId=${e.viewId}
    .height=${e.height}
    .title=${e.title}
  ></mcp-app-view>`}function qy(e,t,n,r){switch(e){case`canvas-html`:{if(t.sandbox!==`strict`&&zy(t))return bn(`openclaw-canvas-widget-view`,vb).catch(e=>console.error(`[openclaw] failed to load widget view`,e)),Y(`${t.viewId}\0${Ze()}`,H`
            <openclaw-canvas-widget-view
              .docId=${t.viewId.trim()}
              .sessionKey=${r?.sessionKey??``}
              .messageTimestamp=${r?.messageTimestamp}
              .title=${t.title?.trim()||L(`chat.toolCards.canvas`)}
              .preferredHeight=${t.preferredHeight}
              .allowScripts=${n.includes(`allow-scripts`)}
              .connectionGeneration=${Ze()}
            ></openclaw-canvas-widget-view>
          `);let e=Ei(t.url);return Gy({title:t.title?.trim()||L(`chat.toolCards.canvas`),src:co(t.url,r?.canvasPluginSurfaceUrl,r?.allowExternalEmbedUrls??!1),frameKey:t.url?.trim()||t.viewId?.trim(),connectionGeneration:e?Ze():void 0,height:t.preferredHeight,sandbox:n,promptCapable:e})}case`mcp-app`:return t.mcpApp?Ky({sessionKey:r?.sessionKey??``,viewId:t.mcpApp.viewId,height:t.preferredHeight??600,title:t.title?.trim()||L(`mcpApp.title`)}):G}return G}function Jy(e,t){let n=e.detail.item.value;if(n===`raw-details`){let t=e.currentTarget,n=(t instanceof HTMLElement?t.closest(`.chat-tool-card__widget-host`):null)?.querySelector(`.chat-tool-card__widget-raw .chat-tool-card__raw-toggle`);n?.click(),(t instanceof HTMLElement?t.querySelector(`[data-raw-label]`):null)?.replaceChildren(L(n&&n.getAttribute(`aria-expanded`)===`true`?`chat.toolCards.hideRawDetails`:`chat.toolCards.showRawDetails`));return}if(n!==`copy`&&n!==`download`)return;let r=e.currentTarget,i=r instanceof HTMLElement?r.closest(`.chat-tool-card__preview`)?.querySelector(`.chat-tool-card__preview-frame`):null;if(!i){I({message:L(`chat.toolCards.widgetExportFailed`)});return}let a=i.closest(`openclaw-canvas-widget-view`)?.documentHtml;ky(n,i,t,{documentHtml:a}).then(e=>{e===`rerender-required`?I({message:L(`chat.toolCards.widgetExportRerender`)}):e===`html`?I({message:L(`chat.toolCards.widgetExportHtmlFallback`)}):n===`copy`&&I({message:L(`common.copied`)})}).catch(()=>{I({message:L(`chat.toolCards.widgetExportFailed`)})})}function Yy(){let e,t;return n=>{e?.disconnect(),e=void 0,t!==void 0&&(cancelAnimationFrame(t),t=void 0),n instanceof HTMLElement&&typeof ResizeObserver<`u`&&(t=requestAnimationFrame(()=>{t=void 0;let r=n.closest(`.chat-thread`);r&&(e=new ResizeObserver(()=>{let e=r.getBoundingClientRect().left+r.clientLeft+r.clientWidth-n.getBoundingClientRect().right;n.toggleAttribute(`data-widget-actions-above`,e<40)}),e.observe(n),e.observe(r))}))}}function Xy(e,t){let n=!e.mcpApp&&Ei(e.url);return!n&&!t?G:H`
    <wa-dropdown
      class="chat-tool-card__widget-actions"
      placement="bottom-end"
      aria-label=${L(`chat.toolCards.widgetActions`)}
      @wa-select=${t=>Jy(t,e.title)}
    >
      <button
        slot="trigger"
        type="button"
        class="btn btn--ghost btn--icon chat-tool-card__widget-actions-trigger"
        aria-label=${L(`chat.toolCards.widgetActions`)}
        title=${L(`chat.toolCards.widgetActions`)}
      >
        ${z.moreHorizontal}
      </button>
      ${n?[[`copy`,z.copyImage,`chat.toolCards.copyAsImage`],[`download`,z.download,`chat.toolCards.downloadAsImage`]].map(([e,t,n])=>H`
                <wa-dropdown-item class="session-menu__item" value=${e}>
                  <span slot="icon" class="session-menu__icon" aria-hidden="true">${t}</span>
                  <span class="session-menu__text">${L(n)}</span>
                </wa-dropdown-item>
              `):G}
      ${t?H`<wa-dropdown-item class="session-menu__item" value="raw-details">
              <span slot="icon" class="session-menu__icon" aria-hidden="true"
                >${z.fileText}</span
              >
              <span class="session-menu__text" data-raw-label
                >${L(`chat.toolCards.showRawDetails`)}</span
              >
            </wa-dropdown-item>`:G}
    </wa-dropdown>
  `}function Zy(e,t,n){if(!e)return G;if(e.kind===`browser-tab`)return t===`chat_tool`?H`<openclaw-browser-tab-card
          .preview=${e}
          .revision=${n?.browserTabRevision}
          .latest=${n?.browserTabLatest??!1}
        ></openclaw-browser-tab-card>`:G;if(e.kind!==`canvas`||t===`chat_tool`||e.surface!==`assistant_message`)return G;let r=e.mcpApp?`mcp-app`:`canvas-html`,i=Fr(n?.embedSandboxMode??`scripts`,e.sandbox),a=n?.boardProvider,o=e.mcpApp?.viewId?.trim(),s=e.viewId?.trim(),c=e.mcpApp?o?ka(o):void 0:e.boardWidgetName||(s?Do(s):void 0),l=!!(c&&a?.snapshot$.value.widgets.find(e=>e.name===c)),u=L(l?`chat.toolCards.pinnedToDashboard`:`chat.toolCards.pinToDashboard`),d=a&&(r===`mcp-app`?a.canPinMcpApps:a.canPinWidgets)&&c&&(r===`canvas-html`&&i.includes(`allow-scripts`)&&zy(e)||r===`mcp-app`&&o)?H`<button
          class="btn btn--ghost btn--icon chat-tool-card__widget-action"
          type="button"
          data-pin-widget
          ?disabled=${l}
          ?data-pinned=${l}
          title=${u}
          aria-label=${u}
          @click=${t=>void Ry(t,e,a,c,o)}
        >
          ${z.pin}
        </button>`:G,f=Xy(e,!!n?.rawText),p=d===G&&f===G?G:H`<div class="chat-tool-card__preview-actions" data-widget-actions>
          ${d} ${f}
        </div>`;return H`
    <div
      ${p===G?G:U(Yy())}
      class="chat-tool-card__preview"
      data-content-kind=${r}
      ?data-has-widget-actions=${p!==G}
      data-kind="canvas"
      data-surface=${t}
    >
      ${p}
      <div class="chat-tool-card__preview-panel" data-side="canvas">
        ${qy(r,e,i,n)}
      </div>
    </div>
  `}var Qy,$y,eb,tb,nb,rb,ib,ab,ob,sb,cb,lb,ub,db,fb,pb,mb,hb,gb,_b,vb;function yb(){return(yb=e((()=>{K(),Hn(),sr(),W(),Mt(),B(),Ml(),Lc(),R(),Ro(),oe(),Gr(),Oe(),aa(),Fy(),Ly(),t(),Qy=`openclaw:widget-size`,$y=`openclaw:widget-prompt-offer`,eb=`openclaw:widget-prompt`,tb=`openclaw:widget-prompt-host-ready`,nb=`openclaw:widget-chat-host`,rb=48,ib=8e3,ab=new Set,ob=new Map,sb=`data-frame-key`,cb=100,lb=new WeakSet,ub=new WeakMap,db=new WeakSet,fb=new WeakSet,pb=new WeakSet,mb=new WeakSet,hb=class extends gr{render(e){Wy(),na();let t=e.sandbox??``,n=this.frame&&pb.has(this.frame)?this.frame.getAttribute(`src`):e.src??``,r=e.frameKey||n,i=(r?ob.get(r):void 0)??e.height;return e.promptCapable&&Uy(),Y(n,H`
        <iframe
          ${U(e=>{e instanceof HTMLIFrameElement&&(this.frame&&this.frame!==e&&ab.delete(this.frame),this.frame=e)})}
          src=${n||G}
          data-frame-key=${r||G}
          class="chat-tool-card__preview-frame"
          title=${e.title}
          sandbox=${t}
          style=${i?`height:${i}px;min-height:${i}px`:``}
          @load=${t=>{if(t.currentTarget instanceof HTMLIFrameElement){let n=t.currentTarget;ab.add(n),e.promptCapable&&(fb.add(n),Hy(n)),la(n),n.contentWindow?.postMessage({type:nb},`*`)}}}
        ></iframe>
      `)}},gb=Kn(hb),_b=async()=>{(await ne(()=>import(`./mcp-app-view-registration-CmvjRgVO.js`),__vite__mapDeps([12,3,1,2,4,5,6,7]),import.meta.url)).registerMcpAppView()},vb=()=>ne(()=>import(`./canvas-widget-view-CeY5vbTq.js`),__vite__mapDeps([13,1,2,3,4,14,5,6,7]),import.meta.url)})))()}function bb(e,t){let n=e.flatMap(e=>e.messages.flatMap(e=>fo(e.message))),r=new Set,i=new Set;return n.toReversed().flatMap(e=>{if(!e.browserTab||vs(e,!1)!==`succeeded`)return[];let n=Sc(e.browserTab);if(r.has(n))return[];r.add(n);let a=e.preview;if(a?.kind!==`browser-tab`)return[];let o=a.url.length<2047?JSON.stringify([lc(a),a.url]):n;if(i.has(o))return[];i.add(o);let s=es(e);return[Zy(a,`chat_tool`,{browserTabRevision:s?JSON.stringify([t.sessionKey,s]):void 0,browserTabLatest:!!(s&&t.latestBrowserTabs?.get(Sc(a))?.revision===s)})]}).toReversed()}function xb(e,t){let n=t?.pluginToolIcons?.get(t.toolName);return n?H`<span
      class="chat-tool-activity-icon"
      aria-hidden="true"
      style=${nr({maskImage:`url("${n.url}")`})}
    >
      <img hidden src=${n.url} alt="" @error=${n.onError} />
    </span>`:z[e]??z.puzzle}function Sb(e){if(e.kind===`write`)return`write`;if(e.kind!==`edit`)return;let t=new Set(e.fileOperations?.map(({operation:e})=>e));return t.size>1?`mixed`:t.values().next().value??`update`}function Cb(e,t){let n=Sb(e);if(n){let[e,r,i]=Rb[n];return L(t===`running`?e:t===`succeeded`?r:i)}let r=Lb[e.kind];return r?L(r):void 0}function wb(e){return o((br(e).command||e).replace(/\s+/gu,` `).trim(),200)}function Tb(e,t){return t!==`edit`&&t!==`write`?e:e.split(/[\\/]/u).findLast(Boolean)??e}function Eb(e){let t=e.currentTarget;if(!(t instanceof HTMLElement))return;let n=t.querySelector(`.chat-tool-disclosure__content`);t.classList.toggle(`chat-tool-disclosure--overflowing`,!!(n&&n.scrollWidth>n.clientWidth))}function Db(e,t,n,r,i){if(t.title)return H`<span class="chat-tool-row__title">${t.title}</span>`;if(t.kind===`command`&&t.command)return H`
      <span class="chat-tool-row__prompt" aria-hidden="true">$</span>
      <code class="chat-tool-row__cmd"
        >${Xv(wb(t.command))}</code
      >
    `;let a=Cb(t,n);if(a&&t.target){let o=n===`succeeded`?t.stat:n===`running`&&(t.kind===`edit`||t.kind===`write`)?e.liveDiffStat:void 0;return H`
      <span class="chat-tool-row__verb">${a}</span>
      ${r&&i?H`<button
              class="chat-tool-row__file-link"
              type="button"
              title=${L(`chat.toolCards.openFile`)}
              @click=${e=>{e.stopPropagation(),i({path:r})}}
            >
              ${Tb(t.target,t.kind)}
            </button>`:H`<span class="chat-tool-row__target"
              >${Tb(t.target,t.kind)}</span
            >`}
      ${o?ry(o):G}
      ${!r&&t.targetDetail&&t.kind!==`edit`&&t.kind!==`write`?H`<span class="chat-tool-row__detail">${t.targetDetail}</span>`:G}
    `}let o=io({name:e.name,args:e.args,detailMode:`explain`}),s=jb({card:e,displayLabel:o.label,displayDetail:o.detail}),c=Va(s.label)??s.label,l=jo(s.name,c);return H`
    <span class="chat-tool-msg-summary__label">${c}</span>
    ${l?H`<span class="chat-tool-msg-summary__names">${l}</span>`:G}
  `}function Ob(e){return Array.isArray(e)?e.flatMap(e=>{let t=m(e);return typeof t?.step!=`string`||t.status!==`pending`&&t.status!==`in_progress`&&t.status!==`completed`?[]:[{step:t.step,status:t.status}]}):[]}function kb(e,t){if(e.name.trim().toLowerCase()!==`progress_card`)return null;let n=m(e.args),r=Ob(n?.plan),i=typeof n?.markdown==`string`?n.markdown.trim():``,a=r.filter(e=>e.status===`completed`).length,o=r.find(e=>e.status===`in_progress`)??r.find(e=>e.status===`pending`)??r.findLast(e=>e.status===`completed`),s=t===`skipped`?L(`sessionProgressCard.receipt.skipped`):t===`failed`?L(`sessionProgressCard.receipt.failed`):t===`running`?L(`sessionProgressCard.receipt.updating`):r.length>0?L(`sessionProgressCard.receipt.updated`,{completed:String(a),current:o?.step??``,total:String(r.length)}):L(i?`sessionProgressCard.receipt.noteUpdated`:`sessionProgressCard.receipt.cleared`);return H`<div class="chat-tool-msg-collapse chat-progress-card-receipt">
    <div class="chat-tool-msg-summary chat-tool-row" role="status">
      <span class="chat-tool-msg-summary__icon">${xb(`listChecks`)}</span>
      <span class="chat-progress-card-receipt__text">${s}</span>
    </div>
  </div>`}function Ab(e,t){if(t?.trim())return t;if(typeof e.args!=`string`)return;let n=e.inputText?.trim()?e.inputText:e.args;return Pa(n)}function jb(e){let t=e.displayDetail?.trim();if(e.card.name.trim().toLowerCase()===`message`)return{label:e.displayLabel,name:t||void 0};let n=ts(e.card.args);return n?{label:e.displayLabel,name:n}:t?{label:e.displayLabel,name:t}:{label:typeof e.card.args==`string`?Ab(e.card,void 0)??e.displayLabel:e.displayLabel}}function Mb(e,t,n){if(t.title)return t.title;if(t.kind===`command`&&t.command)return`$ ${wb(t.command)}`;let r=Cb(t,n);if(r&&t.target)return`${r} ${t.target}`;let i=io({name:e.name,args:e.args,detailMode:`explain`}),a=jb({card:e,displayLabel:i.label,displayDetail:i.detail});return[a.label,a.name].filter(Boolean).join(` `)}function Nb(e){let t=e.status===`in_progress`?`reviewing`:e.status===`timed_out`?`timedOut`:e.status;return L(`chat.toolCards.review.${t}`,{reviewer:e.label})}function Pb(e){let t=Ki(e.details);return t.length===0?G:H`
    <div class="chat-tool-reviews">
      ${t.map(e=>{let t=[`denied`,`timed_out`,`aborted`].includes(e.status);return H`
          <div class="chat-tool-review" data-review-status=${e.status}>
            <div class="chat-tool-review__header">
              <span class="chat-tool-review__icon"
                >${t?z.shieldX:z.shieldCheck}</span
              >
              <span class="chat-tool-review__label">${Nb(e)}</span>
              ${e.riskLevel?H`<span class="chat-tool-review__chip"
                      >${L(`chat.toolCards.review.risk`,{level:e.riskLevel})}</span
                    >`:G}
              ${e.userAuthorization?H`<span class="chat-tool-review__chip"
                      >${L(`chat.toolCards.review.authorization`,{level:e.userAuthorization})}</span
                    >`:G}
            </div>
            ${e.status===`in_progress`?G:H`<div class="chat-tool-review__rationale">
                    ${e.rationale??L(`chat.toolCards.review.noRationale`)}
                  </div>`}
          </div>
        `})}
    </div>
  `}function Fb(e,t){let n=vs(e,t.runActive),r=kb(e,n);if(r&&!t.children)return Ib(e,t,r);let i=Qa({name:e.name,args:e.args,details:e.details}),a=io({name:e.name,args:e.args,detailMode:`explain`}),o=t.activityCards??[e],s=o.some(e=>vs(e,t.runActive)===`running`),c=t.expanded,l=zb[i.kind]??a.icon,u=my(e,i),d=!!u,f=H`
    <span class="chat-tool-msg-summary__icon"
      >${xb(l,{toolName:a.name,pluginToolIcons:t.pluginToolIcons})}</span
    >
    <span class="chat-tool-disclosure__content"
      >${Db(e,i,n,u,t.onOpenWorkspaceFile)}</span
    >
    ${c?G:Ty(o,!!t.children)}
    <span class="chat-tool-row__chevron" aria-hidden="true">${z.chevronRight}</span>
  `;return Ib(e,t,H`
      <div
        class="chat-tool-msg-collapse chat-tool-msg-collapse--manual ${c?`is-open`:``}"
      >
        ${d?H`<div
                class="chat-inline-disclosure chat-tool-msg-summary chat-tool-row chat-tool-row--file ${s?`chat-tool-row--running`:``}"
                @pointerenter=${Eb}
                @focusin=${Eb}
              >
                <button
                  class="chat-tool-row__toggle"
                  type="button"
                  aria-expanded=${String(c)}
                  aria-label=${Mb(e,i,n)}
                  @click=${()=>t.onToggleExpanded(e.id)}
                ></button>
                ${f}
              </div>`:H`<button
                class="chat-inline-disclosure chat-tool-msg-summary chat-tool-row ${s?`chat-tool-row--running`:``}"
                type="button"
                aria-expanded=${String(c)}
                @pointerenter=${Eb}
                @focus=${Eb}
                @click=${()=>t.onToggleExpanded(e.id)}
              >
                ${f}
              </button>`}
        ${c?t.children?H`<div class="chat-tool-children">
                  ${t.children}
                  <details class="chat-tool-wrapper-details">
                    <summary>${L(`chat.toolCards.toolInput`)}</summary>
                    <div class="chat-tool-msg-body">
                      ${by(e,t)}
                    </div>
                  </details>
                </div>`:H`<div class="chat-tool-msg-body">
                  ${by(e,t)}
                </div>`:G}
        ${t.showApprovalReviews===!1?G:Pb(e)}
      </div>
    `)}function Ib(e,t,n){return e?Je(`tool-result`,{sessionKey:t.sessionKey??``,agentId:t.agentId,toolName:e.name,toolCallId:e.callId??e.id,input:e.args,output:{text:e.outputText,details:e.details,isError:e.isError,completed:e.completed},expanded:t.expanded},n,t.presented??!0):n}var Lb,Rb,zb;function Bb(){return(Bb=e((()=>{K(),rr(),yr(),$l(),B(),R(),_s(),Ji(),_o(),vo(),Gr(),rt(),$v(),ay(),wy(),Ey(),yb(),Lb={read:`chat.toolCards.verbs.read`,search:`chat.toolCards.verbs.searched`,fetch:`chat.toolCards.verbs.fetched`},Rb={update:[`chat.toolCards.verbs.editing`,`chat.toolCards.verbs.edited`,`chat.toolCards.verbs.edit`],add:[`chat.toolCards.verbs.creating`,`chat.toolCards.verbs.created`,`chat.toolCards.verbs.create`],delete:[`chat.toolCards.verbs.deleting`,`chat.toolCards.verbs.deleted`,`chat.toolCards.verbs.delete`],mixed:[`chat.toolCards.verbs.changing`,`chat.toolCards.verbs.changed`,`chat.toolCards.verbs.change`],write:[`chat.toolCards.verbs.writing`,`chat.toolCards.verbs.wrote`,`chat.toolCards.verbs.write`]},zb={command:`squareTerminal`,read:`fileText`,edit:`pencil`,write:`fileCode`,search:`search`,fetch:`globe`}})))()}function Vb(e,t){return Y(e,H`<button
      class="btn btn--sm chat-copy-btn"
      type="button"
      @click=${n=>void Nc(n,e,t)}
    >
      <span data-copy-label>${t}</span>
    </button>`)}function Hb(e){let t=e.conflict;if(!t)return G;let n=qd(t),r=vf(t),i=zd(t),a=L(n===1?`chat.workspaceConflict.titleOne`:`chat.workspaceConflict.titleMany`,{count:String(n)});return H`
    <details
      class="chat-composer-neighbor-card chat-composer-neighbor-card--warn chat-workspace-conflict-notice"
      role="status"
    >
      <summary class="chat-workspace-conflict-notice__summary">
        <span class="chat-composer-neighbor-card__icon" aria-hidden="true"
          >${z.alertTriangle}</span
        >
        <span class="chat-composer-neighbor-card__copy">
          <strong>${a}</strong>
          <span>${L(`chat.workspaceConflict.summary`)}</span>
        </span>
        <span class="chat-workspace-conflict-notice__chevron" aria-hidden="true"
          >${z.chevronUp}</span
        >
        ${e.onDismiss?H`<button
                class="chat-error__dismiss"
                type="button"
                @click=${t=>{t.preventDefault(),t.stopPropagation(),e.onDismiss?.()}}
                aria-label=${L(`chat.workspaceConflict.dismiss`)}
              >
                ${z.x}
              </button>`:G}
      </summary>
      <div class="chat-workspace-conflict-notice__content">
        <ul class="chat-workspace-conflict-paths">
          ${r.paths.map(e=>{let n=zd(t,e);return H`<li>
              <code>${Rd(e)}</code>
              ${n?H`<span class="chat-workspace-conflict-path-actions">
                      ${Vb(n.inspect,L(`chat.workspaceConflict.inspectCloud`))}
                      ${Vb(n.takeCloud,L(`chat.workspaceConflict.takeCloud`))}
                    </span>`:G}
            </li>`})}
        </ul>
        ${r.remaining>0?H`<div class="chat-workspace-conflict-more">
                ${L(`chat.workspaceConflict.morePaths`,{count:String(r.remaining)})}
              </div>`:G}
        <details class="chat-workspace-conflict-commands-disclosure">
          <summary>${L(`chat.workspaceConflict.showCommands`)}</summary>
          <div class="chat-workspace-conflict-ref">
            <span>${L(`chat.workspaceConflict.stagedResult`)}</span>
            <code>${t.stagedResultRef}</code>
            ${Pc(t.stagedResultRef,L(`chat.workspaceConflict.copyStagedResult`))}
          </div>
          ${i?H`<div class="chat-workspace-conflict-commands">
                    <div>
                      <span>${L(`chat.workspaceConflict.inspectCloud`)}</span>
                      <code>${i.inspect}</code>
                      ${Pc(i.inspect,L(`chat.workspaceConflict.copyInspectCommand`))}
                    </div>
                    <div>
                      <span>${L(`chat.workspaceConflict.takeCloud`)}</span>
                      <code>${i.takeCloud}</code>
                      ${Pc(i.takeCloud,L(`chat.workspaceConflict.copyTakeCommand`))}
                    </div>
                  </div>
                  <p class="chat-workspace-conflict-command-help">
                    ${L(`chat.workspaceConflict.commandHelp`)}
                  </p>`:H`<p class="chat-workspace-conflict-command-help">
                  ${L(`chat.workspaceConflict.commandsUnavailable`)}
                </p>`}
        </details>
      </div>
    </details>
  `}function Ub(e,t,n){let r=qd(e),i=vf(e);return H`
    <div
      class="chat-bubble chat-bubble--workspace-conflict"
      data-message-id=${t}
      data-entry-id=${n||G}
    >
      <div class="chat-workspace-conflict-event" role="status">
        <div class="chat-workspace-conflict-event__header">
          <span aria-hidden="true">${z.alertTriangle}</span>
          <strong
            >${L(r===1?`chat.workspaceConflict.eventTitleOne`:`chat.workspaceConflict.eventTitleMany`,{count:String(r)})}</strong
          >
        </div>
        <p>${L(`chat.workspaceConflict.eventDescription`)}</p>
        <ul class="chat-workspace-conflict-paths">
          ${i.paths.map(e=>H`<li><code>${Rd(e)}</code></li>`)}
        </ul>
        ${i.remaining>0?H`<div class="chat-workspace-conflict-more">
                ${L(`chat.workspaceConflict.morePaths`,{count:String(i.remaining)})}
              </div>`:G}
        <div class="chat-workspace-conflict-ref">
          <span>${L(`chat.workspaceConflict.stagedResult`)}</span>
          <code>${e.stagedResultRef}</code>
        </div>
      </div>
    </div>
  `}function Wb(){return(Wb=e((()=>{K(),sr(),ic(),B(),R(),Id()})))()}function Gb(e){return[...e.orderedContent,...e.supplementalAttachments].filter(e=>e.type===`attachment`&&e.attachment.kind===`video`)}function Kb(e,t){let n=wr(e);return n?.role!==`user`||n.isImported?{localSubmission:!1}:!n.id||qu(e)?{localSubmission:!!n.sendId}:n.id.startsWith(`pending:`)?{}:{canonicalMessageKey:JSON.stringify([t,n.id,n.sequence])}}function qb(e,t){return H`
    <div class="chat-tools-inline">
      ${e.map((e,n)=>{if(t.toolCardOverrides?.has(e))return t.toolCardOverrides.get(e);let r=`${t.messageKey}:toolcard:${n}`,i=t.isToolExpanded?.(r)??!1;return Fb(e,{...t,expanded:i,onToggleExpanded:t.onToggleToolExpanded?()=>t.onToggleToolExpanded?.(r,i):()=>void 0})})}
    </div>
  `}function Jb(e){return e===0?G:H`
    <div class="chat-pairing-qr-notices">
      ${Array.from({length:e},()=>H`
          <div
            class="chat-assistant-attachment-card chat-assistant-attachment-card--blocked chat-pairing-qr-expired"
          >
            <span class="chat-pairing-qr-expired__icon" aria-hidden="true"
              >${z.alertTriangle}</span
            >
            <div class="chat-pairing-qr-expired__content">
              <div class="chat-pairing-qr-expired__heading">
                <span class="chat-pairing-qr-expired__title"
                  >${L(`chat.pairingQrExpired.title`)}</span
                >
                <span class="chat-pairing-qr-expired__badge"
                  >${L(`chat.pairingQrExpired.badge`)}</span
                >
              </div>
              <div class="chat-assistant-attachment-card__reason">
                ${L(`chat.pairingQrExpired.reason`)}
              </div>
            </div>
          </div>
        `)}
    </div>
  `}function Yb(e,t,n,r){let i=n.assistantMessageDisclosure,{message:a,normalizedMessage:o,displayMarkdown:s,humanMentions:c}=i?.expanded&&i.message?ov(i.message):e,l=a,u=typeof l.role==`string`?l.role:`unknown`,d=Fi(u),f=n.asyncQuestions?.submit?Qm(a):null,p=Fi(o.role),m=sf(a);if(m)return Ub(m,t,n.entryId);let h=p===`tool`,g=ai(a),_=n.showToolCalls??!0?fo(a):[],v=_.some(e=>n.toolCardOverrides?.get(e)!==G),{images:y,attachments:b,expiredPairingQrCount:x,nextPairingQrExpiresAt:S,orderedContent:C,supplementalImages:w,supplementalAttachments:T}=Wp(a,o.content);Gp(t,S,n.onRequestUpdate);let E=y.length>0,D=p===`user`?b.filter(e=>e.type===`attachment`&&e.attachment.kind===`video`):[],O=b.filter(e=>!D.includes(e)),k=p===`user`&&D_(O),ee={galleryImages:y,galleryVideos:e=>{let r=Gb({orderedContent:C,supplementalAttachments:T}),i=r.indexOf(e),a=n.getTurnVideoMessages?.(t);if(!a||i<0)return{index:i,items:r};let o=[],s=-1;for(let e of a)if(e.key===t)s=o.length+i,o.push(...r);else{let t=ov(e.message);o.push(...Gb(Wp(t.message,t.normalizedMessage.content)))}return{index:s,items:o}},sessionKey:n.sessionKey,agentId:n.agentId,policyKey:n.mediaPolicyKey,...E?Kb(a,n.sessionKey):{},connectionEpoch:n.connectionEpoch,resourceBasePath:n.resourceBasePath,authToken:n.assistantAttachmentAuthToken,onRequestUpdate:n.onRequestUpdate,onRequestOpenImage:n.onRequestOpenImage,onOpenImage:n.onOpenImage,resolveArtifactDownload:n.resolveArtifactDownload},te=n.messageActions?.markdown??s,ne=o.content.filter(e=>e.type===`omitted_media`),re=o.content.filter(e=>e.type===`canvas`),ie=o.content.filter(e=>e.type===`clawhub`),ae=n.showReasoning&&u===`assistant`?yo(a):null,oe=ae?`_Reasoning:_\n\n${ae}`:null,A=(p===`user`?n.messageActions?.markdown:void 0)??(s||null),j={assistantTranscriptRoleHeaders:u===`assistant`,codeBlockChrome:u===`user`?`none`:`copy`,codeBlockInteraction:u===`assistant`?`interactive`:`static`,fileLinks:!0,githubRepo:u===`assistant`?n.githubRepo??null:null,humanMentions:A===s?c:void 0,...u===`assistant`&&n.githubRepositories?{githubRepositories:n.githubRepositories}:{},interactiveImages:n.onOpenImage!==void 0,sessionLinks:!0,tableInteractions:`enabled`,linkFavicons:!!n.fetchLinkFavicon&&!n.isStreaming},M=A&&!n.isStreaming?mc(A):null,se=p===`user`&&!A&&!o.replyTarget&&!E&&!v&&ne.length===0&&x===0&&b.length>0&&b.every(e=>g_(e)||e_(e)),ce=[`chat-bubble`,E||D.length>0||k||p===`user`&&O.some(e=>g_(e)||e_(e))?`chat-bubble--with-images`:``,se?`chat-bubble--preview-chips-only`:``,k?`chat-bubble--with-files`:``,h?`chat-bubble--tool-shell`:``,n.isStreaming?`streaming`:``].filter(Boolean).join(` `);if(!A&&!f&&!oe&&!v&&!E&&x===0&&ne.length===0&&b.length===0&&re.length===0&&ie.length===0&&!o.replyTarget)return G;let le=`toolmsg:${t}`,ue=n.isToolMessageExpanded?.(le)??!1,de=[...new Set(_.map(e=>e.name))],N=_.length===1?_[0]:null,fe=g&&!!A&&!M&&!E&&N?.outputText?.trim()===A?.trim(),pe=fe?null:A,me=p===`assistant`&&!!A&&!f&&(!i?.expanded||!!i.message)&&C.some(e=>e.type!==`text`),he=!!N&&(!A||fe)&&!E,ge=he?void 0:_.find(qa),_e=N?io({name:N.name,args:N.args,detailMode:`explain`}):null,ve=N&&_e?Ab(N,_e.detail):void 0,ye=ve?!A&&!E?ve:N?.outputText?.trim()?`output`:void 0:de.length<=3?de.join(`, `):`${de.slice(0,2).join(`, `)} +${de.length-2} more`,be=A?Pa(A)??``:``,xe=_e&&!A&&!E?_e.label:L(`chat.toolCards.toolOutput`),Se=Va(xe)??xe,Ce=jo(ye,Se),we=_e?xb(_e.icon,{toolName:_e.name,pluginToolIcons:n.pluginToolIcons}):z.zap,Te=d===`assistant`&&re.length>0?H`${re.map(e=>H`<div class="chat-tool-card__widget-host">
            ${Zy(e.preview,`chat_message`,{rawText:e.rawText??null,canvasPluginSurfaceUrl:n.canvasPluginSurfaceUrl,boardProvider:n.boardProvider,embedSandboxMode:n.embedSandboxMode??`scripts`,allowExternalEmbedUrls:n.allowExternalEmbedUrls,sessionKey:n.sessionKey,messageTimestamp:typeof l.timestamp==`number`?l.timestamp:void 0})}
            ${e.rawText?H`<div class="chat-tool-card__widget-raw">
                    ${cy(e.rawText)}
                  </div>`:G}
          </div>`)}`:G,Ee=Math.max(1,Math.floor(n.duplicateCount??1)),De=Ee>1?{count:Ee,label:L(`chat.messages.duplicatesCollapsed`,{count:String(Ee)})}:void 0,P=g&&v&&!A&&!E&&x===0&&ne.length===0&&b.length===0&&re.length===0&&!oe,F={...n,messageKey:t,onOpenSidebar:r},Oe=()=>f?Gm(f,n.asyncQuestions):M?Ov(M,t,{...n,role:g?`tool`:p},j):pe?Mv(pe,t,{...n,role:g?`tool`:p},j,De):G,ke=()=>{let e=fv(C,e=>e.type===`image`?iv([e.image],ee):O_([e],ee,r,n.onAssistantAttachmentLoaded)),s=Jo(a,{...o,content:[{type:`text`,text:e.markdown}]});return Mv(s,t,{...n,role:p,assistantMessageDisclosure:i?{...i,markdown:s}:void 0},j,A?De:void 0,{...e.media,text:pe??``})},I=()=>me?ke():Oe(),Ae=()=>H`
    ${d===`assistant`?ie.map(e=>H`<openclaw-chat-clawhub-card
              .recommendation=${e}
              .agentId=${n.agentId}
            ></openclaw-chat-clawhub-card>`):G}
    ${Jb(x)}
    ${iv(me?w:y,ee,D.map(e=>H`
          <div class="chat-image-frame chat-video-preview">
            ${n.transcriptVisible===!1?G:k_(e,ee,r,n.onAssistantAttachmentLoaded,`preview`)}
          </div>
        `))}
    ${uh(ne)}
    ${O_(me?T:O,ee,r,n.onAssistantAttachmentLoaded,p===`assistant`)}
    ${g?Te:G}
    ${oe?H`<div class="chat-thinking">
            ${lr(Wc(oe,{codeBlockInteraction:`interactive`}))}
          </div>`:G}
    ${g?G:Te}
    ${n.avatar?H`<div class="chat-message-avatar-anchor">
            ${I()}${n.avatar}
          </div>`:I()}
    ${v?g&&he&&N?by(N,F):qb(_,{...F,showApprovalReviews:!g&&void 0}):G}
    ${g&&ge?gy(`failed`,ge.exitCode):G}
  `;return H`
    <div
      class="${ce}"
      ${n.entryRef?U(n.entryRef):G}
      data-message-id=${t}
      data-entry-id=${n.entryId||G}
      data-message-text=${te||G}
      .messageActions=${n.messageActions}
    >
      ${qv(o.replyTarget,o.replyTarget?.kind===`id`?n.resolveReplyPreview?.(o.replyTarget.id)??o.replyPreview:void 0,n.onOpenReply,n.onResolveReply,o.replyTarget?.kind===`id`&&n.replyNavigationId===o.replyTarget.id)}
      ${P?qb(_,F):g?Ib(N,{...F,expanded:ue},H`
                  <div
                    class="chat-tool-msg-collapse chat-tool-msg-collapse--manual ${ue?`is-open`:``}"
                  >
                    <button
                      class="chat-inline-disclosure chat-tool-msg-summary"
                      type="button"
                      aria-expanded=${String(ue)}
                      @pointerenter=${Eb}
                      @focus=${Eb}
                      @click=${()=>n.onToggleToolMessageExpanded?.(le,ue)}
                    >
                      <span class="chat-tool-msg-summary__icon">${we}</span>
                      <span class="chat-tool-disclosure__content">
                        <span class="chat-tool-msg-summary__label">${Se}</span>
                        ${Ce?H`<span class="chat-tool-msg-summary__names"
                                >${Ce}</span
                              >`:be?H`<span class="chat-tool-msg-summary__preview"
                                  >${be}</span
                                >`:G}
                      </span>
                      <span class="chat-tool-row__chevron" aria-hidden="true"
                        >${z.chevronRight}</span
                      >
                    </button>
                    ${ue?H`<div class="chat-tool-msg-body">${Ae()}</div>`:uh(ne)}
                    ${_.map(e=>Pb(e))}
                  </div>
                `):Ae()}
      ${d===`assistant`&&mu(a)?H`<div
              class="chat-tasks-status chat-turn-recap chat-turn-recap--continuation"
              role="status"
            >
              ${L(`chat.composer.runInterrupted`)}
            </div>`:G}
      ${Ee>1&&(!A||M)?H`<div
              class="chat-duplicate-count"
              aria-label=${L(`chat.messages.duplicatesCollapsed`,{count:String(Ee)})}
            >
              ×${Ee}
            </div>`:G}
    </div>
    ${M_(a)}
  `}function Xb(){return(Xb=e((()=>{Tr(),K(),W(),dr(),Er(),B(),dc(),Il(),R(),$r(),lo(),ac(),Fo(),Zr(),vo(),Gr(),Vu(),id(),jm(),Id(),nh(),fh(),j_(),N_(),av(),dv(),Sv(),Qp(),Kv(),n_(),Jv(),v_(),Bb(),wy(),Wb(),yb(),di()})))()}function Zb(e,t){if(!e)return G;let n=t.queuedMessageAction?.id===e.id?t.queuedMessageAction:void 0,r=e.state===`waiting-reconnect`,i=r?void 0:n?.onAction??t.onRetryQueuedMessage,a=(e.state===`failed`||e.state===`unconfirmed`||e.state===`held`||r)&&!n?t.onDiscardQueuedMessage:void 0;return H`<span
    class="chat-send-status"
    title=${e.error??G}
    data-send-state=${e.state}
  >
    <span class="chat-send-status__part">
      <span aria-hidden="true">·</span>
      <span
        >${L(r?`chat.queue.states.waitingForReconnect`:e.state===`held`?`chat.queue.states.needsReview`:e.state===`unconfirmed`?`chat.queue.deliveryUnconfirmed`:`chat.queue.notSent`)}</span
      >
    </span>
    ${i?H`
            <span class="chat-send-status__part">
              <span aria-hidden="true">·</span>
              <button
                class="chat-send-status__action chat-send-status__retry"
                type="button"
                aria-label=${n?.label??L(`chat.queue.retryQueuedMessage`)}
                @click=${()=>i(e.id)}
              >
                ${n?.label??L(`chat.queue.retry`)}
              </button>
            </span>
          `:G}
    ${a?H`
            <span class="chat-send-status__part">
              <span aria-hidden="true">·</span>
              <button
                class="chat-send-status__action chat-send-status__discard"
                type="button"
                title=${L(`chat.queue.discardPendingMessage`)}
                @click=${t=>{t.detail<=1&&a(e.id)}}
              >
                ${L(`chat.queue.discard`)}
              </button>
            </span>
          `:G}
  </span>`}function Qb(){return(Qb=e((()=>{K(),R()})))()}function $b(e){let t=new Date(e);return Number.isFinite(t.getTime())?{label:t.toLocaleString([],{month:`short`,day:`numeric`,year:`numeric`,hour:`numeric`,minute:`2-digit`,timeZoneName:`short`}),title:t.toLocaleString([],{weekday:`long`,month:`long`,day:`numeric`,year:`numeric`,hour:`numeric`,minute:`2-digit`,second:`2-digit`,timeZoneName:`short`}),dateTime:t.toISOString()}:{label:L(`chat.messages.unknownDate`),title:L(`chat.messages.unknownDate`),dateTime:``}}function ex(e,t=Date.now()){let n=new Date(e);if(!Number.isFinite(n.getTime()))return L(`chat.messages.unknownDate`);let r=t-n.getTime();return r>=-12e4&&r<ix?be(Math.max(0,r)):n.toLocaleDateString([],{month:`short`,day:`numeric`,...n.getFullYear()===new Date(t).getFullYear()?{}:{year:`numeric`}})}function tx(e,t=[]){let n=$b(e),r=H`
    <time class="chat-group-timestamp" datetime=${n.dateTime} aria-live="off">
      ${ex(e)}
    </time>
  `;return H`
    <openclaw-tooltip
      class="msg-meta"
      ?open-on-click=${t.length>0}
      content=${t.length?``:n.label}
    >
      ${t.length?H`<button
              type="button"
              class="msg-meta__summary"
              aria-label=${L(`chat.messages.contextFor`,{timestamp:n.title})}
            >
              ${r}
            </button>`:r}
      ${t.length?H`<span slot="content" class="msg-meta__details">
              <span class="msg-meta__time">${n.label}</span>${t}
            </span>`:G}
    </openclaw-tooltip>
  `}function nx(e,t){let n=0,r=0,i=0,a=0,o=0,s=null,c=!1,l=0;for(let{message:t}of e.messages){let e=t;if(e.role!==`assistant`)continue;let u=e.usage;if(u){c=!0;let e=u.input??u.inputTokens??0,t=u.output??u.outputTokens??0,o=u.cacheRead??u.cache_read_input_tokens??0,s=u.cacheWrite??u.cache_creation_input_tokens??0;n+=e,r+=t,i+=o,a+=s,l=Math.max(l,e+o+s)}let d=u?.cost??e.cost;d?.total&&(o+=d.total),typeof e.model==`string`&&e.model!==`gateway-injected`&&(s=e.model)}if(!c&&!s)return null;let u=t&&l>0?Math.min(Math.round(l/t*100),100):null;return{input:n,output:r,cacheRead:i,cacheWrite:a,cost:o,model:s,contextPercent:u}}function rx(e,t){if(!t)return tx(e);let n=[];for(let[e,r,i]of[[t.input,`↑`,`msg-meta__tokens`],[t.output,`↓`,`msg-meta__tokens`],[t.cacheRead,`R`,`msg-meta__cache`],[t.cacheWrite,`W`,`msg-meta__cache`]])e&&n.push(H`<span class=${i}>${r}${F(e)}</span>`);if(t.cost>0&&n.push(H`<span class="msg-meta__cost">${se(t.cost)}</span>`),t.contextPercent!==null){let e=t.contextPercent,r=e>=90?`msg-meta__ctx msg-meta__ctx--danger`:e>=75?`msg-meta__ctx msg-meta__ctx--warn`:`msg-meta__ctx`;n.push(H`<span class="${r}">${e}% ctx</span>`)}if(t.model){let e=t.model.includes(`/`)?t.model.split(`/`).pop():t.model;n.push(H`<span class="msg-meta__model">${e}</span>`)}return tx(e,n)}var ix;function ax(){return(ax=e((()=>{K(),R(),$r(),we(),di(),ix=6048e5})))()}function ox(e){return e.matches(`.agent-chat__composer-combobox > textarea`)&&typeof CSS<`u`&&CSS.supports(`field-sizing`,`content`)}function sx(e){let t=window.visualViewport?.offsetTop??0,n=e.getBoundingClientRect().top-t-Tx;e.style.setProperty(`--chat-composer-popover-max-height`,`${Math.max(0,n)}px`)}function cx(e){if(wx.has(e))return;let t=window.visualViewport,n={resizeObserver:null,toggleObserver:null,viewport:t,updateFrame:null,scheduleUpdate:()=>{n.updateFrame===null&&(n.updateFrame=requestAnimationFrame(()=>{n.updateFrame=null,wx.get(e)===n&&sx(e)}))}};typeof ResizeObserver==`function`&&(n.resizeObserver=new ResizeObserver(n.scheduleUpdate),n.resizeObserver.observe(e)),typeof MutationObserver==`function`&&(n.toggleObserver=new MutationObserver(n.scheduleUpdate),n.toggleObserver.observe(e,{attributes:!0,attributeFilter:[`open`],subtree:!0})),window.addEventListener(`resize`,n.scheduleUpdate),t?.addEventListener(`resize`,n.scheduleUpdate),t?.addEventListener(`scroll`,n.scheduleUpdate),wx.set(e,n),sx(e)}function lx(e){let t=wx.get(e);wx.delete(e),t&&(t.resizeObserver?.disconnect(),t.toggleObserver?.disconnect(),window.removeEventListener(`resize`,t.scheduleUpdate),t.viewport?.removeEventListener(`resize`,t.scheduleUpdate),t.viewport?.removeEventListener(`scroll`,t.scheduleUpdate),t.updateFrame!==null&&cancelAnimationFrame(t.updateFrame))}function ux(e,t){let n=t instanceof HTMLElement?t:null;return e&&e!==n&&lx(e),n&&cx(n),n}function dx(e,t){t.nativeInputPending=!0;let n=e.closest(`.chat`)?.querySelector(`.chat-thread`);n&&bf(n,{type:`composer-input`}),t.hasScrollbarGutter&&e.style.overflowY!==`hidden`&&(e.style.overflowY=`hidden`)}function fx(e){e.removeAttribute(`data-scroll-fade-top`),e.removeAttribute(`data-scroll-fade-bottom`);let t=Cx.get(e);t&&t.overflowFrame===null&&(t.overflowFrame=requestAnimationFrame(()=>{t.overflowFrame=null,e.isConnected&&Cx.get(e)===t&&px(e,!1)}))}function px(e,t=!0,n){if(t&&Cx.get(e)?.editing&&ox(e)){fx(e);return}let r=n?.clientHeight??e.clientHeight,i=n?.scrollHeight??e.scrollHeight,a=i>r+1,o=a&&r>=64&&!Cx.get(e)?.editing,s=o&&e.scrollTop>1,c=o&&e.scrollTop+r<i-1,l=a?`auto`:`hidden`;e.style.overflowY!==l&&(e.style.overflowY=l),e.toggleAttribute(`data-scroll-fade-top`,s),e.toggleAttribute(`data-scroll-fade-bottom`,c);let u=Cx.get(e);if(u){if(u.hasScrollbarGutter=!1,a&&ox(e)){let t=getComputedStyle(e);u.hasScrollbarGutter=e.offsetWidth-e.clientWidth>Number.parseFloat(t.borderLeftWidth)+Number.parseFloat(t.borderRightWidth)}let t=u.height!==r;if(u.height=r,u.nativeInputPending){u.nativeInputPending=!1;let n=e.closest(`.chat`)?.querySelector(`.chat-thread`);n&&bf(n,{type:`composer-layout`,changed:t})}}}function mx(e,t={}){if(e.closest(`[data-composer-layout="single-line"]`)){e.style.height=``,e.style.overflowY=``,e.removeAttribute(`data-scroll-fade-top`),e.removeAttribute(`data-scroll-fade-bottom`);return}let n=e.closest(`.chat`)?.querySelector(`.chat-thread`)??null,r=Cx.get(e);if(t.nativeInput&&r&&ox(e)){dx(e,r),e.style.height!==``&&(e.style.height=``),fx(e);return}n&&bf(n,{type:`before-resize`});let i=n?.clientHeight,a=n?Bd(n):null,o=getComputedStyle(e),s=o.maxHeight.trim(),c=/^(\d+(?:\.\d+)?)px$/u.exec(s),l=c?Number(c[1]):150,u=o.boxSizing===`border-box`,d=Number.parseFloat(o.lineHeight)*e.rows+(u?Number.parseFloat(o.paddingTop)+Number.parseFloat(o.paddingBottom):0),f=Math.max(Number.parseFloat(o.minHeight),Math.round(d)+(u?Number.parseFloat(o.borderTopWidth)+Number.parseFloat(o.borderBottomWidth):0)),p=/^(\d+(?:\.\d+)?)px$/u.exec(e.style.height);if(!p||Number(p[1])<=f||c&&Number(p[1])>=l){let t=Number.parseFloat(o.height),n=e.scrollHeight,r=e.clientHeight,i=n>r+1,a=!i&&t===f,s=i&&c&&t>=l&&e.offsetWidth-e.clientWidth<=Number.parseFloat(o.borderLeftWidth)+Number.parseFloat(o.borderRightWidth);if(a||s){px(e,!1,{scrollHeight:n,clientHeight:r});return}}e.style.overflowY=`hidden`,e.style.height=`auto`;let m=o.boxSizing===`border-box`?e.offsetHeight-e.clientHeight:0;if(e.style.height=`${Math.min(e.scrollHeight+m,l)}px`,px(e),n){a?.anchorToEnd&&(n.scrollTop=n.scrollHeight);let e=n.scrollTop;if(n.clientHeight===i&&e===a?.scrollTop)return;bf(n,{type:`resize`,...a?.anchorToEnd&&a.scrollTop!==e?{scrollCorrection:{before:a.scrollTop,after:e}}:{}})}}function hx(e){if(Cx.has(e))return;let t={observer:null,adjustmentFrame:null,overflowFrame:null,height:e.clientHeight,nativeInputPending:!1,hasScrollbarGutter:!1,editing:!1,events:new AbortController},n=e.getBoundingClientRect().width,r=()=>px(e,!1);t.observer=typeof ResizeObserver==`function`?new ResizeObserver(()=>{let r=e.getBoundingClientRect().width;if(r!==n){n=r,Cx.get(e)===t&&t.adjustmentFrame===null&&(t.adjustmentFrame=requestAnimationFrame(()=>{t.adjustmentFrame=null,Cx.get(e)===t&&mx(e)}));return}px(e,!1)}):null;let i=n=>{n instanceof KeyboardEvent&&(n.isComposing||!/^(ArrowUp|ArrowDown|ArrowLeft|ArrowRight|PageUp|PageDown|Home|End)$/u.test(n.key))||(t.editing=[`beforeinput`,`input`,`compositionstart`,`keydown`].includes(n.type),n.type===`beforeinput`&&ox(e)&&dx(e,t),px(e))},a={passive:!0,signal:t.events.signal};for(let t of[`beforeinput`,`input`,`compositionstart`,`wheel`,`pointerdown`,`keydown`,`blur`])e.addEventListener(t,i,a);e.addEventListener(`scroll`,r,a),Cx.set(e,t),t.observer?.observe(e),px(e)}function gx(e){let t=Cx.get(e);Cx.delete(e),t&&(t.observer?.disconnect(),t.events.abort(),t.adjustmentFrame!==null&&cancelAnimationFrame(t.adjustmentFrame),t.overflowFrame!==null&&cancelAnimationFrame(t.overflowFrame))}function _x(e){queueMicrotask(()=>{e.isConnected&&mx(e,{nativeInput:!0})})}function vx(e,t){if(e.defaultPrevented)return;let n=e.target;if(!(n instanceof Element))return;if(e.type===`pointerdown`){e.button===0&&n.closest(`summary, wa-dropdown>[slot='trigger']`)&&e.preventDefault();return}if(!t||e.composedPath().some(e=>e instanceof Element&&e.matches(Sx)))return;let r=e.currentTarget;r instanceof HTMLElement&&r.querySelector(`.agent-chat__composer-combobox > textarea`)?.focus({preventScroll:!0})}function yx(e,t){let n=t?.closest(`.agent-chat__composer-shell`);document.activeElement===t&&n&&e.preventDefault()}function bx(e,t){requestAnimationFrame(()=>{if(document.activeElement!==e)return;mx(e);let n=t===`up`?0:e.value.length;e.selectionStart=n,e.selectionEnd=n})}function xx(e,t){return`chat-${encodeURIComponent(e)}-${t}`}var Sx,Cx,wx,Tx;function Ex(){return(Ex=e((()=>{Jd(),xf(),Sx=[`a[href]`,`button`,`input`,`select`,`textarea`,`summary`,`wa-dropdown`,`[contenteditable='true']`,`[role='button']`,`[role='listbox']`,`[role='option']`].join(`,`),Cx=new WeakMap,wx=new WeakMap,Tx=28})))()}function Dx(e){return e?H`<div class="chat-question-panel__external">
        <a
          class="btn btn--sm"
          href=${e}
          target=${hs}
          rel=${wa()}
        >
          ${z.externalLink} ${L(`chat.questions.openLink`)}
        </a>
        <span class="muted">${L(`chat.questions.externalStepHint`)}</span>
      </div>`:G}function Ox(){return(Ox=e((()=>{K(),B(),R(),cs()})))()}function kx(e,t){let{onChange:n,onSubmit:r,onSkip:i}=t;return{model:{requestKey:e.id,title:L(`chat.questions.eyebrow`),questions:e.questions,agentId:e.agentId,sessionKey:e.sessionKey,secretStoreAllowedHostsDraft:e.secretStoreAllowedHostsDraft,collapsed:t.collapsed??!1,disabled:e.status!==`pending`,submitting:e.submitting,drafts:e.drafts,error:e.error,requestPosition:t.requestPosition},onChange:n,onSecretStoreAllowedHostsChange:t=>{e.secretStoreAllowedHostsDraft=t,n?.()},onSubmit:r?async t=>{if(await r(t),e.status===`pending`&&e.error)throw Error(e.error)}:void 0,onSkip:i?async()=>{if(await i(),e.status===`pending`&&e.error)throw Error(e.error)}:void 0,onDismissError:e.error&&n?()=>{e.error=null,n()}:void 0,onCollapsedChange:t.onCollapsedChange,onPreviousRequest:t.onPreviousRequest,onNextRequest:t.onNextRequest}}function Ax(e,t){return e.status===`cancelled`?L(`chat.questions.skipped`):e.status===`expired`?L(`chat.questions.expired`):e.status===`unavailable`?L(`chat.questions.unavailable`):t.isSecret?L(`chat.questions.answered`):e.answers?.answers[t.questionId]?.join(`, `)||(e.answeredElsewhere?L(`chat.questions.answeredElsewhere`):L(`chat.questions.answered`))}function jx(e){return e.status===`pending`?G:H`
    <div class="chat-question-summary" aria-label=${L(`chat.questions.summaryLabel`)}>
      ${e.questions.map(t=>H`
          <div class="chat-question-summary__item">
            <div class="chat-question-summary__prompt">${t.question}</div>
            <div class="chat-question-summary__line">
              <strong>${t.header}:</strong>
              <span>${Ax(e,t)}</span>
            </div>
          </div>
        `)}
    </div>
  `}var Mx;function Nx(){return(Nx=e((()=>{K(),ar(),B(),R(),we(),tt(),Ex(),Vm(),Ox(),Mx=class extends gt{constructor(...e){super(...e),this.currentQuestionIndex=0,this.pendingAction=null,this.requestKey=null,this.collapsed=!1,this.focusAfterUpdate=!1,this.answerTextarea=null,this.measuredAnswer=null}setCollapsed(e){if(this.props?.onCollapsedChange){this.props.onCollapsedChange(e);return}this.collapsed=e,this.focusAfterUpdate=!e,this.requestUpdate()}willUpdate(){let e=this.props?.model,t=e?.requestKey??null,n=e?.collapsed??!1;t===this.requestKey?this.props?.onCollapsedChange&&(this.collapsed&&!n&&(this.focusAfterUpdate=!0),this.collapsed=n):(this.requestKey=t,this.currentQuestionIndex=0,this.pendingAction=null,this.collapsed=n,this.focusAfterUpdate=!n&&e?.autoFocus!==!1)}disconnectedCallback(){super.disconnectedCallback(),this.answerTextarea&&=(gx(this.answerTextarea),null)}updated(){let e=this.querySelector(`.chat-question-panel__textarea`);this.answerTextarea!==e&&(this.answerTextarea&&gx(this.answerTextarea),this.answerTextarea=e,this.measuredAnswer=null,e&&hx(e)),e&&this.measuredAnswer!==e.value&&(mx(e),this.measuredAnswer=e.value),this.focusAfterUpdate&&!this.collapsed&&(this.focusAfterUpdate=!1,this.querySelector(`.chat-question-panel`)?.focus({preventScroll:!0}))}answerValues(e,t){return Lm(e.drafts.get(t.questionId),t.isSecret)}buildAnswers(e){return Object.fromEntries(e.questions.map(t=>[t.questionId,this.answerValues(e,t)]))}updateDraft(e,t,n){e.drafts.set(t.questionId,n),this.requestUpdate(),this.props?.onChange?.()}focusPanel(){this.updateComplete.then(()=>this.querySelector(`.chat-question-panel`)?.focus({preventScroll:!0}))}toggleOption(e,t,n,r=!0){let i=e.drafts.get(t.questionId),a=new Set(t.multiSelect?i?.selected:[]);t.multiSelect&&a.has(n)?a.delete(n):a.add(n),this.updateDraft(e,t,{selected:a,freeText:t.multiSelect?i?.freeText??``:``}),r&&!t.multiSelect&&this.currentQuestionIndex<e.questions.length-1&&(this.currentQuestionIndex+=1,this.focusPanel())}setFreeText(e,t,n){let r=e.drafts.get(t.questionId);this.updateDraft(e,t,{selected:!t.multiSelect&&(t.isSecret?n:n.trim())?new Set:r?.selected??new Set,freeText:n})}async resolve(e,t){if(e.disabled||e.submitting||this.pendingAction)return;let n;if(t===`submit`){let t=this.props?.onSubmit;if(!t||!e.questions.every(t=>this.answerValues(e,t).length>0))return;n=()=>t(this.buildAnswers(e))}else{let e=this.props?.onSkip;if(!e)return;n=e}let r={kind:t};this.pendingAction=r;try{await n()}catch{}finally{this.pendingAction===r&&(this.pendingAction=null)}}advanceOrSubmit(e,t){if(this.answerValues(e,t).length!==0){if(this.currentQuestionIndex<e.questions.length-1){this.currentQuestionIndex+=1,this.focusPanel();return}this.resolve(e,`submit`)}}goBack(){this.currentQuestionIndex!==0&&(--this.currentQuestionIndex,this.focusPanel())}handleKeyDown(e,t,n,r){if(r||e.isComposing||e.keyCode===229)return;if(e.target instanceof HTMLTextAreaElement){e.key===`Enter`&&(e.metaKey||e.ctrlKey)&&!e.altKey&&!e.shiftKey&&this.answerValues(t,n).length>0&&(e.preventDefault(),this.advanceOrSubmit(t,n));return}if(e.metaKey||e.ctrlKey||e.altKey||e.target instanceof HTMLAnchorElement)return;if(e.target instanceof HTMLInputElement){e.key===`Enter`&&this.answerValues(t,n).length>0&&(e.preventDefault(),this.advanceOrSubmit(t,n));return}if(e.target instanceof HTMLButtonElement&&e.target.getAttribute(`role`)===`radio`&&[`ArrowDown`,`ArrowLeft`,`ArrowRight`,`ArrowUp`,`End`,`Home`].includes(e.key)){e.preventDefault();let r=Number(e.target.dataset.optionIndex??`0`),i=n.options.length-1,a=e.key===`Home`?0:e.key===`End`?i:e.key===`ArrowLeft`||e.key===`ArrowUp`?(r-1+n.options.length)%n.options.length:(r+1)%n.options.length,o=n.options[a];if(!o)return;let s=this.currentQuestionIndex;this.toggleOption(t,n,o.label,!1),this.currentQuestionIndex===s&&this.updateComplete.then(()=>this.querySelector(`.chat-question-panel__option[data-option-index="${a}"]`)?.focus({preventScroll:!0}));return}let i=Number(e.key)-1;if(i>=0&&i<4&&n.options[i]){e.preventDefault(),this.toggleOption(t,n,n.options[i].label);return}if(n.options.length>0&&n.isOther&&i===n.options.length){e.preventDefault(),this.querySelector(`.chat-question-panel__other`)?.focus({preventScroll:!0});return}e.key===`Enter`&&!(e.target instanceof HTMLButtonElement)&&this.answerValues(t,n).length>0&&(e.preventDefault(),this.advanceOrSubmit(t,n))}render(){let e=this.props;if(!e)return G;let{model:t}=e,n=t.questions[this.currentQuestionIndex];if(!n)return G;let r=t.disabled||t.submitting||this.pendingAction!==null,i=this.currentQuestionIndex===t.questions.length-1,a=this.answerValues(t,n).length>0,o=t.drafts.get(n.questionId),s=`${this.currentQuestionIndex+1}/${t.questions.length}`,c=t.requestPosition?`${t.requestPosition.current}/${t.requestPosition.total}`:null,l=c?H`<div class="chat-question-panel__request-nav">
          <button
            type="button"
            aria-label=${L(`common.previous`)}
            @click=${e.onPreviousRequest}
          >
            ${z.chevronLeft}
          </button>
          <span>${c}</span>
          <button type="button" aria-label=${L(`common.next`)} @click=${e.onNextRequest}>
            ${z.chevronRight}
          </button>
        </div>`:G;return this.collapsed?H`
        <section
          class="chat-question-panel chat-question-panel--collapsed"
          aria-label=${t.title}
        >
          <button
            class="chat-question-panel__collapsed-button"
            type="button"
            @click=${()=>this.setCollapsed(!1)}
            aria-label=${L(`chat.questions.expand`)}
            aria-expanded="false"
          >
            <span
              ><strong>${t.title}</strong> ·
              ${t.collapsedLabel?H`${t.collapsedLabel} · ${n.question}`:n.header}</span
            >
            ${t.collapsedLabel?G:H`<span class="chat-question-panel__progress">${s}</span>`}
            <span class="chat-question-panel__chevron">${z.chevronDown}</span>
          </button>
          ${l}
        </section>
      `:H`
      <section
        class="chat-question-panel"
        role="group"
        aria-label=${t.title}
        tabindex="0"
        @keydown=${e=>this.handleKeyDown(e,t,n,r)}
      >
        <div class="chat-question-panel__topline">
          <div class="chat-question-panel__title">${t.title}</div>
          ${l}
          <span class="chat-question-panel__progress">${s}</span>
          <button
            class="chat-question-panel__collapse"
            type="button"
            @click=${()=>this.setCollapsed(!0)}
            aria-label=${L(`chat.questions.collapse`)}
            aria-expanded="true"
          >
            ${z.chevronDown}
          </button>
        </div>

        <div class="chat-question-panel__heading">
          <span class="chat-question-panel__prompt">${n.question}</span>
        </div>

        ${Dx(n.url)}
        ${Rm({question:n,selected:o?.selected??new Set,disabled:r,onSelect:e=>this.toggleOption(t,n,e)})}
        ${n.secretStore?H`
                <div class="chat-question-panel__store">
                  <div class="chat-question-panel__store-requester">
                    ${L(`chat.questions.storeRequestedBy`,{agent:t.agentId??L(`common.unknown`),session:t.sessionKey??L(`common.unknown`)})}
                  </div>
                  <div class="chat-question-panel__store-entry">
                    ${L(`chat.questions.storeEntry`,{name:n.secretStore.name,kind:n.secretStore.kind===`secret`?L(`secretsStore.protectedSecret`):L(`secretsStore.agentReadable`)})}
                  </div>
                  ${n.secretStore.reason?H`<div class="chat-question-panel__store-reason">
                          ${n.secretStore.reason}
                        </div>`:G}
                  ${n.secretStoreExisting?H`<div class="chat-question-panel__store-replacement">
                          ${n.secretStoreExisting.updatedBy?L(`chat.questions.storeReplacementBy`,{name:n.secretStore.name,updated:ge(n.secretStoreExisting.updatedAtMs),updatedBy:n.secretStoreExisting.updatedBy}):L(`chat.questions.storeReplacement`,{name:n.secretStore.name,updated:ge(n.secretStoreExisting.updatedAtMs)})}
                        </div>`:G}
                  ${n.secretStore.kind===`secret`?H`<label class="chat-question-panel__store-hosts">
                          <span>${L(`secretsStore.allowedHosts`)}</span>
                          <input
                            class="chat-question-panel__other chat-question-panel__hosts"
                            type="text"
                            autocomplete="off"
                            placeholder=${L(`secretsStore.allowedHostsPlaceholder`)}
                            .value=${t.secretStoreAllowedHostsDraft??n.secretStore.allowedHosts?.join(`, `)??``}
                            ?disabled=${r}
                            @input=${t=>{let n=t.target;n instanceof HTMLInputElement&&e.onSecretStoreAllowedHostsChange?.(n.value)}}
                          />
                        </label>`:G}
                </div>
              `:G}
        ${Bm({question:n,value:o?.freeText??``,selected:!!(n.isSecret?o?.freeText:o?.freeText.trim()),disabled:r,onInput:e=>this.setFreeText(t,n,e)})}

        <div class="chat-question-panel__footer">
          ${t.notice?H`<span class="chat-question-panel__error" role="status">${t.notice}</span>`:G}
          ${t.error?H`<span class="chat-question-panel__error" role="status">
                  ${L(`chat.questions.submitFailed`,{error:t.error})}
                  ${e.onDismissError?H`<button
                          type="button"
                          class="chat-question-panel__error-dismiss"
                          aria-label=${L(`chat.actions.dismissError`)}
                          @click=${e.onDismissError}
                        >
                          ${z.x}
                        </button>`:G}
                </span>`:G}
          ${this.currentQuestionIndex>0?H`<button
                  class="btn btn--sm chat-question-panel__back"
                  type="button"
                  ?disabled=${r}
                  @click=${()=>this.goBack()}
                >
                  ${L(`chat.questions.back`)}
                </button>`:G}
          ${e.onSkip?H`<button
                  class="btn btn--sm chat-question-panel__skip"
                  type="button"
                  ?disabled=${r}
                  @click=${()=>void this.resolve(t,`skip`)}
                >
                  ${this.pendingAction?.kind===`skip`?L(t.nonBlocking?`chat.asyncQuestions.dismissing`:`chat.questions.skipping`):L(t.nonBlocking?`chat.asyncQuestions.dismiss`:`chat.questions.skip`)}
                </button>`:G}
          <button
            class="btn btn--sm primary chat-question-panel__advance"
            type="button"
            ?disabled=${r||!a||!e.onSubmit}
            @click=${()=>this.advanceOrSubmit(t,n)}
          >
            ${this.pendingAction?.kind===`submit`||t.submitting?L(`chat.questions.submitting`):L(i?`chat.questions.submit`:`chat.questions.next`)}
          </button>
        </div>
      </section>
    `}},k([X({attribute:!1})],Mx.prototype,`props`,void 0),k([J()],Mx.prototype,`currentQuestionIndex`,void 0),k([J()],Mx.prototype,`pendingAction`,void 0),customElements.get(`openclaw-chat-question-panel`)||customElements.define(`openclaw-chat-question-panel`,Mx)})))()}function Px(e){let t=Lr(e);if(!t)return G;let n=L(`chat.messages.replyingTo`,{name:t});return H`<div class="chat-reply-attribution" title=${n} aria-label=${n}>
    <span class="chat-reply-attribution__icon" aria-hidden="true">${z.cornerDownLeft}</span>
    <span>${t}</span>
  </div>`}function Fx(){return(Fx=e((()=>{K(),B(),R(),qi()})))()}function Ix(e,t={}){if(t.eligible===!1)return``;let n=(ce(e)^(t.salt??Lx))>>>0;return n%1e3>=Rx?``:zx[Math.floor(n/1e3)%zx.length]??``}var Lx,Rx,zx;function Bx(){return(Bx=e((()=>{Lx=Math.trunc(Math.random()*4294967295),Rx=50,zx=[`chat-reading-indicator--southpaw`,`chat-reading-indicator--flurry`,`chat-reading-indicator--spin`,`chat-reading-indicator--shadowbox`,`chat-reading-indicator--backflip`,`chat-reading-indicator--zen`,`chat-reading-indicator--drummer`,`chat-reading-indicator--peekaboo`,`chat-reading-indicator--nodoff`,`chat-reading-indicator--curious`,`chat-reading-indicator--omnom`,`chat-reading-indicator--fakeout`]})))()}function Vx(e){let t=Math.max(1,Math.round(e/1e3)),n=dt.getLocale(),r=[];for(let{seconds:e,unit:i}of Gx){let a=Math.floor(t/e);if(a!==0&&(r.push(new Intl.NumberFormat(n,{style:`unit`,unit:i,unitDisplay:`long`}).format(a)),t-=a*e,r.length===2))break}return new Intl.ListFormat(n,{style:`long`,type:`unit`}).format(r)}function Hx(e){return e===1?L(`chat.turnRecap.tokensOne`):L(`chat.turnRecap.tokens`,{count:F(e)})}function Ux(e,t={}){let n=t.waitingApproval===!0,r=(t.mascot??vn().mascot)===`none`,i=t.presentation===`continuation`,a=n?L(`chat.waitingForApproval`):t.startupLabel||L(`common.working`),o=!n&&!t.startupLabel,s=t.outputTokens;return H`
    <div
      class="chat-working-indicator ${i?`chat-working-indicator--continuation`:``}"
      role="status"
      aria-live="off"
    >
      ${i?G:H`
              <div
                class="chat-bubble chat-reading-indicator ${r?`chat-reading-indicator--neutral`:Ix(e.key,{eligible:!n})}"
                aria-hidden="true"
              >
                ${r?H`<span></span><span></span><span></span>`:z.claw}
              </div>
            `}
      <span class="chat-working-indicator__status">
        <span class=${o&&!i?`sr-only`:``}>${a}</span>
        ${n?G:H`
                <openclaw-elapsed-time
                  class="chat-working-indicator__elapsed"
                  .startMs=${e.startedAt}
                ></openclaw-elapsed-time>
              `}
        ${s==null?o?H`
                  <openclaw-working-phrase
                    aria-hidden="true"
                    .startMs=${e.startedAt}
                    .seed=${e.key}
                    .phrases=${t.workingPhrases}
                  ></openclaw-working-phrase>
                `:G:H`
                <span aria-hidden="true">·</span>
                <span class="chat-working-indicator__tokens"
                  >${Hx(s)}</span
                >
              `}
      </span>
    </div>
  `}function Wx(e,t={}){let n=t.presentation===`continuation`,r=Vx(e.runtimeMs),i=typeof e.outputTokens==`number`?Hx(e.outputTokens):null;return H`
    <div
      class="chat-turn-recap ${n?`chat-turn-recap--continuation`:``}"
      role="status"
    >
      ${n?G:H`<span class="chat-turn-recap__claw" aria-hidden="true"
              >${vn().mascot===`none`?z.mark:z.claw}</span
            >`}
      <span>${L(`chat.turnRecap.doneIn`,{duration:r})}</span>
      ${i===null?G:H`
              <span class="chat-turn-recap__sep" aria-hidden="true">·</span>
              <span>${i}</span>
            `}
    </div>
  `}var Gx;function Kx(){return(Kx=e((()=>{K(),pc(),Rl(),B(),jn(),R(),we(),Bx(),Gx=[{seconds:86400,unit:`day`},{seconds:3600,unit:`hour`},{seconds:60,unit:`minute`},{seconds:1,unit:`second`}]})))()}function qx(e,t,n){return q(e,e=>`${e.kind}:${e.key}`,e=>Jx(e,t,n))}function Jx(e,t,n){if(e.kind===`reading-indicator`)return Ux(e,{mascot:t.branding?.mascot,workingPhrases:t.branding?.workingPhrases,waitingApproval:t.waitingApproval===!0,startupLabel:t.startupLabel,outputTokens:t.runOutputTokens,presentation:n});if(e.kind===`question`){let n=t.questionPrompts?.get(e.questionId);return n?jx(n):G}let r=ov({role:`assistant`,content:[{type:`text`,text:e.text}],timestamp:e.startedAt});return Yb(r,e.key,{...t,isStreaming:e.isStreaming,entryRef:t.entryRefFor?.(e.key),showReasoning:!1,messageActions:cv(r,{messageId:e.key,onReply:t.onReply,senderLabel:t.assistant?.name??`Assistant`})},t.onOpenSidebar)}function Yx(e,t={}){let{assistant:n}=t,r=n?.name??`Assistant`,i=e.flatMap(e=>e.kind===`stream`?[e.startedAt]:[]),a=i.length>0?Math.min(...i):null,o=e.some(e=>e.kind===`reading-indicator`||e.kind===`stream`&&e.isStreaming),s=e.every(e=>e.kind!==`stream`),c=s||t.showAssistantAvatar===!1?G:ou(`assistant`,n);return H`
    <div class=${`chat-group assistant${s?` chat-group--working`:``}${a===null?``:` chat-group--with-footer`}`} data-chat-row-key=${e[0]?.key??G}>
      ${c}
      <div class="chat-group-messages">
        ${Px(e.find(e=>e.kind===`stream`)?.replyToSender)}
        ${qx(e,t,`standalone`)}
      </div>
      ${a===null?G:o?Zx:H`
                <div class="chat-group-footer">
                  <div class="chat-group-footer__meta">
                    <span class="chat-sender-name">${r}</span>
                    ${tx(a)}
                  </div>
                </div>
              `}
    </div>
  `}function Xx(e,t){let n=si(e.durationMs),r=e.groups.flatMap(e=>e.messages.map(({message:e})=>({cards:fo(e),activity:Array.isArray(i(e)?.activity)?Ri(e):void 0}))),a=r.flatMap(({cards:e,activity:t})=>t===void 0?[]:[{cards:e,activity:t}]),o=new Set(a.flatMap(({cards:e,activity:t})=>[...e.flatMap(e=>e.callId?[e.callId]:[]),...t.map(e=>e.toolCallId??e.itemId)])),s=[...new Map(r.flatMap(e=>e.cards).map(e=>[e.callId??e,e])).values()],c=new Set(r.filter(e=>e.activity===void 0).flatMap(e=>e.cards)),l=s.filter(e=>c.has(e)&&(!e.callId||!o.has(e.callId))),u=a.flatMap(e=>e.activity);for(let[e,t]of l.entries()){let n=vs(t,!1);u.push({itemId:`work-summary-raw:${e}`,toolCallId:t.callId,kind:`tool`,phase:`end`,title:t.name,name:t.name,status:n===`succeeded`?`completed`:n===`unknown`?void 0:n})}let d=n?L(`chat.workRun.workedFor`,{duration:n}):L(`chat.workRun.worked`),f=Ea(u),p=f.total,m=f.outcomes.filter(({kind:e})=>e!==`failed`&&e!==`skipped`),h=Ty(s,!0,u),g=H`
    <div class="chat-activity-group chat-work-group ${t.expanded?`is-open`:``}">
      <button
        class="chat-inline-disclosure chat-activity-group__summary"
        type="button"
        aria-expanded=${String(t.expanded)}
        @pointerenter=${Eb}
        @focus=${Eb}
        @click=${t.onToggle}
      >
        <span class="chat-tool-disclosure__content">
          <span class="chat-activity-group__label">${d}</span>
        </span>
        ${p>0?H`<span class="chat-work-group__total"
                >·
                ${L(`chat.workRun.toolCalls${p===1?`One`:`Many`}`,{count:String(p)})}</span
              >`:G}
        ${m.map(e=>H`<span class="muted">· ${e.label}</span>`)}
        ${h===G?G:H`<span class="chat-work-group__outcomes">· ${h}</span>`}
        <span class="chat-tool-row__chevron" aria-hidden="true">${z.chevronRight}</span>
      </button>
      <div class="chat-work-group__separator" aria-hidden="true"></div>
      ${t.expanded?G:t.browserTabPreviews??G}
    </div>
  `;return t.presentation===`continuation`?g:H`
        <div
          class="chat-group tool chat-group--turn-block chat-group--work"
          data-chat-row-key=${e.key}
        >
          <div class="chat-group-messages">${g}</div>
        </div>
      `}var Zx;function Qx(){return(Qx=e((()=>{K(),ur(),B(),R(),us(),vo(),ta(),Su(),Xb(),dv(),ax(),Nx(),Fx(),Bb(),Ey(),Kx(),Zx=H`<div class="chat-group-footer" aria-hidden="true"></div>`})))()}function $x(e,t,n){let r=ov(t.message),i=cv(r,{...n,messageId:t.key,canFetchFullMessage:!!(n.loadFullAssistantMessage&&n.sessionKey),senderLabel:iS(e,n)}),a=i?.fullMessage?.messageId;if(a){let e=n.getAssistantMessageExpansion?.(a);(!e||e.status===`error`&&e.revision<6)&&n.onToggleAssistantMessageExpanded?.(a)}return{item:t,source:r,actions:i}}function eS(e,t,n,{item:r,source:i,actions:a}){let o,s=a?.fullMessage;if(s&&n.loadFullAssistantMessage&&n.onToggleAssistantMessageExpanded){let{messageId:e,state:t}=s,r=t?.status===`error`&&t.revision>=6;o={expanded:t?.status===`loaded`,...t?.status===`loaded`?{markdown:a?.markdown,message:t.message}:{},...r?{onRetryFullMessage:()=>n.onToggleAssistantMessageExpanded?.(e)}:{}}}return Yb(i,r.key,{...n,isStreaming:e.isStreaming&&t===e.messages.length-1,entryId:td(r.message)??void 0,entryRef:n.entryRefFor?.(r.key),duplicateCount:r.duplicateCount??1,showToolCalls:n.showToolCalls??!0,autoExpandToolCalls:n.autoExpandToolCalls??!1,assistantMessageDisclosure:o,messageActions:a},n.onOpenSidebar)}function tS(e,t){let n=e.sender?.identity;return n?.type===`profile`&&n.id===t}function nS(e,t,n=`standalone`){let r=e[0];if(!r||t.showToolCalls===!1)return G;let i=e.flatMap(e=>e.messages),a=[],o=new Map,s=new Map,c=new Set,l=i.flatMap(n=>{let r=Ri(n.message);t.runActive&&t.activityRunId&&(!t.activityGroupKey||e.some(e=>e.key===t.activityGroupKey))&&eu(n.message)===t.activityRunId&&r.forEach(e=>c.add(e));let i=new Map(r.map(e=>[e.toolCallId,e]));for(let[e,t]of fo(n.message).entries()){a.push(t),o.set(t,{messageKey:n.key,disclosureId:`${n.key}:toolcard:${e}`});let r=t.callId?i.get(t.callId):void 0;r&&s.set(t,r)}return r}).filter(e=>!e.hideFromChannelProgress&&!e.suppressChannelProgress),u=[...new Map(l.filter(e=>c.has(e)).map(e=>[e.toolCallId??e.itemId,e])).values()],d=Et(a),f=Cm(u,d,s),p=new Set(l.map(e=>e.toolCallId??e.itemId)),m=`activity:${r.key}`,h=`activity-body-${ce(r.key).toString(16)}`,g=t.isToolMessageExpanded?.(m)??!1,_=Hr(l,{includeInlineOutcomes:g}),v=new Map;function y(e){let{card:n,children:r}=e,i=o.get(n),a=t.isToolExpanded?.(i.disclosureId)??!1,s=[],c=[...r];for(let e of c)s.push(e.card),c.push(...e.children),v.set(e.card,G);return Fb(n,{...t,messageKey:i.messageKey,expanded:a,onToggleExpanded:()=>t.onToggleToolExpanded?.(i.disclosureId,a),activityCards:[n,...s],children:r.length?H`${a?r.map(y):G}`:void 0})}if(g)for(let e of d)e.children.length>0&&v.set(e.card,y(e));let b=a.flatMap(e=>Ki(e.details)),x=a.flatMap(e=>{let t=ti(e.details);return t?[t]:[]}),S=Qi(b,x),C=b[0]?.label??`Review`,w=S?L(`chat.toolCards.review.${S===`reviewing`?`reviewing`:S}`,{reviewer:C}):``,T=H`
    <div class="chat-activity-group ${g?`is-open`:``}">
      <button
        class="chat-inline-disclosure chat-activity-group__summary"
        type="button"
        aria-expanded=${String(g)}
        aria-controls=${h}
        @pointerenter=${Eb}
        @focus=${Eb}
        @click=${()=>t.onToggleToolMessageExpanded?.(m,g)}
      >
        <span class="chat-activity-group__icon">${z.listTree}</span>
        <span class="chat-tool-disclosure__content">
          ${Em(JSON.stringify([t.sessionKey,t.connectionEpoch,t.activityRunId]),f,_,u)}
        </span>
        ${f?Ea(l).outcomes.filter(({kind:e})=>e!==`failed`&&e!==`skipped`).map(({label:e})=>H`<span class="muted">${e}</span>`):G}
        ${S?H`<span
                class="chat-activity-group__review-status"
                data-outcome=${S}
                role="img"
                aria-label=${w}
                >${S===`denied`?z.shieldX:S===`reviewing`?z.shieldQuestion:z.shieldCheck}</span
              >`:G}
        ${g?G:Ty(a.filter(e=>e.callId&&p.has(e.callId)),!0,l)}
        <span class="chat-tool-row__chevron" aria-hidden="true">${z.chevronRight}</span>
      </button>
      <div class="chat-activity-group__body" id=${h} ?hidden=${!g}>
        ${g?e.map(e=>e.messages.map((n,r)=>eS(e,r,{...t,toolCardOverrides:v},$x(e,n,t)))):G}
      </div>
      ${bb(e,t)}
    </div>
  `;return n===`continuation`?T:H`
        <div
          class="chat-group tool chat-group--turn-block chat-group--activity chat-group--with-footer"
          data-chat-row-key=${r.key}
        >
          <div class="chat-group-messages">${T}</div>
        </div>
      `}function rS(e){return Fi(e.role)===`user`&&!!e.sourceClients?.length&&!e.sender&&!e.senderLabel?.trim()}function iS(e,t){let n=Fi(e.role);if(rS(e))return Po(e.sourceClients??[]);if(n===`custom`){if(e.messages.every(({message:e})=>{let t=m(e)?.customType;return t===`run-failed-before-reply`||t===`cloud-workspace-recovery-failed`})){let t=e.messages.every(({message:e})=>{let t=m(e);return t?.customType===`run-failed-before-reply`&&m(t.details)?.errorKind===`state_contention`});return L(t?`common.system`:`chat.messages.errorSender`)}return e.messages.every(({message:e})=>sf(e))?L(`chat.workspaceConflict.eventSender`):L(`common.system`)}let r=Lt({name:t.userName}),i=e.senderLabel?.trim();return n===`user`?tS(e,t.userId)?r:i??L(`chat.messages.unattributedSender`):n===`assistant`?i??t.assistantName??`Assistant`:n===`tool`?L(`chat.messages.toolSender`):n}function aS(e){if(Fi(e.role)!==`tool`)return!1;let t=e.messages.flatMap(e=>fo(e.message));return e.messages.length>1||t.length>1||t.some(e=>Ki(e.details).length>0)}function oS(e,t){if(aS(e))return nS([e],t,`continuation`);let n={...t,isForwarded:Hu(e)},r=q(e.messages,e=>e.key,(r,i)=>eS(e,i,n,$x(e,r,t)));return H`${r}${t.showToolCalls===!1?G:bb([e],t)}`}function sS(e,t){let n=Fi(e.role),r=rS(e),i=n!==`user`||!!(e.sender||e.senderLabel?.trim()),a=t.assistantName??`Assistant`,o=tS(e,t.userId),s=n===`user`&&!!(t.userId&&e.sender)&&!o,c=Hu(e),l=n===`assistant`&&c,u=!l&&!r&&(n!==`user`||!o||t.showOwnSenderName!==!1),d=e.sourceClients?.filter(e=>ci(e)!==`web`),f=e.senderSession?.sessionKey,p=iS(e,t),m=n===`user`||n===`assistant`||n===`tool`?n:e.messages.every(e=>sf(e.message))?`workspace-conflict`:`other`,h=t.avatarPlacement??`gutter`,g=nx(e,t.contextWindow??null);if(n===`tool`&&t.showToolCalls===!1)return G;if(aS(e))return nS([e],t);let _=t.frameContent!==void 0,v=n===`tool`||n===`assistant`&&!t.searchResult&&!_&&!l&&tu(e.messages[0]?.message)===`commentary`,y=(_?t.frameActionOwner?[t.frameActionOwner]:[]:e.messages).map(n=>$x(e,n,t)),b=e.messages.length-1,x=_?y[0]?.actions??null:y[b]?.actions??null,S=_?t.frameActionOwner?.key:e.messages[b]?.key,C=n===`user`&&(x?.replyTarget&&t.onReply||t.onRewind&&!t.rewindDisabled||x?.markdown)?H`
        <div
          class="chat-group-footer-actions"
          data-message-actions-for=${S??G}
        >
          ${x?.replyTarget&&t.onReply?uv(x.replyTarget,t.onReply):G}
          ${t.onRewind&&!t.rewindDisabled?om(t.onRewind):G}
          ${x?.markdown?lv(x,{}):G}
        </div>
      `:G,w=l&&f?Ko({id:f}):n===`user`&&e.sender?Ko(e.sender):null,T=Yu(e.messages.at(-1)?.message),E=n===`user`&&h===`gutter`&&!!y[b]?.source.displayMarkdown,D=i&&!v&&h===`gutter`&&(l||n!==`assistant`||t.showAssistantAvatar!==!1)?l?au(e.senderSession?.agentId,t):ou(e.role,{agentId:t.agentId,name:a,avatar:t.assistantAvatar??null,textAvatar:t.assistantTextAvatar},o?{name:t.userName??null,avatar:t.userAvatar??null}:void 0,e.sender):G;return H`
    <div
      class="chat-group ${m} chat-group--with-footer${v?` chat-group--turn-block`:``}${t.latestAssistant?` chat-group--latest-assistant`:``}${s?` chat-group--peer`:``}${l?` chat-group--forwarded`:``}${w===null?``:` chat-group--sender-tint`}"
      style=${w===null?G:`--chat-sender-hue: ${w}`}
      data-chat-row-key=${e.key}
    >
      ${E?G:D}
      <div class="chat-group-messages">
        ${c?Om(e,t):G}
        ${n===`assistant`?Px(e.replyToSender):G}
        ${t.frameContent??q(y,e=>e.item.key,(n,r)=>{let{item:i,actions:a}=n;return H`
                ${eS(e,r,{...t,isForwarded:c,avatar:E&&r===b?D:void 0},n)}
                ${a&&(a.markdown||a.replyTarget&&t.onReply)&&r<b&&!v?H`
                        <div class="chat-message-actions-row" data-message-actions-for=${i.key}>
                          ${lv(a,t)}
                        </div>
                      `:G}
              `})}
        ${_||t.showToolCalls===!1?G:bb([e],t)}
        ${t.activeContinuation?qx(t.activeContinuation.parts,t.activeContinuation.options,`continuation`):t.turnRecap?Wx(t.turnRecap,{presentation:`continuation`}):G}
      </div>
      ${v?G:e.isStreaming||t.activeContinuation?Zx:H`<div
                class="chat-group-footer ${n===`user`&&(d?.length||s||u&&h!==`footer`)?`chat-group-footer--persistent-identity`:``}${T?` chat-group-footer--send-status`:``}"
              >
                ${s?G:C}
                <div class="chat-group-footer__meta">
                  ${n===`user`&&i&&h===`footer`?ym(e.sender):G}
                  ${u?gl(p,s&&e.sender?.identity?.type===`profile`?El(e.sender.identity.id,t.personActivity,p):null,`chat-sender-name`):G}
                  ${d?.length?H`<span class="chat-message-source"
                          >${Po(d)}</span
                        >`:G}
                  ${Zb(T,t)}
                  ${rx(e.timestamp,g)}
                </div>
                ${s?C:n!==`user`&&x?H`
                          <div
                            class="chat-group-footer-actions"
                            data-message-actions-for=${S??G}
                          >
                            ${lv(x,t)}
                          </div>
                        `:G}
              </div>`}
    </div>
  `}function cS(){return(cS=e((()=>{K(),ur(),In(),B(),Hc(),R(),pi(),Zr(),Ji(),us(),vo(),oa(),ji(),Vu(),Su(),wu(),rd(),ad(),Id(),Dm(),Sm(),km(),Xb(),gm(),dv(),Qb(),Qx(),ax(),Fx(),Bb(),Ey(),Kx()})))()}function lS(){return(lS=e((()=>{V(),Qp(),gm(),cS(),Qx()})))()}function uS(e){return typeof e==`string`?e:e instanceof Error&&typeof e.message==`string`?e.message:`unknown error`}function dS(e){let t=uS(e.message),n=b(t),r=_(e.details),i=w(t),a=r?.reason??i?.reason;if(n.startsWith(`pairing required:`)&&a)return`gateway pairing required: ${te(a)}`;if(i&&n!==`pairing required`)return t;let o=r?.approvedRoles?.join(`, `)??`none`,s=r?.requestedRole??`none`,c=r?.approvedScopes?.join(`, `)??`none`,l=r?.requestedScopes?.join(`, `)??`none`;switch(r?.reason){case`scope-upgrade`:return r.approvedScopes||r.requestedScopes?`device scope upgrade requires approval (approved: ${c}; requested: ${l})`:S(e.details);case`role-upgrade`:return r.approvedRoles||r.requestedRole?`device role upgrade requires approval (approved: ${o}; requested: ${s})`:S(e.details);case`metadata-upgrade`:return`device reconnect details changed and require approval`;default:return`gateway pairing required`}}function fS(e){let t=uS(e.message);switch(Tn(e)){case D.AUTH_TOKEN_MISMATCH:return`gateway token mismatch`;case D.AUTH_UNAUTHORIZED:return`gateway auth failed`;case D.AUTH_RATE_LIMITED:return`too many failed authentication attempts`;case D.PAIRING_REQUIRED:return dS(e);case D.CONTROL_UI_DEVICE_IDENTITY_REQUIRED:return`device identity required (use HTTPS or localhost)`;case D.CONTROL_UI_ORIGIN_NOT_ALLOWED:return`origin not allowed (open the Control UI from the gateway host or allow it in gateway.controlUi.allowedOrigins)`;case D.AUTH_TOKEN_MISSING:return`gateway token missing`}let n=b(t);return n===`fetch failed`||n===`failed to fetch`||n===`connect failed`?`gateway connect failed`:t}function pS(e){let t=e&&typeof e==`object`?fS(e):uS(e);return N(t)}function mS(){return(mS=e((()=>{O(),mn(),ft()})))()}function hS(e,t=`pasted-image`){let n=e.trim(),r=/^data:(image\/[a-z0-9.+-]+);base64,/i.exec(n),i=r?.[1]?.toLowerCase(),a=r?n.slice(r[0].length).replace(/\s+/g,``):void 0;if(!i||!a)return null;try{let e=atob(a),n=new Uint8Array(e.length);for(let t=0;t<e.length;t++)n[t]=e.charCodeAt(t);return{file:new File([n],`${t}.${i.slice(6)}`,{type:i}),dataUrl:`data:${i};base64,${a}`}}catch{return null}}function gS(e){return e.type===`image/png`}async function _S(e,t){let n=new DataView(await e.slice(0,33).arrayBuffer());if(t.throwIfAborted(),n.byteLength!==33||n.getUint32(0)!==2303741511||n.getUint32(4)!==218765834||n.getUint32(8)!==13||n.getUint32(12)!==1229472850)throw Error(`Invalid PNG header`);let r=n.getUint32(16),i=n.getUint32(20);if(r===0||i===0||r*i>25e6)throw Error(`PNG dimensions exceed the resize budget`);for(let n=33;n+12<=e.size;){t.throwIfAborted();let r=new DataView(await e.slice(n,n+8).arrayBuffer());t.throwIfAborted();let i=r.getUint32(0),a=r.getUint32(4);if(i>e.size-n-12||a===1229472850)break;if(a===1633899596)throw Error(`Animated PNG cannot be resized without losing animation`);if(a===1229209940)return;n+=i+12}throw Error(`PNG image data is missing`)}async function vS(e,t,n,r){n.throwIfAborted(),await _S(e,n),r(!1);let i=yS.then(()=>(n.throwIfAborted(),r(!0),new Promise((r,i)=>{let a=new Worker(new URL(new URL(`chat-attachment-image.worker-P4E63gj9.js`,import.meta.url).href,``+import.meta.url),{type:`module`}),o=!1,s=e=>{o||(o=!0,a.terminate(),n.removeEventListener(`abort`,c),e&&!n.aborted?r(e):i(n.aborted?new DOMException(`Image preparation aborted`,`AbortError`):Error(`Image preparation failed`)))},c=()=>s(null);n.addEventListener(`abort`,c,{once:!0}),a.addEventListener(`message`,({data:e})=>s(e),{once:!0}),a.addEventListener(`error`,e=>{e.preventDefault(),s(null)},{once:!0}),a.addEventListener(`messageerror`,()=>s(null),{once:!0});try{a.postMessage({file:e,maxBytes:t},[])}catch{s(null)}})));return yS=i.then(()=>{},()=>{}),i}var yS;function bS(){return(bS=e((()=>{yS=Promise.resolve()})))()}function xS(e){if(!e?.attachments)return;let t=AS.get(e);return t||(t={...e.attachments,maxBatchBytes:yd(e.maxPayload??1/0)},AS.set(e,t)),t}function SS(e,t){return L(e,{names:t.slice(0,3).map(e=>e.trim()?e:L(`chat.attachments.attachedFile`)).join(`, `),more:t.length>3?` +${t.length-3}`:``})}function CS(e,t){t.length!==0&&I({message:SS(e,t.map(e=>e.name))})}function wS(e,t,n,r={}){let i=[],a=[],o=[],s=n;for(let n of e){let e=TS(n.size,n.type,t);n.size===0?a.push(n):t&&(n.size>e&&!(r.resizeImages&&gS(n))||s+e>t.maxBatchBytes)?o.push(n):(i.push(n),s+=e)}return CS(`chat.attachments.readFailed`,a),CS(`chat.attachments.tooLarge`,o),i}function TS(e,t,n){let r=t.startsWith(`image/`)?n?.maxImageBytes:n?.maxBytes;return Math.min(e,r??1/0)}function ES(e){let t=e.sizeBytes;if(typeof t==`number`&&Number.isFinite(t)&&t>=0)return t;let n=fu(e)?.match(/^data:[^,]*;base64,([\s\S]*)$/i)?.[1]?.replace(/\s/g,``);return n?Math.max(0,Math.floor(n.length*3/4)-(n.match(/=+$/)?.[0].length??0)):0}function DS(e){return e.reduce((e,t)=>e+ES(t),0)}function OS(e,t){if(!t)return[];let n=0;return e.filter(e=>{let r=ES(e);return r>(e.mimeType.startsWith(`image/`)?t.maxImageBytes:t.maxBytes)||n+r>t.maxBatchBytes||(n+=r,!1)})}function kS(e,t){let n=OS(e,xS(t));return n.length>0?SS(`chat.attachments.tooLarge`,n.map(e=>e.fileName??``)):void 0}var AS;function jS(){return(jS=e((()=>{fd(),R(),Oe(),cu(),bS(),AS=new WeakMap})))()}function MS(e){let t=ee(e.sessionKey)?.toLowerCase(),n=t===`global`?null:nt(e.sessionKey),r=We(e,e.sessionKey).agentId,i=u(e.assistantAgentId??e.agentsList?.defaultId??e.agentsList?.agents?.[0]?.id??`main`);return t===`global`?r??i:n??r??i}function NS(e){e?.browserSearchTimer&&(globalThis.clearTimeout(e.browserSearchTimer),e.browserSearchTimer=null)}function PS(e){NS(e.sessionWorkspaceState)}function FS(e){XS.add(e)}function IS(e,t){FS(t),e.handleOpenSidebar(t)}function LS(e){e.sidebarContent&&XS.has(e.sidebarContent)&&(e.sidebarContent=null)}function RS(e,t){return{previews:[],activePreviewId:null,activeId:null,agentId:MS(e),browserPath:``,browserSearch:``,filter:`all`,browserSearchTimer:null,collapsed:t?.collapsed??!0,connectionEpoch:e.connectionEpoch,dock:t?.dock??cn(e.settings?.chatWorkspaceDock),error:null,list:null,loading:!1,pendingReload:!1,sessionKey:e.sessionKey}}function zS(e,t){return e.sessionWorkspaceState===t&&t.sessionKey===e.sessionKey&&t.agentId===MS(e)&&t.connectionEpoch===e.connectionEpoch}function BS(e){let t=e.sessionWorkspaceState;if(t&&zS(e,t))return t;LS(e),NS(t);let n=RS(e,t);return e.sessionWorkspaceState=n,n}function VS(e,t,n){e.error=t,e.errorOwner=n}function HS(e,t){e.errorOwner===t&&VS(e,null)}function US(e,t,n=!1){if(!e.client||!e.connected)return;if(t.loading){n&&(t.pendingReload=!0);return}t.loading=!0,VS(t,null),n&&(t.list=null),t.pendingReload=!1;let r=e.sessionKey,i=t.agentId,a=e.client,o=t.browserPath,s=t.browserSearch,c=()=>zS(e,t)&&t.browserPath===o&&t.browserSearch===s;(async()=>{try{let[n,l]=await Promise.all([e.sessions.listFiles(r,{path:s?``:o,search:s,agentId:i}),a.request(`artifacts.list`,{sessionKey:r,...i?{agentId:i}:{}})]);if(!c())return;let u=n?.files??[],d=l?.artifacts??[];t.list={sessionKey:r,...n?.root?{root:n.root}:{},...typeof n?.gitCheckout==`boolean`?{gitCheckout:n.gitCheckout}:{},files:u,...n?.browser?{browser:n.browser}:{},artifacts:d}}catch(e){c()&&VS(t,N(e))}finally{zS(e,t)&&(t.loading=!1),e.requestUpdate?.()}})()}function WS(e,t){let n=e.sessionWorkspaceState;if(!n||n.sessionKey!==e.sessionKey)return!1;let r=n.diffContent!==void 0&&e.sidebarContent===n.diffContent;return delete n.diffContent,t?(n.loading?n.pendingReload=!0:US(e,n),r):(n.pendingReload=!0,r)}function GS(e){let t=e.sessionWorkspaceState;t&&t.sessionKey===e.sessionKey&&(LS(e),NS(t),e.sessionWorkspaceState=RS(e,t),e.requestUpdate?.())}function KS(e,t,n,r){let i=BS(e),a=i.previews.find(e=>e.id===t||e.requestIds?.includes(t));return a||(a={id:t,label:n,content:r},i.previews=[...i.previews,a]),i.activePreviewId=a.id,e.requestUpdate?.(),a}function qS(e,t){let n=BS(e);(t===null||n.previews.some(e=>e.id===t))&&(n.activePreviewId=t,e.requestUpdate?.())}function JS(e,t){let n=BS(e),r=n.previews.findIndex(e=>e.id===t);r<0||(n.previews=n.previews.filter(e=>e.id!==t),n.activePreviewId===t&&(n.activePreviewId=n.previews[Math.min(r,n.previews.length-1)]?.id??null),e.requestUpdate?.())}function YS(e){let t=e.sessionWorkspaceState;t&&(t.previews=[],t.activePreviewId=null,e.requestUpdate?.())}var XS;function ZS(){return(ZS=e((()=>{hn(),ft(),Ve(),it(),XS=new WeakSet})))()}function QS(e){return kn(void 0,t=>{let{render:n,finish:r}=t,i=[...e],a=``,o,s=e=>t.settled?!1:!i.includes(e)||!e.isCurrent()?(a=L(`chat.detailPanel.draftRecovery.changed`),n(c),!1):!0,c=()=>H`
      <openclaw-modal-dialog
        label=${L(`chat.detailPanel.draftRecovery.review`)}
        description=${L(`chat.detailPanel.draftRecovery.description`)}
        @modal-cancel=${()=>r()}
      >
        <section class="exec-approval-card exec-approval-modal-stack">
          <div class="exec-approval-header">
            <div>
              <div class="exec-approval-title">${L(`chat.detailPanel.draftRecovery.review`)}</div>
              <div class="exec-approval-sub">
                ${L(`chat.detailPanel.draftRecovery.description`)}
              </div>
            </div>
          </div>
          ${i.map(e=>H`
              <section
                role="group"
                style="overflow-wrap: anywhere"
                aria-label=${[e.path,e.context?.sessionTitle,e.context?.paneLabel,e.context?.sessionKey].filter(Boolean).join(` — `)}
              >
                ${e.context?H`
                        <div class="exec-approval-title">${e.context.sessionTitle}</div>
                        <div class="exec-approval-sub">${e.context.paneLabel}</div>
                        <div class="exec-approval-sub">${e.context.sessionKey}</div>
                      `:G}
                <label class="field">
                  <span>${e.path}</span>
                  <textarea readonly rows="6" .value=${e.content}></textarea>
                </label>
                <div class="exec-approval-actions">
                  <button
                    type="button"
                    class="btn"
                    @click=${async()=>{if(!s(e))return;let t=await et(e.content,()=>s(e));s(e)&&(o=t?e:void 0,a=t?``:L(`chat.detailPanel.draftRecovery.copyFailed`),n(c))}}
                  >
                    ${o===e?L(`common.copied`):L(`chat.detailPanel.draftRecovery.copy`,{name:e.name})}
                  </button>
                  <button
                    type="button"
                    class="btn"
                    @click=${()=>{s(e)&&ma(e.name,e.content)}}
                  >
                    ${L(`chat.detailPanel.draftRecovery.download`,{name:e.name})}
                  </button>
                  <button
                    type="button"
                    class="btn danger"
                    @click=${()=>{s(e)&&e.discard()&&(i=i.filter(t=>t!==e),a=``,i.length?n(c):r())}}
                  >
                    ${L(`chat.detailPanel.draftRecovery.discard`,{name:e.name})}
                  </button>
                </div>
              </section>
            `)}
          ${a?H`<p role="alert">${a}</p>`:G}
          <div class="exec-approval-actions">
            <button type="button" class="btn" autofocus @click=${()=>r()}>
              ${L(`chat.detailPanel.draftRecovery.keep`)}
            </button>
          </div>
        </section>
      </openclaw-modal-dialog>
    `;n(c)})}function $S(){return($S=e((()=>{K(),wn(),R(),gs(),xt(),Ta()})))()}async function eC(){if(!(cC||oC.size===0)){cC=!0;try{await QS([...oC].map(([e,t])=>({name:t.name,path:t.path,context:t.context,content:t.draft.content,isCurrent:()=>oC.get(e)===t,discard:()=>oC.get(e)===t&&(oC.delete(e),aC(),!0)})))}finally{cC=!1}}}function tC(e){return e.draftKey??`${e.root??``}\u0000${e.path}`}function nC(e){return oC.get(tC(e))?.draft}function rC(e,t){if(!t.editing)return null;let{dirty:n}=t,r=n?t.expectedHash:e.edit?.hash??``;return iC(e,n?{content:t.content,expectedHash:r}:null),{dirty:n,expectedHash:r}}function iC(e,t){let n=tC(e);oC.delete(n),t&&oC.set(n,{draft:t,name:e.name,path:e.path,context:e.draftContext}),aC()}function aC(){oC.size>0?sC??=Pt(()=>oC.size===0,()=>I({message:L(`chat.detailPanel.reloadBlocked`),actionLabel:L(`chat.detailPanel.draftRecovery.review`),onAction:()=>void eC()})):(sC?.(),sC=void 0)}var oC,sC,cC;function lC(){return(lC=e((()=>{Vn(),R(),gs(),Oe(),$S(),Ta(),oC=new Map,cC=!1})))()}function uC(e,t,n,r,i,a,o){if(!e.client||!e.connected)return;let s={kind:`loading`,fileTab:{id:n,label:o.label}},c=KS(e,n,s.fileTab.label,s),l=c.canonicalKey??n;t.activeId=l,o.line!=null&&(c.navigation={line:o.line},t.navigationOrder=(t.navigationOrder??0)+1,c.navigationOrder=t.navigationOrder,c.content.kind===`file`&&(c.content.navigation=c.navigation),t.previews=[...t.previews]),c.content.kind===`unavailable`&&(c.content=s,t.previews=[...t.previews]),e.handleOpenSidebar(s);let u=c.content;if(u!==s&&(!o.revalidate||u.kind===`loading`||u.kind===`file`&&nC(u)))return;let d={order:++hC};mC.set(c,d);let f=dC(c),p=new Map(t.previews.map(e=>{let t=mC.get(e);return[e,{snapshot:dC(e),read:t,published:t?.published}]})),m=()=>t.previews.includes(c)&&mC.get(c)===d&&fC(c,f)&&zS(e,t),h=e=>{m()&&(VS(t,e,d),c.content={kind:`unavailable`,message:e},d.published=dC(c),t.previews=[...t.previews])};(async()=>{VS(t,null);try{let e=await r(),n=e==null?null:i(e),s=e==null?void 0:o.resolveLabel?.(e),u=e==null?void 0:o.resolveKey?.(e);if(!n){h(a);return}if(m()){t.activeId===l&&u&&(t.activeId=u);let e=u?t.previews.find(e=>e!==c&&e.canonicalKey===u):void 0;if(e){e.requestIds=[...new Set([...e.requestIds??[],c.id,...c.requestIds??[]])],c.navigation&&(c.navigationOrder??0)>(e.navigationOrder??0)&&(e.navigation=c.navigation,e.navigationOrder=c.navigationOrder,e.content.kind===`file`&&(e.content.navigation=e.navigation));let r=p.get(e),i=mC.get(e),a=i===r?.read&&i?.published===r?.published?r?.snapshot:i?.published;o.revalidate&&(i?.order??0)<=d.order&&fC(e,a)&&(pC(e,n,s),i&&HS(t,i),d.published=dC(e),mC.set(e,d)),t.previews=t.previews.filter(e=>e!==c),t.activePreviewId===c.id&&(t.activePreviewId=e.id);return}c.canonicalKey=u,pC(c,n,s),d.published=dC(c),t.previews=[...t.previews]}}catch(e){h(N(e))}finally{e.requestUpdate?.()}})()}function dC(e){let t=e.content;return{content:t,text:t.kind===`file`?t.content:void 0,hash:t.kind===`file`?t.edit?.hash:void 0}}function fC(e,t){let n=e.content;return t!==void 0&&n===t.content&&(n.kind!==`file`||!nC(n)&&n.content===t.text&&n.edit?.hash===t.hash)}function pC(e,t,n){let r=e.content;t.kind===`file`&&e.navigation&&(t.line=e.navigation.line,t.navigation=e.navigation),(r.kind!==`file`||t.kind!==`file`||r.content!==t.content||r.edit?.hash!==t.edit?.hash||r.path!==t.path||r.root!==t.root||r.mimeType!==t.mimeType)&&(e.content=t),e.label=n||e.label}var mC,hC;function gC(){return(gC=e((()=>{ft(),lC(),ZS(),mC=new WeakMap,hC=0})))()}var _C;function vC(){return(vC=e((()=>{R(),ft(),_C=class{constructor(e,t,n){this.host=e,this.content=t,this.runtime=n,this.error=null,this.request=null,this.onDownload=()=>{this.run()}}get pending(){return this.request!==null}cancel(){(this.request||this.error!==null)&&(this.request?.abort(),this.request=null,this.error=null,this.host.requestUpdate())}async run(){let e=this.content();if(e?.kind!==`attachment`||!e.download||this.request)return;let t=new AbortController,{connectionEpoch:n,sessionKey:r,agentId:i}=this.runtime();this.request=t,this.error=null,this.host.requestUpdate();let a=()=>{let a=this.runtime();return this.host.isConnected&&this.content()===e&&this.request===t&&a.connectionEpoch===n&&a.sessionKey===r&&a.agentId===i&&!t.signal.aborted};try{let n=await e.download(t.signal);if(!a())return;if(!n)throw Error(L(`chat.attachments.unavailable`));Ka(e.title,n)}catch(e){a()&&(this.error=N(e))}finally{this.request===t&&(this.request=null,this.host.requestUpdate())}}}})))()}function yC(e){if(!e.absolutePath)return G;let t=`Open in editor`;return H`
    <div class="sidebar-file-view__editor">
      <wa-dropdown
        class="sidebar-file-view__editor-menu"
        placement="bottom-end"
        .open=${e.open}
        @wa-select=${t=>{let n=t.detail.item.value;n&&no.includes(n)&&e.onOpenEditor(n)}}
        @wa-show=${()=>e.onOpenChange(!0)}
        @wa-hide=${()=>e.onOpenChange(!1)}
      >
        <button
          slot="trigger"
          class="btn btn--sm sidebar-file-view__action"
          type="button"
          title=${t}
          aria-label=${t}
        >
          ${z.externalLink}
        </button>
        ${no.map(e=>H`
            <wa-dropdown-item class="sidebar-file-view__editor-item" value=${e}>
              ${ba[e]}
            </wa-dropdown-item>
          `)}
      </wa-dropdown>
    </div>
  `}function bC(){return(bC=e((()=>{K(),B(),Lc(),Eo()})))()}function xC(){try{return P()?.getItem(OC)===`true`}catch{return!1}}function SC(e){try{P()?.setItem(OC,String(e))}catch{}}function CC(e){return[e.split(`\r
`).length-1,(e.match(/\r(?!\n)/g)??[]).length,(e.match(/(?<!\r)\n/g)??[]).length].filter(e=>e>0).length<=1}function wC(e,t){let n=t.toLocaleLowerCase();return n?e.split(/\r\n?|\n/).flatMap((e,t)=>e.toLocaleLowerCase().includes(n)?[t+1]:[]):[]}function TC({label:e,icon:t,onClick:n,className:r=``,pressed:i,disabled:a=!1}){return H`
    <openclaw-tooltip .content=${e}>
      <button
        class="btn btn--sm sidebar-file-view__action ${r}"
        type="button"
        aria-label=${e}
        aria-pressed=${i===void 0?G:String(i)}
        ?disabled=${a}
        @click=${n}
      >
        ${t}
      </button>
    </openclaw-tooltip>
  `}function EC(e,t){let n=t?.copyFeedback[e];return TC({label:L(n===`failed`?`common.copyFailed`:n===`copied`?`common.copied`:e===`path`?`chat.detailPanel.copyPath`:`chat.detailPanel.copyContents`),icon:n===`copied`?z.check:z.copy,onClick:()=>t?.onCopy(e),className:n===`copied`?`copied`:``})}function DC(e,t,n){let r=Xc(e,n?.execNode),i=n?.matches.length?n.currentMatchIndex+1:0;return H`
    <section class="sidebar-file-view ${n?.wrap?`sidebar-file-view--wrap`:``}">
      <div class="sidebar-file-view__path-bar">
        <div class="sidebar-file-view__path-field">
          <span class="sidebar-file-view__path" title=${e.path}>${e.path}</span>
          ${EC(`path`,n)}
        </div>
        ${n?H`
                <div class="sidebar-file-view__actions">
                  ${!n.htmlPreview||n.htmlPreview.source?TC({label:L(n.wrap?`chat.codeBlock.disableWrap`:`chat.codeBlock.enableWrap`),icon:z.wrapText,onClick:n.onToggleWrap,className:`sidebar-file-view__wrap`,pressed:n.wrap}):G}
                  ${n.htmlPreview?H`<button
                          class="btn btn--sm"
                          type="button"
                          aria-pressed=${String(n.htmlPreview.source)}
                          @click=${n.htmlPreview.onToggle}
                        >
                          ${n.htmlPreview.source?L(`chat.workspaceFiles.preview`):L(`chat.detailPanel.viewSource`)}
                        </button>`:G}
                  ${n.editing?H`
                          <button
                            class="btn btn--sm"
                            type="button"
                            ?disabled=${!n.dirty||n.saving}
                            @click=${n.onSave}
                          >
                            ${n.saving?L(`common.saving`):L(`common.save`)}
                          </button>
                          <button
                            class="btn btn--sm"
                            type="button"
                            ?disabled=${n.saving}
                            @click=${n.onDiscard}
                          >
                            ${L(`chat.detailPanel.discard`)}
                          </button>
                        `:H`
                          ${e.edit?TC({label:L(`chat.detailPanel.editFile`),icon:z.edit,onClick:n.onEdit,disabled:n.loadingEditor}):G}
                          ${TC({label:L(`chat.detailPanel.searchInFile`),icon:z.search,onClick:n.onToggleSearch,className:`sidebar-file-view__search-toggle`,pressed:n.searchOpen})}
                          ${n.onReveal?TC({label:L(`chat.detailPanel.showInFiles`),icon:z.folder,onClick:()=>n.onReveal?.(e.path)}):G}
                          ${yC({absolutePath:r,open:n.editorMenuOpen,onOpenChange:n.onEditorMenuOpenChange,onOpenEditor:n.onOpenEditor})}
                          ${EC(`contents`,n)}
                        `}
                </div>
              `:G}
      </div>
      ${Object.values(n?.copyFeedback??{}).includes(`failed`)?H`<div class="file-view__save-notice" role="alert">${L(`common.copyFailed`)}</div>`:G}
      ${n?.searchOpen?H`
              <div class="file-view__search" @keydown=${n.onSearchKeydown}>
                <input
                  type="search"
                  aria-label=${L(`chat.detailPanel.searchInFile`)}
                  placeholder=${L(`common.search`)}
                  .value=${n.query}
                  @input=${e=>n.onSearchInput(e.currentTarget.value)}
                />
                <span class="file-view__search-counter" role="status"
                  >${i}/${n.matches.length}</span
                >
                ${[[`chat.detailPanel.previousMatch`,n.onPreviousMatch,` file-view__search-action--previous`],[`chat.detailPanel.nextMatch`,n.onNextMatch,``]].map(([e,t,r])=>H`<button
                    class="btn btn--sm file-view__search-action${r}"
                    type="button"
                    aria-label=${L(e)}
                    ?disabled=${n.matches.length===0}
                    @click=${t}
                  >
                    ${z.chevronDown}
                  </button>`)}
              </div>
            `:G}
      ${n?.saveNotice?H`
              <div class="file-view__save-notice" role="alert">
                <span>
                  ${n.saveNotice.kind===`conflict`?L(`chat.detailPanel.fileChanged`):n.saveNotice.message}
                </span>
                ${n.saveNotice.kind===`conflict`?H`
                        <div class="file-view__save-notice-actions">
                          <button
                            class="btn btn--sm"
                            type="button"
                            ?disabled=${n.saving}
                            @click=${n.onReload}
                          >
                            ${L(`common.reload`)}
                          </button>
                          <button
                            class="btn btn--sm"
                            type="button"
                            ?disabled=${n.saving}
                            @click=${n.onOverwrite}
                          >
                            ${L(`chat.detailPanel.overwrite`)}
                          </button>
                        </div>
                      `:G}
              </div>
            `:G}
      ${n?.htmlPreview?H`<div class="chat-html-preview" ?hidden=${n.htmlPreview.source}>
              ${n.htmlPreview.presentation}
            </div>`:G}
      <div class="file-view" ?hidden=${n?.htmlPreview&&!n.htmlPreview.source}>
        ${n?.htmlPreview?.sourceFallback??G}
        ${Y(n?.mountKey??e,H`<div class="file-view__mount"></div>`)}
        ${n?.loadingEditor?Fl(`review`,L(`common.loading`),!1,!0):G}
      </div>
      ${n?.editing||n?.htmlPreview?G:H`
              <div class="sidebar-file-view__footer">
                <button @click=${t} class="btn btn--sm" type="button">
                  ${L(`chat.detailPanel.viewRawText`)}
                </button>
              </div>
            `}
    </section>
  `}var OC,kC;function AC(){return(AC=e((()=>{K(),sr(),Dl(),B(),Cl(),V(),R(),Fa(),gs(),bC(),Wo(),Ta(),OC=`openclaw.control.fileView.wrap.v1`,kC={}})))()}var jC;function MC(){return(MC=e((()=>{xt(),AC(),jC=class{constructor(e,t){this.host=e,this.content=t,this.feedback=kC,this.attempts=new Map,this.timers=new Map,this.copy=e=>{let t=this.content();if(t?.kind!==`file`)return;let n=(this.attempts.get(e)??0)+1;this.attempts.set(e,n);let r=()=>this.attempts.get(e)===n&&this.content()===t&&this.host.isConnected;et(e===`path`?t.path:t.content,r).then(t=>{r()&&(this.feedback={...this.feedback,[e]:t?`copied`:`failed`},this.host.requestUpdate(),globalThis.clearTimeout(this.timers.get(e)),this.timers.set(e,globalThis.setTimeout(()=>{this.timers.delete(e),this.feedback={...this.feedback,[e]:void 0},this.host.requestUpdate()},t?1500:2e3)))})},e.addController(this)}reset(){for(let e of this.timers.values())globalThis.clearTimeout(e);this.timers.clear();for(let[e,t]of this.attempts)this.attempts.set(e,t+1);this.feedback=kC,this.host.isConnected&&this.host.requestUpdate()}hostConnected(){this.reset()}hostDisconnected(){this.reset()}}})))()}function NC(e,t){return e.split(`;`,1)[0]?.trim().toLowerCase()===`text/html`||/\.html?$/i.test(t)}function PC(e,t,n,r,i){e.requestWhileActive(FC,!0);let a=e.visibleState;return H`
    ${a?.status===`error`?Mn({error:a.error,stale:a.stale,onRetry:()=>e.retry()}):a?H`<div role="status">${L(`common.loading`)}</div>`:G}
    <openclaw-chat-html-preview
      .html=${t}
      .sourceIdentity=${n}
      .title=${r}
      .embedSandboxMode=${i}
    ></openclaw-chat-html-preview>
  `}var FC,IC;function LC(){return(LC=e((()=>{K(),Mt(),qt(),fn(),R(),gs(),t(),Ta(),FC={tagName:`openclaw-chat-html-preview`,get label(){return L(`chat.detailPanel.renderPreview`)},loadModule:()=>ne(()=>import(`./chat-html-preview-element-Bq8JPIhe.js`),__vite__mapDeps([15,1,2,3,4,14,5,6,7]),import.meta.url)},IC=class{constructor(e,t,n){this.host=e,this.content=t,this.text=n,this.source=!1,this.preview=null,this.loader=new Jt(e),e.addController(this)}get file(){let e=this.content();return e?.kind===`file`&&NC(e.mimeType??``,e.name)?e:null}get showing(){return this.file!==null&&!this.source}reset(e,t){this.source=t;let n=this.file;this.preview=n&&!t?e??n.content:null}showSource(){this.source||(this.source=!0,this.host.requestUpdate())}toggle(){this.source&&(this.preview=this.text()),this.source=!this.source,this.host.requestUpdate()}discard(e){this.preview!==null&&(this.preview=e,this.host.requestUpdate())}hostDisconnected(){this.loader.requestWhileActive(FC,!1)}controls(e){let t=this.file;if(t)return{source:this.source,onToggle:e.onToggle,presentation:this.preview===null?G:PC(this.loader,this.preview,t.draftKey??[e.runtime.sessionKey??``,e.runtime.agentId??``,t.root??``,t.path].join(`\0`),t.name,e.mode),sourceFallback:e.error?H`
            ${Mn({error:e.error,stale:zt(e.error),onRetry:e.onRetry})}
            <pre class="sidebar-attachment-preview__text">${this.text()}</pre>
          `:void 0}}}})))()}function RC(e){return e.composedPath().some(e=>e instanceof HTMLElement&&e.localName===`openclaw-image-lightbox`)}function zC(e){let t=e.composedPath().find(e=>e instanceof HTMLElement&&(e.classList.contains(`markdown-inline-image`)||e.classList.contains(`markdown-inline-image-button`))),n=t instanceof HTMLImageElement?t:t?.querySelector(`.markdown-inline-image`)??null;return n?.closest(`a`)?null:n}function BC(e,t){if(e.defaultPrevented)return!1;let n=zC(e);return n?(e.preventDefault(),s_(t,n.currentSrc||n.src,n.alt.trim()||L(`chat.imageLightbox.untitled`)),!0):!1}function VC(e,t){return e?H`
    <openclaw-image-lightbox
      .mediaKind=${e.kind??`image`}
      .gallery=${e.gallery}
      .connectVideo=${e.connectVideo}
      .loadFullResolution=${e.loadFullResolution}
      src=${e.src}
      .originalSrc=${e.originalSrc??``}
      .imageTitle=${e.title}
      .imageWidth=${e.width}
      .imageHeight=${e.height}
      @image-lightbox-close=${t}
    ></openclaw-image-lightbox>
  `:G}function HC(){return(HC=e((()=>{K(),yc(),R(),c_()})))()}function UC(e,t){let n=e.split(`;`,1)[0]?.trim().toLowerCase()??``;return n===`application/pdf`||(!n||n===`application/octet-stream`)&&/\.pdf$/i.test(t)}var WC,GC,KC;function qC(){return(qC=e((()=>{K(),ar(),R(),tt(),yh(),Eh(),WC=16777216,GC=1e4,KC=class extends lt{constructor(...e){super(...e),this.src=``,this.sourceIdentity=``,this.label=``,this.mimeType=``,this.downloadHref=``,this.status=`loading`,this.previewUrl=null,this.loadVersion=0}connectedCallback(){super.connectedCallback(),this.requestUpdate(`src`)}disconnectedCallback(){this.cancelLoad(),this.revokePreviewUrl(),super.disconnectedCallback()}willUpdate(e){(e.has(`src`)||e.has(`sourceIdentity`)||e.has(`sizeBytes`))&&(this.cancelLoad(),(!this.src||!this.previewUrl||!this.sourceIdentity||e.has(`sourceIdentity`)||e.has(`sizeBytes`))&&(this.revokePreviewUrl(),this.status=`loading`),this.src&&this.loadPdf())}cancelLoad(){this.loadVersion+=1,this.abortController?.abort(),this.abortController=void 0}revokePreviewUrl(){this.previewUrl&&URL.revokeObjectURL(this.previewUrl),this.previewUrl=null,this.previewBytes=void 0}async loadPdf(){if(this.sizeBytes!==void 0&&this.sizeBytes>WC){this.status=`error`;return}let e=this.loadVersion,t=new AbortController;this.abortController=t;let n=setTimeout(()=>t.abort(),GC);try{let n=await fetch(this.src,{credentials:`same-origin`,redirect:`error`,signal:t.signal});if(!n.ok)throw await n.body?.cancel().catch(()=>void 0),Error(`PDF attachment unavailable`);let r=await hg(n,WC);if(!r)throw Error(`PDF attachment exceeds preview limit`);if(e!==this.loadVersion||!this.isConnected)return;let i=new Uint8Array(r);if(this.previewBytes?.length===i.length&&this.previewBytes.every((e,t)=>e===i[t]))return;this.revokePreviewUrl(),this.previewBytes=i,this.previewUrl=URL.createObjectURL(new Blob([r],{type:`application/pdf`})),this.status=`ready`}catch{e===this.loadVersion&&this.isConnected&&(this.revokePreviewUrl(),this.status=`error`)}finally{clearTimeout(n),this.abortController===t&&(this.abortController=void 0)}}render(){let e=xh(this.downloadHref||this.src);return H`
      <div class="sidebar-pdf-preview" aria-label=${this.label}>
        <div class="sidebar-pdf-preview__surface">
          ${this.status===`loading`?mh():this.status===`error`||!this.previewUrl?H`<div class="sidebar-attachment-preview__unavailable" role="alert">
                    ${L(`chat.attachments.previewUnavailable`)}
                    ${ph({kind:`document`,label:this.label,mimeType:this.mimeType,sizeBytes:this.sizeBytes,downloadHref:e??void 0})}
                  </div>`:H`<iframe
                    class="sidebar-pdf-preview__frame"
                    title=${this.label}
                    src=${this.previewUrl}
                    referrerpolicy="no-referrer"
                  ></iframe>`}
        </div>
      </div>
    `}},k([X()],KC.prototype,`src`,void 0),k([X()],KC.prototype,`sourceIdentity`,void 0),k([X()],KC.prototype,`label`,void 0),k([X()],KC.prototype,`mimeType`,void 0),k([X({type:Number})],KC.prototype,`sizeBytes`,void 0),k([X()],KC.prototype,`downloadHref`,void 0),k([J()],KC.prototype,`status`,void 0),k([J()],KC.prototype,`previewUrl`,void 0),customElements.get(`openclaw-chat-pdf-preview`)||customElements.define(`openclaw-chat-pdf-preview`,KC)})))()}function JC(e,t){let n=e.split(`;`,1)[0]?.trim().toLowerCase()??``;return n.startsWith(`text/`)||/^application\/(?:(?:[\w.-]+\+)?(?:json|xml)|javascript|x-javascript|yaml|x-yaml)$/.test(n)?!0:(!n||n===`application/octet-stream`)&&/\.(?:txt|md|markdown|html?|log|csv|tsv|json|jsonl|xml|yaml|yml)$/i.test(t)}var YC;function XC(){return(XC=e((()=>{K(),ar(),sr(),dr(),Mt(),ic(),B(),Uc(),Il(),R(),gs(),xe(),ua(),tt(),yh(),Qg(),LC(),Ta(),YC=class extends lt{constructor(...e){super(...e),this.compact=!1,this.plainText=!1,this.actions=G,this.embedSandboxMode=`scripts`,this.src=``,this.sourceIdentity=``,this.label=``,this.mimeType=``,this.text=null,this.failed=!1,this.source=!1,this.htmlPreviewLoader=new Jt(this),this.loadVersion=0}connectedCallback(){super.connectedCallback(),this.requestUpdate(`src`)}disconnectedCallback(){this.cancelLoad(),this.htmlPreviewLoader.requestWhileActive(FC,!1),super.disconnectedCallback()}get htmlDocument(){return!this.plainText&&NC(this.mimeType,this.label)}willUpdate(e){e.has(`sourceIdentity`)&&(this.source=!1);let t=e.has(`plainText`)||e.has(`mimeType`)||e.has(`label`);(t||e.has(`src`)||e.has(`sourceIdentity`)||e.has(`sizeBytes`))&&(this.cancelLoad(),(t||!this.src||!this.sourceIdentity||e.has(`sourceIdentity`)||e.has(`sizeBytes`))&&(this.text=null),this.failed=!1,this.src&&this.loadText())}cancelLoad(){this.loadVersion+=1,this.abortController?.abort(),this.abortController=void 0}async loadText(){let e=this.loadVersion,t=new AbortController;this.abortController=t;try{let n=await Xg(this.src,this.sizeBytes,t.signal,this.htmlDocument?`html`:`full`);e===this.loadVersion&&this.isConnected&&(this.text=n)}catch{e===this.loadVersion&&this.isConnected&&(this.text=null,this.failed=!0)}finally{this.abortController===t&&(this.abortController=void 0)}}retry(){this.cancelLoad(),this.text=null,this.failed=!1,this.loadText()}render(){let e=this.htmlDocument,t=this.mimeType.split(`;`,1)[0]?.trim().toLowerCase(),n=!this.plainText&&(t===`text/markdown`||t===`text/x-markdown`||/\.(?:md|markdown)$/i.test(this.label)),r=this.text===null?mh():H`${Y(this.sourceIdentity||this.loadVersion,H`${Y(this.text,e?H`<div class="chat-html-preview" ?hidden=${this.source}>
                      ${PC(this.htmlPreviewLoader,this.text,this.sourceIdentity||this.src,this.label,this.embedSandboxMode)}
                    </div>
                    <pre
                      class="sidebar-attachment-preview__text"
                      tabindex="0"
                      aria-label=${this.label}
                      ?hidden=${!this.source}
                    >
${this.text}</pre>`:n&&!this.source?H`<article
                      class="sidebar-attachment-preview__markdown sidebar-markdown-reader sidebar-markdown"
                      dir=${ra(this.text)}
                      aria-label=${this.label}
                      ${Ol()}
                    >
                      ${lr(Wc(this.text,{mode:`document`,remoteImages:!1,codeBlockInteraction:`interactive`}))}
                    </article>`:H`<pre
                      class="sidebar-attachment-preview__text"
                      tabindex="0"
                      aria-label=${this.label}
                    >
${this.text}</pre>`)}`)}`;return H`
      ${this.compact?H`<div class="sidebar-file-toolbar">
              <span class="sidebar-file-toolbar__type" title=${this.mimeType}
                >${this.mimeType||this.label.split(`.`).at(-1)}</span
              >
              ${this.sizeBytes===void 0?G:H`<span>${ve(this.sizeBytes)}</span>`}
              <span class="sidebar-file-toolbar__actions">
                ${this.text!==null&&!this.failed?Y(this.loadVersion,Pc(this.text,L(`common.copy`))):G}
                ${this.actions}
                ${this.failed?H`<button class="btn btn--sm" type="button" @click=${()=>this.retry()}>${L(`common.retry`)}</button>`:G}
                ${(n||e)&&this.text!==null?H`<button
                        class="btn btn--sm"
                        type="button"
                        aria-pressed=${String(this.source)}
                        @click=${()=>{this.source=!this.source}}
                      >
                        ${this.source?L(`chat.workspaceFiles.preview`):L(e?`chat.detailPanel.viewSource`:`chat.detailPanel.viewRawText`)}
                      </button>`:G}
                <a
                  class="rail-header__action"
                  href=${this.src||G}
                  download=${this.label}
                  target="_blank"
                  rel="noreferrer"
                  aria-label=${L(`chat.mediaPlayer.download`,{filename:this.label})}
                  >${z.download}</a
                >
              </span>
            </div>`:ph({kind:`document`,label:this.label,mimeType:this.mimeType,sizeBytes:this.sizeBytes,downloadHref:this.src,downloadPending:!this.src})}
      ${this.failed?H`<p class="muted" role="status">
              ${L(e?`chat.attachments.htmlPreviewUnavailable`:`chat.attachments.textPreviewUnavailable`)}
            </p>`:r}
    `}},k([X({type:Boolean})],YC.prototype,`compact`,void 0),k([X({type:Boolean})],YC.prototype,`plainText`,void 0),k([X({attribute:!1})],YC.prototype,`actions`,void 0),k([X()],YC.prototype,`embedSandboxMode`,void 0),k([X()],YC.prototype,`src`,void 0),k([X()],YC.prototype,`sourceIdentity`,void 0),k([X()],YC.prototype,`label`,void 0),k([X()],YC.prototype,`mimeType`,void 0),k([X({type:Number})],YC.prototype,`sizeBytes`,void 0),k([J()],YC.prototype,`text`,void 0),k([J()],YC.prototype,`failed`,void 0),k([J()],YC.prototype,`source`,void 0),customElements.get(`openclaw-chat-text-attachment`)||customElements.define(`openclaw-chat-text-attachment`,YC)})))()}var ZC;function QC(){return(QC=e((()=>{K(),ar(),ic(),hl(),B(),Kc(),Lc(),R(),Eo(),tt(),ZC=class extends gt{constructor(...e){super(...e),this.menu=null,this.onAction=()=>{},this.onClose=()=>{},this.menuLifecycle=new hc(this,{getTrigger:()=>this.menu?.trigger??null,onClose:()=>this.onClose()}),this.handleSelect=e=>{e.preventDefault();let t=e.detail.item.value;if(!t)return;let n={"collapse-all":{kind:`collapse-all`},"expand-all":{kind:`expand-all`},"toggle-split":{kind:`toggle-split`},"toggle-wrap":{kind:`toggle-wrap`},"scope:all":{kind:`scope`,value:{scope:`all`}},"scope:uncommitted":{kind:`scope`,value:{scope:`uncommitted`}}},r=this.menu?.kind===`file`?this.menu:null;if(r&&(t===`open-file`||t===`reveal-file`)){this.run({kind:t,path:r.path});return}let i=n[t];if(i){this.run(i);return}if(t.startsWith(`open-editor:`)){let e=t.slice(12);if(no.includes(e)){let t=this.menu?.kind===`file`?this.menu.absolutePath:void 0;t&&this.run({kind:`open-editor`,editor:e,path:t})}return}t.startsWith(`scope:commit:`)&&this.run({kind:`scope`,value:{scope:`commit`,commit:t.slice(13)}})},this.handleAfterHide=e=>{e.currentTarget instanceof Node&&e.currentTarget.isConnected&&this.onClose()}}connectedCallback(){super.connectedCallback(),Jl(this)}run(e){this.onClose(),this.onAction(e)}renderFileMenu(e){return H`
      ${this.renderCopyRow(e.path,L(`chat.sessionDiff.copyPath`))}
      <wa-dropdown-item class="session-menu__item" value="open-file" ?disabled=${!e.canOpenFile}>
        <span slot="icon" class="session-menu__icon" aria-hidden="true">${z.fileText}</span>
        <span class="session-menu__text">${L(`chat.sessionDiff.openFile`)}</span>
      </wa-dropdown-item>
      ${e.canReveal?H`<wa-dropdown-item class="session-menu__item" value="reveal-file">
              <span slot="icon" class="session-menu__icon" aria-hidden="true">${z.folder}</span>
              <span class="session-menu__text">${L(`chat.sessionDiff.revealInFileTree`)}</span>
            </wa-dropdown-item>`:G}
      ${e.absolutePath?H`<wa-dropdown-item class="session-menu__item">
              <span slot="icon" class="session-menu__icon" aria-hidden="true"
                >${z.externalLink}</span
              >
              <span class="session-menu__text">${L(`chat.sessionDiff.openInEditor`)}</span>
              ${no.map(e=>H`<wa-dropdown-item
                  slot="submenu"
                  class="session-menu__item"
                  value=${`open-editor:${e}`}
                >
                  <span class="session-menu__text">${ba[e]}</span>
                </wa-dropdown-item>`)}
            </wa-dropdown-item>`:G}
    `}renderViewMenu(e){return H`
      <wa-dropdown-item class="session-menu__item" value="collapse-all">
        <span class="session-menu__text">${L(`chat.sessionDiff.collapseAll`)}</span>
      </wa-dropdown-item>
      <wa-dropdown-item class="session-menu__item" value="expand-all">
        <span class="session-menu__text">${L(`chat.sessionDiff.expandAll`)}</span>
      </wa-dropdown-item>
      <div class="session-menu__separator" role="separator"></div>
      <wa-dropdown-item class="session-menu__item" value="toggle-wrap">
        <span class="session-menu__text"
          >${L(e.wrap?`chat.sessionDiff.disableWrapping`:`chat.sessionDiff.enableWrapping`)}</span
        >
      </wa-dropdown-item>
      <wa-dropdown-item class="session-menu__item" value="toggle-split">
        <span class="session-menu__text"
          >${L(e.split?`chat.sessionDiff.switchUnified`:`chat.sessionDiff.switchSplit`)}</span
        >
      </wa-dropdown-item>
    `}renderScopeMenu(e){let t=e.active.scope===`commit`?e.active.commit:null;return H`
      ${this.renderScopeItem(`scope:all`,L(`chat.sessionDiff.allChanges`),e.active.scope===`all`)}
      ${this.renderScopeItem(`scope:uncommitted`,L(`chat.sessionDiff.uncommitted`),e.active.scope===`uncommitted`)}
      ${e.result.commits?.length?H`<div class="session-menu__separator" role="separator"></div>
              ${e.result.commits.map((e,n)=>this.renderScopeItem(`scope:commit:${e.sha}`,H`<span class="session-diff-menu__sha">${e.sha}</span>
                    <span class="session-diff-menu__subject">${e.subject}</span>
                    ${n===0?H`<span class="session-diff-menu__head"
                            >${L(`chat.sessionDiff.head`)}</span
                          >`:G}`,t===e.sha))}`:G}
      ${e.result.mergeBase?H`<div class="session-menu__separator" role="separator"></div>
              <div class="session-diff-menu__merge-base">
                <span>${L(`chat.sessionDiff.mergeBase`)}</span>
                <span class="session-diff-menu__sha">${e.result.mergeBase.sha}</span>
                <span class="session-diff-menu__subject">${e.result.mergeBase.subject}</span>
              </div>`:G}
    `}renderScopeItem(e,t,n){return H`<wa-dropdown-item
      class="session-menu__item session-diff-menu__scope-item"
      value=${e}
      role="menuitemradio"
      aria-checked=${String(n)}
    >
      <span class="session-menu__text">${t}</span>
      ${n?H`<span slot="details" class="session-menu__check" aria-hidden="true"
              >${z.check}</span
            >`:G}
    </wa-dropdown-item>`}renderSyncMenu(e){return H`<div class="session-diff-menu__sync">
      <strong>${L(`chat.sessionDiff.syncLocally`)}</strong>
      <p>${L(`chat.sessionDiff.syncDescription`)}</p>
      ${this.renderCopyRow(e.command,L(`chat.sessionDiff.copyCommand`),!0)}
      ${this.renderCopyRow(e.root,L(`chat.sessionDiff.checkoutPath`))}
      ${this.renderCopyRow(e.branch,L(`chat.sessionDiff.branchName`))}
      <p class="session-diff-menu__note">${L(`chat.sessionDiff.uncommittedStay`)}</p>
    </div>`}renderCopyRow(e,t,n=!1){return H`<div class="session-diff-menu__copy-row ${n?`is-command`:``}">
      <span class="session-diff-menu__copy-label">${t}</span>
      <code title=${e}>${e}</code>
      ${Pc(e,t)}
    </div>`}render(){let e=this.menu;if(!e)return G;let t=e.kind===`scope`?e.placement??`top-start`:`bottom-end`,n=e.kind===`sync`?360:e.kind===`scope`?340:240,r=e.kind===`file`?L(`chat.sessionDiff.fileActions`,{path:e.path}):e.kind===`scope`?L(`chat.sessionDiff.scopeMenu`):e.kind===`sync`?L(`chat.sessionDiff.syncLocally`):L(`chat.sessionDiff.viewOptions`),i=Math.max(8,Math.min(e.anchor.x,window.innerWidth-8)),a=Math.max(8,Math.min(e.anchor.y,window.innerHeight-8));return H`<wa-dropdown
      class="session-menu session-diff-menu session-diff-menu--${e.kind}"
      style=${`--session-diff-menu-width:${n}px`}
      .open=${!0}
      placement=${t}
      .distance=${4}
      aria-label=${r}
      @wa-select=${this.handleSelect}
      @wa-after-hide=${this.handleAfterHide}
    >
      <button
        slot="trigger"
        type="button"
        tabindex="-1"
        aria-hidden="true"
        style="position:fixed;left:${i}px;top:${a}px;width:1px;height:1px;opacity:0;pointer-events:none"
      ></button>
      ${e.kind===`file`?this.renderFileMenu(e):e.kind===`scope`?this.renderScopeMenu(e):e.kind===`sync`?this.renderSyncMenu(e):this.renderViewMenu(e)}
    </wa-dropdown>`}},k([X({attribute:!1})],ZC.prototype,`menu`,void 0),k([X({attribute:!1})],ZC.prototype,`onAction`,void 0),k([X({attribute:!1})],ZC.prototype,`onClose`,void 0),customElements.get(`openclaw-session-diff-menu`)||customElements.define(`openclaw-session-diff-menu`,ZC)})))()}function $C(e,t,n){let r=t===`left`?`-`:`+`;return H`<div
    class="session-diff-split__side session-diff-split__side--${t} ${e?`session-diff-split__side--filled`:``}"
  >
    <span class="session-diff-split__gutter">${e?.lineNo??``}</span>
    <span class="session-diff-split__sign">${e?r:``}</span>
    <span class="session-diff-split__text">${e?n(e):``}</span>
  </div>`}function ew(e,t,n={path:``}){let r=Ma(e);return ty(e,n,e=>H`<div
      class="session-diff-split code-highlight"
      role="figure"
      aria-label=${L(`chat.toolCards.fileChanges`)}
    >
      ${r.map(n=>n.kind===`pair`?H`<div class="session-diff-split__row session-diff-split__row--pair">
            ${$C(n.left,`left`,e)}
            ${$C(n.right,`right`,e)}
          </div>`:n.line.kind===`skip`?H`<div class="session-diff-split__row session-diff-split__row--skip">
            ${(t?.(n.line)??n.line.text)||`⋯`}
          </div>`:H`<div class="session-diff-split__row session-diff-split__row--context">
          <span class="session-diff-split__gutter">${n.line.lineNo??``}</span>
          <span class="session-diff-split__sign"></span>
          <span class="session-diff-split__text">${e(n.line)}</span>
        </div>`)}
    </div>`)}function tw(){return(tw=e((()=>{K(),R(),ny()})))()}function nw(){try{let e=JSON.parse(P()?.getItem(lw)??`null`);return{split:e?.split===!0,wrap:e?.wrap===!0}}catch{return{split:!1,wrap:!1}}}function rw(e){try{P()?.setItem(lw,JSON.stringify(e))}catch{}}function iw(e){let t=Math.min(e.additions,e.deletions);return{added:e.additions-t,removed:e.deletions-t,modified:t}}function aw(e){return e.reduce((e,t)=>{let n=iw(t);return e.added+=n.added,e.removed+=n.removed,e.modified+=n.modified,e},{added:0,removed:0,modified:0})}function ow(e){let t=e.replaceAll(`\\`,`/`),n=t.lastIndexOf(`/`);return n<0?{directory:``,name:t}:{directory:t.slice(0,n),name:t.slice(n+1)}}function sw(e){return/^[A-Za-z0-9_./:@+-]+$/.test(e)?e:`'${e.replaceAll(`'`,`'\\''`)}'`}function cw(e){return{result:e,views:e.files.map(e=>({file:e,parsed:e.patch?ko(e.patch,e=>L(`chat.sessionDiff.unmodifiedLines`,{count:String(e)})):null}))}}var lw,uw,dw;function fw(){return(fw=e((()=>{Cs(),K(),ar(),sr(),Dl(),B(),Cl(),R(),V(),Za(),za(),Eo(),ft(),tt(),ay(),QC(),tw(),lw=`openclaw.control.sessionDiff.v1`,uw={added:[`A`,`chat.sessionDiff.statusAdded`],deleted:[`D`,`chat.sessionDiff.statusDeleted`],renamed:[`R`,`chat.sessionDiff.statusRenamed`],modified:[`M`,`chat.sessionDiff.statusModified`]},dw=class extends gt{constructor(){super(),this.execNode=null,this.loader=null,this.loadFileText=null,this.openFile=null,this.revealFile=null,this.collapsedPaths=new Set,this.menu=null,this.scope={scope:`all`},this.split=nw().split,this.wrap=nw().wrap,this.fileTextCache=new WeakMap,this.unavailableFileText=new WeakSet,this.prefetchedDiffResult=null,this.diffTask=new ws(this,{args:()=>[this.loader,this.scope.scope,this.scope.scope===`commit`?this.scope.commit:null],task:async([e,t,n])=>{if(!e)return null;let r=t===`commit`?{scope:t,commit:n}:{scope:t},i=this.prefetchedDiffResult??await e(r);return this.prefetchedDiffResult=null,cw(i)},onComplete:e=>{let t=new Set(e?.views.map(e=>e.file.path)??[]);this.collapsedPaths=new Set([...this.collapsedPaths].filter(e=>t.has(e)))}}),_l(this,()=>{this.menu=null})}get loading(){return this.loader!==null&&this.diffTask.status===Ts.PENDING}toggleFile(e){let t=new Set(this.collapsedPaths);t.has(e)?t.delete(e):t.add(e),this.collapsedPaths=t}openAnchoredMenu(e,t,n=`bottom-end`){e.stopPropagation();let r=e.currentTarget;if(!(r instanceof HTMLElement))return;let i=r.getBoundingClientRect();this.menu={...t,...t.kind===`scope`&&n!==`bottom-end`?{placement:n}:{},anchor:{x:n.endsWith(`start`)?i.left:i.right,y:n.startsWith(`top`)?i.top:i.bottom},trigger:r}}handleMenuAction(e){switch(e.kind){case`collapse-all`:{let e=this.diffTask.value?.views??[];this.collapsedPaths=new Set(e.map(e=>e.file.path));return}case`expand-all`:this.collapsedPaths=new Set;return;case`toggle-wrap`:this.wrap=!this.wrap,rw({split:this.split,wrap:this.wrap});return;case`toggle-split`:this.split=!this.split,rw({split:this.split,wrap:this.wrap});return;case`scope`:this.scope=e.value;return;case`open-file`:this.openFile?.(e.path);return;case`reveal-file`:this.revealFile?.(e.path);return;case`open-editor`:Ho(e.editor,e.path)}}renderSummary(e){let t=e.baseRef&&e.branch&&e.baseRef!==e.branch?`${e.baseRef} → ${e.branch}`:e.branch??e.baseRef??``,n=e.root&&e.branch?`git fetch ${sw(e.root)} ${sw(e.branch)} && git checkout FETCH_HEAD`:null;return H`
      <div class="session-diff__summary">
        <span class="session-diff__branch" title=${e.root??``}>
          ${z.gitBranch}
          <span class="session-diff__branch-label">${t}</span>
        </span>
        ${e.unavailableReason===`workspace_stopped`?G:ry(aw(e.files))}
        <span class="session-diff__summary-spacer"></span>
        ${n&&e.root&&e.branch?H`<button
                class="btn btn--ghost btn--sm session-diff__toolbar-button"
                type="button"
                @click=${t=>this.openAnchoredMenu(t,{kind:`sync`,command:n,root:e.root,branch:e.branch})}
              >
                ${L(`chat.sessionDiff.sync`)} ${z.chevronDown}
              </button>`:G}
        <openclaw-tooltip .content=${L(`chat.sessionDiff.viewOptions`)}>
          <button
            class="btn btn--ghost btn--icon session-diff__toolbar-icon"
            type="button"
            aria-label=${L(`chat.sessionDiff.viewOptions`)}
            @click=${e=>this.openAnchoredMenu(e,{kind:`view`,split:this.split,wrap:this.wrap})}
          >
            ${z.moreHorizontal}
          </button>
        </openclaw-tooltip>
        <openclaw-tooltip .content=${L(`chat.sessionDiff.refresh`)}>
          <button
            class="btn btn--ghost btn--icon session-diff__refresh"
            type="button"
            aria-label=${L(`chat.sessionDiff.refresh`)}
            ?disabled=${this.loading}
            @click=${()=>void this.diffTask.run()}
          >
            ${z.refresh}
          </button>
        </openclaw-tooltip>
      </div>
    `}canExpandGaps(e){return this.scope.scope!==`commit`&&!!this.loadFileText&&e.file.binary!==!0&&e.parsed!==null&&!e.parsed.truncated&&!this.unavailableFileText.has(e)}loadFileLines(e){let t=this.fileTextCache.get(e);if(t)return t;let n=this.loadFileText,r=n?n(e.file.path).then(e=>e===null?null:ha(e)).catch(()=>null):Promise.resolve(null);return this.fileTextCache.set(e,r),r}async expandGap(e,t,n){let r=e.parsed,i=this.loader;if(!r||!t.gap||!i||!this.canExpandGaps(e))return;let a=this.scope,o;try{o=await i(a)}catch{return}if(this.loader!==i||this.scope!==a||!this.diffTask.value?.views.includes(e))return;let s=o.files.find(t=>t.path===e.file.path);if(!s||s.patch!==e.file.patch){this.fileTextCache.delete(e),this.prefetchedDiffResult=o,await this.diffTask.run();return}let c=await this.loadFileLines(e);if(!c||!this.diffTask.value?.views.includes(e)){this.unavailableFileText.add(e),this.requestUpdate();return}let l=go(r.lines,t.gap,c,n,e=>L(`chat.sessionDiff.unmodifiedLines`,{count:String(e)}));if(!l){this.unavailableFileText.add(e),this.requestUpdate();return}r.lines=l,this.requestUpdate()}renderGap(e,t){let n=t.gap;if(!n||!this.canExpandGaps(e))return t.text;let r=n.count<=25?n.count:Math.min(20,n.count);return H`<span class="session-diff__gap-controls">
      <button
        type="button"
        aria-label=${L(`chat.sessionDiff.expandPreviousLines`,{count:String(r)})}
        @click=${()=>void this.expandGap(e,t,`up`)}
      >
        ${z.chevronUp}
      </button>
      <button
        class="session-diff__gap-count"
        type="button"
        aria-label=${L(`chat.sessionDiff.expandAllLines`,{count:String(n.count)})}
        @click=${()=>void this.expandGap(e,t,`all`)}
      >
        ${t.text}
      </button>
      <button
        type="button"
        aria-label=${L(`chat.sessionDiff.expandNextLines`,{count:String(r)})}
        @click=${()=>void this.expandGap(e,t,`down`)}
      >
        ${z.chevronDown}
      </button>
    </span>`}renderFileBody(e,t){let{file:n,parsed:r}=e;if(n.binary===!0)return H`<div class="session-diff__note">${L(`chat.sessionDiff.binaryFile`)}</div>`;if(!r)return H`<div class="session-diff__note">
        ${L(t.unavailableReason===`workspace_stopped`?`chat.sessionDiff.workspaceStoppedFile`:`chat.sessionDiff.previewUnavailable`)}
      </div>`;let i=t=>this.renderGap(e,t);return H`
      ${this.split?ew(r.lines,i,n):iy(r.lines,`succeeded`,i,n)}
      ${r.truncated?H`<div class="session-diff__note">${L(`chat.sessionDiff.truncatedFile`)}</div>`:G}
    `}renderFile(e,t){let{file:n}=e,r=this.collapsedPaths.has(n.path),{directory:i,name:a}=ow(n.path),o=t.root?Xc({root:t.root,path:n.path},this.execNode)??void 0:void 0,s=n.oldPath?`${n.oldPath} → ${n.path}`:n.path,[c,l]=uw[n.status]??uw.modified;return H`
      <section class="session-diff__file" data-status=${n.status}>
        <div class="session-diff__file-header">
          <button
            class="session-diff__file-toggle"
            type="button"
            aria-expanded=${String(!r)}
            title=${s}
            @click=${()=>this.toggleFile(n.path)}
          >
            <span class="session-diff__chevron ${r?``:`session-diff__chevron--open`}">
              ${z.chevronRight}
            </span>
            <span
              class="session-diff__status session-diff__status--${n.status}"
              title=${L(l)}
              >${c}</span
            >
            <span class="session-diff__path">
              ${n.oldPath?H`<span class="session-diff__old-path">${n.oldPath} →</span>`:G}
              <span class="session-diff__filename">${a}</span>
              ${i?H`<span class="session-diff__directory">${i}</span>`:G}
            </span>
            ${n.untracked===!0?H`<span class="session-diff__badge">${L(`chat.sessionDiff.untracked`)}</span>`:G}
            ${t.unavailableReason===`workspace_stopped`?G:ry(iw(n))}
          </button>
          <button
            class="btn btn--ghost btn--icon session-diff__file-menu"
            type="button"
            aria-label=${L(`chat.sessionDiff.fileActions`,{path:n.path})}
            @click=${e=>this.openAnchoredMenu(e,{kind:`file`,path:n.path,...o?{absolutePath:o}:{},canOpenFile:!!this.openFile,canReveal:!!this.revealFile})}
          >
            ${z.moreHorizontal}
          </button>
        </div>
        ${r?G:H`<div
                class="session-diff__file-body"
                style=${`contain-intrinsic-size:auto ${Math.max(80,Math.min(12e3,(e.parsed?.lines.length??2)*19))}px`}
              >
                ${this.renderFileBody(e,t)}
              </div>`}
      </section>
    `}scopeTitle(e){let t=this.scope;if(t.scope===`uncommitted`)return L(`chat.sessionDiff.uncommitted`);if(t.scope===`commit`){let n=e.commits?.find(e=>e.sha===t.commit);return n?`${n.sha} ${n.subject}`:t.commit}return L(`chat.sessionDiff.allChanges`)}renderFooter(e){let t=e.branch??e.baseRef??L(`chat.sessionDiff.allChanges`),n=e.aheadCount&&e.baseRef?L(`chat.sessionDiff.commitsAhead`,{count:String(e.aheadCount),base:e.baseRef}):t;return H`<button
      class="session-diff__footer"
      type="button"
      aria-label=${L(`chat.sessionDiff.scopeMenu`)}
      @click=${t=>this.openAnchoredMenu(t,{kind:`scope`,active:this.scope,result:e},`top-start`)}
    >
      <span>${n}</span>${z.chevronUp}
    </button>`}renderBody(){if(this.diffTask.status===Ts.ERROR){let e=this.diffTask.error;return H`<div class="callout danger">${N(e)}</div>`}if(this.loading)return Fl(`review`,L(`chat.sessionDiff.loading`));let e=this.diffTask.value;if(!e)return G;let{result:t,views:n}=e;return t.unavailableReason===`not_git`?H`<div class="session-diff__note">${L(`chat.sessionDiff.notGit`)}</div>`:t.unavailableReason===`unknown_session`?H`<div class="session-diff__note">${L(`chat.sessionDiff.unknownSession`)}</div>`:H`
      ${this.renderSummary(t)}
      ${t.unavailableReason===`workspace_stopped`?H`<div class="session-diff__note">${L(`chat.sessionDiff.workspaceStopped`)}</div>`:G}
      <button
        class="session-diff__section-title"
        type="button"
        aria-label=${L(`chat.sessionDiff.scopeMenu`)}
        @click=${e=>this.openAnchoredMenu(e,{kind:`scope`,active:this.scope,result:t},`bottom-start`)}
      >
        <span>${this.scopeTitle(t)}</span>${z.chevronDown}
      </button>
      <div class="session-diff__files">
        ${t.unavailableReason===`unknown_commit`?H`<div class="session-diff__note">${L(`chat.sessionDiff.unknownCommit`)}</div>`:t.files.length===0?t.unavailableReason===`workspace_stopped`||t.truncated===!0?G:H`<div class="session-diff__note">${L(`chat.sessionDiff.empty`)}</div>`:n.map(e=>this.renderFile(e,t))}
        ${t.truncated===!0?H`<div class="session-diff__note">${L(`chat.sessionDiff.truncatedResult`)}</div>`:G}
      </div>
      ${this.renderFooter(t)}
    `}render(){return H`
      <div
        class="session-diff ${this.wrap?`session-diff--wrap`:``}"
        aria-busy=${String(this.loading)}
      >
        ${this.renderBody()}
        ${this.menu?Y(this.menu,H`<openclaw-session-diff-menu
                  .menu=${this.menu}
                  .onAction=${e=>this.handleMenuAction(e)}
                  .onClose=${()=>{this.menu=null}}
                ></openclaw-session-diff-menu>`):G}
      </div>
    `}},k([X({attribute:!1})],dw.prototype,`execNode`,void 0),k([X({attribute:!1})],dw.prototype,`loader`,void 0),k([X({attribute:!1})],dw.prototype,`loadFileText`,void 0),k([X({attribute:!1})],dw.prototype,`openFile`,void 0),k([X({attribute:!1})],dw.prototype,`revealFile`,void 0),k([J()],dw.prototype,`collapsedPaths`,void 0),k([J()],dw.prototype,`menu`,void 0),k([J()],dw.prototype,`scope`,void 0),k([J()],dw.prototype,`split`,void 0),k([J()],dw.prototype,`wrap`,void 0),customElements.get(`openclaw-session-diff`)||customElements.define(`openclaw-session-diff`,dw)})))()}function pw(e,t,n,r,i){if(e.download&&i)return H`${ph({kind:`document`,label:e.title,mimeType:e.mimeType??void 0,sizeBytes:e.sizeBytes,onDownload:i.onDownload,downloadPending:i.pending})}${i.error?H`<div role="alert">${i.error}</div>`:G}`;let a=e.resolveSource?.(t,n),o=a?a.status===`ready`?a:null:e,s=e.mimeType?.split(`;`,1)[0]?.trim().toLowerCase()??``,c=e.attachmentKind===`video`||s.startsWith(`video/`)?`video`:e.attachmentKind===`audio`||s.startsWith(`audio/`)?`audio`:e.attachmentKind===`image`||s.startsWith(`image/`)?`image`:`document`,l=(e.plainText?Ch:c===`audio`||c===`video`?Sh:xh)(o?.src??``),u=o?.authToken??null,d=a?.status===`pending`,f=(s===`image/svg+xml`||(!s||s===`application/octet-stream`)&&(da(e.sourceIdentity??``,void 0)||da(l??``,void 0)||da(e.title,void 0)))&&bh(l??``),p=(l||d)&&!f&&c===`image`;if((l||d)&&c===`document`&&UC(s,e.title)&&!bh(l??``))return H`<openclaw-chat-pdf-preview
      .src=${l??``}
      .sourceIdentity=${[n.connectionEpoch??``,n.agentId??``,n.sessionKey??``,e.sourceIdentity??l??``].join(`\0`)}
      .label=${e.title}
      .mimeType=${e.mimeType??``}
      .sizeBytes=${o?.sizeBytes??e.sizeBytes}
      .downloadHref=${l??``}
    ></openclaw-chat-pdf-preview>`;if((l||d)&&JC(s,e.title)&&!bh(l??``))return H`<openclaw-chat-text-attachment
      .compact=${!0}
      .plainText=${e.plainText??!1}
      .actions=${e.renderActions?.()??G}
      .embedSandboxMode=${r}
      .src=${l??``}
      .sourceIdentity=${[n.connectionEpoch??``,n.agentId??``,n.sessionKey??``,e.sourceIdentity??l??``].join(`\0`)}
      .label=${e.title}
      .mimeType=${e.mimeType??``}
      .sizeBytes=${o?.sizeBytes??e.sizeBytes}
    ></openclaw-chat-text-attachment>`;if(c===`video`&&(l||d))return H`<openclaw-chat-video-player
      .src=${l??``}
      .preview=${!0}
      .sourceIdentity=${e.sourceIdentity??e.src??l??``}
      .label=${e.title}
      .mimeType=${e.mimeType??``}
      .playback=${o?.playback??e.playback??`native`}
      .authToken=${u}
      .sizeBytes=${o?.sizeBytes??e.sizeBytes}
      .mediaWidth=${o?.width??e.width}
      .mediaHeight=${o?.height??e.height}
    ></openclaw-chat-video-player>`;if(!l||p){let t=o?.width??e.width,n=o?.height??e.height;return H`
      <div
        class="chat-assistant-attachment-card chat-assistant-attachment-card--${c} sidebar-attachment-preview__state-card"
        aria-busy=${d?`true`:G}
      >
        ${_h({kind:c,label:e.title,mimeType:e.mimeType??void 0,sizeBytes:o?.sizeBytes??e.sizeBytes,downloadHref:l??void 0,downloadPending:d,visualMode:`preview-with-favicon`})}
        <div
          class="sidebar-attachment-preview__state"
          style=${nr({"--preview-ratio":t&&n?`${t} / ${n}`:void 0})}
        >
          ${d||p?mh():G}
          ${p&&l?Y(l,H`<img
                    class="sidebar-attachment-preview__image"
                    src=${l}
                    alt=${e.title}
                    .onload=${function(){this.dataset.preview=`ready`}}
                    .onerror=${function(){this.dataset.preview=`error`}}
                  />`):G}
          ${d?G:H`<div class="sidebar-attachment-preview__unavailable">
                  ${L(`chat.attachments.previewUnavailable`)}
                  ${a?.status===`error`?H`<span>${a.reason}</span>`:G}
                  ${(a?.status===`error`||a?.status===`unavailable`)&&a.onRetry?H`<button class="btn btn--sm" type="button" @click=${a.onRetry}>
                          ${L(`common.retry`)}
                        </button>`:G}
                </div>`}
        </div>
      </div>
    `}return c===`audio`?H`<openclaw-chat-audio-player
      .src=${l}
      .sourceIdentity=${e.sourceIdentity??e.src??l}
      .label=${e.title}
      .mimeType=${e.mimeType??``}
      .playback=${o?.playback??e.playback??`native`}
      .authToken=${u}
      .sizeBytes=${o?.sizeBytes??e.sizeBytes}
      .serverDurationMs=${o?.durationMs??e.durationMs}
      .voiceNote=${e.voiceNote===!0}
    ></openclaw-chat-audio-player>`:ph({kind:e.attachmentKind??`document`,label:e.title,mimeType:e.mimeType??void 0,sizeBytes:o?.sizeBytes??e.sizeBytes,downloadHref:l})}function mw(e){if(!e)return null;if(e.kind===`markdown`||e.kind===`file`){let t=e.rawText??e.content;return{kind:`markdown`,content:ud(t,e.kind===`file`?e.language:void 0),rawText:t}}return e.rawText?.trim()?{kind:`markdown`,content:ud(e.rawText,`json`),rawText:e.rawText}:null}function hw(e){let t=e.content,n=t?.kind===`markdown`&&t.content.trim()?Wc(t.content,{codeBlockInteraction:`interactive`,fileLinks:!0,githubRepo:e.githubRepo??null,githubRepositories:e.githubRepositories,interactiveImages:e.onOpenImage!==void 0,sessionLinks:!0}):``,r=t?.kind===`canvas`?Fr(e.embedSandboxMode??`scripts`,t.sandbox):``,i=t?.kind===`canvas`?co(t.entryUrl,e.canvasPluginSurfaceUrl,e.allowExternalEmbedUrls??!1):null,a=t?.kind===`canvas`?t.title?.trim()||L(`chat.detailPanel.renderPreview`):t?.kind===`image`?t.title.trim()||L(`chat.detailPanel.imagePreview`):t?.kind===`attachment`?t.title.trim()||L(`chat.detailPanel.file`):t?.kind===`file`?t.name.trim()||L(`chat.detailPanel.file`):t?.kind===`session-diff`?L(`chat.sessionDiff.title`):t?.kind===`markdown`?L(e.showingRawText?`chat.detailPanel.viewSource`:`chat.detailPanel.markdownPreview`):L(`chat.detailPanel.toolDetails`);return H`
    <div class="sidebar-panel">
      ${e.embedded?G:H`<div class="sidebar-header">
              <div class="sidebar-title">${a}</div>
              <div class="sidebar-header__actions">
                <openclaw-tooltip .content=${L(`chat.detailPanel.close`)}>
                  <button
                    @click=${e.onClose}
                    class="btn"
                    type="button"
                    aria-label=${L(`chat.detailPanel.close`)}
                  >
                    ${z.x}
                  </button>
                </openclaw-tooltip>
              </div>
            </div> `}
      <div class="sidebar-content">
        ${e.error?H`
                ${Mn({error:e.error,stale:zt(e.error),onRetry:e.onRetry})}
                ${t?.kind===`file`||t?.rawText?.trim()?H`
                        <button
                          @click=${e.onViewRawText}
                          class="btn"
                          type="button"
                          style="margin-top: 12px;"
                        >
                          ${L(`chat.detailPanel.viewRawText`)}
                        </button>
                      `:G}
              `:t?t.kind===`file`?DC(t,e.onViewRawText,e.fileView):t.kind===`session-diff`?H`<openclaw-session-diff
                      .loader=${t.load}
                      .loadFileText=${t.loadFileText??null}
                      .execNode=${e.fileView?.execNode??null}
                      .openFile=${t.openFile??null}
                      .revealFile=${e.fileView?.onReveal??null}
                    ></openclaw-session-diff>`:t.kind===`canvas`||t.kind===`image`?Y(t.kind,H`
                          <div class="chat-tool-card__preview" data-kind=${t.kind}>
                            <div class="chat-tool-card__preview-panel" data-side="front">
                              ${t.kind===`canvas`?Y(`${r}\u0000${i??``}\u0000${t.preferredHeight??``}`,H`<iframe
                                        class="chat-tool-card__preview-frame"
                                        title=${a}
                                        sandbox=${r}
                                        src=${i??G}
                                        style=${t.preferredHeight?`height:${t.preferredHeight}px`:``}
                                      ></iframe>`):H`<button
                                      type="button"
                                      class="chat-tool-card__preview-image-button"
                                      aria-label=${L(`chat.imageLightbox.open`,{title:a})}
                                      @click=${()=>s_(e.onOpenImage,t.src,a)}
                                    >
                                      <img
                                        class="chat-tool-card__preview-image"
                                        src=${t.src}
                                        alt=${a}
                                        style="display:block;max-width:100%;height:auto;border-radius:8px;"
                                      />
                                    </button>`}
                            </div>
                            ${t.rawText?.trim()?H`
                                    <div style="margin-top: 12px;">
                                      <button
                                        @click=${e.onViewRawText}
                                        class="btn"
                                        type="button"
                                      >
                                        ${L(`chat.detailPanel.viewRawText`)}
                                      </button>
                                    </div>
                                  `:G}
                          </div>
                        `):t.kind===`attachment`?H`<div class="sidebar-attachment-preview">
                          ${pw(t,e.onAttachmentUpdate,e.attachmentRuntime,e.embedSandboxMode??`scripts`,e.attachmentDownload)}
                        </div>`:H`
                          <section class="sidebar-markdown-shell">
                            <div class="sidebar-markdown-shell__toolbar">
                              <div class="sidebar-markdown-shell__intro">
                                <div class="sidebar-markdown-shell__eyebrow">
                                  ${z.scrollText}
                                  <span
                                    >${L(e.showingRawText?`chat.detailPanel.viewSource`:`chat.detailPanel.renderedMarkdown`)}</span
                                  >
                                </div>
                                ${e.showingRawText?G:H`
                                        <div class="sidebar-markdown-shell__hint">
                                          ${L(`chat.detailPanel.renderedMarkdownHint`)}
                                        </div>
                                      `}
                              </div>
                              ${e.showingRawText?G:H`
                                      <button
                                        @click=${e.onViewRawText}
                                        class="btn btn--sm"
                                        type="button"
                                      >
                                        ${L(`chat.detailPanel.viewRawText`)}
                                      </button>
                                    `}
                            </div>
                            ${n?H`
                                    <article
                                      class="sidebar-markdown-reader sidebar-markdown"
                                      dir=${ra(t.content)}
                                    >
                                      ${lr(n)}
                                    </article>
                                  `:H`
                                    <div class="sidebar-markdown-empty">
                                      ${L(`chat.detailPanel.noPreviewableMarkdown`)}
                                    </div>
                                  `}
                          </section>
                        `:H` <div class="muted">${L(`chat.detailPanel.noContent`)}</div> `}
      </div>
    </div>
  `}function gw(e){let t=e.content?.kind===`file`||e.content?.kind===`markdown`||e.content?.kind===`attachment`||e.content?.kind===`session-diff`;return H`
    <div
      class=${t?`sidebar-panel-host--fill`:``}
      ${e.content?.kind===`attachment`?G:Ol()}
      @click=${e.onClick}
      @keydown=${e.onKeydown}
    >
      ${hw(e)}
    </div>
  `}function _w(e,t){if(BC(e,t.onOpenImage??void 0))return;tc(e);let n=Dc(e);if(n){t.onOpenWorkspaceFile?.(n);return}let r=xl(e,t.basePath);r&&Ie(e)&&(e.preventDefault(),t.onOpenSessionLink?.(r))}function vw(e,t){let n=rc(e);if(n){t.onOpenWorkspaceFile?.(n);return}let r=cl(e,t.basePath);r&&t.onOpenSessionLink?.(r)}function yw(){return(yw=e((()=>{K(),sr(),rr(),dr(),qt(),B(),fn(),Uc(),Ks(),ql(),Nl(),Il(),V(),R(),gs(),Gr(),li(),ua(),yh(),Eh(),HC(),bg(),Eg(),c_(),qC(),AC(),XC(),fw(),Ta()})))()}var Q;function bw(){return(bw=e((()=>{T(),ar(),Dl(),qt(),R(),gs(),Eo(),ft(),tt(),vC(),MC(),lC(),LC(),Qp(),yw(),AC(),t(),Ta(),Q=class extends gt{constructor(){super(),this.content=null,this.fileNavigation=null,this.execNode=null,this.attachmentRuntime={},this.basePath=``,this.canvasPluginSurfaceUrl=null,this.embedSandboxMode=`scripts`,this.allowExternalEmbedUrls=!1,this.githubContext={},this.embedded=!1,this.onOpenWorkspaceFile=null,this.onOpenSessionLink=null,this.onRevealInWorkspace=null,this.onOpenImage=null,this.visibleContent=null,this.error=null,this.fileSearchOpen=!1,this.fileWrap=xC(),this.fileSearchQuery=``,this.fileSearchMatchIndex=0,this.fileEditorMenuOpen=!1,this.fileCopy=new jC(this,()=>this.visibleContent),this.fileEditorLoading=!1,this.fileEditing=!1,this.fileDirty=!1,this.fileReloading=!1,this.fileSaving=!1,this.fileSaveNotice=null,this.htmlPreview=new IC(this,()=>this.visibleContent,()=>this.currentFileText()),this.fileOperationVersion=0,this.showingRawText=!1,this.rawFileContent=null,this.fileEditor=null,this.fileEditorLoad=null,this.fileDraftContent=null,this.fileSavedContent=``,this.fileHash=``,this.requestAttachmentUpdate=()=>this.requestUpdate(),this.attachmentDownload=new _C(this,()=>this.content===this.visibleContent?this.content:null,()=>this.attachmentRuntime),this.toggleHtmlSource=()=>{this.fileSearchOpen=!1,this.htmlPreview.toggle()},this.retryFileEditor=()=>{let e=this.error,t=this.fileOperationVersion;zt(e)?Ut({canReload:()=>this.isConnected&&this.error===e&&t===this.fileOperationVersion}):this.error=null},this.handleDocumentPointerDown=e=>{if(!this.fileEditorMenuOpen)return;let t=this.querySelector(`.sidebar-file-view__editor`);(!t||!e.composedPath().includes(t))&&(this.fileEditorMenuOpen=!1)},this.toggleFileWrap=()=>{this.fileWrap=!this.fileWrap,SC(this.fileWrap)},this.toggleFileSearch=()=>{if(this.htmlPreview.showSource(),this.fileSearchOpen=!this.fileSearchOpen,this.fileEditorMenuOpen=!1,!this.fileSearchOpen){this.fileSearchQuery=``,this.fileSearchMatchIndex=0;return}this.updateComplete.then(()=>{this.querySelector(`.file-view__search input`)?.focus()})},this.updateFileSearch=e=>{this.fileSearchQuery=e,this.fileSearchMatchIndex=0,this.scrollToCurrentFileMatch()},this.handleFileSearchKeydown=e=>{if(e.key===`Escape`){e.preventDefault(),e.stopPropagation(),this.toggleFileSearch(),this.querySelector(`.sidebar-file-view__search-toggle`)?.focus({preventScroll:!0});return}e.key===`Enter`&&e.target instanceof HTMLInputElement&&(e.preventDefault(),this.moveFileSearch(e.shiftKey?-1:1))},this.openInEditor=e=>{let t=this.visibleContent;if(t?.kind!==`file`)return;let n=Xc(t,this.execNode);n&&(this.fileEditorMenuOpen=!1,Ho(e,n,this.fileNavigation?.line??t.line))},this.editFile=async()=>{let e=this.visibleContent;if(e?.kind===`file`&&e.edit&&(this.htmlPreview.showSource(),await this.updateComplete,await this.ensureFileEditor(),this.visibleContent===e&&this.fileEditor)){if(this.fileEditing){this.fileEditor.focus();return}this.fileSavedContent=e.content,this.fileHash=e.edit.hash,this.fileDirty=!1,this.fileSaveNotice=null,this.fileSearchOpen=!1,this.fileSearchQuery=``,this.fileSearchMatchIndex=0,this.fileEditorMenuOpen=!1,this.fileEditing=!0,this.fileEditor.setEditable(!0),this.updateComplete.then(()=>this.fileEditor?.focus())}},this.discardFileEdits=()=>{if(!this.fileEditing||this.fileSaving)return;this.fileEditor?.setContent(this.fileSavedContent),this.fileDraftContent=null,this.htmlPreview.discard(this.fileSavedContent);let e=this.visibleContent;e?.kind===`file`&&(iC(e,null),this.fileHash=e.edit?.hash??``),this.fileDirty=!1,this.fileSaveNotice=null,this.fileEditing=!1,this.fileEditor?.setEditable(!1)},this.saveFile=()=>{let e=this.visibleContent;if(e?.kind!==`file`||!e.edit||!this.fileEditing||!this.fileDirty||this.fileSaving)return;let t=this.fileOperationVersion;this.fileSaving=!0,this.fileSaveNotice=null,this.trackFileOperation(this.saveFileContent(e,this.currentFileText(),this.fileHash,t),t)},this.reloadFile=()=>{let e=this.visibleContent;if(e?.kind!==`file`||!e.edit||this.fileSaving)return;let t=this.fileOperationVersion;this.fileSaving=!0,this.fileReloading=!0,this.fileEditor?.setEditable(!1),this.trackFileOperation(e.edit.fetchLatest().then(e=>{if(t===this.fileOperationVersion&&this.visibleContent?.kind===`file`){if(!e){this.fileSaveNotice={kind:`error`,message:L(`chat.detailPanel.reloadFailed`)};return}if(this.fileEditor?.setContent(e.content),this.fileDraftContent=this.fileEditor?null:e.content,this.htmlPreview.discard(e.content),this.updateSavedFile(this.visibleContent,e.content,e.hash),!e.editable&&this.visibleContent?.kind===`file`){iC(this.visibleContent,null),this.fileEditing=!1,this.fileDirty=!1;let{edit:e,...t}=this.visibleContent;this.visibleContent=t}}}),t)},this.overwriteFile=()=>{let e=this.visibleContent;if(e?.kind!==`file`||!e.edit||this.fileSaving)return;let t=this.fileOperationVersion,n=this.currentFileText();this.fileSaving=!0,this.trackFileOperation(e.edit.fetchLatest().then(async r=>{if(t===this.fileOperationVersion){if(!r){this.fileSaveNotice={kind:`error`,message:L(`chat.detailPanel.overwriteLoadFailed`)};return}await this.saveFileContent(e,n,r.hash,t)}}),t)},this.close=()=>{this.dispatchEvent(new CustomEvent(`chat-detail-panel-close`,{bubbles:!0}))},this.showRawText=()=>{if(this.htmlPreview.file){this.htmlPreview.showSource();return}let e=mw(this.visibleContent);e&&(this.rawFileContent=this.visibleContent?.kind===`file`?this.visibleContent:null,this.showingRawText=!0,this.destroyFileEditor(),this.visibleContent=e,this.error=null)},this.handlePanelClick=e=>{_w(e,this)},this.handlePanelKeyDown=e=>{vw(e,this)},_l(this)}connectedCallback(){super.connectedCallback(),document.addEventListener(`pointerdown`,this.handleDocumentPointerDown)}disconnectedCallback(){this.attachmentDownload.cancel(),document.removeEventListener(`pointerdown`,this.handleDocumentPointerDown),this.fileDirty&&(this.fileDraftContent=this.currentFileText()),this.destroyFileEditor(),Fp(this.requestAttachmentUpdate),super.disconnectedCallback()}willUpdate(e){let t=e.get(`attachmentRuntime`);if(t&&typeof t==`object`&&`connectionEpoch`in t&&t.connectionEpoch!==this.attachmentRuntime.connectionEpoch&&(Fp(this.requestAttachmentUpdate),this.attachmentDownload.cancel()),e.has(`fileNavigation`)&&this.fileNavigation&&this.content?.kind===`file`&&this.htmlPreview.showSource(),!e.has(`content`)){e.has(`fileNavigation`)&&this.fileNavigation&&this.content?.kind===`file`&&this.showingRawText&&(this.showingRawText=!1,this.visibleContent=this.rawFileContent??this.content,this.rawFileContent=null);return}Fp(this.requestAttachmentUpdate),this.attachmentDownload.cancel(),this.visibleContent=this.content,this.error=null,this.showingRawText=!1,this.rawFileContent=null,this.fileSearchOpen=!1,this.fileSearchQuery=``,this.fileSearchMatchIndex=0,this.fileEditorMenuOpen=!1,this.fileCopy.reset(),this.fileOperationVersion+=1,this.fileEditing=!1,this.fileDirty=!1,this.fileReloading=!1,this.fileSaving=!1,this.fileSaveNotice=null;let n=this.content?.kind===`file`&&this.content.edit?nC(this.content):void 0,r=this.content?.kind===`file`&&n?.content!==this.content.content?n:void 0;n&&!r&&this.content?.kind===`file`&&iC(this.content,null),this.fileDraftContent=r?.content??null,this.fileSavedContent=this.content?.kind===`file`?this.content.content:``,this.fileHash=r?.expectedHash??(this.content?.kind===`file`?this.content.edit?.hash??``:``),this.fileEditing=!!r,this.fileDirty=!!r,this.htmlPreview.reset(this.fileDraftContent,!!(this.fileNavigation||this.content?.kind===`file`&&this.content.line!=null)),this.fileEditorLoading=this.content?.kind===`file`&&!this.htmlPreview.showing,this.destroyFileEditor()}updated(e){let t=this.visibleContent;t?.kind===`file`&&!this.showingRawText&&!this.htmlPreview.showing&&!this.error&&this.ensureFileEditor().then(()=>{this.syncFileEditor(),(e.has(`content`)||e.has(`fileNavigation`))&&(this.fileNavigation?.line??t.line)!=null&&this.scrollToFileLine(t)})}currentFileText(){return this.fileEditor?.getContent()??this.fileDraftContent??(this.visibleContent?.kind===`file`?this.visibleContent.content:``)}scrollToFileLine(e){let t=this.fileNavigation?.line??e.line;this.visibleContent===e&&!this.showingRawText&&t!=null&&this.fileEditor?.scrollToLine(t,!0)}destroyFileEditor(){this.fileOperationVersion+=1,this.fileEditor?.destroy(),this.fileEditor=null,this.fileEditorLoad=null}ensureFileEditor(){if(this.fileEditor)return Promise.resolve();if(this.fileEditorLoad)return this.fileEditorLoad;let e=this.visibleContent,t=this.querySelector(`.file-view__mount`);if(e?.kind!==`file`||!t||this.htmlPreview.showing)return Promise.resolve();let n=this.fileOperationVersion;return this.fileEditorLoading=!0,this.fileEditorLoad=ne(async()=>{let{createFileEditorView:e}=await import(`./file-editor-view-FK2Mdezs.js`);return{createFileEditorView:e}},__vite__mapDeps([16,10,11,5]),import.meta.url).then(async({createFileEditorView:e})=>{let r=this.visibleContent;if(n!==this.fileOperationVersion||r?.kind!==`file`)return;let i=await e({parent:t,content:this.fileDraftContent??r.content,name:r.name,editable:this.fileEditing,wrap:this.fileWrap,onSave:this.saveFile});if(n!==this.fileOperationVersion||!this.isConnected||this.visibleContent?.kind!==`file`){i.destroy();return}i.setContent(this.currentFileText()),this.fileEditor=i,this.fileDraftContent=null,i.onDocChanged(e=>{let t=rC(r,{editing:this.fileEditing&&!this.fileReloading,content:e,dirty:!i.contentEquals(this.fileSavedContent),expectedHash:this.fileHash});t&&(this.fileDirty=t.dirty,this.fileHash=t.expectedHash,this.fileSaveNotice?.kind===`error`&&(this.fileSaveNotice=null))})}).catch(e=>{n===this.fileOperationVersion&&this.isConnected&&(this.error=c(e,L(`lazyView.errorTitle`)),zt(this.error)&&Kt())}).finally(()=>{n===this.fileOperationVersion&&(this.fileEditorLoad=null,this.fileEditorLoading=!1)}),this.fileEditorLoad}syncFileEditor(){let e=this.visibleContent,t=this.fileEditor;if(e?.kind!==`file`||!t)return;this.fileEditing||t.setContent(e.content),t.setEditable(this.fileEditing&&!this.fileReloading),t.setLineWrapping(this.fileWrap);let n=this.fileSearchMatches();t.setDecorations({targetLine:this.fileNavigation?.line??e.line,matches:n,currentMatch:n[this.fileSearchMatchIndex]??null})}fileSearchMatches(){let e=this.visibleContent;return e?.kind===`file`?wC(e.content,this.fileSearchQuery):[]}async scrollToCurrentFileMatch(){await this.updateComplete;let e=this.fileSearchMatches()[this.fileSearchMatchIndex];e!=null&&this.fileEditor?.scrollToLine(e,!0)}moveFileSearch(e){let t=this.fileSearchMatches();t.length!==0&&(this.fileSearchMatchIndex=(this.fileSearchMatchIndex+e+t.length)%t.length,this.scrollToCurrentFileMatch())}updateSavedFile(e,t,n){let r=this.currentFileText();this.fileSavedContent=t,this.fileHash=n,this.fileDirty=!(this.fileEditor?.contentEquals(t)??r===t),this.fileDraftContent=!this.fileEditor&&this.fileDirty?r:null,iC(e,this.fileDirty?{content:r,expectedHash:n}:null),this.fileSaveNotice=null,e.content=t,e.rawText=t,e.edit&&(e.edit.hash=n)}async saveFileContent(e,t,n,r){if(!e.edit)return;let i=await e.edit.save({content:t,expectedHash:n});r===this.fileOperationVersion&&this.visibleContent?.kind===`file`&&(i.ok?this.updateSavedFile(this.visibleContent,t,i.hash):this.fileSaveNotice=i.code===`conflict`?{kind:`conflict`}:{kind:`error`,message:i.message})}trackFileOperation(e,t){e.catch(e=>{t===this.fileOperationVersion&&(this.fileSaveNotice={kind:`error`,message:N(e)})}).finally(()=>{t===this.fileOperationVersion&&(this.fileSaving=!1,this.fileReloading&&(this.fileReloading=!1,this.fileEditor?.setEditable(this.fileEditing)))})}render(){let e=this.htmlPreview.file,t=this.fileSearchMatches(),n=t.length?Math.min(this.fileSearchMatchIndex,t.length-1):0;return gw({content:this.visibleContent,showingRawText:this.showingRawText,error:e?null:this.error,onRetry:this.retryFileEditor,fileView:{htmlPreview:this.htmlPreview.controls({error:this.error,onRetry:this.retryFileEditor,onToggle:this.toggleHtmlSource,runtime:this.attachmentRuntime,mode:this.embedSandboxMode}),copyFeedback:this.fileCopy.feedback,currentMatchIndex:n,dirty:this.fileDirty,execNode:this.execNode,editorMenuOpen:this.fileEditorMenuOpen,editing:this.fileEditing,loadingEditor:this.fileEditorLoading,mountKey:this.fileOperationVersion,matches:t,query:this.fileSearchQuery,saveNotice:this.fileSaveNotice,saving:this.fileSaving,searchOpen:this.fileSearchOpen,wrap:this.fileWrap,onCopy:this.fileCopy.copy,onDiscard:this.discardFileEdits,onEdit:()=>void this.editFile(),onNextMatch:()=>this.moveFileSearch(1),onOpenEditor:this.openInEditor,onOverwrite:this.overwriteFile,onPreviousMatch:()=>this.moveFileSearch(-1),onReload:this.reloadFile,onReveal:this.onRevealInWorkspace??void 0,onSave:this.saveFile,onSearchInput:this.updateFileSearch,onSearchKeydown:this.handleFileSearchKeydown,onEditorMenuOpenChange:e=>{this.fileEditorMenuOpen=e},onToggleSearch:this.toggleFileSearch,onToggleWrap:this.toggleFileWrap},canvasPluginSurfaceUrl:this.canvasPluginSurfaceUrl,embedSandboxMode:this.embedSandboxMode,allowExternalEmbedUrls:this.allowExternalEmbedUrls,...this.githubContext,embedded:this.embedded,onClose:this.close,onOpenImage:this.onOpenImage??void 0,onViewRawText:this.showRawText,onClick:this.handlePanelClick,onKeydown:this.handlePanelKeyDown,onAttachmentUpdate:this.requestAttachmentUpdate,attachmentRuntime:this.attachmentRuntime,attachmentDownload:this.attachmentDownload})}},k([X({attribute:!1})],Q.prototype,`content`,void 0),k([X({attribute:!1})],Q.prototype,`fileNavigation`,void 0),k([X({attribute:!1})],Q.prototype,`execNode`,void 0),k([X({attribute:!1})],Q.prototype,`attachmentRuntime`,void 0),k([X()],Q.prototype,`basePath`,void 0),k([X()],Q.prototype,`canvasPluginSurfaceUrl`,void 0),k([X()],Q.prototype,`embedSandboxMode`,void 0),k([X({type:Boolean})],Q.prototype,`allowExternalEmbedUrls`,void 0),k([X({attribute:!1})],Q.prototype,`githubContext`,void 0),k([X({type:Boolean})],Q.prototype,`embedded`,void 0),k([X({attribute:!1})],Q.prototype,`onOpenWorkspaceFile`,void 0),k([X({attribute:!1})],Q.prototype,`onOpenSessionLink`,void 0),k([X({attribute:!1})],Q.prototype,`onRevealInWorkspace`,void 0),k([X({attribute:!1})],Q.prototype,`onOpenImage`,void 0),k([J()],Q.prototype,`visibleContent`,void 0),k([J()],Q.prototype,`error`,void 0),k([J()],Q.prototype,`fileSearchOpen`,void 0),k([J()],Q.prototype,`fileWrap`,void 0),k([J()],Q.prototype,`fileSearchQuery`,void 0),k([J()],Q.prototype,`fileSearchMatchIndex`,void 0),k([J()],Q.prototype,`fileEditorMenuOpen`,void 0),k([J()],Q.prototype,`fileEditorLoading`,void 0),k([J()],Q.prototype,`fileEditing`,void 0),k([J()],Q.prototype,`fileDirty`,void 0),k([J()],Q.prototype,`fileReloading`,void 0),k([J()],Q.prototype,`fileSaving`,void 0),k([J()],Q.prototype,`fileSaveNotice`,void 0),customElements.get(`openclaw-chat-detail-panel`)||customElements.define(`openclaw-chat-detail-panel`,Q)})))()}function xw(){return(xw=e((()=>{bw(),AC()})))()}function Sw(e){return typeof e!=`number`||!Number.isFinite(e)||e<0?``:f(e,{style:`legacy-binary`,maxUnit:`mega`,separator:` `,fractionDigits:(e,t)=>t===`byte`?null:Math.round(e*10)%10?1:0})}function Cw({icon:e,label:t,onClick:n,className:r=``}){return n?H`
        <openclaw-tooltip .content=${t}>
          <button
            type="button"
            class="rail-header__action chat-workspace-rail__terminal ${r}"
            aria-label=${t}
            @click=${n}
          >
            ${e}
          </button>
        </openclaw-tooltip>
      `:G}function ww({icon:e,name:t,meta:n,tooltip:r=t,badge:i=G,actions:a=G,onOpen:o,active:s=!1,directory:c=!1}){return H`
    <div
      class="chat-workspace-rail__file ${c?`chat-workspace-rail__file--directory`:``}
      ${s?`chat-workspace-rail__file--active`:``}"
      role="listitem"
    >
      <button
        class="chat-workspace-rail__file-open"
        type="button"
        aria-label=${r}
        @click=${o}
      >
        <span class="chat-workspace-rail__file-icon">${e}</span>
        <span class="chat-workspace-rail__file-main">
          <openclaw-tooltip .content=${r}>
            <span class="chat-workspace-rail__file-name">${t}</span>
          </openclaw-tooltip>
          ${n?H`<span class="chat-workspace-rail__file-meta">${n}</span>`:G}
        </span>
      </button>
      ${i} ${a}
    </div>
  `}function Tw(e,t={}){if(!e||e.collapsed&&!t.embedded)return G;let n=e.narrowLayout?`bottom`:e.dock,r=e.list?.files??[],i=Yl(r.map(e=>e.path||e.name)),a=e.list?.artifacts??[],o=e.list?.browser,s=o?.entries??[],c=ee(e.browserSearch)?.toLowerCase()??``,l=(...e)=>e.some(e=>e?.toLowerCase().includes(c)),u=r.filter(e=>e.kind===`modified`),d=r.filter(e=>e.kind===`read`),f=e=>e.filter(e=>l(e.path,e.name)),p=f(u),m=f(d),h=a.filter(e=>l(e.title,e.id,e.mimeType)),g=r.length>0||a.length>0||s.length>0,_=[{filter:`all`,label:L(`chat.workspaceFiles.filterAll`),count:r.length+a.length},{filter:`changed`,label:L(`chat.workspaceFiles.changedCount`,{count:String(u.length)}),count:u.length},{filter:`read`,label:L(`chat.workspaceFiles.readCount`,{count:String(d.length)}),count:d.length},{filter:`artifacts`,label:L(`chat.workspaceFiles.artifactCount`,{count:String(a.length)}),count:a.length}],v=_.some(({filter:t,count:n})=>t===e.filter&&n>0)?e.filter:`all`,y=(e,t)=>H`
    <span
      class="chat-workspace-rail__row-actions"
      role="group"
      aria-label=${L(`chat.workspaceFiles.actions`)}
    >
      <openclaw-tooltip .content=${L(`chat.workspaceFiles.preview`)}>
        <button
          class="chat-workspace-rail__row-action"
          type="button"
          aria-label=${L(`chat.workspaceFiles.preview`)}
          @click=${t=>{t.stopPropagation(),e()}}
        >
          ${z.eye}
        </button>
      </openclaw-tooltip>
      ${t===void 0?G:H` <span @click=${e=>e.stopPropagation()}>
              ${Pc(t,L(`chat.workspaceFiles.copyPath`))}
            </span>`}
    </span>
  `,b=t=>t.length===0?G:H`
          <div class="chat-workspace-rail__list" role="list">
            ${t.map(t=>{let n=()=>e.onOpenFile(t.path,`session`);return ww({icon:z.fileText,name:i.get(t.path||t.name)??t.name,tooltip:t.path||t.name,meta:Sw(t.size),onOpen:n,active:ho(e.activeId,e.list?.root,t.path,t.workspacePath),badge:t.missing?H`<span class="chat-workspace-rail__file-badge"
                      >${L(`chat.workspaceFiles.missing`)}</span
                    >`:G,actions:y(n,t.path)})})}
          </div>
        `,x=!o&&e.list!==null&&!e.loading&&!c&&e.browserPath!==``,S=x?e.browserPath.slice(0,Math.max(0,e.browserPath.lastIndexOf(`/`))):o?.search?null:o?.parentPath,C=()=>H`
    ${o?.search?H`<div class="chat-workspace-rail__browser-caption">${L(`chat.workspaceFiles.searchResults`)}</div>`:G}
    <div class="chat-workspace-rail__list chat-workspace-rail__list--browser" role="list">
      ${S==null?G:ww({icon:z.folder,name:`..`,directory:!0,meta:L(`chat.workspaceFiles.parentFolder`),onOpen:()=>e.onBrowsePath(S)})}
      ${s.length===0?H`<div class="chat-workspace-rail__state">
              ${L(x?`chat.workspaceFiles.folderUnavailable`:o?.search?`chat.workspaceFiles.noSearchResults`:`chat.workspaceFiles.noBrowserFiles`)}
            </div>`:G}
      ${s.map(t=>{let n=t.kind===`directory`,r=()=>n?e.onBrowsePath(t.path):e.onOpenFile(t.path,`workspace`),i=t.sessionKind;return ww({icon:n?z.folder:z.fileText,name:t.name,tooltip:t.path||t.name,meta:n?t.path||L(`chat.workspaceFiles.root`):[t.path,Sw(t.size)].filter(Boolean).join(` / `),onOpen:r,directory:n,active:ho(e.activeId,e.list?.root,t.path,t.path),badge:i?H`<span
                class="chat-workspace-rail__file-badge chat-workspace-rail__file-badge--kind"
                >${L(Ew[i])}</span
              >`:G,actions:n?G:y(r,t.path)})})}
    </div>
    ${o?.truncated?H`<div class="chat-workspace-rail__state">${L(`chat.workspaceFiles.truncated`)}</div>`:G}
  `,w=()=>h.length===0?G:H`
          <div class="chat-workspace-rail__list" role="list">
            ${h.map(t=>{let n=()=>e.onOpenArtifact(t.id);return ww({icon:t.mimeType?.startsWith(`image/`)?z.image:z.paperclip,name:t.title,meta:[t.mimeType,Sw(t.sizeBytes)].filter(Boolean).join(` / `),onOpen:n,active:`artifact:${t.id}`===e.activeId,actions:y(n)})})}
          </div>
        `,T=!!c||v!==`all`,E=(e,t,n,r,i)=>i===G||v!==`all`&&v!==e?G:Y(T,H`<details class="chat-workspace-rail__group" ?open=${r||T}>
        <summary class="chat-workspace-rail__group-summary">
          <span class="chat-workspace-rail__group-chevron" aria-hidden="true"
            >${z.chevronRight}</span
          >
          ${t}<span class="chat-workspace-rail__group-count">${n}</span>
        </summary>
        ${i}
      </details>`);return H`
    <aside class="chat-workspace-rail" aria-label=${L(`chat.workspaceFiles.label`)}>
      ${t.embedded?G:H`<div class="rail-header chat-workspace-rail__header">
              <div class="rail-header__copy chat-workspace-rail__title">
                <span class="rail-header__eyebrow chat-workspace-rail__eyebrow"
                  >${L(`chat.workspaceFiles.workspace`)}</span
                >
                <strong class="rail-header__title">${L(`chat.workspaceFiles.files`)}</strong>
              </div>
              <div class="rail-header__actions chat-workspace-rail__actions">
                ${Cw({icon:z.diff,label:L(`chat.sessionDiff.show`),onClick:e.onOpenDiff,className:`chat-session-diff-toggle`})}
                ${Cw({icon:z.terminal,label:L(`terminal.toggle`),onClick:e.onToggleTerminal})}
                ${Cw({icon:z.globe,label:L(`browser.toggle`),onClick:e.onToggleBrowser})}
                ${Cw({icon:vn().mascot===`none`?z.shieldCheck:z.lobster,label:L(`custodian.panel.toggle`),onClick:e.onToggleCustodian})}
                ${e.narrowLayout?G:H`
                        <openclaw-tooltip
                          .content=${L(n===`bottom`?`chat.workspaceFiles.dockRight`:`chat.workspaceFiles.dockBottom`)}
                        >
                          <button
                            class="rail-header__action chat-workspace-rail__dock"
                            type="button"
                            aria-label=${L(n===`bottom`?`chat.workspaceFiles.dockRight`:`chat.workspaceFiles.dockBottom`)}
                            @click=${()=>e.onSetDock(n===`bottom`?`right`:`bottom`)}
                          >
                            ${n===`bottom`?z.panelRightOpen:z.panelBottomOpen}
                          </button>
                        </openclaw-tooltip>
                      `}
                <openclaw-tooltip .content=${L(`chat.workspaceFiles.refresh`)}>
                  <button
                    class="rail-header__action chat-workspace-rail__refresh"
                    type="button"
                    aria-label=${L(`chat.workspaceFiles.refresh`)}
                    ?disabled=${e.loading}
                    @click=${e.onRefresh}
                  >
                    ${z.refresh}
                  </button>
                </openclaw-tooltip>
                <openclaw-tooltip
                  .content=${`${L(`chat.workspaceFiles.collapse`)} (${Ce(Me.workspaceFiles)})`}
                  .contentTemplate=${En(L(`chat.workspaceFiles.collapse`),Me.workspaceFiles)}
                >
                  <button
                    type="button"
                    class="rail-header__action chat-workspace-rail__collapse-toggle"
                    aria-label=${L(`chat.workspaceFiles.collapse`)}
                    aria-keyshortcuts=${yt()?`Meta+Shift+B`:`Control+Shift+B`}
                    aria-expanded="true"
                    @click=${e.onToggleCollapsed}
                  >
                    <span class="nav-collapse-toggle__icon" aria-hidden="true"
                      >${n===`bottom`?z.panelBottomClose:z.panelRightClose}</span
                    >
                  </button>
                </openclaw-tooltip>
              </div>
            </div>`}
      ${e.list?.root?H`
              <openclaw-tooltip .content=${e.list.root}>
                <div class="chat-workspace-rail__path">${e.list.root}</div>
              </openclaw-tooltip>
            `:G}
      <div class="chat-workspace-rail__toolbar">
        <label class="chat-workspace-rail__search">
          <span class="chat-workspace-rail__search-icon" aria-hidden="true">${z.search}</span>
          <input
            type="search"
            placeholder=${L(`chat.workspaceFiles.search`)}
            aria-label=${L(`chat.workspaceFiles.search`)}
            .value=${e.browserSearch}
            @input=${t=>e.onSearch(t.currentTarget.value)}
          />
        </label>
        ${r.length||a.length?H` <div
                class="chat-workspace-rail__filters"
                role="group"
                aria-label=${L(`chat.workspaceFiles.filters`)}
              >
                ${_.filter(({count:e})=>e>0).map(({filter:t,label:n})=>H` <button
                      type="button"
                      class="chat-workspace-rail__chip"
                      aria-pressed=${v===t}
                      @click=${()=>e.onSetFilter(t)}
                    >
                      ${n}
                    </button>`)}
              </div>`:G}
      </div>
      ${e.error?H`<div class="chat-workspace-rail__state chat-workspace-rail__state--error">
              ${e.error}
            </div>`:e.loading&&!g?Fl(`files`,L(`chat.workspaceFiles.loading`)):H`
                <div class="chat-workspace-rail__scroll">
                  ${E(`changed`,L(`chat.workspaceFiles.changed`),p.length,!0,b(p))}
                  ${E(`read`,L(`chat.workspaceFiles.read`),m.length,!1,b(m))}
                  ${E(`artifacts`,L(`chat.workspaceFiles.artifacts`),h.length,!1,w())}
                  ${E(null,L(`chat.workspaceFiles.browser`),s.length,!0,o||x?C():G)}
                </div>
              `}
    </aside>
  `}var Ew;function Dw(){return(Dw=e((()=>{K(),sr(),ic(),Jc(),B(),rn(),jn(),Cl(),V(),R(),we(),Ge(),Ew={modified:`chat.workspaceFiles.changed`,read:`chat.workspaceFiles.read`,mixed:`chat.workspaceFiles.session`}})))()}function Ow(e){let t=e.match(/\.([a-z0-9_-]+)$/i)?.[1]?.toLowerCase()??``;return t===`yml`?`yaml`:t}function kw(e){return e.split(/[\\/]/).findLast(e=>e)??e}function Aw(e){let t=e.replace(/\r/g,`\\r`).replace(/\n/g,`\\n`),n=t.startsWith(` `)&&t.endsWith(` `);return dd(n&&!/^ +$/.test(t)?` ${t} `:t)}function jw(e){if(typeof e!=`number`)return null;let t=new Date(e);return Number.isNaN(t.getTime())?null:t.toISOString()}function Mw(e,t){let n=e.workspacePath||e.path||t,r=jw(e.updatedAtMs),i=[`This file is not previewable inline.`,``,`- Path: ${Aw(n)}`,e.mimeType?`- Type: ${Aw(e.mimeType)}`:null,typeof e.size==`number`?`- Size: ${e.size.toLocaleString()} bytes`:null,r?`- Updated: ${r}`:null].filter(e=>e!==null).join(`
`);return{kind:`markdown`,content:i,rawText:i}}function Nw(e,t){if(!e)return t;let n=e.includes(`\\`)&&!e.includes(`/`)?`\\`:`/`,r=e.replace(/[\\/]+$/,``),i=t.replace(/^[\\/]+/,``).replaceAll(/[\\/]/g,n);return r?`${r}${n}${i}`:`${n}${i}`}async function Pw(e,t,n){let{data:r,encoding:i,url:a,blob:o}=e,{title:s}=e.artifact,c=e.artifact.mimeType??``,l,u;if(o?c.startsWith(`image/`)?l=await new Promise((e,t)=>{let n=new FileReader;n.addEventListener(`load`,()=>{typeof n.result==`string`?e(n.result):t(Error(`Artifact image could not be decoded`))},{once:!0}),n.addEventListener(`error`,()=>t(n.error??Error(`Artifact image could not be decoded`)),{once:!0}),n.readAsDataURL(o)}):u=await o.text():i===`base64`&&r&&(c.startsWith(`image/`)?l=`data:${c};base64,${r}`:(c===`application/json`||c.startsWith(`text/`))&&(u=new TextDecoder().decode(Uint8Array.from(globalThis.atob(r),e=>e.charCodeAt(0))))),l)return{kind:`image`,title:s,src:l,mimeType:c,rawText:a??null};if(u!==void 0)return{kind:`markdown`,content:`# ${s}\n\n${ud(u,c===`application/json`?`json`:``)}`,rawText:u};if(i===`base64`||a&&Bl(a,n))return{kind:`attachment`,attachmentKind:`document`,title:s,mimeType:c,download:t};let d=a?`# ${s}\n\n[Open artifact](${a})`:`# ${s}\n\nArtifact download is not previewable in the sidebar.`;return{kind:`markdown`,content:d,rawText:d}}function Fw(e,t){WS(e,t)&&(e.sidebarContent=Uw(e),e.requestUpdate?.())}function Iw(e,t,n,r={}){let i=r.requestPath??n,a=e.sessionWorkspaceDraftScope,o=e.sessionWorkspaceDraftContext,s=e.settings?.gatewayUrl??``;uC(e,t,`file:${i}`,()=>e.sessions.getFile(t.sessionKey,i,{agentId:t.agentId}),c=>{let l=c.file;if(!l)return null;let u=l.name||kw(n);if(l.previewKind===`image`)return l.contentEncoding!==`base64`||typeof l.content!=`string`||!l.mimeType||!Ww.has(l.mimeType)?null:{kind:`image`,title:u,src:`data:${l.mimeType};base64,${l.content}`,mimeType:l.mimeType,rawText:l.workspacePath||l.path||n};if(l.previewKind===`unsupported`)return Mw(l,n);if(l.previewKind!==void 0&&l.previewKind!==`text`||l.previewKind===`text`&&l.contentEncoding!==void 0&&l.contentEncoding!==`utf8`||typeof l.content!=`string`)return null;let d=typeof l.hash==`string`&&CC(l.content)&&kr(e,`sessions.files.set`)===!0&&gn(e.hello?.auth??null)?{hash:l.hash,save:async({content:n,expectedHash:r})=>{try{let a=await e.sessions.setFile(c.sessionKey,i,n,{agentId:t.agentId,expectedHash:r}),o=a?.file.hash,s=a?.file.updatedAtMs;return typeof o==`string`&&zS(e,t)&&Fw(e,!0),typeof o==`string`?{ok:!0,hash:o,...typeof s==`number`?{updatedAtMs:s}:{}}:{ok:!1,code:`error`,message:`Save failed.`}}catch(e){let t=e instanceof kt&&e.details&&typeof e.details==`object`?e.details:null;return t?.type===`session_file_conflict`?{ok:!1,code:`conflict`,...typeof t.currentHash==`string`?{currentHash:t.currentHash}:{}}:{ok:!1,code:`error`,message:N(e)}}},fetchLatest:async()=>{let n=(await e.sessions.getFile(c.sessionKey,i,{agentId:t.agentId}))?.file;return!n||typeof n.content!=`string`||typeof n.hash!=`string`?null:{content:n.content,hash:n.hash,editable:CC(n.content)}}}:void 0;return{kind:`file`,path:l.workspacePath||l.path||n,name:u,content:l.content,draftKey:[s,a??``,c.sessionKey,c.root??``,l.workspacePath||l.path||n].join(`\0`),draftContext:{sessionKey:c.sessionKey,sessionTitle:o?.sessionTitle??ye(c.sessionKey),paneLabel:o?.paneLabel},root:c.root??null,mimeType:l.mimeType,language:Ow(u),line:r.line??null,rawText:l.content,...d?{edit:d}:{}}},`Failed to load ${n}`,{line:r.line,label:kw(n),revalidate:!0,resolveLabel:e=>e.file?.name,resolveKey:e=>{let t=e.file?.workspacePath||e.file?.path;return t?Ga(e.root,t):void 0}})}function Lw(e,t){Iw(e,BS(e),t.path,{line:t.line})}function Rw(e){let t=BS(e);t.collapsed=!t.collapsed,!t.collapsed&&t.list?.sessionKey!==e.sessionKey&&US(e,t),e.requestUpdate?.()}function zw(e,t){let n=BS(e);n.dock!==t&&(n.dock=t,e.settings&&={...e.settings,chatWorkspaceDock:t},Qt({chatWorkspaceDock:t})),e.requestUpdate?.()}function Bw(e,t){let n=BS(e);NS(n);let r=t.replaceAll(`\\`,`/`),i=r.lastIndexOf(`/`);n.collapsed=!1,n.browserPath=i>0?r.slice(0,i):``,n.browserSearch=``,n.filter=`all`,n.activeId=`file:${t}`,US(e,n,!0),e.requestUpdate?.()}function Vw(e,t,n){let r={sessionKey:t.sessionKey,artifactId:n,...t.agentId?{agentId:t.agentId}:{}},i=async n=>{let i=BS(e);if(i.sessionKey!==r.sessionKey||i.agentId!==t.agentId)return null;let a=e.client,o=e.connectionEpoch,s=await Ws(e,r,n,{readBinary:!0});return n.aborted||!e.connected||e.client!==a||e.connectionEpoch!==o||!zS(e,i)?null:s?.blob?s.blob:s?.encoding!==`base64`||s.data===void 0?null:new Blob([Uint8Array.from(atob(s.data),e=>e.charCodeAt(0))],{type:s.artifact.mimeType??`application/octet-stream`})};uC(e,t,`artifact:${n}`,async()=>{let t=await Ws(e,r);return t?.artifact?{artifact:t.artifact,content:await Pw(t,i,e.resourceBasePath)}:null},e=>e.content,`Failed to load artifact ${n}`,{label:t.list?.artifacts?.find(e=>e.id===n)?.title||L(`chat.workspaceFiles.artifacts`),resolveLabel:e=>e.artifact?.title})}function Hw(e,t){e.sessionWorkspaceDraftScope=t?.draftScope,e.sessionWorkspaceDraftContext=t?.draftContext;let n=BS(e);(t?.expanded===!1||t?.presented===!1)&&n.browserSearchTimer&&(NS(n),n.pendingReload=!0),t?.presented!==!1&&t?.expanded===!0&&e.connected&&e.agentsList&&!n.loading&&!n.browserSearchTimer&&(!n.error||n.pendingReload)&&(n.pendingReload||n.list?.sessionKey!==e.sessionKey)&&US(e,n);let r=Uw(e);return{collapsed:t?.expanded!==!0&&n.collapsed,sessionKey:e.sessionKey,list:n.list?.sessionKey===e.sessionKey?n.list:null,loading:n.loading,error:n.error,activeId:n.activeId,dock:n.dock,narrowLayout:t?.narrowLayout===!0,filter:n.filter,browserPath:n.browserPath,browserSearch:n.browserSearch,onSetFilter:t=>{n.filter=t,e.requestUpdate?.()},onToggleCollapsed:()=>Rw(e),onSetDock:t=>zw(e,t),onRefresh:()=>US(e,n,!0),onBrowsePath:t=>{NS(n),n.browserPath=t,n.browserSearch=``,US(e,n,!0)},onOpenFile:(t,r)=>{let i=r===`workspace`?{requestPath:Nw(n.list?.root,t)}:{};Iw(e,n,t,i)},onSearch:t=>{n.browserSearch=t,e.requestUpdate?.(),NS(n),n.browserSearchTimer=globalThis.setTimeout(()=>{n.browserSearchTimer=null,US(e,n,!0)},160)},onOpenArtifact:t=>Vw(e,n,t),onOpenDiff:r?()=>IS(e,r):void 0}}function Uw(e){let t=BS(e);if(!(kr(e,`sessions.diff`)===!0&&e.client))return null;if(t.diffContent)return t.diffContent;let n=e.sessionKey,r=e.client,i=t.agentId,a={kind:`session-diff`,load:async e=>{if(!r)throw Error(L(`chat.sessionDiff.disconnected`));return await r.request(`sessions.diff`,{sessionKey:n,...i?{agentId:i}:{},...e})},loadFileText:kr(e,`sessions.files.get`)===!0&&e.client?async t=>{try{let r=(await e.sessions.getFile(n,t,{agentId:i}))?.file;return!r||r.previewKind!==void 0&&r.previewKind!==`text`||r.contentEncoding!==void 0&&r.contentEncoding!==`utf8`||typeof r.content!=`string`?null:r.content}catch{return null}}:void 0,openFile:t=>Iw(e,BS(e),t)};return FS(a),t.diffContent=a,a}var Ww;function Gw(){return(Gw=e((()=>{nl(),mn(),on(),hn(),R(),ft(),Ar(),Xe(),gC(),ZS(),xw(),Dw(),Ww=new Set([`image/avif`,`image/gif`,`image/jpeg`,`image/png`,`image/webp`])})))()}function Kw(e){return kn({signal:e.signal,value:!1},({render:t,finish:n})=>{let r=!1,i=``,a=()=>!e.signal.aborted&&e.isCurrent(),o=()=>H` <openclaw-modal-dialog
      label=${L(`chat.privateDraftReload.title`)}
      description=${L(`chat.privateDraftReload.description`)}
      @modal-cancel=${()=>n(!1)}
    >
      <section class="exec-approval-card">
        <div class="exec-approval-header">
          <div>
            <div class="exec-approval-title">${L(`chat.privateDraftReload.title`)}</div>
            <div class="exec-approval-sub">${L(`chat.privateDraftReload.description`)}</div>
          </div>
        </div>
        ${e.text?H`
                <label class="field"
                  ><span>${L(`chat.privateDraftReload.text`)}</span>
                  <textarea readonly rows="6" .value=${e.text}></textarea>
                </label>
                <button
                  type="button"
                  class="btn"
                  @click=${async()=>{if(!a()){n(!1);return}r=await et(e.text,a),a()&&(i=r?``:L(`chat.privateDraftReload.copyFailed`),t(o))}}
                >
                  ${L(r?`common.copied`:`chat.privateDraftReload.copy`)}
                </button>
              `:G}
        ${e.hasGoal?H`<p>${L(`chat.privateDraftReload.goal`)}</p>`:G}
        ${e.pendingReads?H`<p>${L(`chat.privateDraftReload.reading`)}</p>`:G}
        ${e.attachments.map(e=>H`
            <div class="field">
              <span>${e.fileName??e.mimeType}</span>
              <button
                type="button"
                class="btn"
                @click=${()=>{if(!a()){n(!1);return}let r=du(e);r?Ka(e.fileName??`attachment`,r):(i=L(`chat.privateDraftReload.attachmentUnavailable`),t(o))}}
              >
                ${L(`chat.privateDraftReload.download`,{name:e.fileName??e.mimeType})}
              </button>
            </div>
          `)}
        ${i?H`<p role="alert">${i}</p>`:G}
        <div class="exec-approval-actions">
          <button type="button" class="btn danger" @click=${()=>n(a())}>
            ${L(`chat.privateDraftReload.discard`)}
          </button>
          <button type="button" class="btn" autofocus @click=${()=>n(!1)}>
            ${L(`chat.privateDraftReload.keep`)}
          </button>
        </div>
      </section>
    </openclaw-modal-dialog>`;t(o)})}function qw(){return(qw=e((()=>{K(),wn(),R(),xt(),cu()})))()}function Jw(e,t,n,r){let i=r.readSignal??n.readSignal;if(i.aborted){n.remove(t);return}let a=new FileReader,o=e,s=new AbortController,c=!1,l,u=e=>{d(e);try{a.abort()}catch{}},d=e=>{if(!c){if(c=!0,s.abort(),clearTimeout(l),l=void 0,i.removeEventListener(`abort`,f),t.cancel=void 0,e===`ready`&&!bt(r.uploadConfig))I({message:Qe()}),n.settle(t,`error`);else if(e===`ready`&&typeof a.result==`string`&&!i.aborted){let e=uu({attachment:t.attachment,dataUrl:a.result,file:o}),r=[...t.destination.getAttachments(),e],i=new Set(r.map(({id:e})=>e));t.destination.onAttachmentsChange(n.project(r).filter(({attachment:e})=>i.has(e.id)).map(({attachment:e})=>e)),n.settle(t,`ready`)}else e===`aborted`||i.aborted?n.remove(t):n.settle(t,`error`);t.destination.onPendingReadsChange?.(-1)}},f=()=>u(`aborted`),p=()=>u(`error`),m=e=>{clearTimeout(l),l=e&&!c?setTimeout(p,Yw):void 0};t.cancel=f,i.addEventListener(`abort`,f,{once:!0}),a.addEventListener(`error`,()=>d(`error`),{once:!0}),a.addEventListener(`abort`,()=>d(`aborted`),{once:!0}),a.addEventListener(`load`,()=>d(`ready`),{once:!0}),a.addEventListener(`progress`,e=>{!c&&e.lengthComputable&&e.total>0&&(n.updateProgress(t,Math.min(1,Math.max(0,e.loaded/e.total))),l!==void 0&&m(!0))}),t.destination.onPendingReadsChange?.(1),m(!0);let h=e=>{if(!c){if(wS([e],r.attachmentLimits,0).length===0){d(`error`);return}o=e,t.attachment={...t.attachment,mimeType:e.type||`application/octet-stream`,sizeBytes:e.size},m(!0);try{a.readAsDataURL(e)}catch{d(`error`)}}},g=r.attachmentLimits?.maxImageBytes;g!==void 0&&e.type.startsWith(`image/`)&&e.size>g?vS(e,g,s.signal,m).then(h,()=>d(`error`)):h(e)}var Yw,Xw;function Zw(){return(Zw=e((()=>{Oe(),Le(),cu(),jS(),bS(),Yw=15e3,Xw=class{constructor(e){this.notify=e,this.pendingReads=0,this.controller=new AbortController,this.entries=[]}retarget(e,t){this.notify=t;for(let t of this.entries)t.destination&&=e}get readSignal(){return this.controller.signal}pendingBytes(e){return this.entries.reduce((t,n)=>t+(n.state===`reading`?TS(n.attachment.sizeBytes??0,n.attachment.mimeType,e):0),0)}updatePending(e,t){this.controller.signal===e&&(this.pendingReads=Math.max(0,this.pendingReads+t),this.notify())}begin(e,t,n){this.project(t);let r=e.map(e=>({attachment:{id:Bu(),origin:`file`,mimeType:e.type||`application/octet-stream`,fileName:e.name||void 0,sizeBytes:e.size},state:`reading`,destination:n}));return this.entries.push(...r),this.notify(),r}project(e){let t=new Map(e.map(e=>[e.id,e]));this.entries=this.entries.filter(e=>{let n=t.get(e.attachment.id);return n&&(e.attachment=n,t.delete(n.id)),e.state!==`ready`||n!==void 0});for(let e of t.values())this.entries.push({attachment:e,state:`ready`});return this.entries}settle(e,t){this.entries.includes(e)&&(e.state=t,e.cancel=void 0,this.notify())}updateProgress(e,t){this.entries.includes(e)&&e.state===`reading`&&(e.progress=t,this.notify())}remove(e){this.entries=this.entries.filter(t=>t!==e),e.cancel?.(),e.cancel=void 0,this.notify()}abortReads(){let e=this.controller;this.controller=new AbortController,this.entries=[],this.pendingReads=0,e.abort(),this.notify()}}})))()}function Qw(e){return`data:text/plain;base64,${$e(new TextEncoder().encode(e))}`}function $w(){return($w=e((()=>{})))()}function eT(e){return e.getAttachments?.()??e.attachments??[]}function tT(e){let t=/^data:([^,]*),(.*)$/s.exec(e);if(!t)return null;let n=t[1],r=t[2];if(n===void 0||r===void 0)return null;if(n.toLowerCase().includes(`;base64`))try{let e=atob(r),t=Uint8Array.from(e,e=>e.charCodeAt(0));return new TextDecoder().decode(t)}catch{return null}try{return decodeURIComponent(r.replace(/\+/g,`%20`))}catch{return null}}function nT(e,t){return e.trim()?`${e.replace(/\s+$/u,``)}\n\n${t}`:t}function rT(e,t){let n=fu(e),r=n?tT(n):null;if(!r||!t.onDraftChange)return;let i=eT(t).filter(t=>t.id!==e.id);vt(e.id),t.onAttachmentsChange?.(i),t.onDraftChange(nT(t.getDraft?.()??t.draft??``,r)),t.onRequestUpdate?.()}function iT(e,t){let n=()=>t.readSignal?.aborted?void 0:eT(t).find(t=>t.id===e.id),r=e.fileName?.trim()?L(`chat.composer.removeNamedAttachment`,{name:e.fileName}):L(`chat.composer.removeAttachment`),i=()=>{if(!n()||t.disabled)return;let r=eT(t).filter(t=>t.id!==e.id);vt(e.id),t.onAttachmentsChange?.(r)},a=()=>H`<button
    class="chat-attachment-text-action"
    type="button"
    ?disabled=${t.disabled}
    @click=${()=>{let e=n();e&&!t.disabled&&rT(e,t)}}
  >
    ${L(`chat.attachments.showInTextField`)}
  </button>`;return H`<openclaw-chat-pasted-text
    .src=${fu(e)}
    .sizeBytes=${e.sizeBytes}
    .scope=${e.id}
    .onOpen=${()=>{n()&&t.onOpenSidebar?.({kind:`attachment`,attachmentKind:`document`,title:e.fileName??L(`chat.attachments.pastedText`),mimeType:`text/plain`,plainText:!0,sourceIdentity:e.id,resolveSource:()=>{let e=n();if(!e)return{status:`unavailable`};let t=hu(e);return t?{status:`ready`,src:t,sizeBytes:e.sizeBytes}:{status:`unavailable`}},renderActions:()=>H`${a()}
        <button
          class="btn btn--sm"
          type="button"
          aria-label=${r}
          ?disabled=${t.disabled}
          @click=${i}
        >
          ${z.trash}
        </button>`})}}
    .composerAction=${a()}
    .composerRemoveAction=${H`<openclaw-tooltip .content=${r}>
      <button
        class="chat-attachment-remove"
        type="button"
        aria-label=${r}
        ?disabled=${t.disabled}
        @click=${i}
      >
        ${z.x}
      </button>
    </openclaw-tooltip>`}
  ></openclaw-chat-pasted-text>`}function aT(){return(aT=e((()=>{K(),B(),R(),cu()})))()}function oT(e){let t=e.attachments?.filter(e=>e.selectionAnnotation)??[],n=(e,t,n)=>{e.currentTarget?.dispatchEvent(new CustomEvent(`openclaw-comment-action`,{bubbles:!0,composed:!0,detail:{id:t,action:n}}))};return t.length?m_(t.length,H`<ol class="chat-comment-preview__list" role="list">
          ${t.map((t,r)=>p_(t.selectionAnnotation,H`<span class="chat-comment-preview__actions">
                <button
                  type="button"
                  aria-label=${L(`chat.messages.editAnnotation`,{number:String(r+1)})}
                  ?disabled=${e.disabled||e.readSignal?.aborted}
                  @click=${e=>n(e,t.id,`edit`)}
                >
                  ${z.pencil}
                </button>
                <button
                  type="button"
                  data-comment-delete=${t.id}
                  aria-label=${L(`chat.messages.deleteAnnotation`)}
                  ?disabled=${e.disabled||e.readSignal?.aborted}
                  @click=${e=>n(e,t.id,`delete`)}
                >
                  ${z.trash}
                </button>
              </span>`))}
        </ol>`,void 0,!0,{onRemove:e=>n(e,void 0,`delete-all`),disabled:!!(e.disabled||e.readSignal?.aborted)}):G}function sT(){return(sT=e((()=>{K(),B(),R(),$r(),h_(),di()})))()}function cT(e){return Array.from(e?.types??[]).includes(`Files`)}function lT(e){let t=e.target;if(!(t instanceof Element))return!1;let n=t.closest(`textarea, input, [contenteditable]`);return n instanceof HTMLInputElement?DT.has(n.type)&&!n.disabled&&!n.readOnly:n instanceof HTMLTextAreaElement?!n.disabled&&!n.readOnly:n instanceof HTMLElement&&n.isContentEditable}function uT(e){return e.getAttachments?.()??e.attachments??[]}function dT(e,t=uT(e)){return DS(t)+(e.attachmentReads?.pendingBytes(e.attachmentLimits)??0)}function fT(e,t,n=`file`){let r={id:Bu(),origin:n,mimeType:e.type||`application/octet-stream`,fileName:e.name||void 0,sizeBytes:e.size};return uu({attachment:r,dataUrl:t,file:e})}function pT(e,t){if(!t.onAttachmentsChange||!bt(t.uploadConfig))return!1;let n=e.clipboardData?.getData(`text/plain`);if(!n||n.length<=wT)return!1;e.preventDefault();let r=new File([n],`${ET}${Date.now()}.txt`,{type:TT}),i=dT(t);if(wS([r],t.attachmentLimits,i).length===0)return!0;let a=fT(r,Qw(n),`paste`);return t.onAttachmentsChange([...uT(t),a]),!0}function mT(e){let t=Array.from(e?.items??[]).filter(e=>e.type.startsWith(`image/`)).map(e=>e.getAsFile()).filter(e=>e!==null),n=t.length===0?e?.getData(`text/plain`):void 0,r=n?hS(n):null;return r?{files:[r.file],inline:r}:{files:t}}function hT(e,t,n,r){let i=hS(e,t.replace(/\.[a-z0-9]+$/i,``)||`image`);return!i||wS([i.file],n,r).length===0?null:fT(i.file,i.dataUrl)}function gT(e,t){if(!t.onAttachmentsChange||e.length===0||t.readSignal?.aborted)return 0;if(!bt(t.uploadConfig))return I({message:Qe()}),0;let n=t.imagesOnly?e.filter(e=>!e.type.startsWith(`image/`)):[];n.length&&I({message:L(`chat.attachments.imagesOnly`)});let r=dT(t),i=wS(e.filter(e=>!n.includes(e)),t.attachmentLimits,r,{resizeImages:!0});if(i.length===0)return 0;let a=t.attachmentReads??new Xw(()=>t.onRequestUpdate?.());return a.begin(i,uT(t),{getAttachments:()=>uT(t),onAttachmentsChange:t.onAttachmentsChange,onPendingReadsChange:t.onPendingReadsChange}).forEach((e,n)=>{let r=i[n];r&&Jw(r,e,a,t)}),i.length}function _T(e,t,n={}){if(!e.clipboardData||!t.onAttachmentsChange)return;if(!bt(t.uploadConfig)){let t=Array.from(e.clipboardData.items??[]).some(e=>e.kind===`file`||e.type.startsWith(`image/`)),n=/^data:image\//i.test(e.clipboardData.getData(`text/plain`).trim());(t||n)&&(e.preventDefault(),I({message:Qe()}));return}let{files:r,inline:i}=mT(e.clipboardData);if(r.length===0){n.imagesOnly||pT(e,t);return}if(e.preventDefault(),i&&(!t.attachmentLimits||i.file.size<=t.attachmentLimits.maxImageBytes)){let e=dT(t);if(wS([i.file],t.attachmentLimits,e).length===0)return;t.onAttachmentsChange([...uT(t),fT(i.file,i.dataUrl)]);return}gT(r,t)}function vT(e){let t=0,n=(n,r)=>{let i=n.currentTarget;if(i instanceof HTMLElement){if(r){if(!e.canCompose||!bt(e.uploadConfig)||!cT(n.dataTransfer))return;t+=1}else t=Math.max(0,t-1);i.toggleAttribute(`data-attachment-drop-active`,t>0)}},r=e=>{t=0;let n=e.currentTarget;n instanceof HTMLElement&&n.removeAttribute(`data-attachment-drop-active`)};return{onDragenter:e=>{cT(e.dataTransfer)&&e.stopPropagation(),n(e,!0)},onDragleave:e=>{cT(e.dataTransfer)&&e.stopPropagation(),n(e,!1)},onDragover:t=>{if(!cT(t.dataTransfer)){lT(t)||(t.preventDefault(),t.dataTransfer&&(t.dataTransfer.dropEffect=`none`));return}t.preventDefault(),t.stopPropagation(),t.dataTransfer&&(t.dataTransfer.dropEffect=e.canCompose&&bt(e.uploadConfig)?`copy`:`none`)},onDrop:t=>{if(!cT(t.dataTransfer)){lT(t)||t.preventDefault();return}t.preventDefault(),t.stopPropagation(),r(t),e.canCompose&&gT([...t.dataTransfer?.files??[]],e)}}}function yT(e,t){if(t.onRemoveAttachment){t.onRemoveAttachment(e);return}let n=uT(t).filter(t=>t.id!==e.id);vt(e.id),t.onAttachmentsChange?.(n)}function bT(e,t,n,r){let i=hu(e);return i?r.onOpenImage?H`
    <button
      type="button"
      class="chat-message-image-button chat-attachment-image-button"
      aria-label=${L(`chat.imageLightbox.open`,{title:n})}
      @click=${()=>r.onOpenImage?.({src:i,title:n})}
    >
      <img src=${i} alt=${t} />
    </button>
  `:H`<img src=${i} alt=${t} />`:G}function xT(e,t,n){let r=t.title.trim()||t.displayUrl.trim()||e.fileName||L(`chat.attachments.attachedFile`),i=L(t.markedRegionCount===1?`chat.composer.browserAnnotationRegion`:`chat.composer.browserAnnotationRegions`,{count:String(t.markedRegionCount)}),a=L(`chat.composer.removeBrowserAnnotation`,{name:r});return H`
    <div
      class="chat-attachment-thumb chat-attachment-thumb--browser-annotation"
      data-attachment-id=${e.id}
      role="group"
      aria-label=${`${L(`chat.composer.browserAnnotation`)}: ${r}`}
    >
      <div class="chat-browser-annotation-card__preview">
        ${bT(e,L(`chat.composer.browserAnnotationPreview`),r,n)}
      </div>
      <div class="chat-attachment-file__body chat-browser-annotation-card__body">
        <span
          class="chat-attachment-file__name chat-browser-annotation-card__identity"
          title=${r}
          >${r}</span
        >
        <span class="chat-attachment-file__meta chat-browser-annotation-card__meta">
          <span>${i}</span>
        </span>
      </div>
      <openclaw-tooltip .content=${a}>
        <button
          class="chat-attachment-remove chat-browser-annotation-card__remove"
          type="button"
          aria-label=${a}
          ?disabled=${n.disabled}
          @click=${()=>yT(e,n)}
        >
          ${z.x}
        </button>
      </openclaw-tooltip>
    </div>
  `}function ST(e){return H`<div
    class="chat-attachments-status sr-only"
    role="status"
    aria-live="polite"
    aria-atomic="true"
  >
    ${e>0?L(e===1?`chat.composer.preparingAttachmentCount`:`chat.composer.preparingAttachmentsCount`,{count:String(e)}):G}
  </div>`}function CT(e){let t=e.attachments??[],n=e.attachmentReads?.project(t)??t.map(e=>({attachment:e,state:`ready`}));return n.length===0?G:H`
    <div class="chat-attachments-preview" ${Ic(!0)}>
      ${oT(e)}
      ${q(n.filter(({attachment:e})=>!e.selectionAnnotation),({attachment:e})=>e.id,t=>{let n=t.attachment,r=t.state===`reading`,i=t.state===`error`,a=L(`chat.attachments.readFailed`,{names:n.fileName??L(`chat.attachments.attachedFile`),more:``}),o=n.fileName?.trim()?L(`chat.composer.removeNamedAttachment`,{name:n.fileName}):L(`chat.composer.removeAttachment`);return n.browserAnnotation?xT(n,n.browserAnnotation,e):$g(n)?iT(n,e):H`
                  <div
                    class=${[`chat-attachment-thumb`,n.mimeType.startsWith(`image/`)?``:`chat-attachment-thumb--file`,i?`chat-attachment-thumb--error`:``].filter(Boolean).join(` `)}
                    aria-busy=${r?`true`:`false`}
                  >
                    ${i?H`<openclaw-tooltip .content=${a}>
                            <span
                              class="chat-attachment-error"
                              tabindex="0"
                              role="img"
                              aria-label=${a}
                            >
                              ${ah({filename:n.fileName??``,mimeType:n.mimeType,mode:`large-placeholder`,unavailable:!0})}
                            </span>
                          </openclaw-tooltip>`:r?G:n.mimeType.startsWith(`image/`)&&hu(n)?bT(n,n.fileName?.trim()||L(`chat.composer.attachmentPreview`),n.fileName?.trim()||L(`chat.imageLightbox.untitled`),e):Gg(n)}
                    <span
                      class="chat-attachment-loading"
                      data-state=${t.state}
                      data-indeterminate=${r&&t.progress===void 0?`true`:`false`}
                      aria-hidden="true"
                      ><span
                        style=${nr({transform:t.progress===void 0?void 0:`scaleX(${t.progress})`})}
                      ></span
                    ></span>
                    <openclaw-tooltip .content=${o}>
                      <button
                        class="chat-attachment-remove"
                        type="button"
                        aria-label=${o}
                        ?disabled=${e.disabled}
                        @click=${()=>{e.attachmentReads?.remove(t);let r=uT(e).filter(e=>e.id!==n.id);vt(n.id),e.onAttachmentsChange?.(r)}}
                      >
                        ${z.x}
                      </button>
                    </openclaw-tooltip>
                  </div>
                `})}
    </div>
  `}var wT,TT,ET,DT;function OT(){return(OT=e((()=>{K(),ur(),rr(),B(),oc(),V(),Lc(),R(),Oe(),Le(),cu(),jS(),ch(),Kg(),bS(),Zw(),$w(),aT(),n_(),sT(),wT=1e3,TT=`text/plain`,ET=`pasted-text-`,DT=new Set([`email`,`number`,`password`,`search`,`tel`,`text`,`url`])})))()}function kT(e){return m(m(m(e?.tools)?.web)?.search)?.enabled!==!1}function AT(e){let t=Object.values(e.missing).some(e=>e.length>0),n=e.blockedByAllowlist||e.blockedByAgentFilter,r=!e.disabled;return{key:e.skillKey,name:e.name,enabled:r&&!t&&!n,baseEnabled:r,...t?{missingDeps:!0}:{},...n?{blocked:!0}:{}}}var jT;function MT(){return(MT=e((()=>{jT=class{constructor(e){this.notify=e,this.skills=new Map,this.loading=new Set,this.loadErrors=new Set,this.client=null}synchronize(e,t){(this.client!==e||this.connectionEpoch!==t)&&(this.client=e,this.connectionEpoch=t,this.skills.clear(),this.loading.clear(),this.loadErrors.clear())}load(e,t,n,r){if(this.synchronize(e,t),!e||!r()||this.skills.has(n)||this.loading.has(n))return;let i=()=>this.client===e&&this.connectionEpoch===t&&r();this.loadErrors.delete(n),this.loading.add(n),this.notify(),_e(e,n).then(e=>{e&&i()&&this.skills.set(n,e.skills.map(AT).toSorted((e,t)=>e.name.localeCompare(t.name)))}).catch(()=>{i()&&this.loadErrors.add(n)}).finally(()=>{i()&&(this.loading.delete(n),this.notify())})}rows(e,t){return this.skills.get(e)?.map(e=>Object.assign({},e,{enabled:e.missingDeps||e.blocked?!1:zi(t?.skills,e.key)??e.baseEnabled}))??null}isLoading(e){return this.loading.has(e)}hasError(e){return this.loadErrors.has(e)}}})))()}var NT;function PT(){return(PT=e((()=>{R(),$a(),St(),La(),ft(),Tu(),Ja(),NT=class{constructor(e){this.notify=e,this.result=null,this.loading=!1,this.busy=!1,this.error=null,this.notice=null,this.read=null,this.selectedFile=`SKILL.md`,this.target=null,this.readOwner=null}synchronize(e){let t=this.target;(t?.client!==e?.client||t?.connectionEpoch!==e?.connectionEpoch||t?.sessionKey!==e?.sessionKey||t?.agentId!==e?.agentId)&&(this.target=e,this.result=null,this.loading=!1,this.busy=!1,this.error=null,this.notice=null,this.closeRead())}current(e){return this.target===e&&e.isCurrent()}closeRead(){this.readOwner=null,this.read=null,this.selectedFile=`SKILL.md`}async load(e=!1){let t=this.target;if(!(!t||!this.current(t)||this.loading||this.result&&!e)){this.loading=!0,this.error=null,this.notify();try{let e=await t.client.request(`skills.library.list`,{sessionKey:t.sessionKey});this.current(t)&&(this.result=e)}catch(e){this.current(t)&&(this.error=N(e))}finally{this.current(t)&&(this.loading=!1,this.notify())}}}async openRead(e,t){let n=this.target;if(!n||!this.current(n)||this.busy||this.loading)return;let r={};this.readOwner=r,this.error=null,this.busy=!0,this.notify();try{let i=await n.client.request(`skills.library.read`,{sessionKey:n.sessionKey,skillId:e,revision:t});this.current(n)&&this.readOwner===r&&(this.read=i,this.selectedFile=`SKILL.md`)}catch(e){this.current(n)&&this.readOwner===r&&(this.error=N(e))}finally{this.current(n)&&(this.busy=!1,this.notify())}}async activate(e,t,n){let r=this.target;if(r&&this.current(r)&&!this.busy&&!this.loading){this.busy=!0,this.error=null,this.notice=null,this.notify();try{if(await r.client.request(`skills.library.activate`,{action:e,sessionKey:r.sessionKey,...t?{skillId:t}:{},...n?{revision:n}:{}}),!this.current(r))return;this.notice=L(`skillLibrary.session.queued`),this.result=null,this.closeRead();let i={agentId:r.agentId,sessionKey:r.sessionKey};sd(r.client,i),Ke(r.client,i),await Promise.all([this.load(),xa(r.client,i)])}catch(e){this.current(r)&&(this.error=N(e))}finally{this.current(r)&&(this.busy=!1,this.notify())}}}}})))()}var FT;function IT(){return(IT=e((()=>{Ss(),K(),W(),Zc(),Al(),R(),vi(),Ex(),FT=class{constructor(){this.target=null,this.items=[],this.index=0,this.dismissed=null,this.resolver=new Pr,this.inserting=!1,this.acceptedEnter=!1,this.requestUpdate=null,this.anchor=new Gc(()=>{let e=this.requestUpdate;this.dismiss(this.textarea),e?.()}),this.popup=null,this.textarea=null,this.popupRef=e=>{this.popup=e instanceof Os?e:null,this.syncAnchor()}}syncAnchor(){this.popup&&this.textarea&&this.target&&this.open?this.anchor.update(this.popup,this.textarea,this.target.start):this.anchor.close()}get open(){return this.items.length>0}close(){this.acceptedEnter=!1,this.anchor.close(),this.requestUpdate=null,this.textarea=null,this.target=null,this.items=[],this.index=0,this.dismissed=null,this.resolver.reset()}dismiss(e){this.close(),this.dismissed=e?{value:e.value,caret:e.selectionStart}:null}activeId(e){return this.open?xx(e,`emoji-option-${this.index}`):null}activeLabel(){return this.open?`:${this.items[this.index]}:`:``}update(e,t,n=!0){if(this.dismissed&&this.dismissed.caret===e.selectionStart&&this.dismissed.value===e.value)return;let r=n&&e.isConnected&&e.ownerDocument.activeElement===e&&!e.disabled&&!e.readOnly&&e.selectionStart===e.selectionEnd?this.resolver.find(e.value,e.selectionStart):null;if(r?.start===this.target?.start&&r?.query===this.target?.query&&r?.end===this.target?.end){r&&this.syncAnchor();return}let i=this.open;this.target=r,this.items=r?xi(r.query):[],this.index=0,this.dismissed=null,(i||this.open)&&t()}insert(e,t,n,r){if(e.disabled||e.readOnly||this.inserting)return!1;e.focus({preventScroll:!0});let i=e.selectionStart,a=e.selectionEnd;this.inserting=!0,this.close(),e.setSelectionRange(t.start,t.end);let o=!1;try{o=e.ownerDocument.execCommand?.(`insertText`,!1,n)??!1}finally{this.inserting=!1}return o||e.setSelectionRange(i,a),r(),o}complete(e,t,n=!0){let r=e.target;if(!n||this.inserting||e.isComposing||e.inputType!==`insertText`||e.data!==`:`||!(r instanceof HTMLTextAreaElement)||r.selectionStart!==r.selectionEnd||!e.cancelable)return!1;let i=r.selectionStart,a=this.resolver.find(r.value,i),o=a&&ro(a.query);return!a||!o||!this.insert(r,{...a,end:i},o,t)?!1:(e.preventDefault(),!0)}handleKeyup(e){e.key===`Enter`&&(this.acceptedEnter=!1)}handleKeydown(e,t,n){if(e.key===`Enter`){if(!e.repeat)this.acceptedEnter=!1;else if(this.acceptedEnter)return e.preventDefault(),!0}let r=e.target;return!this.open||!(r instanceof HTMLTextAreaElement)||r.disabled||r.readOnly||r.selectionStart!==r.selectionEnd||e.shiftKey||e.altKey||e.isComposing||e.keyCode===229?!1:zl(e,{count:this.items.length,index:this.index,consumeEmpty:!1,close:()=>{this.dismiss(r),n()},move:e=>(this.index=e,n(),this.activeId(t)),select:e=>{this.select(r,n),this.acceptedEnter=e===`Enter`}})}select(e,t,n=this.index){let r=this.resolver.find(e.value,e.selectionStart),i=ro(this.items[n]??``);r&&i&&r.start===this.target?.start&&r.query===this.target.query&&this.insert(e,r,i,t)}render(e,t,n){if(!this.open||!t||t.disabled||t.readOnly)return G;this.requestUpdate=n,this.textarea=t,this.syncAnchor();let r=yl({className:`emoji-menu`,id:xx(e,`emoji-menu-listbox`),label:L(`chat.composer.emojiSuggestions`),content:this.items.map((r,i)=>Gl({id:xx(e,`emoji-option-${i}`),active:i===this.index,select:()=>this.select(t,n,i),hover:()=>{this.index=i,n()},icon:ro(r),iconHidden:!0,name:`:${r}:`,description:G}))});return H`<wa-popup ${U(this.popupRef)} class="emoji-menu-popup">${r}</wa-popup>`}}})))()}function LT(e){let t=HT.get(e);t!==void 0&&(clearInterval(t),HT.delete(e))}function RT(e){let t=null;return n=>{if(t&&=(LT(t),null),!(n instanceof HTMLElement)||(n.textContent=Dd(xd(e,Date.now())),e.status!==`active`))return;t=n;let r=setInterval(()=>{if(!n.isConnected){LT(n);return}n.textContent=Dd(xd(e,Date.now()))},1e3);HT.set(n,r)}}function zT(e,t,n){if(!t)return G;let r=Dd(xd(t,Date.now())),i=wd(t),a=e.goalExpandedId===t.id,o=n.canAct&&!!n.onGoalAction,s=t.status===`paused`||t.status===`blocked`||t.status===`usage_limited`||t.status===`budget_limited`,c=s&&!a?t.lastStatusNote:void 0;return H`
    <div
      class="agent-chat__goal agent-chat__goal--${t.status}"
      data-expanded=${String(a)}
      role="group"
      aria-label=${bd(t)}
    >
      <div class="agent-chat__goal-row">
        <span class="agent-chat__goal-icon" aria-hidden="true"
          >${UT[t.status]}</span
        >
        <span class="agent-chat__goal-copy">
          <openclaw-tooltip .content=${c??``} ?disabled=${!c}>
            <span class="agent-chat__goal-label" tabindex=${c?`0`:G}
              >${hd(t.status)}</span
            >
          </openclaw-tooltip>
          <span class="agent-chat__goal-objective">${t.objective}</span>
        </span>
        <span class="agent-chat__goal-elapsed" ${U(RT(t))}></span>
        <span class="agent-chat__goal-actions">
          <span class="agent-chat__goal-command-actions">
            ${[[`edit`,n.onGoalEdit&&t.status!==`complete`,`chat.goals.edit`,`chat.goals.editChip`,z.penLine],[`pause`,t.status===`active`,`chat.goals.pause`,`chat.goals.pauseChip`,z.pause],[`resume`,s,`chat.goals.resume`,`chat.goals.resumeChip`,z.play],[`clear`,!0,`chat.goals.clear`,`chat.goals.clearChip`,z.trash]].map(([e,r,i,a,s])=>o&&r?H`<openclaw-tooltip content=${L(i)}>
                    <button
                      class="agent-chat__goal-action agent-chat__goal-${e}"
                      type="button"
                      aria-label=${L(i)}
                      @click=${()=>e===`edit`?n.onGoalEdit?.(t):n.onGoalAction?.(t.id,e)}
                    >
                      ${s}
                      <span class="agent-chat__goal-action-label">${L(a)}</span>
                    </button>
                  </openclaw-tooltip>`:G)}
          </span>
          <button
            class="agent-chat__goal-action agent-chat__goal-expand"
            type="button"
            aria-expanded=${a?`true`:`false`}
            aria-label=${L(a?`chat.goals.hideDetails`:`chat.goals.showDetails`)}
            @click=${()=>{e.goalExpandedId=a?null:t.id,n.requestUpdate()}}
          >
            ${a?z.chevronDown:z.chevronRight}
          </button>
        </span>
      </div>
      <div
        class="agent-chat__goal-detail"
        data-expanded=${String(a)}
        aria-hidden=${String(!a)}
        ?inert=${!a}
      >
        <div class="agent-chat__goal-detail-content">
          <div
            class="agent-chat__goal-detail-objective"
            ${Ic()}
            .textContent=${t.objective}
          ></div>
          ${t.lastStatusNote?H`<div class="agent-chat__goal-detail-note">${t.lastStatusNote}</div>`:G}
          <div class="agent-chat__goal-detail-meta">
            ${i?H`
                    <span class="agent-chat__goal-detail-usage">${i}</span>
                    <span class="agent-chat__goal-detail-separator" aria-hidden="true">·</span>
                  `:G}
            <span class="agent-chat__goal-detail-duration">${r}</span>
          </div>
        </div>
      </div>
    </div>
  `}function BT(){for(let e of HT.values())clearInterval(e);HT.clear()}function VT(e,t){return e?H`
    <div class="chat-composer-neighbor-card chat-composer-neighbor-card--warn" role="status">
      <span class="chat-composer-neighbor-card__icon" aria-hidden="true"
        >${z.alertTriangle}</span
      >
      <div class="chat-composer-neighbor-card__copy">
        <strong>${L(e.pending?`chat.goals.checking`:`chat.goals.recoveryTitle`)}</strong>
        <span
          >${L(e.retired===`expired`?`chat.goals.recoveryExpired`:e.retired===`invalid`?`chat.goals.recoveryInvalid`:`chat.goals.recoveryHint`)}</span
        >
      </div>
      <button
        class="btn btn--sm"
        type="button"
        ?disabled=${!t||e.pending}
        @click=${e.onCheck}
      >
        ${L(e.retired?`chat.goals.refreshCurrent`:`chat.goals.checkOutcome`)}
      </button>
    </div>
  `:G}var HT,UT;function WT(){return(WT=e((()=>{K(),W(),Yt(),B(),oc(),R(),ii(),gi(),HT=new Map,UT={active:Ot(fr` <path d="M12 13V2l8 4-8 4" />
  <path d="M20.561 10.222a9 9 0 1 1-12.55-5.29" />
  <path d="M8.002 9.997a5 5 0 1 0 8.9 2.02" />`),paused:z.pause,blocked:z.alertTriangle,usage_limited:z.alertTriangle,budget_limited:z.alertTriangle,complete:z.check}})))()}function GT(e,t){if(e.trimStart().startsWith(`/`))return null;let n=e.slice(0,t),r=n.slice(n.lastIndexOf(`
`)+1);if(/^\s*>/u.test(r)||(n.match(/```/gu)?.length??0)%2!=0||(r.match(/`/gu)?.length??0)%2!=0)return null;let i=/(?:^|[\s([{])@(?! )([\p{L}\p{N}\p{M}_. -]{0,128})$/u.exec(n);if(!i)return null;let a=i[1]??``,o=t-a.length-1,s=t;for(;s<e.length&&/[\p{L}\p{N}\p{M}_.-]/u.test(e[s]??``);)s+=1;return{start:o,end:s,query:a,value:e}}var KT,qT,JT,YT,XT,ZT;function QT(){return(QT=e((()=>{O(),K(),mn(),Zc(),R(),qr(),Sm(),Ex(),KT=3e5,qT=18e5,JT=3e4,YT=15e3,XT=16,ZT=class{constructor(){this.generation=0,this.target=null,this.search=null,this.index=0,this.selectedAvatars=new Map,this.results=new Map,this.requests=new Map}get open(){return this.target!==null}syncDirectory(e){(this.directory?.client!==e?.client||this.directory?.ownerKey!==e?.ownerKey||JSON.stringify(this.directory?.params)!==JSON.stringify(e?.params))&&(this.close(),this.results.clear(),this.requests.clear(),this.selectedAvatars.clear(),this.directory=e?{...e}:void 0)}cancelSearch(){this.generation+=1,clearTimeout(this.timer),this.timer=void 0}close(){this.cancelSearch(),this.target=null,this.search=null,this.index=0,this.selectedProfileId=void 0}dispose(){this.syncDirectory(void 0)}update(e,t,n=`selection`){let{value:r,selectionStart:i,selectionEnd:a}=e,o=this.directory?GT(r,i):null,s=n===`selection`&&this.target!==null&&(r!==this.target.value||o?.start!==this.target.start||a>this.target.end);if(!o||s||!this.open&&n!==`trigger`){this.open&&(this.close(),t());return}let c=this.target;c?.start===o.start&&n!==`trigger`&&(o.end=Math.max(o.end,c.end+r.length-c.value.length)),c?.start!==o.start&&(this.selectedProfileId=void 0),this.target=o,(c?.start!==o.start||c.query!==o.query)&&this.searchPeople(t)}showResults(e){this.index=Math.max(0,e.users.findIndex(e=>e.profileId===this.selectedProfileId)),this.selectedProfileId=e.users[this.index]?.profileId,this.search={kind:`ready`,result:e}}searchPeople(e){let t=this.target,n=this.directory;if(!t||!n)return;this.cancelSearch();let r=t.query,i=this.results.get(r);if(i&&Date.now()-i.fetchedAt>=qT&&(this.results.delete(r),i=void 0),i){if(this.showResults(i.result),Date.now()<i.refreshAfter&&!this.requests.has(r)){e();return}}else this.search={kind:`loading`};let a=this.generation;this.timer=setTimeout(()=>{this.timer=void 0;let t=this.results.get(r);if(t&&t!==i&&Date.now()<t.refreshAfter){this.showResults(t.result),e();return}let o=this.requests.get(r);o||(i&&(i.refreshAfter=Date.now()+JT),o=n.client.request(`users.mentionable`,{...n.params,query:r},{timeoutMs:YT}).then(e=>{if(this.directory===n){this.results.delete(r),this.results.size===XT&&this.results.delete(this.results.keys().next().value);let t=Date.now();this.results.set(r,{result:e,fetchedAt:t,refreshAfter:t+KT})}return e}).finally(()=>{this.directory===n&&this.requests.delete(r)}),this.requests.set(r,o)),o.then(t=>{a===this.generation&&(this.showResults(t),e())},t=>{let r=t instanceof kt&&(t.gatewayCode!==`UNAVAILABLE`||Tn(t)===D.AUTHENTICATED_PROFILE_UNAVAILABLE);this.directory===n&&r?(this.results.clear(),this.requests.clear(),this.directory={...n},this.cancelSearch(),this.open&&(this.search={kind:`error`},e())):a===this.generation&&!i&&(this.search={kind:`error`},e())})},150),e()}activeId(e){return this.search?.kind===`ready`&&this.search.result.users[this.index]?xx(e,`mention-option-${this.index}`):null}activeLabel(){return this.search?.kind===`ready`?this.search.result.users[this.index]?.displayName??``:``}handleKeydown(e,t,n){if(!this.open||e.defaultPrevented||e.isComposing||e.keyCode===229||this.search?.kind===`error`&&e.key===`Tab`)return!1;let r=this.search?.kind===`ready`?this.search.result.users:[];return zl(e,{count:r.length,index:this.index,consumeEmpty:!0,close:()=>{this.close(),n()},move:e=>(this.index=e,this.selectedProfileId=r[e]?.profileId,n(),this.activeId(t.paneId)),select:()=>this.select(r[this.index],t,n)})}select(e,t,n){let r=t.getTextarea(),i=r?.value??t.getDraft();this.update(r??{value:i,selectionStart:i.length,selectionEnd:i.length},n);let a=this.target;if(!a||t.getMentions().length>=10)return;let o=`@${e.displayName}`,s=`${o} `,c=`${i.slice(0,a.start)}${s}${i.slice(a.end)}`,l=[...oo(i,c,t.getMentions(),{value:i,start:a.start,end:a.end,inputType:`insertReplacementText`}),{profileId:e.profileId,start:a.start,end:a.start+o.length}].toSorted((e,t)=>e.start-t.start);for(let e of this.selectedAvatars.keys())l.some(t=>t.profileId===e)||this.selectedAvatars.delete(e);e.avatarUrl?this.selectedAvatars.set(e.profileId,e.avatarUrl):this.selectedAvatars.delete(e.profileId),t.commitDraft(c,l),this.close(),n(),queueMicrotask(()=>{let e=t.getTextarea();e?.focus({preventScroll:!0}),e?.setSelectionRange(a.start+s.length,a.start+s.length)})}get selectedAvatarUrls(){return this.selectedAvatars}render(e,t){if(!this.open)return G;let n=this.search?.kind===`ready`?this.search.result:void 0,r=e.getMentions().length>=10,i=this.search?.kind===`loading`,a=r?L(`chat.mentions.limit`):this.search?.kind===`error`?L(`chat.mentions.unavailable`):!i&&!n?.users.length?L(`chat.mentions.empty`):null;return yl({id:xx(e.paneId,`mention-menu-listbox`),className:`mention-menu`,label:L(`chat.mentions.menu`),trackScroll:!1,activeId:this.activeId(e.paneId),content:H` <div class="slash-menu-group" aria-busy=${i}>
        <div class="slash-menu-group__label" role="status">
          ${a??L(`chat.mentions.menu`)}
        </div>
        ${this.search?.kind===`error`&&!r?H`<button
                type="button"
                class="btn btn--sm mention-menu__retry"
                @click=${()=>{this.searchPeople(t),e.getTextarea()?.focus({preventScroll:!0})}}
              >
                ${L(`common.retry`)}
              </button>`:G}
        ${a?G:i?[0,1,2].map(()=>H`<div class="slash-menu-item mention-menu__loading" aria-hidden="true">
                    <span class="slash-menu-icon"
                      ><span class="skeleton mention-menu__avatar"></span
                    ></span>
                    <span class="skeleton skeleton-line skeleton-line--medium"></span>
                  </div>`):n?.users.map((n,r)=>Gl({id:xx(e.paneId,`mention-option-${r}`),active:r===this.index,select:()=>this.select(n,e,t),hover:()=>{this.index=r,this.selectedProfileId=n.profileId,t()},icon:ym({id:n.profileId,name:n.displayName,identity:{type:`profile`,id:n.profileId},profileAvatarUrl:n.avatarUrl}),iconHidden:!0,name:n.displayName,description:n.online?L(`chat.mentions.online`):G}))}
        ${n?.truncated?H`<div class="slash-menu-group__label">${L(`chat.mentions.truncated`)}</div>`:G}
      </div>`})}}})))()}function $T(e){return e.toLowerCase().replace(/[^a-z0-9_-]+/gu,`-`).replace(/^-+|-+$/gu,``)||`item`}function eE(e,t){return xx(e,`slash-option-command-${$T(t.name)}`)}function tE(e,t,n){return xx(e,`slash-option-arg-${$T(t)}-${$T(n)}`)}function nE(e){return z[e]??z.terminal}function rE(e,t){let n=e.toLowerCase().startsWith(t.toLowerCase())?t.length:0;return n===0?H`${e}`:H`<mark>${e.slice(0,n)}</mark>${e.slice(n)}`}function iE(e){return e?`${`/${e.name}${e.args?` ${e.args}`:``}`} ${to(e)}`:``}function aE(){return(aE=e((()=>{K(),B(),ya(),Ex()})))()}function oE(){return{skillMenuOpen:!1,skillMenuItems:[],skillMenuIndex:0,skillMenuTarget:null,skillCommandRefreshPending:!1,skillCommandRefreshGeneration:0,skillCommandRefreshTargetStart:null}}function sE(e,t){let n=0;for(let r=t-1;r>=0&&e[r]===`\\`;--r)n+=1;return n%2==1}function cE(e,t){let n=Math.max(0,Math.min(t,e.length)),r=n;for(;r>0&&xE.test(e[r-1]??``);)--r;if(r===0||e[r-1]!==`$`)return null;let i=r-1;if(sE(e,i))return null;let a=n;for(;a<e.length&&xE.test(e[a]??``);)a+=1;let o=a;for(;o>r&&e[o-1]===`:`;)--o;let s=e.slice(r,o);return s.length>0&&!/[a-z]/u.test(s)?null:{start:i,end:o,query:s}}function lE(e){return e.skillMenuOpen||e.skillMenuItems.length>0||e.skillMenuTarget!==null||e.skillCommandRefreshPending}function uE(e){e.skillCommandRefreshGeneration+=1,e.skillCommandRefreshPending=!1,e.skillCommandRefreshTargetStart=null,e.skillMenuOpen=!1,e.skillMenuItems=[],e.skillMenuIndex=0,e.skillMenuTarget=null}function dE(e,t){lE(e)&&(uE(e),t())}function fE(e,t,n){if(!t.refreshCommands||e.skillCommandRefreshPending)return;let r=t.refreshCommands();if(!r||typeof r.then!=`function`)return;let i=e.skillCommandRefreshGeneration+1;e.skillCommandRefreshGeneration=i,e.skillCommandRefreshPending=!0,Promise.resolve(r).catch(()=>void 0).finally(()=>{if(e.skillCommandRefreshGeneration!==i)return;e.skillCommandRefreshPending=!1;let r=t.getDraft();pE(r,t.getTextarea()?.selectionStart??r.length,e,t,n,{skipRefresh:!0})})}function pE(e,t,n,r,i,a={}){if(e.trimStart().startsWith(`/`)){dE(n,i);return}let o=cE(e,t);if(!o){dE(n,i);return}!a.skipRefresh&&n.skillCommandRefreshTargetStart!==o.start&&(n.skillCommandRefreshTargetStart=o.start,fE(n,r,i));let s=Ia(o.query);n.skillMenuTarget=o,n.skillMenuItems=s,n.skillMenuIndex=Math.min(n.skillMenuIndex,Math.max(0,s.length-1)),n.skillMenuOpen=s.length>0||n.skillCommandRefreshPending,i()}function mE(e,t){return xx(e,`skill-option-${t.name.replace(/[^a-z0-9_-]+/giu,`-`).replace(/^-+|-+$/gu,``)||`skill`}`)}function hE(e){return e.skillMenuOpen&&(e.skillMenuItems.length>0||e.skillCommandRefreshPending)}function gE(e,t){if(!hE(e)||e.skillCommandRefreshPending)return null;let n=e.skillMenuItems[e.skillMenuIndex];return n?mE(t,n):null}function _E(e){if(e.skillCommandRefreshPending)return``;let t=e.skillMenuItems[e.skillMenuIndex];return t?`${Go(t)} ${to(t)}`:``}function vE(e,t,n,r){if(t.skillCommandRefreshPending)return;let i=n.getTextarea(),a=i?.value??n.getDraft(),o=i?.selectionStart??t.skillMenuTarget?.end??a.length,s=cE(a,o);if(!s){uE(t),r();return}let c=s.end===a.length?` `:``,l=`$${e.name}${c}`,u=`${a.slice(0,s.start)}${l}${a.slice(s.end)}`,d=Math.max(0,o-s.end),f=s.start+l.length+d;n.commitDraft(u),uE(t),r(),queueMicrotask(()=>{let e=n.getTextarea();e&&(e.focus({preventScroll:!0}),e.setSelectionRange(f,f))})}function yE(e,t,n,r){if(!t.skillMenuOpen)return!1;let i=t.skillCommandRefreshPending?[]:t.skillMenuItems;return zl(e,{count:i.length,index:t.skillMenuIndex,consumeEmpty:!0,close:()=>{uE(t),r()},move:e=>(t.skillMenuIndex=e,r(),gE(t,n.paneId)),select:()=>{let e=i[t.skillMenuIndex];e&&vE(e,t,n,r)}})}function bE(e,t,n){if(!hE(e))return G;let r=e.skillCommandRefreshPending||e.skillMenuItems.length===0;return yl({id:xx(t.paneId,`skill-menu-listbox`),className:`skill-menu`,label:L(`chat.skills.menu`),content:H`<div class="slash-menu-group">
      <div class="slash-menu-group__label">
        ${L(r?`chat.skills.loading`:`chat.skills.label`)}
      </div>
      ${r?G:e.skillMenuItems.map((r,i)=>Gl({id:mE(t.paneId,r),active:i===e.skillMenuIndex,select:()=>vE(r,e,t,n),hover:()=>{e.skillMenuIndex=i,n()},icon:z.pencilSparkles,name:rE(Go(r),e.skillMenuTarget?.query??``),description:to(r)}))}
    </div>`})}var xE;function SE(){return(SE=e((()=>{K(),Zc(),B(),R(),ya(),Ex(),aE(),xE=/[-a-zA-Z0-9_:]/u})))()}function CE(e,t,n){let r=e.getTextarea();r&&(r.value=t,mx(r)),e.commitDraft(t),queueMicrotask(()=>{let t=e.getTextarea();t&&(t.focus({preventScroll:!0}),t.selectionStart=n,t.selectionEnd=n)})}function wE(e,t,n){let r=t.slashMenuCompletion;if(!r?.inline)return!1;let i=n.getTextarea()?.value??n.getDraft(),a=i.slice(r.end),o=a.length===0||!/^\s/u.test(a)?` `:``;return CE(n,`${i.slice(0,r.start)}${e}${o}${a}`,r.start+e.length+o.length),!0}function TE(e,t,n){let r=t.slashMenuCompletion;if(!r?.inline)return!1;let i=n.getTextarea()?.value??n.getDraft(),a=`/${e} `,o=`${i.slice(0,r.start)}${a}${i.slice(r.end)}`,s=r.start+a.length;return CE(n,o,s),t.slashMenuCompletion={query:e,start:r.start,end:s,inline:!0,argumentStart:s},!0}function EE(e,t){let n=e.slashMenuCompletion;if(!n?.inline)return!1;let r=t.getTextarea()?.value??t.getDraft(),i=r.slice(0,n.start),a=r.slice(n.end);return(i.length===0||/\s$/u.test(i))&&/^\s/u.test(a)&&(a=a.slice(1)),CE(t,`${i}${a}`,i.length),!0}function DE(e,t,n,r){let i=`/${n.query}`,a=n.argumentStart??n.start+`/${r} `.length,o=e.slice(n.start,a);return t>=a&&o.startsWith(i)&&/^\s+$/u.test(o.slice(i.length))}function OE(e,t=e.length){let n=Math.max(0,Math.min(t,e.length)),r=e.slice(0,n),i=/(?:^|\s)\/([^\s/:]+)\s+/gu,a=null;for(let t of r.matchAll(i)){let i=t[1]?.toLowerCase();if(!i||t.index===void 0)continue;let o=Io(i,{showAll:!0,inlineOnly:!0}).find(e=>e.name.toLowerCase()===i||e.aliases?.some(e=>e.replace(/^\//u,``).toLowerCase()===i));if(!o?.args||o.source===`skill`)continue;let s=t.index+t[0].indexOf(`/`),c=r.slice(t.index+t[0].length).trim();(!/\s/u.test(c)||o.allowsInlineMultiWordArgs)&&(a={command:o,completion:{query:i,start:s,end:n,inline:e.slice(0,s).trim().length>0||e.slice(n).trim().length>0,argumentStart:t.index+t[0].length}})}return a?.completion.inline?a:null}function kE(){return(kE=e((()=>{ya(),Ex()})))()}function AE(){return{slashCommandDispatchConnected:!1,slashMenuOpen:!1,slashMenuItems:[],slashMenuIndex:0,slashMenuMode:`command`,slashMenuCommand:null,slashMenuArgItems:[],slashMenuCompletion:null,slashCommandRefreshPending:!1}}function jE(e){e.slashMenuOpen=!1,e.slashMenuMode=`command`,e.slashMenuCommand=null,e.slashMenuArgItems=[],e.slashMenuItems=[],e.slashMenuCompletion=null}function ME(e){return e.slashMenuOpen||e.slashMenuMode!==`command`||e.slashMenuCommand!==null||e.slashMenuArgItems.length>0||e.slashMenuItems.length>0}function NE(e,t){ME(e)&&(jE(e),t())}function PE(e,t,n){if(!t.refreshCommands||e.slashCommandRefreshPending)return;let r=t.refreshCommands();r&&typeof r.then==`function`&&(e.slashCommandRefreshPending=!0,Promise.resolve(r).catch(()=>void 0).finally(()=>{e.slashCommandRefreshPending=!1,(e.slashMenuOpen||e.slashMenuCompletion)&&(e.slashMenuMode===`args`&&e.slashMenuCompletion?.inline||FE(t.getDraft(),e,t,n,{skipSlashIntent:!0}))}))}function FE(e,t,n,r,i={}){if(t.slashMenuMode===`freeform-args`&&t.slashMenuCompletion?.inline&&t.slashMenuCommand){let i=n.getTextarea()?.selectionStart??e.length,a=t.slashMenuCompletion;if(DE(e,i,a,t.slashMenuCommand.name)){t.slashMenuCompletion.end=i,r();return}jE(t)}let a=e.match(/^\/(\S+)\s(.*)$/);if(a){i.skipSlashIntent||PE(t,n,r);let e=a[1]?.toLowerCase(),o=a[2]?.toLowerCase();if(e===void 0||o===void 0){NE(t,r);return}let s=Mo.find(t=>t.name===e&&(n.commandFilter?.(t)??!0)),c=s?n.resolveArgOptions(s):[];if(s&&c.length>0){let e=o?c.filter(e=>e.toLowerCase().startsWith(o)):c;if(e.length>0){t.slashMenuMode=`args`,t.slashMenuCommand=s,t.slashMenuArgItems=e,t.slashMenuOpen=!0,t.slashMenuIndex=0,t.slashMenuItems=[],t.slashMenuCompletion=null,r();return}}NE(t,r);return}let o=n.getTextarea()?.selectionStart??e.length,s=Ai(e,o);if(!s){NE(t,r);return}i.skipSlashIntent||PE(t,n,r);let c=Io(s.query,{showAll:!0,inlineOnly:s.inline,allowImmediateInlineCommands:!s.skillOnly}).filter(e=>(n.commandFilter?.(e)??!0)&&(!s.inline||e.source===`skill`||n.canRun(!0,e)));t.slashMenuCompletion=s,t.slashMenuItems=[...c.filter(e=>e.source!==`skill`),...c.filter(e=>e.source===`skill`)],t.slashMenuOpen=c.length>0,t.slashMenuIndex=0,t.slashMenuMode=`command`,t.slashMenuCommand=null,t.slashMenuArgItems=[],r()}function IE(e,t,n,r){if(!t.slashMenuCompletion?.inline||e.source===`skill`||!e.args||!n.canRun(!0,e)||!n.runInlineCommand)return!1;t.slashMenuCommand=e,t.slashMenuIndex=0,t.slashMenuItems=[];let i=n.resolveArgOptions(e);return i.length>0?(t.slashMenuMode=`args`,t.slashMenuArgItems=i,t.slashMenuOpen=!0,r(),!0):TE(e.name,t,n)?(t.slashMenuMode=`freeform-args`,t.slashMenuArgItems=[],t.slashMenuOpen=!1,r(),!0):!1}function LE(e,t,n,r,i=!1){if(n.activateComposerMode?.(e)||!i&&e.source!==`skill`&&!n.canRun(!0,e)&&t.slashMenuCompletion?.inline)return;let a=e.source===`skill`?`$${e.name}`:`/${e.name}`;if(IE(e,t,n,r))return;if(!i&&t.slashMenuCompletion?.inline&&ca(e)&&n.canRun(!0,e)&&n.runInlineCommand&&EE(t,n)){jE(t),r(),n.runInlineCommand(`/${e.name}`);return}if(wE(a,t,n)){jE(t),r();return}let o=n.resolveArgOptions(e);if(o.length>0){n.commitDraft(`/${e.name} `),t.slashMenuMode=`args`,t.slashMenuCommand=e,t.slashMenuArgItems=o,t.slashMenuOpen=!0,t.slashMenuIndex=0,t.slashMenuItems=[],r();return}i?(n.commitDraft(e.args?`/${e.name} `:`/${e.name}`),jE(t),r()):e.executeLocal&&!e.args&&(e.key!==`btw`||n.canRun(!0,e))?(jE(t),n.commitDraft(`/${e.name}`),n.runCommand()):(n.commitDraft(`/${e.name} `),NE(t,r))}function RE(e,t,n,r,i){let{slashMenuCommand:a,slashMenuCompletion:o}=t;if(a?.source!==`skill`&&!n.canRun(o?.inline===!0,a??void 0,e))return;let s=a?.name??``;if(i&&t.slashMenuCompletion?.inline&&a&&ca(a)&&n.canRun(!0,a,e)&&n.runInlineCommand&&EE(t,n)){jE(t),r(),n.runInlineCommand(`/${s} ${e}`);return}if(t.slashMenuCompletion?.inline&&(!i||!a||!ca(a))&&wE(`/${s} ${e}`,t,n)){jE(t),r();return}jE(t),n.commitDraft(`/${s} ${e}`),i&&n.runCommand(),r()}function zE(e,t,n){let r=e.slashMenuCommand,i=e.slashMenuCompletion;if(e.slashMenuMode!==`freeform-args`||!i?.inline||!r||!ca(r)||!t.runInlineCommand)return!1;let a=t.getTextarea()?.value??t.getDraft(),o=i.argumentStart??i.start+`/${r.name} `.length,s=a.slice(o,i.end).trim();return!t.canRun(!0,r,s)||!EE(e,t)?!1:(jE(e),n(),t.runInlineCommand(`/${r.name}${s?` ${s}`:``}`),!0)}function BE(e,t){if(!t.runInlineCommand)return!1;let n=t.getTextarea()?.value??t.getDraft(),r=OE(n,t.getTextarea()?.selectionStart??n.length);return r?(e.slashMenuMode=`freeform-args`,e.slashMenuCommand=r.command,e.slashMenuCompletion=r.completion,!0):!1}function VE(e,t,n,r,i){if(e.key===`Escape`)return t.slashMenuMode!==`freeform-args`||!t.slashMenuCompletion?.inline?!1:(e.preventDefault(),jE(t),r(),!0);let a=i===`enter`||e.metaKey||e.ctrlKey;return e.key!==`Enter`||e.shiftKey||!a||(t.slashMenuMode!==`freeform-args`||!t.slashMenuCompletion?.inline)&&!BE(t,n)||!t.slashMenuCommand||!ca(t.slashMenuCommand)?!1:(e.preventDefault(),zE(t,n,r),!0)}function HE(e,t,n,r){if(!t.slashMenuOpen)return!1;let i=t.slashMenuMode===`args`?t.slashMenuArgItems:t.slashMenuItems;return zl(e,{count:i.length,index:t.slashMenuIndex,consumeEmpty:!1,close:()=>{jE(t),r()},move:e=>(t.slashMenuIndex=e,r(),WE(t,n.paneId)),select:e=>{if(t.slashMenuMode===`args`){let i=t.slashMenuArgItems[t.slashMenuIndex];i!==void 0&&RE(i,t,n,r,e===`Enter`)}else{let i=t.slashMenuItems[t.slashMenuIndex];i&&LE(i,t,n,r,e===`Tab`)}}})}function UE(e){return e.slashMenuOpen?e.slashMenuMode===`args`?!!(e.slashMenuCommand&&e.slashMenuArgItems.length>0):e.slashMenuItems.length>0:!1}function WE(e,t){if(!UE(e))return null;if(e.slashMenuMode===`args`){let n=e.slashMenuCommand?.name,r=e.slashMenuArgItems[e.slashMenuIndex];return n&&r?tE(t,n,r):null}let n=e.slashMenuItems[e.slashMenuIndex];return n?eE(t,n):null}function GE(e){if(!UE(e))return``;if(e.slashMenuMode===`args`){let t=e.slashMenuCommand?.name,n=e.slashMenuArgItems[e.slashMenuIndex];return t&&n?`/${t} ${n}`:``}return iE(e.slashMenuItems[e.slashMenuIndex])}function KE(e){let{cmd:t,index:n,query:r,requestUpdate:i,host:a,state:o}=e;return Gl({id:eE(a.paneId,t),active:n===o.slashMenuIndex,select:()=>LE(t,o,a,i),hover:()=>{o.slashMenuIndex=n,i()},icon:t.source===`skill`?z.pencilSparkles:t.icon?nE(t.icon):z.terminal,name:H`/${rE(t.name,r)}${t.args?H`<span class="slash-menu-args"> ${t.args}</span>`:G}`,description:to(t)})}function qE(e,t,n,r){let i=xx(t.paneId,`slash-menu-listbox`);if(!e.slashMenuOpen)return G;if(e.slashMenuMode===`args`&&e.slashMenuCommand&&e.slashMenuArgItems.length>0)return Y(`args`,yl({id:i,label:L(`chat.commands.arguments`),content:H` <div class="slash-menu-group">
          <div class="slash-menu-group__label">
            /${e.slashMenuCommand.name} ${to(e.slashMenuCommand)}
          </div>
          ${e.slashMenuArgItems.map((n,i)=>Gl({id:tE(t.paneId,e.slashMenuCommand?.name??``,n),active:i===e.slashMenuIndex,preserveFocus:!1,select:()=>RE(n,e,t,r,!0),hover:()=>{e.slashMenuIndex=i,r()},icon:e.slashMenuCommand?.icon?nE(e.slashMenuCommand.icon):z.terminal,name:n,description:H`/${e.slashMenuCommand?.name} ${n}`}))}
        </div>`}));if(e.slashMenuItems.length===0)return G;let a=n.slice(1),o=e.slashMenuItems.filter(e=>e.source!==`skill`),s=e.slashMenuItems.filter(e=>e.source===`skill`),c=[];for(let[e,t]of o.entries()){let r=t.category??`session`,i=n===`/`?c.find(([e])=>e===r):c.at(-1);i?.[0]===r?i[1].push({command:t,index:e}):c.push([r,[{command:t,index:e}]])}return Y(`command`,yl({id:i,label:L(`chat.commands.menu`),content:H`
        ${c.map(([n,i])=>H`<div class="slash-menu-group">
            <div class="slash-menu-group__label">${xo(n)}</div>
            ${i.map(({command:n,index:i})=>KE({cmd:n,index:i,query:a,requestUpdate:r,host:t,state:e}))}
          </div>`)}
        ${s.length>0?H`<div class="slash-menu-group slash-menu-group--skills">
                <div class="slash-menu-group__label">${L(`chat.skills.label`)}</div>
                ${s.map((n,i)=>KE({cmd:n,index:o.length+i,query:a,requestUpdate:r,host:t,state:e}))}
              </div>`:G}
      `}))}function JE(){return(JE=e((()=>{K(),sr(),Zc(),B(),R(),ya(),Ex(),kE(),aE()})))()}function YE(){return{...AE(),...oE(),composerComposing:!1,editRevision:0,mentionMenu:new ZT,emojiMenu:new FT,composingDraft:null,composerInputIntentKey:null,pendingClearedSubmittedDraft:null,goalExpandedId:null,goalComposer:null,activeQuestionKey:null,gatewayQuestionIds:new Set,asyncQuestionIds:new Set,questionCollapsed:!1,questionTakeoverActive:!1,restoreComposerFocus:!1,composerInput:null,composerTextarea:null,microphonePicker:null,capabilityMenuOpen:!1,capabilityMenuView:`root`,textareaRef:null,composerInputRef:null,dictation:null,composerDraftScopeKey:null,dictationError:null,dictationSelection:null}}function XE(e){let t=lD.get(e);if(t)return t;let n=YE();return lD.set(e,n),n}function ZE(e){return e?.phase===`done`||e?.phase===`interrupted`}function QE(e,t,n){return e.sessionKey===t&&!e.pendingRunId&&(e.sendState===`submitting`||e.sendState===`sending`||e.sendState===`waiting-model`)&&(n==null||e.sendRunId!==n.runId)}function $E(e){return e.runActive===!0&&!ZE(e.runStatus)||e.queue.some(t=>QE(t,e.sessionKey,e.runStatus))}function eD(e){return`${e.currentAgentId}\u0000${e.sessionKey}`}function tD(e,t,n){let r=e.getDraft?e.getDraft():e.draft;if(r===t&&n===void 0)return;let i=e.getMentions?.()??e.mentions??[];XE(e.paneId).editRevision+=1,e.onDraftChange(t,n);let a=e.getMentions?.()??n??e.mentions??[];(i.length!==a.length||i.some((e,n)=>{let i=a[n];return e.profileId!==i.profileId||r.slice(e.start,e.end)!==t.slice(i.start,i.end)}))&&e.onRequestUpdate?.()}function nD(e,t){e.editRevision+=1,e.composerInputIntentKey=t}function rD(e,t){return e.composerInputIntentKey===t&&(e.composerInputIntentKey=null,!0)}function iD(e,t){e.pendingClearedSubmittedDraft?.key===t&&(e.pendingClearedSubmittedDraft=null)}function aD(e){return e.inputType===`insertFromPaste`||e.inputType===`insertFromDrop`}function oD(e,t,n,r,i){let a=i.pendingClearedSubmittedDraft;return!a||e.value!==a.value||r||aD(t)?!1:(e.value=n,mx(e),!0)}function sD(e){e.emojiMenu.close(),e.mentionMenu.dispose(),e.composerDraftScopeKey=null,e.dictation?.dispose(),e.microphonePicker?.dispose(),e.composerInput&&lx(e.composerInput)}function cD(e){if(e){let t=lD.get(e);t&&sD(t),lD.delete(e);return}for(let e of lD.values())sD(e);lD.clear(),BT()}var lD;function uD(){return(uD=e((()=>{Ex(),IT(),WT(),QT(),SE(),JE(),lD=new Map})))()}function dD(e){return e instanceof Element?e.closest(`.chat-controls__model-menu`):null}function fD(e){return[...e.querySelectorAll(`[data-chat-model-option]`)].filter(e=>!e.hidden).toSorted((e,t)=>Number(e.dataset.chatModelRank??e.dataset.chatModelIndex??0)-Number(t.dataset.chatModelRank??t.dataset.chatModelIndex??0))}function pD(e){return!e.disabled&&e.getAttribute(`aria-disabled`)!==`true`}function mD(e){return fD(e).filter(pD)}function hD(e){let t=e.closest(`.chat-controls__model-picker`),n=e.querySelector(`[data-chat-model-search]`),r=[...e.querySelectorAll(`[data-chat-model-list]`)];if(!t||!n||r.length===0)return;let i=t.dataset.chatModelPickerId??`chat-model-picker-${p()}`;t.dataset.chatModelPickerId=i,r.forEach((e,t)=>{e.id=`${i}-listbox-${t}`,e.closest(`section`)?.querySelector(`[data-chat-model-group-toggle]`)?.setAttribute(`aria-controls`,e.id)}),e.querySelectorAll(`[data-chat-model-option]`).forEach((e,t)=>{e.id=`${i}-option-${t}`}),n.setAttribute(`aria-controls`,r.map(e=>e.id).join(` `)),n.setAttribute(`aria-expanded`,t.open?`true`:`false`)}function gD(e,t){e.querySelectorAll(`[data-chat-model-option]`).forEach(e=>{e.toggleAttribute(`data-chat-model-highlighted`,e===t)});let n=e.querySelector(`[data-chat-model-search]`);t?.id?n?.setAttribute(`aria-activedescendant`,t.id):n?.removeAttribute(`aria-activedescendant`)}function _D(e){let t=e.currentTarget,n=dD(t);t instanceof HTMLButtonElement&&n&&gD(n,t)}function vD(e,t){e.querySelectorAll(`[data-chat-model-shortcut]`).forEach(e=>{e.hidden=!0,e.removeAttribute(`data-shortcut`),e.removeAttribute(`data-chat-model-shortcut-number`)}),t.slice(0,9).forEach((e,t)=>{let n=e.querySelector(`[data-chat-model-shortcut]`);n&&(n.hidden=!1,n.setAttribute(`data-shortcut`,String(t+1)),n.setAttribute(`data-chat-model-shortcut-number`,String(t+1)))})}function yD(e,t){let n=e.dataset.chatModelName??``,r=e.dataset.chatModelKeywords??``,i=e.dataset.chatModelProviderLabel??``;return n.startsWith(t)?0:n.includes(t)?1:r.includes(t)?2:i.startsWith(t)?3:i.includes(t)?4:(e.dataset.chatModelTarget??e.dataset.chatModelOption??``).toLocaleLowerCase().includes(t)?5:null}function bD(e,t=!1){let n=dD(e);if(!n)return;hD(n);let r=e.value.trim().toLocaleLowerCase();n.toggleAttribute(`data-chat-model-filtering`,!!r);let i=[...n.querySelectorAll(`[data-chat-model-option]`)],a=[];i.forEach((e,t)=>{let n=e.closest(`section`)?.querySelector(`[data-chat-model-group-toggle]`)?.getAttribute(`aria-expanded`)===`false`,i=r?yD(e,r):n?null:0;e.hidden=i===null,e.style.removeProperty(`--chat-model-rank`),delete e.dataset.chatModelRank,i!==null&&a.push({row:e,score:i,index:t})});let o=[];a.toSorted((e,t)=>e.score-t.score||e.index-t.index).forEach(({row:e},t)=>{e.dataset.chatModelRank=String(t),e.style.setProperty(`--chat-model-rank`,String(t)),pD(e)&&o.push(e)}),vD(n,o);let s=o.find(e=>e.getAttribute(`aria-selected`)===`true`);gD(n,(t?o.find(e=>e.hasAttribute(`data-chat-model-highlighted`)):void 0)??(r?o[0]:s??o[0]));let c=n.querySelector(`[data-chat-model-search-empty]`);c&&(c.hidden=!r||a.length>0)}function xD(e){e.querySelectorAll(`[data-chat-model-provider-toggle]`).forEach(e=>{let t=e.closest(`section`)?.querySelector(`[data-chat-model-option][aria-selected="true"]`);e.setAttribute(`aria-expanded`,String(!!t))});let t=e.querySelector(`[data-chat-model-search]`);t&&(t.value=``,bD(t))}function SD(e){e.stopPropagation();let t=e.currentTarget;t.setAttribute(`aria-expanded`,String(t.getAttribute(`aria-expanded`)!==`true`));let n=dD(t)?.querySelector(`[data-chat-model-search]`);n&&bD(n,!0)}function CD(e){if(e.key!==`Escape`)return!1;let t=e.composedPath().find(e=>e instanceof HTMLInputElement&&e.matches(`[data-chat-model-search]`));return t?.value?(t.value=``,bD(t),e.preventDefault(),e.stopPropagation(),!0):!1}function wD(e){if(e.isComposing||e.keyCode===229||e.key!==`Enter`&&e.key!==`ArrowDown`&&e.key!==`ArrowUp`)return;let t=e.currentTarget,n=dD(t);if(!n)return;let r=mD(n);if(r.length===0)return;if(e.key===`Enter`){let t=r.find(e=>e.hasAttribute(`data-chat-model-highlighted`));t&&(e.preventDefault(),t.click());return}e.preventDefault();let i=r.findIndex(e=>e.hasAttribute(`data-chat-model-highlighted`)),a=e.key===`ArrowDown`?1:r.length-1,o=i<0?0:(i+a)%r.length;gD(n,r[o]),r[o]?.scrollIntoView?.({block:`nearest`})}function TD(e){let t=e.currentTarget;if(!t.open||e.target instanceof HTMLInputElement||e.composedPath().some(e=>e instanceof HTMLElement&&e.localName===`wa-dropdown`)||!/^[1-9]$/u.test(e.key))return;let n=mD(t)[Number(e.key)-1];e.preventDefault(),n?.click()}function ED(e){if(!(e instanceof HTMLDetailsElement)||!e.open)return;let t=e.ownerDocument.activeElement,n=t?.closest(`[data-chat-model-refresh]`)&&e.contains(t)?t:void 0;queueMicrotask(()=>{let t=e.querySelector(`[data-chat-model-search]`);t&&bD(t,!0),n&&!n.isConnected&&e.isConnected&&e.open&&e.ownerDocument.activeElement===e.ownerDocument.body&&(t&&!t.disabled?t:e.querySelector(`summary`))?.focus({preventScroll:!0})})}function DD(){return(DD=e((()=>{r()})))()}function OD(e){return e instanceof HTMLDetailsElement?e.open:`open`in e&&e.open===!0||e.hasAttribute(`open`)}function kD(e){return Array.from(e.querySelectorAll(`.agent-chat__input details, .agent-chat__input wa-dropdown`)).filter(OD)}function AD(e){HD.delete(e),e.removeAttribute(GD),e instanceof HTMLDetailsElement?e.open=!1:(`open`in e&&(e.open=!1),e.removeAttribute(`open`))}function jD(e){return e instanceof HTMLDetailsElement?e.querySelector(`summary`):e.querySelector(`[slot=trigger]`)}function MD(){this.removeEventListener(`blur`,MD),this.removeEventListener(`keydown`,MD),this.removeAttribute(WD)}function ND(e){let t=UD.get(e)??{owners:new Set,dispose:PD(e)};UD.set(e,t);let n=Symbol(`composer picker`);return t.owners.add(n),()=>{!t.owners.delete(n)||t.owners.size>0||(UD.delete(e),t.dispose())}}function PD(e){let t=new AbortController,n={capture:!0,signal:t.signal};function r(t){let n=t.composedPath();for(let t of kD(e))n.includes(t)||AD(t);for(let t of e.querySelectorAll(`.agent-chat__input > :is(.slash-menu, .skill-menu, .emoji-menu-popup)`))n.includes(t)||t.closest(`.agent-chat__input`)?.dispatchEvent(new CustomEvent(KD))}function i(t){if(t.isComposing||t.keyCode===229||t.defaultPrevented||Zt(t,e)||t.key!==`Escape`||e.querySelector(`.shell-nav[aria-modal='true']`)||CD(t))return;let n=kD(e),r=e.querySelector(`.agent-chat__input > :is(.slash-menu, .skill-menu, .emoji-menu-popup)`)?.closest(`.agent-chat__input`);if(n.length===0&&!r)return;t.preventDefault(),t.stopPropagation();let i=n.filter(e=>!n.some(t=>t!==e&&e.contains(t))),a=i.at(-1);i.forEach(AD),r?.dispatchEvent(new CustomEvent(KD)),r?.querySelector(`.agent-chat__composer-combobox > textarea`)?.focus({preventScroll:!0}),a&&jD(a)?.focus({preventScroll:!0})}return e.addEventListener(`pointerdown`,r,n),e.defaultView?.addEventListener(`keydown`,i,n),e.addEventListener(`keydown`,e=>{let t=e.composedPath().find(e=>e instanceof HTMLElement&&e.localName===`wa-dropdown`);t&&(HD.delete(t),t.removeAttribute(GD))},n),()=>t.abort()}function FD(e){let t=e.closest(`.agent-chat__input`);if(t)for(let n of kD(t))n!==e&&!n.contains(e)&&AD(n)}function ID(e){let t=e.currentTarget;t instanceof HTMLDetailsElement&&t.open&&FD(t)}function LD(e){let t=e.target;t instanceof HTMLElement&&t.localName===`wa-dropdown`&&(HD.has(t)||t.removeAttribute(GD),FD(t))}function RD(e){let t=e.composedPath().find(e=>e instanceof HTMLElement&&e.localName===`wa-dropdown`);t&&(HD.add(t),t.setAttribute(GD,``))}function zD(e){let t=e.target instanceof HTMLElement&&e.target.localName===`wa-dropdown`?e.target:e.currentTarget;if(t instanceof HTMLElement&&t.localName===`wa-dropdown`&&HD.delete(t)){let e=jD(t);if(!e)return;e.setAttribute(WD,``),e.addEventListener(`blur`,MD,{once:!0}),e.addEventListener(`keydown`,MD,{once:!0}),e.focus({preventScroll:!0})}}function BD(e){let t=typeof window.matchMedia==`function`&&window.matchMedia(VD).matches?e.closest(`.agent-chat__input`)??void 0:void 0;tl(e,`top`,{alignment:`end`,anchor:t})}var VD,HD,UD,WD,GD,KD;function qD(){return(qD=e((()=>{Us(),V(),DD(),VD=`(max-width: 640px), (max-width: 932px) and (max-height: 500px) and (orientation: landscape)`,HD=new WeakSet,UD=new WeakMap,WD=`data-chat-pointer-restored-focus`,GD=`data-chat-pointer-opened-picker`,KD=`openclaw-composer-dismiss-invocations`})))()}function JD(e){return e.some(e=>e instanceof Element&&(e.matches(`a, img, audio, video, iframe, input, textarea, select`)||e instanceof HTMLElement&&(e.isContentEditable||e.getAttribute(`contenteditable`)===`true`||e.getAttribute(`contenteditable`)===`plaintext-only`||e.getAttribute(`contenteditable`)===``)))}function YD(e){let t=e.closest(`.code-block-wrapper`)?.querySelector(`.code-block-copy`);if(t)return{label:L(`common.copyCode`),text:fl(t)};let n=e.closest(`pre, code`);if(n)return{label:L(`common.copyCode`),text:n.textContent??``};let r=e.closest(`table`)??e.closest(`.markdown-table`)?.querySelector(`table`);if(r instanceof HTMLTableElement)return{label:L(`common.copyTable`),text:$c(r)};let i=e.closest(`.chat-assistant-attachment-card, .chat-attachment-file`);if(i){let e=i.querySelector(`a.chat-assistant-attachment-card__download[href]:not([aria-disabled='true'])`);if(e?.getAttribute(`href`))return{label:L(`chat.messages.copyLink`),text:e.href};let t=i.querySelector(`.chat-assistant-attachment-card__title, .chat-attachment-file__name`)?.textContent;if(t)return{label:L(`chat.messages.copyFileName`),text:t}}return null}function XD(){return(XD=e((()=>{Ks(),Wl(),R(),$r(),di()})))()}function ZD(e){sO&&(e===void 0||sO.paneId===e)&&(window.clearTimeout(sO.timer),sO=null),(e===void 0||oO?.paneId===e)&&(oO?.element.remove(),oO?.listeners.abort(),oO=null)}function QD(e){return oO?.paneId===e&&oO.element.contains(document.activeElement)}function $D(e,t){if(e.isCollapsed||e.rangeCount!==1)return null;let n=e.getRangeAt(0),r=n.commonAncestorContainer,i=(r instanceof Element?r:r.parentElement)?.closest(`.chat-bubble`);if(!i||!t.contains(i))return null;let a=e.toString();if(!a.trim())return null;let o=n.cloneRange();o.selectNodeContents(i),o.setEnd(n.startContainer,n.startOffset);let s=o.toString().length;return o.setEnd(n.endContainer,n.endOffset),{text:a,start:s,end:o.toString().length,...i.dataset.messageId?{messageId:i.dataset.messageId}:{},...i.dataset.entryId?{entryId:i.dataset.entryId}:{}}}function eO(e,t){let n=window.visualViewport,r=(n?.offsetLeft??0)+8,i=(n?.offsetTop??0)+8,a=r+(n?.width??window.innerWidth)-16,o=i+(n?.height??window.innerHeight)-16;e.style.maxWidth=`${a-r}px`,e.style.maxHeight=`${o-i}px`;let s=e.getBoundingClientRect(),c=t.left+t.width/2-s.width/2,l=t.top-s.height-8,u=t.bottom+8,d=e.classList.contains(`chat-annotation-editor`)&&u+s.height<=o||l<i?u:l;e.style.left=`${Math.max(r,Math.min(c,a-s.width))}px`,e.style.top=`${Math.max(i,Math.min(d,o-s.height))}px`}function tO(e,t,n,r,i){ZD(),document.body.appendChild(e);let a=new AbortController;oO={element:e,listeners:a,paneId:n};let{signal:o}=a,s=()=>eO(e,i?.getBoundingClientRect()??t);return s(),document.addEventListener(`pointerdown`,t=>{e.contains(t.target)||ZD()},{capture:!0,signal:o}),document.addEventListener(`keydown`,e=>{ot(Me.escape,e)&&(e.preventDefault(),e.stopPropagation(),ZD(),r?.())},{signal:o}),document.addEventListener(`scroll`,t=>{(!(t.target instanceof Node)||!e.contains(t.target))&&ZD()},{capture:!0,passive:!0,signal:o}),window.addEventListener(`resize`,s,{signal:o}),window.visualViewport?.addEventListener(`resize`,s,{signal:o}),o}function nO(e,t){let n=document.createElement(`button`);return n.type=`button`,n.setAttribute(`aria-label`,e),n.textContent=e,n.addEventListener(`click`,t),n}function rO(e,t,n){let r=document.createElement(`div`);r.className=`chat-selection-popup`,r.setAttribute(`role`,`toolbar`),r.setAttribute(`aria-label`,L(`chat.messages.selectionActions`)),r.addEventListener(`pointerdown`,e=>e.preventDefault());let i=e=>{ZD(),window.getSelection()?.removeAllRanges(),e()};if(n.onAddToChat){let a=n.onAddToChat;r.append(nO(L(`chat.messages.addToChat`),()=>i(()=>a(t,e))))}r.append(nO(L(`chat.messages.askInSideChat`),()=>i(()=>n.onAskSideChat(t,e))));let a=tO(r,e,n.paneId);document.addEventListener(`selectionchange`,()=>{(!window.getSelection()||window.getSelection()?.isCollapsed)&&ZD()},{signal:a})}function iO(e){if(e.readSignal?.aborted)return;let t=document.createElement(`div`);t.className=`chat-annotation-editor`,t.setAttribute(`role`,`dialog`),t.setAttribute(`aria-label`,L(`chat.messages.annotationEditor`));let n=document.createElement(`textarea`);n.value=e.comment,n.rows=1,n.placeholder=L(`chat.messages.annotationComment`),n.setAttribute(`aria-label`,L(`chat.messages.annotationComment`));let r=()=>{ZD(),e.onCancel?.()},i=()=>{if(e.readSignal?.aborted){ZD();return}e.onSave(n.value)!==!1&&ZD()},a=nO(L(`chat.messages.saveAnnotation`),i);a.className=`btn primary chat-annotation-editor__confirm`,a.textContent=``,Xn(z.cornerDownLeft,a);let o=document.createElement(`div`);o.className=`chat-annotation-editor__controls`;let s=nO(L(`chat.messages.deleteAnnotation`),()=>{ZD(),e.readSignal?.aborted||(e.onDelete??e.onCancel)?.()});s.className=`btn btn--icon btn--ghost chat-annotation-editor__delete`,s.title=L(`chat.messages.deleteAnnotation`),s.textContent=``,Xn(z.trash,s);let c=nO(L(`common.cancel`),r);c.className=`btn`;let l=nO(L(`common.save`),i);l.className=`btn primary`,o.append(s,c,l),t.append(n,a,o),e.expanded&&t.classList.add(`chat-annotation-editor--expanded`),t.addEventListener(`keydown`,e=>{if(e.target===n&&(ot(Me.sendMessage,e)||ot(Me.modifiedEnter,e))&&(e.preventDefault(),i()),e.key===`Tab`){let r=[n,...Array.from(t.querySelectorAll(`button`))].filter(e=>e.getClientRects().length>0),i=r[0],a=r.at(-1);e.shiftKey&&document.activeElement===i?(e.preventDefault(),a?.focus()):!e.shiftKey&&document.activeElement===a&&(e.preventDefault(),i?.focus())}});let u=tO(t,e.anchorRect,e.paneId,e.onCancel,e.anchorElement),d=()=>{let r=n.scrollTop;n.style.height=`auto`,n.style.height=`${n.scrollHeight}px`,n.scrollTop=r,Bc(n),eO(t,e.anchorElement?.getBoundingClientRect()??e.anchorRect)};n.addEventListener(`input`,d,{signal:u}),n.addEventListener(`scroll`,()=>Bc(n),{passive:!0,signal:u}),window.addEventListener(`resize`,d,{signal:u}),d(),e.sourceRange&&typeof Highlight<`u`&&(CSS.highlights.set(`openclaw-comment`,new Highlight(e.sourceRange)),u.addEventListener(`abort`,()=>CSS.highlights.delete(`openclaw-comment`),{once:!0}));let f=()=>ZD();return e.readSignal?.addEventListener(`abort`,f,{once:!0}),u.addEventListener(`abort`,()=>e.readSignal?.removeEventListener(`abort`,f),{once:!0}),n.focus({preventScroll:!0}),n.setSelectionRange(n.value.length,n.value.length),()=>{oO?.element===t&&eO(t,e.anchorElement?.getBoundingClientRect()??e.anchorRect)}}function aO(e,t){let n=e.currentTarget instanceof HTMLElement?e.currentTarget:null;n&&(ZD(),sO={paneId:t.paneId,timer:window.setTimeout(()=>{sO=null;let e=window.getSelection(),r=e?$D(e,n):null;r&&e&&n.isConnected&&rO(e.getRangeAt(0).getBoundingClientRect(),r,t)},0)})}var oO,sO;function cO(){return(cO=e((()=>{K(),B(),oc(),R(),$r(),Ge(),di(),oO=null,sO=null})))()}function lO(){return{asyncQuestionDrafts:new Map,asyncQuestionRevision:0,turnRecapWatch:null,searchOpen:!1,searchQuery:``,searchFocusPending:!1,searchReturnFocusTarget:null,searchReturnFocusOwner:null,transcriptRenderDependencies:[],transcriptRenderContext:{}}}function uO(e){let t=CO.get(e);if(t)return t;let n=lO();return CO.set(e,n),n}function dO(e,t){let n=wO?.paneId===e?wO.element:null;return t.contains(t.ownerDocument.activeElement)||QD(e)||nm(t)||!!(n&&(n.contains(document.activeElement)||nm(n)))}function fO(e,t){vO(e),t&&tm(t),ZD(e)}function pO(e,t){fO(e,t),t?.querySelectorAll(`.chat-thread`).forEach(sl);let n=CO.get(e);n&&(n.asyncQuestionDrafts=new Map,n.searchOpen=!1,n.searchQuery=``,n.searchFocusPending=!1,n.searchReturnFocusTarget=null,n.searchReturnFocusOwner=null)}function mO(e,t){fO(e,t);let n=e?[CO.get(e)]:CO.values();for(let e of n)e&&(e.asyncQuestionGeneration=(e.asyncQuestionGeneration??0)+1,e.asyncQuestionDrafts=new Map);e?(CO.delete(e),Uu(e)):(CO.clear(),Uu())}function hO(e,t){let n=uO(e);return n.searchOpen?H`
    <div
      class="agent-chat__search-bar"
      @keydown=${e=>{e.key!==`Escape`||e.defaultPrevented||e.isComposing||e.keyCode===229||(e.preventDefault(),e.stopPropagation(),gO(n,t))}}
    >
      ${z.search}
      <input
        type="text"
        placeholder=${L(`chat.thread.searchPlaceholder`)}
        aria-label=${L(`chat.thread.search`)}
        .value=${n.searchQuery}
        ${n.searchFocusPending?U(e=>{e instanceof HTMLInputElement&&(n.searchFocusPending=!1,queueMicrotask(()=>{e.isConnected&&e.focus({preventScroll:!0})}))}):G}
        @input=${e=>{n.searchQuery=e.target.value,t()}}
      />
      <openclaw-tooltip .content=${L(`chat.thread.closeSearch`)}>
        <button
          class="btn btn--ghost"
          aria-label=${L(`chat.thread.closeSearch`)}
          @click=${()=>gO(n,t)}
        >
          ${z.x}
        </button>
      </openclaw-tooltip>
    </div>
  `:G}function gO(e,t){let n=e.searchReturnFocusTarget,r=e.searchReturnFocusOwner;e.searchOpen=!1,e.searchQuery=``,e.searchFocusPending=!1,e.searchReturnFocusTarget=null,e.searchReturnFocusOwner=null,t(),queueMicrotask(()=>{(n?.isConnected?n:r?.querySelector(`.agent-chat__composer-combobox > textarea`))?.focus({preventScroll:!0})})}function _O(e,t,n){let r=uO(e);if(r.searchOpen){gO(r,t);return}r.searchOpen=!0,r.searchFocusPending=!0;let i=n?.target,a=n?.currentTarget;r.searchReturnFocusTarget=i instanceof HTMLElement&&i.isConnected?i:null,r.searchReturnFocusOwner=a instanceof HTMLElement&&a.isConnected?a:null,t()}function vO(e){let t=wO;if(e&&e!==t?.paneId)return;t&&(tm(t.element),t.element.remove()),wO=null;let n=document.querySelector(`.chat-reply-context-menu`);n&&(tm(n),n.remove()),t?.listeners.abort()}function yO(e){let t=e.currentTarget,n=e.target;if(e.pointerType!==`touch`||!(t instanceof HTMLElement)||!(n instanceof Element))return;let r=n.closest(`.chat-group--with-footer`);if(!(r instanceof HTMLElement)||!t.contains(r)||n.closest(`a, button, details, input, label, select, textarea, [contenteditable]`))return;let i=window.getSelection();if(i&&!i.isCollapsed)return;let a=!r.classList.contains(`chat-group--meta-revealed`);for(let e of t.querySelectorAll(`.chat-group--meta-revealed`))e.classList.remove(`chat-group--meta-revealed`);r.classList.toggle(`chat-group--meta-revealed`,a)}function bO(e,t){yO(e),!(e.button!==0||e.ctrlKey||typeof t.onCompanionSelection!=`function`)&&aO(e,{paneId:t.paneId,onAddToChat:t.onAddToChat,onAskSideChat:(e,n)=>t.onCompanionSelection?.(e,n)})}function xO(e,t){if(!e||e.isCollapsed)return!1;for(let n=0;n<e.rangeCount;n+=1)if(e.getRangeAt(n).intersectsNode(t))return!0;return!1}function SO(e,t){if(e.defaultPrevented||JD(e.composedPath()))return;let n=e.composedPath().find(e=>e instanceof Element);if(!n)return;let r=n.closest(`.chat-bubble`),i=r?.closest(`.chat-group`);if(i?.querySelector(`.chat-reading-indicator, .chat-bubble.streaming`))return;let a=YD(n),o=window.getSelection(),s=xO(o,r??n)?o?.toString():``,c=r?.messageActions?.replyTarget,l=r?.dataset.entryId?.trim()??``,u=r?.dataset.messageId?.trim()??``,d=i?.classList.contains(`user`)&&!!l,f=[...i?.querySelectorAll(`[data-message-actions-for]`)??[]].find(e=>e.dataset.messageActionsFor===u),p=f?.querySelector(`.chat-copy-btn`),m=i?.dataset.chatRowKey?.startsWith(`agent-run:`)===!0,h=!(!c||!t.onSetReply||m&&!f),g=d&&typeof t.onRewindMessage==`function`,_=r?.messageActions?.copyMarkdown,v=!!(p||_),y=d&&typeof t.onForkMessage==`function`;if(!h&&!g&&!v&&!y&&!s&&!a?.text)return;e.preventDefault(),e.stopPropagation(),vO();let b=document.createElement(`div`);b.className=`chat-reply-context-menu`,b.setAttribute(`role`,`menu`),b.setAttribute(`aria-label`,L(`chat.messages.actions`)),b.style.left=`${e.clientX}px`,b.style.top=`${e.clientY}px`;let x=[],S=e=>{let t=document.createElement(`button`);t.type=`button`,t.disabled=e.disabled??!1,t.setAttribute(`role`,`menuitem`),t.addEventListener(`click`,e.onClick);let n=document.createElement(`span`);n.dataset.copyLabel=``,n.textContent=e.label,t.append(n);let r=document.createElement(`openclaw-tooltip`);return r.content=e.tooltip,r.append(t),e.className&&(r.className=e.className),b.append(r),x.push(t),t},C=(e,n)=>{n&&S({label:e,tooltip:e,onClick:r=>{Nc(r,n,e).then(e=>{e&&wO?.element===b&&vO(t.paneId)})}})};if(s&&C(L(`chat.messages.copySelection`),s),a&&C(a.label,a.text),h&&c){let e=document.createElement(`button`);e.type=`button`,e.setAttribute(`role`,`menuitem`),e.setAttribute(`aria-label`,L(`chat.messages.replyToMessage`)),e.textContent=L(`chat.messages.reply`),e.addEventListener(`click`,()=>{t.onSetReply?.(c),vO(),t.onFocusComposer?.()}),b.append(e),x.push(e)}let w=!!(t.runActive||t.runWorking);if(g){let e=S({label:L(`chat.messages.rewindToHere`),disabled:w,tooltip:L(w?`chat.messages.rewindUnavailable`:`chat.messages.rewindToHere`),className:`chat-confirm-wrap chat-rewind-wrap`,onClick:()=>{sm(e,()=>{vO(),Promise.resolve(t.onRewindMessage?.(l)).then(e=>{e&&t.onFocusComposer?.()})})}})}_&&!p?C(Xs(),_):p&&S({label:Xs(),tooltip:Xs(),onClick:()=>{vO(),p?.click()}}),y&&S({label:L(`chat.messages.forkFromHere`),disabled:w,tooltip:L(w?`chat.messages.forkUnavailable`:`chat.messages.forkFromHere`),onClick:()=>{vO(),t.onForkMessage?.(l)}}),(n.closest(`openclaw-modal-dialog, dialog`)??document.body).appendChild(b);let T={element:b,paneId:t.paneId,listeners:new AbortController};wO=T;let E=b.getBoundingClientRect(),D=e.clientX,O=e.clientY;D+E.width>window.innerWidth&&(D=window.innerWidth-E.width-8),O+E.height>window.innerHeight&&(O=window.innerHeight-E.height-8),b.style.left=`${Math.max(0,D)}px`,b.style.top=`${Math.max(0,O)}px`,x.find(e=>!e.disabled)?.focus(),requestAnimationFrame(()=>{if(!b.isConnected||wO!==T)return;let e=e=>{b.contains(e.target)||vO()},n=e=>{e.key===`Escape`&&(e.preventDefault(),e.stopPropagation(),vO(),t.onFocusComposer?.())},{signal:r}=T.listeners;document.addEventListener(`click`,e,{signal:r}),document.addEventListener(`contextmenu`,e,{capture:!0,signal:r}),document.addEventListener(`keydown`,n,{signal:r})})}var CO,wO;function TO(){return(TO=e((()=>{K(),W(),ic(),B(),Wl(),R(),V(),$r(),rd(),XD(),gm(),lS(),cO(),di(),CO=new Map,wO=null})))()}var EO;function DO(){return(DO=e((()=>{rd(),EO=class{constructor(){this.input=null,this.projected=new Map,this.committed=new Map,this.refs=new Map,this.seen=new Set,this.pending=new Set,this.active=new Map,this.enabled=!1,this.refFor=e=>this.refs.get(e)}get projectedKeys(){return this.projected}project(e){if(this.input===e)return this.projected;let t=new Map;for(let n of e)if(n.kind===`group`&&(n.role===`user`||ku(n)))for(let e of n.messages)t.set(e.key,n.role===`user`?e.key:null);else n.kind===`stream`&&t.set(n.key,null);return this.input=e,this.projected=t,t}sync(e,t){if(e===this.committed&&t===this.enabled)return;let n=[...e.keys()],r=n.findIndex(e=>this.committed.has(e));this.pending.clear();for(let[i,a]of n.entries()){let n=e.get(a);if(n!=null&&(t&&this.enabled&&(this.committed.size===0||r>=0&&i>=r)&&!this.seen.has(n)&&this.pending.add(n),!this.refs.has(a))){let e;this.refs.set(a,t=>{e!==t&&(e&&this.active.get(e)?.(),e=t instanceof HTMLElement?t:void 0),e&&this.pending.delete(n)&&this.enter(e)})}}for(let t of this.refs.keys())e.has(t)||(this.refs.get(t)?.(void 0),this.refs.delete(t));for(let t of e.values())t!==null&&this.seen.add(t);this.committed=e,this.enabled=t}enter(e){if(this.active.get(e)?.(),globalThis.matchMedia?.(`(prefers-reduced-motion: reduce)`).matches)return;let t=()=>{this.active.get(e)===t&&(this.active.delete(e),e.removeEventListener(`animationend`,n),e.removeEventListener(`animationcancel`,n),e.classList.remove(`chat-bubble--enter`))},n=n=>{n.target===e&&n.animationName===`chat-message-enter`&&t()};this.active.set(e,t),e.addEventListener(`animationend`,n),e.addEventListener(`animationcancel`,n),e.classList.add(`chat-bubble--enter`)}didCommit(){this.pending.clear()}disconnect(){this.enabled=!1,this.pending.clear();for(let e of this.active.values())e()}}})))()}var OO;function kO(){return(kO=e((()=>{OO=class{constructor(){this.highlight=null}reveal(e,{messageId:t,behavior:n},r){let i=[...e?.querySelectorAll(`.chat-bubble`)??[]].find(e=>(e.dataset.entryId??e.dataset.messageId)===t),a=r.scrollElement;if(!i||!a)return!1;this.clear();let o=i.getBoundingClientRect(),s=a.scrollTop+o.top-a.getBoundingClientRect().top-a.clientTop+(o.height-a.clientHeight)/2;r.scrollToOffset(s,{behavior:n});let c=n===`auto`?1e3:1200;return i.style.setProperty(`--duration`,`${c}ms`),i.classList.add(`chat-bubble--reply-target`),this.highlight={element:i,timer:window.setTimeout(()=>this.clear(),c)},!0}clear(){this.highlight&&=(window.clearTimeout(this.highlight.timer),this.highlight.element.classList.remove(`chat-bubble--reply-target`),this.highlight.element.style.removeProperty(`--duration`),null)}}})))()}function AO(e){let t=i(e)?.content;return(Array.isArray(t)?t:[]).flatMap(e=>(ei(e)??[]).filter(e=>e.type===`attachment_error`)).map(({attachment:e})=>`${e.label}: ${L(`chat.attachments.notSent`)}. ${lh(e.code)}`).join(` `)||null}function jO(e){let t=Uo(e)?.trim();return[AO(e),t].filter(Boolean).join(` `)||null}function MO(e,t=jO){if(e.role.toLowerCase()!==`assistant`)return null;for(let n=e.messages.length-1;n>=0;--n){let r=e.messages[n],i=t(r?.message);if(i)return{key:r?.key??e.key,text:i}}return null}function NO(e){let t=(e,t)=>({key:e,text:o(t,PO)});for(let n=e.length-1;n>=0;--n){let r=e[n];if(!r)continue;let i=jO;if(r.kind===`agent-run-frame`){if(r.outcome.kind===`completed`){let e=r.outcome.actionOwner,n=e?jO(e.message):null;if(e&&n)return t(e.key,n);i=AO}if(r.outcome.kind===`failed`)continue}for(let e of r.kind===`agent-run-frame`?r.parts.toReversed():[r]){if(e.kind===`stream-run`){if(r.kind===`agent-run-frame`&&r.outcome.kind!==`completed`){let n=e.parts.findLast(e=>e.kind===`stream`&&e.text.trim());if(n?.kind===`stream`)return t(n.key,n.text.trim())}continue}let n=e.kind===`group`?[e]:e.kind===`work-group`||e.kind===`activity-run`?e.groups.toReversed():[];for(let e of n){let n=MO(e,i);if(n)return t(n.key,n.text)}}}return null}var PO,FO;function IO(){return(IO=e((()=>{R(),Fo(),$i(),fh(),PO=500,FO=class{constructor(){this.text=``}sync(e,t){this.key===void 0||!t?(this.key=e?.key??null,this.text=``):e&&e.key!==this.key&&(this.key=e.key,this.text=e.text)}}})))()}function LO(e){if(!(e instanceof HTMLElement)||typeof getComputedStyle!=`function`)return 0;let t=Number.parseFloat(getComputedStyle(e).paddingTop);return Number.isFinite(t)?t:0}function RO(e,t){return LO(e)+t}function zO(e,t,n){let r=RO(e,n);r!==t.options.scrollMargin&&t.setOptions({...t.options,scrollMargin:r})}function BO(e){let t=e instanceof HTMLElement?e.clientWidth:0,n=e instanceof HTMLElement?e.clientHeight:0;return{width:t||(typeof window>`u`?0:window.innerWidth),height:n||(typeof window>`u`?0:window.innerHeight)}}function VO(e,t){let n=e?.getBoundingClientRect();if(!e||t.scrollElement!==e||!n?.width||!n.height)return!1;let r=!1;for(let n of e.querySelectorAll(`.chat-virtual-row`)){let e=t.indexFromElement(n),i=Number.parseFloat(getComputedStyle(n).height),a=t.options.getItemKey(e),o=t.itemSizeCache.get(a);t.resizeItem(e,Number.isFinite(i)?i:n.offsetHeight),r||=t.itemSizeCache.get(a)!==o}return r}function HO(e,t,n){let r=t.range,i=n&&!t.options.useCachedMeasurements&&r?e.flatMap(e=>{let n=t.indexFromElement(e);return e.isConnected&&n>=r.startIndex&&n<=r.endIndex&&!t.itemSizeCache.has(t.options.getItemKey(n))?[{element:e,index:n}]:[]}):[];if(i.length>0&&t.scrollElement?.clientHeight){let e=i.map(({element:e,index:t})=>({element:e,index:t,visibility:e.style.getPropertyValue(`content-visibility`),priority:e.style.getPropertyPriority(`content-visibility`)})),n=[];try{for(let{element:t}of e)t.style.setProperty(`content-visibility`,`visible`);for(let{element:r,index:i}of e)n.push({index:i,size:t.options.measureElement(r,void 0,t)})}finally{for(let{element:t,visibility:n,priority:r}of e)n?t.style.setProperty(`content-visibility`,n,r):t.style.removeProperty(`content-visibility`)}for(let{index:e,size:r}of n)t.resizeItem(e,r)}for(let n of e)t.measureElement(n)}function UO(e,t,n){let r=t?.borderBoxSize?.[0]?.blockSize??zs(e,t,n);if(r===0&&n.scrollElement?.clientHeight===0){let t=n.indexFromElement(e);return n.itemSizeCache.get(n.options.getItemKey(t))??n.options.estimateSize(t)}return r}function WO(e){return e&&e.clientHeight>0?Math.max(0,e.scrollHeight-e.clientHeight):null}function GO(e,t){let n=WO(e),r=t.scrollOffset;return n===null||r===null?`pending`:r>=0&&r<=n?`settled`:n===0?(t.scrollOffset=0,t.scrollToOffset(0),`corrected`):`pending`}var KO;function qO(){return(qO=e((()=>{Ns(),KO=class{constructor(e,t){this.host=e,this.inner=t,this.frame=null,this.resizeObserver=null,this.viewport=null,this.innerElement=null,this.region=null,e.addController(this)}hostUpdated(){let e=this.host.scrollElement,t=this.inner(),n=e?.closest(`.chat-main__conversation`)??e;if(e===this.viewport&&t===this.innerElement&&n===this.region||(this.hostDisconnected(),!e?.isConnected||t?.parentElement!==e||!n))return;this.viewport=e,this.innerElement=t,this.region=n;let r=t.querySelector(`:scope > .chat-virtual-sizer`)??t,i,a;this.resizeObserver=new ResizeObserver(e=>{let t=!1;for(let o of e)if(o.target===r){let e=o.borderBoxSize?.[0]?.inlineSize??o.contentRect.width;t||=e!==i,i=e}else if(o.target===n){let e=o.borderBoxSize?.[0]?.blockSize??o.contentRect.height;t||=e!==a,a=e}t&&this.scheduleSync()}),this.resizeObserver.observe(r,{box:`border-box`}),this.resizeObserver.observe(n,{box:`border-box`}),this.scheduleSync()}scheduleSync(){this.frame===null&&(this.frame=requestAnimationFrame(()=>{this.frame=null,this.sync()}))}hostDisconnected(){this.resizeObserver?.disconnect(),this.resizeObserver=null,this.viewport=null,this.innerElement=null,this.region=null,this.frame!==null&&(cancelAnimationFrame(this.frame),this.frame=null)}sync(){let e=this.host.scrollElement,t=this.inner();if(!e?.isConnected||t?.parentElement!==e)return;let n=e.getBoundingClientRect().left+e.clientLeft,r=t.getBoundingClientRect().left-n,i=t.clientWidth;i>0&&e.style.setProperty(`--chat-transcript-column-width`,`${i}px`);let a=e.closest(`.chat-main__conversation`)??e;e.style.setProperty(`--chat-position-rail-viewport-height`,`${a.clientHeight}px`),e.toggleAttribute(`data-position-rail-gutter`,r>=68)}}})))()}var JO;function YO(){return(YO=e((()=>{Jd(),qO(),xf(),JO=class{constructor(){this.offset=null,this.frame=null,this.maxOffset=null,this.lastOffset=null,this.composerResizePending=null}isResizeAnchor(e){let t=WO(e);return this.offset!==null&&t!==null&&e!==null&&Math.abs(e.scrollTop-this.offset)<=1&&this.offset!==t}recordLayoutCorrection(e,t){this.offset!==null&&Math.abs(this.offset-e)<=1?this.offset=t:this.clear()}scheduleReconcile(e){this.frame===null&&(this.frame=requestAnimationFrame(()=>{this.frame=null,e()}))}cancelReconcile(){this.frame!==null&&(cancelAnimationFrame(this.frame),this.frame=null)}disconnect(){this.cancelComposerResize(),this.cancelReconcile()}invalidateComposerResize(e){this.composerResizePending??={preserveEnd:e&&this.maxOffset!==null&&this.lastOffset!==null&&this.maxOffset-this.lastOffset<=8}}commitComposerResize(e,t,n,r){if(!this.composerResizePending||!t||r)return null;let{preserveEnd:i}=this.composerResizePending;this.composerResizePending=null;let a=this.maxOffset,o=this.lastOffset,s=WO(e);if(!e||s===null)return null;let c=e.scrollTop,l=a!==null&&Math.abs(c-Math.min(a,s))<=8,u=!n&&l&&this.lastOffset!==null&&c>this.lastOffset;(i||l&&(n||u))&&(e.scrollTop=s,this.offset=e.scrollTop),this.maxOffset=s,this.lastOffset=e.scrollTop;let d={before:i&&o!==null&&o>s&&c===s?o:c,after:e.scrollTop,resumeFollow:u};return(a!==s||d.before!==d.after)&&bf(e,{type:`resize`,...d.before===d.after?{}:{scrollCorrection:{before:d.before,after:d.after}}}),d}cancelComposerResize(){this.composerResizePending=null}get atEnd(){return this.maxOffset!==null&&this.lastOffset!==null&&Math.abs(this.maxOffset-this.lastOffset)<=1}recordViewport(e){return this.maxOffset=WO(e),this.lastOffset=e?.scrollTop??null,this.atEnd}clear(){this.cancelComposerResize(),this.offset=null}capture(e){this.offset=this.recordViewport(e)?this.maxOffset:null}reconcile(e,t,n,r){let i=this.recordViewport(e);if(!t){this.clear();return}if(!n&&e&&this.maxOffset!==null&&this.offset!==null){if(i){this.offset=this.maxOffset;return}if(Math.abs(e.scrollTop-this.offset)>1){this.clear();return}r()}}}})))()}function XO(e,t,n,r){if(n===r)return r;let i=n-r;e.setOptions({...e.options,scrollMargin:RO(t,n)});let a=e.scrollOffset,o=a===null?null:Math.max(0,a+i);return o!==null&&o!==a&&(e.scrollOffset=o,e.scrollToOffset(o)),n}function ZO(){return(ZO=e((()=>{qO()})))()}function QO(e){let t=e.target,n=(t instanceof Element?t.closest(`button[aria-expanded], button[aria-pressed], summary`):null)?.closest(`.chat-virtual-row`);return n?{row:n,top:n.getBoundingClientRect().top}:null}function $O(e,t,n,r){if(!e)return!0;let i=e.row;if(i.closest(`.sidebar-region__right-runtime`)&&!(t instanceof Element&&t.contains(i)))return!1;if(!i.isConnected||!n?.contains(i))return!0;let a=r.indexFromElement(i),o=r.options;return r.setOptions({...o,anchorTo:`start`}),r.resizeItem(a,i.offsetHeight),r.setOptions(o),n.scrollTop+=i.getBoundingClientRect().top-e.top,!0}function ek({rows:e,renderRow:t,virtualizer:n,overlay:r,header:i,scrollElementRef:a,captureInteractionResize:o,measureRowRefFor:s,measureRows:c,layout:l,headerHeight:u}){let d=n.getVirtualItems();return H`
    <div
      class="chat-thread-inner chat-thread-inner--virtual"
      ?data-measuring-rows=${c}
      ${U(a)}
      ${wf(l,n.getTotalSize()+u)}
      @click=${{handleEvent:o,capture:!0}}
    >
      ${i}
      <div class="chat-virtual-sizer">
        ${r}
        <div
          class="chat-virtual-block"
          style=${nr({transform:`translateY(${(d[0]?.start??n.options.scrollMargin)-n.options.scrollMargin}px)`})}
        >
          ${q(d,e=>e.key,(n,r)=>{let i=e[n.index];if(!i)return G;let a=d[r-1],o=a&&n.index>a.index+1?n.start-a.end:0;return H`
                ${o>0?H`<div aria-hidden="true" style=${nr({height:`${o}px`})}></div>`:G}
                <div
                  class="chat-virtual-row ${n.index===0?`chat-virtual-row--first`:``}"
                  style=${nr({containIntrinsicBlockSize:`${n.size}px`})}
                  data-index=${String(n.index)}
                  data-virtual-row-key=${i.key}
                  ${U(s(i.key))}
                >
                  ${t(i)}
                </div>
              `})}
        </div>
      </div>
    </div>
  `}function tk(){return(tk=e((()=>{K(),W(),ur(),rr(),Sf()})))()}function nk(){return{pendingScrollOffset:null,scrollCommand:null,touching:!1,touchScrolling:!1,get touchActive(){return this.touching||this.touchScrolling},renderedScrollState:{atEnd:!1,touchActive:!1},renderState(e){return{atEnd:e,touchActive:this.touchActive}},maintenanceScrollOffset:null,pendingInteractionAnchor:null,syncNativeOffset:null,recordProgrammaticScroll:null}}function rk(e,t){return t!==null&&e.maintenanceScrollOffset!==null&&Math.min(e.maintenanceScrollOffset,WO(t)??0)===t.scrollTop}function ik(e,t){let n=(WO(t)??0)-(t?.scrollTop??0);return rk(e,t)||e.pendingScrollOffset!==null||e.scrollCommand!==null&&n>8}function ak(e,t){let n=e.scrollCommand;return!n||n.target===`end`&&n.source!==`manual`?!1:n.target!==`end`||Math.abs((WO(t)??0)-(t?.scrollTop??0))>1}function ok(e,t,{source:n,behavior:r},i,a){n!==`auto`||e.scrollCommand?.target!==`end`?i():e.scrollCommand.behavior===`smooth`&&r!==`smooth`&&a();let o=e.scrollCommand;e.scrollCommand={behavior:r,target:`end`,source:n===`auto`&&o?.target===`end`?o.source:n},t.scrollToEnd({behavior:r})}function sk(e,t,n,r){let i=r.scrollElement,a=i?.scrollTop??0;ks(t,n,r),e.recordProgrammaticScroll?.(a,i?.scrollTop??0,n.behavior===void 0)}function ck(e,t,n){let r=e.getScrollElement(),i=r?.scrollTop??0,a=0,o=null,s,c=new Set,l=e=>Array.from(e.touches).find(e=>c.has(e.identifier))?.clientY,u=e=>{r&&bf(r,e)},d=t=>{u({type:`input`,event:t,touching:e.state.touching})},f=(n,r,o)=>{let s=n-i;i=r,u({type:`offset`,delta:s,scrolling:t.isScrolling,touching:e.state.touching,programmatic:e.isProgrammaticScroll()}),!o&&(e.state.scrollCommand||e.state.pendingScrollOffset)?e.state.maintenanceScrollOffset=null:n!==r&&(e.state.maintenanceScrollOffset=r,a+=1)},p=(t,n,r)=>{r&&t!==n&&e.endAnchor.recordLayoutCorrection(t,n),f(t,n,r)};e.state.recordProgrammaticScroll=p;let m=r?Cf(r,t=>{if(t.type===`composer-input`?e.endAnchor.invalidateComposerResize(e.canFollowEnd()):t.type===`composer-layout`?e.onComposerLayout(t.changed):t.type===`before-resize`&&e.onComposerLayout(!0),t.type===`resize`&&t.scrollCorrection){let{before:e,after:n}=t.scrollCorrection;f(e,n,!0)}}):void 0,h=(t,a)=>{a&&t!==i&&e.state.touchActive&&(e.state.touchScrolling=!0);let o=t-i;if(i=t,e.state.maintenanceScrollOffset!==null){let t=Math.min(e.state.maintenanceScrollOffset,WO(r)??0),n=r?.scrollTop;e.state.maintenanceScrollOffset=n===t?n:null}let s=e.isProgrammaticScroll();a&&o!==0&&!s&&(o>0&&e.canFollowEnd()?e.endAnchor.capture(r):e.endAnchor.clear(),e.prependAnchor.moveWithReader(o)),u({type:`offset`,delta:o,scrolling:a,touching:e.state.touching,programmatic:s}),n(t,a);let c=e.onOffset(),l=e.state.renderedScrollState,d=e.state.renderState(c);(d.atEnd!==l.atEnd||d.touchActive!==l.touchActive)&&e.requestUpdate()},g=()=>{if(!r||r!==e.getScrollElement()||t.scrollElement!==r)return;let n=r.scrollTop;n!==t.scrollOffset&&h(n,t.isScrolling)};e.state.syncNativeOffset=g;let _=n=>{let r=e.state.touchActive;for(let e of n.changedTouches)c.delete(e.identifier);if(e.state.touching=c.size>0,e.state.touching){s=l(n),d(n);return}s=void 0,t.isScrolling||(e.state.touchScrolling=!1),d(n),r!==e.state.touchActive&&e.requestUpdate()},v=()=>{!e.state.touching&&e.state.touchScrolling&&(e.state.touchScrolling=!1,e.requestUpdate())},y=t=>{e.endAnchor.clear(),e.onReaderScroll(t),t&&e.canFollowEnd()&&e.endAnchor.capture(r)},b=n=>{if(!r||r!==e.getScrollElement()||t.scrollElement!==r||n instanceof KeyboardEvent&&!ed(n)||n instanceof PointerEvent&&n.target!==r)return;if(n.type===`touchstart`&&n instanceof TouchEvent){for(let e of n.changedTouches)e.target instanceof Node&&r.contains(e.target)&&c.add(e.identifier);e.state.touching=c.size>0,s=l(n)}e.endAnchor.cancelComposerResize(),e.state.pendingInteractionAnchor=null,e.state.maintenanceScrollOffset=null,d(n),(n.type!==`touchstart`||e.state.scrollCommand||e.state.pendingScrollOffset)&&e.cancelScroll(),g();let i=n instanceof WheelEvent&&n.deltaY>0||n instanceof KeyboardEvent&&([`ArrowDown`,`PageDown`,`End`].includes(n.key)||n.key===` `&&!n.shiftKey);y(i)},x=e=>{let t=l(e);s!==void 0&&t!==void 0&&t<s&&y(!0),s=t,d(e)},S=()=>e.onComposerLayout(!0);r?.addEventListener(`scroll`,S,{capture:!0,passive:!0}),r?.addEventListener(`touchmove`,x,{passive:!0});for(let e of[`wheel`,`touchstart`,`keydown`,`pointerdown`])r?.addEventListener(e,b,{passive:!0});r?.addEventListener(`scrollend`,v,{passive:!0}),r?.addEventListener(`touchend`,_,{passive:!0}),r?.addEventListener(`touchcancel`,_,{passive:!0});let C=As(t,(n,i)=>{if(r===e.getScrollElement()){if(h(n,i),i&&e.state.maintenanceScrollOffset!==null){let t=a;o!==null&&cancelAnimationFrame(o),o=requestAnimationFrame(()=>{o=null,t===a&&(e.state.maintenanceScrollOffset=null)})}i||v(),!i&&e.prependAnchor.hasPrepend&&e.requestUpdate(),!i&&Math.abs((WO(r)??0)-(r?.scrollTop??0))<=1&&r&&e.state.scrollCommand?.target===`end`&&(e.state.scrollCommand.behavior===`smooth`?e.cancelScroll():(e.state.scrollCommand=null,t.scrollToOffset(r.scrollTop,{behavior:`instant`})),e.endAnchor.capture(r))}});return()=>{o!==null&&cancelAnimationFrame(o),e.state.syncNativeOffset===g&&(e.state.syncNativeOffset=null),e.state.recordProgrammaticScroll===p&&(e.state.recordProgrammaticScroll=null,e.state.maintenanceScrollOffset=null),C?.(),m?.(),c.clear(),e.state.touching=!1,e.state.touchScrolling=!1,r?.removeEventListener(`scroll`,S,!0),r?.removeEventListener(`scrollend`,v),r?.removeEventListener(`touchend`,_),r?.removeEventListener(`touchmove`,x),r?.removeEventListener(`touchcancel`,_);for(let e of[`wheel`,`touchstart`,`keydown`,`pointerdown`])r?.removeEventListener(e,b)}}function lk(){return(lk=e((()=>{Ns(),Ku(),Jd(),qO(),xf()})))()}function uk(e,t,n,r,i){if(!e||n.length===0)return null;let a=WO(e);if(a!==null&&Math.abs(a-e.scrollTop)<=1)return n.findLast(e=>r.has(e))??null;let o=t.getVirtualItemForOffset(e.scrollTop+e.clientHeight*.5);if(!o)return null;let s=null;for(let e of n){let t=r.get(e),n=t?i.get(t):void 0;if(n!==void 0){if(n>o.index)return s??e;s=e}}return s}function dk(){return(dk=e((()=>{qO()})))()}function fk(e,t,n){let r=Ls(e);for(let i of n){let n=i===null?void 0:t.get(i);n!==void 0&&n>=0&&n<e.count&&!r.includes(n)&&r.push(n)}return r.toSorted((e,t)=>e-t)}function pk(e,t,n){let r=new Map(t.map((e,t)=>[e,t])),i=new Fs({...e.options,initialMeasurementsCache:e.takeSnapshot(),initialOffset:e.scrollOffset??e.options.initialOffset,initialRect:e.scrollRect??e.options.initialRect,onChange:()=>void 0,rangeExtractor:e=>fk(e,r,[n])});return i.scrollElement=e.scrollElement,i.setOptions({...i.options,count:t.length,getItemKey:e=>t[e]??`missing:${e}`}),new Set(i.getVirtualIndexes().flatMap(e=>t[e]??[]))}function mk(e,t){if(!(t instanceof Element)||!e?.contains(t))return null;let n=t.closest(`.chat-virtual-row[data-virtual-row-key]`);return n&&e.contains(n)&&n.dataset.virtualRowKey||null}function hk(){return(hk=e((()=>{Ns()})))()}function gk(e,t){if(!e)return null;let n=e.getBoundingClientRect();for(let r of e.querySelectorAll(`.chat-bubble[data-message-id]`)){let e=r.dataset.messageId,i=r.getBoundingClientRect();if(e&&t.has(e)&&i.bottom>n.top&&i.top<n.bottom)return{messageKey:e,rowKey:r.closest(`.chat-virtual-row`)?.dataset.virtualRowKey??null,top:i.top}}return null}function _k(e,t,n){if(!e||!t)return!1;let r=[...t.querySelectorAll(`.chat-bubble[data-message-id]`)].find(t=>t.dataset.messageId===e.messageKey);if(!r)return!1;let i=r.getBoundingClientRect().top-e.top;if(Math.abs(i)<=1)return!1;let a=Math.max(0,t.scrollHeight-t.clientHeight),o=Math.max(0,Math.min(a,t.scrollTop+i));return Math.abs(o-t.scrollTop)<=1?!1:(n.scrollToOffset(o,{behavior:`instant`}),!0)}var vk;function yk(){return(yk=e((()=>{hk(),vk=class{constructor(){this.messageKeys=new Set,this.committedMessageRows=new Map,this.pending=null}get messageKey(){return this.pending?.messageKey??null}get rowKey(){return this.pending?.rowKey??null}extractRange(e,t,n){let r=this.messageKey;return fk(e,t,[n,(r===null?null:this.committedMessageRows.get(r))??this.rowKey])}get hasPrepend(){return!!(this.firstMessageKey&&this.firstMessageKey!==this.messageKeys.keys().next().value&&this.messageKeys.has(this.firstMessageKey))}capture(e,t,n=!1){let r=this.pending&&this.messageKeys.has(this.pending.messageKey)?this.pending:null,i=!t&&(this.hasPrepend||n)?r??gk(e,this.messageKeys):null;i&&(this.pending={...i,measured:!1}),this.firstMessageKey=this.messageKeys.keys().next().value}update(e,t,n){let r=this.pending;if(!r)return!1;let i=n(),a=_k(r,e,t);return r.measured&&!i&&!a&&(this.pending=null),r.measured=!0,!0}moveWithReader(e){this.pending&&(this.pending.top-=e)}clear(){this.pending=null}reset(){this.clear(),this.firstMessageKey=void 0,this.messageKeys=new Set,this.committedMessageRows=new Map}}})))()}var bk;function xk(){return(xk=e((()=>{qO(),bk=class{constructor(e,t){this.virtualizer=e,this.callbacks=t,this.refs=new Map,this.pruneQueued=!1,this.pendingRows=new Map,this.measureQueued=!1}queueMountedRow(e,t){this.pendingRows.set(e,t),!this.measureQueued&&(this.measureQueued=!0,queueMicrotask(()=>{let e=this.pendingRows;this.pendingRows=new Map,this.measureQueued=!1,queueMicrotask(()=>{HO([...e].flatMap(([e,t])=>e.isConnected&&e.dataset.virtualRowKey===t&&this.callbacks.isCurrentRow(e,t)?[e]:[]),this.virtualizer,this.callbacks.canMeasureVisibleRows())})}))}forKey(e){let t=this.refs.get(e);return t||(t=t=>{if(t instanceof HTMLElement){this.callbacks.onMount(e),this.queueMountedRow(t,e);return}this.pruneQueued||(this.pruneQueued=!0,queueMicrotask(()=>{this.pruneQueued=!1,this.virtualizer.measureElement(null)}))},this.refs.set(e,t)),t}retainKeys(e){for(let t of this.refs.keys())e.has(t)||this.refs.delete(t)}clear(){this.refs.clear(),this.pendingRows.clear()}}})))()}var Sk,Ck;function wk(){return(wk=e((()=>{Sk=2,Ck=class{constructor(e,t,n,r){this.host=e,this.virtualizer=t,this.callbacks=n,this.measureConnectedRows=r,this.presented=!1,this.renderedRows=!1,this.overscanFrame=null,this.measureFrame=null,e.addController(this)}prepare(e=!1){let t=this.host.connected&&(this.callbacks.visuallyPresented?.()??!0);(t!==this.presented||e&&this.virtualizer.options.overscan!==6)&&(this.presented=t,this.overscanFrame!==null&&(cancelAnimationFrame(this.overscanFrame),this.overscanFrame=null),t&&this.virtualizer.setOptions({...this.virtualizer.options,overscan:e?6:Sk}))}didRenderRows(e){this.renderedRows=e>0}hostUpdated(){this.prepare(this.renderedRows&&!this.presented);let e=this.renderedRows;this.renderedRows=!1;let t=this.host.scrollElement;e&&this.presented&&t&&this.virtualizer.options.overscan===Sk&&this.overscanFrame===null&&(this.overscanFrame=requestAnimationFrame(()=>{this.overscanFrame=null,this.prepare(),this.presented&&t===this.host.scrollElement&&(this.virtualizer.setOptions({...this.virtualizer.options,overscan:6}),this.host.requestUpdate())}))}queueRowMeasure(){if(this.measureFrame!==null)return;let e=this.host.scrollElement;this.measureFrame=requestAnimationFrame(()=>{this.measureFrame=null,e===this.host.scrollElement&&this.measureConnectedRows()})}hostDisconnected(){this.overscanFrame!==null&&(cancelAnimationFrame(this.overscanFrame),this.overscanFrame=null),this.measureFrame!==null&&(cancelAnimationFrame(this.measureFrame),this.measureFrame=null),this.presented=!1,this.renderedRows=!1,this.virtualizer.setOptions({...this.virtualizer.options,overscan:6})}}})))()}function Tk(e){let t=e.offsetState.pendingScrollOffset;if(!t||!e.isConnected())return;if(e.isContentReady()&&e.getRowCount()===0){Dk(e,0);return}let n=WO(e.getScrollElement());if(n===null){t.observedMaxOffset=void 0,t.stableFrames=0,t.zeroMaxFrames=0;return}if(n===0&&t.offset>0){t.observedMaxOffset=void 0,t.stableFrames=0,e.isContentReady()&&(t.zeroMaxFrames>=60?Dk(e,0):Ek(e));return}if(t.zeroMaxFrames=0,n<t.offset&&(t.observedMaxOffset!==n&&(t.observedMaxOffset=n,t.stableFrames=0),t.stableFrames<=12)){Ek(e);return}let r=Math.min(t.offset,n),i=e.getScrollElement();i&&(i.scrollTop=r),e.virtualizer.scrollToOffset(r);let a=e.getScrollElement()?.scrollTop;a==null?Ek(e):Dk(e,a)}function Ek(e){e.isConnected()&&e.getPendingScrollFrame()===null&&e.setPendingScrollFrame(requestAnimationFrame(()=>{e.setPendingScrollFrame(null);let t=e.offsetState.pendingScrollOffset;if(e.isConnected()&&t){let n=WO(e.getScrollElement());n===0&&t.offset>0&&e.isContentReady()?t.zeroMaxFrames+=1:n!==null&&n>0&&n<t.offset&&n===t.observedMaxOffset&&(t.stableFrames+=1),e.requestUpdate()}}))}function Dk(e,t){let n=e.offsetState.pendingScrollOffset;if(e.offsetState.pendingScrollOffset=null,!n)return;let r=WO(e.getScrollElement());n.onSettled?.({scrollTop:t,anchorToEnd:r===null?e.isContentReady()&&e.getRowCount()===0:r-t<=8}),e.onReaderScroll()}function Ok(){return(Ok=e((()=>{Jd(),qO(),wk()})))()}var kk;function Ak(){return(Ak=e((()=>{Ds(),Ns(),K(),Dn(),cf(),DO(),kO(),IO(),YO(),qO(),ZO(),Sf(),tk(),lk(),dk(),yk(),hk(),xk(),Ok(),wk(),kk=class{get scrollElement(){let e=this.threadInnerElement?.parentElement;return this.connected&&e instanceof HTMLDivElement&&e.isConnected?e:null}queueScrollElementAttach(){this.scrollElementAttachQueued||(this.scrollElementAttachQueued=!0,queueMicrotask(()=>{this.scrollElementAttachQueued=!1;let e=this.virtualizerController.getVirtualizer();this.connected&&e.scrollElement!==this.scrollElement&&(this.layout.connect(this.scrollElement),this.virtualizerController.hostUpdated(),this.host.requestUpdate())}))}measureConnectedRows(){return this.offsetState.syncNativeOffset?.(),VO(this.scrollElement,this.virtualizerController.getVirtualizer())}constructor(e,t=null,n,r={}){this.host=e,this.callbacks=r,this.offsetState=nk(),this.entryAnimations=new EO,this.expandedAssistantMessages=new Map,this.controllers=new Set,this.threadInnerElement=null,this.connected=!1,this.observedWidth=null,this.observedHeight=null,this.contentReady=!1,this.headerHeight=0,this.appliedHeaderHeight=0,this.endAnchor=new JO,this.layout=new Tf((e,t)=>this.endAnchor.recordLayoutCorrection(e,t)),this.followEnd=()=>this.scrollToEnd({source:`auto`,behavior:`auto`}),this.pendingScrollFrame=null,this.messageReveal=new OO,this.scrollElementRef=e=>{let t=e instanceof HTMLDivElement?e:null;t!==this.threadInnerElement&&(this.threadInnerElement=t,this.queueScrollElementAttach())},this.scrollElementAttachQueued=!1,this.captureInteractionResize=e=>{let t=QO(e);t&&(this.endAnchor.clear(),this.prependAnchor.clear(),this.offsetState.pendingInteractionAnchor=t,queueMicrotask(()=>this.offsetState.pendingInteractionAnchor===t&&this.host.requestUpdate()))},this.handleGeometryCommit=e=>{if(this.reconcileInteractionResize(e.target),this.positionRail.sync(),e instanceof CustomEvent&&e.detail?.widthChanged===!1)return;let t=this.scrollElement?.getBoundingClientRect();t&&t.width!==0&&t.height!==0&&(this.observedWidth=Math.round(t.width),this.measureConnectedRows())},this.rowKeys=[],this.rowIndexesByKey=new Map,this.messageRowKeysById=new Map,this.prependAnchor=new vk,this.candidateMessageRowKeysById=new Map,this.candidateMessageRowsByKey=new Map,this.renderPreviousRows=null,this.focusedRowKey=null,this.announcement=new FO,this.mcpAppUnmountGate=new Cn(this),this.requestUpdate=()=>this.host.requestUpdate(),this.positionRail=new KO(this,()=>this.threadInnerElement),this.implicitEndAnchorPending=t===null,this.virtualizerController=new Ms(this,{count:0,getScrollElement:()=>this.scrollElement,estimateSize:()=>120,getItemKey:()=>``,initialRect:BO(e),initialOffset:t??2**53-1,anchorTo:`end`,followOnAppend:!1,scrollToFn:(e,t,n)=>sk(this.offsetState,e,t,n),observeElementRect:(e,t)=>js(e,n=>{if(e.scrollElement!==this.scrollElement||!n.width||!n.height)return;this.commitComposerResize(!0);let r=this.observedHeight,i=this.observedWidth!==null&&this.observedWidth!==n.width,a=r!==null&&r!==n.height;this.observedWidth=n.width,this.observedHeight=n.height,this.positionRail.sync(),zO(e.scrollElement,e,this.appliedHeaderHeight),t(n),i&&(this.measureConnectedRows(),this.presentation.queueRowMeasure()),(i||a)&&(this.callbacks.onViewportResize?.(),this.host.requestUpdate())}),observeElementOffset:(e,t)=>ck({state:this.offsetState,getScrollElement:()=>this.scrollElement,prependAnchor:this.prependAnchor,endAnchor:this.endAnchor,canFollowEnd:()=>this.canAutoFollow(),isProgrammaticScroll:()=>this.isProgrammaticScroll,cancelScroll:()=>this.cancelScroll(),requestUpdate:()=>this.host.requestUpdate(),onOffset:()=>this.endAnchor.recordViewport(this.scrollElement),onComposerLayout:e=>this.commitComposerResize(e),onReaderScroll:e=>{this.implicitEndAnchorPending=!1,this.callbacks.onReaderScroll?.(e)}},e,t),measureElement:(e,t,n)=>{let r=UO(e,t,n);return e.dataset.virtualRowKey===`presence:typing`&&n.itemSizeCache.get(`presence:typing`)!==r&&this.endAnchor.clear(),r},rangeExtractor:e=>this.prependAnchor.extractRange(e,this.rowIndexesByKey,this.focusedRowKey),scrollEndThreshold:-1,overscan:6}),this.presentation=new Ck(this,this.virtualizerController.getVirtualizer(),r,()=>this.measureConnectedRows()),this.rowRefs=new bk(this.virtualizerController.getVirtualizer(),{canMeasureVisibleRows:()=>!this.implicitEndAnchorPending&&this.offsetState.scrollCommand?.behavior!==`smooth`&&(this.callbacks.visuallyPresented?.()??!0),isCurrentRow:(e,t)=>this.threadInnerElement?.contains(e)===!0&&this.rowIndexesByKey.has(t),onMount:e=>{this.offsetState.scrollCommand?.target===`message`&&this.messageRowKeysById.get(this.offsetState.scrollCommand.messageId)===e&&queueMicrotask(()=>this.completeMessageReveal())}}),this.scrollRestoreHost={offsetState:this.offsetState,virtualizer:this.virtualizerController.getVirtualizer(),getScrollElement:()=>this.scrollElement,isContentReady:()=>this.contentReady,getRowCount:()=>this.rowKeys.length,isConnected:()=>this.connected,getPendingScrollFrame:()=>this.pendingScrollFrame,setPendingScrollFrame:e=>{this.pendingScrollFrame=e},requestUpdate:this.requestUpdate,onReaderScroll:()=>this.callbacks.onReaderScroll?.()},t!==null&&(this.offsetState.pendingScrollOffset={offset:t,stableFrames:0,zeroMaxFrames:0,onSettled:n})}get updateComplete(){return this.host.updateComplete}get liveAnnouncementText(){return this.announcement.text}addController(e){this.controllers.add(e)}removeController(e){this.controllers.delete(e)}connect(){if(!this.connected){this.connected=!0,this.host instanceof HTMLElement&&this.host.addEventListener(hf,this.handleGeometryCommit);for(let e of this.controllers)e.hostConnected?.();this.offsetState.pendingScrollOffset&&this.host.requestUpdate()}}commitComposerResize(e){this.endAnchor.commitComposerResize(this.scrollElement,e,this.canAutoFollow(),this.offsetState.pendingScrollOffset!==null||this.offsetState.pendingInteractionAnchor!==null||this.offsetState.scrollCommand!==null&&this.offsetState.scrollCommand.target!==`end`||this.offsetState.touchActive)?.resumeFollow&&this.callbacks.onReaderScroll?.(!0)}update(){this.layout.connect(this.scrollElement),this.entryAnimations.didCommit();for(let e of this.controllers)e.hostUpdated?.();let e=this.offsetState.pendingInteractionAnchor!==null;this.reconcileInteractionResize(),!this.offsetState.touchActive&&this.prependAnchor.update(this.scrollElement,this.virtualizerController.getVirtualizer(),()=>this.measureConnectedRows())&&(this.offsetState.syncNativeOffset?.(),this.host.requestUpdate()),Tk(this.scrollRestoreHost),e?this.endAnchor.cancelReconcile():this.connected&&this.endAnchor.scheduleReconcile(()=>{this.connected&&!this.offsetState.pendingInteractionAnchor&&(this.commitComposerResize(!0),this.reconcileImplicitEndAnchor(),this.endAnchor.reconcile(this.scrollElement,this.canAutoFollow(),this.offsetState.pendingScrollOffset!==null||this.offsetState.touchActive,this.followEnd))})}disconnect(){if(this.layout.disconnect(),this.endAnchor.disconnect(),this.entryAnimations.disconnect(),this.expandedAssistantMessages.clear(),this.expandedAssistantMessages=new Map,this.offsetState.scrollCommand=null,this.offsetState.maintenanceScrollOffset=null,this.prependAnchor.clear(),this.offsetState.touching=!1,this.offsetState.touchScrolling=!1,this.renderPreviousRows=null,this.messageReveal.clear(),this.pendingScrollFrame!==null&&(cancelAnimationFrame(this.pendingScrollFrame),this.pendingScrollFrame=null),this.threadInnerElement=null,this.connected){this.connected=!1,this.host instanceof HTMLElement&&this.host.removeEventListener(hf,this.handleGeometryCommit);for(let e of this.controllers)e.hostDisconnected?.()}}dispose(){this.disconnect(),this.rowRefs.clear(),this.rowKeys=[],this.rowIndexesByKey.clear(),this.messageRowKeysById=new Map,this.prependAnchor.reset(),this.focusedRowKey=null,this.offsetState.pendingScrollOffset=null}render(e,t,n,r,i=G,a=null,o=!1){this.presentation.prepare(o||this.focusedRowKey!==null||this.prependAnchor.messageKey!==null||this.offsetState.pendingInteractionAnchor!==null||this.offsetState.scrollCommand!==null),this.offsetState.renderedScrollState=this.offsetState.renderState(this.scrollElement!==null&&this.endAnchor.atEnd);let s=this.virtualizerController.getVirtualizer();return this.prependAnchor.hasPrepend&&(this.offsetState.touchActive||s.isScrolling)&&!this.offsetState.scrollCommand&&!this.offsetState.pendingScrollOffset&&this.renderPreviousRows?this.renderPreviousRows():this.renderCommittedRows({rows:e,renderRow:t,announcement:n,announce:r,overlay:i,header:a,messageRows:this.candidateMessageRowKeysById,renderKeyRows:this.candidateMessageRowsByKey,entryKeys:this.entryAnimations.projectedKeys},!0)}renderCommittedRows(e,t){let{rows:n,renderRow:r,announcement:i,announce:a,overlay:o,header:s,messageRows:c,renderKeyRows:l}=e,u=n.length!==this.rowKeys.length||n.some((e,t)=>e.key!==this.rowKeys[t]),d=u?n.map(e=>e.key):this.rowKeys,f=this.virtualizerController.getVirtualizer(),p=u?d:f.getVirtualItems().flatMap(({index:e})=>n[e]?.key??[]);return this.mcpAppUnmountGate.render(u?d:JSON.stringify(p),()=>(this.presentation.didRenderRows(n.length),this.entryAnimations.sync(e.entryKeys,a&&!this.offsetState.pendingScrollOffset),this.messageRowKeysById=c,this.prependAnchor.committedMessageRows=l,this.renderPreviousRows=()=>this.renderCommittedRows(e,!1),t&&this.prependAnchor.capture(this.scrollElement,!!(this.offsetState.pendingScrollOffset||this.offsetState.scrollCommand||this.offsetState.pendingInteractionAnchor),u&&!this.canAutoFollow()),this.headerHeight=s?.height??0,u?this.syncRows(d):this.appliedHeaderHeight=XO(f,this.scrollElement,this.headerHeight,this.appliedHeaderHeight),this.announcement.sync(i,a),ek({layout:this.layout,headerHeight:this.headerHeight,rows:n,renderRow:r,virtualizer:f,overlay:o,header:s?.template??G,scrollElementRef:this.scrollElementRef,captureInteractionResize:this.captureInteractionResize,measureRowRefFor:e=>this.rowRefs.forKey(e),measureRows:this.prependAnchor.messageKey!==null||this.offsetState.scrollCommand?.target===`message`||this.offsetState.scrollCommand?.target===`index`})),()=>{let e=new Set([...this.threadInnerElement?.querySelectorAll(`mcp-app-view`)??[]].flatMap(e=>e.closest(`.chat-virtual-row`)??[]));if(e.size===0)return[];let t=u?pk(f,d,this.focusedRowKey):new Set(p);return[...e].filter(e=>!t.has(e.dataset.virtualRowKey??``))})}get isMaintenanceScroll(){return this.endAnchor.isResizeAnchor(this.scrollElement)&&this.canAutoFollow()||rk(this.offsetState,this.scrollElement)}get isProgrammaticScroll(){return ik(this.offsetState,this.scrollElement)}get isManualScroll(){return ak(this.offsetState,this.scrollElement)}canAutoFollow(){return this.callbacks.canFollowEnd?.()??!0}scrollToEnd({source:e=`manual`,behavior:t=`auto`}={}){return e===`auto`&&(this.offsetState.pendingScrollOffset||!this.canAutoFollow())?!1:(ok(this.offsetState,this.virtualizerController.getVirtualizer(),{source:e,behavior:t},()=>this.cancelScroll(),()=>this.presentation.queueRowMeasure()),t!==`smooth`&&this.endAnchor.capture(this.scrollElement),!0)}cancelScroll(){if(this.endAnchor.clear(),this.prependAnchor.clear(),this.offsetState.scrollCommand===null&&!this.offsetState.pendingScrollOffset)return;this.offsetState.scrollCommand?.behavior===`smooth`&&this.presentation.queueRowMeasure(),this.offsetState.scrollCommand=null,this.offsetState.pendingScrollOffset=null,this.pendingScrollFrame!==null&&(cancelAnimationFrame(this.pendingScrollFrame),this.pendingScrollFrame=null);let e=this.scrollElement;e&&this.virtualizerController.getVirtualizer().scrollToOffset(e.scrollTop,{behavior:`instant`})}syncMessageRows(e,t){this.candidateMessageRowKeysById=e,this.candidateMessageRowsByKey=t,this.prependAnchor.messageKeys=t}activeMessageId(e){return uk(this.scrollElement,this.virtualizerController.getVirtualizer(),e,this.messageRowKeysById,this.rowIndexesByKey)}revealMessage(e){let t=this.messageRowKeysById.get(e),n=t?this.rowIndexesByKey.get(t):void 0;return n!==void 0&&(this.cancelScroll(),this.offsetState.scrollCommand={behavior:Zi(),target:`message`,messageId:e},this.virtualizerController.getVirtualizer().scrollToIndex(n,{align:`center`}),this.host.requestUpdate(),this.host.updateComplete.then(()=>this.completeMessageReveal()),!0)}completeMessageReveal(){let e=this.offsetState.scrollCommand;if(e?.target!==`message`)return;let t=this.virtualizerController.getVirtualizer();if(this.messageReveal.reveal(this.threadInnerElement,e,t)){this.offsetState.scrollCommand={behavior:e.behavior,target:`index`};return}let n=this.messageRowKeysById.get(e.messageId),r=n?this.rowIndexesByKey.get(n):void 0;r!==void 0&&(t.scrollToIndex(r,{align:`center`}),this.host.requestUpdate())}setContentReady(e){this.contentReady=e}restoreScrollOffset(e,t){this.cancelScroll(),this.implicitEndAnchorPending=!1,this.offsetState.pendingScrollOffset={offset:e,stableFrames:0,zeroMaxFrames:0,onSettled:t},this.connected&&this.host.requestUpdate()}handleFocusIn(e){this.focusedRowKey=mk(this.scrollElement,e.target)}handleFocusOut(e){this.focusedRowKey=mk(this.scrollElement,e.relatedTarget)}reconcileInteractionResize(e){let t=this.virtualizerController.getVirtualizer();$O(this.offsetState.pendingInteractionAnchor,e,this.scrollElement,t)&&(this.offsetState.pendingInteractionAnchor=null)}syncRows(e){let t=this.virtualizerController.getVirtualizer();!this.rowIndexesByKey.has(`presence:typing`)&&e.includes(`presence:typing`)&&this.endAnchor.clear(),this.rowKeys=Object.freeze(e);let n=new Map(this.rowKeys.map((e,t)=>[e,t]));this.rowIndexesByKey=n,this.rowRefs.retainKeys(n),this.appliedHeaderHeight=this.headerHeight,t.setOptions({...t.options,count:e.length,getItemKey:t=>e[t]??`missing:${t}`,followOnAppend:!1,rangeExtractor:e=>this.prependAnchor.extractRange(e,n,this.focusedRowKey),scrollMargin:RO(this.scrollElement,this.headerHeight)})}reconcileImplicitEndAnchor(){if(!this.implicitEndAnchorPending||!this.connected||!this.contentReady)return;let e=GO(this.scrollElement,this.virtualizerController.getVirtualizer());this.implicitEndAnchorPending=e===`pending`,e!==`pending`&&this.canAutoFollow()&&this.endAnchor.capture(this.scrollElement),e===`corrected`&&this.host.requestUpdate()}}})))()}var jk;function Mk(){return(Mk=e((()=>{it(),Jd(),Ak(),jk=class{constructor(e,t,n={}){this.host=e,this.scrollPaneId=t,this.callbacks=n,this.activeSessionKey=null,this.sessionVirtualizer=null,this.connected=!1,e.addController(this)}get renderedSessionKey(){return this.activeSessionKey}renderSession(e,t){if(!this.sessionVirtualizer||this.activeSessionKey===null||!je(this.activeSessionKey,e)){this.sessionVirtualizer?.dispose();let t=this.scrollPaneId(),n=Hd(t,e),r=n?.anchorToEnd?null:n?.scrollTop??null;this.activeSessionKey=e,this.sessionVirtualizer=new kk(this.host,r,n=>Gd(t,e,n),this.callbacks),this.connected&&this.sessionVirtualizer.connect()}return t(this.sessionVirtualizer)}get isMaintenanceScroll(){return this.sessionVirtualizer?.isMaintenanceScroll??!1}get isProgrammaticScroll(){return this.sessionVirtualizer?.isProgrammaticScroll??!1}get isManualScroll(){return this.sessionVirtualizer?.isManualScroll??!1}scrollToEnd(e={}){return this.sessionVirtualizer?.scrollToEnd(e)??!1}scrollToOffset(e,t){this.sessionVirtualizer?.restoreScrollOffset(e,t)}revealMessage(e){return this.sessionVirtualizer?.revealMessage(e)??!1}cancelScroll(){this.sessionVirtualizer?.cancelScroll()}get scrollElement(){return this.sessionVirtualizer?.scrollElement??null}hostConnected(){this.connected=!0,this.sessionVirtualizer?.connect()}hostUpdated(){this.sessionVirtualizer?.update()}hostDisconnected(){this.connected=!1,this.sessionVirtualizer?.disconnect()}}})))()}function Nk(e){return[`Selected text:\n${e.text}`,...e.comment.trim()?[`User comment:\n${e.comment}`]:[],[`Source session: ${e.sessionKey}`,...e.messageId?[`Source message: ${e.messageId}`]:[],...e.entryId?[`Source entry: ${e.entryId}`]:[],`Selected text UTF-16 length: ${e.text.length}`,`DOM text UTF-16 range: [${e.start}, ${e.end})`].join(`
`)].join(`

`)}function Pk(e,t,n){let r={id:Bu(),mimeType:`text/plain`,fileName:`selection-comment.txt`,selectionAnnotation:{...e}};if(t.selectionContextOnly)return r;let i=Nk(e),a=new File([i],r.fileName,{type:r.mimeType});return wS([a],t.attachmentLimits,n).length===0?null:uu({attachment:{...r,sizeBytes:a.size},dataUrl:Qw(i),file:a})}function Fk(){return(Fk=e((()=>{cu(),jS(),$w()})))()}function Ik(e){return e===`draft`?z.pencil:e===`shared`?z.users:z.lock}function Lk(){return H`
    <div
      class="chat-pane__sharing-members-loading"
      role="status"
      aria-busy="true"
      aria-label=${L(`common.loading`)}
    >
      ${Array.from({length:3},()=>H`
          <div class="chat-pane__sharing-member-skeleton" aria-hidden="true">
            <span class="skeleton chat-pane__sharing-member-skeleton-icon"></span>
            <span class="skeleton chat-pane__sharing-member-skeleton-label"></span>
          </div>
        `)}
    </div>
  `}function Rk(e,t){if(t?.startsWith(`public:`)){if(!e.session||!zk(e.session)||e.state?.loading||!e.state?.result)return;t===`public:copy`&&e.state.result.publicShare?e.onCopyPublicLink?.():e.publicShareDisabledReason||(t===`public:enable`?e.onPublicShareChange?.(!0):t===`public:disable`&&e.onPublicShareChange?.(!1));return}let n=new Set(e.state?.result?.members.map(e=>e.identityId)??[]);if(t?.startsWith(`visibility:`)){let n=t.slice(11);!e.visibilityDisabledReason&&n!==(e.session?.visibility??`shared`)&&e.onVisibilityChange(n);return}if(!t?.startsWith(`member:`))return;let r=t.slice(7),i=!n.has(r);(i?e.memberAddDisabledReason:e.memberRemoveDisabledReason)||e.onMemberChange(r,i)}function zk(e){return e.sharingRole===`admin`||e.sharingRole===`owner`}function Bk(e){if(!e.state?.result?.publicShare)return G;let t=L(`chat.sessionSharing.worldReadable`);return H`<span
    class="chat-pane__public-share-indicator"
    role="status"
    aria-label=${t}
    title=${t}
  >
    <span aria-hidden="true">${z.globe}</span>
    <span>${L(`chat.sessionSharing.publicIndicator`)}</span>
  </span>`}function Vk(e,t=!1){let n=e.session;if(!n)return G;let r=n.visibility??`shared`,i=zk(n),a=e.state?.result,o=a?.publicShare,s=a?.owner??n.owner?.actor,c=El(s?.identity?.type===`profile`?s.identity.id:void 0,e.personActivity,s?.label);if(!i)return r===`draft`?H`${e.showOwner&&s?Ul(Sl(s,`header`,`owned`,e.ownerViewing),c):G}<span class="chat-pane__draft-indicator" title=${L(`chat.sessionSharing.draft`)}
            >${Ik(`draft`)}</span
          >`:G;let l=new Set(a?.members.map(e=>e.identityId)??[]),u=a?.identities.filter(e=>e.id!==a.owner?.id)??[],d=a?.allowedVisibilities??e.allowedVisibilities??[r],f=r===`draft`&&d.includes(`shared`),p=e.membersAvailable!==!1,m=d.filter(e=>!f||e!==`shared`),h=p&&m.length+u.length+ +!!f+ +!!s>12,g=H`
    ${f?H`<wa-dropdown-item
              value="visibility:shared"
              class="session-menu__item chat-pane__publish-draft"
              ?disabled=${!!e.visibilityDisabledReason}
              title=${e.visibilityDisabledReason??G}
            >
              <span class="session-menu__text">${L(`chat.sessionSharing.publishDraft`)}</span>
              <span slot="details" aria-hidden="true">${z.users}</span>
            </wa-dropdown-item>
            <div class="session-menu__separator" role="separator"></div>`:G}
    <div class="chat-pane__sharing-title chat-pane__sharing-visibility-title">
      ${L(`chat.sessionSharing.visibility`)}
    </div>
    ${m.map(t=>{let n=t===r;return H`
        <wa-dropdown-item
          class="session-menu__item chat-pane__sharing-visibility-item"
          value=${`visibility:${t}`}
          role="menuitemradio"
          aria-checked=${String(n)}
          ${U(e=>Fc(e,n))}
          ?disabled=${!!e.visibilityDisabledReason}
          title=${e.visibilityDisabledReason??G}
        >
          <span slot="icon" class="session-menu__icon" aria-hidden="true"
            >${Ik(t)}</span
          >
          <span class="session-menu__text">${L(Hk[t])}</span>
          ${n?H`<span slot="details" class="session-menu__check" aria-hidden="true"
                  >${z.check}</span
                >`:G}
        </wa-dropdown-item>
      `})}
    ${e.onPublicShareChange?H`
            <div class="session-menu__separator" role="separator"></div>
            <div class="chat-pane__sharing-title">${L(`chat.sessionSharing.publicAccess`)}</div>
            <div class="chat-pane__sharing-status">
              ${L(e.state?.loading||!a?`common.loading`:o?`chat.sessionSharing.worldReadable`:`chat.sessionSharing.notPublic`)}
            </div>
            ${o?H`<wa-dropdown-item
                    class="session-menu__item"
                    value="public:copy"
                    ?disabled=${!!e.state?.loading}
                    >${L(`chat.sessionSharing.copyPublicLink`)}</wa-dropdown-item
                  >`:G}
            <wa-dropdown-item
              class="session-menu__item"
              value=${o?`public:disable`:`public:enable`}
              ?disabled=${!!(e.publicShareDisabledReason||e.state?.loading||!a)}
              title=${e.publicShareDisabledReason??G}
            >
              ${L(o?`chat.sessionSharing.disablePublicAccess`:`chat.sessionSharing.enablePublicAccess`)}
            </wa-dropdown-item>
          `:G}
    ${s?H`
            <div class="chat-pane__sharing-title chat-pane__sharing-owner-title">
              ${L(`chat.sessionSharing.owner`)}
            </div>
            <div class="chat-pane__sharing-owner">
              <span class="chat-pane__sharing-member-icon" aria-hidden="true">
                ${s.type===`human`?Yc(Sl(s,`header`,`owned`,e.ownerViewing),c):z.bot}
              </span>
              ${gl(s.label??s.id??L(`chat.sessionSharing.owner`),c,`session-menu__text`)}
            </div>
          `:G}
    ${p?H`
            <div class="chat-pane__sharing-title chat-pane__sharing-members-title">
              ${L(`chat.sessionSharing.members`)}
            </div>
            ${e.state?.loading?Lk():u.length>0?ec(u.map(t=>({text:[t.label,t.id,t.type].join(` `),render:()=>{let n=l.has(t.id)?e.memberRemoveDisabledReason:e.memberAddDisabledReason;return H`
                            <wa-dropdown-item
                              class="session-menu__item chat-pane__sharing-member"
                              value=${`member:${t.id}`}
                              ?disabled=${!!n}
                              title=${n??G}
                            >
                              <span
                                slot="icon"
                                class="chat-pane__sharing-member-icon"
                                aria-hidden="true"
                              >
                                ${t.type===`human`?Sl(t,`header`):z.bot}
                              </span>
                              <span
                                class="session-menu__text chat-pane__sharing-member-label"
                                title=${n?G:t.label??t.id}
                                >${t.label??t.id}</span
                              >
                              ${l.has(t.id)?H`<span
                                      slot="details"
                                      class="session-menu__check"
                                      aria-label=${L(`chat.sessionSharing.selected`)}
                                      >${z.check}</span
                                    >`:G}
                            </wa-dropdown-item>
                          `}})),a):H`<div class="chat-pane__sharing-status">
                      ${L(`chat.sessionSharing.noPeople`)}
                    </div>`}
          `:G}
    ${e.state?.error?H`<div class="chat-pane__sharing-status chat-pane__sharing-status--error" role="alert">
            ${e.state.error}
          </div>`:G}
  `;return t?g:H`
    ${Bk(e)}
    <wa-dropdown
      class="chat-pane__sharing-menu ${h?`chat-pane__sharing-menu--capped`:``}"
      placement="bottom-end"
      @keydown=${Ec}
      @wa-show=${()=>{e.openDisabledReason||e.onOpen()}}
      @wa-select=${t=>{Rk(e,t.detail.item.value)}}
    >
      <button
        slot="trigger"
        class="btn btn--ghost btn--icon chat-icon-btn chat-pane__sharing-trigger"
        type="button"
        aria-label=${L(`chat.sessionSharing.menu`)}
        ?disabled=${!!e.openDisabledReason}
        title=${e.openDisabledReason??L(`chat.sessionSharing.current`,{visibility:L(Hk[r])})}
      >
        ${Ik(r)}
      </button>
      ${g}
    </wa-dropdown>
  `}var Hk;function Uk(){return(Uk=e((()=>{K(),W(),B(),Hc(),nc(),el(),Lc(),R(),Hk={shared:`chat.sessionSharing.shared`,"read-only":`chat.sessionSharing.readOnly`,suggest:`chat.sessionSharing.suggest`,draft:`chat.sessionSharing.draft`}})))()}function Wk(e){if(e.status===`in_progress`)return`running`;switch(e.conclusion){case`success`:return`passed`;case`failure`:case`timed_out`:case`action_required`:case`startup_failure`:return`failed`;case`skipped`:case`neutral`:case`cancelled`:return`skipped`;default:return`queued`}}function Gk(e){let[t,n]=Xk[e],r=L(t);return H`<span
    class="chat-ci__status"
    data-state=${e}
    role="img"
    aria-label=${r}
    title=${r}
    >${n}</span
  >`}function Kk(e,t){let n=e.startedAt?Date.parse(e.startedAt):NaN,r=e.completedAt?Date.parse(e.completedAt):t?Date.now():NaN;return Number.isFinite(n)&&Number.isFinite(r)&&r>=n?si(r-n)??``:``}var qk,Jk,Yk,Xk,Zk;function Qk(){return(Qk=e((()=>{K(),ar(),ur(),Yt(),B(),R(),wi(),ta(),ft(),Pe(),tt(),ao(),qk=3e4,Jk=Ot(fr`<circle cx="12" cy="12" r="10" /><path d="M8 12h8" />`),Yk={failed:0,running:1,passed:2,skipped:3},Xk={passed:[`chat.pullRequests.checksPassed`,z.check],failed:[`chat.pullRequests.checksFailed`,z.circleX],running:[`chat.pullRequests.checksRunning`,z.loader],skipped:[`chat.pullRequests.checksSkipped`,Jk],queued:[`chat.pullRequests.checksQueued`,z.clock]},Zk=class extends gt{constructor(...e){super(...e),this.sessionKey=``,this.presented=!0,this.loading=!1,this.error=null,this.disclosure=null,this.connection=ut({client:null,phase:`stopped`}),this.target=``,this.requestGeneration=0,this.retryAt=0,this.expandedJobs=new Map,this.expansionInitialized=!1,this.handleToggle=e=>{e.target===this.disclosure&&this.handleVisibility()},this.handleVisibility=()=>{this.visible?this.load():this.cancelRequest()}}connectedCallback(){super.connectedCallback(),this.disclosure=this.closest(`.chat-pr__checks`),this.disclosure?.addEventListener(`toggle`,this.handleToggle),this.ownerDocument.addEventListener(`visibilitychange`,this.handleVisibility),this.requestUpdate()}disconnectedCallback(){this.disclosure?.removeEventListener(`toggle`,this.handleToggle),this.ownerDocument.removeEventListener(`visibilitychange`,this.handleVisibility),this.stopGateway?.(),this.stopGateway=void 0,this.boundGateway=void 0,this.connection.transition({client:null,phase:`stopped`}),this.reset(),super.disconnectedCallback()}targetKey(){let e=this.pullRequest;return JSON.stringify([this.sessionKey,e?.owner,e?.repo,e?.number,e?.headSha])}get visible(){return this.isConnected&&this.presented&&this.disclosure?.open===!0&&this.ownerDocument.visibilityState!==`hidden`}willUpdate(e){let t=this.targetKey();t!==this.target&&(e.has(`sessionKey`)&&e.get(`sessionKey`)&&this.disclosure&&(this.disclosure.open=!1),this.target=t,this.reset()),this.boundGateway!==this.gateway&&(this.stopGateway?.(),this.boundGateway=this.gateway,this.connection.transition(this.gateway?.snapshot??{client:null,phase:`stopped`}),this.reset(),this.stopGateway=this.gateway?.subscribe(e=>{this.connection.transition(e)&&(this.reset(),this.load())})),this.visible||this.cancelRequest()}updated(e){(e.has(`pullRequest`)||e.has(`gateway`)||e.has(`sessionKey`)||e.has(`presented`))&&this.visible&&!this.loading&&(e.has(`presented`)||!this.result&&!this.error)&&this.load()}cancelRequest(){this.requestGeneration+=1,this.requestController?.abort(),this.requestController=void 0,clearTimeout(this.refreshTimer),this.refreshTimer=void 0,this.loading=!1}reset(){this.cancelRequest(),this.result=void 0,this.error=null,this.retryAt=0,this.expandedJobs.clear(),this.expansionInitialized=!1}async load(){if(!this.visible||this.loading)return;if(Date.now()<this.retryAt){this.scheduleRetryAvailability();return}let e=this.pullRequest,t=this.gateway,n=this.connection.capture();if(!n||!t||!e?.headSha||!this.sessionKey){this.error=L(`chat.pullRequests.checksUnavailable`);return}clearTimeout(this.refreshTimer);let r=++this.requestGeneration,i=this.targetKey(),a=n.client.connectionGeneration,o=t.connectionRevision,s=new AbortController;this.requestController=s,this.loading=!0,this.error=null;let c=()=>this.visible&&r===this.requestGeneration&&i===this.targetKey()&&t===this.gateway&&t.connectionRevision===o&&t.snapshot.client===n.client&&t.snapshot.phase===`connected`&&this.connection.isCurrent(n)&&n.client.connectionGeneration===a;try{let t=await n.client.request(`controlUi.sessionPullRequests.checks`,{sessionKey:this.sessionKey,owner:e.owner,repo:e.repo,number:e.number,headSha:e.headSha},{signal:s.signal});if(!c())return;if(t.owner.toLowerCase()!==e.owner.toLowerCase()||t.repo.toLowerCase()!==e.repo.toLowerCase()||t.number!==e.number||t.headSha!==e.headSha){this.result=void 0,this.error=L(`chat.pullRequests.checksUnavailable`);return}if(this.result=t,this.retryAt=Date.now()+Math.max(0,t.retryAfterMs??(t.rateLimited?6e4:0)),!this.expansionInitialized&&t.checks.length>0){this.expansionInitialized=!0;let e=t.checks.toSorted((e,t)=>Yk[e.state]-Yk[t.state]).find(e=>e.state===`failed`||e.state===`running`);e&&this.expandedJobs.set(e.id,!0)}let r=new Set(t.checks.map(e=>e.id));for(let e of this.expandedJobs.keys())r.has(e)||this.expandedJobs.delete(e);this.retryAt>Date.now()?this.scheduleRetryAvailability():t.status===`ready`&&(this.refreshTimer=setTimeout(()=>void this.load(),qk))}catch(e){c()&&(this.result=void 0,this.error=N(e,L(`chat.pullRequests.checksUnavailable`)))}finally{c()&&(this.loading=!1,this.requestController=void 0)}}scheduleRetryAvailability(){clearTimeout(this.refreshTimer),this.refreshTimer=setTimeout(()=>this.requestUpdate(),Math.min(2147483647,Math.max(0,this.retryAt-Date.now())))}renderNotice(){let e=this.result,t=e?.rateLimited,n=e?.status===`stale`,r=this.error||e?.status===`unavailable`,i=!!e?.error;if(this.loading&&!e)return H`<div class="chat-ci__notice" role="status">
        ${L(`chat.pullRequests.checksLoading`)}
      </div>`;if(!t&&!n&&!r&&!i)return G;let a=Math.max(0,this.retryAt-Date.now());return H`<div
      class="chat-ci__notice"
      role="status"
      data-state=${t?`rate-limited`:`unavailable`}
    >
      <span
        >${this.error??L(t?`chat.pullRequests.checksRateLimited`:n?`chat.pullRequests.checksStale`:`chat.pullRequests.checksUnavailable`)}
        ${a>0?L(`chat.pullRequests.checksRetryAfter`,{duration:si(a)??``}):G}
      </span>
      <button
        class="chat-ci__retry"
        type="button"
        ?disabled=${this.loading||a>0}
        @click=${()=>void this.load()}
      >
        ${L(`common.retry`)}
      </button>
    </div>`}renderJob(e){let t=e.detailsUrl?Be(e.detailsUrl,this.ownerDocument.baseURI):null,n=e.state===`running`&&e.status!==`in_progress`?`queued`:e.state;return H`<details
      class="chat-ci__job"
      data-state=${e.state}
      data-check-id=${e.id}
      .open=${this.expandedJobs.get(e.id)??!1}
      @toggle=${t=>{t.target instanceof HTMLDetailsElement&&t.target===t.currentTarget&&(this.expandedJobs.set(e.id,t.target.open),this.requestUpdate())}}
    >
      <summary class="chat-ci__job-summary">
        ${Gk(n)}
        <span class="chat-ci__name">${e.name}</span>
        <span class="chat-ci__duration">${Kk(e,n===`running`)}</span>
        <span class="chat-ci__chevron" aria-hidden="true">${z.chevronDown}</span>
      </summary>
      <div class="chat-ci__job-detail">
        ${e.steps?.length?H`<ol class="chat-ci__steps" role="list">
                ${q(e.steps.toSorted((e,t)=>e.number-t.number),e=>e.number,e=>{let t=Wk(e);return H`<li class="chat-ci__step" data-state=${t} value=${e.number}>
                      ${Gk(t)}<span class="chat-ci__name">${e.name}</span>
                      <span class="chat-ci__duration">${Kk(e,t===`running`)}</span>
                    </li>`})}
              </ol>`:H`<div class="chat-ci__empty-steps">
                ${e.source===`check`?L(`chat.pullRequests.checksNoSteps`):L(`chat.pullRequests.checksStepsUnavailable`)}
              </div>`}
        ${t?H`<a
                class="chat-ci__job-link"
                href=${t}
                target="_blank"
                rel="noopener noreferrer"
                >${e.source===`actions`?L(`chat.pullRequests.openJob`):L(`chat.pullRequests.openCheck`)}${z.externalLink}</a
              >`:G}
      </div>
    </details>`}render(){let e=this.result?.checks??[],t=e.filter(e=>e.state!==`skipped`).toSorted((e,t)=>Yk[e.state]-Yk[t.state]),n=e.filter(e=>e.state===`skipped`);return H`${this.renderNotice()}
      <div class="chat-ci__jobs" aria-busy=${this.loading?`true`:`false`}>
        ${q(t,e=>e.id,e=>this.renderJob(e))}
        ${n.length?H`<details class="chat-ci__skipped">
                <summary>
                  ${Gk(`skipped`)}<span
                    >${L(`chat.pullRequests.checksSkippedCount`,{count:String(n.length)})}</span
                  >
                  <span class="chat-ci__chevron" aria-hidden="true">${z.chevronDown}</span>
                </summary>
                ${q(n,e=>e.id,e=>this.renderJob(e))}
              </details>`:G}
        ${this.result?.status===`ready`&&!e.length&&!this.result.rateLimited&&!this.result.error?H`<div class="chat-ci__notice">${L(`chat.pullRequests.checksEmpty`)}</div>`:G}
      </div>`}},k([X({attribute:!1})],Zk.prototype,`pullRequest`,void 0),k([X({attribute:!1})],Zk.prototype,`gateway`,void 0),k([X({attribute:!1})],Zk.prototype,`sessionKey`,void 0),k([X({type:Boolean})],Zk.prototype,`presented`,void 0),k([J()],Zk.prototype,`loading`,void 0),k([J()],Zk.prototype,`result`,void 0),k([J()],Zk.prototype,`error`,void 0),customElements.get(`openclaw-chat-ci-details`)||customElements.define(`openclaw-chat-ci-details`,Zk)})))()}function $k(e){return L(e===`personal`?`githubPublication.personal`:e===`agent-override`?`githubPublication.agent`:`githubPublication.system`)}function eA(e){return e.result?.status===`published`?H`<a
        class="chat-pr__create"
        href=${e.result.url}
        target="_blank"
        rel="noopener noreferrer"
      >
        ${L(`chat.pullRequests.openPublishedPr`)}
      </a>
      ${e.onNewAction?H`<button
              class="chat-pr__dismiss"
              type="button"
              aria-label=${L(`common.dismiss`)}
              ?disabled=${e.activity!==null}
              @click=${e.onNewAction}
            >
              ${z.x}
            </button>`:G}`:e.result||e.locked?rA(e):H`
    ${rA(e)}
    <button
      class="btn btn--ghost btn--icon chat-icon-btn"
      type="button"
      aria-label=${L(`githubPublication.account`)}
      aria-haspopup="dialog"
      aria-expanded="false"
    >
      ${z.chevronDown}
    </button>
    <wa-popover
      ${U(tA)}
      style="--max-width: min(320px, calc(100vw - 16px))"
      placement="top-end"
      @wa-show=${nA}
      @wa-hide=${nA}
    >
      ${aA(e)}
    </wa-popover>
  `}function tA(e){let t=e?.previousElementSibling;e instanceof Ps&&t instanceof HTMLButtonElement&&(t.id||=`github-publisher-${p()}`,e.id||=`${t.id}-popover`,e.for=t.id,t.setAttribute(`aria-controls`,e.id),dl(e))}function nA(e){let t=e.currentTarget;t instanceof Ps&&t.anchor?.setAttribute(`aria-expanded`,String(t.open))}function rA(e){let{result:t,selection:n,activity:r}=e,i=r!==null,a=L(r===`read`?`common.loading`:`chat.pullRequests.publishing`),o;return o=t?.status===`failed`?{click:e.onNewAction,label:L(e.canWrite?`githubPublication.newAction`:`common.dismiss`),disabled:i}:t?.status===`needs_confirmation`?{click:e.onConfirm,label:L(`githubPublication.confirm`),disabled:i||!e.personalReady}:t?.status===`publishing`||t?.status===`requested`?{click:e.onRefresh,label:i?a:L(`githubPublication.check`),disabled:i}:{click:e.onPublish,disabled:i||!n||n.source===`personal`&&!e.personalReady,label:i?a:e.locked?L(`chat.pullRequests.retryPublication`):L(`chat.pullRequests.publishPr`)},o.click||t?.status===`publishing`||t?.status===`requested`?H`<button
        class="chat-pr__create"
        type="button"
        ?disabled=${o.disabled}
        @click=${o.click}
      >
        ${o.label}
      </button>`:G}function iA(e){let{selection:t,result:n}=e,r=n?n.publisher:Rr(t);return r?H`<span data-publication-account>
        ${L(`githubPublication.publishAs`,{account:r.login})} ·
        ${$k(r.source)}
      </span>`:G}function aA(e){let{options:t,selection:n,result:r,activity:i,locked:a}=e,o=i!==null,s=t?.personal,c=s?.state===`connected`&&s.generation?s.account:null,l=e.onSelect&&t&&(!n||t.shared&&c);return H`<div class="stack muted">
    ${iA(e)}
    ${l?H`<label>
            <span class="sr-only">${L(`githubPublication.account`)}</span>
            <select
              class="settings-select"
              aria-label=${L(`githubPublication.account`)}
              .value=${n?.source??``}
              ?disabled=${o||a}
              @change=${t=>{if(!(t.currentTarget instanceof HTMLSelectElement))return;let n=t.currentTarget.value;(n===`shared`||n===`personal`)&&e.onSelect?.(n)}}
            >
              ${n?G:H`<option value="" disabled>${L(`githubPublication.choose`)}</option>`}
              ${t.shared?H`<option value="shared">
                      ${$k(t.shared.source)} · @${t.shared.login}
                    </option>`:G}
              ${c?H`<option value="personal">
                      ${L(`githubPublication.personal`)} · @${c.login}
                    </option>`:G}
            </select>
          </label>`:G}
    ${e.personalReady?G:H`<span>${L(`githubPublication.personalWorkspace`)}</span>`}
    ${!r&&t?H`<span>${L(`githubPublication.scopeHelp`)}</span> ${c?G:H`<span
                    >${L(s===null?`githubPublication.unidentified`:`githubPublication.connectHelp`)}</span
                  >`}`:G}
    ${!t&&!o?oA(e):G}
  </div>`}function oA(e){return H`<button class="btn btn--sm" type="button" @click=${e.onRefresh}>
    ${L(`githubPublication.refresh`)}
  </button>`}function sA(e){let{selection:t,result:n,confirmation:r,activity:i,locked:a,error:o}=e;if(n?.status===`published`&&!o)return G;let s=i!==null,c=t?.source===`personal`&&!e.personalReady;return!n&&!r&&!o&&!a&&!c?G:H`<div class="chat-pr__publication-outcome" data-state=${n?.status??`selection`}>
    ${iA(e)}
    ${n&&n.status!==`published`?H`<span role="status">${n.message}</span>`:G}
    ${n?.status===`failed`?H`<span>${n.nextAction}</span>`:G}
    ${o?H`<span role="alert">${o}</span>`:G}
    ${a&&!n&&!s?H`<span>${L(`githubPublication.unknown`)}</span>`:G}
    ${r?H`<div>
            <div>
              ${L(`githubPublication.target`,{repository:r.repository,base:r.baseBranch})}
            </div>
            <div>
              ${L(`githubPublication.pushTarget`,{repository:r.pushRepository,branch:r.branch})}
            </div>
            <details>
              <summary>${L(`githubPublication.snapshot`)}</summary>
              <div>
                ${L(`githubPublication.head`)}: <code>${r.sourceHeadCommit}</code>
              </div>
              <div>
                ${L(`githubPublication.index`)}: <code>${r.sourceIndexTree}</code>
              </div>
              <div>
                ${L(`githubPublication.workspace`)}: <code>${r.workspaceTree}</code>
              </div>
            </details>
          </div>`:G}
    ${n?.effect?H`<span
            >${L(n.effect.status===`dispatched`?`githubPublication.dispatched`:`githubPublication.observed`,{kind:L(n.effect.kind===`push`?`githubPublication.effectPush`:`githubPublication.effectPullRequest`)})}
            ${n.effect.headCommit?H`<code>${n.effect.headCommit}</code>`:G}
            ${n.effect.url?H`<a href=${n.effect.url} target="_blank" rel="noopener noreferrer"
                    >${L(`githubPublication.effectLink`)}</a
                  >`:G}
          </span>`:G}
    ${c?H`<span>${L(`githubPublication.personalWorkspace`)}</span>`:G}
    ${!s&&(o||n&&!e.onConfirm&&n.status!==`published`)?oA(e):G}
  </div>`}function cA(){return(cA=e((()=>{Rs(),K(),W(),B(),Ll(),R(),xs(),r()})))()}function lA(e){return`${e.owner}/${e.repo}#${e.number}`.toLowerCase()}function uA(e){try{let t=JSON.parse(e.getItem(bA)??`{}`);if(!s(t))return{};let n={};for(let[e,r]of Object.entries(t))Array.isArray(r)&&(n[e]=r.filter(e=>typeof e==`string`));return n}catch{return{}}}function dA(e){let t=P();return!t||!e?new Set:new Set(uA(t)[e]??[])}function fA(e,t){let n=P();if(!n||!e)return new Set([lA(t)]);let r=uA(n),i=new Set(r[e]??[]);i.add(lA(t)),delete r[e],r[e]=[...i];let a=Object.keys(r).slice(0,-20);for(let e of a)delete r[e];try{n.setItem(bA,JSON.stringify(r))}catch{}return i}function pA(e,t,n){return t===0?G:H`
    <div class="chat-pr__checks-row chat-pr__checks-row--${n}">
      <span class="chat-pr__checks-row-dot" aria-hidden="true"></span>
      <span class="chat-pr__checks-row-label">${e}</span>
      <span class="chat-pr__checks-row-count">${t}</span>
    </div>
  `}function mA(e,t){let n=e.checks;if(!n)return G;let r=L(SA[n.state]),i=e=>{if(!(e instanceof HTMLDetailsElement))return;tl(e,`top`,{alignment:`end`});let n=e.querySelector(`:scope > wa-popup[data-anchored-overlay]`);n&&t.presented===!1&&(n.active=!1)};return H`
    <details
      class="chat-pr__checks"
      data-checks=${n.state}
      ${U(i)}
      @toggle=${e=>i(e.currentTarget)}
    >
      <summary class="chat-pr__checks-pill" aria-label=${r} title=${r}>
        <span class="chat-pr__checks-dot" aria-hidden="true"></span>
        ${L(`chat.pullRequests.checks`)}
        <span class="chat-pr__checks-chevron" aria-hidden="true">${z.chevronDown}</span>
      </summary>
      <wa-popup data-anchored-overlay>
        <div
          class="chat-pr__checks-menu"
          role="group"
          aria-label=${L(`chat.pullRequests.ciMonitoring`)}
        >
          <div class="chat-pr__checks-menu-header">
            <span>${L(`chat.pullRequests.ciMonitoring`)}</span>
            <a
              href=${e.checksUrl??e.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label=${L(`chat.pullRequests.openChecks`)}
            >
              ${z.externalLink}
            </a>
          </div>
          <div class="chat-pr__checks-counts">
            ${pA(L(`chat.pullRequests.checksPassed`),n.passed,`passed`)}
            ${pA(L(`chat.pullRequests.checksFailed`),n.failed,`failed`)}
            ${pA(L(`chat.pullRequests.checksRunning`),n.running,`running`)}
            ${pA(L(`chat.pullRequests.checksSkipped`),n.skipped,`skipped`)}
          </div>
          <openclaw-chat-ci-details
            .pullRequest=${e}
            .gateway=${t.gateway}
            .sessionKey=${t.sessionKey??``}
            .presented=${t.presented??!0}
          ></openclaw-chat-ci-details>
        </div>
      </wa-popup>
    </details>
  `}function hA(e,t){if(typeof e.additions!=`number`&&typeof e.deletions!=`number`)return G;let n=H`<span class="chat-pr__additions"
    >+${(e.additions??0).toLocaleString()}</span
  >`,r=H`<span class="chat-pr__deletions"
    >−${(e.deletions??0).toLocaleString()}</span
  >`;return t?H`
      <button
        class="chat-pr__diff"
        type="button"
        aria-label=${L(`chat.sessionDiff.show`)}
        @click=${t}
      >
        ${n} ${r}
      </button>
    `:H` <span class="chat-pr__diff">${n} ${r}</span> `}function gA(e){if(e===`ready`)return G;let t=L(e===`rate-limited`?`chat.pullRequests.rateLimited`:`chat.pullRequests.unavailable`);return H`
    <openclaw-tooltip content=${t}>
      <span class="chat-pr__warning" role="img" aria-label=${t}>
        ${z.alertTriangle}
      </span>
    </openclaw-tooltip>
  `}function _A(e){return e.createUrl?H`
        <a
          class="chat-pr__create"
          href=${e.createUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label=${L(`chat.pullRequests.createPrLabel`,{branch:e.branch})}
        >
          ${L(`chat.pullRequests.createPr`)}
        </a>
      `:G}function vA(e,t,n,r){let i=!e&&r?.result?.status===`published`?r.result:void 0;return H`
    <article
      class="chat-pr"
      data-state=${i?`published`:e?`branch`:`publication`}
    >
      <span class="chat-pr__link chat-pr__link--static">
        <span class="chat-pr__icon" aria-hidden="true"
          >${i||!e?z.gitPullRequest:z.gitBranch}</span
        >
        <span class="chat-pr__identity">
          <span class="chat-pr__repo"
            >${i?.repository??e?.repo??L(`chat.pullRequests.publishPr`)}</span
          >
          <span class="chat-pr__branch">${i?.branch??e?.branch}</span>
        </span>
      </span>
      <span class="chat-pr__meta">
        ${e&&!i?hA(e,n):G}
        ${gA(t)}
        ${r?eA(r):e?_A(e):G}
      </span>
      ${r?sA(r):G}
    </article>
  `}function yA(e){let{publication:t}=e,n=t?.result?.status===`published`?t.result:void 0,r=t?.result||t?.locked||t?.error;if(e.branch||e.pullRequests.length===0&&r)return H`<div class="chat-prs" aria-live="polite">
      ${vA(e.branch,e.status,e.onOpenSessionDiff,t)}
    </div>`;if(e.pullRequests.length===0)return G;let i=r&&(!n||t?.error)?t:void 0,a=[...e.pullRequests.filter(e=>e.state===`open`||e.state===`draft`),...e.pullRequests.filter(e=>e.state!==`open`&&e.state!==`draft`)];return H`
    <div class="chat-prs" aria-live="polite">
      ${q(a,lA,r=>{let o=r.state===`merged`,s=r===a[0]?i:void 0;return H`
          <article class="chat-pr" data-state=${r.state}>
            <a
              class="chat-pr__link"
              href=${r.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label=${L(`chat.pullRequests.linkLabel`,{number:String(r.number),title:r.title})}
            >
              <span class="chat-pr__icon" aria-hidden="true">
                ${o?z.gitMerge:z.gitPullRequest}
              </span>
              <span class="chat-pr__number">#${r.number}</span>
              <span class="chat-pr__identity">
                <span class="chat-pr__repo">${r.repo}</span>
                <span class="chat-pr__branch">${r.branch}</span>
              </span>
            </a>
            <span class="chat-pr__meta">
              ${hA(r)} ${mA(r,e)}
              ${r.state===`open`?G:H`<span class="chat-pr__state"
                      >${L(xA[r.state])}</span
                    >`}
              ${!o||e.status===`unavailable`?gA(e.status):G}
              ${s&&!n?eA(s):G}
              <button
                class="chat-pr__dismiss"
                type="button"
                ?disabled=${!!n&&t?.activity!==null}
                aria-label=${L(`chat.pullRequests.dismiss`,{number:String(r.number)})}
                @click=${()=>{n&&t?.onNewAction?.(),e.onDismiss(r)}}
              >
                ${z.x}
              </button>
            </span>
            ${s?sA(s):G}
          </article>
        `})}
    </div>
  `}var bA,xA,SA;function CA(){return(CA=e((()=>{K(),W(),ur(),Qk(),Us(),B(),R(),V(),cA(),bA=`openclaw.chat.dismissedPullRequests`,xA={merged:`chat.pullRequests.merged`,draft:`chat.pullRequests.draft`,closed:`chat.pullRequests.closed`,open:`chat.pullRequests.open`},SA={passing:`chat.pullRequests.checksPassing`,failing:`chat.pullRequests.checksFailing`,pending:`chat.pullRequests.checksPending`}})))()}function wA(e){return L(e===`darwin`?`chat.sessionHeader.revealFinder`:e===`win32`?`chat.sessionHeader.revealFileExplorer`:`chat.sessionHeader.revealFileManager`)}function TA(e){let t=e?Date.parse(e):NaN;return Number.isFinite(t)?ge(t,{fallback:``}):``}function EA(e,t){let n=De(e);if(!n||e&&je(n,e.key))return null;let r=t.find(e=>je(e.key,n));return r?{key:r.key,title:ye(r.key,r)}:null}function DA(e,t,n,r){let i=AA(e,t,n,r),a=OA(e);return H`
    <div class="chat-pane__crumbs">
      ${i?H`<div class="chat-pane__project-row">${i}</div>`:G}
      <div class="chat-pane__session-trail">
        ${i?H`<span class="chat-pane__crumb-sep" aria-hidden="true">/</span>`:G}
        ${a?H`${a}<span class="chat-pane__crumb-sep" aria-hidden="true">/</span>`:G}
        ${kA(e)}
      </div>
    </div>
  `}function OA(e){let t=e.parentSession;if(!t)return null;let n=L(`chat.sessionHeader.openParent`,{title:t.title});return H`<button
    class="chat-pane__parent-session"
    type="button"
    title=${n}
    aria-label=${n}
    @click=${()=>e.onOpenParentSession(t.key)}
  >
    <span class="chat-pane__parent-session-text">${t.title}</span>
  </button>`}function kA(e){return e.editing?H`<input
      class="chat-pane__session-title-input"
      .value=${e.renameValue}
      aria-label=${L(`chat.sessionHeader.renameInputAria`)}
      placeholder=${L(`chat.sessionHeader.renameInputPlaceholder`)}
      @input=${t=>e.onRenameInput(t.currentTarget.value)}
      @keydown=${t=>{t.isComposing||t.keyCode===229||(t.key===`Enter`?(t.preventDefault(),e.onCommitRename()):t.key===`Escape`&&(t.preventDefault(),e.onCancelRename()))}}
      @blur=${e.onCommitRename}
    />`:e.catalog||!e.session||e.renameDisabledReason?H`<span class="chat-pane__session-title" title=${e.renameDisabledReason??e.title}
        >${Tl(e.catalog?e.catalogColor:e.session?.color)}<span
          class="chat-pane__session-title-text"
          >${e.title}</span
        ></span
      >`:H`<button
        class="chat-pane__session-title chat-pane__session-title-button"
        type="button"
        title=${L(`chat.sessionHeader.renameTooltip`)}
        aria-label=${L(`chat.sessionHeader.renameAria`,{title:e.title})}
        @click=${e.onBeginRename}
      >
        ${Tl(e.catalog?e.catalogColor:e.session?.color)}<span
          class="chat-pane__session-title-text"
          >${e.title}</span
        >
      </button>`}function AA(e,t,n,r){return e.catalog||!e.workspaceLabel?null:H`
    <wa-dropdown
      class="chat-pane__workspace-menu"
      placement="bottom-start"
      @wa-select=${t=>{let n=t.detail.item.value;(n===`reveal`||n===`copy-path`||n===`copy-branch`)&&e.onMenuAction(n)}}
      @wa-show=${()=>e.onMenuOpenChange(!0)}
      @wa-hide=${()=>e.onMenuOpenChange(!1)}
    >
      <button
        slot="trigger"
        class=${`chat-pane__workspace-chip${!t&&!e.workspaceIcon?` chat-pane__workspace-chip--fallback-icon`:``}`}
        type="button"
        title=${e.workspaceRoot??e.workspaceLabel}
        aria-label=${L(`chat.sessionHeader.workspaceAria`,{workspace:e.workspaceLabel})}
      >
        ${t?z.check:jA(e.workspaceIcon)}<span
          >${t?L(`chat.sessionHeader.copied`):e.workspaceLabel}</span
        >
      </button>
      ${e.canReveal&&e.workspaceRoot?H`<wa-dropdown-item value="reveal">${wA(e.platform)}</wa-dropdown-item>`:G}
      ${e.workspaceRoot?H`<wa-dropdown-item value="copy-path">${n}</wa-dropdown-item>`:G}
      ${e.branch?H`<wa-dropdown-item value="copy-branch">${r}</wa-dropdown-item>`:G}
    </wa-dropdown>
  `}function jA(e){return e?H`<openclaw-workspace-icon
        .routeUrl=${e.routeUrl}
        .authTokens=${e.authTokens}
        .authReady=${e.authReady}
      ></openclaw-workspace-icon>`:z.folder}function MA(e){return!!(e.workspaceRoot&&e.methodAdvertised&&e.hasAdminAccess&&!e.session?.execNode&&!Dr(e.session?.placement?.state))}function NA(e){let t=e.copiedAction===`copy-path`?L(`chat.sessionHeader.copied`):L(`chat.sessionHeader.copyPath`),n=e.copiedAction===`copy-branch`?L(`chat.sessionHeader.copied`):L(`chat.sessionHeader.copyBranch`),r=e.copiedAction===`copy-path`||e.copiedAction===`copy-branch`,i=e.navDrawerOpen?L(`nav.collapse`):L(`nav.expand`),a=e.narrow&&e.sessionMenuAction!==G,o=e.faceControl!==void 0&&e.faceControl!==G,s=e.sharingControl!==void 0&&e.sharingControl!==G;return H`
    <div
      class="chat-pane__header ${o?`chat-pane__header--centered`:``}"
      role="group"
      aria-label=${e.title}
      tabindex="-1"
      @mousedown=${ln}
    >
      <div class="chat-pane__header-leading">
        ${e.mergedChrome?H`<openclaw-tooltip .content=${i}>
                <button
                  class="btn btn--ghost btn--icon chat-icon-btn chat-pane__nav-toggle"
                  type="button"
                  aria-label=${i}
                  aria-expanded=${String(!!e.navDrawerOpen)}
                  @click=${e=>{window.dispatchEvent(new CustomEvent(Bt,{detail:{trigger:e.currentTarget}}))}}
                >
                  ${z.menu}
                </button>
              </openclaw-tooltip>`:G}
        ${e.session?.incognito?H`<span
                class="chat-pane__incognito"
                role="img"
                aria-label=${L(`chat.sessionHeader.incognito`)}
                title=${L(`chat.sessionHeader.incognito`)}
                >${z.lock}</span
              >`:G}
        ${DA(e,r,t,n)}
        ${e.publicAccessIndicator??G}
        ${s?e.sharingControl:Ul(Sl(e.showOwnerChip?e.session?.owner?.actor:void 0,`header`,e.session?.owner?.assignedAt===void 0?`created`:`owned`,e.ownerViewing),e.showOwnerChip?El(e.session?.owner?.actor.identity?.type===`profile`?e.session.owner.actor.identity.id:void 0,e.personActivity,e.session?.owner?.actor.label):null)}
        ${e.showOwnerChip&&e.session?.participants?.length?H`<openclaw-viewer-facepile
                class="chat-pane__participants"
                .staticParticipants=${e.session.participants}
                .totalCount=${e.session.participantCount}
                .maxVisible=${4}
                .personActivity=${e.personActivity}
                variant="session"
              ></openclaw-viewer-facepile>`:G}
        ${e.placementControl??G} ${e.presence??G}
      </div>
      ${o?H`<div class="chat-pane__header-center">${e.faceControl}</div>`:G}
      <div class="chat-pane__header-trailing">
        ${!e.catalog&&e.branches.length>1?H`
                <wa-dropdown
                  class="chat-pane__branches-menu"
                  placement="bottom-end"
                  @wa-select=${t=>{let n=t.detail.item.value,r=e.branches.find(e=>e.leafEntryId===n);n&&r&&!r.active&&!e.branchSwitchDisabledReason&&e.onBranchSelect(n)}}
                >
                  <button
                    slot="trigger"
                    class="btn btn--ghost btn--icon chat-icon-btn chat-pane__branches-trigger"
                    type="button"
                    ?disabled=${!!e.branchSwitchDisabledReason}
                    title=${e.branchSwitchDisabledReason??L(`chat.sessionHeader.branches`)}
                    aria-label=${L(`chat.sessionHeader.branches`)}
                  >
                    ${z.gitBranch}
                  </button>
                  ${e.branches.map(t=>{let n=TA(t.updatedAt);return H`
                      <wa-dropdown-item
                        class="chat-pane__branch-item"
                        value=${t.leafEntryId}
                        ?disabled=${t.active||!!e.branchSwitchDisabledReason}
                        data-active=${t.active?`true`:`false`}
                      >
                        <span class="chat-pane__branch-copy">
                          <span class="chat-pane__branch-headline"
                            >${t.headline||L(`chat.sessionHeader.untitledBranch`)}</span
                          >
                          <span class="chat-pane__branch-meta"
                            >${L(t.messageCount===1?`chat.sessionHeader.oneMessage`:`chat.sessionHeader.messages`,{count:String(t.messageCount)})}${n?` · ${n}`:``}</span
                          >
                        </span>
                        ${t.active?H`<span
                                class="chat-pane__branch-active"
                                aria-label=${L(`chat.sessionHeader.activeBranch`)}
                                >${z.check}</span
                              >`:G}
                      </wa-dropdown-item>
                    `})}
                </wa-dropdown>
              `:G}
        <div class="chat-pane__actions">
          ${e.panelLayoutActions}
          <fieldset class="chat-pane__actions" ?disabled=${e.actionsDisabled}>
            ${a?G:e.panelActions}
            ${a?G:e.discussionAction}
            ${e.catalog||a?G:H`${e.diffAction} ${e.workspaceAction} ${e.sessionRailAction}`}
            ${[[e.onOpenSplitView&&!a,`chat-open-split-view`,`chat.splitView.open`,z.columns2,e.onOpenSplitView],[!e.narrow&&e.onSplitDown,`chat-pane__split-down`,`chat.splitView.splitDown`,z.panelBottomOpen,()=>e.onSplitDown?.(e.paneId)],[!e.narrow&&e.onSplitRight,`chat-pane__split-right`,`chat.splitView.splitRight`,z.panelRightOpen,()=>e.onSplitRight?.(e.paneId)],[e.onClosePane,`chat-pane__close-pane`,`chat.splitView.closePane`,z.x,()=>e.onClosePane?.(e.paneId)],[e.mergedChrome&&!a,`chat-pane__palette-open`,`chat.openCommandPalette`,z.search,()=>window.dispatchEvent(new Event(en))]].map(([e,t,n,r,i])=>e?H`<openclaw-tooltip .content=${L(n)}>
                    <button
                      class=${`btn btn--ghost btn--icon chat-icon-btn ${t}`}
                      type="button"
                      aria-label=${L(n)}
                      @click=${i}
                    >
                      ${r}
                    </button>
                  </openclaw-tooltip>`:G)}
            ${e.sessionMenuAction}
          </fieldset>
        </div>
      </div>
    </div>
  `}function PA(){return(PA=e((()=>{K(),Pn(),Gt(),B(),Hc(),Hl(),el(),gc(),V(),il(),R(),we(),Xe(),it()})))()}function FA(e){return e.event!==`talk.event`||!e.payload||typeof e.payload!=`object`?null:e.payload}function IA(e){return e instanceof DOMException?uf(e):N(e)}function LA(e){return e instanceof DOMException&&e.name===`AbortError`}function RA(e,t,n,r){let i=t.trim();if(!i)return{value:e,caret:r};let a=Math.max(0,Math.min(n,e.length)),o=Math.max(a,Math.min(r,e.length)),s=e.slice(0,a),c=e.slice(o),l=`${s&&!/\s$/.test(s)&&!/^\s|^[,.;:!?)]/.test(i)?` `:``}${i}${c&&!/^\s|^[,.;:!?)]/.test(c)&&!/[\s([{]$/.test(i)?` `:``}`;return{value:`${s}${l}${c}`,caret:s.length+l.length}}var zA,BA,VA,HA,UA,WA,GA,KA;function qA(){return(qA=e((()=>{hn(),R(),ft(),of(),Xd(),Md(),zA=150,BA=350,VA=1e4,HA=`g711_ulaw`,UA=8e3,WA=UA*10,GA=class{constructor(e,t){this.client=e,this.callbacks=t,this.input=new ef(e=>this.reportFailure(e)),this.context=null,this.inputPump=new gf,this.inputMeter=null,this.unsubscribe=null,this.sessionId=null,this.transcriptionSessionId=null,this.finalTranscripts=[],this.currentPartial=``,this.startPromise=null,this.pendingAudio=[],this.pendingAudioSamples=0,this.appendChain=Promise.resolve(),this.closePromise=null,this.stopped=!1,this.discarded=!1,this.failed=!1,this.gatewayDisconnected=!1,this.settleLateFinalDrain=null}start(){return this.startPromise??=this.startInternal(),this.startPromise}async startInternal(){let e=xn().realtimeTalkInputDeviceId?.trim()||void 0,t=await this.input.open(e);if(this.stopped)return;this.unsubscribe=this.client.addEventListener(e=>this.handleEvent(e));try{this.context=new AudioContext({sampleRate:UA})}catch{throw Error(L(`chat.composer.dictationBrowserAudioUnsupported`))}if(this.context.sampleRate!==UA)throw Error(L(`chat.composer.dictationBrowserAudioUnsupported`));this.inputMeter=new Pd(this.callbacks.onLevel),this.inputMeter.start(t,this.context),this.inputPump.start(t,this.context,e=>this.appendAudio(e)),this.callbacks.onReady();let n=await this.client.request(`talk.session.create`,{mode:`transcription`,transport:`gateway-relay`,brain:`none`});if(this.sessionId=n.sessionId,this.transcriptionSessionId=n.transcriptionSessionId??n.sessionId,n.audio?.inputEncoding!==HA||n.audio.inputSampleRateHz!==UA)throw await this.closeRemote(),Error(L(`chat.composer.dictationAudioUnsupported`));this.discarded?(this.pendingAudio.length=0,this.pendingAudioSamples=0):this.flushPendingAudio(),this.stopped&&(await this.appendChain,await this.closeRemote())}transcriptSnapshot(){return this.transcriptIncludingPartial()}async finish(e=!1){let t=e&&!this.gatewayDisconnected?this.waitForLateFinal():null,n=this.stopAndClose(!0);return t?(n.catch(()=>void 0),t):n.then(()=>this.transcriptIncludingPartial())}async cancel(){this.discarded=!0,await this.stopAndClose(!1)}async stopAndClose(e){await this.stopCapture(),await this.startPromise?.catch(t=>{e&&!LA(t)&&this.reportFailure(IA(t))}),await this.appendChain,await this.closeRemote()}markGatewayDisconnected(){return this.gatewayDisconnected=!0,this.settleLateFinalDrain?.(!1),this.hasTranscript()}cancelPendingFinal(){this.settleLateFinalDrain?.(!0)}appendAudio(e){if(!this.stopped){if(!this.sessionId){let t=WA-this.pendingAudioSamples;if(t<=0)return;let n=e.slice(0,t);this.pendingAudio.push(n),this.pendingAudioSamples+=n.length;return}this.queueAudio(e)}}flushPendingAudio(){let e=this.pendingAudio.splice(0);this.pendingAudioSamples=0;for(let t of e)this.queueAudio(t)}queueAudio(e){if(!this.sessionId)return;let t=this.sessionId,n=$e(Ld(e));this.appendChain=this.appendChain.then(async()=>{await this.client.request(`talk.session.appendAudio`,{sessionId:t,audioBase64:n})}).catch(e=>{this.reportFailure(IA(e))})}handleEvent(e){let t=FA(e);if(t&&t.transcriptionSessionId===this.transcriptionSessionId&&!this.stopped){if(t.type===`transcript`&&typeof t.text==`string`){let e=t.text.trim();if(t.final!==!0){this.currentPartial=e,this.callbacks.onTranscriptChange();return}e&&(this.finalTranscripts.push(e),this.currentPartial=``),this.callbacks.onTranscriptChange();return}if(t.type===`partial`&&typeof t.text==`string`){this.currentPartial=t.text.trim(),this.callbacks.onTranscriptChange();return}if(t.type===`error`){this.reportFailure(me(typeof t.message==`string`?t.message:void 0,L(`chat.composer.dictationFailed`)));return}t.type===`close`&&t.reason===`error`&&this.reportFailure(L(`chat.composer.dictationDisconnected`))}}reportFailure(e){this.failed||(this.failed=!0,this.callbacks.onError(e,this.hasTranscript()))}hasTranscript(){return this.finalTranscripts.length>0||!!this.currentPartial}transcriptIncludingPartial(){return[...this.finalTranscripts,this.currentPartial].filter(Boolean).join(` `).trim()}async stopCapture(){this.stopped||(this.stopped=!0,this.input.stop(),this.inputPump.stop(),this.unsubscribe?.(),this.unsubscribe=null,this.inputMeter?.stop(),this.inputMeter=null,await this.context?.close(),this.context=null)}closeRemote(){return this.sessionId?(this.closePromise??=this.client.request(`talk.session.close`,{sessionId:this.sessionId}).then(()=>void 0).catch(()=>void 0),this.closePromise):Promise.resolve()}waitForLateFinal(){return new Promise(e=>{let t=[],n=()=>{},r=t=>{globalThis.clearTimeout(a),n(),this.settleLateFinalDrain=null,e(t)},i=()=>t.join(` `).trim(),a=globalThis.setTimeout(()=>r(i()),VA);n=this.client.addEventListener(e=>{let n=FA(e);n&&n.transcriptionSessionId===this.transcriptionSessionId&&(n.type===`transcript`&&n.final===!0&&typeof n.text==`string`&&n.text.trim()?t.push(n.text.trim()):(n.type===`error`||n.type===`close`)&&r(i()))}),this.settleLateFinalDrain=e=>r(e?``:i())})}},KA=class{constructor(e){this.inputLevel=new Wd,this.phase=`idle`,this.pointerId=null,this.pointerTarget=null,this.pointerBounds=null,this.holdTimer=null,this.session=null,this.suppressClick=!1,this.suppressedPointerId=null,this.suppressClickTimer=null,this.pendingCommitSession=null,this.disposed=!1,this.handleDocumentPointerMove=e=>{if(e.pointerId!==this.pointerId||!this.pointerBounds)return;let t=this.pointerBounds;(e.clientX<t.left||e.clientX>t.right||e.clientY<t.top||e.clientY>t.bottom)&&this.stop({commit:!1})},this.handleDocumentPointerUp=e=>{if(e.pointerId===this.pointerId){if(this.phase===`pressing`||this.phase===`holding`){let e=this.phase===`pressing`;this.clearPointerGesture(),this.setPhase(`idle`),e&&this.options.onTap?.(),this.expireClickSuppression();return}this.stop({commit:!0})}},this.handleDocumentPointerCancel=e=>{e.pointerId===this.pointerId&&this.stop({commit:!1})},this.handleSuppressedPointerRelease=e=>{e.pointerId===this.suppressedPointerId&&this.expireClickSuppression()},this.handleDocumentKeyDown=e=>{e.key===`Escape`&&this.phase!==`idle`&&(e.preventDefault(),e.stopPropagation(),this.stop({commit:!1}))},this.handleLostPointerCapture=e=>{e.pointerId===this.pointerId&&this.stop({commit:!1})},this.handleVisibilityChange=()=>{document.visibilityState===`hidden`&&(this.clearClickSuppression(),this.stop({commit:!1}))},this.handleWindowBlur=()=>{this.clearClickSuppression(),this.stop({commit:!1})},this.options=e}get active(){return this.phase===`connecting`||this.phase===`recording`||this.phase===`stopping`}get connecting(){return this.phase===`connecting`}get arming(){return this.phase===`holding`}get finalizing(){return this.phase===`stopping`}get locksComposer(){return this.phase!==`idle`}get transcript(){return this.session?.transcriptSnapshot()??``}finishActive(){return this.stop({commit:!0})}startDirect(){return this.phase!==`idle`||!this.canHold()?!1:(this.setPhase(`holding`),this.start(),!0)}update(e){if(this.options=e,e.connected||this.pendingCommitSession?.markGatewayDisconnected(),this.phase!==`stopping`&&(this.phase!==`idle`&&!this.canHold()||this.active&&!e.connected)){let t=this.active&&!e.connected,n=t?this.session?.markGatewayDisconnected()??!1:!1;this.stop({commit:t}),t&&e.onError(L(`chat.composer.dictationDisconnected`),{kind:`interrupted`,preservesText:n})}}handlePointerDown(e){return e.button!==0||this.phase!==`idle`||!this.canHold()?!1:(e.preventDefault(),this.pointerId=e.pointerId,this.pointerTarget=e.currentTarget instanceof HTMLElement?e.currentTarget:null,this.pointerBounds=this.pointerTarget?.getBoundingClientRect()??null,this.pointerTarget?.setPointerCapture?.(e.pointerId),this.pointerTarget?.addEventListener(`lostpointercapture`,this.handleLostPointerCapture),this.suppressClick=!0,this.suppressedPointerId=e.pointerId,this.setPhase(`pressing`),this.holdTimer=globalThis.setTimeout(()=>{this.phase===`pressing`&&(this.setPhase(`holding`),this.holdTimer=globalThis.setTimeout(()=>void this.start(),BA))},zA),document.addEventListener(`pointermove`,this.handleDocumentPointerMove),document.addEventListener(`pointerup`,this.handleDocumentPointerUp),document.addEventListener(`pointercancel`,this.handleDocumentPointerCancel),document.addEventListener(`pointerup`,this.handleSuppressedPointerRelease),document.addEventListener(`pointercancel`,this.handleSuppressedPointerRelease),!0)}handleClick(e){if(this.suppressClick){this.clearClickSuppression(),e.preventDefault();return}if(this.active){e.preventDefault(),this.finishActive();return}if(this.phase!==`idle`){e.preventDefault();return}this.options.onTap?.()}handleContextMenu(e){this.phase!==`idle`&&e.preventDefault()}dispose(){this.disposed=!0,this.retirePendingCommit(),this.clearClickSuppression(),this.stop({commit:!1})}canHold(){return this.options.enabled&&this.options.connected&&!this.options.realtimeTalkActive&&this.options.client!==null}async start(){let e=this.options.client;if(this.phase!==`holding`||!e||!this.canHold()){await this.stop({commit:!1});return}if(this.options.dictationAvailable===!1){this.clearPointerGesture(),this.setPhase(`idle`),this.options.onDictationUnavailable?.();return}this.clearPointerGesture(),this.setPhase(`connecting`);let t=new GA(e,{onError:(e,n)=>{if(this.session===t)try{this.options.onError(e,{kind:`interrupted`,preservesText:n})}finally{this.stop({commit:!0})}},onLevel:e=>this.inputLevel.set(e),onTranscriptChange:()=>this.options.onStateChange(),onReady:()=>{this.session===t&&this.phase===`connecting`&&this.setPhase(`recording`)}});this.retirePendingCommit(),this.session=t;try{await t.start()}catch(e){if(this.session!==t||this.disposed||this.isStopping())return;this.options.onError(IA(e),{kind:`start`,preservesText:!1}),await this.stop({commit:!1})}}stop(e){if(this.phase===`idle`||this.phase===`stopping`)return Promise.resolve(!1);let t=this.active;this.clearPointerGesture();let n=this.session;if(!n)return this.reset(),Promise.resolve(!1);this.setPhase(`stopping`);let r=e.commit?n.transcriptSnapshot():``,i=!!(e.commit&&r&&t&&!this.disposed);return this.session=null,this.reset(),i&&this.options.onCommit(r),e.commit?i?(n.finish().catch(()=>void 0),Promise.resolve(!0)):(this.pendingCommitSession=n,n.finish(!0).then(e=>{let r=this.pendingCommitSession===n;return r&&(this.pendingCommitSession=null),!r||!e||!t||this.disposed?!1:(this.options.onCommit(e,!0),!0)}).catch(()=>(this.pendingCommitSession===n&&(this.pendingCommitSession=null),!1))):(n.cancel().catch(()=>void 0),Promise.resolve(!1))}reset(){this.inputLevel.set(0),this.setPhase(`idle`)}retirePendingCommit(){this.pendingCommitSession?.cancelPendingFinal(),this.pendingCommitSession=null}clearPointerGesture(){if(this.holdTimer!==null&&(globalThis.clearTimeout(this.holdTimer),this.holdTimer=null),this.pointerId!==null){this.pointerTarget?.removeEventListener(`lostpointercapture`,this.handleLostPointerCapture);try{this.pointerTarget?.releasePointerCapture?.(this.pointerId)}catch{}}this.pointerId=null,this.pointerTarget=null,this.pointerBounds=null,document.removeEventListener(`pointermove`,this.handleDocumentPointerMove),document.removeEventListener(`pointerup`,this.handleDocumentPointerUp),document.removeEventListener(`pointercancel`,this.handleDocumentPointerCancel)}expireClickSuppression(){this.suppressClick&&this.suppressClickTimer===null&&(this.suppressClickTimer=globalThis.setTimeout(()=>this.clearClickSuppression(),0))}clearClickSuppression(){this.suppressClickTimer!==null&&(globalThis.clearTimeout(this.suppressClickTimer),this.suppressClickTimer=null),document.removeEventListener(`pointerup`,this.handleSuppressedPointerRelease),document.removeEventListener(`pointercancel`,this.handleSuppressedPointerRelease),this.suppressedPointerId=null,this.suppressClick=!1}isStopping(){return this.phase===`stopping`}setPhase(e){this.phase!==e&&(this.phase===`idle`?(document.addEventListener(`keydown`,this.handleDocumentKeyDown),document.addEventListener(`visibilitychange`,this.handleVisibilityChange),window.addEventListener(`blur`,this.handleWindowBlur)):e===`idle`&&(document.removeEventListener(`keydown`,this.handleDocumentKeyDown),document.removeEventListener(`visibilitychange`,this.handleVisibilityChange),window.removeEventListener(`blur`,this.handleWindowBlur)),this.phase=e,this.options.onStateChange())}}})))()}var JA;function YA(){return(YA=e((()=>{Xd(),JA=class{constructor(e){this.requestUpdate=e,this.devicesValue=[],this.loadingValue=!1,this.openValue=!1,this.issueValue=null,this.deviceWatch=null,this.discoveryRequest=0,this.catalogClient=null,this.catalogConnected=!1,this.catalogRequest=0,this.realtimeStatusValue=`unknown`,this.dictationStatusValue=`unknown`,this.refreshOnFocus=()=>this.loadCatalog(),this.handleOpen=()=>{this.openValue||(this.openValue=!0,this.deviceWatch??=ff(this.discover),this.discover(),this.loadCatalog())},this.handleClose=()=>{this.openValue&&(this.release(),this.openValue=!1,this.requestUpdate())},this.discover=()=>{this.loadingValue=!0,this.issueValue=null;let e=++this.discoveryRequest;this.requestUpdate(),rf(()=>this.openValue&&e===this.discoveryRequest).then(t=>{e===this.discoveryRequest&&(this.devicesValue=t.devices,this.issueValue=t.issue)}).catch(()=>{e===this.discoveryRequest&&(this.devicesValue=[],this.issueValue=`failed`)}).finally(()=>{e===this.discoveryRequest&&(this.loadingValue=!1,this.requestUpdate())})}}get devices(){return this.devicesValue}get loading(){return this.loadingValue}get open(){return this.openValue}get issue(){return this.issueValue}get realtimeStatus(){return this.realtimeStatusValue}get dictationStatus(){return this.dictationStatusValue}syncCatalog(e,t){if(e!==this.catalogClient||t!==this.catalogConnected){if(window.removeEventListener(`focus`,this.refreshOnFocus),this.catalogClient=e,this.catalogConnected=t,this.catalogRequest++,!e||!t){this.realtimeStatusValue=`unknown`,this.dictationStatusValue=`unknown`;return}window.addEventListener(`focus`,this.refreshOnFocus),this.loadCatalog(!1)}}release(){this.deviceWatch?.(),this.deviceWatch=null}dispose(){window.removeEventListener(`focus`,this.refreshOnFocus),this.release(),this.discoveryRequest++,this.catalogRequest++,this.catalogClient=null,this.catalogConnected=!1,this.realtimeStatusValue=`unknown`,this.dictationStatusValue=`unknown`,this.openValue=!1,this.loadingValue=!1}loadCatalog(e=!0){let t=this.catalogClient;if(!t||!this.catalogConnected)return;let n=++this.catalogRequest;this.realtimeStatusValue===`unknown`&&(this.realtimeStatusValue=`checking`),this.dictationStatusValue===`unknown`&&(this.dictationStatusValue=`checking`),e&&this.requestUpdate(),t.request(`talk.catalog`,{}).then(e=>{n===this.catalogRequest&&(this.realtimeStatusValue=e.realtime?.ready===!0?`ready`:`unavailable`,this.dictationStatusValue=e.transcription?.ready===!0?`ready`:`unavailable`)}).catch(()=>{n===this.catalogRequest&&(this.realtimeStatusValue===`checking`&&(this.realtimeStatusValue=`unknown`),this.dictationStatusValue===`checking`&&(this.dictationStatusValue=`unknown`))}).finally(()=>{n===this.catalogRequest&&this.requestUpdate()})}}})))()}function XA(e){for(let t=(e?.length??0)-1;t>=0;--t){let n=a(e?.[t]);if(n?.role===`user`)return null;if(n?.role!==`assistant`||md(n))continue;let r=a(n.cost),i=a(a(n.usage)?.cost),o={};for(let e of[`input`,`output`,`cacheRead`,`cacheWrite`]){let t=y(r?.[e])??y(i?.[e]);t!==void 0&&(o[e]=t)}if(Object.keys(o).length>0)return o}return null}function ZA(e){for(let t=(e?.length??0)-1;t>=0;--t){let n=a(e?.[t]);if(!(n?.role!==`assistant`||md(n)))return typeof n.provider==`string`&&n.provider.trim()||null}return null}function QA(e,t){let n=e?.totalTokens,{tokens:r,fromLastPrompt:i}=Ir(e,t);if(typeof n!=`number`||!Number.isFinite(n)||n<0||!r)return null;let a=e?.totalTokensFresh===!1,o=n/r,s=Math.min(Math.round(o*100),100),c=!a&&o>=oj,l={fromLastPrompt:i,used:n,limit:r,input:Number.isFinite(e?.inputTokens)?e?.inputTokens??null:null,output:Number.isFinite(e?.outputTokens)?e?.outputTokens??null:null,cost:typeof e?.estimatedCostUsd==`number`&&Number.isFinite(e.estimatedCostUsd)&&e.estimatedCostUsd>=0?e.estimatedCostUsd:null};if(!c)return{pct:s,...l,detail:`${a?`~`:``}${F(n)} / ${F(r)}`,color:`var(--muted)`,bg:`color-mix(in srgb, var(--muted) 8%, transparent)`,warning:c,approximate:a};let u=Math.min(Math.max((o-oj)/.1,0),1),d=`color-mix(in srgb, var(--warn), var(--danger) ${u*100}%)`,f=`color-mix(in srgb, ${d} ${8+8*u}%, transparent)`;return{pct:s,...l,detail:`${F(n)} / ${F(r)}`,color:d,bg:f,warning:c,approximate:a}}function $A(e){if(e===`5h`)return L(`chat.composer.contextUsage.limitFiveHour`);if(e===`Week`)return L(`chat.composer.contextUsage.limitWeekly`);if(e===`Day`)return L(`chat.composer.contextUsage.limitDaily`);let t=/^(\d+)h$/.exec(e);return t?L(`chat.composer.contextUsage.limitHours`,{hours:t[1]??``}):e}function ej(e,t){if(/^[A-Za-z]{3}$/.test(t))try{return new Intl.NumberFormat(void 0,{style:`currency`,currency:t.toUpperCase(),maximumFractionDigits:2}).format(e)}catch{}return`${e.toFixed(2)} ${t}`}function tj(e,t){let n=e>=90?`danger`:e>=75?`warn`:null;return H`
    <div
      class="context-usage__limit-bar"
      role="progressbar"
      aria-label=${t}
      aria-valuemin="0"
      aria-valuemax="100"
      aria-valuenow=${e}
    >
      <span
        class=${n?`context-usage__limit-fill--${n}`:``}
        style="width: ${e}%"
      ></span>
    </div>
  `}function nj(e){let t=$A(e.label),n=ns(e.resetAt);return H`
    <div class="context-usage__limit">
      <div class="context-usage__limit-head">
        <span class="context-usage__limit-label">${t}</span>
        <span class="context-usage__limit-meta">
          ${n?H`<span class="context-usage__limit-reset"
                  >${L(`chat.composer.contextUsage.resets`,{time:n})}</span
                >`:G}
          <strong>${e.usedPercent}%</strong>
        </span>
      </div>
      ${tj(e.usedPercent,t)}
    </div>
  `}function rj(e){let t=e.label||L(`chat.composer.contextUsage.usageCredits`),n=Math.max(0,Math.min(100,Math.round(e.used/e.limit*100))),r=L(`chat.composer.contextUsage.budgetValue`,{used:ej(e.used,e.unit),limit:ej(e.limit,e.unit)});return H`
    <div class="context-usage__limit">
      <div class="context-usage__limit-head">
        <span class="context-usage__limit-label">${t}</span>
        <span class="context-usage__limit-meta"><strong>${r}</strong></span>
      </div>
      ${tj(n,t)}
    </div>
  `}function ij(e,t){return H`
    <div class="context-usage__section-label context-usage__plan-header">
      <span>${L(`chat.composer.contextUsage.planUsage`)}</span>
      <a
        class="context-usage__plan-link"
        href=${t}
        data-chat-provider-usage="true"
        aria-label=${L(`chat.composer.contextUsage.openUsage`)}
      >
        ${e.plan?H`<span class="context-usage__plan-badge">${e.plan}</span>`:G}
        ${z.externalLink}
      </a>
    </div>
    ${e.accountEmail?H`<div class="context-usage__account" data-chat-usage-account="true">
            ${e.accountEmail}
          </div>`:G}
    <div class="context-usage__limits">
      ${e.windows.map(e=>nj(e))}
      ${e.budgets.map(e=>rj(e))}
    </div>
    <div class="context-usage__provenance" data-chat-usage-provider="true">
      <span>${L(`sessionsView.provider`)}:</span>
      <strong>${e.displayName}</strong>
    </div>
  `}function aj(e,t,n={}){let r=QA(e,t),i=n.providerUsage?zr(n.providerUsage.modelAuthStatusResult??null,Qo):[],a=(e?.modelProvider?.trim()||ZA(n.messages))?.toLowerCase(),o=a?i.find(e=>e.providers.some(e=>e.trim().toLowerCase()===a)):void 0;if(!r&&!o)return G;let s=r?L(`chat.composer.contextUsage.summary`,{used:`${r.approximate?`~`:``}${F(r.used)}`,limit:F(r.limit),pct:`${r.approximate?`~`:``}${r.pct}`}):L(`chat.usageRemaining`),c=r?`${r.approximate?`~`:``}${r.pct}%`:null,l=r?cj*(1-r.pct/100):cj,u=r?XA(n.messages):null,d=!o,f=`${v(n.providerUsage?.basePath??``)}/usage`,p=e=>e===null?L(`usage.common.emptyValue`):F(e),m=(e,t)=>t===void 0||t<=0?G:H`
          <div>
            <dt>${e}</dt>
            <dd>${se(t)}</dd>
          </div>
        `,h=u&&Object.values(u).some(e=>e>0);return H`
    <div
      class="context-usage"
      style=${r?`--ctx-color:${r.color};--ctx-bg:${r.bg}`:``}
    >
      <details
        @toggle=${e=>{ID(e);let t=e.currentTarget;t instanceof HTMLDetailsElement&&BD(t)}}
      >
        <summary
          class="context-ring ${r?.warning?`context-ring--warning`:``}"
          aria-label=${s}
          title=${L(`chat.composer.contextUsage.open`)}
        >
          <svg
            class="context-ring__dial"
            viewBox="0 0 16 16"
            width="16"
            height="16"
            aria-hidden="true"
          >
            <circle class="context-ring__track" cx="8" cy="8" r=${sj} />
            <circle
              class="context-ring__fill"
              cx="8"
              cy="8"
              r=${sj}
              stroke-dasharray=${cj.toFixed(2)}
              stroke-dashoffset=${l.toFixed(2)}
            />
          </svg>
        </summary>
        <wa-popup data-anchored-overlay>
          <section
            class="context-usage__popover"
            aria-label=${L(`chat.composer.contextUsage.title`)}
          >
            ${r?H`
                    <div class="context-usage__header">
                      <span class="context-usage__title"
                        >${L(r.fromLastPrompt?`chat.composer.contextUsage.promptBudget`:`chat.composer.contextUsage.contextWindow`)}</span
                      >
                      <strong class="context-usage__context-value"
                        >${r.detail} · ${c}</strong
                      >
                    </div>
                    <div
                      class="context-usage__bar"
                      role="progressbar"
                      aria-label=${s}
                      aria-valuemin="0"
                      aria-valuemax="100"
                      aria-valuenow=${r.pct}
                    >
                      <span style="width: ${r.pct}%"></span>
                    </div>
                  `:G}
            ${r?H`
                    <div class="context-usage__section-label">
                      ${L(`chat.composer.contextUsage.latestRunTokens`)}
                    </div>
                    <dl class="context-usage__stats">
                      <div>
                        <dt>${L(`usage.breakdown.input`)}</dt>
                        <dd>${p(r.input)}</dd>
                      </div>
                      <div>
                        <dt>${L(`usage.breakdown.output`)}</dt>
                        <dd>${p(r.output)}</dd>
                      </div>
                      ${!d||r.cost===null?G:H`
                              <div>
                                <dt>${L(`chat.composer.contextUsage.estimatedCost`)}</dt>
                                <dd>${se(r.cost)}</dd>
                              </div>
                            `}
                    </dl>
                  `:G}
            ${d&&u&&h?H`
                    <div class="context-usage__section-label">
                      ${L(`usage.breakdown.costByType`)}
                    </div>
                    <dl class="context-usage__stats">
                      ${m(L(`usage.breakdown.input`),u.input)}
                      ${m(L(`usage.breakdown.output`),u.output)}
                      ${m(L(`usage.breakdown.cacheRead`),u.cacheRead)}
                      ${m(L(`usage.breakdown.cacheWrite`),u.cacheWrite)}
                    </dl>
                  `:G}
            ${o?ij(o,f):G}
          </section>
        </wa-popup>
      </details>
    </div>
  `}var oj,sj,cj;function lj(){return(lj=e((()=>{C(),K(),Ed(),un(),B(),R(),we(),pa(),Bi(),qD(),oj=.85,sj=6.5,cj=2*Math.PI*sj})))()}function uj(e){return e===hj.length?hj:Array.from({length:e},(t,n)=>.35+.65*Math.sin(Math.PI*((n+.5)/e)))}function dj(e){return e===`connecting`||e===`thinking`?e:`listening`}function fj(e,t){return t?.trim()||L(e===`thinking`?`chat.voice.asking`:e===`connecting`?`chat.voice.connecting`:`chat.voice.listening`)}function pj(e){return H`
    <openclaw-microphone-activity
      class="agent-chat__voice-activity"
      data-status=${dj(e.status)}
      data-source="microphone"
      bars=${Jn(e.bars)}
      mode=${Jn(e.mode)}
      aria-hidden="true"
      .signal=${e.inputLevel??_j}
    >
    </openclaw-microphone-activity>
  `}function mj(e){return e.status===`connecting`?H`<div
      class="callout agent-chat__talk-status"
      role="status"
      aria-live="polite"
      aria-atomic="true"
    >
      ${fj(e.status,e.detail)}
    </div>`:e.status!==`error`||!e.detail?G:H`
    <div class="agent-chat__composer-errors agent-chat__composer-errors--standalone">
      <div class="agent-chat__composer-error agent-chat__talk-status" role="alert">
        <span class="agent-chat__composer-error-icon" aria-hidden="true"
          >${z.alertTriangle}</span
        >
        <div class="callout__content">
          <div class="agent-chat__talk-status-text">${e.detail}</div>
          ${e.onUseSystemDefaultMicrophone?H`<button
                  class="btn btn--sm"
                  type="button"
                  @click=${e.onUseSystemDefaultMicrophone}
                >
                  ${L(`chat.composer.useSystemDefaultMicrophoneForCall`)}
                </button>`:G}
        </div>
        ${e.onDismissError?H`
                <button
                  class="callout__dismiss"
                  type="button"
                  @click=${e.onDismissError}
                  aria-label=${L(`chat.composer.dismissVoiceInputError`)}
                >
                  ${z.x}
                </button>
              `:G}
      </div>
    </div>
  `}var hj,gj,_j,vj;function yj(){return(yj=e((()=>{K(),Un(),B(),V(),R(),Md(),hj=[.38,.62,.84,1,.84,.62,.38],gj=`openclaw-microphone-activity`,_j=new Wd,vj=class extends HTMLElement{constructor(...e){super(...e),this.unsubscribe=null,this.gains=hj,this.history=null}set signal(e){e!==this.levelSignal&&(this.unsubscribe?.(),this.unsubscribe=null,this.levelSignal=e,this.ensureBars(),this.renderLevel(e?.value??0),this.isConnected&&this.subscribe())}connectedCallback(){this.ensureBars(),this.subscribe()}disconnectedCallback(){this.unsubscribe?.(),this.unsubscribe=null}ensureBars(){if(!this.firstElementChild){let e=Number(this.getAttribute(`bars`));this.gains=uj(Number.isInteger(e)&&e>0?e:hj.length),this.history=this.getAttribute(`mode`)===`scroll`?this.gains.map(()=>0):null;for(let[e]of this.gains.entries()){let t=document.createElement(`span`);t.className=`agent-chat__voice-activity-bar`,t.style.setProperty(`--talk-bar-delay`,`${e*-70}ms`),this.append(t)}}}subscribe(){this.unsubscribe?.(),this.unsubscribe=this.levelSignal?.subscribe(e=>this.renderLevel(e))??null}renderLevel(e){this.dataset.level=String(e),this.history&&(this.history.push(e),this.history.shift());for(let[t,n]of[...this.children].entries()){let r=this.history?.12+(this.history[t]??0)*.88:.18+e*(this.gains[t]??1)*.82;n.style.setProperty(`--talk-bar-scale`,String(r))}}},customElements.get(gj)||customElements.define(gj,vj)})))()}function bj(e,t){t.matches(`:focus-visible`)||e instanceof HTMLElement&&queueMicrotask(()=>{let t=e.querySelector(`.chat-talk-input-picker__trigger`);t&&document.activeElement===t&&t.blur()})}function xj(e){let t=!e.loading&&e.devices.length===0?e.issue:null,n=t?[]:[{deviceId:``,label:L(`chat.composer.systemDefaultMicrophone`)},...e.loading?[]:e.devices],r=t!==null&&t!==`none-found`&&t!==`list-unsupported`,i=L(`chat.composer.microphoneInput`),a=[{key:`realtime`,label:L(`chat.composer.realtimeTalkCapability`),status:e.realtimeStatus,unavailableReason:L(`chat.composer.realtimeTalkProviderUnavailable`),onOpenSettings:e.onOpenTalkSettings},{key:`dictation`,label:L(`chat.composer.dictationCapability`),status:e.dictationStatus,unavailableReason:L(`chat.composer.dictationProviderUnavailableShort`),onOpenSettings:e.onOpenDictationSettings}].filter(t=>t.status!==`ready`&&(t.key!==`realtime`||e.showRealtimeCapability!==!1));return H`
    <wa-dropdown
      class="chat-talk-input-picker"
      placement="top-end"
      aria-label=${i}
      .open=${e.open}
      @wa-show=${e.onOpen}
      @wa-hide=${e.onClose}
      @wa-select=${t=>{let n=t.detail.item;if(n.hasAttribute(`data-chat-talk-device`)){e.onSelect(n.value??``),bj(t.currentTarget,n);return}if(t.preventDefault(),n.dataset.chatTalkPreference===`hold-to-dictate`){e.onHoldToDictateChange?.(e.holdToDictate===!1);return}a.find(e=>e.key===n.dataset.chatTalkCapability)?.onOpenSettings?.()}}
    >
      <button
        slot="trigger"
        type="button"
        class="chat-talk-input-picker__trigger"
        aria-label=${i}
        aria-haspopup="menu"
        aria-expanded=${String(e.open)}
      >
        ${z.chevronDown}
      </button>
      <div class="chat-talk-input-picker__heading">${i}</div>
      ${t?H`<wa-dropdown-item class="chat-talk-input-picker__notice" disabled>
              <div
                class="chat-talk-input-picker__empty${r?` chat-talk-input-picker__empty--fault`:``}"
                role="status"
              >
                ${$d(t,`audioinput`)}
              </div>
            </wa-dropdown-item>`:H`
              ${n.map(t=>{let n=t.deviceId===e.selectedDeviceId;return H`
                  <wa-dropdown-item
                    class="chat-talk-input-picker__item"
                    data-chat-talk-device
                    value=${t.deviceId}
                    role="menuitemradio"
                    aria-checked=${String(n)}
                    ${U(e=>Fc(e,n))}
                  >
                    <span slot="icon" class="chat-talk-input-picker__option-icon" aria-hidden="true"
                      >${z.mic}</span
                    >
                    <span class="chat-talk-input-picker__label">${t.label}</span>
                    <span slot="details" class="chat-talk-input-picker__check" aria-hidden="true"
                      >${n?z.check:G}</span
                    >
                  </wa-dropdown-item>
                `})}
              ${e.loading?H`<wa-dropdown-item class="chat-talk-input-picker__notice" disabled>
                      <div class="chat-talk-input-picker__note" role="status">
                        ${L(`common.loading`)}
                      </div>
                    </wa-dropdown-item>`:G}
              ${e.issue?H`<wa-dropdown-item class="chat-talk-input-picker__notice" disabled>
                      <div class="chat-talk-input-picker__warning" role="alert">
                        ${$d(e.issue,`audioinput`)}
                      </div>
                    </wa-dropdown-item>`:G}
              ${e.voiceActive?H`<wa-dropdown-item class="chat-talk-input-picker__notice" disabled>
                      <div class="chat-talk-input-picker__hint">
                        ${L(`chat.composer.microphoneAppliesNextSession`)}
                      </div>
                    </wa-dropdown-item>`:G}
            `}
      ${a.map(e=>H`
          <wa-dropdown-item
            class="chat-talk-input-picker__capability"
            data-chat-talk-capability=${e.key}
            data-status=${e.status}
            ?disabled=${!e.onOpenSettings}
          >
            <span class="chat-talk-input-picker__capability-copy" role="status">
              <strong>
                ${e.status===`unavailable`?H`<span class="chat-talk-input-picker__capability-alert" aria-hidden="true"
                        >${z.alertTriangle}</span
                      >`:G}
                <span>${e.label}</span>
              </strong>
              <span>
                ${e.status===`checking`?L(`chat.composer.talkCapabilityChecking`):e.status===`unknown`?L(`chat.composer.talkCapabilityUnknown`):e.unavailableReason}
              </span>
            </span>
            ${e.onOpenSettings?H`<span slot="details" class="chat-talk-input-picker__settings">
                    <span aria-hidden="true">${z.settings}</span>
                    <span>${L(`chat.composer.configureCapability`)}</span>
                  </span>`:G}
          </wa-dropdown-item>
        `)}
      ${e.onHoldToDictateChange?H`
              <wa-dropdown-item
                class="chat-talk-input-picker__preference"
                data-chat-talk-preference="hold-to-dictate"
                type="checkbox"
                .checked=${or(e.holdToDictate!==!1)}
              >
                <span>${L(`chat.composer.holdToDictate`)}</span>
                <span
                  slot="details"
                  class="chat-controls__speed-toggle ${e.holdToDictate===!1?``:`chat-controls__speed-toggle--active`}"
                  aria-hidden="true"
                >
                  <span class="chat-controls__speed-toggle-thumb"></span>
                </span>
              </wa-dropdown-item>
            `:G}
    </wa-dropdown>
  `}function Sj(e){let t=e.dictation?.active===!0,n=e.dictation?.arming===!0,r=e.dictation?.finalizing===!0,i=e.dictation?.locksComposer===!0,a=e.dictation!==void 0&&e.onToggleVoice===void 0,o=t?L(`chat.composer.dictationStopAndKeep`):e.idleLabel??L(`chat.composer.startVoiceInput`),s=e.dictation&&!a&&!(t||r)?[e.submitDisabledReason,L(`chat.composer.voiceGestureHint`)].filter(Boolean).join(` · `):t?o:e.submitDisabledReason??o;return H`
    <span class="chat-talk-control${i?` chat-talk-control--holding`:``}">
      <openclaw-tooltip .content=${s}>
        <button
          class=${t?`chat-send-btn chat-send-btn--dictating`:`chat-send-btn chat-send-btn--voice${e.dictation&&!a?` chat-send-btn--hold-enabled`:``}${n?` chat-send-btn--dictation-arming`:``}`}
          type="button"
          @pointerdown=${t=>e.onDictationPointerDown?.(t)}
          @click=${n=>{if(t){n.preventDefault(),r||e.dictation?.finishActive();return}if(a){n.preventDefault(),e.onDirectDictationStart?.(),e.dictation?.startDirect();return}e.dictation?e.dictation.handleClick(n):e.onToggleVoice?.()}}
          @contextmenu=${t=>e.dictation?.handleContextMenu(t)}
          ?disabled=${!t&&(!e.connected||e.sending||e.isBusy||!e.dictation&&!!e.submitDisabledReason)}
          aria-disabled=${String(r)}
          aria-label=${o}
        >
          ${t?z.stop:H`
                  ${z.mic}
                  <span class="agent-chat__control-label">${o}</span>
                `}
        </button>
      </openclaw-tooltip>
      ${e.microphonePicker}
    </span>
  `}function Cj(e,t,n){return e.active?H`
    ${e.connecting?G:H`<span class="sr-only" role="status" aria-live="polite" aria-atomic="true"
            >${e.finalizing?L(`chat.composer.dictationFinalizing`):L(`chat.composer.dictationListening`)}</span
          >`}
    <openclaw-tooltip .content=${L(`chat.runControls.send`)}>
      <button
        class="chat-send-btn chat-send-btn--send chat-send-btn--dictation-commit"
        type="button"
        @pointerdown=${n}
        @click=${async()=>{e.finalizing||(await e.finishActive(),t())}}
        aria-disabled=${String(e.finalizing)}
        aria-label=${L(`chat.runControls.send`)}
      >
        ${z.arrowUp}
      </button>
    </openclaw-tooltip>
  `:G}function wj(e){if(!e?.active)return G;if(e.connecting)return mj({status:`connecting`,detail:L(`chat.composer.microphoneAccessPending`)});let t=!e.finalizing;return H`
    <div class="agent-chat__composer-status-stack">
      <div
        class=${`agent-chat__dictation-status${e.finalizing?` agent-chat__dictation-status--finalizing`:``}`}
      >
        <span
          class="agent-chat__dictation-phase${t?` agent-chat__dictation-phase--listening`:``}"
        >
          ${e.finalizing?L(`chat.composer.dictationFinalizing`):L(`chat.composer.dictationListening`)}
        </span>
      </div>
    </div>
  `}function Tj(e){return e.canAbort?H`
        <openclaw-tooltip .content=${L(`chat.runControls.stop`)}>
          <button
            class="chat-send-btn chat-send-btn--stop"
            @pointerdown=${e.onPrimaryActionPointerDown}
            @click=${e.onAbort}
            aria-label=${L(`chat.runControls.stopGenerating`)}
          >
            ${z.stop}
            <span class="agent-chat__control-label">${L(`chat.runControls.stop`)}</span>
          </button>
        </openclaw-tooltip>
      `:G}function Ej(e){let t=!!(e.draft.trim()||e.hasAttachments),[n,r]=e.suggestionComposer?[`chat.sessionSuggestions.suggest`,`chat.sessionSuggestions.suggestMessage`]:!e.canAbort||e.followUpMode===void 0||e.followUpMode===`interrupt`?[`chat.runControls.send`,`chat.runControls.sendMessage`]:e.followUpMode===`steer`?[`chat.queue.steer`,`chat.followUpModeSteer`]:[`chat.runControls.queue`,`chat.runControls.queueMessage`],i=e.submissionLabel??L(n),a=e.submissionLabel??L(r),o=L(e.alternateFollowUpMode===`queue`?`chat.runControls.queue`:`chat.queue.steer`),s=e.alternateFollowUpMode&&e.canSend&&t,c=s?`${i} ⏎ · ${o} ${L(`chat.sendShortcutModifierEnter`)}`:i,l=s?H`${i}${` `}${Vt(`⏎`,{inline:!0})}${` · `}${o}${` `}${Vt(L(`chat.sendShortcutModifierEnter`).split(/(⌘)/u).filter(Boolean),{inline:!0})}`:void 0,u=t=>e.onSend(t),d=Tj(e),f=e.voiceStatus===`error`,p=L(e.voiceVideoEnabled?`chat.composer.turnCameraOff`:`chat.composer.turnCameraOn`),m=Sj(e),h=e.dictation||e.onToggleVoice?m:G,g=e.dictation?H`
        <span class="chat-mobile-dictation-action">
          ${Sj({connected:e.connected,sending:e.sending,isBusy:e.isBusy,dictation:e.dictation,idleLabel:L(`chat.composer.dictationCapability`)})}
        </span>
      `:G,_=!t&&!e.dictation?.active&&e.onToggleVoice?H`
          <openclaw-tooltip
            class="chat-mobile-talk-action"
            .content=${e.submitDisabledReason??L(`chat.composer.realtimeTalkCapability`)}
          >
            <button
              class="chat-send-btn chat-send-btn--talk-mode"
              type="button"
              @pointerdown=${e.onPrimaryActionPointerDown}
              @click=${e.onToggleVoice}
              ?disabled=${!e.connected||e.sending||e.isBusy||!!e.submitDisabledReason}
              aria-label=${L(`chat.composer.realtimeTalkCapability`)}
            >
              ${z.audioLines}
              <span class="agent-chat__control-label"
                >${L(`chat.composer.realtimeTalkCapability`)}</span
              >
            </button>
          </openclaw-tooltip>
        `:G,v=e.canSend&&ea(e.draft)?null:e.submitDisabledReason,y=e.sending||!!(v&&e.submitPending),b=v??(e.sending?L(`chat.composer.sendingMessage`):t?null:L(`chat.composer.emptyHint`)),x=t&&e.canSend&&!e.sending&&!v,S=H`
    <openclaw-tooltip
      .content=${e.preparingAttachments?L(`chat.composer.preparingAttachments`):b??c}
      .contentTemplate=${!e.preparingAttachments&&b==null?l:void 0}
    >
      <button
        class="chat-send-btn chat-send-btn--send${e.sending?` chat-send-btn--sending`:``}"
        @pointerdown=${e.onPrimaryActionPointerDown}
        @click=${u}
        ?disabled=${!x}
        aria-label=${b??a}
        aria-busy=${y||e.preparingAttachments?`true`:`false`}
      >
        ${y?H`<span class="btn__spinner" aria-hidden="true"></span>`:z.arrowUp}
        <span class="agent-chat__control-label">${i}</span>
      </button>
    </openclaw-tooltip>
  `,C=e.dictation&&(!e.submitDisabledReason||ea(e.draft))?Cj(e.dictation,()=>e.onSend(),e.onPrimaryActionPointerDown):S,w=e.dictation?.active?C:e.canAbort&&!x?d:S,T=e.dictation?.active?C:e.canAbort&&!x?d:t?S:e.onToggleVoice?_:S,E=T===w?H`<span class="chat-mobile-primary-action chat-desktop-primary-action"
          >${w}</span
        >`:H`
          <span class="chat-mobile-primary-action">${T}</span>
          <span class="chat-desktop-primary-action">${w}</span>
        `;return H`
    ${e.voiceActive&&e.onToggleVoice?H`
            <span class="chat-talk-control chat-talk-control--active">
              <openclaw-tooltip .content=${L(`chat.composer.stopVoiceInput`)}>
                <button
                  class="chat-send-btn chat-send-btn--voice-live${f?` chat-send-btn--voice-error`:``}"
                  @click=${e.onToggleVoice}
                  aria-label=${L(`chat.composer.stopVoiceInput`)}
                >
                  ${f?G:pj({status:e.voiceStatus,inputLevel:e.voiceInputLevel})}
                  <span class="chat-send-btn__voice-stop-glyph">${z.stop}</span>
                </button>
              </openclaw-tooltip>
              ${e.microphonePicker}
            </span>
            ${f||e.voiceStatus===`connecting`?G:H`
                    <span
                      class="sr-only agent-chat__voice-status"
                      role="status"
                      aria-live="polite"
                      aria-atomic="true"
                      >${fj(e.voiceStatus,e.voiceDetail)}</span
                    >
                  `}
            ${e.voiceVideoCapable&&e.onToggleCamera?H`
                    <openclaw-tooltip .content=${p}>
                      <button
                        class="chat-send-btn chat-send-btn--voice"
                        @click=${e.onToggleCamera}
                        ?disabled=${e.voiceVideoPending||e.voiceStatus===`connecting`||e.voiceStatus===`error`}
                        aria-label=${p}
                        aria-pressed=${e.voiceVideoEnabled?`true`:`false`}
                      >
                        ${e.voiceVideoEnabled?z.cameraOff:z.camera}
                        <span class="agent-chat__control-label">${p}</span>
                      </button>
                    </openclaw-tooltip>
                  `:G}
            <span class="chat-mobile-primary-action chat-desktop-primary-action"
              >${d}</span
            >
          `:H` ${h} ${g} ${E} `}
  `}function Dj(){return(Dj=e((()=>{K(),tr(),W(),B(),rn(),Lc(),R(),ya(),Xd(),yj()})))()}function Oj(e,t,n){let r=eD(e),i=()=>t.composerDraftScopeKey===r&&t.goalComposer?.key===r?t.goalComposer:null;if(e.goalDraftMode!==void 0){let n=e.goalDraftMode,a=i();a&&n&&a.action===n.action&&a.sessionId===n.sessionId&&(a.action!==`edit`||n.action===`edit`&&a.goalId===n.goalId&&a.previousDraft===n.previousDraft)||(t.goalComposer=n?{...n,key:r,pending:!1}:null)}let a=n=>{tD(e,n);let r=t.composerTextarea;r&&(r.value=n,mx(r))},o=()=>queueMicrotask(()=>t.composerTextarea?.focus({preventScroll:!0})),s=()=>{let r=i();r&&!r.pending&&(t.goalComposer=null,e.onGoalDraftModeChange?.(null),r.action===`edit`&&a(r.previousDraft),n(),o())},c=s=>{if(!e.onGoalSubmit||i()?.pending)return;let c=t.composerTextarea?.value??e.getDraft?.()??e.draft,l={...e.currentSessionId?{sessionId:e.currentSessionId}:{},...s?{action:`edit`,goalId:s.id,previousDraft:c}:{action:`start`}};t.goalComposer={...l,key:r,pending:!1},e.onGoalDraftModeChange?.(l),jE(t),uE(t),a(s?.objective??``),n(),o()},l=(t,n=!1)=>{if(i()||!e.connected||!e.canSend||!e.onGoalSubmit)return!1;let r=/^\s*\/goal(?:\s+(start|set|create))?\s*$/iu.exec(t);return!r||!n&&(!r[1]||!/\s$/u.test(t))?!1:(c(),!0)};return{get active(){return i()!==null},get pending(){return i()?.pending===!0},get submissionLabel(){let e=i();return e?L(e.action===`edit`?`chat.goals.save`:`chat.goals.start`):void 0},begin:c,activateDraft:l,submitCommand:()=>{l(e.getDraft?.()??e.draft,!0)||e.onSend()},activateCommand:n=>n.key!==`goal`||n.source!==`native`||t.slashMenuCompletion?.inline||!e.onGoalSubmit?!1:(c(),!0),cancel:s,async submit(r){let o=i(),s=t.composerTextarea?.value??e.getDraft?.()??e.draft;if(o&&!o.pending&&e.onGoalSubmit&&s.trim()){a(s),o.pending=!0,n();try{await e.onGoalSubmit({...o.sessionId?{sessionId:o.sessionId}:{},...o.action===`start`?{action:`start`,objective:s}:{action:`edit`,goalId:o.goalId,objective:s}},r)&&i()===o&&(t.goalComposer=null,e.onGoalDraftModeChange?.(null),o.action===`edit`&&a(o.previousDraft))}finally{o.pending=!1,n()}}},render(){let e=i();return e?H`<div
            class="agent-chat__goal-mode composer-context-strip"
            role="group"
            aria-label=${L(`chat.goals.composerMode`)}
          >
            <span class="agent-chat__goal-mode-label composer-context-strip__label">
              <span class="composer-context-strip__icon">${z.flag}</span>
              <span class="composer-context-strip__label-text"
                >${L(e.action===`edit`?`chat.goals.edit`:`chat.goals.composerMode`)}</span
              >
            </span>
            <span class="agent-chat__goal-mode-hint composer-context-strip__text"
              >${L(e.action===`edit`?`chat.goals.editHint`:`chat.goals.startHint`)}</span
            >
            <button
              type="button"
              class="composer-context-strip__dismiss"
              aria-label=${L(`chat.goals.cancel`)}
              ?disabled=${e.pending}
              @click=${s}
            >
              ${z.x}
            </button>
          </div>`:G}}}function kj(){return(kj=e((()=>{K(),B(),R(),ii(),Ex(),SE(),JE(),uD(),gi()})))()}function Aj({state:e,props:t,skillMenuHost:n,slashMenuHost:r,mentionMenuHost:i,requestUpdate:a,sendShortcut:o,canSubmitDraft:s,commitDraft:c,syncDraftAfterSend:l,showAbortableUi:u,alternateFollowUpMode:d,goalComposer:f}){return p=>{let m=p.target;if(!(m instanceof HTMLTextAreaElement)||e.composerComposing||p.isComposing||p.keyCode===229||e.emojiMenu.handleKeydown(p,t.paneId,a)||e.mentionMenu.handleKeydown(p,i,a))return;if(f.active){p.key===`Escape`?(p.preventDefault(),f.cancel()):p.key===`Enter`&&!p.shiftKey&&(o===`enter`||p.metaKey||p.ctrlKey)&&s(m.value)&&(p.preventDefault(),c(m.value),f.submit(p));return}if(t.connected&&yE(p,e,n,a)||t.connected&&VE(p,e,r,a,o)||t.connected&&HE(p,e,r,a))return;if((p.key===`ArrowUp`||p.key===`ArrowDown`)&&t.onHistoryKeydown){c(m.value);let n=t.onHistoryKeydown({key:p.key,selectionStart:m.selectionStart,selectionEnd:m.selectionEnd,valueLength:m.value.length,altKey:p.altKey,ctrlKey:p.ctrlKey,metaKey:p.metaKey,shiftKey:p.shiftKey,isComposing:p.isComposing,keyCode:p.keyCode});if(n.handled){e.editRevision+=1,n.preventDefault&&p.preventDefault(),a(),n.restoreCaret&&bx(m,n.restoreCaret);return}}if(p.key===`Escape`&&!e.skillMenuOpen&&!e.slashMenuOpen&&!e.mentionMenu.open&&!t.replyTarget&&!e.dictation?.active&&u&&t.onAbort){p.preventDefault(),t.onAbort();return}let h=o===`enter`||p.metaKey||p.ctrlKey;if(p.key===`Enter`&&!p.shiftKey&&h){if(p.repeat){p.preventDefault();return}let e=t.getAttachments?.()??t.attachments??[];if(!(m.value.trim()||e.length)){let e=u&&t.connected&&t.canSend&&!t.submitDisabledReason&&t.onQueueSteer?xu(t.displayQueue??t.queue):void 0;if(e){p.preventDefault(),t.onQueueSteer?.(e.id);return}s(m.value)&&p.preventDefault();return}if(!s(m.value)||(p.preventDefault(),c(m.value),f.activateDraft(m.value,!0)))return;let n=(p.metaKey||p.ctrlKey)&&!p.altKey?d:void 0;t.onSend(n,p),l(m)}}}function jj(){return(jj=e((()=>{ld(),Ex(),SE(),JE()})))()}function Mj(e,t){return e.key===`think`?t.modelSwitching?[]:oi(t.selectedSession,t.sessions?.defaults,t.modelCatalog):e.argOptions??[]}function Nj(e,t,n,r,i,a){let o=t&&hE(n),s=t&&UE(r);return{skillMenuVisible:o,slashMenuVisible:s,mentionMenuVisible:i.open,emojiMenuVisible:a.open,menuVisible:o||s||i.open||a.open,activeMenuOptionId:a.open?a.activeId(e):i.open?i.activeId(e):o?gE(n,e):WE(r,e),activeMenuOptionLabel:a.open?a.activeLabel():i.open?i.activeLabel():o?_E(n):GE(r),menuListboxId:xx(e,a.open?`emoji-menu-listbox`:i.open?`mention-menu-listbox`:o?`skill-menu-listbox`:`slash-menu-listbox`)}}function Pj(){return(Pj=e((()=>{Wi(),Ex(),SE(),JE()})))()}function Fj(e){return e?H`<div class="agent-chat__question-dock">
        <openclaw-chat-question-panel .props=${e}></openclaw-chat-question-panel>
      </div>`:G}function Ij(e,t,n){let r=e.gatewayQuestionPrompts?.filter(e=>e.status===`pending`)??[],i=e.asyncQuestions,a=t=>JSON.stringify([e.sessionKey,e.currentAgentId,t]),o=e.disabledBanner?.kind===`composer-replacement`?[]:[...r.map(t=>({key:`gateway:${t.id}`,asyncIdentity:null,compactOnArrival:!1,panel:n=>kx(t,{...n,onChange:e.onGatewayQuestionChange,onSubmit:e.onGatewayQuestionSubmit?n=>e.onGatewayQuestionSubmit?.(t.id,n):void 0,onSkip:e.onGatewayQuestionSkip?()=>e.onGatewayQuestionSkip?.(t.id):void 0})})),...i?.submit?i.pending.map(e=>({key:JSON.stringify([i.scope,e.itemId]),asyncIdentity:a(e.itemId),compactOnArrival:!t.asyncQuestionIds.has(a(e.itemId)),panel:t=>eh(e,i,t)})):[]];t.asyncQuestionIds=new Set(i?.pending.map(e=>a(e.itemId)).filter(e=>t.asyncQuestionIds.has(e)));let s=r.find(e=>!t.gatewayQuestionIds.has(e.id));t.gatewayQuestionIds=new Set(r.map(e=>e.id));let c=r.some(e=>t.activeQuestionKey===`gateway:${e.id}`);s&&!c&&(t.activeQuestionKey=`gateway:${s.id}`,t.questionCollapsed=!1);let l=o.findIndex(e=>e.key===t.activeQuestionKey);if(l<0){l=0,t.activeQuestionKey=o[0]?.key??null;let n=o[l];n&&(t.questionCollapsed=n.asyncIdentity===null?!1:n.compactOnArrival?!!e.draft.trim()||t.composerTextarea!==null&&document.activeElement===t.composerTextarea:t.questionCollapsed)}let u=o[l];if(!u)return null;u.asyncIdentity!==null&&t.asyncQuestionIds.add(u.asyncIdentity);let d=e=>{t.activeQuestionKey=o[e].key,t.questionCollapsed=!1,n()};return u.panel({collapsed:t.questionCollapsed,onCollapsedChange:e=>{t.questionCollapsed=e,t.restoreComposerFocus=e,n(),e&&queueMicrotask(()=>{t.restoreComposerFocus&&t.composerTextarea?.isConnected&&(t.restoreComposerFocus=!1,t.composerTextarea.focus({preventScroll:!0}))})},requestPosition:o.length>1?{current:l+1,total:o.length}:void 0,onPreviousRequest:()=>d((l-1+o.length)%o.length),onNextRequest:()=>d((l+1)%o.length)})}function Lj(){return(Lj=e((()=>{K(),nh(),Nx()})))()}function Rj(){if(!Ee()||Nt()||nn())return!1;let e=navigator.userAgent;return/AppleWebKit\//u.test(e)&&/Version\/[\d.]+(?: Mobile\/\S+)? Safari\/[\d.]+$/u.test(e)}function zj(){return(zj=e((()=>{Bn()})))()}var Bj;function Vj(){return(Vj=e((()=>{K(),Bj=ir`
  :host {
    display: contents;
  }
  openclaw-modal-dialog {
    --openclaw-modal-width: 640px;
  }
  .camera {
    box-sizing: border-box;
    max-height: var(--openclaw-modal-height-limit);
    overflow: auto;
    border: 1px solid var(--border);
    border-radius: var(--radius-xl);
    background: var(--bg);
    color: var(--text);
    box-shadow: var(--shadow-xl);
  }
  header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    padding: 20px;
  }
  h2 {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
  }
  p {
    margin: 6px 0 0;
    color: var(--muted);
    font-size: 13px;
    line-height: 1.5;
  }
  .preview {
    position: relative;
    display: grid;
    place-items: center;
    aspect-ratio: 4 / 3;
    max-height: 55dvh;
    margin: 0 20px;
    overflow: hidden;
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    background: var(--bg-elevated);
  }
  video,
  img {
    display: block;
    width: 100%;
    height: 100%;
    min-height: 0;
    object-fit: contain;
  }
  .notice {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 12px;
    padding: 24px;
    text-align: center;
    background: var(--bg-elevated);
  }
  .notice svg {
    width: 32px;
    height: 32px;
    color: var(--muted);
  }
  .notice p {
    max-width: 38ch;
    margin: 0;
  }
  .notice strong {
    font-size: 15px;
    font-weight: 600;
  }
  .camera-selector {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 16px 20px 0;
    font-size: 13px;
    color: var(--muted);
  }
  select {
    min-width: 0;
    flex: 1;
    padding: 8px;
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    background: var(--bg);
    color: var(--text);
    font: inherit;
  }
  footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    padding: 20px;
  }
  .actions {
    display: flex;
    gap: 8px;
    margin-inline-start: auto;
  }
  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-height: 38px;
    padding: 8px 14px;
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    background: var(--bg);
    color: var(--text);
    font: inherit;
    font-size: 13px;
    font-weight: 500;
    cursor: default;
  }
  button:hover:not(:disabled) {
    background: var(--bg-elevated);
  }
  button:focus-visible,
  select:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 3px;
  }
  button:disabled {
    opacity: 0.45;
  }
  button svg {
    width: 16px;
    height: 16px;
  }
  .primary {
    background: var(--primary);
    color: var(--primary-foreground);
    border-color: var(--primary);
  }
  .primary:hover:not(:disabled) {
    background: var(--primary-hover);
  }
  .icon-button {
    width: 32px;
    min-height: 32px;
    padding: 6px;
    border-color: transparent;
  }
  .upload {
    border-color: transparent;
    color: var(--muted);
    padding-inline: 0;
  }
  @media (max-width: 560px) {
    header,
    footer {
      padding: 16px;
    }
    .preview {
      margin-inline: 16px;
    }
    .camera-selector {
      margin-inline: 16px;
    }
  }
`})))()}var Hj;function Uj(){return(Uj=e((()=>{K(),ar(),B(),Ft(),R(),os(),tt(),Vj(),Ii(),Hj=class extends He{constructor(...e){super(...e),this.disabled=!1,this.nativeFallback=!1,this.stage=`closed`,this.error=``,this.photoUrl=``,this.cameras=[],this.cameraId=``,this.videoReady=!1,this.generation=0,this.close=()=>{this.generation+=1,this.stopCamera(),this.clearPhoto(),this.activeSignal?.removeEventListener(`abort`,this.close),this.activeSignal=void 0,this.captureDestination=void 0,this.uploadDestination=void 0,this.nativeCaptureDestination=void 0,this.stage=`closed`},this.capture=async()=>{let e=this.renderRoot.querySelector(`video`),t=this.generation;if(this.isCurrent(t)&&this.stage===`live`&&e?.videoWidth&&e.videoHeight){this.stage=`capturing`;try{let n=document.createElement(`canvas`);n.width=e.videoWidth,n.height=e.videoHeight;let r=n.getContext(`2d`);if(!r)throw Error(`Canvas unavailable`);r.drawImage(e,0,0),this.stopCamera();let i=await new Promise(e=>{n.toBlob(e,`image/jpeg`,.92)});if(n.width=n.height=0,!this.isCurrent(t))return;if(!i)throw Error(`Image encoding failed`);this.photo=new File([i],`camera-${Date.now()}.${i.type===`image/png`?`png`:`jpg`}`,{type:i.type}),this.photoUrl=URL.createObjectURL(i),this.stage=`review`}catch{this.isCurrent(t)&&this.fail(L(`chat.camera.captureFailed`))}}},this.usePhoto=()=>{if(!this.isCurrent(this.generation)||this.stage!==`review`||!this.photo)return;let e=this.photo,t=this.captureDestination;this.close(),t?.(e)},this.upload=()=>{if(!this.isCurrent(this.generation))return;let e=this.uploadDestination;this.close(),e?.(this)},this.useNativeCamera=()=>{if(!this.isCurrent(this.generation)||this.stage!==`error`||!this.nativeFallback)return;let e=this.nativeCaptureDestination;this.close(),e?.(this)}}static{this.styles=Bj}connectedCallback(){super.connectedCallback(),window.addEventListener(`pagehide`,this.close)}disconnectedCallback(){this.close(),window.removeEventListener(`pagehide`,this.close),super.disconnectedCallback()}willUpdate(e){this.stage!==`closed`&&(e.has(`disabled`)&&this.disabled||e.has(`readSignal`)&&this.readSignal!==this.activeSignal)&&this.close()}show(){!this.isConnected||this.disabled||this.readSignal?.aborted||this.stage!==`closed`||(this.activeSignal=this.readSignal,this.activeSignal?.addEventListener(`abort`,this.close,{once:!0}),this.captureDestination=this.onCapture,this.uploadDestination=this.onUpload,this.nativeCaptureDestination=this.onNativeCapture,this.cameraId=``,this.cameras=[],this.stage=`requesting`,this.startCamera())}isCurrent(e){return e===this.generation&&this.stage!==`closed`&&this.isConnected&&!this.disabled&&this.activeSignal===this.readSignal&&!this.activeSignal?.aborted}stopCamera(){this.stream?.getTracks().forEach(e=>e.stop()),this.stream=void 0;let e=this.renderRoot.querySelector(`video`);e&&(e.srcObject=null),this.videoReady=!1}clearPhoto(){this.photoUrl&&URL.revokeObjectURL(this.photoUrl),this.photoUrl=``,this.photo=void 0}fail(e,t=!1){this.generation+=1,this.stopCamera(),this.error=e,this.nativeFallback=t,this.stage=`error`}async startCamera(){if(!this.isCurrent(this.generation))return;let e=++this.generation;if(this.stopCamera(),this.clearPhoto(),this.stage=`requesting`,this.error=``,this.nativeFallback=!1,!globalThis.isSecureContext){this.fail(L(`chat.camera.insecure`),!0);return}if(!navigator.mediaDevices?.getUserMedia){this.fail(L(`chat.camera.unsupported`),!0);return}try{let t=await navigator.mediaDevices.getUserMedia({audio:!1,video:this.cameraId?{deviceId:{exact:this.cameraId}}:{facingMode:{ideal:`environment`}}});if(!this.isCurrent(e)){t.getTracks().forEach(e=>e.stop());return}this.stream=t;let n=t.getVideoTracks()[0];if(!n||n.readyState===`ended`){this.fail(L(`chat.camera.stopped`));return}if(n.addEventListener(`ended`,()=>{this.isCurrent(e)&&this.stream===t&&this.fail(L(`chat.camera.stopped`))},{once:!0}),this.cameraId=n.getSettings().deviceId??this.cameraId,this.listCameras(e),await this.updateComplete,!this.isCurrent(e))return;let r=this.renderRoot.querySelector(`video`);if(!r||(r.srcObject=t,await r.play(),!this.isCurrent(e)))return;this.videoReady=r.videoWidth>0&&r.videoHeight>0,this.stage=`live`}catch(t){if(!this.isCurrent(e))return;let n=t instanceof DOMException||t instanceof Error?t.name:``;this.fail(L(n===`NotAllowedError`||n===`SecurityError`?`chat.camera.permissionDenied`:n===`NotFoundError`||n===`OverconstrainedError`?`chat.camera.notFound`:`chat.camera.unavailable`))}}async listCameras(e){try{let t=await navigator.mediaDevices.enumerateDevices();this.isCurrent(e)&&(this.cameras=t.filter(e=>e.kind===`videoinput`))}catch{}}render(){if(this.stage===`closed`)return G;let e=this.stage===`review`,t=this.stage===`error`,n=t&&this.nativeFallback&&!!this.nativeCaptureDestination;return H`
      <openclaw-modal-dialog .label=${L(`chat.camera.title`)} @modal-cancel=${this.close}>
        <section class="camera">
          <header>
            <div>
              <h2>${L(`chat.camera.title`)}</h2>
              <p>${L(e?`chat.camera.reviewHint`:`chat.camera.previewHint`)}</p>
            </div>
            <button
              type="button"
              class="icon-button"
              aria-label=${L(`common.close`)}
              @click=${this.close}
            >
              ${z.x}
            </button>
          </header>
          <div
            class="preview"
            aria-busy=${this.stage===`requesting`||this.stage===`capturing`?`true`:`false`}
          >
            ${e?H`<img src=${this.photoUrl} alt=${L(`chat.camera.photoAlt`)} />`:H`<video
                    autoplay
                    muted
                    playsinline
                    aria-label=${L(`chat.composer.cameraPreview`)}
                    @loadeddata=${e=>{let t=e.currentTarget;t instanceof HTMLVideoElement&&t.srcObject===this.stream&&this.isCurrent(this.generation)&&(this.videoReady=t.videoWidth>0&&t.videoHeight>0)}}
                  ></video>`}
            ${t?H`<div class="notice" role="alert">
                    ${z.camera}<strong
                      >${L(n?`chat.camera.previewUnavailable`:`chat.camera.errorTitle`)}</strong
                    >
                    <p>${this.error}</p>
                  </div>`:this.stage===`requesting`||this.stage===`capturing`?H`<div class="notice" role="status">
                      ${z.camera}
                      <p>
                        ${this.stage===`capturing`?L(`chat.camera.capturing`):L(`chat.camera.requesting`)}
                      </p>
                    </div>`:G}
          </div>
          ${!e&&!t&&this.cameras.length>1?H`<label class="camera-selector"
                  >${L(`chat.composer.cameraInput`)}
                  <select
                    .value=${this.cameraId}
                    ?disabled=${this.stage!==`live`}
                    @change=${e=>{let t=e.currentTarget;t instanceof HTMLSelectElement&&this.isCurrent(this.generation)&&this.stage===`live`&&(this.cameraId=t.value,this.startCamera())}}
                  >
                    ${this.cameras.map((e,t)=>H`<option value=${e.deviceId} ?selected=${e.deviceId===this.cameraId}>${e.label||L(`chat.composer.cameraFallback`,{number:String(t+1)})}</option>`)}
                  </select>
                </label>`:G}
          <footer>
            <button type="button" class="upload" @click=${this.upload}>
              ${z.image}${L(`chat.camera.upload`)}
            </button>
            <div class="actions">
              <button
                type="button"
                autofocus
                @click=${e?()=>void this.startCamera():this.close}
              >
                ${L(e?`chat.camera.retake`:`common.cancel`)}
              </button>
              <button
                type="button"
                class="primary"
                ?disabled=${!e&&!t&&(this.stage!==`live`||!this.videoReady)}
                @click=${e?this.usePhoto:n?this.useNativeCamera:t?()=>void this.startCamera():this.capture}
              >
                ${L(e?`chat.camera.usePhoto`:n?`chat.camera.useNativeCamera`:t?`chat.camera.retry`:`chat.camera.capture`)}
              </button>
            </div>
          </footer>
        </section>
      </openclaw-modal-dialog>
    `}},k([X({type:Boolean})],Hj.prototype,`disabled`,void 0),k([X({attribute:!1})],Hj.prototype,`readSignal`,void 0),k([X({attribute:!1})],Hj.prototype,`onCapture`,void 0),k([X({attribute:!1})],Hj.prototype,`onUpload`,void 0),k([X({attribute:!1})],Hj.prototype,`onNativeCapture`,void 0),k([J()],Hj.prototype,`nativeFallback`,void 0),k([J()],Hj.prototype,`stage`,void 0),k([J()],Hj.prototype,`error`,void 0),k([J()],Hj.prototype,`photoUrl`,void 0),k([J()],Hj.prototype,`cameras`,void 0),k([J()],Hj.prototype,`cameraId`,void 0),k([J()],Hj.prototype,`videoReady`,void 0),customElements.get(`openclaw-chat-camera-capture`)||customElements.define(`openclaw-chat-camera-capture`,Hj)})))()}function Wj(e,t){e.closest(`details`)?.removeAttribute(`open`),e.closest(`.agent-chat__composer-shell, .new-session-page__composer`)?.querySelector(t)?.click()}function Gj(e,t){let n=e.target;if(!(n instanceof HTMLInputElement))return;let r=[...n.files??[]];n.value=``,gT(r,t)}function Kj(e){return bt(e.uploadConfig)?H`
    <openclaw-chat-camera-capture
      .disabled=${!!e.disabled||e.cameraActive===!1}
      .readSignal=${e.readSignal??e.attachmentReads?.readSignal}
      .onCapture=${t=>{e.disabled||gT([t],e)}}
      .onNativeCapture=${t=>{e.disabled||Wj(t,`.agent-chat__camera-input`)}}
      .onUpload=${t=>{e.disabled||Wj(t,`.agent-chat__photo-input`)}}
    ></openclaw-chat-camera-capture>
    ${[`file`,`photo`,`camera`].map(t=>H`
        <input
          type="file"
          accept=${t===`file`?Xj:`image/*`}
          ?multiple=${t!==`camera`}
          capture=${t===`camera`?`environment`:G}
          class=${`agent-chat__${t}-input`}
          ?disabled=${e.disabled}
          @change=${t=>{e.disabled||Gj(t,e)}}
        />
      `)}
  `:G}function qj(e){let t=e.detail.item.value;if(t!==`camera`&&t!==`photo`&&t!==`file`)return!1;let n=e.currentTarget;return n instanceof HTMLElement&&(t===`camera`?n.closest(`.agent-chat__composer-shell, .new-session-page__composer`)?.querySelector(`openclaw-chat-camera-capture`)?.show():Wj(n,`.agent-chat__${t}-input`)),!0}function Jj(e,t=!1){return H`
    <button
      slot="trigger"
      type="button"
      class="agent-chat__input-btn agent-chat__input-btn--attach ${t?`agent-chat__input-btn--has-overrides`:``}"
      aria-label=${L(`chat.composer.addAttachment`)}
      ?disabled=${e}
      title=${L(`chat.composer.addAttachment`)}
    >
      ${z.plus}
    </button>
  `}function Yj(e=z.folder){return[{value:`camera`,icon:z.camera,label:L(`chat.composer.takePhoto`)},...Rj()?[{value:`file`,icon:e,label:L(`chat.composer.attach`)}]:[{value:`photo`,icon:z.image,label:L(`chat.composer.attachPhoto`)},{value:`file`,icon:e,label:L(`chat.composer.attachFileOption`)}]].map(({value:e,icon:t,label:n})=>H`
      <wa-dropdown-item class="agent-chat__attach-menu-option" value=${e}>
        <span slot="icon" aria-hidden="true">${t}</span>
        <span>${n}</span>
      </wa-dropdown-item>
    `)}var Xj;function Zj(){return(Zj=e((()=>{K(),B(),Lc(),R(),Le(),zj(),OT(),Uj(),Xj=`image/*,audio/*,video/*,application/pdf,text/*,.csv,.json,.md,.txt,.zip,.doc,.docx,.xls,.xlsx,.ppt,.pptx`})))()}function Qj(){return H`<div class="agent-chat__capability-menu-divider" role="separator"></div>`}function $j(){return H`
    <wa-dropdown-item class="agent-chat__capability-menu-item" value="back">
      <span slot="icon" aria-hidden="true">${z.arrowLeft}</span>
      <span>${L(`chat.composer.menu.back`)}</span>
    </wa-dropdown-item>
    ${Qj()}
  `}function eM(e){return H`
    <wa-dropdown-item
      class="agent-chat__capability-menu-item agent-chat__capability-menu-toggle"
      value=${e.value}
      type="checkbox"
      .checked=${or(e.checked)}
      ?disabled=${e.disabled}
      title=${e.title??``}
    >
      ${e.icon?H`<span slot="icon" aria-hidden="true">${e.icon}</span>`:G}
      <span class="agent-chat__capability-menu-label">
        <span>${e.label}</span>
        ${e.note??G}
      </span>
      ${e.checkbox?G:H`<wa-switch
              slot="details"
              class="agent-chat__capability-menu-switch"
              size="s"
              tabindex="-1"
              inert
              aria-hidden="true"
              .checked=${e.checked}
              ?disabled=${e.disabled}
            ></wa-switch>`}
    </wa-dropdown-item>
  `}function tM(){return(tM=e((()=>{K(),tr(),B(),R()})))()}function nM(e){return H`
    ${e.loading||e.busy?H`<div class="agent-chat__capability-menu-state" role="status">
            ${L(`common.loading`)}
          </div>`:G}
    ${e.error?H`<div class="agent-chat__capability-menu-state" role="alert">${e.error}</div>
            <wa-dropdown-item value="library-reload">${L(`common.retry`)}</wa-dropdown-item>`:G}
    ${e.notice?H`<div class="agent-chat__capability-menu-state" role="status">${e.notice}</div>`:G}
  `}function rM(e,t){if(!e)return G;let n=e.busy||e.loading,r=e.result?.session;if(t){let i=r?.selections.find(e=>e.skillId===t);return H`
      ${$j()} ${nM(e)}
      ${i?H`
              <div class="agent-chat__capability-menu-state">
                <span class="agent-chat__capability-menu-label">
                  <strong>${i.slug} · ${i.ownerLabel}</strong>
                  <span class="agent-chat__capability-menu-note"
                    >${L(`skillLibrary.session.pin`,{revision:i.revision.slice(0,8)})}</span
                  >
                </span>
              </div>
              <wa-dropdown-item
                class="agent-chat__capability-menu-item"
                value=${`library-read:${i.skillId}`}
                ?disabled=${n}
                >${L(`skillLibrary.session.read`)}</wa-dropdown-item
              >
              ${e.canWrite?H`
                      <wa-dropdown-item
                        class="agent-chat__capability-menu-item"
                        value=${`library-refresh:${i.skillId}`}
                        ?disabled=${n}
                        >${L(`skillLibrary.session.refresh`)}</wa-dropdown-item
                      >
                      <wa-dropdown-item
                        class="agent-chat__capability-menu-item"
                        value=${`library-detach:${i.skillId}`}
                        ?disabled=${n}
                        >${L(`skillLibrary.session.detach`)}</wa-dropdown-item
                      >
                    `:G}
            `:e.result&&!n?H`<div class="agent-chat__capability-menu-state">${L(`skillsPage.notFound`)}</div>`:G}
    `}return e.result?.defaultTarget===`workspace`&&!r?.selections.length&&!r?.attachable.length?G:H`
    <div class="agent-chat__capability-menu-state">${L(`skillLibrary.session.selected`)}</div>
    ${nM(e)}
    ${r?.selections.map(e=>H`<wa-dropdown-item
        class="agent-chat__capability-menu-item"
        value=${`library-selected:${e.skillId}`}
        ?disabled=${n}
        title=${`${e.slug} · ${e.ownerLabel}`}
      >
        <span class="agent-chat__capability-menu-label"
          ><span>${e.slug} · ${e.ownerLabel}</span
          ><span class="agent-chat__capability-menu-note"
            >${L(`skillLibrary.session.pin`,{revision:e.revision.slice(0,8)})}</span
          ></span
        >
        <span slot="details" class="agent-chat__capability-menu-chevron" aria-hidden="true"
          >${z.chevronRight}</span
        >
      </wa-dropdown-item>`)}
    ${r&&r.selections.length===0?H`<div class="agent-chat__capability-menu-state">
            ${L(`skillLibrary.session.empty`)}
          </div>`:G}
    ${r?.attachable.length?H`${Qj()}
            <div class="agent-chat__capability-menu-state">
              ${L(`skillLibrary.session.attachable`)}
            </div>
            ${r.attachable.map(t=>H`<wa-dropdown-item
                class="agent-chat__capability-menu-item"
                value=${`library-attach:${t.skillId}`}
                ?disabled=${n||!e.canWrite}
              >
                <span class="agent-chat__capability-menu-label"
                  ><span title=${`${t.slug} · ${t.ownerLabel}`}
                    >${L(`skillLibrary.session.attachNamed`,{name:t.slug,owner:t.ownerLabel})}</span
                  ><span class="agent-chat__capability-menu-note" title=${t.description}
                    >${t.description}</span
                  ></span
                >
              </wa-dropdown-item>`)}`:G}
    ${e.result?H`<div class="agent-chat__capability-menu-state">
            ${L(`skillLibrary.defaultLimit`,{count:String(e.result.defaultSelectionLimit)})}
          </div>`:G}
    ${e.result?.defaultSelectionNotice?H`<div class="agent-chat__capability-menu-state" role="status">
            ${e.result.defaultSelectionNotice}
          </div>`:G}
    ${Qj()}
    <div class="agent-chat__capability-menu-state">${L(`skillLibrary.inventory`)}</div>
  `}function iM(e,t,n){if(!e.startsWith(`library-`))return!1;if(e===`library-reload`)t?.onReload();else if(t&&!t.loading&&!t.busy){let r=e.slice(e.indexOf(`:`)+1),i=t.result?.session?.selections.find(e=>e.skillId===r);if(e.startsWith(`library-selected:`)&&i)n(`library:${i.skillId}`);else if(e.startsWith(`library-read:`)&&i)t.onRead(i.skillId,i.revision);else if(t.canWrite){if(e.startsWith(`library-attach:`)){let e=t.result?.session?.attachable.find(e=>e.skillId===r);e&&t.onActivate(`attach`,e.skillId,e.revision)}else i&&e.startsWith(`library-detach:`)?(t.onActivate(`detach`,i.skillId),n(`skills`)):i&&e.startsWith(`library-refresh:`)&&t.onActivate(`refresh`,i.skillId)}}return!0}function aM(){return(aM=e((()=>{K(),B(),R(),$a(),fs(),tM(),Sa(),Ja()})))()}function oM(e,t){return H`<a
    class="agent-chat__capability-menu-link"
    href=${e}
    tabindex="-1"
    @click=${e=>e.preventDefault()}
    >${t}</a
  >`}function sM(e){let t=_a(e.toolOverrides),n=e.mcpServers.filter(t=>Ur(t.enabled,zi(e.toolOverrides?.mcpServers,t.name))).length,r=Object.keys(e.toolOverrides?.skills??{}).length>0,i=e.skills?.filter(e=>e.enabled).length??0,a=as(e.webSearchBaseEnabled,e.toolOverrides?.webSearch),o=!e.webSearchBaseEnabled&&e.toolOverrides?.webSearch===!0,s=e.mutationBlockedReason!==null||!e.webSearchBaseEnabled&&!o,c=e.mutationBlockedReason??(o?L(`chat.composer.menu.webSearchClearStaleEnable`):e.webSearchBaseEnabled?``:L(`chat.composer.menu.webSearchGloballyDisabled`)),l=bt(e.attachments.uploadConfig),u=l?Yj(z.paperclip):G,d=e.rootToggles??[];return!e.showCapabilities&&d.length===0?u:H`
    ${u} ${l?Qj():G}
    ${d.map(eM)}
    ${e.showCapabilities?H`<wa-dropdown-item class="agent-chat__capability-menu-item" value="open-skills">
              <span slot="icon" aria-hidden="true">${z.book}</span>
              <span>${L(`chat.composer.menu.skills`)}</span>
              <span slot="details" class="agent-chat__capability-menu-details">
                ${r?H`<span class="agent-chat__capability-menu-badge"
                        >${L(`chat.composer.menu.enabledCount`,{count:String(i)})}</span
                      >`:G}
                <span class="agent-chat__capability-menu-chevron" aria-hidden="true"
                  >${z.chevronRight}</span
                >
              </span>
            </wa-dropdown-item>
            <wa-dropdown-item class="agent-chat__capability-menu-item" value="open-connectors">
              <span slot="icon" aria-hidden="true">${z.plug}</span>
              <span>${L(`chat.composer.menu.connectors`)}</span>
              <span slot="details" class="agent-chat__capability-menu-details">
                <span class="agent-chat__capability-menu-badge">${n}</span>
                <span class="agent-chat__capability-menu-chevron" aria-hidden="true"
                  >${z.chevronRight}</span
                >
              </span>
            </wa-dropdown-item>
            ${eM({value:`toggle-web-search`,label:L(`chat.composer.menu.webSearch`),checked:a,disabled:s,title:c,icon:z.globe,checkbox:!0})}
            ${Qj()}
            <wa-dropdown-item class="agent-chat__capability-menu-item" value="manage-plugins">
              <span slot="icon" aria-hidden="true">${z.plug}</span>
              ${oM(_n(`plugins`,e.basePath),L(`chat.composer.menu.managePlugins`))}
            </wa-dropdown-item>
            ${t>0?H`
                    <wa-dropdown-item
                      class="agent-chat__capability-menu-item agent-chat__capability-menu-overrides"
                      value="clear-overrides"
                      ?disabled=${e.mutationBlockedReason!==null}
                      title=${e.mutationBlockedReason??``}
                    >
                      <span slot="icon" aria-hidden="true">${z.settings}</span>
                      <span
                        >${L(t===1?`chat.composer.overrides.countOne`:`chat.composer.overrides.count`,{count:String(t)})}</span
                      >
                      <span
                        slot="details"
                        class="agent-chat__capability-menu-clear-overrides"
                        aria-hidden="true"
                        >${z.x}</span
                      >
                    </wa-dropdown-item>
                  `:G}`:G}
  `}function cM(e){let t=e.mutationBlockedReason,n=e.skillsLoading?H`<div class="agent-chat__capability-menu-state" role="status">
        ${L(`chat.composer.menu.loadingSkills`)}
      </div>`:e.skillsError?H`<div class="agent-chat__capability-menu-state" role="alert">
          ${L(`chat.composer.menu.skillsLoadFailed`)}
        </div>`:!e.skills||e.skills.length===0?H`<div class="agent-chat__capability-menu-state">
            ${L(`chat.composer.menu.noSkills`)}
          </div>`:e.skills.map((e,n)=>{let r=e.missingDeps?L(`chat.composer.menu.depsMissing`):e.blocked?L(`chat.composer.menu.skillBlocked`):t;return eM({value:`skill:${n}`,label:e.name,checked:e.enabled,disabled:e.missingDeps||e.blocked||t!==null,title:r,note:e.missingDeps||e.blocked?H`<span class="agent-chat__capability-menu-note">${r}</span>`:G})});return H`
    ${$j()} ${rM(e.library)} ${n} ${Qj()}
    <wa-dropdown-item class="agent-chat__capability-menu-item" value="manage-skills">
      ${oM(_n(`skills`,e.basePath),L(`chat.composer.menu.manageSkills`))}
    </wa-dropdown-item>
  `}function lM(e){let t=e.mutationBlockedReason,n=e.mcpServers.length===0?H`<div class="agent-chat__capability-menu-state">
          ${L(`chat.composer.menu.noConnectors`)}
        </div>`:e.mcpServers.map((n,r)=>{let i=zi(e.toolOverrides?.mcpServers,n.name),a=Ur(n.enabled,i);return H`
            ${eM({value:`connector:${r}`,label:n.name,checked:a,disabled:t!==null,title:t,note:H`<span class="agent-chat__capability-menu-note">
                ${L(a?`common.enabled`:`common.disabled`)}
                ${i===void 0?G:H`<span class="agent-chat__capability-menu-session-tag"
                        >${L(`chat.composer.menu.sessionTag`)}</span
                      >`}
              </span>`})}
            ${e.onOpenToolAccess?H`<wa-dropdown-item
                    class="agent-chat__capability-menu-item agent-chat__capability-menu-subrow"
                    value=${`tools:${r}`}
                  >
                    <span slot="icon" aria-hidden="true">${z.wrench}</span>
                    <span>${L(`chat.composer.menu.toolAccess.label`)}</span>
                  </wa-dropdown-item>`:G}
          `}),r=!e.canAdmin;return H`
    ${$j()} ${n} ${Qj()}
    ${e.onAddServer?H`<wa-dropdown-item
            class="agent-chat__capability-menu-item"
            value="add-server"
            ?disabled=${r}
            title=${r?e.adminBlockedReason??``:``}
          >
            <span slot="icon" aria-hidden="true">${z.plus}</span>
            <span>${L(`chat.composer.menu.addMcpServer`)}</span>
          </wa-dropdown-item>`:G}
  `}function uM(e,t){return(e?.groups??[]).flatMap(e=>e.tools).filter(e=>e.source===`mcp`&&e.mcpServer===t&&!!e.mcpToolName)}function dM(e,t){return e?.notices?.find(e=>_M.has(e.id)&&e.servers?.includes(t)===!0)}function fM(e,t){let n=t.mcpServer,r=t.mcpToolName;return!n||!r?!1:e.toolOverrides==null?t.deniedBySession===!0:zi(e.toolOverrides.mcpToolsDeny,n)?.includes(r)??!1}function pM(e,t){let n=uM(e.toolsEffectiveResult,t),r=n.length===0?dM(e.toolsEffectiveResult,t):null,i=n.filter(t=>!fM(e,t)).length,a=L(n.length===1?`chat.composer.menu.toolAccess.summaryOne`:`chat.composer.menu.toolAccess.summary`,{enabled:String(i),total:String(n.length)}),o=e.toolsEffectiveLoading?H`<div class="agent-chat__capability-menu-state" role="status">
        ${L(`chat.composer.menu.toolAccess.loading`)}
      </div>`:e.toolsEffectiveError?H`<div class="agent-chat__capability-menu-state" role="alert">
          ${L(`chat.composer.menu.toolAccess.loadFailed`)}
        </div>`:r?H`<div class="agent-chat__capability-menu-state" role="status">
            ${me(r.message)}
          </div>`:n.length===0?H`<div class="agent-chat__capability-menu-state">
              ${L(`chat.composer.menu.toolAccess.noTools`)}
            </div>`:n.map((t,n)=>{let r=t.mcpToolName,i=t.label?.trim(),a=fM(e,t);return eM({value:`mcp-tool:${n}`,label:r,checked:!a,disabled:e.toolAccessMutationBlockedReason!==null,title:e.toolAccessMutationBlockedReason,note:i&&i!==r?H`<span class="agent-chat__capability-menu-note">${i}</span>`:G})});return H`
    ${$j()}
    <div class="agent-chat__capability-menu-state">
      <span class="agent-chat__capability-menu-label">
        <strong translate="no">${t}</strong>
        ${n.length>0?H`<span class="agent-chat__capability-menu-note">${a}</span>`:G}
      </span>
    </div>
    ${o}
  `}function mM(e,t){let n=e.detail.item.value??``;if(bt(t.attachments.uploadConfig)&&qj(e))return;let r=t.rootToggles?.find(e=>e.value===n);if(r){e.preventDefault(),r.disabled||r.onChange(!r.checked);return}let i=e.currentTarget,a=e=>{t.onViewChange(e),requestAnimationFrame(()=>i.querySelector(`wa-dropdown-item:not([disabled])`)?.focus())};if(n===`back`){e.preventDefault(),a(t.view.startsWith(`tools:`)?`connectors`:t.view.startsWith(`library:`)?`skills`:`root`);return}if(n===`open-skills`||n===`open-connectors`){e.preventDefault(),a(n===`open-skills`?`skills`:`connectors`);return}if(iM(n,t.library,a)){e.preventDefault();return}if(n===`toggle-web-search`){if(e.preventDefault(),t.mutationBlockedReason)return;if(!t.webSearchBaseEnabled){t.toolOverrides?.webSearch===!0&&t.onPatchToolOverrides(ds(t.toolOverrides,!1,t.webSearchBaseEnabled));return}let n=as(t.webSearchBaseEnabled,t.toolOverrides?.webSearch);t.onPatchToolOverrides(ds(t.toolOverrides,!n,t.webSearchBaseEnabled));return}if(n===`clear-overrides`){e.preventDefault(),t.mutationBlockedReason||t.onPatchToolOverrides(null);return}if(n.startsWith(`skill:`)){e.preventDefault();let r=t.skills?.[Number(n.slice(6))];r&&!r.missingDeps&&!r.blocked&&!t.mutationBlockedReason&&t.onPatchToolOverrides(ys(t.toolOverrides,`skills`,r.key,!r.enabled,r.baseEnabled));return}if(n.startsWith(`connector:`)){e.preventDefault();let r=t.mcpServers[Number(n.slice(10))];if(r&&!t.mutationBlockedReason){let e=Ur(r.enabled,zi(t.toolOverrides?.mcpServers,r.name));t.onPatchToolOverrides(ys(t.toolOverrides,`mcpServers`,r.name,!e,r.enabled))}return}if(n.startsWith(`tools:`)){e.preventDefault();let r=t.mcpServers[Number(n.slice(6))];r&&(t.onOpenToolAccess?.(r.name),a(`tools:${r.name}`));return}if(n.startsWith(`mcp-tool:`)&&t.view.startsWith(`tools:`)){if(e.preventDefault(),t.toolAccessMutationBlockedReason)return;let r=t.view.slice(6),i=uM(t.toolsEffectiveResult,r)[Number(n.slice(9))];i?.mcpToolName&&t.onPatchToolOverrides(Da(t.toolOverrides,r,i.mcpToolName,!fM(t,i)));return}if(n===`add-server`){t.onAddServer?.();return}n===`manage-skills`?t.onNavigate(`skills`):n===`manage-plugins`&&t.onNavigate(`plugins`)}function hM(e){let t=_a(e.toolOverrides)>0,n=e.showCapabilities?e.view:`root`,r=n===`skills`?cM(e):n===`connectors`?lM(e):n.startsWith(`tools:`)?pM(e,n.slice(6)):n.startsWith(`library:`)?rM(e.library,n.slice(8)):sM(e);return H`
    <wa-dropdown
      class="agent-chat__attach-menu agent-chat__capability-menu"
      placement="top-start"
      aria-label=${L(`chat.composer.addAttachment`)}
      .open=${e.open}
      @wa-select=${t=>mM(t,e)}
      @wa-show=${()=>{e.open||e.onOpenChange(!0),e.onLoadSkills()}}
      @wa-hide=${()=>{e.open&&e.onOpenChange(!1)}}
      data-view=${n}
    >
      ${Jj(e.disabled,t)} ${r}
    </wa-dropdown>
    ${e.addServerDialog??G} ${e.libraryDialog??G}
  `}function gM(e){let t=e.capabilityMenu;return!t&&!e.rootToggles?.length&&!bt(e.attachments.uploadConfig)?G:hM({...e,...t,showCapabilities:t!==void 0,basePath:t?.basePath??``,skills:t?.skills??null,skillsLoading:t?.skillsLoading??!1,skillsError:t?.skillsError??!1,mcpServers:t?.mcpServers??[],toolsEffectiveResult:t?.toolsEffectiveResult??null,toolsEffectiveLoading:t?.toolsEffectiveLoading??!1,toolsEffectiveError:t?.toolsEffectiveError??!1,toolAccessMutationBlockedReason:t?.toolAccessMutationBlockedReason??null,webSearchBaseEnabled:t?.webSearchBaseEnabled??!0,mutationBlockedReason:t?.mutationBlockedReason??null,canAdmin:t?.canAdmin??!1,adminBlockedReason:t?.adminBlockedReason??null,onLoadSkills:t?.onLoadSkills??(()=>{}),onPatchToolOverrides:t?.onPatchToolOverrides??(()=>{}),onNavigate:t?.onNavigate??(()=>{})})}var _M;function vM(){return(vM=e((()=>{K(),un(),B(),Is(),R(),Ci(),ft(),V(),Lc(),Le(),Zj(),aM(),tM(),ki(),_M=new Set([`mcp-not-yet-connected`,`mcp-not-yet-listed`,`mcp-stale-catalog`])})))()}function yM(){RM?.frame!=null&&cancelAnimationFrame(RM.frame),RM=void 0}function bM(){let e=RM;if(!e||e.velocity===0)return;let t=e.container.scrollTop;if(e.container.scrollTop+=e.velocity,e.container.scrollTop===t){yM();return}e.frame=requestAnimationFrame(bM)}function xM(e,t){let n=e.getBoundingClientRect(),r=Math.min(NM,Math.max(0,NM-(t-n.top))),i=Math.min(NM,Math.max(0,NM-(n.bottom-t))),a=(i>0?i:-r)/NM*PM;if(a===0){yM();return}if(RM?.container===e){RM.velocity=a,RM.frame??(RM.frame=requestAnimationFrame(bM));return}yM(),RM={container:e,velocity:a,frame:requestAnimationFrame(bM)}}function SM(e,t){e?.toggleAttribute(jM,t)}function CM(e){e.style.height=`auto`;let t=Number.parseFloat(getComputedStyle(e).maxHeight)||101;e.style.height=`${Math.min(e.scrollHeight,t)}px`,e.style.overflowY=e.scrollHeight>t?`auto`:`hidden`}function wM(e,t){e instanceof HTMLTextAreaElement&&!FM.has(e)&&(FM.add(e),e.value=t,queueMicrotask(()=>{e.isConnected&&(CM(e),e.focus(),e.setSelectionRange(t.length,t.length))}))}function TM(e,t){if(t&&e.sendState!==`failed`&&e.sendState!==`unconfirmed`&&e.sendState!==`held`)return L(`chat.queue.states.waitingForReconnect`);switch(e.sendState){case`waiting-model`:case`waiting-idle`:return null;case`executing-command`:return L(`chat.queue.states.runningCommand`);case`waiting-reconnect`:return L(`chat.queue.states.waitingForReconnect`);case`unconfirmed`:case`held`:return L(`chat.queue.states.needsReview`);case`failed`:return L(`common.failed`);default:return null}}function EM(e){let t=(e.displayQueue??e.queue).filter(e=>e.sendState!==`submitting`&&e.sendState!==`sending`&&!lu(e));if(e.editingSource&&e.editingId===e.editingSource.id&&!t.some(t=>t.id===e.editingId)&&t.push(e.editingSource),!t.length)return G;let n=new Set(t.map(e=>e.id)),r={segments:Di(e.queue,t=>n.has(t.id)&&bi(t)&&t.id!==e.editingId).map(e=>e.map(e=>e.id)),offered:t.filter(bi).length>1},i=e.queue.find(e=>e.sendState!==`failed`||e.localCommandName),a=(i?.sendState===`unconfirmed`||i?.sendState===`held`)&&lu(i)?{label:L(`chat.queue.states.blockedByUnconfirmed`),tone:`warn`}:t.some(e=>e.sendState===`waiting-model`)&&!e.offline?{label:L(`chat.queue.states.applyingSettings`),tone:`settings`}:null;return H`
    <div class="chat-queue" role="status" aria-live="polite">
      ${a?H`<div
              class="chat-queue__global-state"
              data-chat-queue-global-state=${a.tone}
            >
              ${a.label}
            </div>`:G}
      <div
        class="chat-queue__scroll"
        data-scrollable=${t.length>3?`true`:`false`}
        data-at-start="true"
        data-at-end=${t.length>3?`false`:`true`}
        @dragover=${e=>{if(!e.dataTransfer?.types.includes(kM))return;let t=e.currentTarget;t instanceof HTMLElement&&xM(t,e.clientY)}}
        @dragleave=${e=>{let t=e.currentTarget;t instanceof HTMLElement&&e.relatedTarget instanceof Node&&t.contains(e.relatedTarget)||yM()}}
        @drop=${yM}
        @scroll=${e=>{let t=e.currentTarget;t instanceof HTMLElement&&(t.dataset.atStart=String(t.scrollTop<=1),t.dataset.atEnd=String(t.scrollTop+t.clientHeight>=t.scrollHeight-1))}}
      >
        ${q(t,e=>e.id,t=>OM(t,e,r))}
      </div>
    </div>
  `}function DM(e,t){let n=e.currentTarget;n instanceof HTMLElement&&n.classList.toggle(AM,t)}function OM(e,t,n){let r=ym(e.sender),i=r!==G,a=e.sendState===`failed`||e.sendState===`unconfirmed`||e.sendState===`held`,o=!e.serverQueued&&!a&&(t.offline||e.sendState===`waiting-reconnect`),s=TM(e,!e.serverQueued&&t.offline===!0),c=e.queueMode===`steer`&&s===null,l=e.sendState===`executing-command`,u=t.editingId===e.id,d=u?t.editingText??e.text:e.text,f=u?t.editingMentions:e.mentions,p=!!(t.canAbort&&t.onQueueSteer)&&Ou(e)&&!u,m=!!(t.canAbort&&t.onQueueSteer)&&!u&&!e.localCommandName&&!e.intent&&(Ou(e)||e.sendState===`waiting-model`),h=n.segments.find(t=>t.includes(e.id))??[],g=h.indexOf(e.id),_=t.onQueueMove,v=!!_&&n.offered,y=v&&g>=0&&h.length>1,b=!!t.onQueueEdit&&bi(e)&&!e.localCommandName,x=b&&!t.editingId,S=e.text||(e.attachments?.length?L(`chat.queue.imageCount`,{count:String(e.attachments.length)}):``),C=LM;return H`
    <div
      class=${`chat-queue__item${i?``:` chat-queue__item--no-avatar`}${c?` chat-queue__item--steered`:``}${a?` chat-queue__item--failed`:``}${o?` chat-queue__item--reconnect`:``}${u?` chat-queue__item--editing`:``}`}
      data-chat-queue-item=${e.id}
      @click=${e=>{let t=e.currentTarget,n=e.target;t instanceof Element&&n instanceof Element&&(!x||n.closest(MM)?zM.delete(t):e.detail===1&&zM.add(t))}}
      @dblclick=${x?n=>{let r=n.currentTarget;r instanceof Element&&zM.has(r)&&(zM.delete(r),n.stopPropagation(),SM(r,!1),t.onQueueEdit?.(e.id))}:void 0}
      @dragover=${y?e=>{e.dataTransfer?.types.includes(kM)&&(e.preventDefault(),e.dataTransfer.dropEffect=`move`,DM(e,!0))}:void 0}
      @dragleave=${y?e=>DM(e,!1):void 0}
      @drop=${y?t=>{let n=t.dataTransfer?.getData(kM);DM(t,!1),n&&n!==e.id&&h.includes(n)&&(t.preventDefault(),_?.(n,e.id))}:void 0}
    >
      ${v?H`<button
              class="chat-queue__leading chat-queue__grip"
              type="button"
              draggable=${y?`true`:`false`}
              ?disabled=${!y}
              aria-label=${L(y?`chat.queue.reorderQueuedMessage`:`chat.queue.reorderUnavailable`)}
              aria-keyshortcuts=${Jn(y?`ArrowUp ArrowDown`:void 0)}
              @dragstart=${y?t=>{t.dataTransfer?.setData(kM,e.id),t.dataTransfer&&(t.dataTransfer.effectAllowed=`move`)}:void 0}
              @dragend=${yM}
              @keydown=${t=>{if(!y)return;let n=t.key===`ArrowUp`?-1:+(t.key===`ArrowDown`);if(n===0)return;t.preventDefault();let r=h[g+n];r&&_?.(e.id,r)}}
            >
              <span class="chat-queue__grip-state chat-queue__grip-state--idle" aria-hidden="true"
                >${C}</span
              >
              ${y?H`<span
                      class="chat-queue__grip-state chat-queue__grip-state--active"
                      aria-hidden="true"
                      >${z.gripVertical}</span
                    >`:G}
            </button>`:H`<span class="chat-queue__leading chat-queue__icon" aria-hidden="true"
              >${C}</span
            >`}
      ${r}
      ${u?H`<textarea
              class="chat-queue__edit-input"
              rows="1"
              ${U(n=>wM(n,t.editingText??e.text))}
              aria-label=${L(`chat.queue.editQueuedMessage`)}
              @beforeinput=${e=>{e.currentTarget instanceof HTMLTextAreaElement&&IM.set(e.currentTarget,{value:e.currentTarget.value,start:e.currentTarget.selectionStart,end:e.currentTarget.selectionEnd,inputType:e.inputType})}}
              @input=${e=>{if(e.currentTarget instanceof HTMLTextAreaElement){let n=e.currentTarget;CM(n),f?.length?t.onQueueEditChange?.(n.value,oo(d,n.value,f,IM.get(n))):t.onQueueEditChange?.(n.value),IM.delete(n)}}}
              @keydown=${e=>{e.isComposing||e.keyCode===229||(e.key===`Escape`?(e.preventDefault(),e.stopPropagation(),t.onQueueEditCancel?.()):e.key===`Enter`&&!e.shiftKey&&(e.preventDefault(),t.onQueueEditSubmit?.()))}}
            ></textarea>`:H`<span class="chat-queue__copy">
              <span class="chat-queue__text" title=${S}>${S}</span>
              ${c&&!p?H`<span class="chat-queue__badge chat-queue__badge--steered"
                      >${L(`chat.queue.steer`)}</span
                    >`:G}
              ${s&&(!a||!e.sendError)?H`<span
                      class=${a?`chat-queue__badge`:o?`chat-queue__badge chat-queue__badge--reconnect`:`chat-queue__state`}
                      title=${Jn(o?e.sendError:void 0)}
                      >${s}</span
                    >`:G}
            </span>`}
      <span class="chat-queue__actions">
        ${a&&!u&&t.onQueueRetry?H`
                <button
                  class="chat-queue__action chat-queue__retry"
                  type="button"
                  aria-label=${L(`chat.queue.retryQueuedMessage`)}
                  @click=${()=>t.onQueueRetry?.(e.id)}
                >
                  ${z.refresh}
                  <span>${L(`chat.queue.retry`)}</span>
                </button>
              `:G}
        ${m?H`
                <button
                  class="chat-queue__action chat-queue__steer"
                  type="button"
                  ?disabled=${!p}
                  aria-label=${L(`chat.queue.steerQueuedMessage`)}
                  @click=${()=>t.onQueueSteer?.(e.id)}
                >
                  ${z.arrowUp}
                  <span>${L(`chat.queue.steer`)}</span>
                </button>
              `:G}
        ${u?H`
                <button
                  class="chat-queue__edit-submit"
                  type="button"
                  aria-label=${L(`chat.runControls.sendMessage`)}
                  @click=${()=>t.onQueueEditSubmit?.()}
                >
                  ${z.check}
                </button>
                <button
                  class="chat-queue__edit-cancel"
                  type="button"
                  aria-label=${L(`chat.queue.cancelEdit`)}
                  @click=${()=>t.onQueueEditCancel?.()}
                >
                  ${z.x}
                </button>
              `:G}
        ${l||u?G:H`
                <openclaw-tooltip .content=${L(`chat.queue.removeQueuedMessage`)}>
                  <button
                    class="chat-queue__remove"
                    type="button"
                    ?disabled=${u||e.serverQueued&&!t.canRemoveServerQueued}
                    aria-label=${L(`chat.queue.removeQueuedMessage`)}
                    @click=${n=>{n.detail<=1&&t.onQueueRemove(e.id)}}
                    @dblclick=${e=>e.stopPropagation()}
                  >
                    ${z.trash}
                  </button>
                </openclaw-tooltip>
              `}
        ${u||!b?G:H`
                <wa-dropdown
                  class="chat-queue__overflow"
                  placement="top-end"
                  @wa-select=${n=>{let r=n.detail.item;if(r.value===`edit`&&x){let i=n.currentTarget;SM(i instanceof Element?i.closest(`.chat-queue__item`):null,r.matches(`:focus-visible`)),t.onQueueEdit?.(e.id)}}}
                >
                  <button
                    slot="trigger"
                    class="chat-queue__more"
                    type="button"
                    ?disabled=${!x}
                    aria-label=${L(`chat.queue.moreActions`)}
                    @dblclick=${e=>e.stopPropagation()}
                  >
                    ${z.moreHorizontal}
                  </button>
                  <wa-dropdown-item value="edit" ?disabled=${!x}>
                    <span slot="icon" aria-hidden="true">${z.pencil}</span>
                    ${L(`chat.queue.editQueuedMessage`)}
                  </wa-dropdown-item>
                </wa-dropdown>
              `}
      </span>
      ${f?.length?H`<span class="chat-queue__mentions">
              ${L(`chat.mentions.selected`,{names:f.map(({start:e,end:t})=>d.slice(e,t)).join(`, `)})}
              ${u?H`<button
                      class="chat-queue__remove"
                      type="button"
                      aria-label=${L(`chat.mentions.remove`)}
                      @click=${()=>t.onQueueEditChange?.(d,[])}
                    >
                      ${z.x}
                    </button>`:G}
            </span>`:G}
      ${e.sendError&&!o?H`<span class="chat-queue__error">
              ${a&&s?H`<span class="chat-queue__badge">${s}</span>`:G}
              <span class="chat-queue__error-text">${e.sendError}</span>
            </span>`:G}
    </div>
  `}var kM,AM,jM,MM,NM,PM,FM,IM,LM,RM,zM;function BM(){return(BM=e((()=>{K(),Un(),W(),ur(),Yt(),B(),R(),qr(),$u(),ld(),Sm(),kM=`application/x-openclaw-queued-message`,AM=`chat-queue__item--drop-target`,jM=`data-edit-keyboard-focus`,MM=`a, button, input, select, textarea, wa-dropdown, wa-dropdown-item`,NM=24,PM=12,FM=new WeakSet,IM=new WeakMap,LM=Ot(fr` <path d="M16 5H3" />
  <path d="M16 12H3" />
  <path d="M9 19H3" />
  <path d="m16 16-3 3 3 3" />
  <path d="M21 5v12a2 2 0 0 1-2 2h-6" />`),zM=new WeakSet})))()}function VM(e,t,n,r){if(!t?.length)return G;let i=[...new Map(t.map(e=>[e.profileId,e])).values()].map(t=>{let n=e.slice(t.start,t.end);return{profileId:t.profileId,label:n,name:n.replace(/^@/u,``)}});return H`<div class="chat-reply-preview composer-context-strip" role="status">
    <span class="composer-context-strip__label">
      <span class="composer-context-strip__icon" aria-hidden="true">${z.bell}</span>
      <span class="composer-context-strip__label-text">${L(`chat.mentions.selectedLabel`)}</span>
    </span>
    <span class="sr-only">${i.map(e=>e.name).join(`, `)}</span>
    <span
      class="composer-context-strip__people"
      aria-hidden="true"
      ${UM(JSON.stringify(i.map(e=>e.name)))}
    >
      ${i.map((e,t)=>H`<span class="composer-context-strip__person" title=${e.label}>
          ${ym({id:e.profileId,name:e.name,identity:{type:`profile`,id:e.profileId},profileAvatarUrl:r?.get(e.profileId)})}
          <bdi class="composer-context-strip__person-name"
            >${e.name}${t<i.length-1?`,`:``}</bdi
          >
        </span>`)}
      <span class="composer-context-strip__more" dir="ltr" hidden></span>
    </span>
    <button
      type="button"
      class="chat-reply-preview__dismiss composer-context-strip__dismiss"
      aria-label=${L(`chat.mentions.remove`)}
      @click=${n}
    >
      ${z.x}
    </button>
  </div>`}var HM,UM;function WM(){return(WM=e((()=>{K(),$n(),Hn(),B(),R(),Sm(),HM=class extends Wn{constructor(...e){super(...e),this.observer=typeof ResizeObserver>`u`?void 0:new ResizeObserver(()=>this.sync())}render(e){return G}update(e,[t]){let n=e.element instanceof HTMLElement?e.element:void 0;return this.element===n&&this.names===t?G:(this.element=n,this.names=t,this.schedule(),G)}schedule(){queueMicrotask(()=>{this.isConnected&&this.element?.isConnected&&(this.observer?.observe(this.element),this.sync(),document.fonts?.status===`loading`&&document.fonts.ready.then(()=>this.sync()))})}sync(){let e=this.element;if(!this.isConnected||!e?.isConnected)return;let t=[...e.querySelectorAll(`.composer-context-strip__person`)],n=e.querySelector(`.composer-context-strip__more`);if(!t.length||!n)return;for(let e of t)e.hidden=!1,e.style.maxWidth=``;n.hidden=!1,n.textContent=`+${t.length-1}`;let r=Number.parseFloat(getComputedStyle(e).columnGap),i=t.map(e=>e.getBoundingClientRect().width),a=e.clientWidth,o=n.getBoundingClientRect().width,s=t.length;if(i.reduce((e,t)=>e+t,0)+r*(t.length-1)>a){s=1;let e=i[0];for(;s<t.length&&e+r+i[s]+r+o<=a;)e+=r+i[s],s+=1}t.forEach((e,t)=>{e.hidden=t>=s}),n.hidden=s===t.length,n.textContent=`+${t.length-s}`,n.title=t.slice(s).map(e=>e.title).join(`, `),t[0].style.maxWidth=`${Math.max(0,a-(n.hidden?0:o+r))}px`}disconnected(){this.observer?.disconnect()}reconnected(){this.schedule()}},UM=Kn(HM)})))()}function GM(e){if(e?.phase!==`interrupted`||Date.now()-e.occurredAt>=5e3)return G;let t=L(`chat.composer.runInterrupted`);return H`
    <span
      class="agent-chat__run-status agent-chat__run-status--interrupted"
      aria-label=${L(`chat.composer.runStatus`,{status:t})}
    >
      ${z.square}<span class="agent-chat__run-status-label">${t}</span>
    </span>
  `}function KM(e){if(!e)return G;let t=e.phase??`active`;if(Date.now()-e.occurredAt>=qM)return G;let n=[L(`chat.composer.fallbackSelected`,{model:e.selected}),L(`chat.composer.fallbackCurrent`,{model:t===`cleared`?e.selected:e.active}),t===`cleared`&&e.previous?L(`chat.composer.fallbackPrevious`,{model:e.previous}):null,e.reason?L(`chat.composer.fallbackReason`,{reason:e.reason}):null,e.attempts.length>0?L(`chat.composer.fallbackAttempts`,{attempts:e.attempts.slice(0,3).join(` | `)}):null].filter(Boolean).join(` • `),r=t===`cleared`?L(`chat.composer.fallbackCleared`,{model:e.selected}):L(`chat.composer.fallbackActive`,{model:e.active}),i=t===`cleared`?`compaction-indicator compaction-indicator--fallback-cleared`:`compaction-indicator compaction-indicator--fallback`,a=t===`cleared`?z.check:z.brain;return H`
    <openclaw-tooltip .content=${n}>
      <div class=${i} role="status" aria-live="polite" aria-label=${n}>
        ${a} ${r}
      </div>
    </openclaw-tooltip>
  `}var qM;function JM(){return(JM=e((()=>{K(),B(),R(),Nd(),qM=8e3})))()}function YM(e){let{props:t,state:n,canCompose:r,showAbortableUi:i,activeSession:a,visibleDraft:s,contextNotice:c,composerControls:l,composerLeadControl:u,runStatusAnnouncement:d,composerRunStatus:f,requestUpdate:p,sendShortcut:m,questionPanelProps:h,showComposer:g,placeholder:_,handleKeyDown:v,handleBeforeInput:y,handleInput:b,handleSelect:x,draftKey:S,handleCompositionEnd:C,handleBlur:w,dictation:T,runControlsProps:E,mirrorCameraPreview:D,slashMenuVisible:O,skillMenuVisible:k,mentionMenuVisible:ee,menuVisible:te,mentionMenuHost:ne,mentionError:re,skillMenuHost:ie,slashMenuHost:ae,activeSlashMenuOptionId:oe,activeSlashMenuOptionLabel:A,slashMenuListboxId:j,slashMenuAnnouncementId:M,goalComposer:se}=e,ce=t.disabledBanner?H`
        <div
          class="agent-chat__disabled-banner ${t.disabledBanner.kind===`composer-replacement`?`agent-chat__disabled-banner--replacement`:``} callout ${t.disabledBanner.tone===`neutral`?`agent-chat__disabled-banner--neutral`:`info`} callout--action"
          role="status"
        >
          ${t.disabledBanner.icon?H`<span
                  class="agent-chat__disabled-banner-icon agent-chat__disabled-banner-icon--${t.disabledBanner.icon}"
                  aria-hidden="true"
                  >${t.disabledBanner.icon===`archive`?z.archive:z.alertTriangle}</span
                >`:G}
          <div class="callout__content">
            ${t.disabledBanner.title?H`<div class="agent-chat__disabled-banner-title">
                    ${t.disabledBanner.title}
                  </div>`:G}
            <div class="agent-chat__disabled-banner-detail">${t.disabledBanner.text}</div>
          </div>
          ${t.disabledBanner.onAction?H`<button
                  type="button"
                  class="btn btn--sm ${t.disabledBanner.actionStyle??``}"
                  ?disabled=${!!t.disabledBanner.disabledReason||t.disabledBanner.busy}
                  aria-busy=${t.disabledBanner.busy?`true`:`false`}
                  title=${t.disabledBanner.disabledReason??G}
                  @click=${t.disabledBanner.onAction}
                >
                  ${t.disabledBanner.busy?H`<span class="btn__spinner" aria-hidden="true"></span>${t.disabledBanner.busyLabel??t.disabledBanner.actionLabel}`:t.disabledBanner.actionLabel}
                </button>`:G}
          ${t.disabledBanner.kind===`composer-replacement`&&i?Tj(E):G}
        </div>
      `:G,le=g&&t.disabledBanner?.kind!==`composer-replacement`;t.capabilityMenu||(n.capabilityMenuView=`root`);let ue=xx(t.paneId,`disabled-reason`),de=le?H`
        ${mj({status:t.realtimeTalkCameraError?`error`:t.realtimeTalkStatus,detail:t.realtimeTalkDetail,onUseSystemDefaultMicrophone:t.onUseSystemDefaultMicrophone,onDismissError:t.realtimeTalkCameraError?void 0:t.onDismissRealtimeTalkError})}
        ${t.realtimeTalkInputNotice?mj({status:`error`,detail:t.realtimeTalkInputNotice,onDismissError:t.onDismissRealtimeTalkInputNotice}):G}
      `:G,N=t.offline&&t.queuedOutboxCount?L(`chat.composer.offlineQueuedHint`,{count:String(t.queuedOutboxCount)}):null,fe=t.disabledReason?{text:t.disabledReason,tone:t.disabledReasonTone??`danger`,icon:t.disabledReasonBusy?H`<span class="btn__spinner" aria-hidden="true"></span>`:(t.disabledReasonTone??`danger`)===`danger`?z.alertTriangle:z.shieldQuestion}:re?{text:re,tone:`danger`,icon:z.alertTriangle}:n.dictationError?{text:n.dictationError,tone:`danger`,icon:z.alertTriangle}:N?{text:N,tone:`info`,icon:z.inbox}:null,pe=le&&fe?H`<div class="agent-chat__composer-status" data-tone=${fe.tone}>
          <div
            id=${t.disabledReason?ue:G}
            class="agent-chat__composer-status-band"
            role=${fe.tone===`danger`?`alert`:`status`}
            aria-live="polite"
            aria-busy=${t.disabledReasonBusy?`true`:`false`}
          >
            <span class="agent-chat__composer-status-icon" aria-hidden="true"
              >${fe.icon}</span
            >
            <span class="agent-chat__composer-status-text">${fe.text}</span>
          </div>
        </div>`:G,me=T?.active?RA(n.dictationSelection?.value??s,T.transcript,n.dictationSelection?.start??s.length,n.dictationSelection?.end??s.length).value:s,he=ra(me),ge=t.runError?G:GM(f),_e=KM(t.fallbackStatus),ve=t.progressCard?H`<div class="agent-chat__progress-float" ?hidden=${!g}>
        ${sc(t.progressCard,`composer`,t.onDismissProgressCard,a?.status,a?.startedAt,a?.endedAt,t.runActive,t.collapseTaskProgress,{presented:g,gatewayScope:t.gatewayScope,sessionIdentity:t.progressCardIdentity,cardLifetime:t.progressCardLifetime,readingHistory:t.readingHistory,onManipulate:t.onProgressManipulate},t.connected&&t.canSend?t.progressCardRefresh:void 0)}
      </div>`:t.progressCardInitialLoading?H`<div
          class="agent-chat__progress-float agent-chat__progress-float--loading"
          ?hidden=${!g}
          aria-hidden="true"
        ></div>`:G,ye=EM({queue:t.queue,displayQueue:t.displayQueue,offline:t.offline,canAbort:i,canRemoveServerQueued:t.connected&&t.canSend&&!t.submitDisabledReason,onQueueRetry:t.connected&&t.canSend&&!t.submitDisabledReason?t.onQueueRetry:void 0,onQueueSteer:t.connected&&t.canSend&&!t.submitDisabledReason?t.onQueueSteer:void 0,onQueueMove:t.onQueueMove,onQueueEdit:t.queuedEdit?.onEdit,onQueueEditChange:t.queuedEdit?.onEditChange,onQueueEditSubmit:t.queuedEdit?.onEditSubmit,onQueueEditCancel:t.queuedEdit?.onCancel,editingId:t.queuedEdit?.editingId??null,editingText:t.queuedEdit?.editingText,editingMentions:t.queuedEdit?.editingMentions,editingSource:t.queuedEdit?.source,onQueueRemove:t.onQueueRemove}),be=a?.goal?H`<div class="agent-chat__goal-float">
        ${zT(n,a.goal,{canAct:t.connected&&t.canSend&&!t.submitDisabledReason&&!!t.currentSessionId&&!t.goalRecovery,onGoalAction:t.onGoalAction,onGoalEdit:t.onGoalSubmit?e=>se.begin(e):void 0,requestUpdate:p})}
      </div>`:G;return H`
    <div class="agent-chat__composer-shell">
      <div class="chat-footer__context">
        ${t.footerContent??G}
        <div class="agent-chat__composer-notices">
          ${t.notices??G} ${pe} ${de} ${_e}
          ${ge===G?G:H`<div class="agent-chat__composer-run-status">${ge}</div>`}
        </div>
        ${Fj(h)}
        ${t.disabledBanner?.kind===`above-composer`?ce:G}
        ${ve} ${ye} ${VT(t.goalRecovery,t.connected)}
        ${be}
      </div>
      ${le?H`<div
              class="agent-chat__input agent-chat__input--chat agent-chat__input--mobile-toolbar ${t.offline?`agent-chat__input--offline`:``}${T?.active?` agent-chat__input--dictating`:``}"
              aria-busy=${t.disabledReasonBusy?`true`:`false`}
              @wa-show=${LD}
              @wa-after-show=${zD}
              @openclaw-composer-dismiss-invocations=${()=>{jE(n),uE(n),n.mentionMenu.close(),n.emojiMenu.dismiss(n.composerTextarea),p()}}
              @click=${e=>vx(e,r)}
              @pointerdown=${e=>{RD(e),vx(e,r)}}
              ${U(n.composerInputRef??void 0)}
            >
              ${O?qE(n,ae,s,p):G}
              ${k?bE(n,ie,p):G}
              ${n.emojiMenu.render(t.paneId,n.composerTextarea,p)}
              ${ee?n.mentionMenu.render(ne,p):G}
              <div class="agent-chat__composer-lede">
                ${se.render()}
                ${VM(s,t.mentions,()=>{tD(t,t.getDraft?.()??t.draft,[]),p()},n.mentionMenu.selectedAvatarUrls)}
                ${t.replyTarget?H`
                        <div class="chat-reply-preview composer-context-strip">
                          <span class="chat-reply-preview__label composer-context-strip__label">
                            <span class="chat-reply-preview__icon composer-context-strip__icon"
                              >${z.messageSquare}</span
                            >
                            <span class="composer-context-strip__label-text"
                              >${L(`chat.messages.replyingTo`,{name:t.replyTarget.senderLabel??L(`chat.messages.message`)})}</span
                            >
                          </span>
                          <span class="chat-reply-preview__text composer-context-strip__text"
                            >${o(t.replyTarget.text,120)}${t.replyTarget.text.length>120?`...`:``}</span
                          >
                          <button
                            type="button"
                            class="chat-reply-preview__dismiss composer-context-strip__dismiss"
                            @click=${()=>t.onClearReply?.()}
                            aria-label=${L(`chat.composer.cancelReply`)}
                            title=${L(`chat.composer.cancelReply`)}
                          >
                            ${z.x}
                          </button>
                        </div>
                      `:G}
                ${CT(t)}
                ${ST(t.getPendingAttachmentReads?.()??t.pendingAttachmentReads??0)}
                ${wj(T)}
                ${Kj({...t,disabled:!r,cameraActive:g&&t.cameraActive!==!1})}
                ${t.realtimeTalkVideoStream?H`
                        <div class="agent-chat__video-preview">
                          <video
                            class=${D?`agent-chat__video-preview-mirrored`:G}
                            autoplay
                            .muted=${!0}
                            playsinline
                            aria-label=${L(`chat.composer.cameraPreview`)}
                            .srcObject=${or(t.realtimeTalkVideoStream)}
                          ></video>
                          ${t.realtimeTalkCameraDevices&&t.realtimeTalkCameraDevices.length>=2&&t.onSwitchRealtimeCamera?H`
                                  <openclaw-tooltip
                                    class="agent-chat__video-preview-switch-tooltip"
                                    .content=${L(`chat.composer.switchCamera`)}
                                  >
                                    <button
                                      type="button"
                                      class="agent-chat__video-preview-switch"
                                      aria-label=${L(`chat.composer.switchCamera`)}
                                      ?disabled=${t.realtimeTalkVideoPending}
                                      @click=${t.onSwitchRealtimeCamera}
                                    >
                                      ${z.switchCamera}
                                    </button>
                                  </openclaw-tooltip>
                                `:G}
                        </div>
                      `:G}
              </div>

              <div class="agent-chat__composer-input-row">
                <div class="agent-chat__composer-combobox">
                  <textarea
                    ${U(n.textareaRef??void 0)}
                    .value=${Qn([me],()=>or(me))}
                    dir=${he}
                    ?disabled=${!r}
                    ?readonly=${T?.locksComposer===!0||se.pending}
                    aria-autocomplete="list"
                    aria-controls=${Jn(te?j:void 0)}
                    aria-haspopup=${Jn(te?`listbox`:void 0)}
                    aria-activedescendant=${Jn(oe??void 0)}
                    aria-describedby=${`${M}${t.disabledReason?` ${ue}`:``}`}
                    aria-keyshortcuts=${m===`enter`?`Enter`:`Control+Enter Meta+Enter`}
                    @keydown=${v}
                    @beforeinput=${y}
                    @input=${b}
                    @select=${x}
                    @focus=${x}
                    @pointerup=${x}
                    @keyup=${e=>{n.emojiMenu.handleKeyup(e),(e.key.startsWith(`Arrow`)||e.key===`Home`||e.key===`End`)&&x(e)}}
                    @compositionstart=${e=>{let t=n.emojiMenu.open;n.mentionMenu.close(),n.emojiMenu.close(),n.editRevision+=1,n.composerComposing=!0,n.composingDraft={key:S,value:e.target.value},t&&p()}}
                    @compositionend=${C}
                    @blur=${w}
                    @paste=${e=>{r&&!t.suggestionComposer&&_T(e,t)}}
                    aria-label=${L(`chat.composer.composerInput`)}
                    placeholder=${T?.active?``:_}
                    rows="1"
                  ></textarea>
                  <span class="agent-chat__composer-placeholder" aria-hidden="true"
                    >${T?.active?``:_}</span
                  >
                  <span
                    id=${M}
                    class="sr-only"
                    role="status"
                    aria-live="polite"
                    aria-atomic="true"
                    >${A}</span
                  >
                  <span
                    class="agent-chat__run-status-announcement sr-only"
                    role="status"
                    aria-live="polite"
                    aria-atomic="true"
                    >${d}</span
                  >
                </div>
              </div>

              <div class="agent-chat__composer-footer">
                <div class="agent-chat__composer-lead agent-chat__composer-meta">
                  ${gM({attachments:t,capabilityMenu:t.capabilityMenu,disabled:!r||t.suggestionComposer===!0,open:n.capabilityMenuOpen,view:n.capabilityMenuView,toolOverrides:t.toolOverrides,onOpenChange:e=>{n.capabilityMenuOpen=e,e||(n.capabilityMenuView=`root`),p()},onViewChange:e=>{n.capabilityMenuView=e,p()}})}
                  ${u}
                </div>
                <div class="agent-chat__composer-trail">
                  <div class="agent-chat__composer-meta agent-chat__composer-context">
                    ${c}
                  </div>
                  ${l===G?G:H` <div class="agent-chat__composer-controls">${l}</div> `}
                  <div class="agent-chat__composer-actions">
                    ${Ej(E)}
                  </div>
                </div>
              </div>
            </div> `:t.disabledBanner?.kind===`composer-replacement`?ce:G}
    </div>
  `}function XM(){return(XM=e((()=>{K(),pr(),Un(),tr(),W(),B(),Oc(),R(),ua(),qA(),Zj(),OT(),Dj(),Ex(),WT(),vM(),Lj(),BM(),WM(),SE(),JE(),uD(),JM(),qD(),yj()})))()}function ZM(e,t){let n=e.currentTarget;if(!(n instanceof HTMLElement)||!n.hasAttribute(`open`)||!/^[1-5]$/u.test(e.key))return;let r=n.querySelector(`[data-chat-permission-shortcut="${e.key}"]`);if(!r||r.hasAttribute(`disabled`))return;let i=$M(r.dataset.chatPermissionOption);i!==void 0&&(e.preventDefault(),e.stopPropagation(),t(i),n.removeAttribute(`open`),n.querySelector(`[slot=trigger]`)?.focus())}function QM(e,t){return e?L(`chat.permissionControls.modes.${e}.label`):t?L(`chat.permissionControls.defaultWithMode`,{mode:L(`chat.permissionControls.modes.${t}.label`)}):L(`chat.permissionControls.default`)}function $M(e){return e===rN?null:nN.find(t=>t===e)}function eN(e){let t=e.disabled||e.pending,n=(e.mode??e.defaultMode)===`full`,r=QM(e.mode,e.defaultMode),i=n=>{t||n===`full`&&!e.canSelectFull||n!==(e.mode??null)&&e.onSelect(n)};return H`
    <wa-dropdown
      class="chat-controls__inline-select chat-controls__permission-picker"
      placement="top-start"
      @wa-after-show=${zD}
      @keydown=${e=>ZM(e,i)}
      @wa-select=${e=>{let t=$M(e.detail.item.value);t!==void 0&&i(t)}}
    >
      <button
        slot="trigger"
        type="button"
        class="chat-controls__inline-select-trigger chat-controls__permission-trigger ${e.disabled?`chat-controls__inline-select-trigger--disabled`:``} ${e.mode?``:`chat-controls__permission-trigger--default`} ${n?`chat-controls__permission-trigger--full`:``}"
        data-chat-permission-select="true"
        data-chat-select-value=${e.mode??``}
        aria-label=${`${L(`chat.permissionControls.label`)}: ${r}`}
        aria-disabled=${t?`true`:`false`}
        title=${e.disabledReason??L(`chat.permissionControls.help`)}
        ?disabled=${t}
      >
        <span class="chat-controls__permission-icon" aria-hidden="true"
          >${e.mode?aN[e.mode]:z.shieldCheck}</span
        >
        <span
          class="chat-controls__inline-select-label ${n?`chat-controls__permission-label--full`:``}"
        >
          ${r}
        </span>
      </button>
      <wa-dropdown-item
        class="chat-controls__popover-title chat-controls__permission-heading"
        href=${tN}
        target=${hs}
        rel=${wa()}
      >
        <span>${L(`chat.permissionControls.label`)}</span>
        <span slot="details" class="chat-controls__permission-learn-more learn-more-link"
          >${L(`common.learnMore`)}</span
        >
      </wa-dropdown-item>
      ${iN.map((n,r)=>{let i=n??rN,a=(e.mode??null)===n,o=n===`full`&&!e.canSelectFull;return H`
          <wa-dropdown-item
            class="chat-controls__permission-option ${a?`chat-controls__permission-option--selected`:``}"
            value=${i}
            data-chat-permission-option=${i}
            data-chat-permission-shortcut=${String(r+1)}
            role="menuitemradio"
            aria-checked=${a?`true`:`false`}
            aria-label=${o?`${QM(n,e.defaultMode)}. ${L(`chat.permissionControls.fullRequiresAdmin`)}`:QM(n,e.defaultMode)}
            title=${o?L(`chat.permissionControls.fullRequiresAdmin`):G}
            ?disabled=${t||o}
          >
            <span slot="icon" class="chat-controls__permission-option-icon" aria-hidden="true"
              >${n?aN[n]:z.shieldCheck}</span
            >
            <span class="chat-controls__permission-option-copy">
              <span class="chat-controls__permission-option-title">
                <span>${QM(n,e.defaultMode)}</span>
              </span>
              <span class="chat-controls__permission-option-description">
                ${L(n?`chat.permissionControls.modes.${n}.description`:`chat.permissionControls.defaultDescription`)}
              </span>
            </span>
            <span slot="details" class="chat-controls__permission-option-state" aria-hidden="true">
              ${a||o?G:H`<span class="chat-controls__permission-shortcut">${r+1}</span>`}
              ${o?H`<span class="chat-controls__permission-lock">${z.lock}</span>`:G}
              ${a&&!o?H`<span class="chat-controls__inline-select-check">${z.check}</span>`:G}
            </span>
          </wa-dropdown-item>
        `})}
    </wa-dropdown>
  `}var tN,nN,rN,iN,aN;function oN(){return(oN=e((()=>{K(),B(),R(),Oi(),cs(),qD(),Xr(),tN=`https://docs.openclaw.ai/gateway/permission-modes`,nN=[`read-only`,`guarded`,`workspace`,`full`],rN=`default`,iN=[null,...nN],aN={"read-only":z.shieldEllipsis,guarded:z.shieldLock,workspace:z.shieldCog,full:z.shieldAlert}})))()}function sN(e){let t=XE(e.paneId);t.slashCommandDispatchConnected=e.connected;let n=e.canCompose??e.canSend,r=e.sending||e.stream!==null,i=!!(e.canAbort&&e.onAbort)&&!ZE(e.runStatus),a=e.queue.find(t=>QE(t,e.sessionKey,e.runStatus)),o=e.queue.some(e=>!e.pendingRunId&&(e.sendState===`submitting`||e.sendState===`sending`||e.sendState===`waiting-model`)),s=e.sending&&(!o||a!==void 0),c=$E(e),l=s||c?{phase:`in-progress`}:e.runStatus,u=eD(e);t.composerDraftScopeKey!==null&&t.composerDraftScopeKey!==u&&(t.emojiMenu.close(),t.dictation?.dispose(),t.dictation=null,t.dictationSelection=null),t.composerDraftScopeKey=u;let d=t.composingDraft?.key===u?t.composingDraft.value:e.draft;t.composerInputRef??=e=>{t.composerInput=ux(t.composerInput,e)},t.textareaRef??=e=>{let n=e instanceof HTMLTextAreaElement?e:null,r=t.composerTextarea;r&&r!==n&&gx(r),t.composerTextarea=n,n&&(hx(n),_x(n),t.restoreComposerFocus&&(t.restoreComposerFocus=!1,queueMicrotask(()=>t.composerTextarea?.focus({preventScroll:!0}))))},t.composerTextarea?.isConnected&&t.composerTextarea.value!==d&&_x(t.composerTextarea);let f=(e.attachments??[]).some(e=>!$g(e)),p=aj(e.selectedSession,e.sessions?.defaults?.contextTokens??null,{messages:e.messages,providerUsage:e.providerUsage}),m=e.composerControls??G,h=e.permissionPicker?eN(e.permissionPicker):G,g=e.assistantName||`OpenClaw`,_=e.waitingApproval?L(`chat.waitingForApproval`):a?.sendState===`waiting-model`?L(`chat.composer.preparingModel`):e.stream===null?s||a?L(`chat.composer.sendingMessage`):L(`chat.composer.working`,{name:g}):L(`chat.composer.responding`,{name:g}),v=l==null?``:l.phase===`in-progress`?_:l.phase===`done`?L(`chat.composer.runDone`):L(`chat.composer.runInterrupted`),y=e.onRequestUpdate??(()=>{}),b=Oj(e,t,y),x=e.mentionsUnsupported||b.active;t.mentionMenu.syncDirectory(e.connected&&n&&!x?e.mentionDirectory:void 0);let S=()=>e.getMentions?.()??e.mentions??[],C=S().length>0&&(x||d.trimStart().startsWith(`/`))?L(`chat.mentions.unsupported`):null,w=(t,n)=>{tD(e,t,n),e.onTypingChange?.(!!t.trim(),t)},T={paneId:e.paneId,getDraft:()=>t.composerTextarea?.value??e.getDraft?.()??e.draft,commitDraft:w,getTextarea:()=>t.composerTextarea,refreshCommands:e.onSlashIntent},E={...T,resolveArgOptions:t=>Mj(t,e),runCommand:b.submitCommand,canRun:(n,r,i=``)=>e.canSend&&t.slashCommandDispatchConnected&&!(n&&!e.onSlashCommand)&&(!e.modelRequiredReason||Vo(r?`/${r.name} ${i}`:T.getDraft()))&&(!e.submitDisabledReason||To(r?`/${r.name} ${i}`:T.getDraft())),runInlineCommand:e.connected?e.onSlashCommand:void 0,activateComposerMode:b.activateCommand},D={paneId:e.paneId,getDraft:T.getDraft,getMentions:S,getTextarea:T.getTextarea,commitDraft:w},O=zn(e.sendShortcut),k=e.connected&&O===`enter`&&i&&!e.suggestionComposer&&e.followUpMode!==void 0&&e.followUpMode!==`interrupt`?e.followUpMode===`steer`?`queue`:`steer`:void 0,ee=Ij(e,t,y),te=!(!ee||ee.model.nonBlocking||t.questionCollapsed);!t.questionTakeoverActive&&te&&(t.composingDraft?.key===u&&(tD(e,t.composingDraft.value),t.composingDraft=null),t.composerComposing=!1),t.questionTakeoverActive&&!te&&(t.restoreComposerFocus=!0),t.questionTakeoverActive=te;let ne=!te,re=b.active?L(`chat.goals.objectivePlaceholder`):f?L(`chat.composer.placeholderWithAttachments`):L(`chat.composer.placeholder`,{name:e.assistantName||`agent`}),ie=n=>e.canSend&&(!e.modelRequiredReason||!b.active&&(e.getAttachments?.()??e.attachments??[]).length===0&&Vo(n))&&(!e.submitDisabledReason||!b.active&&ea(n))&&!(S().length>0&&(x||n.trimStart().startsWith(`/`)))&&!b.pending&&t.dictation?.locksComposer!==!0&&!(t.skillMenuOpen&&t.skillCommandRefreshPending)&&(e.getPendingAttachmentReads?.()??e.pendingAttachmentReads??0)===0&&(e.connected||!n.trimStart().startsWith(`/`)),ae=ie(d),oe=n=>{t.emojiMenu.close(),t.mentionMenu.close();let r=n?.value??e.getDraft?.()??e.draft,i=e.getDraft?.()??e.draft;i===``&&r!==``&&n?.value===r?t.pendingClearedSubmittedDraft={key:u,value:r}:iD(t,u),n&&n.value!==i&&(n.value=i,mx(n))},A=Aj({state:t,props:e,skillMenuHost:T,slashMenuHost:E,mentionMenuHost:D,requestUpdate:y,sendShortcut:O,canSubmitDraft:ie,commitDraft:t=>tD(e,t),syncDraftAfterSend:oe,showAbortableUi:i,alternateFollowUpMode:k,goalComposer:b}),j=(n,r=!1)=>{mx(n,{nativeInput:!0}),n.dir=ra(n.value);let i=S();if(tD(e,n.value,i.length?oo(e.getDraft?.()??e.draft,n.value,i,t.mentionInput):void 0),t.mentionInput=void 0,b.activateDraft(n.value),!b.active){FE(n.value,t,E,y),pE(n.value,n.selectionStart,t,T,y);let e=r?`trigger`:`input`;t.mentionMenu.update(n,y,e)}t.emojiMenu.update(n,y,!t.composerComposing&&!t.skillMenuOpen&&!t.slashMenuOpen&&!t.mentionMenu.open),(!!n.value.trim()!=!!d.trim()||ie(n.value)!==ae)&&y()},M=r=>{let i=r.target;i instanceof HTMLTextAreaElement&&(t.mentionInput={value:i.value,start:i.selectionStart,end:i.selectionEnd,inputType:r.inputType},!t.composerComposing&&!r.isComposing&&(nD(t,eD(e)),t.emojiMenu.complete(r,y,n)))},se=n=>{let r=n.target,i=rD(t,u);if(t.composerComposing||n.isComposing){t.composingDraft={key:u,value:r.value},y();return}if(t.composingDraft?.key===u&&(t.composingDraft=null),oD(r,n,e.getDraft?.()??e.draft,i,t))return;let a=n.inputType===`insertText`&&n.data?.includes(`@`)===!0;(n.inputType===`insertFromPaste`||n.inputType===`insertFromDrop`)&&t.mentionMenu.close(),j(r,a),e.onTypingChange?.(!!r.value.trim(),r.value)},ce=e=>{let n=e.target;t.emojiMenu.update(n,y,!t.composerComposing&&!t.skillMenuOpen&&!t.slashMenuOpen&&!t.mentionMenu.open),!b.active&&(t.mentionMenu.update(n,y),e.type!==`keyup`&&(FE(n.value,t,E,y),pE(n.value,n.selectionStart,t,T,y)))},le=n=>{t.composerComposing=!1,t.composingDraft?.key===u&&(t.composingDraft=null),j(n.target);let r=n.target.value;e.onTypingChange?.(!!r.trim(),r)},ue=n=>{let r=t.emojiMenu.open;t.emojiMenu.close(),r&&y();let i=n.target;if(t.composerComposing=!1,t.composingDraft?.key===u&&(t.composingDraft=null),!t.dictation?.locksComposer){let t=Ef(i.value);i.value!==t&&(i.value=t,mx(i)),tD(e,t)}e.onTypingChange?.(!1)},de=n=>{let r=t.composerTextarea?.value??e.draft;if(ie(r)&&(t.composerComposing=!1,t.composingDraft=null,tD(e,r),e.onTypingChange?.(!1),!b.activateDraft(r,!0))){if(b.active){b.submit(n);return}e.onSend(void 0,n),oe(t.composerTextarea)}};t.microphonePicker??=new JA(y);let N=t.microphonePicker;N.syncCatalog(e.gatewayClient??null,e.connected);let fe=()=>{if(N.realtimeStatus!==`ready`){N.handleOpen();return}e.submitDisabledReason||e.onToggleRealtimeTalk?.()},pe=()=>{if(e.realtimeTalkActive){e.onToggleRealtimeTalk?.();return}if((t.composerTextarea?.value??d).trim()||e.attachments?.length){de();return}fe()},me=e.realtimeTalkInputDeviceId?.trim()??``,he=e.onToggleRealtimeTalk?xj({devices:N.devices,loading:N.loading,open:N.open,selectedDeviceId:me,voiceActive:!!e.realtimeTalkActive,issue:N.issue,holdToDictate:e.composerHoldToRecord!==!1,realtimeStatus:N.realtimeStatus,dictationStatus:N.dictationStatus,onOpen:N.handleOpen,onClose:N.handleClose,onSelect:e=>{Qt({realtimeTalkInputDeviceId:e.trim()||void 0}),N.handleClose()},onHoldToDictateChange:t=>{e.onComposerHoldToRecordChange?e.onComposerHoldToRecordChange(t):Qt({composerHoldToRecord:t}),y()},onOpenTalkSettings:e.onOpenTalkSettings,onOpenDictationSettings:e.onOpenDictationSettings}):G,ge={client:e.gatewayClient??null,connected:e.connected,enabled:e.composerHoldToRecord!==!1,dictationAvailable:N.dictationStatus===`ready`,realtimeTalkActive:e.realtimeTalkActive===!0,onCommit:(n,r)=>{let i=t.composerTextarea,a=t.dictationSelection,o=i?.value??e.getDraft?.()??e.draft,s=a&&(!r||a.value===o)?a:{start:i?.selectionStart??o.length,end:i?.selectionEnd??o.length,value:o},c=RA(s.value,n,s.start,s.end);i&&(i.value=c.value,mx(i)),tD(e,c.value),t.dictationSelection=null,y(),queueMicrotask(()=>{let e=t.composerTextarea;e&&(e.focus({preventScroll:!0}),e.selectionStart=c.caret,e.selectionEnd=c.caret)})},onError:(e,n)=>{let r=n.kind===`interrupted`&&n.preservesText?L(`chat.composer.dictationInterruptedRecovery`):L(`chat.composer.dictationStartRecovery`);t.dictationError=`${e} ${r}`,y()},onStateChange:()=>{t.dictation?.locksComposer&&(t.editRevision+=1,e.onDismissRealtimeTalkError?.()),y()},onDictationUnavailable:N.handleOpen,onTap:d.trim()||e.attachments?.length?fe:pe};t.dictation??=new KA(ge),t.dictation.update(ge);let _e=e.onToggleRealtimeTalk&&e.composerHoldToRecord!==!1?t.dictation:void 0,ve={canAbort:i,canSend:ie(d),submitDisabledReason:e.submitDisabledReason,submitPending:e.submitPending,connected:e.connected,draft:d,hasAttachments:!e.suggestionComposer&&!!e.attachments?.length,preparingAttachments:(e.getPendingAttachmentReads?.()??e.pendingAttachmentReads??0)>0,isBusy:r,followUpMode:e.followUpMode,alternateFollowUpMode:k,suggestionComposer:e.suggestionComposer,submissionLabel:b.submissionLabel,sending:e.sending,voiceActive:e.realtimeTalkActive,voiceStatus:e.realtimeTalkStatus,voiceDetail:e.realtimeTalkDetail,voiceInputLevel:e.realtimeTalkInputLevel,voiceVideoCapable:e.realtimeTalkVideoCapable,voiceVideoEnabled:!!e.realtimeTalkVideoStream,voiceVideoPending:e.realtimeTalkVideoPending,onAbort:e.onAbort,onSend:de,onToggleVoice:e.onToggleRealtimeTalk?pe:void 0,onToggleCamera:e.onToggleRealtimeCamera,microphonePicker:he,dictation:_e,onDictationPointerDown:e=>{t.dictationError&&(t.dictationError=null,y());let n=t.composerTextarea,r={start:n?.selectionStart??d.length,end:n?.selectionEnd??d.length,value:n?.value??d};_e?.handlePointerDown(e)&&(t.dictationSelection=r,n&&(n.readOnly=!0))},onPrimaryActionPointerDown:e=>yx(e,t.composerTextarea)},ye=e.realtimeTalkVideoStream?.getVideoTracks?.()[0]?.getSettings?.().facingMode!==`environment`;e.modelSwitching&&t.slashMenuCommand?.key===`think`&&jE(t),(!n||t.composerComposing||t.dictation?.locksComposer||b.pending)&&t.emojiMenu.close();let be=e.connected&&n;!(be&&hE(t))&&t.skillMenuOpen&&!t.skillCommandRefreshPending&&uE(t);let{slashMenuVisible:xe,skillMenuVisible:Se,mentionMenuVisible:Ce,menuVisible:we,activeMenuOptionId:Te,activeMenuOptionLabel:Ee,menuListboxId:De}=Nj(e.paneId,be,t,t,t.mentionMenu,t.emojiMenu),P=xx(e.paneId,`slash-active-announcement`);return YM({props:e,state:t,canCompose:n,showAbortableUi:i,activeSession:e.selectedSession,visibleDraft:d,contextNotice:p,composerControls:m,composerLeadControl:h,runStatusAnnouncement:v,composerRunStatus:l,requestUpdate:y,sendShortcut:O,questionPanelProps:ee,showComposer:ne,placeholder:re,handleKeyDown:A,handleBeforeInput:M,handleInput:se,handleSelect:ce,draftKey:u,handleCompositionEnd:le,handleBlur:ue,dictation:_e,runControlsProps:ve,mirrorCameraPreview:ye,slashMenuVisible:xe,skillMenuVisible:Se,mentionMenuVisible:Ce,menuVisible:we,mentionMenuHost:D,mentionError:C,skillMenuHost:T,slashMenuHost:E,activeSlashMenuOptionId:Te,activeSlashMenuOptionLabel:Ee,slashMenuListboxId:De,slashMenuAnnouncementId:P,goalComposer:b})}function cN(){return(cN=e((()=>{K(),hn(),V(),R(),ii(),ya(),qr(),ua(),qA(),YA(),lj(),Dj(),Ex(),kj(),jj(),Pj(),Lj(),SE(),JE(),uD(),XM(),n_(),oN(),gi()})))()}function lN(e){let{gatewayUrl:t,sessionKey:n}=e,r;try{r=new URL(t)}catch{return{ok:!1,reason:`unavailable`}}if(r.hash)return{ok:!1,reason:`unavailable`};if((r.protocol===`ws:`||r.protocol===`wss:`)&&r.search)return{ok:!1,reason:`query-routed`};let i=n;if(!Ue(n)){let t=e.rowAgentId||e.selectedAgentId;if(!t)return{ok:!1,reason:`unavailable`};i=`agent:${t}:${n}`}try{return{ok:!0,command:`openclaw resume --handoff ${pd({sessionKey:i,gatewayUrl:t})}`,qualifiedSessionKey:i}}catch{return{ok:!1,reason:`unavailable`}}}function uN(){return(uN=e((()=>{Cd(),it()})))()}var dN,fN,$;function pN(){return(pN=e((()=>{K(),ar(),qs(),fc(),B(),Qs(),Hs(),al(),R(),tt(),Uk(),dN={},fN={"compact:open-layout":`layout`,"compact:open-panels":`panels`,"compact:open-sharing":`sharing`,"compact:open-view":`view`},$=class extends gt{constructor(...e){super(...e),this.session=zc,this.worktreePath=null,this.onboarding=!1,this.preferencesBrowserOnly=!1,this.compact=!1,this.navigationAllowed=!1,this.copyMarkdownAllowed=!1,this.splitAllowed=!1,this.settings=dN,this.panelActions=[],this.layoutActions=[],this.sharing=null,this.groups=[],this.currentOwner=null,this.actionDisabledReasons={},this.forkDisabled=!1,this.forkFromLastCompleted=!1,this.archiveAllowed=!1,this.archiveShortcut=!1,this.deleteAllowed=!1,this.onOpen=()=>{},this.onOpenCommandPalette=()=>{},this.onSettingsChange=()=>{},this.onAction=()=>{},this.compactView=`root`,this.managementActions=new vc(this,()=>({session:this.session,selectionCount:1,compact:this.compact,navigationAllowed:this.navigationAllowed,copyMarkdownAllowed:this.copyMarkdownAllowed,splitAllowed:this.splitAllowed,renderOpenInExtra:e=>this.renderTerminalAction(e),disabled:!1,actionDisabledReasons:this.actionDisabledReasons,forkDisabled:this.forkDisabled,forkFromLastCompleted:this.forkFromLastCompleted,archiveAllowed:this.archiveAllowed,archiveShortcut:this.archiveShortcut,deleteAllowed:this.deleteAllowed,groups:this.groups,currentOwner:this.currentOwner,worktreePath:this.worktreePath}),e=>this.onAction(e),()=>{let e=this.querySelector(`wa-dropdown`);e&&(e.open=!1)}),this.handleSelect=e=>{let t=e.detail.item.value;if(!t)return;if(t.startsWith(`board-widget:`)){this.boardWidgetMenu?.onSelect(t.slice(13));return}let n=Qc(t)??fN[t];if(n){e.preventDefault(),this.compactView=n,n===`root`||n===`open-in`||n===`copy`||n===`assign-owner`||n===`icon`||n===`group`?this.managementActions.prepareCompactView(n):n===`sharing`&&!this.sharing?.openDisabledReason&&this.sharing?.onOpen(),this.managementActions.focusCurrentView();return}if(t===`open-command-palette`){this.onOpenCommandPalette();return}if(t.startsWith(`quick:`)){let[,e,n]=t.split(`:`),r=(e===`panels`?this.panelActions:this.layoutActions).find(e=>e.id===n);r&&r.kind!==`status`&&!r.disabled&&r.onActivate();return}if(t.startsWith(`view:`)){if(e.preventDefault(),this.onboarding)return;let n=t.slice(5);n===`reasoning`?this.onSettingsChange({chatShowThinking:!this.settings.chatShowThinking}):n===`tool-calls`?this.onSettingsChange({chatShowToolCalls:!this.settings.chatShowToolCalls}):n===`commentary`&&this.onSettingsChange({chatPersistCommentary:this.settings.chatPersistCommentary===!1});return}if(t.startsWith(`visibility:`)||t.startsWith(`member:`)||t.startsWith(`public:`)){this.sharing&&Rk(this.sharing,t);return}if(this.managementActions.handleSelect(t)){e.preventDefault();return}t===`continue-in-terminal`&&!this.actionDisabledReasons[t]&&(e.currentTarget.open=!1,this.onAction({kind:t}))},this.handleShow=()=>{this.compactView=`root`,this.managementActions.loadOwners(),this.onOpen()},this.handleAfterHide=()=>{this.compactView=`root`}}renderQuickActionItems(e,t,n=!1){return t.map(t=>{let r=H`<span class="session-menu__text"
        >${t.label}${t.description?H`<span class="session-menu__description">${t.description}</span>`:G}</span
      >`;if(t.kind===`status`)return H`<div
          slot=${n?G:`submenu`}
          class="session-menu__status"
          data-menu-status=${t.id}
          role="note"
        >
          <span class="session-menu__check" aria-hidden="true">${t.icon}</span>
          ${r}
        </div>`;let i=typeof t.badge==`number`&&t.badge>0?H`<span slot="details" class="session-menu__sub">${t.badge}</span>`:G;return H`
        <wa-dropdown-item
          slot=${n?G:`submenu`}
          class="session-menu__item"
          value=${`quick:${e}:${t.id}`}
          type=${t.active===void 0?G:`checkbox`}
          .checked=${t.active??!1}
          ?disabled=${t.disabled}
        >
          <span slot="icon" class="session-menu__icon" aria-hidden="true">${t.icon}</span>
          ${r} ${i}
        </wa-dropdown-item>
      `})}renderQuickActions(e,t){if(t.length===0)return G;let n=L(e===`panels`?`chat.sessionHeader.panels`:`chat.sessionHeader.layout`),r=e===`panels`?z.panelRightOpen:z.columns2;return this.compact?bl({value:`compact:open-${e}`,label:n,icon:r}):H`
      <wa-dropdown-item class="session-menu__item">
        <span slot="icon" class="session-menu__icon" aria-hidden="true">${r}</span>
        <span class="session-menu__text">${n}</span>
        ${this.renderQuickActionItems(e,t)}
      </wa-dropdown-item>
    `}renderViewSubmenu(e=!1){let t=!this.onboarding&&this.settings.chatShowThinking,n=this.onboarding?!0:this.settings.chatShowToolCalls,r=this.settings.chatPersistCommentary!==!1,i=this.onboarding?L(`chat.onboardingDisabled`):G,a=(t,n,r)=>H`
      <wa-dropdown-item
        slot=${e?G:`submenu`}
        class="session-menu__item"
        type="checkbox"
        value=${`view:${t}`}
        .checked=${r}
        ?disabled=${this.onboarding}
        title=${i}
      >
        <span class="session-menu__text">${n}</span>
      </wa-dropdown-item>
    `;return H`
      ${a(`reasoning`,L(`chat.view.reasoning`),t)}
      ${a(`tool-calls`,L(`chat.view.toolCalls`),n)}
      ${a(`commentary`,L(`chat.view.commentary`),r)}
      ${this.preferencesBrowserOnly?H`<div slot=${e?G:`submenu`} class="session-menu__info" role="note">
              ${L(`quickSettings.personal.browserOnly`)}
            </div>`:G}
    `}renderCompactView(){if(this.compactView===`root`||this.compactView===`open-in`||this.compactView===`copy`||this.compactView===`assign-owner`||this.compactView===`icon`||this.compactView===`group`)return this.managementActions.renderCompactView(this.compactView);let e=H`${this.compactView===`panels`?this.renderQuickActionItems(`panels`,this.panelActions,!0):this.compactView===`layout`?this.renderQuickActionItems(`layout`,this.layoutActions,!0):this.compactView===`sharing`&&this.sharing?Vk(this.sharing,!0):this.renderViewSubmenu(!0)}`;return jl(e)}renderRootView(){return H`
      ${this.compact?H`<wa-dropdown-item class="session-menu__item" value="open-command-palette">
                <span slot="icon" class="session-menu__icon" aria-hidden="true"
                  >${z.search}</span
                >
                <span class="session-menu__text">${L(`chat.openCommandPalette`)}</span>
              </wa-dropdown-item>
              <div class="session-menu__separator" role="separator"></div>`:G}
      ${this.boardWidgetMenu?H`
              <div class="board-widget__page-menu-heading">
                <strong
                  >${this.boardWidgetMenu.widget.title||this.boardWidgetMenu.widget.name}</strong
                >
              </div>
              ${jc(this.boardWidgetMenu.widget,`details`)}
              ${this.boardWidgetMenu.canMutate?bc({widget:this.boardWidgetMenu.widget,tabs:this.boardWidgetMenu.tabs,disabled:!1,prefix:`board-widget:`}):G}
              <div class="session-menu__separator" role="separator"></div>
            `:G}
      ${this.renderQuickActions(`panels`,this.panelActions)}
      ${this.renderQuickActions(`layout`,this.layoutActions)}
      ${this.compact&&this.sharing?.session&&zk(this.sharing.session)?bl({value:`compact:open-sharing`,label:L(`chat.sessionSharing.menu`),icon:z.users,disabled:!!this.sharing.openDisabledReason}):G}
      ${this.compact?bl({value:`compact:open-view`,label:L(`chat.view.menu`),icon:z.eye}):H`<wa-dropdown-item class="session-menu__item">
              <span slot="icon" class="session-menu__icon" aria-hidden="true">${z.eye}</span>
              <span class="session-menu__text">${L(`chat.view.menu`)}</span>
              ${this.renderViewSubmenu()}
            </wa-dropdown-item>`}
      <div class="session-menu__separator" role="separator"></div>
      ${this.managementActions.renderPrimaryActions()}
      <div class="session-menu__separator" role="separator"></div>
      ${this.managementActions.renderOrganizationActions()}
      <div class="session-menu__separator" role="separator"></div>
      ${this.managementActions.renderTransferActions()}
      <div class="session-menu__separator" role="separator"></div>
      ${this.managementActions.renderDeleteAction()}
    `}renderTerminalAction(e){return H`<wa-dropdown-item
      slot=${e?G:`submenu`}
      class="session-menu__item"
      value="continue-in-terminal"
      ?disabled=${!!this.actionDisabledReasons[`continue-in-terminal`]}
      title=${this.actionDisabledReasons[`continue-in-terminal`]??G}
    >
      <span slot="icon" class="session-menu__icon" aria-hidden="true">${z.terminal}</span>
      <span class="session-menu__text">${L(`chat.sessionHeader.continueInTerminal.action`)}</span>
    </wa-dropdown-item>`}render(){let e=L(`chat.sidebar.sessionMenu`,{session:this.session.label});return H`
      <wa-dropdown
        class=${`session-menu chat-header-session-menu${this.compact?` chat-header-session-menu--compact`:``}${this.compact&&this.compactView===`sharing`?` chat-header-session-menu--compact-sharing`:``}`}
        placement="bottom-end"
        aria-label=${e}
        @keydown=${e=>{this.managementActions.handleKeydown(e)||Tc(this,e)}}
        @wa-show=${this.handleShow}
        @wa-after-hide=${this.handleAfterHide}
        @wa-select=${this.handleSelect}
      >
        <button
          slot="trigger"
          class="btn btn--ghost btn--icon chat-icon-btn chat-header-session-menu__trigger"
          type="button"
          aria-label=${e}
          aria-haspopup="menu"
        >
          ${z.moreHorizontal}
        </button>
        ${this.compact&&this.compactView!==`root`?this.renderCompactView():this.renderRootView()}
      </wa-dropdown>
    `}},k([X({attribute:!1})],$.prototype,`session`,void 0),k([X({attribute:!1})],$.prototype,`worktreePath`,void 0),k([X({attribute:!1})],$.prototype,`onboarding`,void 0),k([X({attribute:!1})],$.prototype,`preferencesBrowserOnly`,void 0),k([X({attribute:!1})],$.prototype,`compact`,void 0),k([X({attribute:!1})],$.prototype,`navigationAllowed`,void 0),k([X({attribute:!1})],$.prototype,`copyMarkdownAllowed`,void 0),k([X({attribute:!1})],$.prototype,`splitAllowed`,void 0),k([X({attribute:!1})],$.prototype,`settings`,void 0),k([X({attribute:!1})],$.prototype,`panelActions`,void 0),k([X({attribute:!1})],$.prototype,`layoutActions`,void 0),k([X({attribute:!1})],$.prototype,`boardWidgetMenu`,void 0),k([X({attribute:!1})],$.prototype,`sharing`,void 0),k([X({attribute:!1})],$.prototype,`groups`,void 0),k([X({attribute:!1})],$.prototype,`currentOwner`,void 0),k([X({attribute:!1})],$.prototype,`actionDisabledReasons`,void 0),k([X({attribute:!1})],$.prototype,`forkDisabled`,void 0),k([X({attribute:!1})],$.prototype,`forkFromLastCompleted`,void 0),k([X({attribute:!1})],$.prototype,`archiveAllowed`,void 0),k([X({attribute:!1})],$.prototype,`archiveShortcut`,void 0),k([X({attribute:!1})],$.prototype,`deleteAllowed`,void 0),k([X({attribute:!1})],$.prototype,`onOpen`,void 0),k([X({attribute:!1})],$.prototype,`onOpenCommandPalette`,void 0),k([X({attribute:!1})],$.prototype,`onSettingsChange`,void 0),k([X({attribute:!1})],$.prototype,`onAction`,void 0),k([J()],$.prototype,`compactView`,void 0),customElements.get(`openclaw-chat-header-session-menu`)||customElements.define(`openclaw-chat-header-session-menu`,$)})))()}function mN(e){let t=e.session,n=t?.placement,r=n?.state,i=nu(t);if(!t||!Dr(r)&&!i)return G;let a=t.placementMove,o=n&&n.state!==`local`&&n.state!==`requested`?n:void 0,s=o?.providerId,c=o?.profileId,l=o?.environmentId,u=!!(s||c||l),d=n?.state===`active`?n.runner:void 0,f=d?.kind===`device`&&d.status===`offline`,p=(n?.state===`active`||n?.state===`draining`)&&n.workspaceResultReconciling===!0,m=n?.state===`failed`&&n.recoveryAction===`restart`,h=qc(n),g=bu(t,e.placementStartupStatus),_=a?.target.kind===`gateway`?L(`sessionsView.moveSessionGatewayTarget`):a?.target.kind===`profile`?a.target.profileId:a?.target.kind===`device`?a.target.deviceId:void 0,v=a?.error?L(`sessionsView.moveSessionFailed`):a&&_?L(`sessionsView.movingSession`,{target:_}):e.placementRestarting?L(t.repositoryWorkspaceId&&r!==`failed`?`sessionsView.dispatchingSession`:`sessionsView.restartingSession`):e.placementMoving?L(`sessionsView.movingSessionGeneric`):f?L(`sessionsView.deviceOffline`):p||r===`draining`||r===`reconciling`?L(`sessionsView.syncingCloudFiles`):i?L(`sessionsView.repositoryWorkerRequiredLabel`):g.label,y=e.placementMoveDisabledReason,b=e.placementReclaimDisabledReason,x=e.placementRecoveryDisabledReason,S=ge(n?.stateChangedAtMs,{fallback:``}),C=a?.error?a.error:i||r===`active`||u?G:`${r}${S?` · ${S}`:``}`;return H`
    <div class="chat-pane__placement-control">
      <wa-dropdown class="chat-pane__placement-menu" placement="bottom-start">
        <button slot="trigger" class="chat-pane__placement-chip" type="button">${v}</button>
        ${C===G?G:H`<div class="chat-pane__placement-state">${C}</div>`}
        ${u?H`<dl class="chat-pane__placement-facts">
                ${s?H`<dt>${L(`sessionsView.placementFactService`)}</dt>
                        <dd>${s}</dd>`:G}
                ${c?H`<dt>${L(`sessionsView.placementFactProfile`)}</dt>
                        <dd>${c}</dd>`:G}
                ${l?H`<dt>${L(`sessionsView.placementFactMachine`)}</dt>
                        <dd>…${l.slice(-6)}</dd>`:G}
                <dt>${L(`sessionsView.placementFactState`)}</dt>
                <dd>${r}${S?` · ${S}`:``}</dd>
                ${n?.state===`active`&&n.diskSpace?H`<dt>${L(`sessionsView.placementFactDisk`)}</dt>
                        <dd>
                          ${L(`sessionsView.placementDiskFree`,{free:ve(n.diskSpace.availableBytes)})}
                        </dd>`:G}
              </dl>`:G}
        ${[[r===`active`,`chat-pane__placement-move ${f?`session-menu__item--destructive`:``}`,f,y,z.monitor,f?`sessionsView.continueOnGatewayMenu`:`sessionsView.moveSession`,e.onPlacementMove],[i||m,`chat-pane__placement-recovery`,!1,x,z.monitor,i?`sessionsView.chooseWorker`:`sessionsView.restartSession`,e.onPlacementRecover],[h,`session-menu__item--destructive chat-pane__placement-reclaim`,!0,b,z.stop,null,e.onPlacementReclaim]].map(([e,t,n,r,i,a,o])=>e?H`<wa-dropdown-item
                class=${`session-menu__item ${t}`}
                variant=${n?`danger`:G}
                ?disabled=${!!r}
                title=${r??G}
                @click=${()=>!r&&o?.()}
              >
                <span slot="icon" class="session-menu__icon" aria-hidden="true">${i}</span>
                <span class="session-menu__text">${a?L(a):g.stopLabel}</span>
              </wa-dropdown-item>`:G)}
      </wa-dropdown>
      ${f?H`<div class="chat-pane__placement-note" role="status">
              ${L(`sessionsView.waitingForDevice`)}
            </div>`:p?H`<div class="chat-pane__placement-note" role="status">
                ${L(`sessionsView.syncingCloudFilesDetail`)}
              </div>`:n&&(n.state===`draining`||n.state===`reconciling`)?H`<div class="chat-pane__placement-note" role="status">
                  ${L(`sessionsView.syncingCloudFilesDetail`)} ·
                  <openclaw-elapsed-time
                    .startMs=${n.stateChangedAtMs}
                  ></openclaw-elapsed-time>
                </div>`:G}
    </div>
  `}function hN(){return(hN=e((()=>{K(),pc(),Xl(),B(),gc(),R(),xe(),we(),vu()})))()}function gN(e){let t=L(`chat.sessionHeader.continueInTerminal.title`),n=L(`chat.sessionHeader.continueInTerminal.description`);return H`
    <openclaw-modal-dialog
      class="continue-in-terminal-dialog"
      label=${t}
      description=${n}
      @modal-cancel=${e.onClose}
    >
      <section class="exec-approval-card continue-in-terminal-dialog__card">
        <header class="continue-in-terminal-dialog__header">
          <h2>${t}</h2>
          <p>${n}</p>
        </header>
        ${Gs(e.command)}
        <p class="continue-in-terminal-dialog__note">
          ${L(`chat.sessionHeader.continueInTerminal.authNote`)}
        </p>
        <footer class="exec-approval-actions">
          <button type="button" class="btn primary" @click=${e.onClose}>
            ${L(`common.close`)}
          </button>
        </footer>
      </section>
    </openclaw-modal-dialog>
  `}function _N(){return(_N=e((()=>{K(),ml(),Ft(),R()})))()}function vN(e,t){let n=Array.from(e.querySelectorAll(`.chat-bubble`)).find(e=>t.entryId?e.dataset.entryId===t.entryId:!!t.messageId&&e.dataset.messageId===t.messageId);if(!n)return null;let r=n.ownerDocument.createTreeWalker(n,NodeFilter.SHOW_TEXT),i=[];for(;r.nextNode();)r.currentNode instanceof Text&&i.push(r.currentNode);let a=n.ownerDocument.createRange(),o=0,s=!1,c=!1;for(let e of i){let n=o+e.length;if(!s&&t.start>=o&&t.start<=n&&(a.setStart(e,t.start-o),s=!0),s&&t.end>=o&&t.end<=n){a.setEnd(e,t.end-o),c=!0;break}o=n}return!c||a.toString().replace(/\s/gu,``)!==t.text.replace(/\s/gu,``)?null:{bubble:n,range:a,nodes:i}}function yN(e){let t=Array.from(e.range.getClientRects()).findLast(e=>e.width&&e.height);if(!t)return null;let n=t.right,r=e.bubble.ownerDocument.createRange();for(let i of e.nodes)if(i.textContent?.trim()){r.selectNodeContents(i);for(let e of r.getClientRects())Math.abs(e.top-t.top)<Math.min(e.height,t.height)/2&&(n=Math.max(n,e.right))}return{right:n,top:t.top,height:t.height}}function bN(){return(bN=e((()=>{})))()}function xN(e,t){return e.filter(e=>!!(e.selectionAnnotation&&je(e.selectionAnnotation.sessionKey,t)))}var SN;function CN(){return(CN=e((()=>{K(),ar(),V(),it(),tt(),cu(),OT(),Fk(),cO(),SN=class extends lt{constructor(...e){super(...e),this.sessionKey=``,this.paneId=``,this.presented=!0,this.root=null,this.retireEditor=()=>{this.editorOwner?.abort(),this.editorOwner=void 0,this.editingId=void 0,this.editorAnchor=void 0,this.positionEditor=void 0,this.editorObserver?.disconnect(),this.focusFrame!==void 0&&(cancelAnimationFrame(this.focusFrame),this.focusFrame=void 0)},this.handleCommentAction=e=>{if(!(e instanceof CustomEvent)||!this.canChange(this.props.readSignal))return;if(e.detail?.action===`delete-all`){e.stopPropagation(),this.clearComments();return}let t=xN(this.currentAttachments(),this.sessionKey).find(t=>t.id===e.detail?.id);if(t){if(e.stopPropagation(),e.detail.action===`delete`){let n=e.target instanceof HTMLElement?e.target.closest(`.chat-comment-preview--editable`):null;this.deleteComment(t.id,n)}else if(e.detail.action===`edit`&&e.target instanceof HTMLElement){let n=e.target.closest(`openclaw-tooltip`)?.querySelector(`.chat-selection-annotations__trigger`);this.editComment(t,this.visiblePin(t.id)??n??e.target)}}},this.syncEditorAnchor=()=>{!this.editorAnchor?.isConnected||this.editorAnchor.hidden?this.retireEditor():this.positionEditor?.()}}connectedCallback(){super.connectedCallback(),this.requestUpdate(`props`)}currentAttachments(){return this.props.getAttachments?.()??this.props.attachments??[]}willUpdate(e){let t=e.get(`props`);e.has(`props`)&&t?.readSignal!==this.props.readSignal&&(t?.readSignal?.removeEventListener(`abort`,this.retireEditor),this.props.readSignal?.addEventListener(`abort`,this.retireEditor,{once:!0}),this.retireEditor()),(e.has(`sessionKey`)||!this.presented||this.props.disabled||this.editingId&&!xN(this.currentAttachments(),this.sessionKey).some(e=>e.id===this.editingId))&&this.retireEditor()}updated(){this.root||(this.root=this.closest(`.chat-session-rail`)??this.closest(`.chat`),this.root?.addEventListener(`openclaw-comment-action`,this.handleCommentAction))}disconnectedCallback(){this.root?.removeEventListener(`openclaw-comment-action`,this.handleCommentAction),this.root=null,this.retireEditor(),this.props.readSignal?.removeEventListener(`abort`,this.retireEditor),super.disconnectedCallback()}canChange(e){return this.isConnected&&this.presented&&!this.props.disabled&&!e?.aborted&&this.props.readSignal===e&&!!this.props.onAttachmentsChange}changeAttachments(e,t){return this.props.onAttachmentsChange?.(t)===!1?(_u(t,[e]),!1):(_u(e,[t]),this.props.onRequestUpdate?.(),!0)}visiblePin(e){return Array.from(this.root?.querySelectorAll(`.chat-comment-pin`)??[]).find(t=>{if(t.dataset.attachmentId!==e||t.hidden)return!1;let n=t.getBoundingClientRect(),r=t.closest(`.chat-thread`)?.getBoundingClientRect();return n.width>0&&n.height>0&&r&&n.top>=Math.max(r.top,0)&&n.bottom<=Math.min(r.bottom,window.innerHeight)&&n.left>=Math.max(r.left,0)&&n.right<=Math.min(r.right,window.innerWidth)})}focusComposer(){this.root?.querySelector(`openclaw-plugin-view[data-plugin-composer], .agent-chat__composer-combobox > textarea`)?.focus({preventScroll:!0})}clearComments(){this.retireEditor();let e=xN(this.currentAttachments(),this.sessionKey);if(e.length===0)return;let t=new Set(e.map(e=>e.id)),n=this.currentAttachments();this.changeAttachments(n,n.filter(e=>!t.has(e.id))),this.focusComposer()}deleteComment(e,t=null){this.retireEditor();let n=this.props.readSignal,r=this.sessionKey,i=xN(this.currentAttachments(),r),a=i.findIndex(t=>t.id===e),o=i[a+1]??i[a-1],s=this.currentAttachments();if(this.changeAttachments(s,s.filter(t=>t.id!==e)),!t||!o){this.focusComposer();return}this.focusFrame=requestAnimationFrame(()=>{this.focusFrame=void 0,this.canChange(n)&&this.sessionKey===r&&t.isConnected&&t.hasAttribute(`open`)&&t.querySelector(`[data-comment-delete="${CSS.escape(o.id)}"]`)?.focus({preventScroll:!0})})}editComment(e,t){let n=this.props.readSignal;this.canChange(n)&&(this.retireEditor(),this.editorOwner=new AbortController,this.editingId=e.id,this.editorAnchor=t,this.positionEditor=iO({paneId:this.paneId,anchorRect:t.getBoundingClientRect(),anchorElement:t,sourceRange:this.root?vN(this.root,e.selectionAnnotation)?.range:void 0,comment:e.selectionAnnotation.comment,expanded:!0,readSignal:this.editorOwner.signal,onSave:r=>{if(!this.canChange(n))return!0;let i=this.currentAttachments(),a=i.find(t=>t.id===e.id);if(!a?.selectionAnnotation)return!0;let o=Pk({...a.selectionAnnotation,comment:r},this.props,dT(this.props,i.filter(t=>t.id!==e.id)));return!o||!this.changeAttachments(i,i.map(t=>t.id===e.id?o:t))?!1:(this.retireEditor(),this.focusFrame=requestAnimationFrame(()=>{if(this.focusFrame=void 0,this.canChange(n)){let e=this.visiblePin(o.id)??(t.isConnected?t:null);e?It(e):this.focusComposer()}}),!0)},onDelete:()=>{this.canChange(n)&&this.deleteComment(e.id)},onCancel:()=>{this.retireEditor(),It(t)}}),this.root&&(this.editorObserver??=new MutationObserver(this.syncEditorAnchor),this.editorObserver.observe(this.root,{childList:!0,subtree:!0,attributes:!0})))}render(){return G}},k([X({attribute:!1})],SN.prototype,`props`,void 0),k([X()],SN.prototype,`sessionKey`,void 0),k([X()],SN.prototype,`paneId`,void 0),k([X({type:Boolean})],SN.prototype,`presented`,void 0),customElements.define(`openclaw-chat-comment-controller`,SN)})))()}function wN(e){if(e.suggestions.length===0)return G;let t=e.canResolve&&(e.role===`owner`||e.role===`admin`);return H`
    <div class="session-suggestions" aria-live="polite">
      ${e.suggestions.map(n=>{let r=e.busyIds.has(n.id),i=n.author.label??n.author.id;return H`
          <article class="session-suggestion" data-suggestion-id=${n.id}>
            <span class="session-suggestion__author">${i}</span>
            <span class="session-suggestion__text">${n.text}</span>
            ${t&&n.state===`pending`?H`
                    <div class="session-suggestion__actions">
                      ${[[`send`,`sendNow`,z.arrowUp],[`queue`,`queue`,z.check],[`edit`,`edit`,z.edit],[`dismiss`,`dismiss`,z.trash]].map(([t,a,o])=>e.archived&&t!==`dismiss`?G:H`
                              <button
                                class="btn btn--ghost btn--icon session-suggestion__action"
                                type="button"
                                ?disabled=${r}
                                aria-label=${L(`chat.sessionSuggestions.${a}`,{author:i})}
                                title=${L(`chat.sessionSuggestions.${a}`,{author:i})}
                                @click=${()=>e.onResolve(n,t)}
                              >
                                ${o}
                              </button>
                            `)}
                    </div>
                  `:H`<span class="session-suggestion__state"
                    >${L(`chat.sessionSuggestions.state.${n.state}`)}</span
                  >`}
          </article>
        `})}
    </div>
  `}function TN(){return(TN=e((()=>{K(),B(),R()})))()}function EN(e,t){if(t===`queued`)return`—`;let n=e.runtimeMs;if(n!=null&&t===`running`&&e.runtimeSampledAt!=null)n+=Math.max(0,Date.now()-e.runtimeSampledAt);else if(n==null&&e.startedAt!=null){let r=e.endedAt??(t===`running`?Date.now():void 0);r!=null&&(n=Math.max(0,r-e.startedAt))}return si(n)??`—`}function DN(e,t){let n=new Map,r=new Map(t.map(e=>[e.groupId,new Map((e.children??[]).map(e=>[e.sessionKey,e.status]))]));for(let t of e){let e=t.swarmGroupId?.trim(),i=e?r.get(e)?.get(t.key):void 0;if(!i||!e)continue;let a=n.get(e)??[];a.push({phaseRank:t.swarmPhaseRank??2**53-1,dot:{key:t.key,label:ye(t.key,t,{includeSubagentPrefix:!1}),status:i,duration:EN(t,i)}}),n.set(e,a)}return new Map([...n].map(([e,t])=>[e,t.toSorted((e,t)=>e.phaseRank-t.phaseRank).map(e=>e.dot)]))}function ON({sessions:e,sessionKey:t,agentId:n}){let r=e.find(e=>je(e.key,t)&&(t!==`global`&&t!==`unknown`||!!(n&&e.agentId===n))),i=r?.swarm;if(!i?.groups.length)return G;let a=r?x(r):!1,o=DN(e,i.groups);return H` <aside
    class="chat-swarm"
    data-test-id="chat-swarm"
    role="status"
    aria-live="off"
    aria-label=${L(`labsPage.swarm.title`)}
  >
    ${q(i.groups,e=>e.groupId,e=>{let t=o.get(e.groupId)??[],n=e.queued+e.running+e.done+e.failed,r=e.done+e.failed,i=r===n,s=i&&n>0&&e.failed===0,c=n===1&&t[0]?t[0].label:L(`labsPage.swarm.groupTitle`),l=L(i?`labsPage.swarm.finished`:`labsPage.swarm.active`,{running:String(e.running),queued:String(e.queued),done:String(e.done),failed:String(e.failed)}),u=[`running`,`queued`,`failed`,`done`].flatMap(t=>Array.from({length:Math.min(e[t],64)},()=>t)).slice(0,64);return H` <details
          class="chat-swarm__group ${e.failed>0?`chat-swarm__group--failed`:``} ${s?`chat-swarm__group--completed`:``}"
          data-swarm-group=${e.groupId}
        >
          <summary class="chat-swarm__summary">
            ${s?H`
                    <span
                      class="chat-swarm__task-icon chat-swarm__task-icon--done"
                      aria-hidden="true"
                      >${z.check}</span
                    >
                    <div class="chat-swarm__header"><strong title=${c}>${c}</strong></div>
                    <span class="chat-swarm__counts"
                      >${L(`labsPage.swarm.completed`,{done:String(e.done)})}</span
                    >
                    <span class="chat-swarm__disclosure"
                      ><span class="sr-only">${L(`labsPage.swarm.details`)}</span
                      >${z.chevronDown}</span
                    >
                  `:H`
                    <div class="chat-swarm__header">
                      <strong title=${c}>${c}</strong>
                      <span
                        >${L(`labsPage.swarm.progress`,{complete:String(r),total:String(n)})}</span
                      >
                    </div>
                    <div class="chat-swarm__markers" role="img" aria-label=${l}>
                      ${u.map(e=>H`<span class=${`chat-swarm__marker chat-swarm__marker--${e}`} aria-hidden="true"></span>`)}
                      ${n>u.length?H`<span>+${n-u.length}</span>`:G}
                    </div>
                    <div class="chat-swarm__counts">${l}</div>
                    ${i?H`<div class="chat-swarm__outcome">${L(a?`labsPage.swarm.childOutcomeProcessing`:`labsPage.swarm.childOutcome`)}</div>`:G}
                    <span class="chat-swarm__disclosure"
                      >${L(`labsPage.swarm.details`)} ${z.chevronDown}</span
                    >
                  `}
          </summary>
          ${s?H`<div class="chat-swarm__outcome">${L(a?`labsPage.swarm.childOutcomeProcessing`:`labsPage.swarm.childOutcome`)}</div>`:G}
          <div class="chat-swarm__tasks" role="list">
            ${t.length===0?H`<div class="chat-swarm__outcome">${L(`labsPage.swarm.detailsUnavailable`)}</div>`:G}
            ${t.map(e=>H` <div class="chat-swarm__task" role="listitem">
                <span
                  class=${`chat-swarm__task-icon chat-swarm__task-icon--${e.status}`}
                  role="img"
                  aria-label=${L(kN[e.status])}
                >
                  ${e.status===`done`?z.check:e.status===`failed`?z.alertTriangle:e.status===`running`?z.loader:z.clock}
                </span>
                <span class="chat-swarm__task-name">${e.label}</span>
                <span class="chat-swarm__task-duration">${e.duration}</span>
              </div>`)}
          </div>
        </details>`})}
    ${i.otherActiveGroups>0?H`<div class="chat-swarm__outcome">${L(`labsPage.swarm.otherGroups`,{count:String(i.otherActiveGroups)})}</div>`:G}
  </aside>`}var kN;function AN(){return(AN=e((()=>{K(),ur(),B(),R(),ta(),Xe(),it(),kN={queued:`common.queued`,running:`common.running`,done:`common.completed`,failed:`labsPage.swarm.failedOrStopped`}})))()}function jN(e){return e.replace(/[\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,``)}function MN(e){if(!(e instanceof HTMLElement))return;let t=e.scrollLeft+e.clientWidth<e.scrollWidth-1;e.toggleAttribute(`data-overflow-right`,t)}function NN(e){let t=e.taskSuggestions??[],n=e.canAcceptTaskSuggestions===!0,r=e.canDismissTaskSuggestions===!0,i=e.canOpenTaskSuggestions===!0,a=e.onOpenTaskSuggestion;if(t.length===0)return G;let o=t.length>1,s=t.some(t=>t.id===e.activeTaskSuggestionId)?e.activeTaskSuggestionId:t[0]?.id;return H`
    <div class="task-suggestions ${o?`task-suggestions--stack`:``}" aria-live="polite">
      ${t.map((c,l)=>{let u=e.taskSuggestionBusyIds?.has(c.id)??!1,d=e.taskSuggestionAcceptance?.(c.id),f=d?.phase===`failed`?d.repository:void 0,p=jN(c.title),m=jN(c.tldr),h=jN(c.cwd),g=jN(c.prompt),_=jN(ae(h)),v=e.taskSuggestionCopiedIds?.has(c.id)??!1,y=L(v?`chat.taskSuggestions.promptCopied`:`chat.taskSuggestions.copyPrompt`),b=t=>{!u&&n&&e.onAcceptTaskSuggestion?.(c,t,void 0)},x=c.id===s,S=H`
          <article
            class="task-suggestion"
            data-task-id=${c.id}
            data-swap-direction=${x&&e.taskSuggestionSwapDirection?e.taskSuggestionSwapDirection:G}
            ?hidden=${!x}
          >
            <header class="task-suggestion__header">
              <div class="task-suggestion__eyebrow" title=${h}>
                ${L(`chat.taskSuggestions.eyebrow`,{repo:_})}
                ${o?H`<span class="task-suggestion__position"
                        >${l+1} / ${t.length}</span
                      >`:G}
              </div>
              <div class="task-suggestion__header-actions">
                <button
                  class="task-suggestion__header-action task-suggestion__copy"
                  type="button"
                  aria-label=${y}
                  title=${y}
                  @click=${()=>e.onCopyTaskSuggestionPrompt?.(c)}
                >
                  ${v?z.check:z.copy}
                </button>
                ${o?H`
                        <button
                          class="task-suggestion__header-action"
                          type="button"
                          aria-label=${L(`chat.taskSuggestions.previous`)}
                          data-task-prev
                          @click=${()=>e.onNavigateTaskSuggestion?.(c.id,`previous`)}
                        >
                          ${z.chevronLeft}
                        </button>
                        <button
                          class="task-suggestion__header-action"
                          type="button"
                          aria-label=${L(`chat.taskSuggestions.next`)}
                          data-task-next
                          @click=${()=>e.onNavigateTaskSuggestion?.(c.id,`next`)}
                        >
                          ${z.chevronRight}
                        </button>
                      `:G}
                ${r||d?.phase===`started`?H`
                        <button
                          class="task-suggestion__header-action task-suggestion__dismiss"
                          type="button"
                          ?disabled=${u||d?.phase===`started`&&!i}
                          aria-label=${L(`chat.taskSuggestions.dismiss`,{title:p})}
                          @click=${()=>e.onDismissTaskSuggestion?.(c)}
                        >
                          ${z.x}
                        </button>
                      `:G}
              </div>
            </header>
            <div class="task-suggestion__body">
              <div class="task-suggestion__title">${p}</div>
              <div class="task-suggestion__summary">${m}</div>
              <details class="task-suggestion__instructions" ?open=${!!d||u}>
                <summary>
                  <span class="task-suggestion__instructions-chevron" aria-hidden="true"
                    >${z.chevronRight}</span
                  >
                  <span class="task-suggestion__show"
                    >${L(`chat.taskSuggestions.showInstructions`)}</span
                  >
                  <span class="task-suggestion__hide"
                    >${L(`chat.taskSuggestions.hideInstructions`)}</span
                  >
                </summary>
                <div class="task-suggestion__instruction-body">
                  <code
                    ${U(e=>{e&&requestAnimationFrame(()=>MN(e))})}
                    @scroll=${e=>MN(e.currentTarget)}
                    >${h}</code
                  >
                  <pre>${g}</pre>
                </div>
              </details>
              ${d?.phase===`started`?H`<p class="task-suggestion__summary" role="status">
                      ${L(`chat.taskSuggestions.started`)}
                    </p>`:d?.phase===`failed`?H`<div class="callout danger" role="alert">
                        <span
                          >${f?G:L(`chat.taskSuggestions.startUnconfirmed`)}
                          ${d.error}</span
                        >
                      </div>`:G}
              ${f?.open?H`
                      <div class="task-suggestion__repository">
                        <p>${L(`chat.taskSuggestions.chooseRepositoryHelp`)}</p>
                        <label>
                          <span>${L(`chat.taskSuggestions.repositoryFolder`)}</span>
                          <input
                            type="text"
                            class="task-suggestion__repository-path"
                            .value=${f.cwd}
                            ?disabled=${!n}
                            @input=${t=>{let n=t.currentTarget;e.onChangeTaskRepository?.(c,{cwd:n.value})}}
                          />
                        </label>
                        ${f.projects.map(t=>H`
                            <button
                              type="button"
                              class="btn task-suggestion__repository-choice"
                              ?disabled=${!n}
                              title=${t.repoRoot??``}
                              @click=${()=>e.onChangeTaskRepository?.(c,{cwd:t.repoRoot??``})}
                            >
                              ${t.displayName}<small>${t.repoRoot}</small>
                            </button>
                          `)}
                        <button
                          type="button"
                          class="btn"
                          @click=${()=>e.onChangeTaskRepository?.(c,{open:!1})}
                        >
                          ${L(`common.cancel`)}
                        </button>
                      </div>
                    `:G}
            </div>
            <div class="task-suggestion__actions">
              ${d?.phase===`started`?H`<a
                      class="btn task-suggestion__start task-suggestion__open"
                      href=${i?d.href:G}
                      aria-disabled=${i?G:`true`}
                      tabindex=${i?0:-1}
                      @click=${e=>{i?a&&Ie(e)&&(e.preventDefault(),a(c)):e.preventDefault()}}
                      >${L(`sessionsView.openSession`)}</a
                    >`:d?.phase===`failed`?H`<button
                        class="btn task-suggestion__start task-suggestion__retry"
                        type="button"
                        ?disabled=${!n||!(!f?.open||Yd(f.cwd.trim()))}
                        @click=${()=>{f?f.open?n&&Yd(f.cwd.trim())&&e.onAcceptTaskSuggestion?.(c,`worktree`,f.cwd.trim()):e.onChangeTaskRepository?.(c,{open:!0}):b(`local`)}}
                      >
                        ${L(f?f.open?`chat.taskSuggestions.startWorktree`:`chat.taskSuggestions.chooseRepository`:`common.retry`)}
                      </button>`:H`
                        <button
                          class="btn task-suggestion__start task-suggestion__start--primary"
                          type="button"
                          ?disabled=${u||!n}
                          title=${n?``:L(`chat.taskSuggestions.adminRequired`)}
                          @click=${()=>b(`local`)}
                        >
                          ${z.play}
                          ${L(u?`chat.taskSuggestions.starting`:`chat.taskSuggestions.startSession`)}
                        </button>
                        <wa-dropdown
                          placement="bottom-end"
                          ?disabled=${u||!n}
                          @wa-select=${e=>{let t=e.detail.item.value;(t===`local`||t===`worktree`||t===`session`)&&b(t)}}
                        >
                          <button
                            slot="trigger"
                            class="btn task-suggestion__start task-suggestion__start--options"
                            type="button"
                            ?disabled=${u||!n}
                            aria-label=${L(`chat.taskSuggestions.startOptions`)}
                            title=${n?``:L(`chat.taskSuggestions.adminRequired`)}
                          >
                            ${z.chevronDown}
                          </button>
                          <wa-dropdown-item value="local" ?disabled=${u||!n}>
                            ${L(`chat.taskSuggestions.startSession`)}
                          </wa-dropdown-item>
                          <wa-dropdown-item value="worktree" ?disabled=${u||!n}>
                            ${L(`chat.taskSuggestions.startWorktree`)}
                          </wa-dropdown-item>
                          <wa-dropdown-item value="session" ?disabled=${u||!n}>
                            ${L(`chat.taskSuggestions.startCurrentSession`)}
                          </wa-dropdown-item>
                        </wa-dropdown>
                      `}
            </div>
          </article>
        `;return Y(x?`${c.id}:${e.taskSuggestionSwapGeneration??0}`:`${c.id}:inactive`,S)})}
    </div>
  `}function PN(){return(PN=e((()=>{K(),sr(),W(),B(),Lc(),R(),Xe()})))()}function FN(e){let t=e.loading?L(`chat.thread.loadingEarlier`):L(`chat.thread.showEarlier`);return H`
    <div class="chat-history-boundary ${e.loading?`chat-history-boundary--loading`:``}">
      <span class="chat-history-boundary__line" aria-hidden="true"></span>
      <button
        class="chat-history-boundary__action"
        type="button"
        ?disabled=${e.loading}
        aria-busy=${e.loading?`true`:`false`}
        aria-label=${t}
        @click=${e.onShowEarlier}
      >
        <span role="status">${t}</span>
      </button>
      <span class="chat-history-boundary__line" aria-hidden="true"></span>
    </div>
  `}function IN(){return(IN=e((()=>{K(),R()})))()}var LN;function RN(){return(RN=e((()=>{K(),ar(),ur(),B(),R(),$r(),tt(),CN(),di(),LN=class extends gt{constructor(...e){super(...e),this.attachments=[],this.sessionKey=``,this.disabled=!1,this.root=null,this.scheduleLayout=()=>{this.frame===void 0&&this.isConnected&&(this.frame=requestAnimationFrame(()=>{this.frame=void 0,this.layoutPins()}))}}updated(e){let t=e.has(`attachments`)||e.has(`sessionKey`);this.root||(this.root=this.closest(`.chat-thread`),this.root&&(t=!0,this.resizeObserver=new ResizeObserver(this.scheduleLayout),this.resizeObserver.observe(this.root),this.mutationObserver=new MutationObserver(e=>{e.some(e=>!this.contains(e.target))&&this.scheduleLayout()}),this.mutationObserver.observe(this.root,{childList:!0,subtree:!0,characterData:!0,attributes:!0}),this.root.addEventListener(`scroll`,this.scheduleLayout,{passive:!0}))),t&&this.scheduleLayout()}disconnectedCallback(){this.resizeObserver?.disconnect(),this.mutationObserver?.disconnect(),this.root?.removeEventListener(`scroll`,this.scheduleLayout),this.root=null,this.observedInner=void 0,this.frame!==void 0&&(cancelAnimationFrame(this.frame),this.frame=void 0),super.disconnectedCallback()}layoutPins(){if(!this.root)return;let e=this.root.querySelector(`.chat-thread-inner`);e&&e!==this.observedInner&&(this.observedInner&&this.resizeObserver?.unobserve(this.observedInner),this.resizeObserver?.observe(e),this.observedInner=e);let t=this.getBoundingClientRect(),n=this.root.getBoundingClientRect().right-28,r=[];for(let e of xN(this.attachments,this.sessionKey)){let i=Array.from(this.querySelectorAll(`button`)).find(t=>t.dataset.attachmentId===e.id);if(!i)continue;let a=vN(this.root,e.selectionAnnotation),o=a&&yN(a);if(i.hidden=!o,!o)continue;let s=Math.min(o.right+4,n)-t.left,c=o.top+(o.height-24)/2-t.top;for(;r.some(e=>Math.abs(e.left-s)<24&&Math.abs(e.top-c)<24);)s+48<=n-t.left?s+=24:c+=24;r.push({left:s,top:c}),i.style.left=`${s}px`,i.style.top=`${c}px`}}render(){return q(xN(this.attachments,this.sessionKey),e=>e.id,(e,t)=>H` <button
        type="button"
        class="btn primary chat-comment-pin"
        data-attachment-id=${e.id}
        aria-label=${L(`chat.messages.editAnnotation`,{number:String(t+1)})}
        title=${e.selectionAnnotation.comment||e.selectionAnnotation.text}
        ?disabled=${this.disabled}
        @pointerup=${e=>e.stopPropagation()}
        @click=${t=>{t.stopPropagation(),t.currentTarget instanceof HTMLElement&&t.currentTarget.dispatchEvent(new CustomEvent(`openclaw-comment-action`,{bubbles:!0,composed:!0,detail:{id:e.id,action:`edit`}}))}}
      >
        ${z.messageSquare}
      </button>`)}},k([X({attribute:!1})],LN.prototype,`attachments`,void 0),k([X()],LN.prototype,`sessionKey`,void 0),k([X({attribute:!1})],LN.prototype,`disabled`,void 0),customElements.define(`openclaw-chat-comment-pins`,LN)})))()}function zN({transcript:e,markers:t,renderedIndexes:n,markerHeight:r,activeId:i,visibleIds:a,rovingId:s,previewId:c,hoveredId:l,bindScroller:u,bindPreview:d,onScroll:f,stopScrollInput:p,onPointerLeave:m,onMarkerHover:h,onMarkerFocus:g,onMarkerBlur:_,onMarkerKeyDown:v,onMarkerSelect:y}){let b=t.length,x=L(`chat.thread.positionUserMessage`),S=L(`chat.thread.positionAssistantMessage`),C=e=>e.role===`user`?x:S,w=c==null?void 0:t.find(e=>e.id===c),T=w?_i(w.message):void 0,E=T?.role===`user`?T.sender:void 0,D=(E?T?.senderLabel:null)??(w?C(w):void 0),O=w&&T?o(Jo(w.message,T).trim(),BN):``;return H`
    <aside
      class="chat-position-rail"
      style=${`--chat-position-rail-count: ${b}`}
      aria-label=${L(`chat.thread.positionRail`)}
      @pointerleave=${m}
    >
      <div class="chat-position-rail__track">
        <div
          ${U(u)}
          class="chat-position-rail__marks"
          role="list"
          aria-label=${L(`chat.thread.positionRail`)}
          @scroll=${f}
          @wheel=${p}
          @touchstart=${p}
          @touchmove=${p}
        >
          <div class="chat-position-rail__virtual-space">
            ${Qn([e,b,l,...n.flatMap(e=>[e,t[e].id,C(t[e]),t[e].anchorId])],()=>q(n,e=>t[e].id,(e,o)=>{let c=t[e],u=n[o-1];return H`
                      ${u!==void 0&&e>u+1?H`<div aria-hidden="true"></div>`:G}
                      <div
                        class="chat-position-rail__item"
                        ?data-hovered=${c.id===l}
                        role="listitem"
                        aria-posinset=${e+1}
                        aria-setsize=${b}
                      >
                        <button
                          class="chat-position-rail__marker"
                          style=${`top: ${e*r}px`}
                          type="button"
                          data-position-marker-id=${c.id}
                          tabindex=${c.id===s?`0`:`-1`}
                          aria-label=${L(`chat.thread.positionMarker`,{position:String(e+1),count:String(b),label:C(c)})}
                          aria-description=${L(`chat.thread.positionMarkerHint`)}
                          aria-current=${String(c.id===i)}
                          ?data-visible=${a.has(c.id)}
                          @pointerenter=${()=>h(c.id)}
                          @focus=${e=>g(c.id,e)}
                          @blur=${_}
                          @keydown=${t=>v(e,t)}
                          @click=${()=>y(c.anchorId)}
                        >
                          <span class="chat-position-rail__tick" aria-hidden="true"></span>
                        </button>
                      </div>
                    `}))}
          </div>
        </div>
        ${w?H`
                <div ${U(d)} class="chat-position-rail__preview" aria-hidden="true">
                  <div class="chat-position-rail__preview-header">
                    ${ym(E)}
                    <span class="chat-position-rail__preview-label">${D}</span>
                  </div>
                  <!-- Preview links remain non-interactive; the marker owns keyboard navigation. -->
                  <div class="chat-position-rail__preview-copy" inert>
                    ${O?lr(Wc(O,{codeBlockChrome:`none`})):L(`chat.attachments.previewUnavailable`)}
                  </div>
                </div>
              `:G}
      </div>
    </aside>
  `}var BN;function VN(){return(VN=e((()=>{K(),pr(),W(),ur(),dr(),Il(),R(),lo(),Zr(),Sm(),BN=140})))()}function HN(){return{hoveredId:null,focusedId:null,dismissed:!1}}var UN,WN,GN,KN,qN,JN;function YN(){return(YN=e((()=>{K(),$n(),Hn(),R(),Jd(),VN(),xf(),UN=12,WN=6,GN=`.chat-bubble[data-entry-id]`,KN=`.chat-bubble[data-message-id]:not([data-entry-id])`,qN=class extends Wn{constructor(...e){super(...e),this.session=null,this.interaction=HN(),this.markerIds=[],this.markerIndexes=new Map,this.renderedIndexes=[],this.viewportOffset=0,this.restoringFocus=!1,this.projectionChanged=!1,this.mountedMarkersChanged=!0,this.markerIdsByMessageId=new Map,this.positionMessageIds=[],this.markersChanged=!0,this.markerElements=new Map,this.observedMessages=new Map,this.visibleIds=new Set,this.initialVisibilityPending=!0,this.targetsChanged=!0,this.followActive=!1,this.layoutVisible=!1,this.followingResize=!1,this.stopScrollInput={handleEvent:e=>{this.followActive=!1,e.stopPropagation()},passive:!0},this.scheduleLayout=()=>{this.layoutFrame===void 0&&this.scrollElement&&(this.layoutFrame=requestAnimationFrame(()=>{this.layoutFrame=void 0,this.syncLayout()}))},this.bindScroller=e=>{this.resizeObserver?.disconnect(),this.disconnectVisibility(),this.markersChanged=!0,this.mountedMarkersChanged=!0,this.layoutVisible=!1,this.viewportHeight=void 0,this.viewportOffset=0,this.layoutFrame!==void 0&&(cancelAnimationFrame(this.layoutFrame),this.layoutFrame=void 0),this.scrollElement=e instanceof HTMLElement?e:void 0,this.scrollElement&&(this.followActive=!0,this.resizeObserver=new ResizeObserver(this.scheduleLayout),this.resizeObserver.observe(this.scrollElement),this.scheduleLayout())},this.dismissPreview=e=>{let t=this.scrollElement?.closest(`.chat-position-rail`);e.key!==`Escape`||e.defaultPrevented||this.interaction.dismissed||!t||t.ownerDocument.defaultView?.getComputedStyle(t).display===`none`||(e.preventDefault(),e.stopImmediatePropagation(),this.interaction.hoveredId=null,this.interaction.dismissed=!0,t.contains(t.ownerDocument.activeElement)&&t.closest(`.chat-thread`)?.focus({preventScroll:!0}),this.requestUpdate?.())},this.bindPreview=e=>{this.previewElement?.ownerDocument.defaultView?.removeEventListener(`keydown`,this.dismissPreview),this.previewElement=e instanceof HTMLElement?e:void 0,this.scheduleLayout(),e?.ownerDocument.defaultView?.addEventListener(`keydown`,this.dismissPreview)}}revealMarker(e){let t=this.scrollElement,n=this.markerIndexes.get(e);if(!t||t.clientHeight===0||n===void 0)return;let r=Number.parseFloat(getComputedStyle(t).scrollPaddingTop)||0,i=n*UN,a=i+UN;(i<t.scrollTop+r||a>t.scrollTop+t.clientHeight-r)&&(t.scrollTop=(i+a-t.clientHeight)/2)}windowIndexes(){let e=this.markerIds.length,t=Math.max(0,Math.floor(this.viewportOffset/UN)-WN),n=Math.min(e,Math.ceil((this.viewportOffset+(this.viewportHeight??window.innerHeight))/UN)+WN),r=new Set;for(let e=t;e<n;e++)r.add(e);for(let e of[this.activeId??this.markerIds[0],this.interaction.focusedId,this.interaction.hoveredId,this.pendingFocusId]){let t=e?this.markerIndexes.get(e):void 0;t!==void 0&&r.add(t)}return[...r].toSorted((e,t)=>e-t)}refreshWindow(){let e=this.renderParams;if(this.isConnected&&e){let t=this.scrollElement,n=this.session,r=t?.ownerDocument.activeElement,i=r instanceof HTMLElement?r.dataset.positionMarkerId:void 0;if(this.setValue(this.render(e)),!this.pendingFocusId&&i&&r instanceof HTMLElement&&this.isConnected&&this.session===n&&this.scrollElement===t&&t?.contains(r)&&t.ownerDocument.activeElement===t.ownerDocument.body){this.interaction.focusedId=i,this.restoringFocus=!0;try{r.focus({preventScroll:!0})}finally{this.restoringFocus=!1}}}}syncMountedMarkers(){if(this.mountedMarkersChanged){this.mountedMarkersChanged=!1,this.markerElements.clear();for(let e of this.scrollElement?.querySelectorAll(`.chat-position-rail__marker`)??[])this.markerElements.set(e.dataset.positionMarkerId,e)}}focusMarker(e){let t=this.session,n=this.scrollElement;if(this.pendingFocusId=e,this.revealMarker(e),this.viewportOffset=n?.scrollTop??0,this.refreshWindow(),!this.isConnected||this.session!==t||this.scrollElement!==n){this.pendingFocusId=void 0;return}this.syncMountedMarkers(),this.markerElements.get(e)?.focus({preventScroll:!0}),this.pendingFocusId=void 0}disconnectVisibility(){this.stopTranscriptScroll?.(),this.stopTranscriptScroll=void 0,this.intersectionObserver?.disconnect(),this.mutationObserver?.disconnect(),this.intersectionObserver=void 0,this.mutationObserver=void 0,this.transcriptElement=void 0,this.readerViewport=void 0,this.resizeScrollTarget=void 0,this.followingResize=!1,this.observedMessages.clear();for(let e of this.visibleIds)this.markerElements.get(e)?.removeAttribute(`data-visible`);this.scrollElement?.querySelector(`[aria-current="true"]`)?.setAttribute(`aria-current`,`false`),this.visibleIds.clear(),this.initialVisibilityPending=!0,this.activeId=void 0}syncVisibilityTargets(){let e=this.scrollElement?.closest(`.chat-thread`);if(!e)return;if(e!==this.transcriptElement){this.disconnectVisibility(),this.transcriptElement=e,this.stopTranscriptScroll=Cf(e,e=>{e.type===`offset`?this.scheduleLayout():e.type===`input`?(this.followingResize&&(this.followActive=!0,this.scheduleLayout()),this.followingResize=!1,this.resizeScrollTarget=void 0):e.type===`resize`&&this.layoutVisible&&this.scrollElement?.clientHeight&&(this.syncReaderViewport(),this.scheduleLayout())}),this.intersectionObserver=new IntersectionObserver((e,t)=>{if(t===this.intersectionObserver){for(let t of e){let e=this.observedMessages.get(t.target);e&&(e.visible=t.isIntersecting&&t.intersectionRatio>0)}this.scheduleLayout()}},{root:e,threshold:[0,2**-52,1]});let t=e=>e.matches(GN)||e.matches(KN)&&this.markerIdsByMessageId.has(e.getAttribute(`data-message-id`));this.mutationObserver=new MutationObserver((e,n)=>{n===this.mutationObserver&&e.some(e=>e.target instanceof Element&&e.target.closest(`.chat-position-rail`)?!1:e.type===`attributes`||[...e.addedNodes,...e.removedNodes].some(e=>e instanceof Element&&(t(e)||[...e.querySelectorAll(`${GN}, ${KN}`)].some(t))))&&(this.targetsChanged=!0,this.scheduleLayout())}),this.mutationObserver.observe(e,{childList:!0,subtree:!0,attributes:!0,attributeFilter:[`data-entry-id`,`data-message-id`]}),this.targetsChanged=!0}if(!this.targetsChanged)return;this.targetsChanged=!1;let t=new Set([...e.querySelectorAll(GN),...e.querySelectorAll(KN)]),n=e=>e.getAttribute(`data-entry-id`)??e.getAttribute(`data-message-id`);for(let[e,r]of this.observedMessages)(!t.has(e)||n(e)!==r.messageId||this.markerIdsByMessageId.get(r.messageId)!==r.id)&&(this.intersectionObserver?.unobserve(e),this.observedMessages.delete(e));for(let e of t){let t=n(e),r=t?this.markerIdsByMessageId.get(t):void 0;t&&r&&!this.observedMessages.has(e)&&(this.observedMessages.set(e,{id:r,messageId:t,visible:!1}),this.intersectionObserver?.observe(e))}}syncReaderViewport(){let e=this.transcriptElement;if(e){let t={height:e.clientHeight,...Bd(e)},n=this.readerViewport;if(n&&t.height!==n.height){this.followingResize=!0,this.followActive||=this.markerElements.get(this.interaction.focusedId??``)?.matches(`:focus-visible`)??!1,this.followActive&&this.scheduleLayout();let r=this.resizeScrollTarget?.atEnd||n.anchorToEnd,i=Math.max(0,e.scrollHeight-t.height);this.resizeScrollTarget={offset:r?i:Math.min(n.scrollTop,i),atEnd:r}}if(n&&t.scrollTop!==n.scrollTop){let e=this.resizeScrollTarget?.offset;e!==void 0&&(Math.abs(t.scrollTop-e)<=1||t.scrollTop>=Math.min(n.scrollTop,e)&&t.scrollTop<=Math.max(n.scrollTop,e))||(this.followingResize&&(this.followActive=!0,this.scheduleLayout()),this.followingResize=!1,this.resizeScrollTarget=void 0)}this.readerViewport=t}}syncVisibleMarks(){this.syncReaderViewport();let e=new Set,t=new Set;for(let n of this.observedMessages.values())n.visible&&(e.add(n.id),t.add(n.messageId));for(let t of this.visibleIds)e.has(t)||this.markerElements.get(t)?.removeAttribute(`data-visible`);for(let t of e)this.visibleIds.has(t)||this.markerElements.get(t)?.setAttribute(`data-visible`,``);this.visibleIds=e,this.initialVisibilityPending&&e.size>0&&(this.followActive=!0,this.scheduleLayout());let n=this.positionMessageIds.filter(e=>t.has(e)),r=this.session?.activeMessageId(n.length?n:this.positionMessageIds),i=(r?this.markerIdsByMessageId.get(r):void 0)??this.markerIds[0];i!==this.activeId&&(this.markerElements.get(this.activeId??``)?.setAttribute(`aria-current`,`false`),this.activeId=i,this.markerElements.get(i??``)?.setAttribute(`aria-current`,`true`),this.syncTabStop(),this.followingResize||(this.followActive=!0),this.scheduleLayout())}syncLayout(){let e=this.scrollElement;if(!e||e.clientHeight===0){this.layoutVisible=!1;return}let t=this.projectionChanged;this.projectionChanged=!1;let n=!this.layoutVisible||t;if(this.layoutVisible=!0,n&&(this.readerViewport=void 0,this.resizeScrollTarget=void 0,this.followingResize=!1),this.markersChanged&&(t&&e.style.removeProperty(`--chat-position-scroll-top`),this.markersChanged=!1,this.targetsChanged=!0),this.syncMountedMarkers(),this.syncVisibilityTargets(),this.syncVisibleMarks(),this.syncTabStop(),n||this.followActive){this.followActive=this.session?.layout.viewportResizePending??!1;let e=this.markerElements.get(this.interaction.focusedId??``),t=(n||e?.matches(`:focus-visible`)?this.interaction.focusedId:void 0)??this.activeId;t&&(this.revealMarker(t),this.visibleIds.size>0&&(this.initialVisibilityPending=!1))}this.viewportHeight=e.clientHeight,this.viewportOffset=e.scrollTop;let r=this.windowIndexes();(r.length!==this.renderedIndexes.length||r.some((e,t)=>e!==this.renderedIndexes[t]))&&(this.refreshWindow(),this.syncMountedMarkers(),this.syncTabStop()),e.style.setProperty(`--chat-position-scroll-top`,`${e.scrollTop}px`);let i=this.markerIds.length*UN;e.toggleAttribute(`data-overflow-top`,e.scrollTop>1),e.toggleAttribute(`data-overflow-bottom`,i-e.clientHeight-e.scrollTop>1);let a=this.previewElement;if(a){let t=this.interaction.hoveredId??this.interaction.focusedId,n=this.markerElements.get(t??``);if(n){let r=(this.markerIndexes.get(t)+.5)*UN-e.scrollTop,i=a.querySelector(`.chat-position-rail__preview-label`)?.textContent?.trim(),o=a.querySelector(`.chat-position-rail__preview-copy`)?.textContent?.trim(),s=`${i??``} ${o??``}. ${L(`chat.thread.positionMarkerHint`)}`;n.getAttribute(`aria-description`)!==s&&n.setAttribute(`aria-description`,s),a.style.setProperty(`--chat-position-preview`,`${r}px`),a.style.visibility=r<0||r>e.clientHeight?`hidden`:``}}}syncTabStop(){let e=this.interaction.focusedId??this.activeId??this.markerIds[0],t=this.scrollElement?.querySelector(`[tabindex="0"]`),n=this.markerElements.get(e??``);n&&n!==t&&(t&&(t.tabIndex=-1),n.tabIndex=0)}disconnected(){this.pendingFocusId=void 0,this.bindPreview(),this.bindScroller(),this.interaction.hoveredId=null,this.interaction.focusedId=null,this.interaction.dismissed=!1}reconnected(){this.requestUpdate?.()}render(e){this.renderParams=e;let{positions:t,transcript:n,requestUpdate:r}=e;this.requestUpdate=r,this.session!==n&&(this.session=n,this.interaction=HN(),this.pendingFocusId=void 0,this.viewportOffset=0,this.viewportHeight=void 0,this.layoutVisible=!1,this.disconnectVisibility(),this.markersChanged=!0);let i=t.markers;t.markerIdsByMessageId!==this.markerIdsByMessageId&&((this.markerIdsByMessageId.size!==t.markerIdsByMessageId.size||[...t.markerIdsByMessageId].some(([e,t])=>this.markerIdsByMessageId.get(e)!==t))&&(this.targetsChanged=!0),this.markerIdsByMessageId=t.markerIdsByMessageId,this.positionMessageIds=[...t.markerIdsByMessageId.keys()]);let a=i.length;if(a===0)return this.disconnected(),G;let o=this.interaction;i.some(e=>e.id===o.focusedId)||(o.focusedId=null),i.some(e=>e.id===o.hoveredId)||(o.hoveredId=null);let s=i.map(e=>e.id);(s.length!==this.markerIds.length||s.some((e,t)=>e!==this.markerIds[t]))&&(this.projectionChanged||=this.markerIds.some((e,t)=>e!==s[t]),this.markerIds=s,this.markerIndexes=new Map(s.map((e,t)=>[e,t])),this.activeId&&!this.markerIndexes.has(this.activeId)&&(this.activeId=void 0),this.markersChanged=!0);let c=this.windowIndexes();(c.length!==this.renderedIndexes.length||c.some((e,t)=>e!==this.renderedIndexes[t])||this.markersChanged)&&(this.renderedIndexes=c,this.mountedMarkersChanged=!0),this.scheduleLayout();let l=o.focusedId??this.activeId??i[0].id,u=(e,t)=>{let n=e.key===`Home`?0:e.key===`End`?a-1:Math.max(0,Math.min(a-1,t+(e.key===`ArrowUp`||e.key===`ArrowLeft`?-1:1)));e.preventDefault(),e.stopPropagation(),e.currentTarget instanceof HTMLButtonElement&&this.focusMarker(i[n].id)};return zN({transcript:n,markers:i,renderedIndexes:this.renderedIndexes,markerHeight:UN,activeId:this.activeId,visibleIds:this.visibleIds,rovingId:l,hoveredId:o.hoveredId,previewId:o.dismissed?void 0:o.hoveredId??o.focusedId,bindScroller:this.bindScroller,bindPreview:this.bindPreview,onScroll:this.scheduleLayout,stopScrollInput:this.stopScrollInput,onPointerLeave:()=>{o.hoveredId=null,this.requestUpdate?.()},onMarkerHover:e=>{o.hoveredId=e,o.dismissed=!1,this.requestUpdate?.()},onMarkerFocus:(e,t)=>{this.restoringFocus||(t.currentTarget instanceof HTMLElement&&t.currentTarget.matches(`:focus-visible`)&&this.revealMarker(e),o.focusedId=e,o.dismissed=!1,this.viewportOffset=this.scrollElement?.scrollTop??0,this.refreshWindow(),this.syncMountedMarkers(),this.syncTabStop(),this.requestUpdate?.())},onMarkerBlur:()=>{o.focusedId=null,this.syncTabStop(),this.requestUpdate?.()},onMarkerKeyDown:(e,t)=>{[`ArrowDown`,`ArrowLeft`,`ArrowRight`,`ArrowUp`,`End`,`Home`].includes(t.key)?u(t,e):t.key===`Escape`?this.dismissPreview(t):(t.key===`PageUp`||t.key===`PageDown`)&&t.stopPropagation()},onMarkerSelect:e=>n.revealMessage(e)})}},JN=Kn(qN)})))()}function XN(e){let t=e?.previousElementSibling;e instanceof Ps&&t instanceof HTMLButtonElement&&(t.id||=`chat-source-${p()}`,e.id||=`${t.id}-preview`,e.for=t.id,t.setAttribute(`aria-controls`,e.id),dl(e))}function ZN(e){let t=e.currentTarget;t instanceof Ps&&t.anchor?.setAttribute(`aria-expanded`,String(t.open))}function QN(e){let t=e.currentTarget,n=t instanceof Element?t.closest(`wa-popover`):null;n instanceof Ps&&(n.open=!1,n.anchor instanceof HTMLElement&&n.anchor.focus({preventScroll:!0}))}function $N(e,t){return e.length>0?H`<openclaw-chat-sources
        .sources=${e}
        .fetchFavicon=${t}
      ></openclaw-chat-sources>`:G}var eP;function tP(){return(tP=e((()=>{Rs(),K(),W(),ur(),B(),Ll(),R(),$r(),r(),tt(),jd(),di(),eP=class extends gt{constructor(...e){super(...e),this.sources=[],this.failedFavicons=new Set,this.refreshFavicons=()=>{this.isConnected&&this.requestUpdate()}}static{this.properties={sources:{attribute:!1},fetchFavicon:{attribute:!1}}}renderFavicon(e){let t=this.fetchFavicon?kd(new URL(e.url).hostname,this.fetchFavicon,this.refreshFavicons):null;return t&&!this.failedFavicons.has(t)?H`<img
          src=${t}
          alt=""
          @error=${()=>{this.failedFavicons.add(t),this.requestUpdate()}}
        />`:z.globe}disconnectedCallback(){for(let e of this.querySelectorAll(`wa-popover`))e.open=!1;super.disconnectedCallback()}willUpdate(){let e=new Set(this.sources.map(e=>e.url));for(let t of this.querySelectorAll(`wa-popover`))e.has(t.dataset.sourceUrl??``)||(t.open=!1)}render(){return H`<div
      class="chat-source-strip"
      role="group"
      aria-label=${L(`chat.messages.sourcePreviews.label`)}
    >
      <div class="chat-source-strip__label">${L(`chat.messages.sourcePreviews.label`)}</div>
      <div class="chat-source-strip__cards">
        ${q(this.sources,e=>e.url,e=>H`
            <div class="chat-source-strip__item">
              <button
                class="chat-source-card"
                type="button"
                aria-haspopup="dialog"
                aria-expanded="false"
              >
                <span class="chat-source-card__title">${e.title}</span>
                <span class="chat-source-card__domain"
                  ><span class="chat-source-card__icon" aria-hidden="true"
                    >${this.renderFavicon(e)}</span
                  >${e.domain}</span
                >
              </button>
              <wa-popover
                ${U(XN)}
                class="chat-source-popover"
                data-source-url=${e.url}
                placement="bottom-start"
                without-arrow
                @wa-show=${ZN}
                @wa-hide=${ZN}
              >
                <section aria-label=${e.title}>
                  <div class="chat-source-popover__header">
                    <span class="chat-source-card__domain">${e.domain}</span>
                    <button
                      class="chat-source-popover__close"
                      type="button"
                      aria-label=${L(`common.close`)}
                      @click=${QN}
                    >
                      ${z.x}
                    </button>
                  </div>
                  ${e.excerpt?H`
                          <div class="chat-source-popover__kind">
                            ${L(e.excerptKind===`page`?`chat.messages.sourcePreviews.pageExcerpt`:`chat.messages.sourcePreviews.searchSnippet`)}
                          </div>
                          <p class="chat-source-popover__excerpt">${e.excerpt}</p>
                        `:H`<p class="chat-source-popover__unavailable">
                          ${L(`chat.messages.sourcePreviews.unavailable`)}
                        </p>`}
                  <a
                    class="chat-source-popover__open"
                    href=${e.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    >${L(`chat.messages.sourcePreviews.open`)}<span aria-hidden="true"
                      >${z.externalLink}</span
                    ></a
                  >
                </section>
              </wa-popover>
            </div>
          `)}
      </div>
    </div>`}},customElements.get(`openclaw-chat-sources`)||customElements.define(`openclaw-chat-sources`,eP)})))()}function nP(e,t){let n=Pu(e);if(n)return Yx(n,t.streamOptions);let r=Qu(e),i=r.find(e=>e.role===`assistant`),a=e.outcome.kind===`completed`?e.outcome.actionOwner:null,o=i??r[0],s=e.parts.flatMap(e=>e.kind===`stream-run`?e.parts.map(e=>e.startedAt):[]),c={key:e.key,kind:`group`,role:`assistant`,senderLabel:i?.senderLabel,replyToSender:i?.replyToSender??e.parts.find(e=>e.kind===`stream-run`)?.replyToSender,messages:o?.messages??[],visibleContent:o?.visibleContent??`none`,timestamp:(a?Ru(a.message):null)??Math.min(...r.map(e=>e.timestamp),...s,Date.now()),isStreaming:e.outcome.kind===`active`,runId:e.runId},l=e=>oS(e,t.renderGroupOptions(e)),u=e.parts.flatMap(e=>e.kind===`stream-run`?e.parts:[e]),d=[q(u,e=>e.kind+`:`+e.key,e=>{if(e.kind===`stream`||e.kind===`reading-indicator`||e.kind===`question`)return Jx(e,t.streamOptions,`standalone`);if(e.kind===`work-group`){let n=t.isWorkExpanded(e.key);return H`
            ${Xx(e,{expanded:n,onToggle:()=>t.onToggleWork(e.key,n),presentation:`continuation`,browserTabPreviews:bb(e.groups,t.renderGroupOptions(c))})}
            ${n?e.groups.map(l):G}
          `}if(e.kind===`activity-run`){let n=e.groups[0];return n?nS(e.groups,t.renderGroupOptions(n),`continuation`):G}return l(e)}),a?$N(fa({groups:r,answer:a.message,runId:e.runId,basePath:t.basePath,sessionPublicOrigin:t.sessionPublicOrigin}),t.streamOptions.fetchLinkFavicon):G];return sS(c,{...t.renderGroupOptions(c),frameContent:d,frameActionOwner:a,turnRecap:t.turnRecap})}function rP(){return(rP=e((()=>{K(),ur(),Zo(),Lu(),id(),lS(),tP(),Bb()})))()}function iP(e){let t=e.realtimeTalkConversation??[];return t.length===0?G:H`
    <div
      class="agent-chat__voice-turns"
      role="log"
      aria-label=${L(`chat.composer.voiceTranscript`)}
    >
      ${q(t,e=>e.id,t=>{let n=t.role===`user`?e.userName?.trim()||`You`:e.assistantName;return H`
            <div
              class="agent-chat__voice-turn agent-chat__voice-turn--${t.role}"
              data-role=${t.role}
            >
              <span class="agent-chat__voice-turn-speaker">${n}</span>
              <span class="agent-chat__voice-turn-text">${t.text}</span>
              ${t.isStreaming?H`<span
                      class="agent-chat__voice-turn-stream"
                      aria-label=${L(`chat.composer.stillListening`)}
                    ></span>`:G}
            </div>
          `})}
    </div>
  `}function aP(){return(aP=e((()=>{K(),ur(),R()})))()}function oP(e,t,n){let r=_i(e),i=sv(e,r);if(!i)return;let a={...r,messages:[{message:e}]},o=td(e)??t;return{messageId:o,sourceMessageId:o,senderLabel:iS(a,n),text:i}}function sP(e,t){let n=new Map;return r=>{if(n.has(r))return n.get(r);let i=e.get(r),a=i?sv(i.message):void 0;if(i&&a){let e={messageId:i.messageId,sourceMessageId:r,senderLabel:i.senderLabel,text:a};return n.set(r,e),e}let o=t.replyMessageAccess?.read(r),s=o?oP(o,r,t):void 0;return n.set(r,s),s}}function cP(){return(cP=e((()=>{Zr(),rd(),cS(),dv()})))()}function lP(e,t,n){let r=new Map,i=new Map,a=(e,t,a,o,s)=>{let c=r.get(e);c?c.message=o:r.set(e,{id:e,role:t,anchorId:a,message:o}),i.set(a,e),n.set(a,s)},o=(e,t)=>{if(!(e.role!==`user`&&e.role!==`assistant`||e.visibleContent===`none`))for(let n of e.messages){if(!n.hasVisibleContent)continue;let r=td(n.message)??n.key,i=e.role===`user`?r:e.runId?`run:${e.runId}`:td(e.messages[0]?.message)??e.key;a(i,e.role,r,n.message,t)}},s=(e,n)=>{if(e.kind===`group`)o(e,n);else if(e.kind===`agent-run-frame`)for(let t of e.parts)s(t,n);else if(e.kind===`activity-run`)for(let t of e.groups)o(t,n);else if(e.kind===`work-group`&&t.get(e.key))for(let t of e.groups)o(t,n===e.key?`${e.key}:${t.key}`:n);else if(e.kind===`stream-run`)for(let t of e.parts){if(t.kind!==`stream`)continue;let r={role:`assistant`,content:[{type:`text`,text:t.text}],timestamp:t.startedAt},{normalizedMessage:i,displayMarkdown:o}=ov(r);(wo(r,i)===`non-text`||o.trim())&&a(e.runId?`run:${e.runId}`:e.key,`assistant`,t.key,r,n)}};for(let t of e)s(t,t.key);return{markers:[...r.values()],markerIdsByMessageId:i}}function uP(){return(uP=e((()=>{bo(),id(),dv()})))()}function dP(e,t){return e.kind===`stream-run`?e.parts.includes(t):e.kind===`agent-run-frame`&&e.parts.some(e=>e.kind===`stream-run`&&e.parts.includes(t))}function fP(e,t){let n=Reflect.ownKeys(e).filter(e=>e!==`text`);return n.length===Reflect.ownKeys(t).filter(e=>e!==`text`).length&&n.every(n=>Object.hasOwn(t,n)&&Object.is(Reflect.get(e,n),Reflect.get(t,n)))}function pP(e,t,n){let r=e=>({...e,parts:e.parts.map(e=>e===t?n:e)});return e.kind===`stream-run`?r(e):{...e,parts:e.parts.map(e=>e.kind===`stream-run`&&e.parts.includes(t)?r(e):e)}}function mP(e,t,n,r){let i=e.get(t);if(i?.key.every((e,t)=>Object.is(e,n[t])))return i.value;let a=r();return e.set(t,{key:n,value:a}),a}function hP(e,t){let{session:n}=t,r=[t.sessionKey,t.runWorking,t.searchActive,n?.key,n?.lastRunId,n?.status,n?.runtimeMs,_f()],i=bP.get(e);if(i?.key.every((e,t)=>Object.is(e,r[t]))){let t=i.live;if(!t||e[t.index]===t.item)return i.value;let n=e[t.index];if(t.owner&&n?.kind===`stream`&&fP(t.item,n)){let r=pP(t.owner.item,t.item,n),a=i.value.collapsedItems.slice(),o=i.value.transcriptItems.slice();a[t.owner.collapsedIndex]=r,o[t.owner.transcriptIndex]=r;let s={collapsedItems:a,transcriptItems:o,continuations:i.value.continuations},c={...t.owner,item:r},l={...t,item:n,owner:c};return xP.set(s,{item:n,owner:c,structuralChain:i.structuralChain}),bP.set(e,{...i,value:s,live:l}),s}}let a=(()=>{let n=Gu(cd(ru(yu(e),t),t),t),r=new Map;return{collapsedItems:n,transcriptItems:n.filter((e,t)=>{let i=n[t-1],a=e.kind===`stream-run`&&e.parts.every(e=>e.kind===`reading-indicator`)?e.parts:e.kind===`agent-run-frame`?Pu(e):void 0,o=e.kind===`stream-run`||e.kind===`agent-run-frame`?e.runId:void 0;return i?.kind!==`group`||!a||!ku(i)||i.runId!==void 0&&o!==void 0&&i.runId!==o||(r.set(i.key,a),!1)}),continuations:r}})(),o=nd(e),s=e[o],c;if(s?.kind===`stream`){let e=a.collapsedItems.findLast(e=>dP(e,s)),t=e?a.transcriptItems.lastIndexOf(e):-1,n=e&&t>=0?{item:e,collapsedIndex:a.collapsedItems.lastIndexOf(e),transcriptIndex:t}:void 0;c={index:o,item:s,owner:n},n&&xP.set(a,{item:s,owner:n,structuralChain:a})}return bP.set(e,{key:r,value:a,structuralChain:a,live:c}),a}function gP(e,t,n){let r=[t,Xu(t),n.assistantName,n.userId,n.userName];return mP(SP,e,r,()=>{let i=xP.get(e);if(!i)return _P(e,t,n);let a=lP(e.transcriptItems.slice(i.owner.transcriptIndex),t,new Map),o=a.markerIdsByMessageId.has(i.item.key),s=mP(CP,i.structuralChain,[...r,o],()=>{let r=_P(e,t,n),a=r.rows.findLastIndex(e=>e.key===i.owner.item.key);if(a<0)throw Error(`Missing live stream owner row`);return{chain:e,index:r,ownerRowIndex:a}});if(s.chain===e)return s.index;let c=s.index.rows.slice();c[s.ownerRowIndex]={kind:`item`,key:i.owner.item.key,item:i.owner.item};let l=s.index.positionIndex.markers;for(let e of a.markers){let t=s.index.positionIndex.markers.findLastIndex(t=>t.id===e.id);if(t<0)continue;let n=s.index.positionIndex.markers[t];e.message!==n.message&&(l===s.index.positionIndex.markers&&(l=l.slice()),l[t]={...n,message:e.message})}return{...s.index,rows:c,positionIndex:{...s.index.positionIndex,markers:l}}})}function _P(e,t,n){let r=new Map,{messageRowKeysById:i,transcriptMessageKeys:a}=yP(e.transcriptItems,t,n,r),o=lP(e.transcriptItems,t,i),s=[];for(let n of e.transcriptItems)if(s.push({kind:`item`,key:n.key,item:n}),n.kind===`work-group`&&t.get(n.key))for(let e of n.groups)s.push({kind:`item`,key:`${n.key}:${e.key}`,item:e});return{messageRowKeysById:i,transcriptMessageKeys:a,loadedReplySources:r,positionIndex:o,rows:s}}function vP(e,t,n){for(let r of e){let e=r.kind===`agent-run-frame`?r.parts:[r];for(let r of e)r.kind===`work-group`&&r.groups.some(e=>e.messages.some(e=>td(e.message)===n))&&od(t,r.key,!0)}}function yP(e,t,n,r){let i=new Map,a=new Map;for(let o of e){let e=o.kind===`agent-run-frame`?o.parts:[o],s=o.kind===`agent-run-frame`?Qu(o):o.kind===`group`?[o]:o.kind===`work-group`||o.kind===`activity-run`?o.groups:[],c=s.find(e=>e.role===`assistant`)??s[0];for(let s of e){if(s.kind===`stream-run`)for(let e of s.parts)e.kind===`stream`&&a.set(e.key,o.key);else s.kind===`stream`&&a.set(s.key,o.key);let e=s.kind===`group`?[s]:s.kind===`work-group`||s.kind===`activity-run`?s.groups:[];for(let s of e){let e=iS(c??s,{assistantName:n.assistantName,userId:n.userId,userName:n.userName}),l=o.kind===`work-group`&&t.get(o.key)?o.key+`:`+s.key:o.key;for(let t of s.messages){a.set(t.key,l);let n=td(t.message);n&&(i.set(n,l),r.set(n,{message:t.message,messageId:t.key,senderLabel:e}))}}}}return{messageRowKeysById:i,transcriptMessageKeys:a}}var bP,xP,SP,CP;function wP(){return(wP=e((()=>{Lu(),rd(),Zd(),cS(),uP(),bP=new WeakMap,xP=new WeakMap,SP=new WeakMap,CP=new WeakMap})))()}function TP(e){if(e.kind===`stream-run`)return[e.key,...e.parts];if(e.kind===`work-group`)return[e.key,e.durationMs,...e.groups];if(e.kind===`activity-run`)return[e.key,...e.groups];if(e.kind===`agent-run-frame`){let t=e.outcome;return[e.key,t.kind,t.kind===`completed`?t.actionOwner:null,...e.parts.flatMap(TP)]}return[e]}function EP(e,t){let n=e.transcriptRenderDependencies;(n.length!==t.length||t.some((e,t)=>!Object.is(n[t],e)))&&(e.transcriptRenderDependencies=t,e.transcriptRenderContext={})}function DP(e,t,n){return r=>Qn([...TP(r),e.transcriptRenderContext,t(r)],()=>n(r))}function OP(){return(OP=e((()=>{pr()})))()}function kP(e,t){let n=t?Fu({...t,searchOpen:!1,searchQuery:``}):e,r=new Map,i=[];for(let e of n)if((e.kind===`divider`||Au(e)||e.kind===`group`&&Hu(e))&&(i=[]),e.kind===`group`){if(Fi(e.role)!==`assistant`||Hu(e))continue;for(let t of e.messages)i.push(t),r.set(t.key,i)}else if(e.kind===`stream`){let t={key:e.key,message:{role:`assistant`,content:[{type:`text`,text:e.text}]}};i.push(t),r.set(e.key,i)}return r}function AP(){return(AP=e((()=>{Zr(),Eu(),ad()})))()}function jP(e){let t=dt.getLocale();(!NP||PP!==t)&&(PP=t,NP=new Intl.ListFormat(t,{type:`conjunction`,style:`long`}));let n=e.length>3?e.slice(0,2):e,r=[...n];e.length>3&&r.push(L(`chat.sessionSuggestions.typingOthers`,{count:String(e.length-2)}));let i=0,a=NP.formatToParts(r).map(e=>e.type===`element`&&i++<n.length?H`<bdi class="agent-chat__typing-name" title=${e.value}>${e.value}</bdi>`:e.value),o=e.length===1?`chat.sessionSuggestions.typing`:`chat.sessionSuggestions.typingMany`,s=L(o,{name:``,names:``});return{text:L(o,{name:NP.format(r),names:NP.format(r)}),content:s.split(``).map((e,t)=>t?H`${a}${e}`:e)}}function MP(e,t=`gutter`,n){if(!e?.length)return null;let r=e.filter(e=>!e.paused),i=e.slice(2,7),a=i.map(e=>e.label),o=n?.several?{text:L(`chat.sessionSuggestions.typingSeveral`),content:L(`chat.sessionSuggestions.typingSeveral`)}:a.length?jP(a):void 0,s=t===`none`&&i.length?i.map(e=>`${e.label} — ${L(`chat.sessionSuggestions.typingDraftState`)}`).join(`; `):void 0,c=n?.several?o?.text??``:r.length===0?``:r.length===1?L(`chat.sessionSuggestions.typing`,{name:r[0]?.label??``}):L(`chat.sessionSuggestions.typingMany`,{names:r.map(e=>e.label).join(`, `)});return H`<div class="agent-chat__typing-indicator agent-chat__typing-indicator--outside">
    ${q(e.slice(0,2),e=>e.id,e=>{let n={id:e.id,name:e.label,identity:{type:`profile`,id:e.id}},r=e.preview?.trim()?e.preview:void 0;return H`<div
          class="agent-chat__typing-row"
          ?data-exiting=${e.exitDurationMs!==void 0}
          style=${e.exitDurationMs===void 0?G:`--chat-typing-exit-duration: ${e.exitDurationMs}ms`}
        >
          <div class="agent-chat__typing-row-content">
            <div
              class="chat-group user chat-group--peer chat-group--sender-tint chat-group--with-footer chat-group--typing"
              style=${`--chat-sender-hue: ${Ko(n)}`}
              aria-live="off"
            >
              <div class="chat-group-messages">
                <div class="chat-bubble ${r?`agent-chat__typing-preview-bubble`:``}">
                  <div class="chat-message-avatar-anchor">
                    ${r?H`<span
                            class="chat-text agent-chat__typing-preview-text"
                            dir="auto"
                            ?data-paused=${e.paused}
                            >${r}</span
                          >`:H`<span class="agent-chat__typing-bubble" aria-hidden="true"
                            ><span></span><span></span><span></span
                          ></span>`}
                    ${t===`gutter`?ou(`user`,void 0,void 0,n):null}
                  </div>
                </div>
              </div>
              <div class="chat-group-footer chat-group-footer--persistent-identity">
                <div class="chat-group-footer__meta">
                  ${t===`footer`?ym(n):null}
                  <span class="chat-sender-name agent-chat__typing-preview-label"
                    >${e.label}</span
                  >
                  <span
                    class="agent-chat__typing-state agent-chat__typing-text"
                    ?data-typing=${!e.paused}
                    >${L(e.paused?`chat.sessionSuggestions.pausedDraftState`:`chat.sessionSuggestions.typingDraftState`)}</span
                  >
                </div>
              </div>
            </div>
          </div>
        </div>`})}
    ${i.length?H`<div class="agent-chat__typing-row agent-chat__typing-group">
            <div class="agent-chat__typing-row-content">
              <div
                class="agent-chat__typing-overflow ${t===`none`?`agent-chat__typing-overflow--no-avatars`:``}"
                role="group"
                aria-label=${s?`${L(`chat.sessionSuggestions.otherCollaborators`)}: ${s}`:L(`chat.sessionSuggestions.otherCollaborators`)}
                title=${s??G}
                aria-live="off"
              >
                ${t===`none`?G:H`<span class="agent-chat__typing-identities">
                        ${q(i,e=>e.id,e=>H`<span class="agent-chat__typing-person">
                            ${ym({id:e.id,name:e.label,identity:{type:`profile`,id:e.id}})}
                          </span>`)}
                      </span>`}
                <span class="agent-chat__typing-summary"
                  ><span class="agent-chat__typing-text" data-typing
                    >${o?.content}</span
                  ></span
                >
              </div>
            </div>
          </div>`:G}
    <span class="sr-only" role="status">${c}</span>
  </div>`}var NP,PP;function FP(){return(FP=e((()=>{K(),ur(),R(),ji(),Su(),Sm()})))()}function IP(e){let t=e.currentAgentId??`main`,n=e.agents?.find(e=>e.id===t);return{id:t,avatar:A(e.assistantAvatarUrl,{identity:{avatar:e.assistantAvatar??void 0,avatarUrl:e.assistantAvatarUrl??void 0}})??(n?Te(n):null),textAvatar:wt(e.assistantAvatar)??(n?ke(n):null)}}function LP(e){if(!e.sessions)return[];let t=e.sessionHost??{},n=Fe(t),r=Ue(e.sessionKey)?.agentId??n;return pt(e.sessions,{agentId:r,defaultAgentId:n,filterByAgent:!0}).filter(t=>!je(t.key,e.sessionKey)&&!Ye(t.key,t.channel).channelSession).toSorted((e,t)=>(t.updatedAt??0)-(e.updatedAt??0)||e.key.localeCompare(t.key)).slice(0,WP)}function RP(){return H`
    <div class="agent-chat__welcome-clawd" aria-hidden="true">
      <openclaw-mascot mood="idle" .size=${112}></openclaw-mascot>
    </div>
  `}function zP(e,t){return H`
    <div class="agent-chat__recents">
      <div class="agent-chat__recents-title">${L(`chat.welcome.recentSessions`)}</div>
      ${e.map(e=>{let n=de(e);return H`
          <button type="button" class="agent-chat__recent" @click=${()=>t?.(e.key)}>
            <span class="agent-chat__recent-name">${ye(e.key,e)}</span>
            ${n?H`<span class="agent-chat__recent-sub">${n}</span>`:G}
            <span class="agent-chat__recent-time">
              ${ge(e.updatedAt,{fallback:``})}
            </span>
          </button>
        `})}
    </div>
  `}function BP(e){return H`
    <div class="agent-chat__suggestions">
      ${UP.map(t=>{let n=L(t);return H`
          <button
            type="button"
            class="agent-chat__suggestion"
            @click=${()=>{e.onDraftChange(n),e.onSend()}}
          >
            ${n}
          </button>
        `})}
    </div>
  `}function VP(e){let t=e.assistantName||`Assistant`,n=e.hint??H`${L(`chat.welcome.hintBeforeShortcut`)} ${Vt(`/`)}
    ${L(`chat.welcome.hintAfterShortcut`)}`;return H`
    <div class="agent-chat__welcome-identity">
      <span class="agent-chat__welcome-avatar" role="img" aria-label=${t}>
        ${rl(IP(e))}
      </span>
      <div class="agent-chat__welcome-identity-copy">
        <h2>${t}</h2>
        <p class="agent-chat__hint">${n}</p>
      </div>
    </div>
  `}function HP(e){if(e.modelSetupRequired)return H`
      <div class="agent-chat__welcome agent-chat__welcome--setup" role="alert">
        ${RP()}
        <h2>${L(`modelSetup.required.title`)}</h2>
        <p class="agent-chat__hint">${L(`modelSetup.required.body`)}</p>
        ${e.onModelSetup?H`<button class="btn primary" type="button" @click=${e.onModelSetup}>
                ${L(`modelSetup.required.action`)}
              </button>`:G}
      </div>
    `;let t=LP(e);return H`
    <div class="agent-chat__welcome" style="--agent-color: var(--accent)">
      ${VP(e)} ${e.composer??G}
      ${e.hideSecondaryContent?G:H`<div
              class="agent-chat__welcome-secondary ${e.fadeSecondaryContent?`agent-chat__welcome-secondary--hidden`:``}"
              aria-hidden=${e.fadeSecondaryContent?`true`:`false`}
              ?inert=${e.fadeSecondaryContent}
            >
              <div class="agent-chat__welcome-secondary-inner">
                ${t.length>0?zP(t,e.onOpenSession):BP(e)}
              </div>
            </div>`}
    </div>
  `}var UP,WP;function GP(){return(GP=e((()=>{K(),_c(),rn(),R(),ll(),Yo(),xe(),fe(),we(),Xe(),pe(),it(),ja(),UP=[`chat.welcome.suggestions.whatCanYouDo`,`chat.welcome.suggestions.summarizeRecentSessions`,`chat.welcome.suggestions.configureChannel`,`chat.welcome.suggestions.checkSystemHealth`],WP=5})))()}function KP(e,t){let n=uO(e.paneId),r=e.asyncQuestions,a=e.onRequestUpdate??(()=>{}),o=e.sessionHost??null,s=e.selectedSession,c=(s?.expandedParticipants??s?.participants??[]).some(({identity:t})=>t.type!==`agent`&&(t.type!==`profile`||t.id!==e.userId))||[...e.messages,...(e.pendingInputs??[]).map(e=>e.message)].some(t=>{if(Fi(Yi(t))!==`user`)return!1;let n=ni(i(i(t)?.__openclaw));return!(!n||n.identity?.type===`profile`&&n.identity.id===e.userId)}),l=xp(s,e.mediaPolicyEpoch),u=Ue(e.sessionKey)?.rest===`global`||o!==null&&st(o)&&Ct(o,e.sessionKey)!==null,d=e.showThinking&&s?.reasoningLevel===`on`,f=e.currentAgentId??e.fullMessageAgentId,p=IP({currentAgentId:f,agents:e.agents,assistantAvatar:e.assistantAvatar,assistantAvatarUrl:e.assistantAvatarUrl}),m={agentId:f,name:e.assistantName,avatar:p.avatar,textAvatar:p.textAvatar},h=dt.getLocale(),g=n.searchOpen&&!!n.searchQuery.trim(),_=t.expandedAssistantMessages,v=t=>Zu(e.fullMessageAgentId,t);_.size>0&&ju(_,e.fullMessageAgentId,[...e.messages,...e.toolMessages,...(e.pendingInputs??[]).map(e=>e.message)]);let y={paneId:e.paneId,sessionKey:e.sessionKey,archiveNotice:gp(s),runId:e.runId??null,compactionStatus:e.compactionStatus,locale:h,messages:e.messages,toolMessages:e.toolMessages,guardianNotices:e.guardianNotices,streamSegments:e.streamSegments,stream:e.stream??null,streamStartedAt:e.streamStartedAt,queue:e.queue,initialTurnId:e.initialTurnId,pendingInputs:e.pendingInputs,workerSetupPending:[`requested`,`provisioning`,`syncing`,`starting`].includes(s?.placement?.state??``),workspaceSyncPendingRunIds:(s?.placement?.state===`active`||s?.placement?.state===`draining`)&&s.placement.workspaceResultReconciling===!0?s.activeRunIds:void 0,showToolCalls:e.showToolCalls,persistCommentary:e.persistCommentary,runWorking:!!e.runWorking,runActive:!!e.runActive,questionPrompts:e.questionPrompts,loading:e.loading,searchOpen:n.searchOpen,searchQuery:n.searchQuery,messageRecovery:g&&e.loadFullAssistantMessage?{messages:_,revision:Xu(_),agentId:e.fullMessageAgentId}:void 0},b=Ju(y),x=b.find(e=>e.kind===`reading-indicator`),S=x?.runId??e.runId,C=e.runActive&&S?b.findLast(e=>e.kind===`group`&&e.messages.some(({message:e})=>eu(e)===S&&Ri(e).some(e=>!e.hideFromChannelProgress&&!e.suppressChannelProgress)))?.key:void 0,w=x?.runId?e.runUsageById?.get(x.runId)?.outputTokens??null:null,T=e.latestBrowserTabs;Mu(e.sessionKey,b,!!e.autoExpandToolCalls,g||!e.showToolCalls);let E=zu(e.sessionKey),D=Du(e.sessionKey),O=hP(b,{sessionKey:e.sessionKey,runWorking:!!e.runWorking,searchActive:g,session:s}),{collapsedItems:k,transcriptItems:ee}=O,te=e.replyMessageAccess?.navigationId;te&&vP(ee,E,te);let{messageRowKeysById:ne,transcriptMessageKeys:re,loadedReplySources:ie,positionIndex:ae,rows:oe}=gP(O,E,e),A=new Map((e.questionPrompts??[]).map(e=>[e.id,e])),j=(e,t)=>{od(E,e,!(t??E.get(e)??!1)),n.transcriptRenderContext.onRequestUpdate?.()},M=t=>{let n=v(t),r=_.get(n),i=e.loadFullAssistantMessage;if(!i||r?.status===`loading`)return;let o=(r?.revision??0)+1,s={status:`loading`,revision:o};od(_,n,s),a();let c=e=>{if(_.get(n)!==s)return;let t=e?.ok&&e.message&&typeof e.message==`object`?Uo(e.message):null;od(_,n,t===null?{status:`error`,revision:o+1}:{status:`loaded`,markdown:t,message:e?.message,revision:o+1}),a()};i({sessionKey:e.sessionKey,...e.fullMessageAgentId?{agentId:e.fullMessageAgentId}:{},messageId:t}).then(c,()=>c(null))},se=(e.realtimeTalkConversation?.length??0)>0,ce=(e.typingActors?.length??0)>0,le=b.length===0&&!e.loading&&!se&&!ce;t.setContentReady(!e.loading);let ue=s?.kind,de=ue&&ue!==`unknown`?ue:u?`global`:Td(e.sessionKey),N=b.some(e=>e.kind===`group`&&Hu(e)),fe=bm((de===`direct`||de===`cron`||de===`spawn-child`)&&!N,e.userId),pe=fe===`footer`,me=s?.classification===`subagent`||Ne(e.sessionKey)?`none`:fe,he=e.loading&&b.length===0&&!ce,ge=s?.contextTokens??e.sessions?.defaults?.contextTokens??null,_e=new Map,ve=new Map,ye=sP(ie,e),be={entryRefFor:t.entryAnimations.refFor,presented:e.presented,onReply:e.onSetReply?e=>n.transcriptRenderContext.onSetReply?.(e):void 0,onOpenSidebar:e.onOpenSidebar,sessionKey:e.sessionKey,boardProvider:e.boardProvider,agentId:e.currentAgentId??e.fullMessageAgentId,runActive:e.runActive,asyncQuestions:r,onOpenWorkspaceFile:e.onOpenWorkspaceFile,onRequestUpdate:a,resourceBasePath:e.resourceBasePath,mediaPolicyKey:l,connectionEpoch:e.connectionEpoch,assistantAttachmentAuthToken:e.assistantAttachmentAuthToken??null,resolveArtifactDownload:e.resolveArtifactDownload,getTurnVideoMessages:e=>n.transcriptRenderContext.turnVideoMessages?.get(e),onRequestOpenImage:e.onRequestOpenImage,onOpenImage:e.onOpenImage,onAssistantAttachmentLoaded:e.onAssistantAttachmentLoaded,canvasPluginSurfaceUrl:e.canvasPluginSurfaceUrl,embedSandboxMode:e.embedSandboxMode??`scripts`,allowExternalEmbedUrls:e.allowExternalEmbedUrls??!1,fetchLinkFavicon:e.fetchLinkFavicon,pluginToolIcons:e.pluginToolIcons,githubRepo:e.githubRepo,githubRepositories:e.githubRepositories,showAssistantAvatar:me===`gutter`},xe={...be,branding:e.branding,assistant:m,startupLabel:e.startupLabel,waitingApproval:e.waitingApproval,runOutputTokens:w,questionPrompts:A},Se=null,Ce=t=>{let r=t.messages.at(-1)?.message,i=t.role.toLowerCase()===`user`&&r?td(r):null;return{...be,transcriptVisible:e.transcriptVisible,latestBrowserTabs:T,showReasoning:d,showToolCalls:e.showToolCalls,activityRunId:S,activityGroupKey:C,autoExpandToolCalls:!!e.autoExpandToolCalls,isToolMessageExpanded:e=>E.get(e),onToggleToolMessageExpanded:j,isUserMessageExpanded:e=>D.get(e)??!1,onToggleUserMessageExpanded:e=>{od(D,e,!D.get(e)),a()},loadFullAssistantMessage:e.loadFullAssistantMessage??void 0,getAssistantMessageExpansion:e=>_.get(v(e)),onToggleAssistantMessageExpanded:M,isToolExpanded:e=>E.get(e)??!1,onToggleToolExpanded:j,assistantName:e.assistantName,assistantAvatar:m.avatar,assistantTextAvatar:m.textAvatar,agentId:m.agentId,agents:e.agents,senderAgentAvatars:e.senderAgentAvatars,mainKey:e.mainKey,userId:e.userId??null,userName:e.userName??null,showOwnSenderName:c,userAvatar:e.userAvatar??null,onRetryQueuedMessage:e.onRetryQueuedMessage,onDiscardQueuedMessage:e.onDiscardQueuedMessage,queuedMessageAction:e.queuedMessageAction,personActivity:e.personActivity,avatarPlacement:me,contextWindow:ge,resolveReplyPreview:ye,onResolveReply:e.replyMessageAccess?.request,onOpenReply:e=>n.transcriptRenderContext.onOpenReply?.(e),replyNavigationId:e.replyMessageAccess?.navigationId,onRewind:i&&e.onRewindMessage?()=>{Promise.resolve(e.onRewindMessage?.(i)).then(t=>{t&&e.onFocusComposer?.()})}:void 0,rewindDisabled:!!(e.runActive||e.runWorking),activeContinuation:_e.get(t.key),turnRecap:ve.get(t.key),latestAssistant:t.key===Se,searchResult:g}},we=JSON.stringify([w]),Te=DP(n,e=>{if(e.kind===`agent-run-frame`){let t=e.parts.some(e=>e.kind===`stream-run`&&e.parts.some(e=>e.kind===`reading-indicator`)),n=ve.get(e.key);return`${t?we:``}|${n?`${n.runtimeMs}:${n.outputTokens??``}`:``}|${e.key===Se?`latest-assistant`:``}`}if(e.kind===`stream-run`)return e.parts.some(e=>e.kind===`reading-indicator`)?we:``;if(e.kind!==`group`)return``;let t=_e.get(e.key),n=ve.get(e.key);return`${t?`${t.parts.map(e=>e.key).join(` `)}${we}`:``}|${n?`${n.runtimeMs}:${n.outputTokens??``}`:``}|${e.key===Se?`latest-assistant`:``}|${g?`search-result`:``}`},t=>{if(t.kind===`divider`)return vp(t);if(t.kind===`notice`)return yp(t);if(t.kind===`stream-run`)return Yx(t.parts,xe);if(t.kind===`work-group`){let n=E.get(t.key)??!1;return Xx(t,{expanded:n,browserTabPreviews:bb(t.groups,{sessionKey:e.sessionKey,latestBrowserTabs:T}),onToggle:()=>j(t.key,n)})}if(t.kind===`activity-run`){let e=t.groups[0];return e?t.groups.length===1?sS(e,Ce(e)):nS(t.groups,Ce(e)):G}return t.kind===`agent-run-frame`?nP(t,{basePath:e.basePath,sessionPublicOrigin:e.sessionPublicOrigin,streamOptions:xe,renderGroupOptions:Ce,isWorkExpanded:e=>E.get(e)??!1,onToggleWork:j,turnRecap:ve.get(t.key)}):t.kind===`group`?sS(t,Ce(t)):t.kind===`question`?Yx([t],{questionPrompts:A}):G}),Ee=Cu(n,{sessionKey:e.sessionKey,agentId:e.currentAgentId,gatewayClient:e.gatewayClient,indicator:x,row:s,usageByRun:e.runUsageById});for(let[e,t]of O.continuations)_e.set(e,{parts:t,options:xe});let De=ee.at(-1),P=De?.kind===`agent-run-frame`&&De.outcome.kind===`completed`&&De.outcome.actionOwner!==null||De?.kind===`group`&&ku(De)?De:null,F=Ee&&(!P?.runId||P.runId===Ee.runId)?Ee:null;Se=!e.runActive&&!e.runWorking&&!g&&P&&(P.kind!==`group`||!P.isStreaming)?P.key:null,t.entryAnimations.project(b),t.syncMessageRows(ne,re);let Oe=null;F!==null&&P?.runId===F.runId&&(ve.set(P.key,F),Oe=P.key);let ke=[...oe],I,Ae=iP({...e,realtimeTalkConversation:e.realtimeTalkConversation?.filter(t=>!t.transcriptId||(I??=new Set(e.messages.map(td)),!I.has(t.transcriptId)))});Ae!==G&&ke.push({kind:`content`,key:`realtime-talk`,content:Ae}),F!==null&&Oe===null&&!le&&!he&&ke.push({kind:`content`,key:`turn-recap`,content:Wx(F)});let je=MP(e.typingActors,me,e.typingOverflow);je&&ke.push({kind:`content`,key:`presence:typing`,content:je});let Me=vn();return EP(n,[h,e.branding?.mascot,e.branding?.avatarHat,e.branding?.artwork,e.branding?.workingPhrases,Me.mascot,Me.avatarHat,E,Xu(E),D,Xu(D),_,Xu(_),Ap(),Math.floor(Date.now()/6e4),JSON.stringify([...T??[]]),e.sessionKey,e.presented,e.transcriptVisible,me,e.boardProvider,e.boardProvider?.canPinWidgets,e.boardProvider?.canPinMcpApps,e.boardProvider?.snapshot$.value.revision,e.fullMessageAgentId,!!e.loadFullAssistantMessage,d,e.showToolCalls,!!e.runActive,S,C,!!e.runWorking,e.startupLabel,!!e.waitingApproval,e.questionPrompts,n.asyncQuestionRevision,e.asyncQuestions?.historyKey,!!e.autoExpandToolCalls,e.assistantName,m.avatar,m.textAvatar,e.currentAgentId,e.agents,e.senderAgentAvatars,e.mainKey,e.userId,e.userName,c,e.userAvatar,e.resourceBasePath,e.basePath,e.sessionPublicOrigin,l,e.assistantAttachmentAuthToken,e.connectionEpoch,e.canvasPluginSurfaceUrl,e.embedSandboxMode??`scripts`,e.allowExternalEmbedUrls??!1,!!e.fetchLinkFavicon,e.pluginToolIcons,e.githubRepo?.owner,e.githubRepo?.repo,$s(e.githubRepositories,e.githubRepo),ge,!!e.onSetReply,!!e.asyncQuestions?.submit,!!e.onRetryQueuedMessage,!!e.onDiscardQueuedMessage,e.queuedMessageAction?.id,e.queuedMessageAction?.label,e.queuedMessageAction?.onAction,e.replyMessageAccess?.revision??0,e.replyMessageAccess?.navigationId??``,F===null?``:`${F.runtimeMs}:${F.outputTokens??``}`]),n.transcriptRenderContext.onRequestUpdate=e.onRequestUpdate,n.transcriptRenderContext.turnVideoMessages=kP(b,g?y:void 0),n.transcriptRenderContext.onSetReply=e.onSetReply,n.transcriptRenderContext.onOpenReply=r=>{let i=ie.get(r);if(i&&sv(i.message)){vP(ee,E,r),t.revealMessage(r);return}g&&gO(n,a),e.replyMessageAccess?.open(r)},{isDirectThread:pe,positionIndex:he?{markers:[],markerIdsByMessageId:new Map}:ae,isEmpty:le,showLoadingSkeleton:he,searchOpen:n.searchOpen,renderRows:(r=G,i=null)=>t.render(ke,e=>e.kind===`item`?Te(e.item):e.content,NO(k),e.announceTranscript!==!1&&!n.searchOpen&&!e.loading,r,i,!!te)}}function qP(){return(qP=e((()=>{K(),vd(),jn(),R(),Fo(),Zr(),us(),it(),Nu(),$u(),wu(),rd(),ad(),rP(),Sm(),bp(),dv(),Qp(),lS(),aP(),cP(),TO(),Bb(),IO(),wP(),OP(),AP(),FP(),GP(),Kx()})))()}function JP(e,t){return t.renderSession(e.sessionKey,t=>YP(e,t))}function YP(e,t){let n=KP(e,t);(n.isEmpty||n.showLoadingSkeleton)&&t.entryAnimations.sync(XP,e.announceTranscript!==!1&&!n.searchOpen&&!e.loading);let r=e.historyPagination?H`<div class="chat-history-sentinel"></div>`:G,i=e.historyPagination?{template:FN(e.historyPagination),height:44}:null,a=e.routeLoadingSkeleton&&n.showLoadingSkeleton,o=e.commentAttachments?.some(e=>e.selectionAnnotation),s=a?yn():n.showLoadingSkeleton||n.isEmpty?H`
          <div class="chat-thread-inner" ${U(t.scrollElementRef)}>
            ${r}
            ${n.isEmpty&&!n.showLoadingSkeleton&&i?i.template:G}
            ${n.showLoadingSkeleton?Fl(`chat`,L(`chat.thread.loading`)):G}
            ${n.isEmpty&&!n.searchOpen?HP({...e,onModelSetup:void 0}):G}
            ${n.isEmpty&&n.searchOpen?H` <div class="agent-chat__empty">${L(`chat.thread.noMatches`)}</div> `:G}
          </div>
        `:n.renderRows(r,i);return H`
    <div class="chat-thread-viewport">
      <div
        class="chat-thread ${n.isDirectThread?`chat-thread--direct`:``} ${a?`chat-thread--route-loading`:``} ${o?`chat-thread--comment-pins`:``}"
        ${Ol(e.transcriptVisible??!0)}
        ${Zs(e.sessionKey,(e.transcriptVisible??!0)&&!n.showLoadingSkeleton,!!e.gatewayClient?.connected)}
        ${U(t=>{t instanceof HTMLElement&&Ad(t,e.fetchLinkFavicon)})}
        role="log"
        aria-live="off"
        aria-relevant="additions"
        tabindex="0"
        @focusin=${e=>t.handleFocusIn(e)}
        @focusout=${e=>t.handleFocusOut(e)}
        @scroll=${e.onChatScroll}
        @wheel=${e.onHistoryIntent?{handleEvent:e.onHistoryIntent,passive:!0}:null}
        @keydown=${t=>{let n=rc(t);if(n){e.onOpenWorkspaceFile?.(n);return}let r=cl(t,e.basePath);if(r){e.onOpenSessionLink?.(r);return}e.onHistoryIntent?.(t)}}
        @touchstart=${e.onHistoryIntent?{handleEvent:e.onHistoryIntent,passive:!0}:null}
        @touchmove=${e.onHistoryIntent?{handleEvent:e.onHistoryIntent,passive:!0}:null}
        @touchend=${e.onHistoryIntent}
        @touchcancel=${e.onHistoryIntent}
        @click=${t=>{tc(t),vl(t);let n=Dc(t);if(n){e.onOpenWorkspaceFile?.(n);return}let r=xl(t,e.basePath);r&&Ie(t)&&(t.preventDefault(),e.onOpenSessionLink?.(r))}}
        @contextmenu=${t=>SO(t,e)}
        @pointerup=${t=>bO(t,e)}
      >
        <span
          class="chat-transcript-announcement sr-only"
          role="status"
          aria-live=${e.announceTranscript===!1?`off`:`polite`}
          aria-atomic="true"
          >${t.liveAnnouncementText}</span
        >
        ${JN({positions:n.positionIndex,transcript:t,requestUpdate:e.onRequestUpdate??(()=>{})})}
        ${s}
        ${o?H`<openclaw-chat-comment-pins
                .attachments=${e.commentAttachments}
                .sessionKey=${e.sessionKey}
                .disabled=${e.commentsDisabled??!1}
              ></openclaw-chat-comment-pins>`:G}
      </div>
    </div>
  `}var XP;function ZP(){return(ZP=e((()=>{K(),W(),wc(),On(),Uc(),Ks(),ql(),Nl(),Wl(),Cl(),R(),Od(),IN(),RN(),YN(),TO(),Mk(),qP(),GP(),XP=new Map})))()}var QP;function $P(){return($P=e((()=>{K(),ar(),ic(),R(),vo(),Na(),tt(),wy(),QP=class extends gt{constructor(...e){super(...e),this.content=null,this.loadFullMessage=null,this.resolvedCard=null,this.loadState=`idle`,this.downloadFailed=!1,this.requestVersion=0,this.loadOutput=async()=>{let e=this.content;if(!this.isConnected||!e||this.loadState===`loading`)return;let{card:t,sessionKey:n,agentId:r}=e;if(Ba(t)){this.loadState=`unavailable`;return}if(!n||!t.resultMessageId||!t.callId||!this.loadFullMessage){t.outputTruncated&&(this.loadState=`unavailable`);return}let i=++this.requestVersion;this.loadState=`loading`;try{let a=await this.loadFullMessage({sessionKey:n,agentId:r,messageId:t.resultMessageId,maxChars:2e6});if(i!==this.requestVersion||this.content!==e||!this.isConnected)return;let o=a?.ok&&a.message?fo(a.message).filter(e=>e.callId===t.callId&&e.completed):[],s=o.length===1?o[0]:void 0;if(!s||s.outputText===void 0){this.loadState=`unavailable`;return}this.resolvedCard={...t,...s},this.loadState=s.outputTruncated||Ba(s)?`unavailable`:`loaded`}catch{i===this.requestVersion&&this.content===e&&this.isConnected&&(this.loadState=`error`)}}}connectedCallback(){super.connectedCallback(),this.hasUpdated&&this.loadState===`idle`&&this.loadOutput()}disconnectedCallback(){this.requestVersion+=1,this.loadState===`loading`&&(this.loadState=`idle`),super.disconnectedCallback()}willUpdate(e){e.has(`loadFullMessage`)&&!this.loadFullMessage&&(this.requestVersion+=1,this.loadState=`idle`),(e.has(`content`)||e.has(`connectionEpoch`))&&(this.requestVersion+=1,this.resolvedCard=null,this.loadState=`idle`,this.downloadFailed=!1),(e.has(`content`)||e.has(`connectionEpoch`)||e.has(`loadFullMessage`)&&!e.get(`loadFullMessage`)&&this.loadFullMessage)&&this.loadOutput()}downloadOutput(e){this.downloadFailed=!1;let t;try{t=URL.createObjectURL(new Blob([e.outputText??``],{type:`text/plain;charset=utf-8`}));let n=document.createElement(`a`);n.href=t,n.download=`tool-output.txt`,n.click()}catch{this.downloadFailed=!0}finally{t&&URL.revokeObjectURL(t)}}render(){let e=this.resolvedCard??this.content?.card;if(!e)return G;let t=e.outputText??``,n=Xo(e)??``;return H`<section class="chat-tool-output" aria-busy=${this.loadState===`loading`}>
      <div class="sidebar-header">
        <div class="sidebar-title">${Ao(e)}</div>
      </div>
      ${this.loadState===`loading`?H`<p role="status">${L(`common.loading`)}</p>`:G}
      ${this.loadState===`unavailable`?H`<p role="status">${L(`chat.toolCards.fullOutputUnavailable`)}</p>`:G}
      ${this.loadState===`error`?H`<p role="alert">${L(`chat.toolCards.outputLoadFailed`)} <button class="btn btn--sm" @click=${this.loadOutput}>${L(`common.retry`)}</button></p>`:G}
      ${e.inputText===void 0?G:H`<details>
              <summary>${L(`chat.toolCards.toolInput`)}</summary>
              <pre>${e.inputText}</pre>
            </details>`}
      ${this.loadState===`loading`?G:H`<div class="chat-tool-output__actions">
              ${Pc(t,L(`chat.toolCards.copyOutput`))}
              <button class="btn btn--sm" type="button" @click=${()=>this.downloadOutput(e)}>
                ${L(`chat.toolCards.downloadOutput`)}
              </button>
            </div>`}
      ${this.downloadFailed?H`<p role="alert">${L(`chat.toolCards.outputDownloadFailed`)}</p>`:G}
      <pre class="chat-tool-output__text"><code>${n}</code></pre>
      ${n===t?G:cy(t)}
    </section>`}},k([X({attribute:!1})],QP.prototype,`content`,void 0),k([X({attribute:!1})],QP.prototype,`loadFullMessage`,void 0),k([X()],QP.prototype,`connectionEpoch`,void 0),k([J()],QP.prototype,`resolvedCard`,void 0),k([J()],QP.prototype,`loadState`,void 0),k([J()],QP.prototype,`downloadFailed`,void 0),customElements.get(`openclaw-chat-tool-output`)||customElements.define(`openclaw-chat-tool-output`,QP)})))()}function eF(e){let{content:t,host:n}=e;return t.kind===`tool-output`?H`<openclaw-chat-tool-output
      class="chat-sidebar"
      .content=${t}
      .loadFullMessage=${e.chat.loadFullAssistantMessage??null}
      .connectionEpoch=${e.chat.connectionEpoch}
    ></openclaw-chat-tool-output>`:H`<openclaw-chat-detail-panel
    class="chat-sidebar"
    .content=${t}
    .fileNavigation=${t.kind===`file`?t.navigation??null:null}
    .execNode=${pu(n)?.execNode??null}
    .attachmentRuntime=${{sessionKey:e.chat.sessionKey,agentId:e.chat.currentAgentId??e.chat.fullMessageAgentId,policyKey:xp(e.chat.selectedSession,e.chat.mediaPolicyEpoch),authToken:e.chat.assistantAttachmentAuthToken,connectionEpoch:e.chat.connectionEpoch,resourceBasePath:e.chat.resourceBasePath,resolveArtifactDownload:e.chat.resolveArtifactDownload}}
    .basePath=${e.chat.basePath??``}
    .canvasPluginSurfaceUrl=${n.canvasPluginSurfaceUrl}
    .embedSandboxMode=${n.embedSandboxMode}
    .allowExternalEmbedUrls=${n.allowExternalEmbedUrls}
    .githubContext=${{githubRepo:e.chat.githubRepo,githubRepositories:e.chat.githubRepositories}}
    .onOpenWorkspaceFile=${e=>Lw(n,e)}
    .onOpenSessionLink=${e.chat.onOpenSessionLink}
    .onRevealInWorkspace=${e=>{Bw(n,e),qS(n,null),n.updateSidebarLayout(tf(n.sidebarLayout,`workspace`))}}
    .onOpenImage=${e=>n.handleOpenImage(e,n.beginImageOpen())}
    .embedded=${!0}
    @chat-detail-panel-close=${()=>n.handleCloseSidebar(t.kind===`attachment`?`workspace`:`detail`)}
  ></openclaw-chat-detail-panel>`}function tF(){return(tF=e((()=>{K(),iu(),cf(),xw(),$P(),Qp(),ZS(),Gw()})))()}function nF(e){let{owner:t,selection:n,client:r}=e;if(!n)return;let i=rF.get(t);(!i?.isCurrent()||i.model!==e.model||i.selection!==n)&&(i={model:e.model,selection:n,accounts:[],loading:!1,open:!1,error:null,isCurrent:e.ownsSelection},rF.set(t,i));let a=i,o=()=>rF.get(t)===a&&a.isCurrent(),s=async t=>{if(r&&o()&&!a.loading){a.loading=!0,a.error=null,e.onRequestUpdate();try{let e=await r.request(`users.listModelAccounts`,t?{cursor:t}:{});o()&&(a.accounts=t?[...a.accounts,...e.accounts]:e.accounts,a.nextCursor=e.nextCursor)}catch(e){o()&&(a.error=N(e,L(`profilePage.modelAccounts.inventoryFailed`)))}finally{o()&&(a.loading=!1,e.onRequestUpdate())}}},c=e.model.includes(`/`)?Se(e.model.slice(0,e.model.indexOf(`/`))):``,l=n.kind===`automatic`?void 0:n.authProfileId,u=e.modelAuthStatusResult?.providers.filter(e=>Ua(Se(e.provider))===Ua(c)).flatMap(e=>e.profiles)??[],d=e=>u.find(t=>t.profileId===e)?.email,f=u.find(e=>e.profileId===l),p=f?.displayName||n.label,m=[...new Set([f?.email,p].filter(Boolean))].join(` · `),h=e=>d(e?.authProfileId)??(e&&a.accounts.some(t=>t.authProfileId!==e.authProfileId&&t.provider===e.provider&&t.label===e.label)?e.authProfileId:void 0),g=`current`,_=[{value:g,label:p,description:d(l)??h(a.accounts.find(e=>e.authProfileId===l))},...a.accounts.filter(e=>e.provider===c&&e.authProfileId!==l).map(e=>({value:`account:${e.authProfileId}`,label:e.label,description:h(e)})),...e.onAutomatic?[{value:`automatic`,label:L(`chat.modelAccounts.automatic`)}]:[],...a.loading?[{value:`loading`,label:L(`common.loading`),disabled:!0}]:[],...a.nextCursor?[{value:`more`,label:L(`profilePage.modelAccounts.loadMore`),disabled:a.loading}]:[],...e.onManage?[{value:`manage`,label:L(`chat.modelAccounts.manage`)}]:[]],v=(t,n)=>{if(n.stopPropagation(),o()&&!e.disabled){if(t===`manage`)e.onManage?.();else if(t===`automatic`)e.onAutomatic?.();else if(t===`more`)n.preventDefault(),s(a.nextCursor);else{let n=a.accounts.find(e=>`account:${e.authProfileId}`===t&&e.provider===c);n&&e.onSelect(n)}}};return{onClose:()=>{a.open=!1,e.onRequestUpdate()},render:t=>H`
      <section
        class="chat-controls__provider-model-group"
        data-chat-account-selection=${n.kind}
        aria-label=${L(`chat.modelAccounts.section`)}
      >
        <button
          class="chat-controls__provider-heading chat-controls__account-heading"
          type="button"
          data-chat-account-group-toggle
          data-chat-model-group-toggle
          aria-expanded=${a.open}
          ?disabled=${e.disabled}
          @click=${()=>{a.open=!a.open,e.onRequestUpdate(),a.open&&a.accounts.length===0&&!a.loading&&s()}}
        >
          <span class="chat-controls__provider-icon chat-controls__target-icon" aria-hidden="true"
            >${z.users}</span
          >
          <span class="chat-controls__provider-label">${L(`chat.modelAccounts.section`)}</span>
          <span class="chat-controls__account-selection" title=${m}
            >${m}</span
          >
          <span class="chat-controls__inline-select-chevron" aria-hidden="true"
            >${a.open?z.chevronUp:z.chevronDown}</span
          >
        </button>
        <div
          class="chat-controls__provider-model-list"
          data-chat-model-list="true"
          role="listbox"
          aria-label=${L(`chat.modelAccounts.section`)}
        >
          ${q(_,e=>e.value,(n,r)=>H`
              <button
                class="chat-controls__inline-select-option chat-controls__model-option"
                type="button"
                role="option"
                aria-selected=${n.value===g}
                data-chat-account-option=${n.value}
                data-chat-model-option=${`account:${n.value}`}
                data-chat-model-index=${t+r}
                data-chat-model-name=${n.label.toLocaleLowerCase()}
                data-chat-model-keywords=${n.description?.toLocaleLowerCase()??``}
                data-chat-model-provider-label="account"
                ?hidden=${!a.open}
                aria-disabled=${n.disabled?`true`:G}
                ?disabled=${e.disabled||n.disabled&&n.value!==`more`}
                @mouseenter=${_D}
                @click=${e=>v(n.value,e)}
              >
                <span class="chat-controls__model-option-provider" aria-hidden="true"
                  >${z.users}</span
                >
                <span class="chat-controls__model-option-copy">
                  <span class="chat-controls__model-option-name">${n.label}</span>
                  ${n.description?H`<span class="chat-controls__auth-meta" title=${n.description}><span class="chat-controls__model-option-name">${n.description}</span></span>`:G}
                </span>
                <span class="chat-controls__model-option-action">
                  ${n.value===g?H`<span class="chat-controls__inline-select-check" aria-hidden="true">${z.check}</span>`:G}
                </span>
              </button>
            `)}
        </div>
        ${a.error?H`<span class="chat-controls__account-error" role="alert"
                >${a.error}</span
              >`:G}
      </section>
    `}}var rF;function iF(){return(iF=e((()=>{K(),ur(),B(),R(),Ya(),he(),ft(),pa(),DD(),Ha(),rF=new WeakMap})))()}function aF(e){return e.replace(/^Inherited:\s*/u,``)}function oF(e){let t=e.thinking.options,n=t.length>0;if(!e.reserved&&!n&&!e.fastMode.supported)return G;let r=e.thinking.selection,i=Qr(r.value)===`off`,a=-120+(i||r.kind===`unanchored`?0:t.length>1?r.index/(t.length-1):1)*240,o=r.source===`override`,s=o?r.value:``,c=r.kind===`anchored`?r.index:0,l=r.kind===`unanchored`,u=t.findLastIndex(e=>e.label!==`On`&&[`minimal`,`low`,`medium`,`high`,`xhigh`,`max`].includes(e.value)),d=e=>t[e]?.value===`ultra`?`ultra`:e===u?`max`:``,f=l?``:d(c),p=e=>t.length>1?e/(t.length-1)*100:0,m=aF(e.thinking.inherited.displayLabel),h=aF(r.displayLabel),g=o?h:L(`chat.modelControls.defaultWithLevel`,{level:m}),_=n?h:L(`chat.modelControls.fastMode`),v=n?e.fastMode.active?`${_} · ${L(`chat.modelControls.fastMode`)}`:_:`${_}: ${e.fastMode.label}`,y=t=>{e.onThinkingSelect(t,e.sessionKey).finally(()=>e.onRequestUpdate?.()),e.onRequestUpdate?.()},b=t=>{e.onFastModeSelect(t,e.sessionKey).finally(()=>e.onRequestUpdate?.()),e.onRequestUpdate?.()},x=(e,t=!1)=>{t&&(e.value=String(c)),e.style.setProperty(`--reasoning-fill`,`${p(c)}%`),e.dataset.effortBoost=f,e.setAttribute(`aria-valuetext`,g);let n=e.closest(`.chat-controls__reasoning-panel`);n?.querySelectorAll(`[data-chat-thinking-preview-index]`).forEach(e=>{e.hidden=!0});let r=n?.querySelector(`[data-chat-thinking-preview-committed]`);r&&(r.hidden=!1)},S=e=>{let n=e.currentTarget,r=t[Number(n.value)];if(!r)return;n.style.setProperty(`--reasoning-fill`,`${p(Number(n.value))}%`),n.dataset.effortBoost=d(Number(n.value)),n.setAttribute(`aria-valuetext`,aF(r.label));let i=n.closest(`.chat-controls__reasoning-panel`);i?.querySelectorAll(`[data-chat-thinking-preview-index]`).forEach(e=>{e.hidden=e.dataset.chatThinkingPreviewIndex!==n.value});let a=i?.querySelector(`[data-chat-thinking-preview-committed]`);a&&(a.hidden=!0)},C=n=>{let r=n.currentTarget,i=t[Number(r.value)];x(r),!e.thinkingDisabled&&i&&i.value!==s&&y(i.value)},w=e=>{let t=e.currentTarget;l&&Number(t.value)===c&&C(e)},T=e=>{l&&[`Home`,`ArrowLeft`,`ArrowDown`,`PageDown`].includes(e.key)&&C(e)},E=t.length===1?t[0]:void 0,D=r.kind===`anchored`&&r.index===0;return H`
    <details
      class="chat-controls__inline-select chat-controls__effort-picker ${e.reserved?`chat-controls__effort-picker--reserved`:``}"
      aria-hidden=${String(e.reserved===!0)}
      ?inert=${e.reserved===!0}
      @toggle=${e=>{let t=e.currentTarget;ID(e),BD(t)}}
    >
      <summary
        class="chat-controls__inline-select-trigger chat-controls__effort-trigger ${e.fastMode.active?`chat-controls__effort-trigger--fast`:``} ${e.disabled?`chat-controls__inline-select-trigger--disabled`:``}"
        data-chat-thinking-select="true"
        data-chat-thinking-value=${s}
        data-chat-thinking-disabled=${e.thinkingDisabled?`true`:`false`}
        data-chat-fast-mode=${e.fastMode.active?`true`:`false`}
        aria-label=${n?`${L(`chat.selectors.thinkingLevel`)}: ${v}`:v}
        aria-disabled=${e.disabled?`true`:`false`}
        title=${e.disabledReason??v}
        @click=${t=>{e.disabled&&t.preventDefault()}}
      >
        ${e.fastMode.active?H`<span class="chat-controls__effort-zap" aria-hidden="true">${z.zap}</span>`:G}
        ${n?H`
                <span
                  class="chat-controls__effort-gauge ${i?`chat-controls__effort-gauge--off`:``}"
                  aria-hidden="true"
                >
                  ${Ot(fr`
                  <path class="chat-controls__effort-gauge-dial" d="M3.34 17a10 10 0 1 1 17.32 0" />
                  <path
                    class="chat-controls__effort-gauge-needle"
                    d="M12 12V6"
                    style=${`transform: rotate(${a}deg)`}
                  />
                  <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
                `)}
                  ${e.fastMode.active?H`<span class="chat-controls__effort-fast-badge">${z.zap}</span>`:G}
                </span>
              `:H`<span class="chat-controls__effort-speed" aria-hidden="true">${z.zap}</span>`}
        <span class="chat-controls__inline-select-label">${_}</span>
        <span class="chat-controls__inline-select-chevron" aria-hidden="true"
          >${z.chevronUp}</span
        >
      </summary>
      <wa-popup data-anchored-overlay>
        <div
          class="chat-controls__inline-select-menu chat-controls__effort-menu"
          aria-label=${L(n?`chat.modelControls.effort`:`chat.modelControls.fastMode`)}
        >
          ${n?H`
                  <div class="chat-controls__reasoning-panel">
                    <div class="chat-controls__reasoning-head">
                      <span class="chat-controls__effort-heading">
                        ${L(`chat.modelControls.effort`)}
                      </span>
                      <span class="chat-controls__effort-value" aria-hidden="true">
                        <span data-chat-thinking-preview-committed>${h}</span>
                        ${t.map((e,t)=>H`<span
                            data-chat-thinking-preview-index=${t}
                            hidden
                            >${aF(e.label)}</span
                          >`)}
                      </span>
                    </div>
                    ${t.length>1?H`
                            <div class="chat-controls__reasoning-slider">
                              <div class="chat-controls__reasoning-dots" aria-hidden="true">
                                ${t.map(e=>H`<span
                                    class="chat-controls__reasoning-dot"
                                    data-stop=${e.value}
                                  ></span>`)}
                              </div>
                              <input
                                class="chat-controls__reasoning-range ${o?``:`chat-controls__reasoning-range--inherit`} ${l?`chat-controls__reasoning-range--unanchored`:``}"
                                type="range"
                                min="0"
                                max=${t.length-1}
                                step="1"
                                .value=${String(c)}
                                style=${`--reasoning-fill: ${p(c)}%`}
                                data-chat-thinking-slider="true"
                                data-effort-boost=${f}
                                data-chat-thinking-values=${t.map(e=>e.value).join(`,`)}
                                aria-label=${L(`chat.selectors.thinkingLevel`)}
                                aria-valuetext=${g}
                                ?disabled=${e.thinkingDisabled}
                                @input=${S}
                                @change=${C}
                                @click=${w}
                                @keydown=${T}
                                @pointercancel=${e=>x(e.currentTarget,!0)}
                                @blur=${e=>x(e.currentTarget,!0)}
                              />
                            </div>
                            <div class="chat-controls__effort-scale" aria-hidden="true">
                              <span>${L(`chat.modelControls.faster`)}</span>
                              <span>${L(`chat.modelControls.smarter`)}</span>
                            </div>
                          `:E?H`
                              <button
                                class="chat-controls__reasoning-option ${D?`chat-controls__reasoning-option--selected`:``}"
                                data-chat-thinking-option=${E.value}
                                type="button"
                                aria-pressed=${D?`true`:`false`}
                                ?disabled=${e.thinkingDisabled}
                                @click=${t=>{if(t.stopPropagation(),e.thinkingDisabled||D){t.preventDefault();return}y(E.value)}}
                              >
                                <span>${E.label}</span>
                                ${D?H`<span
                                        class="chat-controls__inline-select-check"
                                        aria-hidden="true"
                                        >${z.check}</span
                                      >`:G}
                              </button>
                            `:G}
                  </div>
                `:G}
          <div class="chat-controls__fast-mode-row">
            <span class="chat-controls__fast-mode-icon" aria-hidden="true">${z.zap}</span>
            <span class="chat-controls__fast-mode-copy">
              <span class="chat-controls__fast-mode-title">
                ${L(`chat.modelControls.fastMode`)}
              </span>
              <span class="chat-controls__fast-mode-description">
                ${L(`chat.modelControls.fastHelp`)}
              </span>
            </span>
            <button
              class="chat-controls__speed-toggle ${e.fastMode.active?`chat-controls__speed-toggle--active`:``}"
              data-chat-speed-toggle=${e.fastMode.nextValue}
              type="button"
              role="switch"
              aria-checked=${e.fastMode.active?`true`:`false`}
              aria-label=${L(`chat.modelControls.fastResponsesAria`,{state:e.fastMode.label})}
              ?disabled=${e.fastMode.disabled}
              @click=${t=>{if(t.stopPropagation(),e.fastMode.disabled){t.preventDefault();return}b(e.fastMode.nextValue)}}
            >
              <span class="chat-controls__speed-toggle-thumb"></span>
            </button>
          </div>
        </div>
      </wa-popup>
    </details>
  `}function sF(){return(sF=e((()=>{K(),Yt(),B(),V(),R(),Oi(),Wi(),qD(),Xr()})))()}function cF(){return Vt(``,{ariaHidden:!0,hidden:!0,ref:e=>e?.setAttribute(`data-chat-model-shortcut`,`true`)})}function lF(e){return JSON.stringify([e.value,e.agentRuntime??null])}function uF(e,t,n){return(e.value===t||e.isDefault&&t===``)&&(e.agentRuntime===void 0||(e.agentRuntime??void 0)===n)}function dF(e){let t=e.contextTokens,n=e.contextWindow;return t&&n&&t!==n?L(`chat.modelControls.contextActiveAndMax`,{active:le(t),maximum:le(n)}):n?le(n):``}function fF(e){let t=e.trim().toLowerCase();return _F[t]??`${t.charAt(0).toUpperCase()}${t.slice(1)}`}function pF(e){let t=[xc(e.provider),Mc(e.provider)].toSorted((e,t)=>t.length-e.length);for(let n of t){if(e.label.toLowerCase().startsWith(`${n.toLowerCase()} `))return e.label.slice(n.length+1);let t=` (${n.toLowerCase()})`;if(e.label.toLowerCase().endsWith(t))return e.label.slice(0,e.label.length-t.length)}return e.label}function mF(e){return kc(e,{className:`chat-controls__provider-icon`})}function hF(e){let t=uF(e.entry,e.selectedModelValue,e.selectedAgentRuntime),n=pF(e.entry),r=Sd(e.entry.provider,e.entry.agentRuntimeId),i=r?L(`chat.modelControls.routes.${r}.label`):e.entry.agentRuntimeId?fF(e.entry.agentRuntimeId):``,a=r?L(`chat.modelControls.routes.${r}.detail`):``,o=e.entry.supportsTools===!1?L(`chat.modelControls.chatOnlyHelp`):``,s=[a,o].filter(Boolean).join(` `),c=e.entry.isDefault&&e.sessionModelPinned,l=e.entry.disabled&&(e.entry.unavailableReason===`missing-auth`||e.entry.unavailableReason===`auth-failed`),u=l?e.onModelSetup:void 0,d=l?r?i:``:[dF(e.entry),i].filter(Boolean).join(` · `),f=l?L(`modelSetup.candidates.signInNeeded`):e.entry.unavailableReason===`unsupported-runtime`?L(`chat.modelControls.runtimeUnavailable`):``,p=H`<button
    class="chat-controls__inline-select-option chat-controls__model-option ${t?`chat-controls__inline-select-option--selected`:``}"
    data-chat-model-option=${e.entry.value}
    data-chat-model-runtime=${e.entry.agentRuntime??G}
    data-chat-model-default=${e.entry.isDefault?`true`:G}
    data-chat-model-index=${e.index}
    data-chat-model-keywords=${[e.entry.isDefault?L(`chat.modelControls.default`):``,i].filter(Boolean).join(` `).toLocaleLowerCase()}
    data-chat-model-name=${n.toLocaleLowerCase()}
    data-chat-model-provider-label=${Mc(e.entry.provider).toLocaleLowerCase()}
    role="option"
    hidden
    aria-selected=${t?`true`:`false`}
    title=${f||G}
    aria-label=${[n,i,f,o].filter(Boolean).join(`. `)}
    type="button"
    ?disabled=${e.disabled||e.entry.disabled&&!u&&!c}
    data-chat-model-setup=${u?`true`:G}
    @mouseenter=${_D}
    @click=${t=>{if(e.entry.disabled&&!c){t.stopPropagation(),u?.();return}e.onSelect(e.entry,t)}}
  >
    <span class="chat-controls__model-option-provider">
      ${mF(e.entry.provider)}
    </span>
    <span class="chat-controls__model-option-copy">
      <span class="chat-controls__model-option-title">
        <span class="chat-controls__model-option-name">${n}</span>
        ${e.entry.isDefault?H`<span
                class="chat-controls__model-state-label chat-controls__model-state-label--default"
                >${L(`chat.modelControls.default`)}</span
              >`:G}
        ${d?H`<span class="chat-controls__model-option-meta">${d}</span>`:G}
        ${l?H`<span
                class="chat-controls__model-option-auth-warning"
                data-chat-model-auth-warning
              >
                ${z.alertTriangle}<span>${f}</span>
              </span>`:G}
        ${e.entry.supportsTools===!1?H`<span class="chat-controls__model-chat-only-info" aria-hidden="true"
                >${z.info}</span
              >`:G}
      </span>
    </span>
    <span class="chat-controls__model-option-action">
      ${t?H`<span class="chat-controls__inline-select-check" aria-hidden="true"
              >${z.check}</span
            >`:cF()}
    </span>
  </button>`;return s?H`<openclaw-tooltip .content=${s}> ${p} </openclaw-tooltip>`:p}function gF(e){return H`
    <button
      class="chat-controls__inline-select-option chat-controls__model-option"
      data-chat-model-option=${`target:${e.groupId}:${e.entry.value}`}
      data-chat-model-target=${e.entry.value}
      data-chat-model-index=${e.index}
      data-chat-model-name=${e.entry.label.toLocaleLowerCase()}
      data-chat-model-provider-label=${e.groupLabel.toLocaleLowerCase()}
      role="option"
      aria-selected="false"
      type="button"
      ?disabled=${e.disabled}
      @mouseenter=${_D}
      @click=${t=>e.onSelect(e.groupId,e.entry.value,t)}
    >
      <span
        class="chat-controls__model-option-provider chat-controls__target-icon"
        aria-hidden="true"
        >${z.terminal}</span
      >
      <span class="chat-controls__model-option-copy">
        <span class="chat-controls__model-option-title">
          <span class="chat-controls__model-option-name">${e.entry.label}</span>
        </span>
      </span>
      <span class="chat-controls__model-option-action"> ${cF()} </span>
    </button>
  `}var _F;function vF(){return(vF=e((()=>{K(),B(),rn(),Js(),V(),R(),Oi(),we(),DD(),Xr(),_F={"claude-cli":`Claude CLI`,codex:`Codex`,"codex-cli":`Codex`,"google-gemini-cli":`Gemini CLI`,openclaw:`OpenClaw`}})))()}function yF(e,t){let n=e.options.find(t=>t.id===e.selected);if(!n)return G;let r=L(`chat.modelControls.contextWindowAria`,{state:n.label}),i;if(e.options.length===2){let[a,o]=[...e.options].toSorted((e,t)=>e.contextWindow-t.contextWindow);if(!a||!o)return G;let s=n.id===o.id,c=s?a:o;i=H`
      <button
        class="chat-controls__speed-toggle ${s?`chat-controls__speed-toggle--active`:``}"
        data-chat-context-window-toggle=${c.id}
        type="button"
        role="switch"
        aria-checked=${s?`true`:`false`}
        aria-label=${r}
        ?disabled=${e.disabled}
        @click=${n=>{if(n.stopPropagation(),e.disabled){n.preventDefault();return}e.onSelect(c.id,t)}}
      >
        <span class="chat-controls__speed-toggle-thumb"></span>
      </button>
    `}else i=pl({mode:`buttons`,variant:`compact`,className:`chat-controls__context-window-options`,value:n.id,ariaLabel:r,disabled:e.disabled,options:e.options.map(e=>({value:e.id,label:e.label})),onClick:(t,r)=>{t.stopPropagation(),(e.disabled||r===n.id)&&t.preventDefault()},onChange:n=>{e.onSelect(n,t)}});return H`
    <div class="chat-controls__fast-mode-row chat-controls__context-window-row">
      <span
        class="chat-controls__fast-mode-icon chat-controls__context-window-icon"
        aria-hidden="true"
        >${z.scrollText}</span
      >
      <span class="chat-controls__fast-mode-copy">
        <span class="chat-controls__fast-mode-title">
          ${L(`chat.modelControls.contextWindow`)}
        </span>
        <span class="chat-controls__fast-mode-description">${n.label}</span>
      </span>
      ${i}
    </div>
  `}function bF(){return(bF=e((()=>{K(),B(),Vc(),R(),Oi(),Xr()})))()}function xF(e){if(!e||e.status!==`loading`&&!(e.status===`ready`&&e.pendingProviders?.length))return G;let t=e.pendingProviders?.map(Mc).join(`, `),n=t?L(`chat.modelControls.refreshingProviderModels`,{providers:t}):L(`chat.modelControls.refreshingModels`);return H`
    <span class="chat-controls__model-refresh" data-chat-model-refresh role="status">
      <openclaw-tooltip .content=${n} .describe=${!1} open-on-click>
        <button class="chat-controls__model-refresh-details" type="button" aria-label=${n}>
          <span class="btn__spinner" aria-hidden="true"></span>
        </button>
      </openclaw-tooltip>
      <span class="sr-only">${n}</span>
    </span>
  `}function SF(e,t,n,r,i=L(`chat.modelControls.modelsUnavailable`),a){if(!e)return G;let{status:o}=e,s=!!e.pendingProviders?.length;if(o===`ready`&&n&&!s||t&&(o===`loading`||o===`ready`&&s))return G;let c=o===`offline`?L(`common.offline`):o===`error`?t?L(`chat.modelControls.modelsRefreshFailed`):i:L(o===`ready`&&!s?e.modelSelectionPolicy?.restricted?`chat.modelControls.noPermittedModels`:`chat.modelControls.noModelsAvailable`:`chat.modelControls.loadingModels`);return H`
    <div
      class="chat-controls__model-catalog-state ${t?``:`chat-controls__model-catalog-state--empty`}"
      data-chat-model-catalog-state=${o}
      role="status"
      aria-live="polite"
    >
      <span class="chat-controls__model-catalog-state-label">
        ${o===`error`?z.alertTriangle:o===`loading`||o===`idle`||o===`ready`&&s?H`<span class="btn__spinner" aria-hidden="true"></span>`:G}
        <span>${c}</span>
      </span>
      ${o===`error`&&a?H`
              <button
                class="chat-controls__model-catalog-action"
                data-chat-model-target-retry=${a.groupId}
                type="button"
                ?disabled=${a.disabled}
                @click=${e=>{e.stopPropagation(),a.onRetry(a.groupId)}}
              >
                ${L(`common.retry`)}
              </button>
            `:G}
      ${o===`ready`&&!n&&r?H`
              <button
                class="chat-controls__model-catalog-action"
                data-chat-model-setup="true"
                type="button"
                @click=${e=>{e.stopPropagation(),r()}}
              >
                ${L(`chat.modelControls.emptyModelsAction`)}
              </button>
            `:G}
    </div>
  `}function CF(){return(CF=e((()=>{K(),B(),Js(),V(),R(),Oi(),Xr()})))()}function wF(e){let t=e.currentTarget.closest(`details`);t&&(t.open=!1,e.detail===0&&t.querySelector(`summary`)?.focus({preventScroll:!0}))}function TF(e){let t=e.modelOptions.find(e=>e.isDefault),n=e.modelOptions.find(t=>uF(t,e.selectedModelValue,e.selectedAgentRuntime)),r=n??t,i=e.triggerModelValue,a=i===void 0?n:i===``?void 0:e.modelOptions.find(t=>uF(t,i,e.selectedAgentRuntime)),o=a?.supportsTools===!1,s=e.contextWindow?.options.find(t=>t.id===e.contextWindow?.selected),c=s!==void 0&&e.contextWindow?.selected!==e.contextWindow?.defaultId,l=[e.triggerStatusLabel??e.triggerModelLabel,e.triggerStarting?L(`chat.modelControls.modelStarting`):``,o?L(`chat.modelControls.chatOnly`):``].filter(Boolean).join(` · `),u=!e.triggerLoading&&!e.triggerStatusLabel&&a&&Ql(a.provider)?kc(a.provider,{className:`chat-controls__trigger-provider-icon`}):G,d=new Map;for(let t of e.modelOptions){let e=d.get(t.provider);e?t.isDefault?e.unshift(t):t===r?e.splice(+!!e[0]?.isDefault,0,t):e.push(t):d.set(t.provider,[t])}let f=[...d],p=f.findIndex(([e])=>e===r?.provider);if(p>0){let[e]=f.splice(p,1);e&&f.unshift(e)}let m=f.flatMap(([,e])=>e),h=new Map(m.map((e,t)=>[lF(e),t])),g=e.targetGroups??[],_=g.reduce((e,t)=>e+t.options.length,0),v=e.modelOptions.length+_>0||g.some(e=>e.status!==`ready`),y=e.modelOptions.some(e=>!e.disabled),b=t=>{e.modelSelectionLocked||(e.onModelSelect(t.commitValue,e.sessionKey,t.runtimeOverride??(t.isDefault||t.agentRuntime!==void 0?null:void 0)).finally(()=>e.onRequestUpdate?.()),e.onRequestUpdate?.())},x=(t,n)=>{n.stopPropagation();let r=t.isDefault&&e.sessionModelPinned;if(e.disabled||e.modelSelectionLocked||t.disabled&&!r){n.preventDefault();return}b(t),wF(n)},S=(t,n,r)=>{if(r.stopPropagation(),e.disabled||e.modelSelectionLocked){r.preventDefault();return}e.onTargetSelect?.(t,n),wF(r)};return H`
    <details
      class="chat-controls__inline-select chat-controls__model-picker"
      data-chat-autotype-shortcuts
      ?open=${e.open===!0}
      ${U(e=>ED(e))}
      @keydown=${TD}
      @toggle=${t=>{let n=t.currentTarget;if(e.onOpenChange?.(n.open),ID(t),BD(n),!n.open){e.accountSection?.onClose(),xD(n);return}e.onOpen?.(),ED(n)}}
    >
      <summary
        class="chat-controls__inline-select-trigger chat-controls__model-trigger ${e.triggerLoading?`chat-controls__model-trigger--loading`:``} ${e.disabled?`chat-controls__inline-select-trigger--disabled`:``}"
        data-chat-model-select="true"
        data-chat-model-locked=${e.modelSelectionLocked?`true`:`false`}
        data-chat-select-value=${e.selectedModelValue}
        data-chat-model-tools=${o?`unavailable`:`available`}
        aria-label=${`${L(`chat.selectors.model`)}: ${l}${e.selectionScopeDescription?`. ${e.selectionScopeDescription}`:``}`}
        aria-busy=${e.triggerLoading||e.triggerStarting?`true`:`false`}
        aria-disabled=${e.disabled?`true`:`false`}
        title=${e.disabledReason?.trim()||G}
        @click=${t=>{if(e.disabled){t.preventDefault();return}t.currentTarget.focus({preventScroll:!0})}}
      >
        ${o?H`
                <openclaw-tooltip .content=${L(`chat.modelControls.chatOnlyHelp`)}>
                  <span class="chat-controls__model-capability-badge" aria-hidden="true">
                    ${z.alertTriangle}
                    <span>${L(`chat.modelControls.chatOnly`)}</span>
                  </span>
                </openclaw-tooltip>
              `:G}
        ${u}
        <span class="chat-controls__inline-select-label">
          ${e.triggerLoading?H`<span
                  class="skeleton chat-controls__model-trigger-skeleton"
                  aria-hidden="true"
                ></span>`:e.triggerStatusLabel??e.triggerModelLabel}
        </span>
        ${c?H`
                <span
                  class="chat-controls__locked-model-badge chat-controls__model-context-badge"
                  data-chat-model-context-badge
                >
                  ${s.label}
                </span>
              `:G}
        <span class="chat-controls__inline-select-chevron" aria-hidden="true"
          >${e.triggerStarting?H`<span class="btn__spinner"></span>`:z.chevronUp}</span
        >
      </summary>
      <wa-popup data-anchored-overlay>
        <div
          class="chat-controls__inline-select-menu chat-controls__model-menu"
          aria-label=${L(`chat.selectors.model`)}
        >
          ${e.modelSelectionLocked?H`
                  <div
                    class="chat-controls__locked-model"
                    aria-label=${L(`chat.selectors.modelLockedLabel`)}
                  >
                    <span class="chat-controls__inline-select-section-label">
                      ${L(`chat.selectors.modelSection`)}
                    </span>
                    <span class="chat-controls__locked-model-value"
                      >${e.triggerModelLabel}</span
                    >
                    <span class="chat-controls__locked-model-badge">
                      ${L(`chat.selectors.modelLocked`)}
                    </span>
                  </div>
                `:H`
                  ${v||e.accountSection?H`
                          <div class="chat-controls__model-search-wrap">
                            ${z.search}
                            <input
                              class="chat-controls__model-search"
                              data-chat-model-search="true"
                              type="search"
                              role="combobox"
                              aria-autocomplete="list"
                              autocomplete="off"
                              spellcheck="false"
                              placeholder=${L(`chat.modelControls.searchModels`)}
                              aria-label=${L(`chat.modelControls.searchModels`)}
                              ?disabled=${e.disabled}
                              @input=${e=>bD(e.currentTarget)}
                              @keydown=${wD}
                            />
                            ${e.modelOptions.length>0?xF(e.modelCatalogState):G}
                          </div>
                        `:G}
                  ${SF(e.modelCatalogState,e.modelOptions.length>0,y,e.onModelSetup)}
                  ${v||e.accountSection?H`
                          <div class="chat-controls__model-options">
                            ${q(f,([e])=>e,([t,r])=>{let i=e.providerAuth?.get(t),a=i&&!(i.kind===`missing`&&r.some(e=>e.disabled&&(e.unavailableReason===`missing-auth`||e.unavailableReason===`auth-failed`))),o=a?[i.label,i.detail].filter(Boolean).join(` · `):void 0,s=Sd(t),c=s?L(`chat.modelControls.routes.${s}.detail`):void 0;return H`
                                  <section
                                    class="chat-controls__provider-model-group"
                                    data-chat-model-provider-group=${t}
                                    aria-label=${L(`chat.modelControls.providerModels`,{provider:Mc(t)})}
                                  >
                                    <div
                                      class="chat-controls__provider-heading"
                                      data-chat-model-provider=${t}
                                      title=${[c,o].filter(Boolean).join(` · `)||G}
                                    >
                                      <button
                                        class="chat-controls__provider-toggle"
                                        type="button"
                                        data-chat-model-group-toggle
                                        data-chat-model-provider-toggle
                                        aria-expanded=${String(t===n?.provider)}
                                        aria-label=${`${L(`chat.modelControls.providerModels`,{provider:Mc(t)})} (${r.length})`}
                                        aria-description=${c??G}
                                        ?disabled=${e.disabled}
                                        @click=${SD}
                                      >
                                        ${mF(t)}
                                        <span class="chat-controls__provider-label"
                                          >${Mc(t)}</span
                                        >
                                        <span>${r.length}</span>
                                        <span
                                          class="chat-controls__inline-select-chevron"
                                          aria-hidden="true"
                                          >${z.chevronDown}</span
                                        >
                                      </button>
                                      ${a?H`<span class="chat-controls__auth-meta" data-auth-kind=${i.kind}><span aria-hidden="true">${i.kind===`subscription`?z.circleUser:i.kind===`api`?z.key:z.alertTriangle}</span><span class="chat-controls__auth-meta-label">${o}</span></span>`:G}
                                      ${e.onProviderSettings?H`<button
                                              class="chat-controls__provider-settings"
                                              data-chat-model-provider-settings
                                              type="button"
                                              aria-label=${L(`chat.modelControls.configureModels`)}
                                              @click=${n=>{n.stopPropagation(),e.onProviderSettings?.(t)}}
                                            >
                                              ${z.settings}
                                            </button>`:G}
                                    </div>
                                    <div
                                      class="chat-controls__provider-model-list"
                                      data-chat-model-list="true"
                                      role="listbox"
                                      aria-label=${L(`chat.modelControls.providerModels`,{provider:Mc(t)})}
                                    >
                                      ${q(r,lF,t=>hF({disabled:e.disabled,entry:t,index:h.get(lF(t))??0,selectedModelValue:e.selectedModelValue,selectedAgentRuntime:e.selectedAgentRuntime,sessionModelPinned:e.sessionModelPinned,onSelect:x,onModelSetup:e.onModelSetup}))}
                                    </div>
                                  </section>
                                `})}
                            ${q(g,e=>e.id,t=>H`
                                <section
                                  class="chat-controls__provider-model-group"
                                  data-chat-model-target-group=${t.id}
                                  aria-label=${t.label}
                                >
                                  <div class="chat-controls__provider-heading">
                                    <span
                                      class="chat-controls__provider-icon chat-controls__target-icon"
                                      aria-hidden="true"
                                      >${z.terminal}</span
                                    >
                                    <span>${t.label}</span>
                                  </div>
                                  ${t.status===`ready`?G:SF({hasSnapshot:!1,status:t.status},!1,!1,void 0,t.errorLabel,e.onTargetRetry?{disabled:e.disabled,groupId:t.id,onRetry:e.onTargetRetry}:void 0)}
                                  <div
                                    class="chat-controls__provider-model-list"
                                    data-chat-model-list="true"
                                    role="listbox"
                                    aria-label=${t.label}
                                  >
                                    ${q(t.options,e=>e.value,(n,r)=>gF({disabled:e.disabled,entry:n,groupId:t.id,groupLabel:t.label,index:m.length+r,onSelect:S}))}
                                  </div>
                                </section>
                              `)}
                            ${e.accountSection?.render(m.length+_)??G}
                          </div>
                          <div
                            class="chat-controls__model-search-empty"
                            data-chat-model-search-empty
                            hidden
                          >
                            ${L(`chat.modelControls.noMatchingModels`)}
                          </div>
                          ${e.contextWindow?yF(e.contextWindow,e.sessionKey):G}
                        `:G}
                `}
          ${e.modelSelectionLocked&&e.accountSection?H`<div class="chat-controls__model-options">
                  ${e.accountSection.render(0)}
                </div>`:G}
          ${e.modelCatalogState?.modelSelectionPolicy?.restricted?H`<div class="chat-controls__model-catalog-state" data-chat-model-policy>
                  ${L(`chat.modelControls.restrictedModelsHelp`)}
                </div>`:G}
        </div>
      </wa-popup>
    </details>
  `}function EF(){return(EF=e((()=>{K(),W(),ur(),B(),V(),Js(),R(),Oi(),bF(),CF(),vF(),DD(),qD(),Xr()})))()}function DF(e){let t=Se(e);return PF[t]??t}function OF(e){let t=new Map,n=new Map;for(let r of e){let e=r.id.trim().toLowerCase(),i=`${Se(r.provider)}/${e}`,a=t.get(i)??[];a.push(r),t.set(i,a);let o=n.get(e)??[];o.push(r),n.set(e,o)}return{provider(e,r=``){let i=e.trim(),a=i.toLowerCase(),o=t.get(a)?.[0];if(o)return DF(o.provider);let s=n.get(a)??[],c=Se(r),l=s.some(e=>Se(e.provider)===c);if(c&&(s.length===0||l))return DF(c);if(s.length===1)return DF(s[0]?.provider??``);let u=i.indexOf(`/`);return u>0?DF(i.slice(0,u)):`other`},entry(e){let r=e.trim().toLowerCase(),i=r.indexOf(`/`),a=i>0?`${Se(r.slice(0,i))}/${r.slice(i+1)}`:r;if(!a)return;let o=t.get(a)??[];if(o.length>0)return o.find(e=>e.provider.trim().toLowerCase()===`openai`)??o[0];let s=n.get(a)??[];return s.length===1?s[0]:void 0}}}function kF(e,t){return e&&Se(e.provider)===`openai`&&e.name.trim()||t}function AF(e){return/^Default \((.+)\)$/u.exec(e)?.[1]??e}function jF(e){switch(e){case`session`:return L(`chat.modelControls.selectionScopeSession`);case`agent`:return L(`chat.modelControls.selectionScopeAgent`);case`global`:return L(`chat.modelControls.selectionScopeGlobal`);default:return}}function MF(e,t,n){if(e.status!==`offline`){if(e.status===`error`)return t===0?L(`chat.modelControls.modelsUnavailable`):void 0;if(!e.hasSnapshot&&[`idle`,`loading`].includes(e.status))return n?void 0:L(`chat.modelControls.loadingModels`);if(e.hasSnapshot&&t===0)return L(`chat.modelControls.noModelsAvailable`)}}function NF(e){let t=OF(e.modelCatalog),n=e.modelCatalogState?.modelSelectionPolicy,r=e.modelCatalogState?.retired===!0,i=e.modelCatalogState?.initialized===!1,a=r||i||n?.restricted===!0,o=new Map,s=e=>DF(Ua(Se(e)));for(let t of ps((e.modelAuthStatusResult?.providers??[]).map(e=>Object.assign({},e,{provider:s(e.provider)})))){let n=e.accountSelection?.kind===`automatic`?void 0:e.accountSelection?.authProfileId,r=Oo(t,{authProfileId:n});r&&o.set(s(t.provider),r)}let{currentOverride:c,defaultModel:l,defaultLabel:u,modelOverrideSource:d,options:f}=so({activeSession:e.selectedSession,agentDefaultModel:e.agentDefaultModel,chatModelCatalog:e.modelCatalog,modelOverrides:e.modelOverrides??{},sessionKey:e.sessionKey,sessionsResult:e.sessionsResult,modelSelectionPolicy:n,catalogRetired:r,catalogInitialized:e.modelCatalogState?.initialized}),p=!a||!r&&t.entry(c)?c:``,m=ui({catalog:e.modelCatalog,defaults:e.thinkingDefaults,session:e.thinkingSession,sessionKey:e.sessionKey,sessionsResult:e.sessionsResult}),h=e.selectedSession,g=!!(e.activeRunId&&e.activeRunSessionKey&&je(e.activeRunSessionKey,e.sessionKey)),_=g?e.activeRunId:null,v=g?e.stream:null,y=Jr({activeRunId:_,catalog:e.modelCatalog,connected:e.connected,currentModelOverride:p,fastModeTarget:e.fastModeTarget??e.selectedSession,gatewayAvailable:e.gatewayAvailable,loading:e.loading,sending:e.sending,sessionsResult:e.sessionsResult,stream:v}),b=e.modelSwitching?{...y,disabled:!0}:y,S=h?.runtimeSelectionLocked===!0,C=h?.modelProvider??``,w=Object.hasOwn(e.modelOverrides??{},e.sessionKey),T=x(h??{}),E=e.sending||!!_||v!==null||T,D=T&&!e.sending&&(!_||(h?.activeRunIds?h.activeRunIds.includes(_):e.modelObservedRunId===_)),O=w?``:E?D&&h?.activeModel?.trim()&&h.activeModelProvider?.trim()?ie(h.activeModel,h.activeModelProvider):``:ue(h?.activeModel,h?.activeModelProvider,e.modelCatalog),k=!a||!r&&t.entry(O)?O:``,ee=E&&!k,te=k||p,ne=ee&&!!(te||!e.modelSelectionLocked&&l),re=e.sessionsResult?.defaults?.modelProvider??``,ae=t.entry(l),oe=kF(ae,u),A=l&&oe!==u?L(`chat.modelControls.defaultWithModel`,{model:oe}):u,j=l.trim().toLowerCase(),M=f.flatMap(n=>{let r=t.entry(n.value),i=n.value.trim().toLowerCase()===j||r!==void 0&&r===ae,a=r?.agentRuntime,o=a&&(a.source===`model`||a.source===`provider`||Sd(r?.provider??``,a.id))?a.id.trim():void 0,s={...r?.runtimeChoices?.length&&!S?{agentRuntime:a?.id??null,agentRuntimeId:a?.id}:{},commitValue:i?``:n.value,isDefault:i,value:n.value,label:kF(r,n.label),provider:t.provider(n.value,i?re:n.value===p?C:``)};o&&(s.agentRuntimeId=o),i&&yi(e.selectedSession?.agentRuntime)&&Sd(s.provider)&&(s.agentRuntimeId=void 0),r?.contextWindow&&(s.contextWindow=r.contextWindow),typeof r?.supportsTools==`boolean`&&(s.supportsTools=r.supportsTools),n.disabled&&(s.disabled=!0,s.unavailableReason=n.unavailableReason);let c=[s];for(let e of S?[]:r?.runtimeChoices??[])e.manualSelectionAllowed!==!1&&c.push({value:n.value,commitValue:n.value,isDefault:!1,label:s.label,provider:s.provider,agentRuntime:e.agentRuntime.id,runtimeOverride:e.agentRuntime.id,agentRuntimeId:e.agentRuntime.id,contextWindow:e.contextWindow,supportsTools:e.supportsTools,disabled:e.available===!1,unavailableReason:e.unavailableReason});return c}),se=e.selectedSession?.modelOverrideSource===`user`||!S&&yi(e.selectedSession?.agentRuntime);l&&(se||n?.restricted)&&!r&&!i&&!M.some(e=>e.isDefault)&&M.unshift({commitValue:``,isDefault:!0,value:l,label:AF(A),provider:t.provider(l,re)});let ce=t.entry(p);p&&(!a||ce)&&ce?.manualSelectionAllowed!==!1&&M.length>0&&!M.some(e=>e.value===p)&&M.push({commitValue:p,...ce?.contextWindow?{contextWindow:ce.contextWindow}:{},...typeof ce?.supportsTools==`boolean`?{supportsTools:ce.supportsTools}:{},...ce?.available===!1?{disabled:!0,unavailableReason:ce.unavailableReason}:{},isDefault:!1,value:p,label:ce?.name.trim()||p,provider:t.provider(p,C)});let le=e.selectedAgentRuntime??e.selectedSession?.agentRuntime?.id??t.entry(p||l)?.agentRuntime?.id,de=ae?.agentRuntime?.id??e.sessionsResult?.defaults?.agentRuntime?.id,N=d===null&&(!le||le===de)?``:p||l,fe=M.find(e=>uF(e,N,le)),pe=h?.model?t.entry(ue(h.model,h.modelProvider,e.modelCatalog)):void 0,me=fe?t.entry(fe.value):void 0,he=h?.agentRuntime?.id.trim().toLowerCase(),ge=(Si(me,fe?.agentRuntime)?.agentRuntime?.id??(fe?.isDefault?e.sessionsResult?.defaults?.agentRuntime?.id:void 0))?.trim().toLowerCase(),_e=!!he&&he===ge;!e.modelSwitching&&fe&&h?.contextTokens&&_e&&pe!==void 0&&pe===me&&(fe.contextTokens=h.contextTokens);let ve=e.modelSelectionLocked===!0&&!te?L(`chat.selectors.lockedSessionModel`):M.find(e=>e.value===te)?.label??kF(t.entry(te),te||A),ye=e.modelCatalogState??{hasSnapshot:!e.modelsLoading,status:e.modelsLoading?`loading`:`ready`},be=!ye.hasSnapshot&&[`idle`,`loading`].includes(ye.status),xe=!!(p||d===null&&l),Ce=r?MF(ye,0,!1):n?.restricted&&!p&&!l?L(M.length?`chat.modelControls.selectionRequired`:`chat.modelControls.noPermittedModels`):MF(ye,M.length,xe),we=ye.status===`ready`&&fe?.disabled!==!0&&M.some(e=>!e.disabled),Te=e.sending||!!e.activeRunId||e.stream!==null,Ee=!e.connected||Te||e.modelSwitching||!e.gatewayAvailable,De=Ee||e.loading,P=!!e.effortMutationDisabledReason,F=Ee||!!e.modelMutationDisabledReason,Oe=De||P||!ye.hasSnapshot||m.options.length===0&&m.selection.source==="default",ke=e.contextWindowTarget??h??e.sessionsResult?.defaults,I=ke?.contextWindows??[],Ae=ke?.contextWindow??ke?.contextWindowDefault??``,Me=ke?.contextWindowDefault,Ne=De||P||m.options.length===0&&b.disabled,Pe=!we&&(be||e.modelPickerOpen===!0),Fe=we||Pe;return H`
    <div class="chat-controls__session chat-controls__model chat-controls__model-settings">
      ${TF({providerAuth:e.modelAuthStatusResult?o:void 0,accountSection:e.renderAccountSection?.(p||l),contextWindow:I.length>1?{options:I,selected:Ae,...Me?{defaultId:Me}:{},disabled:De||!!e.contextWindowMutationDisabledReason,onSelect:async(t,n)=>{await e.onContextWindowSelect?.(t,n)}}:void 0,disabled:F,disabledReason:e.modelMutationDisabledReason,modelCatalogState:ye,open:e.modelPickerOpen,modelSelectionLocked:e.modelSelectionLocked===!0,selectionScopeDescription:n?.restricted?L(`chat.modelControls.restrictedModelsHelp`):jF(e.modelSelectionTarget),modelOptions:M,targetGroups:e.modelPickerTargetGroups,selectedModelValue:N,selectedAgentRuntime:le,sessionModelPinned:se,sessionKey:e.sessionKey,triggerModelLabel:AF(ve),triggerModelValue:ee&&!ne?``:te||void 0,triggerStarting:ne,triggerStatusLabel:ne?void 0:ee?L(`chat.modelControls.modelPending`):e.modelSelectionLocked?void 0:Ce,triggerLoading:!ee&&!e.modelSelectionLocked&&be&&!xe,onModelSetup:n?.restricted||r||i?void 0:e.onModelSetup,onProviderSettings:n?.restricted||r||i?void 0:e.onProviderSettings,onOpen:e.onModelPickerOpen,onOpenChange:e.onModelPickerOpenChange,onModelSelect:async(t,n,r)=>e.onModelSelect?.(t,n,r),onTargetRetry:e.onModelPickerTargetRetry,onTargetSelect:e.onModelPickerTargetSelect,onRequestUpdate:e.onRequestUpdate})}
      ${Fe?oF({disabled:Ne,disabledReason:e.effortMutationDisabledReason,fastMode:{...b,disabled:b.disabled||De||P},sessionKey:e.sessionKey,thinkingDisabled:Oe,thinking:m,onFastModeSelect:async(t,n)=>e.onFastModeSelect?.(t,n),onRequestUpdate:e.onRequestUpdate,onThinkingSelect:async(t,n)=>e.onThinkingSelect?.(t,n),reserved:Pe}):G}
    </div>
  `}var PF;function FF(){return(FF=e((()=>{K(),R(),Oi(),he(),Vr(),Wi(),pa(),po(),it(),sF(),vF(),EF(),Xr(),PF={"google-gemini-cli":`google`,"moonshot-ai":`moonshot`,moonshotai:`moonshot`,"opencode-go":`opencode`,"opencode-zen":`opencode`}})))()}export{qA as $,Ex as $n,Uf as $r,jT as $t,cN as A,PS as An,xp as Ar,ND as At,Lj as B,xS as Bn,sp as Br,FE as Bt,_N as C,Tw as Cn,Om as Cr,hO as Ct,pN as D,BC as Dn,bm as Dr,cO as Dt,mN as E,RC as En,xm as Er,_O as Et,VM as F,GS as Fn,bp as Fr,AE as Ft,Dj as G,sS as Gn,Qf as Gr,uE as Gt,Ij as H,mS as Hn,hp as Hr,yE as Ht,vM as I,qS as In,vp as Ir,HE as It,Sj as J,kx as Jn,lp as Jr,QT as Jt,Cj as K,Kx as Kn,ap as Kr,pE as Kt,gM as L,kS as Ln,pp as Lr,JE as Lt,oN as M,BS as Mn,Qp as Mr,uD as Mt,eN as N,ZS as Nn,Wp as Nr,$E as Nt,lN as O,VC as On,tm as Or,iO as Ot,WM as P,KS as Pn,Fp as Pr,cD as Pt,KA as Q,gx as Qn,Rf as Qr,PT as Qt,Zj as R,DS as Rn,mp as Rr,qE as Rt,vN as S,Dw as Sn,km as Sr,dO as St,hN as T,HC as Tn,ym as Tr,pO as Tt,Pj as U,lS as Un,tp as Ur,SE as Ut,Fj as V,pS as Vn,$f as Vr,oE as Vt,Nj as W,cS as Wn,ep as Wr,bE as Wt,JA as X,jx as Xn,Hf as Xr,IT as Xt,xj as Y,Nx as Yn,cp as Yr,FT as Yt,YA as Z,mx as Zn,Bf as Zr,NT as Zt,ON as _,Gw as _n,Sh as _r,jk as _t,tF as a,Af as ai,_T as an,ay as ar,lA as at,CN as b,Uw as bn,Xm as br,uO as bt,JP as c,ST as cn,Kv as cr,dA as ct,IP as d,oT as dn,av as dr,Uk as dt,Jf as ei,kT as en,hx as er,RA as et,IN as f,Xw as fn,iv as fr,Bk as ft,AN as g,Hw as gn,Eh as gr,Fk as gt,NN as h,Kw as hn,O_ as hr,Nk as ht,nF as i,Df as ii,vT as in,Hb as ir,EA as it,sN as j,JS as jn,Kp as jr,XE as jt,uN as k,YS as kn,gm as kr,qD as kt,GP as l,dT as ln,Ov as lr,yA as lt,PN as m,qw as mn,j_ as mr,Pk as mt,NF as n,zf as ni,gT as nn,_x as nr,PA as nt,eF as o,Of as oi,OT as on,iy as or,fA as ot,FN as p,Zw as pn,D_ as pr,Vk as pt,wj as q,Ux as qn,up as qr,ZT as qt,iF as r,Wf as ri,hT as rn,Wb as rr,NA as rt,ZP as s,kf as si,CT as sn,ry as sr,CA as st,FF as t,Vf as ti,MT as tn,xx as tr,MA as tt,HP as u,sT as un,Mv as ur,zk as ut,TN as v,Lw as vn,ch as vr,Mk as vt,gN as w,bw as wn,Sm as wr,mO as wt,bN as x,Bw as xn,nh as xr,TO as xt,wN as y,Fw as yn,ah as yr,fO as yt,Kj as z,jS as zn,op as zr,jE as zt};