import{n as e}from"./rolldown-runtime-8BhlS34s.js";import{or as t,sr as n}from"./control-ui-core-D6clmJs8.js";import{$ as r,C as i,T as a,Y as o}from"./lit-runtime-DZL1fcCI.js";import"./settings-DdI5hVp3.js";function s(e,t={}){let i=t.fillHeight?`settings-workspace settings-workspace--fill-height`:`settings-workspace`;return r`
    <section
      class=${i}
      ${n({settingsWorkspace:!0})}
      id=${a(t.id)}
      role=${a(t.role)}
      aria-label=${a(t.ariaLabel)}
    >
      <div class="settings-workspace__body">${e}</div>
    </section>
  `}function c(){return(c=e((()=>{o(),i(),t()})))()}export{s as n,c as t};