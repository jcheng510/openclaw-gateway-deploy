import{n as e}from"./rolldown-runtime-8BhlS34s.js";import{Br as t,Gi as n,qr as r,zr as i}from"./control-ui-foundation-C3MHh_P-.js";import{cc as a,hu as o,lu as s,sc as c,su as l,uu as u}from"./control-ui-core-pYNj5S1a.js";import{Fa as d,Ia as f,Ma as p,Va as m,Xi as h,Zi as g,_r as _,fr as v,or as y,sr as b,va as x,vi as S,yi as C,za as w}from"./control-ui-core-D6clmJs8.js";import{$ as T,X as E,Y as D}from"./lit-runtime-DZL1fcCI.js";import{_i as O,bi as k,vi as A,xi as j,yi as M}from"./control-ui-boot-shared-3Hl8ksFq.js";import{n as N,t as P}from"./en-apps-Dcp-B6xB.js";import{n as F,t as I}from"./settings-workspace-DKW0BVnu.js";import{n as L,t as ee}from"./brand-icons-C3i78qLU.js";import{t as R}from"./native-chrome-setup-jdIZ7Nn9.js";function z(e,t){try{let n=new URL(typeof t==`string`?t:e);if(n.protocol===`wss:`&&(n.protocol=`https:`),n.protocol!==`https:`||n.username||n.password||n.href.includes(`?`)||n.href.includes(`#`))return null;let r=new URL(`openclaw://gateway/add`);return r.searchParams.set(`url`,n.href),r.href}catch{return null}}var B;function V(){return(V=e((()=>{D(),B={watch:T`
    <svg viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="6" />
      <polyline points="12 10 12 12 13 13" />
      <path d="m16.13 7.66-.81-4.05a2 2 0 0 0-2-1.61h-2.68a2 2 0 0 0-2 1.61l-.78 4.05" />
      <path d="m7.88 16.36.8 4a2 2 0 0 0 2 1.61h2.72a2 2 0 0 0 2-1.61l.81-4.05" />
    </svg>
  `,apple:T`
    <svg viewBox="0 0 24 24" class="icon--filled">
      <path
        d="M17.05 12.54c-.03-2.62 2.14-3.88 2.24-3.94-1.22-1.79-3.12-2.03-3.8-2.06-1.61-.16-3.15.95-3.97.95-.82 0-2.08-.93-3.42-.9-1.76.03-3.38 1.02-4.29 2.6-1.83 3.17-.47 7.87 1.31 10.44.87 1.26 1.91 2.67 3.27 2.62 1.31-.05 1.81-.85 3.4-.85 1.58 0 2.03.85 3.42.82 1.41-.02 2.31-1.28 3.17-2.55.99-1.46 1.4-2.87 1.42-2.94-.03-.02-2.73-1.05-2.75-4.19Zm-2.6-7.68c.72-.88 1.21-2.09 1.08-3.3-1.04.04-2.3.69-3.05 1.56-.67.78-1.26 2.02-1.1 3.2 1.16.09 2.34-.59 3.07-1.46Z"
      />
    </svg>
  `,android:T`
    <svg viewBox="0 0 24 24" class="icon--filled">
      <path
        d="M17.52 15.05a.98.98 0 1 1 .01-1.96.98.98 0 0 1-.01 1.96m-11.04 0a.98.98 0 1 1 .01-1.96.98.98 0 0 1-.01 1.96m11.39-5.89 1.96-3.39a.4.4 0 0 0-.15-.55.4.4 0 0 0-.55.15l-1.98 3.43A12.03 12.03 0 0 0 12 7.75c-1.85 0-3.6.42-5.15 1.05L4.87 5.37a.4.4 0 0 0-.55-.15.4.4 0 0 0-.15.55l1.96 3.39C2.75 11 .48 14.42.14 18.4h23.72c-.34-3.98-2.61-7.4-5.99-9.24"
      />
    </svg>
  `,windows:T`
    <svg viewBox="0 0 24 24" class="icon--filled">
      <path
        d="M3 5.55 10.29 4.5v7.02H3V5.55Zm0 12.9 7.29 1.05v-6.93H3v5.88Zm8.09 1.16L21 21v-8.43h-9.91v7.04Zm0-15.22v7.13H21V3l-9.91 1.39Z"
      />
    </svg>
  `,linux:T`
    <svg viewBox="0 0 24 24" class="icon--filled">
      <path
        fill-rule="evenodd"
        d="M12 2c-2.76 0-5 2.24-5 5v3.1c0 1.35-.62 2.5-1.32 3.6C4.6 15.4 4 16.9 4 18.3 4 20.9 7.58 22 12 22s8-1.1 8-3.7c0-1.4-.6-2.9-1.68-4.6-.7-1.1-1.32-2.25-1.32-3.6V7c0-2.76-2.24-5-5-5Zm-2 4.5a1 1 0 1 1 0 2 1 1 0 0 1 0-2Zm4 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2Zm-2 2.7 1.8 1.3c.3.24.3.7-.02.92L12 12.6l-1.78-1.18a.58.58 0 0 1-.02-.93L12 9.2Z"
      />
    </svg>
  `,chrome:T`
    <svg viewBox="0 0 24 24" class="icon--filled">
      <path
        d="M12 2a10 10 0 0 1 8.66 5H12a5 5 0 0 0-4.79 3.57L4.4 5.72A9.98 9.98 0 0 1 12 2Zm9.54 7A10 10 0 0 1 12 22l-.34-.01 4.36-7.55A4.98 4.98 0 0 0 17 12c0-1.13-.37-2.16-1-3h5.54ZM3.35 7.57l4.36 7.56a5 5 0 0 0 6.16 2.24l-2.81 4.87A10 10 0 0 1 3.35 7.57ZM12 8.5a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7Z"
      />
    </svg>
  `}})))()}function H(e,t,n){let r=t===0?`apps-card__cta apps-card__cta--primary`:`apps-card__cta`;return e.kind===`internal`?T`
      <button type="button" class=${r} @click=${()=>n.onNavigate(e.routeId)}>
        ${o(e.labelKey)}
      </button>
    `:T`
    <a
      class=${r}
      href=${e.href}
      target=${M}
      rel=${k()}
    >
      ${o(e.labelKey)}
    </a>
  `}function U(e,t){let[n,r]=e.gradient,i=e.id===`macos`?t.macGatewayLaunchUrl:null;return T`
    <article class="apps-card">
      <div class="apps-card__art" style=${`--apps-art-a:${n};--apps-art-b:${r}`}>
        ${[`light`,`dark`].map(t=>T`<img
            class="apps-card__art-img apps-card__art-img--${t}"
            src=${d(`app-art/${e.id}${t===`dark`?`-dark`:``}.webp`)}
            alt=""
            loading="lazy"
            decoding="async"
          />`)}
      </div>
      <div class="apps-card__body">
        <div class="apps-card__title-row">
          <span class="apps-card__icon" aria-hidden="true">${e.icon}</span>
          <h3 class="apps-card__title">${o(`${e.copyKey}.title`)}</h3>
          ${e.badge?T`<span class="apps-card__badge">${o(e.badge)}</span>`:E}
        </div>
        <p class="apps-card__desc">${o(`${e.copyKey}.desc`)}</p>
        <div class="apps-card__ctas">
          ${i?T`<a class="apps-card__cta apps-card__cta--primary" href=${i}>
                  ${o(`appsPage.ctaOpenMac`)}
                </a>`:E}
          ${e.ctas.map((e,n)=>H(e,n+ +!!i,t))}
        </div>
        ${e.id===`chrome-extension`?T`<openclaw-native-chrome-setup></openclaw-native-chrome-setup>`:E}
      </div>
    </article>
  `}function W(e,t){let n=e.id===`mobile`&&t.onPairDevice?T`
          <p class="apps-pair-hint">
            ${o(`appsPage.havePhone`)}
            <button type="button" @click=${t.onPairDevice}>${o(`appsPage.pairDevice`)}</button>
          </p>
        `:E;return T`
    <section class="apps-section" aria-label=${o(e.labelKey)}>
      <h2 class="apps-section__heading">${o(e.labelKey)}</h2>
      <div class="apps-grid">${e.cards.map(e=>U(e,t))}</div>
      ${n}
    </section>
  `}function G(){return T`
    <section class="apps-section" aria-label=${o(`appsPage.sectionCommunity`)}>
      <h2 class="apps-section__heading">${o(`appsPage.sectionCommunity`)}</h2>
      <nav class="apps-community" aria-label=${o(`appsPage.sectionCommunity`)}>
        ${X.map(e=>T`
            <a
              class="apps-pill"
              href=${e.href}
              target=${M}
              rel=${k()}
            >
              <span class="apps-pill__icon" aria-hidden="true">${e.icon}</span>
              <span>${o(e.labelKey)}</span>
            </a>
          `)}
      </nav>
    </section>
  `}function K(e){return T`
    <div class="apps-page">
      <section class="apps-hero">
        <h1 class="apps-hero__title">${o(`appsPage.heroTitle`)}</h1>
        <p class="apps-hero__tagline">${o(`appsPage.heroTagline`)}</p>
      </section>
      ${Y.map(t=>W(t,e))} ${G()}
    </div>
  `}var q,J,Y,X;function Z(){return(Z=e((()=>{D(),f(),g(),u(),P(),j(),A(),R(),L(),V(),N(),q=(e,t)=>({kind:`external`,href:e,labelKey:t}),J=e=>q(`https://docs.openclaw.ai${e}`,`appsPage.ctaDocs`),Y=[{id:`mobile`,labelKey:`appsPage.sectionMobile`,cards:[{id:`ios`,gradient:[`#38bdf8`,`#1d4ed8`],icon:B.apple,copyKey:`appsPage.cards.ios`,ctas:[q(`https://apps.apple.com/app/openclaw-ai-that-does-things/id6780396132`,`appsPage.ctaAppStore`),J(`/platforms/ios`)]},{id:`android`,gradient:[`#34d399`,`#047857`],icon:B.android,copyKey:`appsPage.cards.android`,ctas:[q(`https://play.google.com/store/apps/details?id=ai.openclaw.app`,`appsPage.ctaPlayStore`),J(`/platforms/android`)]}]},{id:`watch`,labelKey:`appsPage.sectionWatch`,cards:[{id:`apple-watch`,gradient:[`#f472b6`,`#be185d`],icon:B.watch,copyKey:`appsPage.cards.appleWatch`,badge:`appsPage.badgeBundledIos`,ctas:[J(`/platforms/ios`)]},{id:`wear-os`,gradient:[`#22d3ee`,`#0e7490`],icon:B.watch,copyKey:`appsPage.cards.wearOs`,badge:`appsPage.badgeBundledAndroid`,ctas:[J(`/platforms/android`)]}]},{id:`desktop`,labelKey:`appsPage.sectionDesktop`,cards:[{id:`macos`,gradient:[`#a855f7`,`#6b21a8`],icon:B.apple,copyKey:`appsPage.cards.macos`,ctas:[q(`https://github.com/openclaw/openclaw/releases`,`appsPage.ctaDownload`),J(`/platforms/macos`)]},{id:`windows`,gradient:[`#818cf8`,`#4338ca`],icon:B.windows,copyKey:`appsPage.cards.windows`,ctas:[q(`https://github.com/openclaw/openclaw-windows-node/releases/latest`,`appsPage.ctaDownload`),J(`/platforms/windows`)]},{id:`linux`,gradient:[`#fbbf24`,`#b45309`],icon:B.linux,copyKey:`appsPage.cards.linux`,ctas:[q(`https://github.com/openclaw/openclaw/releases`,`appsPage.ctaDownload`),J(`/platforms/linux`)]}]},{id:`browser`,labelKey:`appsPage.sectionBrowser`,cards:[{id:`chrome-extension`,gradient:[`#f59e0b`,`#ea580c`],icon:B.chrome,copyKey:`appsPage.cards.chrome`,ctas:[q(`https://chromewebstore.google.com/detail/openclaw/kcdjddhmeafeomebliikmbpblkmkfoig`,`appsPage.ctaChromeWebStore`),q(`https://docs.openclaw.ai/tools/chrome-extension`,`appsPage.ctaSetupGuide`)]},{id:`plugins`,gradient:[`#fb7185`,`#9f1239`],icon:h.plug,copyKey:`appsPage.cards.plugins`,ctas:[{kind:`internal`,routeId:`plugins`,labelKey:`appsPage.ctaOpenPlugins`},q(`https://clawhub.ai`,`appsPage.ctaBrowseClawHub`)]}]}],X=[{href:O,icon:ee.discord,labelKey:`appsPage.linkDiscord`},{href:`https://docs.openclaw.ai`,icon:h.book,labelKey:`appsPage.linkDocs`}]})))()}var Q;function $(){return($=e((()=>{t(),D(),x(),C(),w(),_(),y(),I(),s(),a(),Z(),Q=class extends l{constructor(...e){super(...e),this.subscriptions=new c(this).watch(()=>this.context?.gateway,(e,t)=>e.subscribe(t))}disconnectedCallback(){this.subscriptions.clear(),super.disconnectedCallback()}render(){let e=this.context.gateway.snapshot,t=e.phase===`connected`&&v(e.hello?.auth??null),r=K({onNavigate:e=>this.context.navigate(e),macGatewayLaunchUrl:e.phase===`connected`&&!m()?z(this.context.gateway.connection.gatewayUrl,n(e.hello?.snapshot)?.controlUiIdentityUrl):null,onPairDevice:t?()=>void this.context.overlays.openDevicePairSetup():void 0});return T`
      <section class="content-header" ${b({toolbarHeader:!0})}>
        <div>
          <div class="page-title">${p(`apps`)}</div>
        </div>
      </section>
      ${F(r)}
    `}},r([i({context:S,subscribe:!0})],Q.prototype,`context`,void 0),customElements.get(`openclaw-apps-page`)||customElements.define(`openclaw-apps-page`,Q)})))()}$();