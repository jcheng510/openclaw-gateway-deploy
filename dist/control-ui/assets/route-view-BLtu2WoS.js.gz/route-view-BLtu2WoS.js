import{n as e}from"./rolldown-runtime-8BhlS34s.js";import{$ as t,Y as n}from"./lit-runtime-DZL1fcCI.js";function r(e){return t`
    <openclaw-custodian-page
      .onboarding=${e?.onboarding===!0}
      .newAgentIntent=${e?.intent===`new-agent`}
    ></openclaw-custodian-page>
  `}function i(){return(i=e((()=>{n()})))()}i();export{r as renderCustodianRoute};